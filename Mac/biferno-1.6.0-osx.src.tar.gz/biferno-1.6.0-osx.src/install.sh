#!/bin/sh
#
# Biferno install
#
#

# install
echo "pre install"
./scripts/preinstall

# checks
if [ ! -r Projects/bifernod/build/Release/bifernod ]
then
	echo "bifernod not found! Compile it and retry (see Readme.txt)"
	exit
fi
if [ ! -r Projects/bifernod/build/Release/bifernoctl ]
then
	echo "bifernoctl not found! Compile it (target bifernoctl of bifernod project) and retry (see Readme.txt)"
	exit
fi
if [ -r Projects/apachemodule/build/Release/mod_biferno.so ]
then
	cp Projects/apachemodule/build/Release/mod_biferno.so Projects/ApxsModule
fi
if [ ! -r Projects/ApxsModule/mod_biferno.so ]
then
	echo "apache module not found! Compile it and retry (see Readme.txt)"
	exit
fi

# copy mod_biferno in modules
HTTPDVERSION=`httpd -v | sed  -n -e '/Server version/s/  */./gp' | sed -n -e 's/\//./p' | awk -F. '{print $4}'`
HTTPDMODULES=`apxs -q LIBEXECDIR`
if [ "${HTTPDVERSION}" = "1" ]; then 
    cp Projects/ApxsModule/mod_biferno.so ${HTTPDMODULES}/mod_biferno_eapi.so
fi
if [ "${HTTPDVERSION}" = "2" ]; then 
	HTTPD_SUB_VERSION=`httpd -v | sed  -n -e '/Server version/s/  */./gp' | sed -n -e 's/\//./p' | awk -F. '{print $5}'`
    HTTPDCONF=etc/apache2/httpd.conf
    # make link to apache2 or apache22 module
	if [ "${HTTPD_SUB_VERSION}" = "2" ]; then 
   		cp Projects/ApxsModule/mod_biferno.so ${HTTPDMODULES}/mod_biferno_apache22.so
	else
   		cp Projects/ApxsModule/mod_biferno.so ${HTTPDMODULES}/mod_biferno_apache2.so
	fi
fi

# copy all files
if [ -d Projects/BifernoPanel/build/Release/BifernoPanel.prefPane ]
then
	cp -R Projects/BifernoPanel/build/Release/BifernoPanel.prefPane /Library/PreferencePanes
fi
cp -R Misc/StartupItems/Biferno /Library/StartupItems
cp -R Misc/BifernoHome/* /Users/BifernoHome
if [ -d Projects/externals/build/release ]
then
	cp Projects/externals/build/release/* /Users/BifernoHome/Extensions
	mv /Users/BifernoHome/Extensions/unix_exec_bfr.so /Users/BifernoHome/InactiveExtensions
	install -m 755 Projects/externals/build/Release/libbifernoapi.a /usr/lib
	if [ -d Projects/additional/build/release ]
	then
		cp Projects/additional/build/release/* /Users/BifernoHome/Extensions
	fi
	BAPI_VERS=`cat Misc/bapi_version`
	CUR_WD=`pwd`
	cd /usr/lib
	ln -s -f libbifernoapi.a libbifernoapi.${BAPI_VERS}.a
	cd ${CUR_WD}
fi
install -m 644 Misc/man8/* /usr/share/man/man8 
install -m 755 Projects/bifernod/build/Release/bifernod /usr/bin
install -m 755 Projects/bifernod/build/Release/bifernoctl /usr/bin

# adjust permissions and user/group
chmod 41775 /Library/StartupItems/Biferno
chmod 41775 /Library/PreferencePanes/BifernoPanel.prefPane
chown -R root /Library/StartupItems/Biferno
chown -R root /Library/PreferencePanes/BifernoPanel.prefPane
chgrp admin /Library/StartupItems/Biferno
chgrp admin /Library/PreferencePanes/BifernoPanel.prefPane
chgrp -R wheel /Library/StartupItems/Biferno
chgrp -R wheel /Library/PreferencePanes/BifernoPanel.prefPane
chown root /usr/bin/bifernod
chgrp wheel /usr/bin/bifernod
chown root /usr/bin/bifernoctl
chgrp wheel /usr/bin/bifernoctl
chown -R biferno:biferno /Users/BifernoHome

echo "post install"
./scripts/postinstall

bifernoctl -s start

echo "ok, biferno installed (now apache must be restarted)"
