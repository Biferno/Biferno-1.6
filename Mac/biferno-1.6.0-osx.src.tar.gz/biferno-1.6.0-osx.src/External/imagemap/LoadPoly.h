/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: LoadPoly.h,v 1.5 2005-05-26 10:17:35 valfer Exp $
	|______________________________________________________________________________
*/

#ifndef	__LOAD_POLY__
	#define __LOAD_POLY__

// Errors
#define	START_ERR	100
enum {
		ErrInvalidMapWidth = START_ERR,
		ErrInvalidMapHeight,
		ErrInvalidBorder,
		ErrBadFile
		/*,
		ErrWhileDrawing,
		ErrNewPixelWand,
		ErrNewMagickWand
		*/
};
#define	TOT_ERRORS	4

typedef struct
{
	long			refCount;	// num images pointing to this map
	BlockRef		offsets;
	long			totPoly;
	long			frame_width;
	long			frame_height;
	long			border;
	long			maxTotPoints;
	double			min_x;		// min and max coordinates
	double			min_y;
	double			max_x;
	double			max_y;
	// ... polygons follow
} PolyHeader;

#define	USER_FRAME_OFFSET		offsetof(PolyHeader, frame_width)
#define	BORDER_OFFSET			offsetof(PolyHeader, border)
#define	POLY_MINMAX_OFFSET		offsetof(PolyHeader, min_x)
#define	POLY_FIRSTPOLY_OFFSET	sizeof(PolyHeader)

#define	SIZE_OF_ENCLOSING		(sizeof(double) * 4)	// enclosing rect vertexs

#define	MAX_DOUBLE (double)1.79769313486231470e+308

XErr	LoadPoly(XFilePathPtr polyPath, BlockRef *resultP, long *resultlenP, long *lineErrorP);
XErr	Normalize(Ptr polyPtr, double width, double height, long border);

#endif
