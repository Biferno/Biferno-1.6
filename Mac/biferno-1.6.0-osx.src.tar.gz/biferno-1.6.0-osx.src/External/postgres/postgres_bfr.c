/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: postgres_bfr.c,v 1.20 2006-05-30 14:53:14 valfer Exp $
	|______________________________________________________________________________
*/
/** @file
* 	Postgres driver for Biferno
*
*	This file implements postgres support for the db class of Biferno.
*	The db class ask to the driver to execute the native calls to the DBMS (postgres)
*
*	Copyright (c) 2001, Tabasoft Sas
*
*	$RCSfile: postgres_bfr.c,v $
*	$Date: 2006-05-30 14:53:14 $ 
*	$Revision: 1.20 $
*
*	Valerio Ferrucci
*/
#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"
#include 	"BDBAPI.h"

#ifdef	POSTGRES_BUILT_IN
	#include 	"StaticClasses.h"
#endif

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

/*#if __MACOSX__
	#include <PostgreSQL/libpq-fe.h>
#else*/
	#include <libpq-fe.h>
//#endif

/*
*	Defines
*/
#define		MAX_FIELD_TITLE_LENGTH	63

/**	Query column */
typedef struct
{		
	char 				title[MAX_FIELD_TITLE_LENGTH+1];	/**< the name of the column as written in the select */
} PostgresColumnDescr;

/**	Cursor (result of a query) */
typedef struct
{		
	PGresult			*pg_res;			/**< the record set of the cursor */
	long				totFields;			/**< if the query is a select, the number of fields of the select */
	long				curRecs;			/**< total records in selection */
	long				curPos;				/**< position of the cursor at the next fetch */
	short				pad;				/**< unused */
	short				cursorMode;			/**< the cursor mode (only kStatic is supported) */
	BlockRef			columnDescrBlock;	/**< the block of memory containing #totFields PostgresColumnDescr*/
	PostgresColumnDescr	*columnDescrP;
} PostgresCursorRec;

/**	Connection */
typedef struct
{		
	PGconn 				*pg_conn;			/**< the connection to the db */
} PostgresConnectionRec;

/*
*	Static
*/
static long			gsPostgresClassID;
//static long			gsApiVersion;
static BDBAPI_Rec	bdbRec;

//===========================================================================================
/**
*	Set the error and get the native atring if it is a native error.
*/
static XErr	_SetPostgresError(PostgresConnectionRec *connectionPtr, char *optString, char *result)
{
CStr15		errorNumberStr;
char		*strP;
int			actLen, maxLen, strLen;
Boolean		addPeriods;

	/*
	*	the db class expects the error string to have the following format:
	*	":errorNumber:name of driver:native error description string"		
	*
	*	So let's begin with error semicolon and number:
	*/
	CEquStr(result, ":");
	CNumToString(ErrDBMSError, errorNumberStr);
	CAddStr(result, errorNumberStr);
	
	/*
	*	Now add the name of this driver
	*/
	CAddStr(result, ":postgres:");
	
	/**
	*	If an optString was passed, it is added here
	*/
	if (optString)
		CAddStr(result, optString);
	
	/**
	*	Then add the native description of the error (using PQerrorMessage)
	*/
	if (connectionPtr && connectionPtr->pg_conn)
	{	CAddStr(result, " - ");
		strP = PQerrorMessage(connectionPtr->pg_conn);
		strLen = CLen(strP);
		actLen = CLen(result);
		maxLen = (sizeof(CStr255) - 1) - 3 - actLen;	// also ...
		if (strLen > maxLen)
		{	strLen = maxLen;
			addPeriods = true;
		}
		else
			addPeriods = false;
		CopyBlock(result, strP, strLen);
		result[actLen + strLen] = 0;
		if (addPeriods)
			CAddStr(result, "...");
	}

	/**
	*	Set the error to generic error: ErrDBMSError
	*/
	return XError(kBAPI_ClassError, ErrDBMSError);
}

//===========================================================================================
/**
*	Fill the description of a column using Postgres native calls
*/
static XErr	_PostgresDescribeColumns(PostgresConnectionRec *connP, PostgresCursorRec *cursorP, char *error)
{
int					i, totFields;
XErr				err = noErr;
char				*fieldName;
PostgresColumnDescr	*colDescrP;
PGresult 			*pg_res = cursorP->pg_res;

	/**
	*	Get the total number of filed in current selection
	*	Note that for command query totFields = 0 (there are no columns returned)
	*/
	totFields = PQnfields(pg_res);
	if (totFields > 0)
	{	/**
		*	Allocate the buffer for column descriptions (names)
		*/
		if (cursorP->columnDescrBlock = NewBlockLocked(sizeof(PostgresColumnDescr) * totFields, &err, (Ptr*)&colDescrP))
		{	cursorP->columnDescrP = colDescrP;
			cursorP->totFields = totFields;
			/**
			*	Get the name of each field and fill each column description
			*/
			for (i = 0; (i < totFields) && NOT(err); i++, colDescrP++)
			{	if (fieldName = PQfname(pg_res, i))
				{	if (CLen(fieldName) < MAX_FIELD_TITLE_LENGTH)
						CEquStr(colDescrP->title, fieldName);
					else
						err = _SetPostgresError(connP, "Field Name is too long", error);
				}
				else
					err = _SetPostgresError(connP, "mysql_fetch_field", error);
			}
			if (err)
				DisposeBlock(&cursorP->columnDescrBlock);
		}
	}

return err;
}

//===========================================================================================
static XErr	_PostgresFreeCallBack(long api_data, long db_api_data, Ptr cursorP, long userData, char *error)
{
XErr				err = noErr;
PostgresCursorRec	*po_cursorP = (PostgresCursorRec*)cursorP;

	PQclear(po_cursorP->pg_res);
	po_cursorP->pg_res = 0L;
	/*
	*	Dispose the column descriptions
	*/
	if (po_cursorP->columnDescrBlock)
		DisposeBlock(&po_cursorP->columnDescrBlock);

return err;
}

#pragma mark-
//===========================================================================================
/**
*	Connect to the database.
*	Connect to the database and return the buffer containing the 
*	PostgresConnectionRec struct in pbPtr->param.connectRec.connBuffer
*/
static XErr	_Connect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
PostgresConnectionRec	*connP;
BlockRef				connBlock = 0;
ConnectRec				*connectRecP = &pbPtr->param.connectRec;

	/*
	*	Allocate the buffer for the connection struct.
	*/
	if (connBlock = NewBlockLocked(sizeof(PostgresConnectionRec), &err, (Ptr*)&connP))
	{	/*
		*	Clean memory
		*/
		ClearBlock(connP, sizeof(PostgresConnectionRec));
		
		/*
		*	Connect to postgres db using the string conn info passed by the user.
		*	It is in connectRecP->connString and is zero terminated
		*/
		connP->pg_conn = PQconnectdb(connectRecP->connString);
		
		/*
		*	check to see that the backend connection was successfully made
		*/
		if (PQstatus(connP->pg_conn) == CONNECTION_BAD)
		{	/*
			*	Set the error and fill the string pbPtr->error with an error message
			*/
			err = _SetPostgresError(connP, "PQconnectdb failed (CONNECTION_BAD)", pbPtr->error);
			
			/*
			*	Note that Postgres documentation says:
			*	"Note that even if the backend connection attempt fails (as indicated by PQstatus),
			*	the application should call PQfinish to free the memory used by the PGconn object."
			*/
			PQfinish(connP->pg_conn);
			
			/*
			*	Dispose of the allocated block to avoid leaking
			*/
			DisposeBlock(&connBlock);
		}
		else
		{	/*
			*	Unlocking the block is relevant only on MacOS (Classic).
			*	On other platforms UnlockBlock does nothing
			*/
			UnlockBlock(connBlock);
			
			/*
			*	Tell to db class the size of our connection block
			*/
			connectRecP->connBufferLength = sizeof(PostgresConnectionRec);
			
			/*
			*	Return the block
			*/
			connectRecP->connBuffer = connBlock;
			
			/*
			*	The pointer can be set to nil, because we returned a block.
			*	Pointer can be useful when returning buffer from a big block containing 
			*	all the connections (i.e. a pool)
			*/
			connectRecP->connPointer = nil;
		}
	}
	
return err;
}

//===========================================================================================
/**
*	Disonnect function.
*	Disconnect form the database
*/
static XErr	_Disconnect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
PostgresConnectionRec	*connP;
//int						disposed, maxCursors, i, allocatedCursors;
//long 					api_data = pbPtr->api_data;
DisconnectRec			*disconnectRecP = &pbPtr->param.disconnectRec;

	/*
	*	Get the connectionP from the DisconnectRec structure
	*/
	connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;
	
	/*
	*	Dispose of all the allocated cursors
	*/
	err = bdbRec.BDBAPI_DisposeAllCursorsSlots(pbPtr->api_data, pbPtr->db_api_data, _PostgresFreeCallBack, 0, pbPtr->error);
	
	/*
	*	Call PQfinish to free the memory used by the PGconn object
	*/
	PQfinish(connP->pg_conn);
	
	/*
	*	Dispose the buffer allocated at Connect time
	*/
	DisposeBlock(&disconnectRecP->connBuffer);

return err;
}

//===========================================================================================
/**
*	Exec function.
*	Send a query sql to the database
*/
static XErr	_Exec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
PostgresConnectionRec	*connP;
PostgresCursorRec		*cursorP, cursoOnStack;
ExecRec					*execRecP = &pbPtr->param.execRec;
PGresult				*result;
int						status;

	/*
	*	Allocate a new cursor
	*/
	if (execRecP->dontReturnCursor)
	{	cursorP = &cursoOnStack;
		ClearBlock(cursorP, sizeof(PostgresCursorRec));
	}
	else
		err = bdbRec.BDBAPI_NewCursorSlot(pbPtr->api_data, pbPtr->db_api_data, &execRecP->cursorID, (Ptr*)&cursorP);
	if (err)
		return err;

	/*
	*	Get the connectionP from the DisconnectRec structure
	*/
	connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;

	/*
	*	We support only static cursors (not dynamic)
	*/
	if (execRecP->cursorMode == kDynamic)
		return _SetPostgresError(connP, "_Exec: Dynamic cursor not supported", pbPtr->error);
		
	/*
	*	Execute the query
	*/
	result = PQexec(connP->pg_conn, execRecP->sqlStringP);
	if NOT(result)
	{	PQclear(result);
		err = _SetPostgresError(connP, "PQexec failed", pbPtr->error);
	}
	else
	{	/*
		*	Check the error to see if all was ok with the wuery
		*/
		status = PQresultStatus(result);
		switch(status)
		{	case PGRES_BAD_RESPONSE:
			case PGRES_NONFATAL_ERROR:
			case PGRES_FATAL_ERROR:
				PQclear(result);
				err = _SetPostgresError(connP, "PQexec failed", pbPtr->error);
				break;
		}
		if NOT(err)
		{	cursorP->pg_res = result;
			/*
			*	Fill the name of the fields
			*/
			if NOT(err = _PostgresDescribeColumns(connP, cursorP, pbPtr->error))
			{	/**
				*	Initialize cursor fields
				*/
				cursorP->curPos = 1;
				cursorP->cursorMode = kStatic;
				cursorP->curRecs = PQntuples(result);
			}
			else
			{	/*
				*	Clean to avoid result leaking
				*/	
				PQclear(result);
			}
		}
	}
	if (execRecP->dontReturnCursor && NOT(err))
		_PostgresFreeCallBack(pbPtr->api_data, pbPtr->db_api_data, (Ptr)cursorP, 0, pbPtr->error);
	else if (err && NOT(execRecP->dontReturnCursor))
		bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, execRecP->cursorID, nil, 0, pbPtr->error);	// free the slot

return err;
}

//===========================================================================================
/**
*	GetCurRecs function.
*	Return the number of records in the current selection (if any)
*/
static XErr	_GetCurRecs(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
//PostgresConnectionRec	*connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;
PostgresCursorRec		*cursorP;
GetCurRecsRec			*getCurRecsRecP = &pbPtr->param.getCurRecsRec;

	// ask the number of rows in the selection previously calculated with PQntuples (see _Exec)
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getCurRecsRecP->cursorID, (Ptr*)&cursorP))
		getCurRecsRecP->curRecs = cursorP->curRecs;

return err;
}

//===========================================================================================
/**
*	GetAffectedRecs function.
*	Return the number of records affected by the last SQL query
*/
static XErr	_GetAffectedRecs(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
//PostgresConnectionRec	*connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;
PostgresCursorRec		*cursorP;
GetAffectedRecsRec		*getAffectedRecsRecP = &pbPtr->param.getAffectedRecsRec;
char					*affectedRecsStr;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getAffectedRecsRecP->cursorID, (Ptr*)&cursorP))
	{	/*
		*	PQcmdTuples return a string and if the query was not a commad
		*	(but a simple select) the string is empty
		*/
		affectedRecsStr = PQcmdTuples(cursorP->pg_res);
		if (*affectedRecsStr)
			CStringToNum(affectedRecsStr, &getAffectedRecsRecP->affectedRecs);
		else
			getAffectedRecsRecP->affectedRecs = 0;
	}

return err;
}

//===========================================================================================
/**
*	Seek function.
*	Move the current position of the record set to a certain position
*/
static XErr	_Seek(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
//PostgresConnectionRec	*connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;
PostgresCursorRec		*cursorP;
SeekRec					*seekRecP = &pbPtr->param.seekRec;

	/*
	*	Set the cursor position to seekRecP->pos. cursor position is 1-based
	*/
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, seekRecP->cursorID, (Ptr*)&cursorP))
		cursorP->curPos = seekRecP->pos;

return err;
}

//===========================================================================================
/**
*	Tell function.
*	Retun the current position of the record set
*/
static XErr	_Tell(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
//PostgresConnectionRec	*connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;
PostgresCursorRec		*cursorP;
TellRec					*tellRecP = &pbPtr->param.tellRec;

	/*
	*	return the cursor position
	*/
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, tellRecP->cursorID, (Ptr*)&cursorP))
		tellRecP->pos = cursorP->curPos;

return err;
}

//===========================================================================================
/**
*	FreeResult function.
*	Free the memory allocated in the Exec funciont ("the cursor")
*/
static XErr	_FreeResult(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
//PostgresConnectionRec	*connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;
//PostgresCursorRec		*cursorP;
//int						cursID;
FreeResultRec			*freeResultRecP = &pbPtr->param.freeResultRec;

	err = bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, _PostgresFreeCallBack, 0, pbPtr->error);

return err;
}


//===========================================================================================
/**
*	FetchRec function.
*	Fetch the record at the current position in the record set
*/
static XErr	_FetchRec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
//PostgresConnectionRec	*connP = (PostgresConnectionRec*)pbPtr->connBufferPtr;
PostgresCursorRec		*cursorP;
PostgresColumnDescr		*colDescrP;
//int						cursID;
long					api_data = pbPtr->api_data;
FetchRec				*fetchRecP = &pbPtr->param.fetchRec;
PGresult				*pg_res;
char					*cellPtr;
ObjRef					arrayElement;
Boolean					undefNull, isNull;
int						i, totFields, curPos, length;

	undefNull = fetchRecP->undefNull;
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, fetchRecP->cursorID, (Ptr*)&cursorP))		
	{	/*
		*	Create an array (initially empty) and store the reference in "pbPtr->param.fetchRec.object"
		*/
		if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &fetchRecP->object))
		{	/*
			*	Get one record at position cursorP->cursorPos and fill the array
			*	with the values.
			*/
			curPos = cursorP->curPos - 1;	// Postgres tuples are 0-based
			if (curPos < cursorP->curRecs)
			{	pg_res = cursorP->pg_res;
				totFields = cursorP->totFields;
				colDescrP = &cursorP->columnDescrP[0];
				for (i = 0; i < totFields; i++, colDescrP++)
				{	cellPtr = PQgetvalue(pg_res, curPos, i);
					if (cellPtr)
					{	/*
						*	Clean (Undefine) the object
						*/
						BAPI_InvalObjRef(api_data, &arrayElement);
						isNull = PQgetisnull(pg_res, curPos, i);
						length = PQgetlength(pg_res, curPos, i);
						
						/*
						*	Get the values.
						*	If the value is null (PQgetisnull) and the user defined "undefNull"
						*	we have to add an undefined object, not a null string
						*/
						if NOT(isNull)
							err = BAPI_StringToObj(api_data, cellPtr, length, &arrayElement);
						else
						{	if (undefNull)
								err = BAPI_StringToObj(api_data, DB_NULL_VALUE, DB_NULL_VALUE_LEN, &arrayElement);
							else
								err = BAPI_StringToObj(api_data, "", 0, &arrayElement);
						}
						if NOT(err)
						{	/*
							*	Add the element to the array, giving the column name (colDescrP->title) as
							*	the associative index name
							*/
							err = BAPI_ArrayAddElement(api_data, &fetchRecP->object, colDescrP->title, &arrayElement);
							/*
							*	Some join queries can return columns with same names. Nevertheless Biferno
							*	arrays don't accept duplicated associative indexs. So let's add
							*	an index number to names for that (particular) queries
							*/
							if (err && (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName)))
							{	
							int			titleLen, index;
							CStr15		tStr;
							CStr255		aCStr;
							
								index = 2;
								titleLen = CLen(colDescrP->title);
								do {
									CNumToString(index++, tStr);
									if ((titleLen + 1 + CLen(tStr)) < 255)
									{	CEquStr(aCStr, colDescrP->title);
										CAddStr(aCStr, "_");
										CAddStr(aCStr, tStr);
										err = BAPI_ArrayAddElement(api_data, &fetchRecP->object, aCStr, &arrayElement);
									}
									else
									{	err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
										break;
									}
								} while (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName));
							}
						}
					}
				}
				/*
				*	Advance the position of the cursor for the next Fetch
				*/
				cursorP->curPos++;
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_RealEscape(BDBAPI_ParamBlockPtr pbPtr)
{
char			*strToEncodeP, *strEncodedP;
XErr			err = noErr;
BlockRef		bl;
long 			api_data = pbPtr->api_data;
size_t			strEncodedLength;
long			strToEncodeLength;
RealEscapeRec	*realEscapeRecP = &pbPtr->param.realEscapeRec;

	strToEncodeLength = realEscapeRecP->stringLen;
	strToEncodeP = realEscapeRecP->stringP;
	if (NOT(realEscapeRecP->byteEsc) && NOT(realEscapeRecP->unescape))
	{	
		/*
		*	Postgres doc says:
		*	"In general, to escape a character, it is converted into the
		*	three digit octal number equal to the decimal ASCII value, and preceded by 
		*	two backslashes."
		*
		*	So I guess allocate five time the length of the string (plus 1 for the zero)
		*/
		bl = NewBlockLocked((strToEncodeLength * 5) + 1, &err, &strEncodedP);
	}
	if NOT(err)
	{	if (realEscapeRecP->unescape)
			strEncodedP = (Ptr)PQunescapeBytea((const unsigned char*)strToEncodeP, &strEncodedLength);
		else if (realEscapeRecP->byteEsc)
		{	strEncodedP = (Ptr)PQescapeBytea((const unsigned char*)strToEncodeP, strToEncodeLength, &strEncodedLength); 
			strEncodedLength--;		// The result string length includes the terminating zero byte of the result
		}
		else
			strEncodedLength = PQescapeString(strEncodedP, strToEncodeP, strToEncodeLength); 
		err = BAPI_StringToObj(api_data, strEncodedP, strEncodedLength, &realEscapeRecP->resultObj);
		if (realEscapeRecP->byteEsc || realEscapeRecP->unescape)
		{
		#ifdef __WIN_XLIB__
			PQfreemem(strEncodedP);
		#else
			free(strEncodedP);
		#endif
		}
		else
			DisposeBlock(&bl);
	}	

return err;
}

#pragma mark-
//===========================================================================================
/**
*	Function called by the db class.
*	This function is called by the db class.
*	\param	message	tells what event have been sent to this plugin
*	\param	pbPtr	the param block containing the message for the class
*	
*/
#pragma export on
static XErr postgres_DBDispatch(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kConnect:
			err = _Connect(pbPtr);
			break;
		case kDisconnect:
			err = _Disconnect(pbPtr);
			break;
		case kExec:
			err = _Exec(pbPtr);
			break;
		case kCall:
		case kCallExt:
		case kPrepare:
		case kRowSetSize:
		case kGetPrepared:
		case kBind:
		//case kBindParam:
		case kBindAll:
		case kExecPrepared:
			/**
			*	Postgres doesn't support prepare, bind etc.. calls
			*	They are needed by odbc, oracle or others drivers.
			*/
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kFreeResult:
			err = _FreeResult(pbPtr);
			break;
		case kSeek:
			err = _Seek(pbPtr);
			break;
		case kTell:
			err = _Tell(pbPtr);
			break;
		case kWarning:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kGetCurRecs:
			err = _GetCurRecs(pbPtr);
			break;
		case kGetAffectedRecs:
			err = _GetAffectedRecs(pbPtr);
			break;
		case kFetchRec:
			err = _FetchRec(pbPtr);
			break;
		case kTransaction:
		case kCommit:
		case kRollBack:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kRealEscape:
		case kRealUnescape:
			err = _RealEscape(pbPtr);
			break;		
		default:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
	}

return err;
}
#pragma export off

//===========================================================================================
static XErr	InitCallBacks(long api_data, BDBAPI_Rec *theRecP)
{
XErr					err = noErr;
BDBAPI_Init_CallBack	BDBAPI_Init_EP;

	if NOT(err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, "db", false), "BDBAPI_Init", (long*)&BDBAPI_Init_EP))
		err = BDBAPI_Init_EP(&bdbRec);

return err;
}

//===========================================================================================
static XErr	postgres_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	/**	
	*	Postgres documentation:
	*	"libpq is thread-safe as of PostgreSQL 7.0, so long as no two threads attempt to 
	*	manipulate the same PGconn object at the same time. In particular, you cannot 
	*	issue concurrent queries from different
	*	threads through the same connection object. (If you need to run concurrent queries, 
	*	start up multiple connections.)"
	*
	*	So set the 4-th parameter of _Register (multiThreadLimited) to true.
	*	In this way the db class will permit only local and global variable to be intialized
	*	(Note that application, session and persistent could use the same variable from
	*	concurrent threads)
	*
	*	That said, there is no need to use critical sections in this code
	*/
	if NOT(err = InitCallBacks(api_data, &bdbRec))
		err = bdbRec.BDBAPI_Register("postgres", postgres_DBDispatch, sizeof(PostgresCursorRec), true);

out:	
return err;
}

//===========================================================================================
/**
*	Biferno Register Function.
*	Register the class returning some values (class name, description etc...) to biferno.
*/
static XErr	postgres_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
RegisterRec		*registerRecP = &pbPtr->param.registerRec;

	/**
	*	Check if the libpq was correctly linked to the project
	*/
	/*if NOT(PQconnectdb)
	{	CEquStr(pbPtr->error, "libpq symbols undefined");
		return ErrDBMSError;
	}*/
		
	/**
	*	Declare the plugin as kNewFunctionsPlugin
	*	(possible types are: kNewFunctionsPlugin, kNewClassPlugin).
	*	Declare it as kNewClassPlugin if you want to declare some methods
	*	(i.e. a = postgres.MyMethod()), not only offer support to db class
	*/
	registerRecP->pluginType = kNewFunctionsPlugin;
	
	/**
	*	Set the name of the extension (It can be different from extension file name)
	*/
	CEquStr(pbPtr->param.registerRec.pluginName, "postgres");
	
	/**
	Set the description of the extension
	*/
	CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft postgres native support");
	// BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
	//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
	VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
	if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
		CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
	
	/**
	*	Get our class id (we will need it later).
	*/
	gsPostgresClassID = pbPtr->param.registerRec.pluginID;
	
return err;
}

#pragma mark-
#pragma export on
//===========================================================================================
#ifdef	POSTGRES_BUILT_IN
	XErr	postgres_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#else
	XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#endif
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = postgres_Register(pbPtr);
			break;
		case kInit:
			err = postgres_Init(pbPtr);
			break;
		case kShutDown:
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#pragma export off
