/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: macutils_bfr.c,v 1.11 2004-09-07 13:15:55 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"BifernoAPI.h"
#include	"BfrVersion.h"
#include 	"XFilesMacPrivate.h"

#include 	<SpeechSynthesis.h>

#define	kFormat	1

static long				macUtilsClassID;
static unsigned long	gMacSecsOffset_1970;

// Functions
enum{
		kPlaySound = 1,
		kSpeakString
		//kLaunchDoc = 1,
		//kPlaySound
	};

#define TOT_FUNCTIONS	2

// Costants
enum{
		k_all = 1,
		k_hour,
		k_date
	};

enum{
	shortDate_k = 1,
	longDate_k,
	abbrevDate_k,
	all_k,
	hour_k,
	date_k
	};
	
#define TOT_COSTANTS	6
static BAPI_MemberRecord	gsTFormatCostants[TOT_COSTANTS] = 
					{	"shortDate", 	shortDate_k,	"int",
						"longDate", 	longDate_k,		"int",
						"abbrevDate", 	abbrevDate_k,	"int",
						"all",			all_k,			"int",
						"wanthour", 	hour_k,			"int",
						"wantdate", 	date_k,			"int"
					};

//#define	kAEFlags	kAECanSwitchLayer + kAECanInteract + kAENoReply /* +  kAEAlwaysInteract*/

static	short	gsRscRef = 0;

//===========================================================================================
static XErr	_PlaySound(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
long		resID;
short		oldres;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &resID, kImplicitTypeCast))
	{	if (gsRscRef)
		{	oldres = CurResFile();
			UseResFile(gsRscRef);
			if NOT(err = ResError())
			{	XPlaySound(resID);
				UseResFile(oldres);
			}
		}		
	}
	
return err;
}

//===========================================================================================
static XErr	_SpeakString(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr	err = noErr;
Str255	pascalMsg;
long	tLen;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, (Ptr)&pascalMsg[1], &tLen, 256, kImplicitTypeCast))
	{	pascalMsg[0] = tLen;
		if (SpeakString)
			SpeakString(pascalMsg);
	}
	
return err;
}

//===========================================================================================
/*static short _LaunchDocWithAE(FSSpec *docFSPtr)
{
AppleEvent			myAEvent, AEReply;
AEAddressDesc		targetAddr;
AEDescList			docList;
long				fndrSign = 'MACS';
AliasHandle			aliasH;
short				err;

	AEReply.descriptorType = typeNull;
	AEReply.dataHandle = 0L;

	if (err = AECreateDesc(typeApplSignature, (Ptr)&fndrSign, 4L, &targetAddr))
		goto AEExit;		
	if (err = AECreateAppleEvent(kAEFinderEvents, kAEOpenSelection, &targetAddr,
							kAutoGenerateReturnID, kAnyTransactionID, &myAEvent))
		goto AEExit2;
		
	if (err = NewAlias(0L, docFSPtr, &aliasH) || aliasH == 0L)
		goto AEExit1;
	HLock((Handle)aliasH);
	if (err = AEPutParamPtr(&myAEvent, keyDirectObject, typeAlias, (Ptr)*aliasH, (*aliasH)->aliasSize))
		goto AEExit0;
	DisposeHandle((Handle)aliasH);

	if (err = NewAliasMinimal(docFSPtr, &aliasH) || aliasH == 0L)
		goto AEExit1;
	if (err = AECreateList(0L, 0L, false, &docList))
		goto AEExit0;
	HLock((Handle)aliasH);
	if (err = AEPutPtr(&docList, 0, typeAlias, (Ptr)*aliasH, (*aliasH)->aliasSize))
		goto AEExit9;
	HUnlock((Handle)aliasH);
	if (err = AEPutParamDesc(&myAEvent, keySelection, &docList))
		goto AEExit9;

	err = AESend(&myAEvent, &AEReply, kAEFlags, kAEHighPriority, kAEDefaultTimeout, 0L, 0L);
	if (kAEFlags & kAEWaitReply)
		AEDisposeDesc(&AEReply);

AEExit9: AEDisposeDesc(&docList);
AEExit0: DisposeHandle((Handle)aliasH);
AEExit1: AEDisposeDesc(&myAEvent);
AEExit2: AEDisposeDesc(&targetAddr);

AEExit: return(err);
}
*/
#pragma mark-
//===========================================================================================
static XErr	MacUtils_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BAPI_MemberRecord	fmtRec = {"Format", 1, "string Format(int which, int format, boolean leadingZeros, boolean wantSecs)"};
BAPI_MemberRecord	functionRec[TOT_FUNCTIONS] = {
									//"LaunchDoc", kLaunchDoc, "void LaunchDoc(string docPath)",
									"PlaySound", 	kPlaySound, "void PlaySound(int resID)",
									"SpeakString", 	kSpeakString, "void SpeakString(string msg)"
									};
DateTimeRec			dtRec;
		
	if (err = BAPI_NewMethods(pbPtr->api_data, macUtilsClassID, &fmtRec, 1, "time"))
		return err;
	if (err = BAPI_NewFunctions(pbPtr->api_data, macUtilsClassID, functionRec, TOT_FUNCTIONS))
		return err;
	if (err = BAPI_NewConstants(pbPtr->api_data, macUtilsClassID, gsTFormatCostants, TOT_COSTANTS, "time"))
		return err;

	dtRec.hour = 0;
	dtRec.minute = 0;
	dtRec.second = 0;
	dtRec.year = 1970;
	dtRec.month = 1;
	dtRec.day = 1;
	dtRec.dayOfWeek = 1;
	DateToSeconds(&dtRec, &gMacSecsOffset_1970);

return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	MacUtils_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;

	switch(getPropertyRec->propertyID)
	{
		case shortDate_k:
			err = BAPI_IntToObj(pbPtr->api_data, shortDate, &getPropertyRec->resultObjRef);
			break;
		case longDate_k:
			err = BAPI_IntToObj(pbPtr->api_data, longDate, &getPropertyRec->resultObjRef);
			break;
		case abbrevDate_k:
			err = BAPI_IntToObj(pbPtr->api_data, abbrevDate, &getPropertyRec->resultObjRef);
			break;
		case all_k:
			err = BAPI_IntToObj(pbPtr->api_data, k_all, &getPropertyRec->resultObjRef);
			break;
		case hour_k:
			err = BAPI_IntToObj(pbPtr->api_data, k_hour, &getPropertyRec->resultObjRef);
			break;
		case date_k:
			err = BAPI_IntToObj(pbPtr->api_data, k_date, &getPropertyRec->resultObjRef);
			break;
	}

return err;
}

//===========================================================================================
static XErr	MacUtils_ExecuteFunction(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
//CStr255				filePath;
//FSSpec				fileSpec;

	switch(exeMethodRecP->methodID)
	{
		/*case kLaunchDoc:
			if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, filePath, &filePathLen, 255, kImplicitTypeCast))
			{	if (filePathLen)
				{	if NOT(err = BAPI_RealPath(api_data, filePath, true))
					{	if NOT(err = _GetMacSpec(filePath, &fileSpec, true, true))
							err = _LaunchDocWithAE(&fileSpec);
					}
				}
			}
			break;*/
		
		case kPlaySound:
			err = _PlaySound(api_data, exeMethodRecP);
			break;
		
		case kSpeakString:
			err = _SpeakString(api_data, exeMethodRecP);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
return err;
}

//===========================================================================================
static XErr	MacUtils_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
unsigned long		secs;
long 				api_data = pbPtr->api_data;
long				which, format;
Boolean				leadingZeros, wantSecs;
long				dForm, totParams = exeMethodRecP->totParams;
ObjRef				tObjRef;
Str63				timeStr;
Str255				dateStr;
Intl0Hndl			intH;
Intl0Ptr			i0P;

	if (exeMethodRecP->methodID == 1)
	{	// defaults
		which = k_all;
		format = longDate;
		leadingZeros = true;
		wantSecs = true;
		if ((totParams < 0) || (totParams > 4))
			return XError(kBAPI_Error, Err_PrototypeMismatch);
		if (totParams >= 1)
		{	err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &which, kImplicitTypeCast);
			if NOT(which)
				which = k_all;
		}
		if (totParams >= 2)
		{	err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &format, kImplicitTypeCast);
			//if NOT(format)
			//	format = longDate;
		}
		if (totParams >= 3)
			err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &leadingZeros, kImplicitTypeCast);
		if (totParams >= 4)
			err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[3].objRef, &wantSecs, kImplicitTypeCast);
			
		if NOT(err = BAPI_ExecuteMethod(api_data, &exeMethodRecP->objRef, nil, 0, "ToSecs", &tObjRef, nil))
		{	if NOT(err = BAPI_ObjToUnsigned(pbPtr->api_data, &tObjRef, &secs, kImplicitTypeCast))	
			{	secs += gMacSecsOffset_1970;
				dateStr[0] = 0;
				if ((which == k_date) || (which == k_all))
				{	if (format == shortDate)
					{	dForm = shortDate;
						intH = (Intl0Hndl)GetIntlResource(0);
					}
					else if (format == longDate)
					{	dForm = longDate;
						intH = (Intl0Hndl)GetIntlResource(1);
					}
					else if (format == abbrevDate)
					{	dForm = abbrevDate;
						intH = (Intl0Hndl)GetIntlResource(1);
					}
					DateString(secs, dForm, dateStr, (Handle)intH);
				}
				timeStr[0] = 0;
				if ((which == k_hour) || (which == k_all))
				{	if (intH = (Intl0Hndl)GetIntlResource(0))
					{	i0P = *intH;
						i0P->timeCycle=0;											// 24-hr format
						if (leadingZeros)
							i0P->timeFmt |= (secLeadingZ | minLeadingZ | hrLeadingZ);	// leading 0
						else
						{	i0P->timeFmt &= (0xF ^ secLeadingZ);
							i0P->timeFmt &= (0xF ^ minLeadingZ);
							i0P->timeFmt &= (0xF ^ hrLeadingZ);
						}
						TimeString(secs, wantSecs, timeStr, (Handle)intH);
					}
				}
				if (*timeStr && *dateStr)
					PAddChar(dateStr, '\t');
				PAddStr(dateStr, timeStr);
				err = BAPI_StringToObj(api_data, (Ptr)&dateStr[1], dateStr[0], &exeMethodRecP->resultObjRef);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchMethod);

return err;
}

#pragma mark-
#pragma export on
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "MacUtils");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft MacOS utilities");
			//BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
			//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			macUtilsClassID = pbPtr->param.registerRec.pluginID;
			gsRscRef = pbPtr->param.registerRec.macOSResRefNum;
			break;
		case kInit:
			err = MacUtils_Init(pbPtr);
			break;
		case kShutDown:
			gsRscRef = 0;
			break;
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kDestructor:
		case kExecuteOperation:
			break;
		case kExecuteMethod:
			err = MacUtils_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			err = MacUtils_ExecuteFunction(pbPtr);
			break;
		case kGetProperty:
			err = MacUtils_GetProperty(pbPtr);
			break;
		case kSetProperty:
		case kPrimitive:
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#pragma export off

