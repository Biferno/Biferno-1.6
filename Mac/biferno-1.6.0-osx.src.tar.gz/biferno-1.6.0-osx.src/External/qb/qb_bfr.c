/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: qb_bfr.c,v 1.8 2005-11-04 14:15:18 valfer Exp $
	|______________________________________________________________________________
*/

#include 	"BifernoAPI.h"
#include	"XFilesMacPrivate.h"
#include 	"BfrSearch.h"
#include 	"QBAPI.h"
#include 	<ctype.h>

typedef struct QuickBaseRec
{		
	long	connID;
	Str255	path;
} QuickBaseRec;

XErr	Initialize(CFragInitBlockPtr ibp);
void	Terminate(void);

// Methods
enum{
		kGetQBServerRoot = 1,
		kGetDBOpenPaths,
		kSort,
		kGetFieldName,
		kGetDBPath,
		kGetCurRecs,
		kGetTotFields,
		kGetRecNum,
		kGetRecID,
		kNewRecord,
		kDeleteRecord,
		kSave,
		kOptimize,
		kGetFieldNote,
		kSetFieldNote,
		kGetCell,
		kSetCell,
		kSelectAll,
		kSelectDistinct,
		kSelect,
		kSelectMand,
		kSelectRel,
		kIsSkipWord,
		kExport,
		kImport,
		kGetFieldInfo,
		kGetFilesInfo
	};
#define TOT_METHODES	27

// Costants
enum{
		kAsc_cs = 10,
		kDesc_cs,
		kFileSize_asc,
		kFileSize_desc,
		kCreatDate_asc,
		kCreatDate_desc,
		kModifDate_asc,
		kModifDate_desc,
		kFileType_asc,
		kFileType_desc,
		kFileCreat_asc,
		kFileCreat_desc,
		kRelevancy_asc,
		kRelevancy_desc,

		kAllNot,
		kAndNot,
		kOrNot
	};
	

enum{
		kContainStrInText = kContainWordExact + 1,
		kContainWordBeginInText,
						
		kMajorInFileSize,
		kMajorEquInFileSize,
		kMinorInFileSize,
		kMinorEquInFileSize,

		kMajorInCreatDate,
		kMajorEquInCreatDate,
		kMinorInCreatDate,
		kMinorEquInCreatDate,

		kMajorInModifDate,
		kMajorEquInModifDate,
		kMinorInModifDate,
		kMinorEquInModifDate,

		kEqualInFileType,
		/*kBeginInFileType,
		kEndInFileType,
		kContainStrInFileType,
		kContainWordBeginInFileType,
		kContainWordEndInFileType,
		kContainWordExactInFileType,*/

		kEqualInFileCreator,
		/*kBeginInFileCreator,
		kEndInFileCreator,
		kContainStrInFileCreator,
		kContainWordBeginInFileCreator,
		kContainWordEndInFileCreator,
		kContainWordExactInFileCreator,*/

		kIndex,
		kFType,
		kMin,
		kMax,
		kTotal,
		kAverage,
		kMissing,

		kTotFiles,
		kTotTypes,
		kIndType,
		kTotBytes,
		kTotDupFiles
	};
#define TOT_COSTANTS	80

// Errors
static CStr255	gQBAPIErrorsStr[] = 
		{	
		//tasks	
			"QBAPI_Err_ServerExpired: The server is expired, contact Tabasoft for a full version",
			"QBAPI_Err_ServerBusy: Too many simultaneous connection to QBAServer",
			"QBAPI_Err_BadTaskRef: A non valid connection ID was passed to this QBAPI function",
		//cell identification
			"QBAPI_Err_BadRecNum: This recNum is a not valid number",
			"QBAPI_Err_BadRecID: This recID doesn't exist in this DB",
			"QBAPI_Err_BadFieldDef: Bad field number or field name",
			"QBAPI_Err_RecIDOutOfRange: This greater recID of the DB is smaller than the one passed",
		//Connect
			"QBAPI_Err_DBNotAvailable: This DB is not available",
			"QBAPI_Err_ConnectFailed: QBServer can't swap to this DB (internal error)",
		//Select
			"QBAPI_Err_BadOperat: Invalid operat for search",
			"QBAPI_Err_BadGroup: Invalid group for search",
			"QBAPI_Err_TooManyLinesSelect: Search lines exceeds maximum (42)",
			"QBAPI_Err_DictionaryNotFound: Content search didn't find the full text dictionary",
		//Modifying db
			"QBAPI_Err_DBOnlyRead: Attempt to modify a DB opened with only read permission",
			"QBAPI_Err_DBLocked: Attempt to modify a DB on a locked volume",
			"QBAPI_Err_DBTooManyRecords: Records exceeds maximum (16.777.215)",
			"QBAPI_Err_BadIndexes: Bad field indexes (internal error)",
			"QBAPI_Err_BadStringFormat: String not valid for this field",
			"QBAPI_Err_BadNumFormat: Number not valid for this field",
			"QBAPI_Err_BadDateFormat: Date not valid for this field",
			"QBAPI_Err_BadInput: Buffer not valid for this field",
			"QBAPI_Err_BadFieldType: Unknown field type",
			"QBAPI_Err_BadFileTypeForThisField: This field can't link this type of files",
			"QBAPI_Err_StringTooLong: String too long for this field",
			"QBAPI_Err_FieldNotUnique: This field must be unique",
			"QBAPI_Err_FieldIsMandatory: This field must be mandatory",
			"QBAPI_Err_FieldNotPresent: This field must be present",
			"QBAPI_Err_RecordOutOfSelection: This recNum is out of the current selection",
			"QBAPI_Err_DBisEmpty: This DB is empty",
		//Accessing XDoc fields
			"QBAPI_Err_XDocVolumeNotAvailable: The XDoc volume was not found",
			"QBAPI_Err_XDocDirectoryNotFound: The XDoc directory was not found",
			"QBAPI_Err_FieldTypeIsNotXDoc: Attempt to get a file from a non-xdoc field",
		//Generic
			"QBAPI_Err_QBServerNotAvailable: The QBServer is not up",
			"QBAPI_Err_CantFindQBEngine: The shared library \"QBEngine\" can't be found",
			"QBAPI_Err_TaskIDBadNumber: Bad task (internal error)",
			"QBAPI_Err_UserDisconnected: User has been connected",
			"QBAPI_Err_TaskNotUsed: Task not in use",
			"QBAPI_Err_ImageLibNotAvailable: The shared library \"ImageLib\" can't be found",
			"QBAPI_Err_QBAPIVersionTooOld: QBAPI_FrameworkPPC.lib is too old for this QBEngine",
			"QBAPI_Err_QBEngineVersionTooOld: QBEngine is too old for this QBAPI_FrameworkPPC.lib",
			"QBAPI_Err_DictStopWordFileNotFound: Couldn't find the Stop Word File",
			"QBAPI_Err_TaskIsNotConnected: QBEngine doesn't know this QBAPI task (low level)",
			"QBAPI_Err_MaxRequestReached",
		//Added Here
			"QBAPI_Err_BadFieldList: Import/Export bad field list"
			};

// Errors
static CStr63	gQBAPIShortErrorsStr[] = 
		{	
		//tasks	
			"QBAPI_Err_ServerExpired",
			"QBAPI_Err_ServerBusy",
			"QBAPI_Err_BadTaskRef",
		//cell identification
			"QBAPI_Err_BadRecNum",
			"QBAPI_Err_BadRecID",
			"QBAPI_Err_BadFieldDef",
			"QBAPI_Err_RecIDOutOfRange",
		//Connect
			"QBAPI_Err_DBNotAvailable",
			"QBAPI_Err_ConnectFailed",
		//Select
			"QBAPI_Err_BadOperat",
			"QBAPI_Err_BadGroup",
			"QBAPI_Err_TooManyLinesSelect",
			"QBAPI_Err_DictionaryNotFound",
		//Modifying db
			"QBAPI_Err_DBOnlyRead",
			"QBAPI_Err_DBLocked",
			"QBAPI_Err_DBTooManyRecords",
			"QBAPI_Err_BadIndexes",
			"QBAPI_Err_BadStringFormat",
			"QBAPI_Err_BadNumFormat",
			"QBAPI_Err_BadDateFormat",
			"QBAPI_Err_BadInput",
			"QBAPI_Err_BadFieldType",
			"QBAPI_Err_BadFileTypeForThisField",
			"QBAPI_Err_StringTooLong",
			"QBAPI_Err_FieldNotUnique",
			"QBAPI_Err_FieldIsMandatory",
			"QBAPI_Err_FieldNotPresent",
			"QBAPI_Err_RecordOutOfSelection",
			"QBAPI_Err_DBisEmpty",
		//Accessing XDoc fields
			"QBAPI_Err_XDocVolumeNotAvailable",
			"QBAPI_Err_XDocDirectoryNotFound",
			"QBAPI_Err_FieldTypeIsNotXDoc",
		//Generic
			"QBAPI_Err_QBServerNotAvailable",
			"QBAPI_Err_CantFindQBEngine",
			"QBAPI_Err_TaskIDBadNumber",
			"QBAPI_Err_UserDisconnected",
			"QBAPI_Err_TaskNotUsed",
			"QBAPI_Err_ImageLibNotAvailable",
			"QBAPI_Err_QBAPIVersionTooOld",
			"QBAPI_Err_QBEngineVersionTooOld",
			"QBAPI_Err_DictStopWordFileNotFound",
			"QBAPI_Err_TaskIsNotConnected",
			"QBAPI_Err_MaxRequestReached",
		//Added Here
			"QBAPI_Err_BadFieldList"
			};

// defines
#define	gsPlugName		"qb"
#define	MAXDB			36
#define	VERSION			"1.0"

enum{
		QBAPI_Err_BadFieldList = QBAPI_Err_MaxRequestReached+1
	};
#define	LAST_ERROR		QBAPI_Err_BadFieldList

static short	quickbaseClassID, gsSearchClassID, gsArrayClassID;
static long		gsApiVersion;
static long		gsTotDBs;
static Str255	gsDBPaths[MAXDB];
static Boolean	gsInited;
static CStr255	gsPath;



//===========================================================================================
static long	_GetSearchOperat(long searchOperat, long *modeP)
{
long	operat = 0;

	switch(searchOperat)
	{	
		case kALL:
			operat = kAll;
			*modeP = kNormalMode;
			break;
		case kALLNOT:
			operat = kAll;
			*modeP = kNotMode;
			break;
		case kAND:
			operat = kAnd;
			*modeP = kNormalMode;
			break;
		case kOR:
			operat = kOr;
			*modeP = kNormalMode;
			break;
		case kANDNOT:
			operat = kAnd;
			*modeP = kNotMode;
			break;
		case kORNOT:
			operat = kOr;
			*modeP = kNotMode;
			break;
	}
	
return operat;
}

//===========================================================================================
static long	_GetSearchGroup(long searchGroup)
{
	switch(searchGroup)
	{	
		case kNO_PAR:
			return kNoPar;
		case kOPEN_PAR:
			return kOpenPar;
		case kCLOSE_PAR:
			return kClosePar;
	}

return 0;
}

//===========================================================================================
static void	_ReleaseBlock(BlockRef *refP)
{
	if (*refP)
		DisposeBlock((BlockRef*)refP);
}

//===========================================================================================
static XErr	_GetBlock(long api_data, ObjRefP objRef, SearchHeaderP *stringP, long *stringLen, BlockRef *refP)
{		
XErr		err = noErr;
long		dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock;
long 		tLen;

	*refP = 0;
	dataLen = 0;
	if NOT(err = BAPI_ReadObj(api_data, objRef, nil, &dataLen, 0, nil))
	{	++dataLen;	// 0-final
		if (dataBlock = NewBlockLocked(dataLen, &err, &dataP))
		{	//LockBlock(dataBlock);
			//dataP = GetPtr(dataBlock);
			*stringP = (SearchHeaderP)dataP;
			*refP = dataBlock;
			tLen = dataLen - 1;
			if NOT(err = BAPI_ReadObj(api_data, objRef, dataP, &tLen, 0, nil))
			{	*stringLen = tLen;
				dataP[tLen] = 0;
			}
		}	
	}
	
if (err && *refP)
	DisposeBlock(&dataBlock);
return err;
}

//===========================================================================================
static XErr _GetOperat(long *findTypeP, long *findDocModeP, Boolean *addWildeP)
{
XErr	err = noErr;
	
	if (addWildeP)
		*addWildeP = false;
	switch(*findTypeP)
	{	case kEqual:
		case kBegin:
		case kEnd:
		case kMajor:
		case kMajorEqu:
		case kMinor:
		case kMinorEqu:
		case kMenuSep:
		case kContainStr:
		case kContainWordBegin:
		case kContainWordEnd:
		case kContainWordExact:
			*findDocModeP = 0;
			break;

		/*case kEqualInText:
			*findTypeP = kEqual;
			*findDocModeP = kInTextMode;
			break;
		case kBeginInText:
			*findTypeP = kBegin;
			*findDocModeP = kInTextMode;
			break;
		case kEndInText:
			*findTypeP = kEnd;
			*findDocModeP = kInTextMode;
			break;*/
		case kContainStrInText:
			*findTypeP = kContainStr;
			*findDocModeP = kInTextMode;
			break;
		case kContainWordBeginInText:
			*findTypeP = kContainStr;		// ex kContainWordBegin
			*findDocModeP = kInTextMode;
			if (addWildeP)
				*addWildeP = true;
			break;
		/*case kContainWordEndInText:
			*findTypeP = kContainWordEnd;
			*findDocModeP = kInTextMode;
			break;
		case kContainWordExactInText:
			*findTypeP = kContainWordExact;
			*findDocModeP = kInTextMode;
			break;*/

		case kMajorInFileSize:
			*findTypeP = kMajor;
			*findDocModeP = kFileSizeMode;
			break;
		case kMajorEquInFileSize:
			*findTypeP = kMajorEqu;
			*findDocModeP = kFileSizeMode;
			break;
		case kMinorInFileSize:
			*findTypeP = kMinor;
			*findDocModeP = kFileSizeMode;
			break;
		case kMinorEquInFileSize:
			*findTypeP = kMinorEqu;
			*findDocModeP = kFileSizeMode;
			break;

		case kMajorInCreatDate:
			*findTypeP = kMajor;
			*findDocModeP = kCreatDateMode;
			break;
		case kMajorEquInCreatDate:
			*findTypeP = kMajorEqu;
			*findDocModeP = kCreatDateMode;
			break;
		case kMinorInCreatDate:
			*findTypeP = kMinor;
			*findDocModeP = kCreatDateMode;
			break;
		case kMinorEquInCreatDate:
			*findTypeP = kMinorEqu;
			*findDocModeP = kCreatDateMode;
			break;

		case kMajorInModifDate:
			*findTypeP = kMajor;
			*findDocModeP = kModifDateMode;
			break;
		case kMajorEquInModifDate:
			*findTypeP = kMajorEqu;
			*findDocModeP = kModifDateMode;
			break;
		case kMinorInModifDate:
			*findTypeP = kMinor;
			*findDocModeP = kModifDateMode;
			break;
		case kMinorEquInModifDate:
			*findTypeP = kMinorEqu;
			*findDocModeP = kModifDateMode;
			break;

		case kEqualInFileType:
			*findTypeP = kEqual;
			*findDocModeP = kFileTypeMode;
			break;
		/*case kBeginInFileType:
			*findTypeP = kBegin;
			*findDocModeP = kFileTypeMode;
			break;
		case kEndInFileType:
			*findTypeP = kEnd;
			*findDocModeP = kFileTypeMode;
			break;
		case kContainStrInFileType:
			*findTypeP = kContainStr;
			*findDocModeP = kFileTypeMode;
			break;
		case kContainWordBeginInFileType:
			*findTypeP = kContainWordBegin;
			*findDocModeP = kFileTypeMode;
			break;
		case kContainWordEndInFileType:
			*findTypeP = kContainWordEnd;
			*findDocModeP = kFileTypeMode;
			break;
		case kContainWordExactInFileType:
			*findTypeP = kContainWordExact;
			*findDocModeP = kFileTypeMode;
			break;*/

		case kEqualInFileCreator:
			*findTypeP = kEqual;
			*findDocModeP = kFileCreatMode;
			break;
		/*case kBeginInFileCreator:
			*findTypeP = kBegin;
			*findDocModeP = kFileCreatMode;
			break;
		case kEndInFileCreator:
			*findTypeP = kEnd;
			*findDocModeP = kFileCreatMode;
			break;
		case kContainStrInFileCreator:
			*findTypeP = kContainStr;
			*findDocModeP = kFileCreatMode;
			break;
		case kContainWordBeginInFileCreator:
			*findTypeP = kContainWordBegin;
			*findDocModeP = kFileCreatMode;
			break;
		case kContainWordEndInFileCreator:
			*findTypeP = kContainWordEnd;
			*findDocModeP = kFileCreatMode;
			break;
		case kContainWordExactInFileCreator:
			*findTypeP = kContainWordExact;
			*findDocModeP = kFileCreatMode;
			break;*/
		default:
			err = XError(kBAPI_ClassError, QBAPI_Err_BadOperat);
			break;
	}

return err;
}

//===========================================================================================
static Boolean _ISQBServerRunning(ProcessSerialNumber *processSerNumP, unsigned long *serverLaunchDateP)
{
XErr					iErr;
ProcessInfoRec			pInfoRec;
Str31					procName;
FSSpec					processSpec;

	processSerNumP->highLongOfPSN = 0;
	processSerNumP->lowLongOfPSN = kNoProcess;
	pInfoRec.processName = (StringPtr)&procName;
	pInfoRec.processAppSpec = &processSpec;
	pInfoRec.processInfoLength = sizeof(ProcessInfoRec);
	while NOT (iErr = GetNextProcess(processSerNumP))
		{
		if NOT(iErr = GetProcessInformation(processSerNumP, &pInfoRec))
			{
			if ( (pInfoRec.processType == 'APPL') && (pInfoRec.processSignature == 'QBWS') )
				break;
			}
		}

	if (iErr)
	{	processSerNumP->highLongOfPSN = 0;
		processSerNumP->lowLongOfPSN = kNoProcess;
		if (serverLaunchDateP)
			*serverLaunchDateP = 0;
		return false;
	}
	else
	{	if (serverLaunchDateP)
			*serverLaunchDateP = pInfoRec.processLaunchDate;
		return true;
	}
}

//===========================================================================================
static XErr	_GetPathOfFile(Byte *fieldStr, char *filePath)
{
FSSpec		spec;
XErr		err = noErr;
CStr255		tempStr;

	if (fieldStr[1])
	{	if NOT(err = QBAPI_GetFSSpecFromString(fieldStr, &spec, nil, nil))
		{	if (err = _GetCFullPath(&spec, tempStr))
			{	*filePath = 0;
				err = noErr;
			}
			else
			{	CEquStr(filePath, "file:/");
				CSubstitute(tempStr, ':', '/');
				CAddStr(filePath, tempStr);
			}
		}
		else
		{	err = noErr;	
			*filePath = 0;	//err = XError(kBAPI_ClassError, err);
		}
	}
	else
		*filePath = 0;

return err;
}

//===========================================================================================
static XErr _QuickBaseInit(long api_data)
{
XErr					err = noErr;
#pragma unused(api_data)

	if (err = QBAPI_Init(128, nil, nil, nil, nil, 0))
		err = XError(kBAPI_ClassError, err);
		
return err;
}

//===========================================================================================
static XErr	_TryInit(long api_data)
{
XErr				err = noErr;
ProcessSerialNumber processSerNum;

	if NOT(gsInited)
	{ 	if (_ISQBServerRunning(&processSerNum, nil))
	 	{	if NOT(err = _QuickBaseInit(api_data))
	 			gsInited = true;
	 	}
	 	else
	 		err = XError(kBAPI_ClassError, QBAPI_Err_QBServerNotAvailable);
	}

return err;
}

/*typedef struct {
				Byte		*byteList;
				long		arrayDim;
				long		index;
				long		connID;
				Boolean		zeroBased;
				Byte		pad1;
				short		pad2;
			} ArrayToByteListRec;

//===========================================================================================
static XErr	_ArrayToByteListCallBack(long api_data, char *elemName, ObjRefP element, long param)
{
#pragma unused(elemName)
ArrayToByteListRec	*arrP = (ArrayToByteListRec*)param;
XErr				err = noErr;
CStr63				fieldName;
Str63				fieldName_p;
long				fldNum;

	if (arrP->index < arrP->arrayDim)
	{	if NOT(err = BAPI_ObjToString(api_data, element, fieldName, nil, 63, kImplicitTypeCast))
		{	CToPascal(fieldName, fieldName_p);
			if NOT(err = QBAPI_GetFieldNumber(arrP->connID, fieldName_p, &fldNum))
			{	if (arrP->zeroBased)
					arrP->byteList[arrP->index] = fldNum - 1;
				else
					arrP->byteList[arrP->index] = fldNum;
			}
			else
				err = XError(kBAPI_ClassError, err);
		}
	}
	else
		arrP->byteList[arrP->index] = 0;
	
	(arrP->index)++;

return err;
}*/

//===========================================================================================
static XErr	_ArrayToByteList(long api_data, long connID, long totFields, ObjRef *arrayObjRef, Byte *fldOrderList, Boolean zeroBased)
{
long			arrayDim;
long			fldNum, listLong;
XErr			err = noErr;
int				i, iMax;
CStr63			fieldName;
//ArrayIndexRec 	mCoords;
ObjRef			element;
Str63			fieldName_p;

	if (totFields > 256)
		return XError(kBAPI_ClassError, QBAPI_Err_BadFieldList);
	if (BAPI_GetObjClassID(api_data, arrayObjRef) == gsArrayClassID)
	{	if NOT(err = BAPI_GetArrayInfo(api_data, arrayObjRef, &arrayDim, nil, nil))
		{	//*mCoords.ind_name = 0;
			for (i = 0; i < totFields; i++)
			{	if (i < arrayDim)
				{	//mCoords.ind = i+1;
					element = *arrayObjRef;
					if NOT(err = BAPI_ElementOfArray(api_data, &element, i+1, &element))
					{	if NOT(err = BAPI_ObjToString(api_data, &element, fieldName, nil, 63, kImplicitTypeCast))
						{	if (*fieldName)
							{	CToPascal(fieldName, fieldName_p);
								if NOT(err = QBAPI_GetFieldNumber(connID, fieldName_p, &fldNum))
								{	if (zeroBased)
										fldOrderList[i] = fldNum-1; 	// 0-based
									else
										fldOrderList[i] = fldNum; 	// 1-based
								}
								else
									err = XError(kBAPI_ClassError, err);
							}
							else
							{	if (zeroBased)
									err = XError(kBAPI_ClassError, err);
								else
									fldOrderList[i] = 0; 	// 1-based (import, don't import this column)
							}
						}
					}
				}
				else
					fldOrderList[i] = 0; 			// solo per l'import (1-based)
			}
		}
	}
	else
	{	if NOT(err = BAPI_ObjToInt(api_data, arrayObjRef, &listLong, kImplicitTypeCast))
		{	if NOT(listLong)
			{	if (zeroBased)
				{	i = 0;
					iMax = totFields;
				}
				else
				{	i = 1;
					iMax = totFields+1;
				}
				for (; i < iMax; i++, fldOrderList++)
					*fldOrderList = i;
			}
			else
				err = XError(kBAPI_ClassError, QBAPI_Err_BadFieldList);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetCellString(long api_data, QuickBaseRec *qbRecP, StringPtr fieldName, long recNum, ObjRef *resultObjRefP)
{	
XErr		err = noErr;
long		fldType;
Boolean		empty;
Byte		fieldStr[kQBAPIMaxCellLength], *textInitP = nil;
long		textLen;
CStr255		filePath;

	if NOT(err = QBAPI_GetCell(qbRecP->connID, nil, fieldName, recNum, true, fieldStr, &fldType, &empty))
	{	if (((fldType & 0xF) == typeNum) && (fieldStr[0] == 1) && (fieldStr[1] == '-'))
			fieldStr[0] = 0;
		if (fldType == typeTxt+typeLongText)
		{	textInitP = fieldStr+2;
			textLen = *(short*)&fieldStr[0];
		}
		else if (fldType == typeBool)
		{	textInitP = fieldStr+3;
			textLen = fieldStr[2];
		}
		else if ((fldType & 0xF) == typeXFile)
		{	if NOT(err = _GetPathOfFile(fieldStr, filePath))
			{	textInitP = (Byte*)filePath;
				textLen = CLen(filePath);
			}
		}
		else
		{	textLen = fieldStr[0];
			textInitP = (Byte*)fieldStr + 1;
		}
		if NOT(err)
		{	if (textInitP)
				err = BAPI_StringToObj(api_data, (Ptr)textInitP, textLen, resultObjRefP);
			else
				err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
		}
	}
	else
		err = XError(kBAPI_ClassError, err);

return err;
}

#pragma mark-
//===========================================================================================
static XErr	_NewRecord(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				newRecID, totParams = exeMethodRecP->totParams;

	if NOT(totParams)
	{	if NOT(err = QBAPI_AddRecord(qbRecP->connID, &newRecID))
			err = BAPI_IntToObj(api_data, newRecID, &exeMethodRecP->resultObjRef);
		else
			err = XError(kBAPI_ClassError, err);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_DeleteRecord(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				record, api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;
Boolean				isRecID;

	if ((totParams == 1) || (totParams == 2))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &record, kImplicitTypeCast))
		{	if (totParams == 2)
				err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &isRecID, kImplicitTypeCast);
			else
				isRecID = false;
			if NOT(err)
			{	if (isRecID)
					err = QBAPI_DeleteRecord(qbRecP->connID, 0, record);	// with recID
				else
					err = QBAPI_DeleteRecord(qbRecP->connID, record, 0);
				if (err)
					err = XError(kBAPI_ClassError, err);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetCurRecs(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				curRecs, totParams = exeMethodRecP->totParams;

	if NOT(totParams)
	{	if NOT(err = QBAPI_GetCurRecs(qbRecP->connID, &curRecs))
			err = BAPI_IntToObj(api_data, curRecs, &exeMethodRecP->resultObjRef);
		else
			err = XError(kBAPI_ClassError, err);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetDBPath(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;

	if NOT(totParams)
		err = BAPI_StringToObj(api_data, (Ptr)&qbRecP->path[1], qbRecP->path[0], &exeMethodRecP->resultObjRef);
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetTotFields(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				totFields, api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;

	if NOT(totParams == 1)
	{	if NOT(err = QBAPI_GetTotFields(qbRecP->connID, &totFields))
			err = BAPI_IntToObj(api_data, totFields, &exeMethodRecP->resultObjRef);
		else
			err = XError(kBAPI_ClassError, err);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetRecNum(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				recNum, recID, api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &recID, kImplicitTypeCast))
		{	if NOT(err = QBAPI_GetRecNum(qbRecP->connID, recID, &recNum))
				err = BAPI_IntToObj(api_data, recNum, &exeMethodRecP->resultObjRef);
			else
				err = XError(kBAPI_ClassError, err);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetRecID(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				recNum, recID, api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &recNum, kImplicitTypeCast))
		{	if NOT(err = QBAPI_GetRecID(qbRecP->connID, recNum, &recID))
				err = BAPI_IntToObj(api_data, recID, &exeMethodRecP->resultObjRef);
			else
				err = XError(kBAPI_ClassError, err);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetFieldName(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				fldNum, api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;
Str255				fldName;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &fldNum, kImplicitTypeCast))
		{	if NOT(err = QBAPI_GetFieldName(qbRecP->connID, fldNum, fldName, nil))
				err = BAPI_StringToObj(api_data, (Ptr)&fldName[1], fldName[0], &exeMethodRecP->resultObjRef);
			else
				err = XError(kBAPI_ClassError, err);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Sort(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP, Boolean selectDistinct)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;
QBAPI_SortRec		sortArray[8], *sortP;
long				aLong, sortType, cStrLen, fldsToSort;
int					i;
CStr255				cStr;

	if (totParams >= 2)
	{	fldsToSort = totParams / 2;
		if (fldsToSort <= 8)
		{	sortP = &sortArray[0];
			for (i = 0; (i < totParams) && NOT(err); i += 2, sortP++)
			{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[i].objRef, cStr, &cStrLen, 63, kImplicitTypeCast))
				{	cStr[cStrLen] = 0;
					CToPascal(cStr, sortP->fldName);
					sortP->fldNum = 0;
					if NOT(err = QBAPI_GetFieldNumber(qbRecP->connID, sortP->fldName, &aLong))
					{	sortP->fldNum = aLong;
						if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[i+1].objRef, &sortType, kImplicitTypeCast))
						{	switch(sortType)
							{	case kAsc_cs:
									sortP->sortType = kAsc;
									sortP->caseSense = 1;
									sortP->docSortMode = 0;
									break;
								case kDesc_cs:
									sortP->sortType = kDesc;
									sortP->caseSense = 1;
									sortP->docSortMode = 0;
									break;
								case kFileSize_asc:
									sortP->sortType = kAsc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortFileSizeM;
									break;
								case kFileSize_desc:
									sortP->sortType = kDesc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortFileSizeM;
									break;
								case kCreatDate_asc:
									sortP->sortType = kAsc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortCreatDateM;
									break;
								case kCreatDate_desc:
									sortP->sortType = kDesc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortCreatDateM;
									break;
								case kModifDate_asc:
									sortP->sortType = kAsc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortModifDateM;
									break;
								case kModifDate_desc:
									sortP->sortType = kDesc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortModifDateM;
									break;
								case kFileType_asc:
									sortP->sortType = kAsc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortFileTypeM;
									break;
								case kFileType_desc:
									sortP->sortType = kDesc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortFileTypeM;
									break;
								case kFileCreat_asc:
									sortP->sortType = kAsc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortFileCreatM;
									break;
								case kFileCreat_desc:
									sortP->sortType = kDesc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortFileCreatM;
									break;
								case kRelevancy_asc:
									sortP->sortType = kAsc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortRelevancyM;
									break;
								case kRelevancy_desc:
									sortP->sortType = kDesc;
									sortP->caseSense = 0;
									sortP->docSortMode = kSortRelevancyM;
									break;
								default:
									sortP->sortType = sortType;
									sortP->caseSense = 0;
									sortP->docSortMode = 0;
									break;
							}
						}
					}
					else
						err = XError(kBAPI_ClassError, err);
				}
			}
			if NOT(err)
			{	if (selectDistinct)
					err = QBAPI_SelectDistinct(qbRecP->connID, fldsToSort, sortArray);
				else
					err = QBAPI_Sort(qbRecP->connID, fldsToSort, sortArray);
				if (err)
					err = XError(kBAPI_ClassError, err);
			}
		}
		else
		{	err = -1;
			CEquStr(pbPtr->error, "Too much fields to sort");
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_SelectRel(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				fldNum, fldNum2, api_data = pbPtr->api_data;
long				tLen, totParams = exeMethodRecP->totParams;
CStr63				fldName_c, fldName2_c;
Str63				fldName, fldName2;
long				findDocMode, mode, operat, findType, recFound, connID = qbRecP->connID;
Str255				keyStrErr;
QuickBaseRec		qbRec;

	if (totParams >= 4)
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &operat, kImplicitTypeCast))
		{	switch(operat)
			{	case kAllNot:
					operat = kAll;
					mode = kNotMode;
					break;
				case kAndNot:
					operat = kAnd;
					mode = kNotMode;
					break;
				case kOrNot:
					operat = kOr;
					mode = kNotMode;
					break;
				default:
					mode = kNormalMode;
					break;
			}
			if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, fldName_c, nil, 63, kImplicitTypeCast))
			{	CToPascal(fldName_c, fldName);
				if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &findType, kImplicitTypeCast))
				{	if NOT(err = _GetOperat(&findType, &findDocMode, nil))
					{	tLen = sizeof(QuickBaseRec);
						if NOT(err = BAPI_ReadObj(api_data, &exeMethodRecP->paramVarsP[3].objRef, (Ptr)&qbRec, &tLen, 0, nil))
						{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[4].objRef, fldName2_c, nil, 63, kImplicitTypeCast))
							{	CToPascal(fldName2_c, fldName2);
								if NOT(err = QBAPI_GetFieldNumber(connID, fldName, &fldNum))
								{	if NOT(err = QBAPI_GetFieldNumber(qbRec.connID, fldName2, &fldNum2))
									{	if NOT(err = QBAPI_SelectRel(connID, &recFound, fldNum, findType, operat, keyStrErr, mode, findDocMode, qbRec.connID, fldNum2))
											err = BAPI_IntToObj(api_data, recFound, &exeMethodRecP->resultObjRef);
										else
										{	err = XError(kBAPI_ClassError, err);
											PascalToC(keyStrErr, pbPtr->error);
										}
									}
									else
										err = XError(kBAPI_ClassError, err);
								}
								else
									err = XError(kBAPI_ClassError, err);
							}
						}
					}
				}
			}
		}								
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_IsSkipWord(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
XErr				err = noErr;
long				connID = qbRecP->connID;
CStr63				fieldName, word;
Str63				fieldName_p, word_p;
Boolean				isSkip;
long 				api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fieldName, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, word, nil, 63, kImplicitTypeCast))
		{	CToPascal(fieldName, fieldName_p);
			CToPascal(word, word_p);
			if NOT(err = QBAPI_IsSkipWord(connID, fieldName_p, word_p, &isSkip))
				err = BAPI_BooleanToObj(api_data, isSkip, &exeMethodRecP->resultObjRef);
			else
				err = XError(kBAPI_ClassError, err);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_Select(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP, Boolean mandatory)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				keyLen, totLines, i, totParams = exeMethodRecP->totParams;
CStr63				fldName_c, keyStr_c;
Str63				fldName, keyStr;
long				findDocMode, mode, operat, t_operat, findType, t_findType, recFound = 0, connID = qbRecP->connID;
Str255				keyStrErr;
int					totAdded, j, k;
BlockRef			ref;
Boolean				toEnclose = true;
Byte				t_group;

	if ((totParams >= 4) && NOT(totParams % 4))
	{	totLines = totParams / 4;
		k = 0;
		totAdded = 0;
		for (i = 0; (i < totLines) && NOT(err); i++)
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[k++].objRef, &operat, kImplicitTypeCast))
			{	switch(operat)
				{	case kAllNot:
						operat = kAll;
						mode = kNotMode;
						break;
					case kAndNot:
						operat = kAnd;
						mode = kNotMode;
						break;
					case kOrNot:
						operat = kOr;
						mode = kNotMode;
						break;
					default:
						mode = kNormalMode;
						break;
				}
				if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[k++].objRef, fldName_c, nil, 64, kImplicitTypeCast))
				{	CToPascal(fldName_c, fldName);
					if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[k++].objRef, &findType, kImplicitTypeCast))
					{	Boolean		addWilde;
					
						if NOT(err = _GetOperat(&findType, &findDocMode, &addWilde))
						{	if (BAPI_GetObjClassID(api_data, &exeMethodRecP->paramVarsP[k].objRef) == gsSearchClassID)
							{	SearchHeaderP	searchHeadP;
								SearchItemP		sItemP;
								long			tot, searchHeadLen;
								
								if NOT(err = _GetBlock(api_data, &exeMethodRecP->paramVarsP[k++].objRef, &searchHeadP, &searchHeadLen, &ref))
								{	tot = searchHeadP->totItems;
									if (tot)
									{	for (j = 0; j < tot; j++)
										{	sItemP = &searchHeadP->sItem[j];
											if (t_group = _GetSearchGroup(sItemP->group))
												toEnclose = false;
											else
												t_group = kNoPar;
											if (j)	//the first one is that of the line
												t_operat = _GetSearchOperat(sItemP->operat, &mode);
											else
												t_operat = operat;
											switch(sItemP->wildChar)
											{	case kCONTAIN:
													t_findType = kContainStr;
													break;
												case kBEGIN:
													if ((findType == kContainStr) || (findType == kContainWordExact))
														t_findType = kContainWordBegin;
													else
														t_findType = kBegin;
													break;
												case kEND:
													if ((findType == kContainStr) || (findType == kContainWordExact))
														t_findType = kContainWordEnd;
													else
														t_findType = kEnd;
													break;
												default:
													t_findType = findType;
													break;
											}
											if ((keyLen = CLen(sItemP->key)) < 63)
											{	CopyBlock(&keyStr[1], sItemP->key, keyLen);
												keyStr[0] = keyLen;
												if (keyLen || mandatory)
												{	if (addWilde)
														PAddChar(keyStr, '*');
													if NOT(err = QBAPI_AddSearchLine(connID, keyStr, 0, fldName, t_findType, t_operat, t_group, mode, findDocMode))
														totAdded++;
													else
														err = XError(kBAPI_ClassError, err);
												}
											}
										}
									}
									else if (mandatory)
									{	if NOT(err = QBAPI_AddSearchLine(connID, "\p", 0, fldName, findType, operat, kNoPar, mode, findDocMode))
											totAdded++;
										else
											err = XError(kBAPI_ClassError, err);
									}
									_ReleaseBlock(&ref);
								}
							}
							else
							{	err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[k++].objRef, keyStr_c, &keyLen, 64, kImplicitTypeCast);
								if (err && (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall)))
								{	CEquStr(pbPtr->error, "search string can't be more than 63 chars in length");
									err = XError(kBAPI_ClassError, QBAPI_Err_StringTooLong);
									BAPI_Exception(api_data, kBAPI_ClassError, QBAPI_Err_StringTooLong, "qb", true);
								}
								if NOT(err)
								{	if (keyLen || mandatory)
									{	CToPascal(keyStr_c, keyStr);
										if (addWilde)
											PAddChar(keyStr, '*');
										if NOT(err = QBAPI_AddSearchLine(connID, keyStr, 0, fldName, findType, operat, kNoPar, mode, findDocMode))
											totAdded++;
										else
											err = XError(kBAPI_ClassError, err);
									}
								}
							}
						}
					}
				}
			}
		}
		if NOT(err)
		{	if (totAdded)
			{	if ((totAdded > 1) && toEnclose)
				{	if NOT(err = QBAPI_ModifySearchLineGroup(connID, kOpenPar, 1))
					{	if (err = QBAPI_ModifySearchLineGroup(connID, totAdded, kClosePar))
							err = XError(kBAPI_ClassError, err);
					}
					else
						err = XError(kBAPI_ClassError, err);
				}
				if NOT(err)
				{	if (err = QBAPI_Select(connID, &recFound, keyStrErr))
					{	err = XError(kBAPI_ClassError, err);
						PascalToC(keyStrErr, pbPtr->error);
					}
				}
			}
			else
			{	if (err = QBAPI_GetCurRecs(connID, &recFound))
					err = XError(kBAPI_ClassError, err);
			}
			if NOT(err)
				err = BAPI_IntToObj(api_data, recFound, &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Save(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				theError, err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;

	if NOT(totParams)
	{	theError = QBAPI_Save(qbRecP->connID);
		err = BAPI_IntToObj(api_data, theError, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

typedef struct {
				long		api_data;
				long		totDocuments;
				long		oldPerc;
				CStr63		callbackName;
				XErr		lastError;
				} OptimCallBackParam;

//===========================================================================================
static int _optimYield(long cnt, long userPar)
{
ParameterRec		param;
OptimCallBackParam	*optimRecP = (OptimCallBackParam*)userPar;
ObjRef				result;
XErr				err = noErr;
long				api_data = optimRecP->api_data;
long				perc;

	if (cnt < 0)
	{	optimRecP->totDocuments = -cnt;
		perc = 0;
		optimRecP->oldPerc = -1;
	}
	else
		perc = (cnt * 100) / optimRecP->totDocuments;
	if (perc != optimRecP->oldPerc)
	{	if (err = XYield(nil))
			return err;
		if (*optimRecP->callbackName)
		{	BAPI_ClearParameterRec(api_data, &param);
			if NOT(err = BAPI_IntToObj(api_data, cnt, &param.objRef))
			{	if NOT(err = BAPI_ExecuteFunction(api_data, &param, 1, optimRecP->callbackName, &result))
					err = BAPI_ObjToInt(api_data, &result, (long*)&err, kImplicitTypeCast);
				else if NOT(optimRecP->lastError)
					optimRecP->lastError = err;
			}
		}
		optimRecP->oldPerc = perc;
	}
	
return err;
}

//===========================================================================================
static XErr	_Optimize(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				theError, err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;
OptimCallBackParam	optimCBParam;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, optimCBParam.callbackName, nil, 63, kImplicitTypeCast))
	{	optimCBParam.api_data = api_data;
		optimCBParam.lastError = noErr;
		optimCBParam.totDocuments = optimCBParam.oldPerc = 0;
		theError = QBAPI_OptimizeDBExt(qbRecP->connID, _optimYield, (long)&optimCBParam);
		if (optimCBParam.lastError)
			err = optimCBParam.lastError;
		else
			err = BAPI_IntToObj(api_data, theError, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	 _GetFieldNote(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;
CStr63				fldName_c;
Str63				fldName;
Str255				noteStr;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fldName_c, nil, 63, kImplicitTypeCast))
		{	CToPascal(fldName_c, fldName);
			if NOT(err = QBAPI_GetFieldNote(qbRecP->connID, 0, fldName, noteStr))
				err = BAPI_StringToObj(api_data, (Ptr)&noteStr[1], noteStr[0], &exeMethodRecP->resultObjRef);
			else
				err = XError(kBAPI_ClassError, err);
		}
	}	
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	 _SetCell(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
long 				api_data = pbPtr->api_data;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
XErr				err = noErr;
CStr63				fldName;
CStr255				aCStr;
long				recNum, stringLen;
Ptr					stringP;
BlockRef			ref;
Str63				fldName_p;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fldName, nil, 64, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &recNum, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[2].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
			{	CToPascal(fldName, fldName_p);
				if (err = QBAPI_SetCell(qbRecP->connID, recNum, 0, 0, fldName_p, stringP, stringLen))
					err = XError(kBAPI_ClassError, err);
				BAPI_ReleaseBlock(&ref);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	 _GetCell(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
long 				api_data = pbPtr->api_data;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
XErr				err = noErr;
CStr63				fldName;
long				recNum;
Str63				fldName_p;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fldName, nil, 64, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &recNum, kImplicitTypeCast))
		{	CToPascal(fldName, fldName_p);
			err = _GetCellString(api_data, qbRecP, fldName_p, recNum, &exeMethodRecP->resultObjRef);
		}
	}

return err;
}

//===========================================================================================
static XErr	 _SetFieldNote(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				noteLen, totParams = exeMethodRecP->totParams;
CStr63				fldName_c;
Str63				fldName;
CStr255				noteStr_c;

	if (totParams == 2)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fldName_c, nil, 63, kImplicitTypeCast))
		{	CToPascal(fldName_c, fldName);
			if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, noteStr_c, &noteLen, 255, kImplicitTypeCast))
			{	if (err = QBAPI_SetFieldNote(qbRecP->connID, 0, fldName, noteStr_c, noteLen))
					err = XError(kBAPI_ClassError, err);
			}
		}
	}	
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	 _GetQBServerRoot(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;
Str255				rootPath;
CStr255				tempStr;

	if NOT(totParams)
	{	if NOT(err = QBAPI_GetRoot(rootPath))
		{	CEquStr(tempStr, FILE_HD_PREFIX);
			CAddStr(tempStr, "/");
			PSubstitute(rootPath, ':', '/');
			AddPascalToCStr(tempStr, rootPath);
			err = BAPI_StringToObj(api_data, tempStr, CLen(tempStr), &exeMethodRecP->resultObjRef);
		}
		else
			err = XError(kBAPI_ClassError, err);
	}	
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetDBOpenPaths(Biferno_ParamBlockPtr pbPtr)
{	
long				api_data = pbPtr->api_data, idx, numDb;
Handle				dbOpenPathH;
StringPtr			curPath;
XErr				err = noErr;
ParameterRec		*tempPathsP, *pathsP;
BlockRef			totPathsBlock;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;

	if (dbOpenPathH = NewHandle(0))
	{	if NOT(err = QBAPI_GetDBOpenPaths(&numDb, &dbOpenPathH))
		{	if (totPathsBlock = NewPtrBlock(numDb * sizeof(ParameterRec), &err, (Ptr*)&pathsP))
			{	//pathsP = (ParameterRec*)GetPtr(totPathsBlock);
				HLock(dbOpenPathH);
				curPath = (StringPtr)*dbOpenPathH;
				tempPathsP = pathsP;
				for(idx = 0; (idx < numDb) && NOT(err); idx++, curPath += (*curPath+1), tempPathsP++)
				{	*tempPathsP->name = 0;
					BAPI_InvalObjRef(api_data, &tempPathsP->objRef);
					err = BAPI_StringToObj(api_data, (Ptr)&curPath[1], curPath[0], &tempPathsP->objRef);
				}
				DisposeHandle(dbOpenPathH);
				dbOpenPathH = nil;
				if NOT(err)
					err = BAPI_ArrayToObj(api_data, false, pathsP, numDb, nil, nil, &exeMethodRecP->resultObjRef);
				DisposeBlock(&totPathsBlock);
			}
		}
		else
			err = XError(kBAPI_ClassError, err);
		if (dbOpenPathH)
			DisposeHandle(dbOpenPathH);
	}
	else
		err = MemError();

return err;
}

//===========================================================================================
static XErr	_SelectAll(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				recFound, totParams = exeMethodRecP->totParams;

	if NOT(totParams)
	{	if NOT(err = QBAPI_SelectAll(qbRecP->connID, &recFound))
			err = BAPI_IntToObj(api_data, recFound, &exeMethodRecP->resultObjRef);
		else
			err = XError(kBAPI_ClassError, err);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Export(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
XErr				err = noErr;
long				connID = qbRecP->connID;
long 				api_data = pbPtr->api_data;
CStr255				filePath;
CStr31				recSep, fieldSep;
ObjRef				arrayObjRef;
Boolean 			overWrite, exportText;
FSSpec				fileSpec;
long				totfields, totRecsExported = 0;
Byte				fieldList[256];

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	err = BAPI_RealPath(api_data, filePath, true);
		if (err == XError(kXLibError, ErrXFiles_FileNotFound))
			err = noErr;
		if NOT(err)
		{	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, recSep, nil, 31, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, fieldSep, nil, 31, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[3].objRef, &totfields, kImplicitTypeCast))
				goto out;
			arrayObjRef = exeMethodRecP->paramVarsP[4].objRef;
			if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[5].objRef, &overWrite, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[6].objRef, &exportText, kImplicitTypeCast))
				goto out;
			if NOT(err = _GetMacSpec(filePath, &fileSpec, true, true))
			{	if NOT(err = _ArrayToByteList(api_data, connID, totfields, &arrayObjRef, fieldList, true))
				{	err = QBAPI_ExportData(connID, &fileSpec, *recSep, *fieldSep, totfields, exportText, overWrite, fieldList, nil, 0L, &totRecsExported);
					if (err)
					{	if (err > 0)
							err = XError(kBAPI_ClassError, err);
					}
					else
						err = BAPI_IntToObj(api_data, totRecsExported, &exeMethodRecP->resultObjRef);
				}
			}
		}
	}

out:	
return err;
}

//===========================================================================================
static XErr	_Import(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
XErr				err = noErr;
long				connID = qbRecP->connID;
long 				api_data = pbPtr->api_data;
CStr255				filePath;
CStr31				recSep, fieldSep;
ObjRef				arrayObjRef;
FSSpec				fileSpec;
long				matchFieldNum, fromRec, mode, totfields, totRecsImported = 0;
Byte				fieldList[256];
CStr63				matchField;
Str63				matchField_p;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, true))
		{	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, recSep, nil, 31, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, fieldSep, nil, 31, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[3].objRef, &totfields, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[4].objRef, &mode, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[5].objRef, &fromRec, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[6].objRef, matchField, nil, 63, kImplicitTypeCast))
				goto out;
			if (*matchField)
			{	CToPascal(matchField, matchField_p);
				if (err = QBAPI_GetFieldNumber(connID, matchField_p, &matchFieldNum))
				{	err = XError(kBAPI_ClassError, err);
					goto out;
				}
			}
			arrayObjRef = exeMethodRecP->paramVarsP[7].objRef;
			if NOT(err = _GetMacSpec(filePath, &fileSpec, true, true))
			{	if NOT(err = _ArrayToByteList(api_data, connID, totfields, &arrayObjRef, fieldList, false))
				{	err = QBAPI_ImportData(connID, &fileSpec, *recSep, *fieldSep, totfields, mode, fromRec, matchFieldNum, fieldList, nil, 0L, &totRecsImported);
					if (err)
						err = XError(kBAPI_ClassError, err);
					else
						err = BAPI_IntToObj(api_data, totRecsImported, &exeMethodRecP->resultObjRef);
				}
			}
		}
	}

out:	
return err;
}

//===========================================================================================
static XErr	_GetFieldInfo(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
XErr				err = noErr;
long				which;
CStr63				fieldName;
long				fldNum, connID = qbRecP->connID;
Str63				fieldName_p;
long 				api_data = pbPtr->api_data;
long				fldType;

	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fieldName, nil, 63, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &which, kImplicitTypeCast))
		goto out;
	CToPascal(fieldName, fieldName_p);
	if (err = QBAPI_GetFieldNumber(connID, fieldName_p, &fldNum))
	{	err = XError(kBAPI_ClassError, err);
		goto out;
	}
	if (err = QBAPI_GetFieldType(connID, fldNum, nil, &fldType))
	{	err = XError(kBAPI_ClassError, err);
		goto out;
	}

	if (which == kFType)
		err = BAPI_IntToObj(api_data, fldType, &exeMethodRecP->resultObjRef);
	else
	{	BlockRef		fieldInfoBlock;
		QBAPI_FldInfoP	fldInfoP = nil;
		long			aLong;
		
		if (fieldInfoBlock = NewBlockLocked(sizeof(QBAPI_FldInfo), &err, (Ptr*)&fldInfoP))
		{	//LockBlock(fieldInfoBlock);
			//fldInfoP = (QBAPI_FldInfoP)GetPtr(fieldInfoBlock);
			if NOT(err = QBAPI_GetFieldInfo(connID, fldNum, 0, 0, fldInfoP))
			{	switch(which)
				{
					case kIndex:
						err = BAPI_IntToObj(api_data, fldNum, &exeMethodRecP->resultObjRef);
						break;
					case kFType:
						break;
					case kMin:
						switch(fldType & 0xF)
						{	case typeTxt:
								aLong = fldInfoP->u.infTextRec.min;
								break;
							case typeNum:
								aLong = fldInfoP->u.infNumRec.min;
								break;
							case typeBool:
								aLong = fldInfoP->u.infBoolRec.totFalse;
								break;
							default:
								aLong = 0;
								break;
						}
						err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
						break;
					case kMax:
						switch(fldType & 0xF)
						{	case typeTxt:
								aLong = fldInfoP->u.infTextRec.max;
								err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
								break;
							case typeNum:
								err = BAPI_DoubleToObj(api_data, fldInfoP->u.infNumRec.max, &exeMethodRecP->resultObjRef);
								break;
							case typeBool:
								aLong = fldInfoP->u.infBoolRec.totTrue;
								err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
								break;
							default:
								err = BAPI_IntToObj(api_data, 0, &exeMethodRecP->resultObjRef);
								break;
						}
						break;
					case kTotal:
						switch(fldType & 0xF)
						{	case typeTxt:
								aLong = fldInfoP->u.infTextRec.tot;
								err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
								break;
							case typeNum:
								err = BAPI_DoubleToObj(api_data, fldInfoP->u.infNumRec.tot, &exeMethodRecP->resultObjRef);
								break;
							default:
								err = BAPI_IntToObj(api_data, 0, &exeMethodRecP->resultObjRef);
								break;
						}
						break;
					case kAverage:
						switch(fldType & 0xF)
						{	case typeTxt:
								err = BAPI_DoubleToObj(api_data, fldInfoP->u.infTextRec.average, &exeMethodRecP->resultObjRef);
								break;
							case typeNum:
								err = BAPI_DoubleToObj(api_data, fldInfoP->u.infNumRec.average, &exeMethodRecP->resultObjRef);
								break;
							default:
								err = BAPI_DoubleToObj(api_data, 0, &exeMethodRecP->resultObjRef);
								break;
						}
						break;
					case kMissing:
						switch(fldType & 0xF)
						{	case typeTxt:
								aLong = fldInfoP->u.infTextRec.miss;
								break;
							case typeNum:
								aLong = fldInfoP->u.infNumRec.miss;
								break;
							default:
								aLong = 0;
								break;
						}
						err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
						break;
					default:
						err = BAPI_IntToObj(api_data, 0, &exeMethodRecP->resultObjRef);
						break;
				}
			}
			DisposeBlock(&fieldInfoBlock);
		}
	}
	
out:
return err;
}

//===========================================================================================
static XErr	_GetFilesInfo(Biferno_ParamBlockPtr pbPtr, QuickBaseRec *qbRecP)
{
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
XErr				err = noErr;
long				which;
CStr63				fieldName;
long				tLen, fldNum, connID = qbRecP->connID;
Str63				fieldName_p;
long 				osTypeIndex = 0, api_data = pbPtr->api_data;
long				fldType;
CStr15				osTypeStr;
OSType				osType;
BlockRef			fieldInfoBlock;
QBAPI_FldInfoP		fldInfoP = nil;
long				aLong;

	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fieldName, nil, 63, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &which, kImplicitTypeCast))
		goto out;
	CToPascal(fieldName, fieldName_p);
	if (err = QBAPI_GetFieldNumber(connID, fieldName_p, &fldNum))
	{	err = XError(kBAPI_ClassError, err);
		goto out;
	}
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, osTypeStr, nil, 15, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[3].objRef, &osTypeIndex, kImplicitTypeCast))
		goto out;
	if (*osTypeStr)
		osType = *(OSType*)osTypeStr;
	if (*osTypeStr)
		osType = *(OSType*)osTypeStr;
	else
		osType = 0;
	if (err = QBAPI_GetFieldType(connID, fldNum, nil, &fldType))
	{	err = XError(kBAPI_ClassError, err);
		goto out;
	}
	if ((fldType & 0xF) == typeXFile)
	{	if (fieldInfoBlock = NewBlockLocked(sizeof(QBAPI_FldInfo), &err, (Ptr*)&fldInfoP))
		{	//LockBlock(fieldInfoBlock);
			//fldInfoP = (QBAPI_FldInfoP)GetPtr(fieldInfoBlock);
			if NOT(err = QBAPI_GetFieldInfo(connID, fldNum, osTypeIndex, osType, fldInfoP))
			{	
				switch(which)
				{
					case kTotFiles:
						aLong = fldInfoP->u.infXFileRec.fileCount;
						err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
						break;
					case kTotDupFiles:
						aLong = fldInfoP->u.infXFileRec.duplCount;
						err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
						break;
					/*case kTotThumb:
						aLong = fldInfoP->u.infXFileRec.thumbCount;
						err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
						break;*/
					case kTotBytes:
						err = BAPI_DoubleToObj(api_data, fldInfoP->u.infXFileRec.bytesCount, &exeMethodRecP->resultObjRef);
						break;
					case kTotTypes:
						aLong = fldInfoP->u.infXFileRec.infoCount;
						err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
						break;
					case kIndType:
						if (fldInfoP->u.infXFileRec.fType)
							tLen = sizeof(OSType);
						else
							tLen = 0;
						err = BAPI_StringToObj(api_data, (Ptr)&fldInfoP->u.infXFileRec.fType, tLen, &exeMethodRecP->resultObjRef);
						break;
					default:
						err = BAPI_IntToObj(api_data, 0, &exeMethodRecP->resultObjRef);
						break;
				}
			}
			DisposeBlock(&fieldInfoBlock);
		}
	}
	else
		err = BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
	
out:
return err;
}

#pragma mark-
//===========================================================================================
static XErr	QuickBase_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec			*initRecP = &pbPtr->param.initRec.newClassRec;
XErr				err = noErr;
long				api_data = pbPtr->api_data;
BAPI_MemberRecord	quickbaseMethods[TOT_METHODES] = 
					{	"GetQBServerRoot",	kGetQBServerRoot,	"static string GetQBServerRoot(void)",
						"GetDBOpenPaths",	kGetDBOpenPaths,	"static array GetDBOpenPaths(void)",
						"Sort", 			kSort, 				"void Sort(string field1, int sortType1=asc...)",
						"GetFieldName",		kGetFieldName,		"string GetFieldName(int fieldNum)",
						"GetDBPath", 		kGetDBPath,			"string GetDBPath(void)",
						"GetCurRecs", 		kGetCurRecs,		"int GetCurRecs(void)",
						"GetTotFields",		kGetTotFields,		"int GetTotFields(void)",
						"GetRecNum", 		kGetRecNum,			"int GetRecNum(int recID)",
						"GetRecID", 		kGetRecID,			"int GetRecID(int recNum)",
						"NewRecord", 		kNewRecord,			"int NewRecord(void)",
						"DeleteRecord",		kDeleteRecord,		"void DeleteRecord(int recNum, boolean isRecID=false)",
						"Save",				kSave,				"int Save(void)",
						"Optimize",			kOptimize,			"int Optimize(string callBackName)",
						"GetFieldNote",		kGetFieldNote,		"string GetFieldNote(string field)",
						"SetFieldNote",		kSetFieldNote,		"void SetFieldNote(string field, string note)",
						"GetCell",			kGetCell,			"string GetCell(string field, int recNum)",
						"SetCell",			kSetCell,			"void SetCell(string field, int recNum, string value)",
						"SelectAll",		kSelectAll,			"int SelectAll(void)",
						"SelectDistinct",	kSelectDistinct,	"void SelectDistinct(string field1, int sortType1=asc...)",
						"Select", 			kSelect,			"int Select(int mode, string field, int operat, obj searchStr...)",
						"SelectMand",		kSelectMand,		"int SelectMand(int mode, string field, int operat, obj searchStr...)",
						"SelectRel",		kSelectRel,			"int SelectRel(int mode, string field, int operat, qb db, string dbField)",
						"IsSkipWord",		kIsSkipWord,		"boolean IsSkipWord(string field, string word)",
						"Export",			kExport,			"int Export(string filePath, string recSep, string fieldSep, int totfields, array fldList, boolean overWrite, boolean exportText)",
						"Import",			kImport,			"int Import(string filePath, string recSep, string fieldSep, int totfields, int mode=add, int fromRec, string matchField, array fldList)",
						"GetFieldInfo",		kGetFieldInfo,		"obj GetFieldInfo(string field, int which=index)",
						"GetFilesInfo",		kGetFilesInfo,		"obj GetFilesInfo(string field, int which=totFiles, string osType, int osTypeIndex)"
					};

BAPI_MemberRecord		quickbaseCostants[TOT_COSTANTS] = 
					{	"asc", 				kAsc,			"int",
						"desc", 			kDesc,			"int",
						"ascCs", 			kAsc_cs,			"int",
						"descCs", 			kDesc_cs,			"int",
						"fileSizeAsc", 		kFileSize_asc,			"int",
						"fileSizeDesc",		kFileSize_desc,			"int",
						"creatDateAsc", 	kCreatDate_asc,			"int",
						"creatDateDesc",	kCreatDate_desc,			"int",
						"modifDateAsc", 	kModifDate_asc,			"int",
						"modifDateDesc", 	kModifDate_desc,			"int",
						"fileTypeAsc", 		kFileType_asc,			"int",
						"fileTypeDesc", 	kFileType_desc,			"int",
						"fileCreatAsc", 	kFileCreat_asc,			"int",
						"fileCreatDesc", 	kFileCreat_desc,			"int",
						"relevancyAsc", 	kRelevancy_asc,			"int",
						"relevancyDesc", 	kRelevancy_desc,			"int",
						
						"all", 				kAll,			"int",
						"and", 				kAnd,			"int",
						"or", 				kOr,			"int",
						"allNot", 			kAllNot,			"int",
						"andNot", 			kAndNot,			"int",
						"orNot", 			kOrNot,			"int",
						
						"equal", 			kEqual,			"int",
						"begins", 			kBegin,			"int",
						"ends", 			kEnd,			"int",
						"greater", 			kMajor,			"int",
						"greaterEqu", 		kMajorEqu,			"int",
						"less", 			kMinor,			"int",
						"lessEqu", 			kMinorEqu,			"int",
						"contains", 		kContainStr,			"int",
						"containsWordBegin",kContainWordBegin,			"int",
						"containsWordEnd", 	kContainWordEnd,			"int",
						"containsWordExact",kContainWordExact,			"int",

						"containsWordInText", 		kContainStrInText,			"int",
						"containsWordBeginInText",	kContainWordBeginInText,			"int",
						
						"greaterInFileSize", 		kMajorInFileSize,			"int",
						"greaterEquInFileSize", 	kMajorEquInFileSize,			"int",
						"lessInFileSize", 			kMinorInFileSize,			"int",
						"lessEquInFileSize", 		kMinorEquInFileSize,			"int",

						"greaterInCreatDate", 		kMajorInCreatDate,			"int",
						"greaterEquInCreatDate", 	kMajorEquInCreatDate,			"int",
						"lessInCreatDate", 			kMinorInCreatDate,			"int",
						"lessEquInCreatDate", 		kMinorEquInCreatDate,			"int",

						"greaterInModifDate", 		kMajorInModifDate,			"int",
						"greaterEquInModifDate", 	kMajorEquInModifDate,			"int",
						"lessInModifDate", 			kMinorInModifDate,			"int",
						"lessEquInModifDate", 		kMinorEquInModifDate,			"int",

						"equalInFileType", 				kEqualInFileType,			"int",
						/*
						"beginsInFileType", 			kBeginInFileType,			"int",
						"endsInFileType", 				kEndInFileType,			"int",
						"containsInFileType", 			kContainStrInFileType,			"int",
						"containsWordBeginInFileType",	kContainWordBeginInFileType,			"int",
						"containsWordEndInFileType", 	kContainWordEndInFileType,			"int",
						"containsWordExactInFileType",	kContainWordExactInFileType,			"int",
						*/

						"equalInFileCreator", 				kEqualInFileCreator,			"int",
						/*
						"beginsInFileCreator", 				kBeginInFileCreator,			"int",
						"endsInFileCreator", 				kEndInFileCreator,			"int",
						"containsInFileCreator", 			kContainStrInFileCreator,			"int",
						"containsWordBeginInFileCreator",	kContainWordBeginInFileCreator,			"int",
						"containsWordEndInFileCreator", 	kContainWordEndInFileCreator,			"int",
						"containsWordExactInFileCreator",	kContainWordExactInFileCreator,			"int",
						*/

						"add",	kAdd,			"int",
						"overwrite",	kOverwrite,			"int",
						"match",	kMatch,			"int",
						"totalReplace",	kTotalReplace,			"int",

						"index",	kIndex,			"int",
						"fType",	kFType,			"int",
						"min",		kMin,			"int",
						"max",		kMax,			"int",
						"total",	kTotal,			"int",
						"average",	kAverage,		"int",
						"missing",	kMissing,		"int",
						
						"totFiles",		kTotFiles,		"int",
						"totTypes",		kTotTypes,		"int",
						"indType",		kIndType,		"int",
						"totBytes",		kTotBytes,		"int",
						"totDupFiles",	kTotDupFiles,	"int",
						
						"typeTxt",			typeTxt,		"int",
						"typeNum",			typeNum,		"int",
						"typeData",			typeData,		"int",
						"typeXFile",		typeXFile,		"int",
						"typeBool",			typeBool,		"int",
						"typeListIndx",		typeListIndx,	"int",

						"typeShortText",	typeShortText,	"int",
						"typeLongText",		typeLongText,	"int",
						"typeComprText",	typeComprText,	"int",

						"typeIntNum	",		typeIntNum,		"int",
						"typeLongNum",		typeLongNum,	"int",
						"typeRealNum",		typeRealNum,	"int",

						"typeGenericDoc",	typeGenericDoc,	"int",
						"typeGraphDoc",		typeGraphDoc,	"int",
						"typeTextDoc",		typeTextDoc,	"int"
					};
					

	//CEquStr(pbPtr->param.initRec.description, "QBAPI Support");
	gsInited = false;
	gsSearchClassID = BAPI_ClassIDFromName(api_data, "search", false);
	gsArrayClassID = BAPI_ClassIDFromName(api_data, "array", false);

	if NOT(err = BAPI_NewMethods(api_data, quickbaseClassID, quickbaseMethods, TOT_METHODES, nil))
	{	if NOT(err = BAPI_NewConstants(api_data, quickbaseClassID, quickbaseCostants, TOT_COSTANTS, nil))
		{	if NOT(err = BAPI_RegisterErrors(api_data, quickbaseClassID, QBAPI_Err_ServerExpired, gQBAPIShortErrorsStr, LAST_ERROR-QBAPI_Err_ServerExpired+1))
				_TryInit(api_data);
		}
	}
 	
return err;
}

//===========================================================================================
// Finalizzazioni
static XErr	QuickBase_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#pragma unused(pbPtr)
XErr	err = noErr;

	if (gsInited)
	{	quickbaseClassID = 0;
		if (err = QBAPI_EndDispose())
			err = XError(kBAPI_ClassError, err);
	}
	
return err;
}

//===========================================================================================
static XErr	QuickBase_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean toClone)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data;
Str255			dbPath;
CStr255			cStr;
QuickBaseRec	qbRec;
long			tLen, cLen, newConnID;

	if (constructorRecP->totVars == 1)
	{	if (toClone && BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP[0].objRef) == quickbaseClassID)
		{	tLen = sizeof(QuickBaseRec);
			if NOT(err = BAPI_ReadObj(api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&qbRec, &tLen, 0, nil))
			{	if (err = QBAPI_CloneTask(&newConnID, qbRec.connID))
					err = XError(kBAPI_ClassError, err);
				qbRec.connID = newConnID;
				//(*pbPtr->plugin_run_dataP)++;
			}
		}
		else
		{	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP->objRef, cStr, &cLen, 255, kImplicitTypeCast))
			{	cStr[cLen] = 0;
				CToPascal(cStr, dbPath);
				PEquStr(qbRec.path, dbPath);
				if NOT(err = QBAPI_Connect(&qbRec.connID, dbPath, 0, nil, nil, nil))
					;//(*pbPtr->plugin_run_dataP)++;
				else
					err = XError(kBAPI_ClassError, err);
			}
			else
				CEquStr(pbPtr->error, "Constructor argument of 'quickbase' must be 'string'");
		}
		
		if NOT(err)
		{	PSubstitute(qbRec.path, ':', '/');
			err = BAPI_BufferToObj(api_data, (Ptr)&qbRec, sizeof(QuickBaseRec), quickbaseClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "quickbase(string databasePath)");
	}
	
	//if NOT(err)
	//	constructorRecP->resultObjRef.classID = quickbaseClassID;
		
return err;
}

//===========================================================================================
static XErr	QuickBase_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
QuickBaseRec	qbRec;
long			tLen;

	tLen = sizeof(QuickBaseRec);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&qbRec, &tLen, 0, nil))
	{	if (tLen)
		{	if NOT(err = QBAPI_Disconnect(qbRec.connID))
				;//(*pbPtr->plugin_run_dataP)--;
			else
				err = XError(kBAPI_ClassError, err);
		}
	}
	
return err;
}

//===========================================================================================
// Il risultato va messo in objRef1
static XErr	QuickBase_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
#pragma unused(pbPtr)
XErr err = noErr;

	err = XError(kBAPI_Error, Err_IllegalOperation); 
	
return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	QuickBase_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				tLen, totParams = exeMethodRecP->totParams;
QuickBaseRec		qbRec;

	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
	{	tLen = sizeof(QuickBaseRec);
		if (err = BAPI_ReadObj(api_data, &exeMethodRecP->objRef, (Ptr)&qbRec, &tLen, 0, nil))
			return err;
	}
		
	switch(exeMethodRecP->methodID)
	{
		case kGetQBServerRoot:
			err = _GetQBServerRoot(pbPtr);
			break;
		case kGetDBOpenPaths:
			err = _GetDBOpenPaths(pbPtr);
			break;
		case kSort:
			err = _Sort(pbPtr, &qbRec, false);
			break;
		case kGetFieldName:
			err = _GetFieldName(pbPtr, &qbRec);
			break;
		case kGetDBPath:
			err = _GetDBPath(pbPtr, &qbRec);
			break;	
		case kGetCurRecs:
			err = _GetCurRecs(pbPtr, &qbRec);
			break;
		case kGetTotFields:
			err = _GetTotFields(pbPtr, &qbRec);
			break;
		case kGetRecNum:
			err = _GetRecNum(pbPtr, &qbRec);
			break;
		case kGetRecID:
			err = _GetRecID(pbPtr, &qbRec);
			break;
		case kNewRecord:
			err = _NewRecord(pbPtr, &qbRec);
			break;
		case kDeleteRecord:
			err = _DeleteRecord(pbPtr, &qbRec);
			break;
		case kSave:
			err = _Save(pbPtr, &qbRec);
			break;
		case kOptimize:
			err = _Optimize(pbPtr, &qbRec);
			break;
		case kGetFieldNote:
			err = _GetFieldNote(pbPtr, &qbRec);
			break;
		case kSetFieldNote:
			err = _SetFieldNote(pbPtr, &qbRec);
			break;
		case kGetCell:
			err = _GetCell(pbPtr, &qbRec);
			break;
		case kSetCell:
			err = _SetCell(pbPtr, &qbRec);
			break;
		case kSelectAll:
			err = _SelectAll(pbPtr, &qbRec);
			break;
		case kSelectDistinct:
			err = _Sort(pbPtr, &qbRec, true);
			break;
		case kSelect:
			err = _Select(pbPtr, &qbRec, false);
			break;
		case kSelectMand:
			err = _Select(pbPtr, &qbRec, true);
			break;
		case kSelectRel:
			err = _SelectRel(pbPtr, &qbRec);
			break;
		case kIsSkipWord:
			err = _IsSkipWord(pbPtr, &qbRec);
			break;
		case kExport:
			err = _Export(pbPtr, &qbRec);
			break;
		case kImport:
			err = _Import(pbPtr, &qbRec);
			break;
		case kGetFieldInfo:
			err = _GetFieldInfo(pbPtr, &qbRec);
			break;
		case kGetFilesInfo:
			err = _GetFilesInfo(pbPtr, &qbRec);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	QuickBase_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
GetPropertyRec	*getPropertyRecP = &pbPtr->param.getPropertyRec;
long 			api_data = pbPtr->api_data;
QuickBaseRec	qbRec;
long			ind = 0;//, fldType;
//Boolean			empty;
//Byte			fieldStr[kQBAPIMaxCellLength], *textInitP = nil;
Str63			fieldName;
long			tLen;//, textLen;
//CStr255			filePath;

	if (getPropertyRecP->isConstant)
		err = BAPI_IntToObj(api_data, getPropertyRecP->propertyID, &getPropertyRecP->resultObjRef);
	else if (BAPI_IsObjRefValid(api_data, &getPropertyRecP->objRef))
	{	if (getPropertyRecP->propertyIndex[0].ind > 0)
			ind = getPropertyRecP->propertyIndex[0].ind;
		else if (*getPropertyRecP->propertyIndex[0].ind_name)
			CStringToNum(getPropertyRecP->propertyIndex[0].ind_name, &ind);
		if (ind > 0)
		{	tLen = sizeof(QuickBaseRec);
			if NOT(err = BAPI_ReadObj(api_data, &getPropertyRecP->objRef, (Ptr)&qbRec, &tLen, 0, nil))
			{	CToPascal(getPropertyRecP->propertyName, fieldName);
				err = _GetCellString(api_data, &qbRec, fieldName, ind, &getPropertyRecP->resultObjRef);
				/*if NOT(err = QBAPI_GetCell(qbRec.connID, nil, fieldName, ind, true, fieldStr, &fldType, &empty))
				{	if (((fldType & 0xF) == typeNum) && (fieldStr[0] == 1) && (fieldStr[1] == '-'))
						fieldStr[0] = 0;
					if (fldType == typeTxt+typeLongText)
					{	textInitP = fieldStr+2;
						textLen = *(short*)&fieldStr[0];
					}
					else if (fldType == typeBool)
					{	textInitP = fieldStr+3;
						textLen = fieldStr[2];
					}
					else if ((fldType & 0xF) == typeXFile)
					{	if NOT(err = _GetPathOfFile(fieldStr, filePath))
						{	textInitP = (Byte*)filePath;
							textLen = CLen(filePath);
						}
					}
					else
					{	textLen = fieldStr[0];
						textInitP = (Byte*)fieldStr + 1;
					}
					if NOT(err)
					{	if (textInitP)
							err = BAPI_StringToObj(api_data, (Ptr)textInitP, textLen, &getPropertyRecP->resultObjRef);
						else
							err = BAPI_StringToObj(api_data, "", 0, &getPropertyRecP->resultObjRef);
					}
				}
				else
					err = XError(kBAPI_ClassError, err);
				*/
			}
		}
		else
			err = XError(kBAPI_Error, Err_InvalidArrayIndex);
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchProperty);
			
return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	QuickBase_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
SetPropertyRec	*setPropertyRecP = &pbPtr->param.setPropertyRec;
long 			api_data = pbPtr->api_data;
QuickBaseRec	qbRec;
CStr255			aCStr, tempPath;
BlockRef		ref;
char			*stringP;
long			ind, fldType, tLen, stringLen;
Str63			fieldName;
FSSpec			fileSpec;

	tLen = sizeof(QuickBaseRec);
	if NOT(err = BAPI_ReadObj(api_data, &setPropertyRecP->objRef, (Ptr)&qbRec, &tLen, 0, nil))
	{	CToPascal(setPropertyRecP->propertyName, fieldName);
		if NOT(err = BAPI_GetStringBlock(api_data, &setPropertyRecP->value, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
		{	if NOT(err = QBAPI_GetFieldType(qbRec.connID, 0, fieldName, &fldType))
			{	if (((fldType & 0xF) == typeXFile) && stringLen)
				{	CEquStr(tempPath, stringP);
					if NOT(err = BAPI_RealPath(api_data, tempPath, true))
					{	if NOT(err = _GetMacSpec(tempPath, &fileSpec, false, true))
						{	stringP = (Ptr)&fileSpec;
							stringLen = sizeof(FSSpec);
						}
					}
				}
				if NOT(err)
				{	if (setPropertyRecP->propertyIndex[0].ind > 0)
						ind = setPropertyRecP->propertyIndex[0].ind;
					else if (*setPropertyRecP->propertyIndex[0].ind_name)
						CStringToNum(setPropertyRecP->propertyIndex[0].ind_name, &ind);
					if (ind > 0)
					{	if (err = QBAPI_SetCell(qbRec.connID, ind, 0, 0, fieldName, stringP, stringLen/*, false*/))
							err = XError(kBAPI_ClassError, err);
					}
					else
						err = XError(kBAPI_Error, Err_InvalidArrayIndex);
				}
			}
			else
				err = XError(kBAPI_ClassError, err);
			BAPI_ReleaseBlock(&ref);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	QuickBase_GetErrMessage(Biferno_ParamBlockPtr pbPtr)
{
GetErrMessageRec		*getErrDescrRecP = &pbPtr->param.getErrMessageRec;
long					tErr;

	tErr = getErrDescrRecP->err;
	if (tErr < 0)		// QBAPI could return a MacOS system error
		CEquStr(getErrDescrRecP->errMessage, "");
	else if (tErr >= QBAPI_Err_ServerExpired)
		CEquStr(getErrDescrRecP->errMessage, gQBAPIErrorsStr[tErr - QBAPI_Err_ServerExpired]);

return noErr;
}

//===========================================================================================
static XErr	QuickBase_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
long			tLen, strLen;
QuickBaseRec	qbRec;
CStr255			cStr;
PrimitiveUnion	*param_d;

	if (typeCast->resultWanted == kCString)
	{	tLen = sizeof(QuickBaseRec);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&qbRec, &tLen, 0, nil))
		{	param_d = &typeCast->result;
			if (param_d->text.variant == kForConstructor)
				CEquStr(cStr, "-");
			else
				PascalToC(qbRec.path, cStr);
			strLen = CLen(cStr);
			if (param_d->text.stringP)
			{	if (param_d->text.stringMaxStorage >= (strLen + 1))
				{	CopyBlock(param_d->text.stringP, cStr, strLen);
					param_d->text.stringP[strLen] = 0;
					param_d->text.stringLen = strLen;
				}
				else
				{	CopyBlock(param_d->text.stringP, cStr, param_d->text.stringMaxStorage - 1);
					param_d->text.stringP[param_d->text.stringMaxStorage - 1] = 0;
					param_d->text.stringLen = strLen;
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
				}
			}
			else
				param_d->text.stringLen = strLen;
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);
	

return err;
}

#pragma mark-
#pragma export on
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr, err2= noErr;
long	isReady;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft QBAPI (MacOS9 only)");
			CEquStr(pbPtr->param.registerRec.pluginVersionStr, VERSION);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			quickbaseClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.fixedSize = true;
			pbPtr->param.registerRec.dynamic = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void qb(string databasePath)");
			break;
		case kInit:
			err = QuickBase_Init(pbPtr);
			break;
		case kShutDown:
			err = QuickBase_ShutDown(pbPtr);
			if (err2 && NOT(err))
				err = err2;
			break;
		case kRun:
			_TryInit(pbPtr->api_data);
			if (gsInited)
			{	if (err = QBAPI_IsServerReady(&isReady))
					err = XError(kBAPI_ClassError, err);
				else	
				{	while NOT(isReady)
					{	if (err = QBAPI_IsServerReady(&isReady))
						{	err = XError(kBAPI_ClassError, err);
							break;
						}
						XYield(nil);
					}
				}
			}
			break;
		case kExit:
		/*#ifdef MEM_DEBUG
			if ((*pbPtr->plugin_run_dataP))
				BAPI_Log(pbPtr->api_data, "QuickBase leaking");
		#endif*/
			break;
		case kConstructor:
		case kTypeCast:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_Constructor(pbPtr, false);
			break;
		case kClone:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_Constructor(pbPtr, true);
			break;
		case kDestructor:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_ExecuteMethod(pbPtr);
			break;
		case kGetProperty:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if (pbPtr->param.getPropertyRec.isConstant)
				err = QuickBase_GetProperty(pbPtr);
			else if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_GetProperty(pbPtr);
			break;
		case kSetProperty:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_SetProperty(pbPtr);
			break;
		case kPrimitive:
			/*if (pbPtr->plugin_run_error)
				err = pbPtr->plugin_run_error;
			else */
			if NOT(err = _TryInit(pbPtr->api_data))
				err = QuickBase_TypeCast(pbPtr);
			break;
		case kGetErrMessage:
			err = QuickBase_GetErrMessage(pbPtr);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

/*if ((err >= QBAPI_Err_ServerExpired) && (err <= QBAPI_Err_MaxRequestReached))
{	CEquStr(pbPtr->error, gQBAPIErrorsStr[err - 10000]);
	err = OFFSET_ERR + err;
}
*/

return err;
}
#pragma export off
//==================================
XErr Initialize(CFragInitBlockPtr ibp)
{
#pragma unused(ibp)

	if (ibp->fragLocator.where == kDataForkCFragLocator)
		_GetCFullPath(ibp->fragLocator.u.onDisk.fileSpec, gsPath);

return noErr;
}

//==================================
void Terminate(void)
{
}

