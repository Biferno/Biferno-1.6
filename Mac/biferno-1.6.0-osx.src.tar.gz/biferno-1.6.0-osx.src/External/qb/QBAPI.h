//QBAPI.h

/*
QuickBase API Interface, version 1.0
Copyright �1997, Tabasoft Sas All rights reserved.

Public interface between QBAPI client applications and QBEngine
*/

#ifndef __QBAPI__
#define __QBAPI__

// VERSION
#ifdef OLD_QBENGINE_ACCEPTED_ONLY_0100
	#define QBAPI_CURRENT_VERSION	0x0100	// Old QBEngine (before version handling (3/4/2002) accepted only (QBAPI_CURRENT_VERSION == 0x0100)
#else
	#define QBAPI_CURRENT_VERSION	0x0101	// Do NOT modify this value
#endif

/*������������� Costants ������������*/
	//=== Field Types
	#define 	typeTxt			1
	#define 	typeNum			2
	#define 	typeData		3
	#define 	typeXFile		4
	#define 	typeBool		5
	#define 	typeListIndx	6

	#define 	typeShortText	16
	#define 	typeLongText	32
	#define 	typeComprText	64

	#define 	typeIntNum		16
	#define 	typeLongNum		32
	#define 	typeRealNum		64

	#define 	typeGenericDoc	0
	#define 	typeGraphDoc	16
	#define 	typeTextDoc		32
	
	#define		kQBAPIMaxCellLength	4096
	
	#define		LOW_FIELD_TYPE(x)			(x & 0xF)

	//== Find type of a search line:
	enum {
		kEqual = 1,
		kBegin,
		kEnd,
		kMajor,
		kMajorEqu,
		kMinor,
		kMinorEqu,
		kMenuSep,
		kContainStr,
		kContainWordBegin,
		kContainWordEnd,
		kContainWordExact
		};

	//== Find doc mode of a search line: 
	enum {
		kNameMode = 0,
		kInTextMode,
		kFileSizeMode,
		kCreatDateMode,
		kModifDateMode,
		kFileTypeMode,
		kFileCreatMode,
		kRelevance
		};

	//=== Find modes of a search line: 
	#define 	kNormalMode	0
	#define 	kNotMode	1

	//=== Find operats of a search line: 
	#define 	kAll		-1
	#define 	kAnd		1
	#define 	kOr			2

	//=== Find groups of a search line: 
	#define 	kNoPar		0
	#define 	kOpenPar	1
	#define 	kClosePar	-1


	//=== Sort modes:
	#define 	kAsc	-1
	#define 	kDesc	1

	//=== Doc sort modes:
	enum {				// doc sort mode
		kSortNormal = 0,
		kSortNameM,
		kSortFileSizeM,
		kSortCreatDateM,
		kSortModifDateM,
		kSortFileTypeM,
		kSortFileCreatM,
		kSortRelevancyM
		};

	//== File info
	enum {
			FILESIZE = 1,	
			CREATDATE,
			MODIFDATE,
			FILETYPE,
			FILECREAT,
			RELEV
		};

	//== IMPORT MODES
	enum {
		kAdd = 1,
		kOverwrite,
		kMatch,
		kTotalReplace
		};

/*������������� Resul Codes ������������*/
	enum {
		//tasks	
			QBAPI_Err_ServerExpired = 10000,	// The server is expired, contact Tabasoft for a full version
			QBAPI_Err_ServerBusy,				// Too many simultaneous connection to QBAServer
			QBAPI_Err_BadTaskRef,				// A non valid connection ID was passed to this QBAPI function
		//cell identification
			QBAPI_Err_BadRecNum,				// This recNum is a not valid number
			QBAPI_Err_BadRecID,					// This recID doesn't exist in this DB
			QBAPI_Err_BadFieldDef,				// Bad field number or field name
			QBAPI_Err_RecIDOutOfRange,			// This greater recID of the DB is smaller than the one passed
		//Connect
			QBAPI_Err_DBNotAvailable,			// This DB is not available
			QBAPI_Err_ConnectFailed,			// QBServer can't swap to this DB (internal error)
		//Select
			QBAPI_Err_BadOperat,				// Invalid operat for search
			QBAPI_Err_BadGroup,					// Invalid group for search
			QBAPI_Err_TooManyLinesSelect,		// Search lines exceeds maximum (42)
			QBAPI_Err_DictionaryNotFound,		// Content search didn't find the full text dictionary
		//Modifying db
			QBAPI_Err_DBOnlyRead,				// Attempt to modify a DB opened with only read permission
			QBAPI_Err_DBLocked,					// Attempt to modify a DB on a locked volume
			QBAPI_Err_DBTooManyRecords,			// Records exceeds maximum (16.777.215)
			QBAPI_Err_BadIndexes,				// Bad field indexes (internal error)
			QBAPI_Err_BadStringFormat,			// String not valid for this field
			QBAPI_Err_BadNumFormat,				// Number not valid for this field 
			QBAPI_Err_BadDateFormat,			// Date not valid for this field 
			QBAPI_Err_BadInput,					// Buffer not valid for this field 
			QBAPI_Err_BadFieldType,				// Unknown field type
			QBAPI_Err_BadFileTypeForThisField,	// This field can't link this type of files
			QBAPI_Err_StringTooLong,			// String too long for this field
			QBAPI_Err_FieldNotUnique,			// This field must be unique
			QBAPI_Err_FieldIsMandatory,			// This field must be mandatory
			QBAPI_Err_FieldNotPresent,			// This field must be present
			QBAPI_Err_RecordOutOfSelection,		// This recNum is out of the current selection
			QBAPI_Err_DBisEmpty,				// This DB is empty
		//Accessing XDoc fields
			QBAPI_Err_XDocVolumeNotAvailable,	// The XDoc volume was not found
			QBAPI_Err_XDocDirectoryNotFound,	// The XDoc directory was not found
			QBAPI_Err_FieldTypeIsNotXDoc,		// Attempt to get a file from a non-xdoc field
		//Generic
			QBAPI_Err_QBServerNotAvailable,		// The QBServer is not up
			QBAPI_Err_CantFindQBEngine,			// The shared library "QBEngine" can't be found
			QBAPI_Err_TaskIDBadNumber,			// Bad task (internal error)
			QBAPI_Err_UserDisconnected,			// User has been connected
			QBAPI_Err_TaskNotUsed,				// Task not in use
			QBAPI_Err_ImageLibNotAvailable,		// The shared library "ImageLib" can't be found
			QBAPI_Err_QBAPIVersionTooOld,		// QBAPI_FrameworkPPC.lib is too old for this QBEngine
			QBAPI_Err_QBEngineVersionTooOld,	// QBEngine is too old for this QBAPI_FrameworkPPC.lib
			QBAPI_Err_DictStopWordFileNotFound,	// Couldn't find the Stop Word File
			QBAPI_Err_TaskIsNotConnected,		// QBEngine doesn't know this QBAPI task (low level)
			QBAPI_Err_MaxRequestReached
			};

/*������������� Data types ������������*/
	//== Import/Export CallBacks
	typedef Boolean (*ExportCallBack)(long record, void* userData);
	typedef Boolean (*ImportCallBack)(long record, void* userData);
	
	typedef OSErr (*YieldCallBack)(long ref, long userData);

	//== Optimize Dict CallBack
	typedef int (*DictOptimCallBackProc)(long cnt, long userPar);

	//== Sort rec
	typedef struct QBAPI_SortRec
		{		
		Str31	fldName;
		short	fldNum;
		short	sortType;
		short	docSortMode;
		short	caseSense;
		} QBAPI_SortRec, *QBAPI_SortRecP;

	typedef struct
		{
		Boolean		addUpCase;		// includi parole interamente maiuscole anche se < minWordLen
		Byte		minWordLen;		// includi parole maggiori o uguali
		Boolean		addCompName;	// includi parole titoletto composte (es. Di Pietro)
		Byte		minWordFreq;			// unused
		Boolean		addNumber;		// sola lettura
		Boolean		skipHTML;		// salta HTML (tutto ci� che � racchiuso fra '<' a '>')
		Boolean		caseSense;
		Boolean		reserved;
		}QBAPI_DictOption, *QBAPI_DictOptionP;
		
	//== Field Info Rec
	typedef struct {
					long	min;
					long	max;
					long	tot;
					double	average;
					long	miss;
					} QBAPI_InfTextRec;
	typedef struct {
					double	min;
					double	max;
					double	tot;
					double	average;
					long	miss;
					} QBAPI_InfNumRec;
	typedef struct {
					long	totTrue;
					long	totFalse;
					} QBAPI_InfBoolRec;
	typedef struct {
					long			infoCount;
					OSType			fType;
					unsigned long	fileCount;
					unsigned long	duplCount;
					unsigned long	thumbCount;
					double	bytesCount;
					} QBAPI_InfXFileRec;

	typedef struct {
					long	fldType;
					union
						{
							QBAPI_InfTextRec		infTextRec;
							QBAPI_InfNumRec			infNumRec;
							QBAPI_InfBoolRec		infBoolRec;
							QBAPI_InfXFileRec		infXFileRec;
						}u;
					} QBAPI_FldInfo, *QBAPI_FldInfoP, **QBAPI_FldInfoH;

/*������������� Funcions ������������*/
	//1) Initialize and Terminate
	OSErr QBAPI_Init(long maxConn, StringPtr fileLogName, long *logRef, void* (*MyOSAlloc)(long, long), YieldCallBack yieldProc, long myUserData);
	OSErr 	QBAPI_End(void);
	OSErr 	QBAPI_EndDispose(void);

	//2) Connect/Disconnect to a db
	OSErr	QBAPI_Disconnect(long connectID);
	OSErr	QBAPI_Connect(long *connectID, StringPtr dbPath, long timeout, long *totalRecs, long *totalRecID, StringPtr message);
	OSErr	QBAPI_CloneTask(long *refIDP, long refIDToClone);

	//3) General info
	OSErr 	QBAPI_GetInfo(short *curConnections, short *maxConnections, long *totConnections);
	OSErr 	QBAPI_CheckQBServer(void);
	OSErr 	QBAPI_ResetLogFile(long refNum);

	//4) Selecting and sorting records in a DB
	OSErr	QBAPI_AddSearchLine(long connID, StringPtr keyStr, short fldNum, StringPtr fldName, short findType, short operat, short group, short findMode, short findDocMode);
	OSErr	QBAPI_ModifySearchLineGroup(long connID, long lineID, short group);
	OSErr	QBAPI_Select(long connID, long *recFoundP, StringPtr keyStrErr);
	OSErr	QBAPI_SelectDistinct(long connID, long matchFields, QBAPI_SortRec *sortArray);
	OSErr	QBAPI_SelectAll(long connID, long *recFound);
	OSErr 	QBAPI_SelectRel(long connID, long *recFound, long fldNum, short findType, long operat, StringPtr keyStrErr, long findMode, long findDocMode,long connID2, long fldNum2);
	OSErr	QBAPI_Sort(long connID, long fldsToSort, QBAPI_SortRec *sortArray);

	//5) Get cell data from a DB
	OSErr	QBAPI_GetCell(long connID, long *fldNum, Str31 fldName, long recNum, short format, StringPtr cellStr, long *fldType, Boolean *empty);
	OSErr	QBAPI_GetCellFromRecID(long connID, long *fldNum, Str31 fldName, long recID, short format, StringPtr cellStr, long *fldType, Boolean *empty);
	OSErr	QBAPI_GetValue(long connID, short fldNum, long recNum, register Ptr valuePtr, long *fldType);
	OSErr	QBAPI_GetValueFromRecID(long connID, short fldNum, long recID, register Ptr value, long *fldType);
	OSErr	QBAPI_GetDateTimeRec(long connID, short fldNum, long recNum, DateTimeRec *dateRec);
	OSErr	QBAPI_GetDateTimeRecFromRecID(long connID, short fldNum, long recID, DateTimeRec *dateRec);
	OSErr	QBAPI_GetXFile(long userData, long connID, short fldNum, long recNum, Handle *dataH, long *len, OSType *fileType, void* (*myAllocProc)(long, long), void (*myDisposeProc)(long, void*), OSErr (*myProgressProc)(long, long), long sleep);
	OSErr	QBAPI_GetXFileFromRecID(long userData, long connID, short fldNum, long recID, Handle *dataH, long *len, OSType *fileType, void* (*myAllocProc)(long, long), void (*myDisposeProc)(long, void*), OSErr (*myProgressProc)(long, long), long sleep);

	//6) modifying a DB
	OSErr	QBAPI_AddRecord(long connID, long *newRecID);
	OSErr	QBAPI_DeleteRecord(long connID, long recNum, long recID);
	OSErr	QBAPI_SetCellExt(long refID, long recNum, long recID, short fldNum, StringPtr fldName, Ptr dataP, long len, Boolean dontIndex);
	#define	QBAPI_SetCell(refID, recNum, recID, fldNum, fldName, dataP, len)	QBAPI_SetCellExt(refID, recNum, recID, fldNum, fldName, dataP, len, false)


	//7) Get info on a record
	OSErr	QBAPI_GetRecID(long connID, long recNum, long *recID);
	OSErr	QBAPI_GetRecNum(long connID, long recID, long *recNum);

	//8) Get info on a field
	OSErr	QBAPI_GetFieldInfo(long connID, long fldNum, long osTypeIdx, OSType type, QBAPI_FldInfoP fldInfoP);
	OSErr	QBAPI_GetFieldType(long connID, long fldNum, StringPtr fldName, long *fldType);
	OSErr	QBAPI_GetFieldNumber(long connID, StringPtr fldName, long *fdlNum);
	OSErr	QBAPI_GetFieldName(long connID, short fldNum, StringPtr fldName, long *fldType);
	OSErr	QBAPI_GetNamesOfAllFields(long connID, Handle *titlesHand, long *fldsNum);
	OSErr	QBAPI_GetFieldNote(long refID, long fldNum, StringPtr fldName, StringPtr noteStr);
	OSErr	QBAPI_SetFieldNote(long refID, short fldNum, StringPtr fldName, Ptr dataP, long len);

	//9) Get info on a db
	OSErr	QBAPI_GetCurRecs(long connID, long *curRecs);
	OSErr	QBAPI_GetTotRecs(long connID, long *totRecs);
	OSErr	QBAPI_GetTotFields(long connID, long *totFlds);

	//10) Save
	OSErr	QBAPI_Save(long connID);

	//11) Import
	OSErr	QBAPI_ImportData(long connID, FSSpec *fileSpec, Byte recSep, Byte fldSep, Byte totFields,
				long mode, long fromRec, long matchFld, Byte *fldOrderList, ImportCallBack callBack, 
				void *callParam, long *totRecsImported);

	//12) Export
	OSErr	QBAPI_ExportData(long connID, FSSpec *fileSpecP, Byte recSep, Byte fldSep, Byte totFields,
				Boolean exportText, Boolean overwrite, Byte *fldOrderList, ExportCallBack callBack,
				void *callParamPtr, long *totRecsExported);

	//13) Utils
	OSErr	QBAPI_GetDBOpenPaths(long *numDBOpenP, Handle *dbOpenHandPtr);
	OSErr	QBAPI_GetDBName(long connID, StringPtr dbPath);
	OSErr	QBAPI_GetFSSpecFromString(StringPtr cellStr, FSSpec *spec, long *thumbOffset, long *fileType);
	OSErr	QBAPI_GetThumbOffsetFromString(StringPtr cellStr, long *thumbOffseP);
	long	QBAPI_GetFileInfo(StringPtr cellStr, long which);
	OSErr	QBAPI_GetThumb(long connID, long thumbOffset, Handle *thumbHandle, long *lengthOfThumb);

	OSErr	QBAPI_OptimizeDBExt(long refID, DictOptimCallBackProc callBack, long param);
	#define	QBAPI_OptimizeDB(refID, callBack)	QBAPI_OptimizeDBExt(refID, callBack, 0L)

	OSErr	QBAPI_HiliteWordInText(long refID, long sourceFieldNum, StringPtr sourceFieldName, Handle fileH, long fileLen, StringPtr findStr, Handle *fileHandleP, long *fileLenP);
	OSErr 	QBAPI_GetRoot(StringPtr rootPath);
	
	// Join
	OSErr	QBAPI_JoinNew(long *connIDsPtr, long totDB, Handle *joinRefHandleP);
	OSErr	QBAPI_JoinDispose(Handle joinRefHandle);
	OSErr	QBAPI_JoinSort(Handle joinRefHandle, long fldsToSort, QBAPI_SortRec *pisortRecP);
	OSErr	QBAPI_JoinGetCell(Handle joinRefHandle, long *fldNumP, Str31 fldName, long index, short format, StringPtr cellStr, long *fldTypeP, Boolean *emptyP);
	OSErr	QBAPI_JoinGetRecID(Handle joinRefHandle, long index, long *recIDP);
	OSErr	QBAPI_JoinGetXFile(long userData, Handle joinRefHandle, short fldNum, long index, Handle *dataH, long *len, OSType *fileType, void* (*myAllocProc)(long, long), void (*myDisposeProc)(long, void*), OSErr (*myProgressProc)(long, long), long sleep);
	OSErr	QBAPI_JoinGetDBName(Handle joinRefH, long index, StringPtr dbPath);
	OSErr	QBAPI_JoinGetFieldName(Handle joinRefH, long index, short fldNum, StringPtr cellStr, long *fldTypeP);
	OSErr	QBAPI_JoinGetFieldNumber(Handle joinRefH, long index, StringPtr fldName, long *fdlNumP);
	OSErr	QBAPI_JoinGetFieldType(Handle joinRefH, long index, long fldNum, StringPtr fldName, long *fldTypeP);

	// Debugging
	OSErr	QBAPI_IsServerReady(long *isReadyP);
	OSErr	QBAPI_IsSkipWord(long refID, StringPtr fieldName, StringPtr word, Boolean *isSkip);
	OSErr	QBAPI_DeleteDict(long refID, int fldNum, StringPtr fldName, Boolean reCreateEmpty);
	OSErr	QBAPI_CreateDict(long refID, int fldNum, StringPtr fldName, StringPtr dictName,
							FSSpec *stopWordSpecP, QBAPI_DictOptionP dictOptionP, Boolean reIndexFld,
							YieldCallBack YieldProc, long userParam);
	
	//void	QBAPI_CheckConnID(long index);
	//void	QBAPI_DebugCheckConnectionID(long index, long id, long userData);
#endif