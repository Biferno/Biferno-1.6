/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: regexp_bfr.c,v 1.12 2006-05-30 14:53:14 valfer Exp $
	|______________________________________________________________________________
*/
/** @file
* 	Regular expression class implementation for Biferno
*
*	This file implements regular expression support for Biferno using via the regexp class.
*	The regexp class implements an interface towards the GNU regexp library
*
*	Copyright (c) 2003, Tabasoft Sas
*
*	$RCSfile: regexp_bfr.c,v $
*	$Date: 2006-05-30 14:53:14 $ 
*	$Revision: 1.12 $
*
*	Valerio e Vincenzo Ferrucci
*/

#include "BifernoAPI.h"
#include "BfrVersion.h"
#include <regex.h>

static unsigned long gsApiVersion;
static long gsRegexClassID;

#define TOT_METHODS 1
enum {
  kMatch = 1
};

#define TOT_PROPERTIES 4
enum {
  knotbol = 1,
  knoteol,
  ksoff,
  keoff
};

#define TOT_COSTANTS 5
enum {
  kdefaultvalue = REG_EXTENDED+REG_NEWLINE,
  kextended = REG_EXTENDED,
  kicase = REG_ICASE,
  knosub= REG_NOSUB,
  knewline = REG_NEWLINE
};

#define	START_ERR	100
enum {
  ErrRegExp = START_ERR
};

static CStr63	gsRegExpErrorsStr[] = 
  {	
    "ErrRegExp"
  };
#define	TOT_ERRORS	1

typedef struct {
  Boolean notbol;
  Boolean noteol;
  Boolean matchdone;
  Byte pad;
  CStr255 exp;
  long flags;
  long noffsets;
  regex_t compiled;
  regmatch_t match[1];
} BfrRegexp;

//#define DEBUG
//===========================================================================================
static XErr	RegExp_Init(Biferno_ParamBlockPtr pbPtr)
{
long api_data = pbPtr->api_data;
XErr	err = noErr;
BAPI_MemberRecord	regexpMethods[TOT_METHODS] = 
  {	
    "Match",		kMatch,		"boolean Match(string text)"
  };

BAPI_MemberRecord	regexpProperty[TOT_PROPERTIES] = 
   {	"notbol", 			knotbol,	"boolean",
	"noteol", 			knoteol,	"boolean",
	"soff", 			ksoff,		"int[]",
	"eoff", 			keoff,		"int[]"
   };

BAPI_MemberRecord	regexpCostants[TOT_COSTANTS] = 
   {	"defaultvalue", 	kdefaultvalue,	"int",
	"extended", 		kextended,	"int",
	"icase", 		kicase,		"int",
	"nosub", 		knosub,		"int",
	"newline", 		knewline,    	"int"
   };

if (err = BAPI_NewProperties(api_data, gsRegexClassID, regexpProperty, TOT_PROPERTIES, nil))
   return err;
if (err = BAPI_NewMethods(api_data, gsRegexClassID, regexpMethods, TOT_METHODS, nil))
   return err;
if (err = BAPI_NewConstants(api_data, gsRegexClassID, regexpCostants, TOT_COSTANTS, nil))
   return err;
err = BAPI_RegisterErrors(api_data, gsRegexClassID, START_ERR, gsRegExpErrorsStr, TOT_ERRORS);

return err;
}
//===========================================================================================
static XErr	RegExp_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
	XErr			err = noErr;	//, pathError = noErr;
  ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
  long			api_data = pbPtr->api_data;
  int res;
  BfrRegexp		*regexpRecP;
  BlockRef block;
  ParameterRec	*paramVarsP;
  //Boolean isAlias = false, isFolder;
  regex_t compiled;
  CStr255 exp;
  long flags;
  long tlen;
  
  //ClearBlock(&regexpRec, sizeof(BfrRegexp));
  if (clone)
    {	
      err = XError(kBAPI_Error, Err_IllegalOperation); 
    }
  else
    {	
      paramVarsP = constructorRecP->varRecsP;
      if not (err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, exp, nil, 256, kImplicitTypeCast))
	{
	  if not (err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &flags, kImplicitTypeCast))
	    {
	      res = regcomp(&compiled, exp, (int) flags);
	      if (res)
		{
		  err = XError(kBAPI_ClassError, ErrRegExp);
		  regerror (res, &compiled, pbPtr->error, 256);
		}
	      else
		{
#ifdef DEBUG 
	      printf("exp: %s-flags compile:%d -Nsub: %d\n", exp, flags,compiled.re_nsub); 
#endif
		  tlen = sizeof(BfrRegexp)+compiled.re_nsub*sizeof(regmatch_t);
		  if (block = NewBlockClear(tlen, &err, (Ptr*) &regexpRecP))
		    {
		      regexpRecP->notbol = true;
		      regexpRecP->noteol = true;
		      regexpRecP->matchdone = false;
		      CEquStr(regexpRecP->exp, exp);
		      regexpRecP->flags = flags;
		      regexpRecP->noffsets = 0;
		      regexpRecP->compiled =  compiled;
		      err = BAPI_BufferToObj(api_data, (Ptr) regexpRecP, tlen, gsRegexClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		      DisposeBlock(&block);
		    }
		}
	    }
	}
    }
  return err;
}

//===========================================================================================
static XErr	RegExp_Destructor(Biferno_ParamBlockPtr pbPtr)
{
  XErr			err = noErr;
  DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
  BfrRegexp		regexpRec;
  long			objLen;
  //Boolean			isDir;

  objLen = sizeof(BfrRegexp);
  if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&regexpRec, &objLen, 0, nil))
    {	
      if (objLen)
      {	
	regfree(&regexpRec.compiled);
      }
    }
  return err;
}
//===========================================================================================

static XErr _GetOffsets(BfrRegexp *regexpRecP, GetPropertyRec *getPropertyRecP, long api_data, Boolean endoffset, Biferno_ParamBlockPtr pbPtr)
{
  XErr err = noErr;
  int arrayindex;
  ObjRef *resP = &getPropertyRecP->resultObjRef;
  
/* #ifdef DEBUG  */
/*   printf("init: ind=%d-so=%d-nmatch=%dmatchdone=%dpdim=%d\n", getPropertyRecP->propertyIndex[0].ind, regexpRecP->match[getPropertyRecP->propertyIndex[0].ind].rm_so, regexpRecP->nmatch, regexpRecP->matchdone, getPropertyRecP->propertyDim ); */
/* #endif */

  if (regexpRecP->matchdone)
    {
      switch (getPropertyRecP->propertyDim)
	{
	case 1:
	  arrayindex = getPropertyRecP->propertyIndex[0].ind;
#ifdef DEBUG 
	  printf("aindex%d-%d-%d\n", arrayindex, regexpRecP->match[arrayindex].rm_so, regexpRecP->noffsets);
#endif
	  if ((arrayindex > 0) && (arrayindex <= regexpRecP->noffsets))
	    {
	      arrayindex--;		// C-arrays are 0-based
	      if (endoffset)
		err = BAPI_IntToObj(api_data, regexpRecP->match[arrayindex].rm_eo+1, resP);
	      else
		err = BAPI_IntToObj(api_data, regexpRecP->match[arrayindex].rm_so+1, resP);
	    }
	  else
	    err = XError(kBAPI_Error, Err_OutOfBoundary);
	  break;
	
	case 0:
	  if NOT(err = BAPI_ArrayToObj(api_data, true, nil, 0, nil, nil, resP))
	    { 
	      int i, dim = regexpRecP->noffsets;
	      ObjRef tmpObj;
	      for (i=0; i<dim && NOT(err); i++)
		{
		  BAPI_InvalObjRef(api_data, &tmpObj);
		  if (endoffset)
		    err = BAPI_IntToObj(api_data, regexpRecP->match[i].rm_eo+1, &tmpObj);
		  else
		    err = BAPI_IntToObj(api_data, regexpRecP->match[i].rm_so+1, &tmpObj);
		  if NOT (err)
			   err = BAPI_ArrayAddElement(api_data, resP, nil, &tmpObj);
		}
	    }
	  break;
	
	default:
	  err = XError(kBAPI_Error, Err_IllegalOperation);
	  break;
	}
    }
  else
    {
      CEquStr(pbPtr->error, "Match method must be called before retrieving match offsets");
      err = XError(kBAPI_Error, Err_IllegalOperation);
    }
  return err;
}
//===========================================================================================

static XErr	RegExp_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
  GetPropertyRec	*getPropertyRecP = &pbPtr->param.getPropertyRec;
  XErr			err = noErr;
  BfrRegexp		*regexpRecP;
  CStr255 buffer;
  BlockRef ref;
  long regexpRecSize;

  long			/*strpLen,*/ tLen, /*eof, */api_data = pbPtr->api_data;
  //CStr255		tempStr;
  //char			*strP;

  if (getPropertyRecP->isConstant)
    err = BAPI_IntToObj(api_data, getPropertyRecP->propertyID, &getPropertyRecP->resultObjRef);
  else if (BAPI_IsObjRefValid(api_data, &getPropertyRecP->objRef))
    {	
      tLen = sizeof(BfrRegexp);
      if NOT(err = BAPI_GetObjBlock(pbPtr->api_data, &getPropertyRecP->objRef, buffer, (Ptr*) &regexpRecP, &regexpRecSize, &ref))
	{      
	  switch(getPropertyRecP->propertyID)
	  {
	  case knotbol:
	    err = BAPI_BooleanToObj(api_data, regexpRecP->notbol, &getPropertyRecP->resultObjRef);
	    break;
	  case knoteol:
	    err = BAPI_BooleanToObj(api_data, regexpRecP->noteol, &getPropertyRecP->resultObjRef);
	    break;
	  case ksoff:
	    err = _GetOffsets(regexpRecP, getPropertyRecP, api_data, false, pbPtr);
	    break;
	  case keoff:
	    err = _GetOffsets(regexpRecP, getPropertyRecP, api_data, true, pbPtr);
	    break;
	  default:
	    err = XError(kBAPI_Error, Err_NoSuchProperty);
	    break;
	  }
	  BAPI_ReleaseBlock(&ref);
	}
    }
  else
    err = XError(kBAPI_Error, Err_NoSuchProperty);

  return err;
}

//===========================================================================================
static XErr	RegExp_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
  SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
  XErr			err = noErr;
  long			api_data = pbPtr->api_data;
  BfrRegexp		*regexpRecP;
  CStr255 buffer;
  BlockRef ref;
  long regexpRecSize;
  
    if NOT(err = BAPI_GetObjBlock(pbPtr->api_data, &setPropertyRecP->objRef, buffer, (Ptr*) &regexpRecP, &regexpRecSize, &ref));
    {	
      switch(setPropertyRecP->propertyID)
      {
      case knotbol:
	err = BAPI_ObjToBoolean(api_data, &setPropertyRecP->value, &regexpRecP->notbol, kImplicitTypeCast);
	if not(err)
		err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)regexpRecP, regexpRecSize);
	break;
      case knoteol:
	err = BAPI_ObjToBoolean(api_data, &setPropertyRecP->value, &regexpRecP->noteol, kImplicitTypeCast);
	if not(err)
		err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)regexpRecP, regexpRecSize);
	break;
      case ksoff:
      case keoff:
	err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
	break;
      default:
	err = XError(kBAPI_Error, Err_NoSuchProperty);
	break;
      }
      BAPI_ReleaseBlock(&ref);
    }
	
  return err;
}
//===========================================================================================
static XErr	RegExp_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
  XErr			err = noErr;
  PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
  long		        strLen;
  char			*strP, *p;
  PrimitiveUnion	*param_d;
  BfrRegexp		*regexpRecP;
  CStr255 buffer;
  BlockRef ref;
  long regexpRecSize;

  if (typeCast->resultWanted == kCString)
    {
      if NOT(err = BAPI_GetObjBlock(pbPtr->api_data, &typeCast->objRef, buffer, (Ptr*) &regexpRecP, &regexpRecSize, &ref))
	{	
	param_d = &typeCast->result;
	strP = regexpRecP->exp;
	strLen = CLen(strP);
	p = param_d->text.stringP;
	if (p)
	  {	
	    if (param_d->text.stringMaxStorage >= (strLen+1))
	    {	
	      CopyBlock(p, strP, strLen);
	      p[strLen] = 0;
	      param_d->text.stringLen = strLen;
	    }
	    else
	    {	
	      CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
	      p[param_d->text.stringMaxStorage - 1] = 0;
	      param_d->text.stringLen = strLen;
	      err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
	    }
	  }
	else
	  param_d->text.stringLen = strLen;
	BAPI_ReleaseBlock(&ref);	
	}
    }
  else
    err = XError(kBAPI_Error, Err_IllegalTypeCast);

  return err;
}
//===========================================================================================
static XErr _Match(long api_data, ExecuteMethodRec *exeMethodRecP, BfrRegexp *regexpRec, long regexpRecSize, Biferno_ParamBlockPtr pbPtr)
{
  XErr err = noErr;
  CStr255 buffer;
  char* textP;
  long textlen;
  int res, flags = 0;
  BlockRef block;
  Boolean returnvalue;

  if not (err = BAPI_GetStringBlock(api_data,  &exeMethodRecP->paramVarsP[0].objRef, buffer, &textP, &textlen, &block, kImplicitTypeCast))
    {
      if (regexpRec->notbol)
	flags |= REG_NOTBOL;
      if (regexpRec->noteol)
	flags |= REG_NOTEOL;
#ifdef DEBUG 
      printf("flags exec:%d\n", flags); 
#endif
      res = regexec(&regexpRec->compiled, textP, regexpRec->compiled.re_nsub+1, regexpRec->match, flags);
      switch (res)
	{
	case REG_NOMATCH:
	  regexpRec->matchdone = true;
	  regexpRec->noffsets = 0;
	  returnvalue=false;
	  break;
	case 0:
	  regexpRec->matchdone = true;
	  regexpRec->noffsets = regexpRec->compiled.re_nsub + 1;
	  err = BAPI_ModifyObj(api_data, &exeMethodRecP->objRef, (Ptr)regexpRec, regexpRecSize);
	  returnvalue=true;
	  break;
	default:
	  err = XError(kBAPI_ClassError, ErrRegExp);
	  regerror (res, &regexpRec->compiled, pbPtr->error, 256);
	  break;
	}
      if not(err)
	      if NOT(err = BAPI_ModifyObj(api_data, &exeMethodRecP->objRef, (Ptr)regexpRec, regexpRecSize))
		      err = BAPI_BooleanToObj(api_data, returnvalue, &exeMethodRecP->resultObjRef);
      BAPI_ReleaseBlock(&block);
    }
  return err;
}
//===========================================================================================
static XErr	RegExp_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
  XErr err = noErr;
  ExecuteMethodRec   *exeMethodRecP = &pbPtr->param.executeMethodRec;
  long 		     api_data = pbPtr->api_data;
  BfrRegexp	     *regexpRecP;
  CStr255 buffer;
  BlockRef ref;
  long regexpRecSize;

  err = BAPI_GetObjBlock(pbPtr->api_data, &exeMethodRecP->objRef, buffer, (Ptr*) &regexpRecP, &regexpRecSize, &ref);
  if NOT(err)
    {	
      switch(exeMethodRecP->methodID)
	{	
	case kMatch:
	  err = _Match(api_data, exeMethodRecP, regexpRecP, regexpRecSize, pbPtr);
	  break;
	default:
	  err = XError(kBAPI_Error, Err_NoSuchMethod);
	  break;
	}
      BAPI_ReleaseBlock(&ref);
    }
  return err;
}
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

 switch(message)
   {
   case kRegister:
     pbPtr->param.registerRec.pluginType = kNewClassPlugin;
     CEquStr(pbPtr->param.registerRec.pluginName, "regexp");
     gsApiVersion = pbPtr->param.registerRec.api_version;
     gsRegexClassID = pbPtr->param.registerRec.pluginID;
     pbPtr->param.registerRec.wantDestructor = true;
     pbPtr->param.registerRec.fixedSize = true;
     CEquStr(pbPtr->param.registerRec.constructor, "void regexp (string exp, int flags = defaultvalue)");
     CEquStr(pbPtr->param.registerRec.pluginDescr, "Implements GNU regular expressions for Biferno");
     //BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
     //CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
	 VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
	 if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
		CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
     break;
   case kInit:
     err = RegExp_Init(pbPtr);
     break;
   case kShutDown:
     break;
   case kRun:
     break;
   case kExit:
     break;
   case kConstructor:
     err = RegExp_Constructor(pbPtr, false);
     break;
   case kTypeCast:
   case kClone:
     err = RegExp_Constructor(pbPtr, true);
     break;
   case kDestructor:
     err = RegExp_Destructor(pbPtr);
     break;
   case kExecuteOperation:
     err = XError(kBAPI_Error, Err_IllegalOperation);
     break;
   case kExecuteMethod:
     err = RegExp_ExecuteMethod(pbPtr);
     break;
   case kExecuteFunction:
     break;
   case kGetProperty:
     err = RegExp_GetProperty(pbPtr);
     break;
   case kSetProperty:
     err = RegExp_SetProperty(pbPtr);
     break;
   case kPrimitive:
     err = RegExp_TypeCast(pbPtr);
     break;
   case kGetErrMessage:
     break;
   default:
     err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
     break;
   }

return err;
}
