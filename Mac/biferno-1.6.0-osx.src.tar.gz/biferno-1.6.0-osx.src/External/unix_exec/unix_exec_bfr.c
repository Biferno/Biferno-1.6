/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: unix_exec_bfr.c,v 1.11 2006-05-30 14:53:14 valfer Exp $
	|______________________________________________________________________________
*/


#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"

#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <sysexits.h>
#include <unistd.h>
#include <fcntl.h>

static long				unixExecClassID;


// Method
#define	kBash	1

#define	READ_STEP			1024
#define	MAX_ARGS			128

#if __MACOSX__
	#include <sys/types.h>
	#include <unistd.h>
	#include <stdlib.h>
#endif
#include <pwd.h>
#include <grp.h>
#include <errno.h>
#include <sys/wait.h>

//#define	DEBUG_BASH	1

//===========================================================================================
#ifdef DEBUG_BASH
	static XErr	_my_system(char *command, FILE *debug)
#else
	static XErr	_my_system(char *command)
#endif
{
XErr		err = noErr;
//int			exitcode = 0;
Ptr			arg_array[MAX_ARGS];

	arg_array[0] = "/bin/bash";
	arg_array[1] = "-c";
	arg_array[2] = command;
	arg_array[3] = nil;
	errno = noErr;
#ifdef DEBUG_BASH
	fwrite("execvp\n", 1, 7, debug);
	fflush(debug);
#endif
	if (execvp(arg_array[0], arg_array) < 0)				// if success, will never return
		err = errno;

return err;
}

//===========================================================================================
static XErr	_subread(int fd, Ptr *textP, int *offsetP, BlockRef block, long *nP)
{
int		n;
XErr	err = noErr;

	errno = noErr;
	n = read(fd, (*textP) + (*offsetP), READ_STEP);
	if (n < 0)
	{	if (errno != EAGAIN)
			err = errno;
	}
	else if (n)
	{	(*offsetP) += n;
		if NOT(err = SetBlockSize(block, (*offsetP) + READ_STEP))
			*textP = GetPtr(block);
	}
	*nP = n;
	
return err;
}

//===========================================================================================
static XErr	_read_outputs(int fdOut, int fdErr, BlockRef *outBlockP, BlockRef *errBlockP, long *outLenP, long *errLenP, unsigned long timeout_sec, char *errMessage)
{
XErr			err = noErr;
int				outOffset = 0, errOffset = 0;	//, n;
Ptr				outTextP, errTextP;
//int				res;
fd_set 			rfds;
struct timeval	tv, *tvP;
int				maxFd, retval;
long			readedOut, readedErr;
unsigned long	timeout_ms, start_ms, t;
//Boolean			childExited = false;

	*outBlockP = *errBlockP = 0;
	if NOT(*outBlockP = NewBlock(READ_STEP, &err, &outTextP))
		goto out;
	if NOT(*errBlockP = NewBlock(READ_STEP, &err, &errTextP))
		goto out;
	if (timeout_sec)
	{	timeout_ms = timeout_sec * 1000;
		XGetMilliseconds(&start_ms);
		tvP = &tv;
	}
	else
		tvP = nil;
	if (fdErr > fdOut)
		maxFd = fdErr + 1;
	else
		maxFd = fdOut + 1;
	while NOT(err)
	{	FD_ZERO(&rfds);
		FD_SET(fdOut, &rfds);
		FD_SET(fdErr, &rfds);
		if (tvP)
		{	tvP->tv_sec = timeout_sec;
			tvP->tv_usec = 0;
		}
		errno = noErr;
		retval = select(maxFd, &rfds, NULL, NULL, tvP);
		if (retval > 0)
		{	if (FD_ISSET(fdOut, &rfds))
				err = _subread(fdOut, &outTextP, &outOffset, *outBlockP, &readedOut);
			if (NOT(err) && FD_ISSET(fdErr, &rfds))
				err = _subread(fdErr, &errTextP, &errOffset, *errBlockP, &readedErr);
			if NOT(err)
			{	if (NOT(readedOut) && NOT(readedErr))		// end of files
					break;
				else if (timeout_sec)
				{	XGetMilliseconds(&t);
					if ((t - start_ms) > timeout_ms)
					{	err = XError(kBAPI_Error, Err_ClassError);
						CEquStr(errMessage, "The command didn't complete after the specified timeout");
						break;
					}
				}
			}
			else
				break;
		}
		else if NOT(retval)
		{	err = XError(kBAPI_Error, Err_ClassError);
			CEquStr(errMessage, "The command didn't complete after the specified timeout (select)");
		}
		else
		{	err = errno;
			CEquStr(errMessage, "select returned an error");
		}
	}
	if NOT(err)
	{	SetBlockSize(*outBlockP, outOffset);		// shrink
		*outLenP = outOffset;
		SetBlockSize(*errBlockP, errOffset);		// shrink
		*errLenP = errOffset;
	}

out:
if (err)
{	if (*outBlockP)
		DisposeBlock(outBlockP);
	if (*errBlockP)
		DisposeBlock(errBlockP);
}
return err;
}

//===========================================================================================
static XErr	_call_exec(char *command, unsigned long timeout_sec, Boolean dontWait, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP, int *resultP, char *errMessage)
{
XErr			err = noErr;
//Ptr				textP;
int				fdOut[2]={-1, -1}, fdErr[2]={-1, -1};
pid_t			pid;
int 			/*exitcode,*/ res = 0;
CStr63			msgStr;
#ifdef DEBUG_BASH
	FILE			*debug;
#endif

#ifdef DEBUG_BASH
	debug = fopen("_call_exec.txt", "w");
	fwrite("init\n", 1, 5, debug);
	fflush(debug);
#endif
	if NOT(dontWait)
	{	errno = noErr;
		res = pipe(fdOut);
	}
	if (res < 0)
		err = errno;
	else
	{	if NOT(dontWait)
		{	errno = noErr;
			res = pipe(fdErr);
		}
		if (res < 0)
			err = errno;
		else
		{	errno = noErr;
			if ((pid = fork()) < 0)
				err = errno;
			else if (pid == 0)		// child
			{	if NOT(dontWait)
				{	dup2(fdOut[1], STDOUT_FILENO);		// duplicate (and close) stdOut to fdOut[1]
					dup2(fdErr[1], STDERR_FILENO);		// duplicate (and close) stdErr to fdErr[1]
					close(fdOut[1]);
					close(fdErr[1]);
					close(fdOut[0]);
					close(fdErr[0]);
				}
			#ifdef DEBUG_BASH
				fwrite("_my_system\n", 1, 11, debug);
				fflush(debug);
				err = _my_system(command, debug);
			#else
				err = _my_system(command);
			#endif
				if (err)
				{	if (dontWait)
						sprintf(errMessage, "biferno exec error: %s", strerror(errno));
					else
					{	sprintf(msgStr, "biferno exec error: %s", strerror(errno));
						write(fdErr[1], msgStr, CLen(msgStr));
					}
				}
				exit(err);
			}
			if NOT(err)				// parent
			{	if (dontWait)
				{	if (stdOutP)
						*stdOutP = 0;
					if (stdErrP)
						*stdErrP = 0;
				}
				else
				{	close(fdOut[1]);
					close(fdErr[1]);						
				#ifdef DEBUG_BASH
					fwrite("_read_fd\n", 1, 9, debug);
					fflush(debug);
				#endif
					if NOT(err = _read_outputs(fdOut[0], fdErr[0], stdOutP, stdErrP, stdOutLenP, stdErrLenP, timeout_sec, errMessage))
						waitpid(pid, resultP, 0);	// get the exit code
				#ifdef DEBUG_BASH
					fwrite("_read_fd ok\n", 1, 12, debug);
					fflush(debug);
				#endif				
					close(fdOut[0]);
					close(fdErr[0]);
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_biferno_Exec(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;

#if __UNIX_XLIB__ || __MACOSX__
XErr			err2 = noErr;
CStr255			aCStr;
long			commandLen;
int				result;
Ptr				commandP;
BlockRef		ref;
BlockRef 		stdOutBlock = 0, stdErrBlock = 0;
long 			stdOutLen, stdErrLen;
Boolean			isInit;
long			timeout_sec;
ParameterRec	*parP = exeMethodRecP->paramVarsP;
Boolean 		dontWait;

	if NOT(err = BAPI_GetStringBlock(api_data, &parP[0].objRef, aCStr, &commandP, &commandLen, &ref, kImplicitTypeCast))
	{	if (commandLen)
		{	if NOT(err = BAPI_ObjToInt(api_data, &parP[1].objRef, &timeout_sec, kImplicitTypeCast))
			{	if (timeout_sec < 0)
					dontWait = true;
				else
					dontWait = false;
				if NOT(err = _call_exec(commandP, timeout_sec, dontWait, &stdOutBlock, &stdOutLen, &stdErrBlock, &stdErrLen, &result, pbPtr->error))
				{	if (stdOutBlock)
					{	if (NOT(err = BAPI_IsVariableInitialized(api_data, &parP[2].objRef, &isInit)) && isInit)
							err = BAPI_StringToObj(api_data, GetPtr(stdOutBlock), stdOutLen, &parP[2].objRef);
						DisposeBlock(&stdOutBlock);
					}
					if (stdErrBlock)
					{	if (NOT(err2 = BAPI_IsVariableInitialized(api_data, &parP[3].objRef, &isInit)) && isInit)
							err2 = BAPI_StringToObj(api_data, GetPtr(stdErrBlock), stdErrLen, &parP[3].objRef);
						DisposeBlock(&stdErrBlock);
					}
					if (err2 && NOT(err))
						err = err2;
					if NOT(err)
						err = BAPI_IntToObj(api_data, result, &exeMethodRecP->resultObjRef);
				}
			}
		}
		else
		{	CEquStr(pbPtr->error, "Invalid empty shell command");
			err = XError(kBAPI_Error, Err_ClassError);
		}
		BAPI_ReleaseBlock(&ref);
	}
		
#else
	#if __MWERKS__
	#pragma unused(exeMethodRecP, api_data)
	#endif
	err = XError(kBAPI_Error, Err_NotImplemented);
#endif

return err;
}

#pragma mark-

//===========================================================================================
static XErr	unixExec_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BAPI_MemberRecord	methodRec[1] = {
									"bash", kBash, "static int bash(string command, int timeout_secs=10, string *stdOut, string *stdErr)"
									};
		
	if (err = BAPI_NewMethods(pbPtr->api_data, unixExecClassID, methodRec, 1, "unix"))
		return err;

return err;
}

//===========================================================================================
static XErr	unixExec_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;

	if (exeMethodRecP->methodID == kBash)
		err = _biferno_Exec(pbPtr, exeMethodRecP, pbPtr->api_data);
	else
		err = XError(kBAPI_Error, Err_NoSuchMethod);

return err;
}

#pragma mark-
#pragma export on
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "unixExec");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Implements method bash for class unix");
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			unixExecClassID = pbPtr->param.registerRec.pluginID;
			break;
		case kInit:
			err = unixExec_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kDestructor:
		case kExecuteOperation:
			break;
		case kExecuteMethod:
			err = unixExec_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
		case kGetProperty:
		case kSetProperty:
		case kPrimitive:
			break;
		case kGetErrMessage:
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#pragma export off

