/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: convimage_unix_bfr.c,v 1.5 2006-03-07 10:46:21 valfer Exp $
	|______________________________________________________________________________
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>
#include <time.h>

#include <wand/magick_wand.h>

#include "XLib.h"

#pragma mark-
//===========================================================================================
static XErr	_GetMagickWandError(MagickWand *wand, char *errMsg)
{
char			*description;
ExceptionType	severity;
int				tLen;

	if (errMsg)
	{	description = MagickGetException(wand, &severity);
		tLen = CLen(description);
		if (tLen > 255)
			tLen = 255;
		CopyBlock(errMsg, description, tLen);
		errMsg[tLen] = 0;
		description = (char*)MagickRelinquishMemory(description);
	}
	
return 1;
}   

//===========================================================================================
XErr		BifernoConvertImage(char *srcfile, char *dstfile, int jpegQuality, double scale, int width, int height, int filter, char *errMessage)
{
XErr				err = noErr;
MagickBooleanType	status;
MagickWand			*magick_wand = nil;
unsigned long		xsize, ysize;

	if (errMessage)
		*errMessage = 0;
    
	// Read an image.
	if (magick_wand = NewMagickWand())
	{	status = MagickReadImage(magick_wand, srcfile);
		if (status == MagickFalse)
			err = _GetMagickWandError(magick_wand, errMessage);
		else
		{	// Turn the images into a thumbnail sequence.
			xsize = MagickGetImageWidth(magick_wand);
			ysize = MagickGetImageHeight(magick_wand);
			if NOT(err = GetRescaledDims(xsize, ysize, scale, &width, &height, errMessage))
			{	MagickResetIterator(magick_wand);
				while (MagickNextImage(magick_wand) != MagickFalse)
			    {   if (MagickResizeImage(magick_wand, width, height, filter, 1.0) == MagickFalse)
			    	{	err = _GetMagickWandError(magick_wand, errMessage);
			    		break;
			    	}
				}
				if NOT(err)
				{	// Write the image and destroy it.
					status = MagickWriteImages(magick_wand, dstfile, true);
					if (status == MagickFalse)
						err = _GetMagickWandError(magick_wand, errMessage);
				}
			}
	    }
	    magick_wand = DestroyMagickWand(magick_wand);
	}
	else
	{	err = 1;
		if (errMessage)
			CEquStr(errMessage, "Can't allocate Magick Wand");
	}
	
return err;
}
