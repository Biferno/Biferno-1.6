/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: convimage_bfr.c,v 1.13 2006-03-07 10:46:21 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
//#include	"Helpers.h"

#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"

#if __UNIX_XLIB__
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <errno.h>
	#include <math.h>
	#include <time.h>
	#include <wand/magick_wand.h>
	//#include <wand/drawing_wand.h>
	//#include <wand/pixel_wand.h>
	//#include <wand/pixel_iterator.h>
#else
	typedef enum
	{
	  UndefinedFilter,
	  PointFilter,
	  BoxFilter,
	  TriangleFilter,
	  HermiteFilter,
	  HanningFilter,
	  HammingFilter,
	  BlackmanFilter,
	  GaussianFilter,
	  QuadraticFilter,
	  CubicFilter,
	  CatromFilter,
	  MitchellFilter,
	  LanczosFilter,
	  BesselFilter,
	  SincFilter
	} FilterTypes;
#endif

#ifdef WIN32
	#include "QTML.h"
#endif

#ifdef CONVERTIMAGE_BUILT_IN
	#include 	"StaticClasses.h"
#endif

#include 	"convimage_bfr.h"

enum{
		kConvertImage = 1
		//kDrawPoly
	};
	
#define TOT_METHODS	1

static long	gsImageUtilsClassID, gsStringClassID;

//===========================================================================================
XErr		GetRescaledDims(long xsize, long ysize, double scale, int *widthP, int *heightP, char *errMessage)
{
XErr	err = noErr;
long	width = *widthP, height = *heightP;

	if (scale)
	{	width = (long)(xsize / scale);
		height = (long)(ysize / scale);
	}
	else
	{	if (width <= 0)
		{	if (height > 0)
				width = (long)((double)height * (double)xsize / (double)ysize);
			else
			{	err = 22;
				CEquStr(errMessage, "BifernoConvertImage: invalid width");
			}
		}
		if (height <= 0)
		{	if (width > 0)
				height = (long)((double)width * (double)ysize / (double)xsize);
			else
			{	err = 23;
				CEquStr(errMessage, "BifernoConvertImage: invalid height");
			}
		}
	}
	*heightP = height;
	*widthP = width;
	
return err;
}

/*#define	TOT_POINTS	3
//===========================================================================================
static XErr	_DrawPoly(ExecuteMethodRec *exeMethodRecP, long api_data, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;
#if __UNIX_XLIB__
CStr255			errMessage;
MagickWand		*magick_wand = nil;
DrawingWand		*drawWand;
PointInfo		coordinates[TOT_POINTS];
ExceptionType	severity;
char			*description = nil;
int				tLen;
PixelWand		*pixelWand = nil;
size_t			imLength;
Ptr				imagePtr;

	*errMessage = 0;
	if (drawWand = NewDrawingWand())
	{
		coordinates[0].x = 60;
		coordinates[0].y = 60;

		coordinates[1].x = 200;
		coordinates[1].y = 200;

		coordinates[2].x = 300;
		coordinates[2].y = 100;
		
		DrawPolygon(drawWand, TOT_POINTS, coordinates);
	
		if (magick_wand = NewMagickWand())
		{	pixelWand = NewPixelWand();
			PixelSetColor(pixelWand, "#EEdddd");
			if (MagickNewImage(magick_wand, 350, 250, pixelWand) == MagickTrue)
			{	if (MagickDrawImage(magick_wand, drawWand) == MagickTrue)
				{	//MagickResetIterator(magick_wand);
					MagickSetImageFormat (magick_wand, "GIF");
					imagePtr = MagickGetImageBlob(magick_wand, &imLength);
					err = BAPI_BufferToObj(api_data, imagePtr, imLength, gsStringClassID, false, nil, &exeMethodRecP->resultObjRef);
					//if (MagickWriteImages(magick_wand, "/Library/WebServer/Documents/test.gif", True) == MagickFalse)
					//	description = MagickGetException(magick_wand, &severity);
					magick_wand = DestroyMagickWand(magick_wand);
				}
				else
					description = MagickGetException(magick_wand, &severity);
			}
			else
				description = MagickGetException(magick_wand, &severity);
			DestroyPixelWand(pixelWand);
		}
		drawWand = DestroyDrawingWand(drawWand);
	}
	if (description)
	{	tLen = CLen(description);
		if (tLen > 255)
			tLen = 255;
		CopyBlock(errMessage, description, tLen);
		errMessage[tLen] = 0;
		description = (char*)MagickRelinquishMemory(description);
	}
	//err = BAPI_StringToObj(api_data, errMessage, CLen(errMessage), &exeMethodRecP->resultObjRef);
	
#endif
return err;
}
*/
//===========================================================================================
static XErr	_ConvertImage(ExecuteMethodRec *exeMethodRecP, long api_data, Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
CStr255		errMessage, sourceFilePath, destFilePath;
long		jpegQuality, width, height;
double		scale;
Boolean		overwrite;
long		filter;

	*errMessage = 0;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, sourceFilePath, nil, 255, kImplicitTypeCast))
		goto out;
	if (err = BAPI_RealPath(api_data, sourceFilePath, true))
		goto out;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, destFilePath, nil, 255, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &jpegQuality, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[3].objRef, &scale, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[4].objRef, &width, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[5].objRef, &height, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[6].objRef, &overwrite, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[7].objRef, &filter, kImplicitTypeCast))
		goto out;
	/*if (filter == -1)
		filter = UndefinedFilter;
	else if NOT(filter)
		filter = PointFilter;
	else*/
	if ((filter < UndefinedFilter) || (filter > SincFilter))
	{	err = XError(kBAPI_Error, Err_ClassError);
		CEquStr(pbPtr->error, "BifernoConvertImage: invalid filter");
		goto out;
	}

	err = BAPI_RealPath(api_data, destFilePath, true);
	if (err == XError(kXLibError, ErrXFiles_FileNotFound))
		err = noErr;
	else if NOT(err)
	{	if (overwrite)
		{	if (err = DeleteXFile(destFilePath))
				goto out;
		}
		else
		{	err = XError(kXLibError, ErrXFiles_DuplicatedFile);
			goto out;
		}
	}
	else
		goto out;
	
	if (err = BifernoConvertImage(sourceFilePath, destFilePath, jpegQuality, scale, width, height, filter, errMessage))
		err = noErr;

	BAPI_StringToObj(api_data, errMessage, CLen(errMessage), &exeMethodRecP->resultObjRef);

out:
return err;
}

#if __MWERKS__
	#pragma mark-
#endif
#define	TOT_COSTANTS	16
//===========================================================================================
static XErr	ImageUtils_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			api_data = pbPtr->api_data;

	if (getPropertyRec->isConstant)
		err = BAPI_IntToObj(api_data, getPropertyRec->propertyID, &getPropertyRec->resultObjRef);
	
return err;
}

//===========================================================================================
static XErr	ImageUtils_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BAPI_MemberRecord	convImageMethods[TOT_METHODS] = 
					{	
						"ConvertImage",	kConvertImage,	"static string ConvertImage(string sourceFilePath, string destFilePath, int jpegQuality, double scale, long width, long height, boolean overwrite, int filter)"
						// "DrawPoly",		kDrawPoly,		"static string DrawPoly()"
					};
BAPI_MemberRecord	convImageCostants[TOT_COSTANTS] = 
					{	"UndefinedFilter", 	UndefinedFilter,	"int",
						"PointFilter", 		PointFilter,		"int",
						"BoxFilter", 		BoxFilter,			"int",
						"TriangleFilter", 	TriangleFilter,		"int",
						"HermiteFilter",	HermiteFilter,		"int",
						"HanningFilter", 	HanningFilter,		"int",
						"HammingFilter", 	HammingFilter,		"int",
						"BlackmanFilter",	BlackmanFilter,		"int",
						"GaussianFilter",	GaussianFilter,		"int",
						"QuadraticFilter",	QuadraticFilter,	"int",
						"CubicFilter",		CubicFilter,		"int",
						"CatromFilter",		CatromFilter,		"int",
						"MitchellFilter",	MitchellFilter,		"int",
						"LanczosFilter",	LanczosFilter,		"int",
						"BesselFilter",		BesselFilter,		"int",
						"SincFilter",		SincFilter,			"int"
					};

#ifdef WIN32 
	if (err = InitializeQTML(0))
		return err;
#endif

	if (err = BAPI_NewMethods(pbPtr->api_data, gsImageUtilsClassID, convImageMethods, TOT_METHODS, nil))
		return err;
	if (err = BAPI_NewConstants(pbPtr->api_data, gsImageUtilsClassID, convImageCostants, TOT_COSTANTS, nil))
		return err;
	gsStringClassID = BAPI_ClassIDFromName(pbPtr->api_data, "string", false);

return err;
}

//===========================================================================================
static XErr	ImageUtils_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				totParams = exeMethodRecP->totParams;
long 				api_data = pbPtr->api_data, methodID = exeMethodRecP->methodID;

	//exeMethodRecP->resultObjRef.id = 0;
	//BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
	switch (methodID)
	{	
		case kConvertImage:
			err = _ConvertImage(exeMethodRecP, api_data, pbPtr);
			break;

		/*case kDrawPoly:
			err = _DrawPoly(exeMethodRecP, api_data, pbPtr);
			break;*/

		default:
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
	}

return err;
}

#if __MWERKS__
	#pragma export on
#endif
//===========================================================================================
#ifdef CONVERTIMAGE_BUILT_IN
	XErr	ImageUtils_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#else
	XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#endif
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "imageUtils");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft Convert Image");
			//BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
			//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			gsImageUtilsClassID = pbPtr->param.registerRec.pluginID;
			break;
		case kInit:
			err = ImageUtils_Init(pbPtr);
			break;
		case kShutDown:
		#ifdef WIN32 
			TerminateQTML(); 
		#endif 
			break;
		case kRun:
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = ImageUtils_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = ImageUtils_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			break;

		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
	#pragma export off
#endif

//#endif
