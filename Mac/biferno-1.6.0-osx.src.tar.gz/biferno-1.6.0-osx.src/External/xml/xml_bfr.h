/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: xml_bfr.h,v 1.4 2004-03-23 15:42:11 valfer Exp $
	|______________________________________________________________________________
*/
#ifndef __XML_BFR_H__
	#define __XML_BFR_H__
	
#include <libxml/parser.h>

typedef struct {
				xmlDocPtr		docP;
				long			refCount;	// how many "xml" and "xmlNode" objects point to this doc
				BlockRef		recordBlockRef;
				} XMLRecord;

XErr	xmlNode_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

// Node utils
XErr	CreateXmlNode(long api_data, XMLRecord *xmlRecP, xmlNodePtr nodeP, ObjRef *resultObjRefP, long constructorPrivateData);
XErr	DecrementNode(XMLRecord *xmlRecP);

XErr	XML_EncodeUTF(Byte *stringP, int stringLen, BlockRef *resultStringHP, long *resultLenP);
XErr	XML_DecodeUTF(Byte *stringP, int stringLen, BlockRef *resultStringHP, long *resultLenP);
XErr 	XMLRedirOutput(XErr (*_Func)(long userData), long userData, BlockRef *stdErrP, long *stdErrLenP);

#endif
