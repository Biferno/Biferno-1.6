/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: xml_bfr.c,v 1.18 2006-05-30 14:53:14 valfer Exp $
	|______________________________________________________________________________
*/
#include "BifernoAPI.h"
#include "BfrVersion.h"
#include "xml_bfr.h"

#include <libxml/parser.h>
#include <libxml/catalog.h>
// use default catalog for IDs resolution
#ifndef XML_XML_DEFAULT_CATALOG
#define	XML_XML_DEFAULT_CATALOG	"file:///etc/xml/catalog"
#endif
#include <stdio.h>
#include <stdarg.h>

#if __UNIX_XLIB__ || __MACOSX__
	#include <unistd.h>
	#include <sys/wait.h>
	#include <fcntl.h>
#endif

//static unsigned long 	gsApiVersion;
static long 			gsXmlDocClassID;
static BufferID			gsOutBuffer;

#define TOT_METHODS 6
enum {
		kNew = 1,
		kExtSubset,
		kSave,
		kNewRoot,
		kNewMixedRoot,
		//kValidate,
		kValidateFile
};

#define TOT_PROPERTIES 1
enum {
		kRoot = 1
};

#define	START_ERR	160
enum {
		Err_DocumentParseFailed = START_ERR,
		Err_EmptyDocument,
		Err_SaveFailed,
		Err_NewDocumentFailed,
		Err_NewDTDFailed,
		Err_AddChildFailed,
		Err_AddPrevSiblingFailed,
		Err_NewDocNodeFailed
};

static CStr63	gsXmlErrorsStr[] = 
		{	
		"Err_DocumentParseFailed",
		"Err_EmptyDocument",
		"Err_SaveFailed",
		"Err_NewDocumentFailed",
		"Err_NewDTDFailed",
		"Err_AddChildFailed",
		"Err_AddPrevSiblingFailed",
		"Err_NewDocNodeFailed"
		};
		
#define	TOT_ERRORS	8

//===========================================================================================
XErr	DecrementNode(XMLRecord *xmlRecP)
{
XErr			err = noErr;
BlockRef		block;

	if NOT(--xmlRecP->refCount)		// 0 nodes point to this doc
	{	xmlFreeDoc(xmlRecP->docP);
		block = xmlRecP->recordBlockRef;
		DisposeBlock(&block);
	}

return err;
}

//===========================================================================================
static XErr _DocGetRootElement(Biferno_ParamBlockPtr pbPtr, XMLRecord *xmlRecP, ObjRef *resultP)
{
XErr			err = noErr;
xmlNodePtr		nodeP;
long			api_data = pbPtr->api_data;

	nodeP = xmlDocGetRootElement(xmlRecP->docP);
	if (nodeP == nil)
		err = XError(kBAPI_ClassError, Err_EmptyDocument);
	else
		err = CreateXmlNode(api_data, xmlRecP, nodeP, resultP, 0);
		
return err;
}

//===========================================================================================
static XErr _ExtSubset(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, XMLRecord *xmlRecP)
{
XErr			err = noErr;
CStr255			rootName, publicID, systemID;
long			rootNameLen, publicIDLen, systemIDLen;
BlockRef		rootNameUTF, publicIDUTF, systemIDUTF;
xmlDtdPtr 		dtd;
long			api_data = pbPtr->api_data;
ParameterRec	*paramVarsP = exeMethodRecP->paramVarsP;
Ptr				systemIDPtr;

	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, rootName, &rootNameLen, 256, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[1].objRef, publicID, &publicIDLen, 256, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[2].objRef, systemID, &systemIDLen, 256, kImplicitTypeCast))
			{	if NOT(err = XML_EncodeUTF((Byte*)rootName, rootNameLen, &rootNameUTF, &rootNameLen))
				{	if NOT(err = XML_EncodeUTF((Byte*)publicID, publicIDLen, &publicIDUTF, &publicIDLen))
					{	if NOT(err = XML_EncodeUTF((Byte*)systemID, systemIDLen, &systemIDUTF, &systemIDLen))
						{	if (systemIDLen)
								systemIDPtr = GetPtr(systemIDUTF);
							else
								systemIDPtr = nil;
							if (dtd = xmlNewDtd(xmlRecP->docP, (Byte*)GetPtr(rootNameUTF), (Byte*)GetPtr(publicIDUTF), (Byte*)systemIDPtr))
							{	if (xmlRecP->docP->children == NULL)
								{	if NOT(xmlAddChild((xmlNodePtr)xmlRecP->docP, (xmlNodePtr)dtd))
										err = XError(kBAPI_ClassError, Err_AddChildFailed);
						    	}
						    	else
						    	{	if NOT(xmlAddPrevSibling(xmlRecP->docP->children, (xmlNodePtr)dtd))
										err = XError(kBAPI_ClassError, Err_AddPrevSiblingFailed);
						    	}
						    	if (err)
						    		xmlFreeDtd(dtd);
						    	else	
						    		xmlRecP->docP->extSubset = dtd;
							}
						  	else
								err = XError(kBAPI_ClassError, Err_NewDTDFailed);
							DisposeBlock(&systemIDUTF);
						}
						DisposeBlock(&publicIDUTF);
					}
					DisposeBlock(&rootNameUTF);
				}
			}
		}
	}


return err;
}

//===========================================================================================
static XErr _ValidateFileRedirected(long userData)
{
Biferno_ParamBlockPtr 	pbPtr = (Biferno_ParamBlockPtr)userData;
XErr					err = noErr;
long					api_data = pbPtr->api_data;
ParameterRec			*paramVarsP;
CStr255					filePath;
long					saveXmlDoValidityCheckingDefaultValue;
xmlDocPtr 				doc;
ExecuteMethodRec		*exeMethodRecP = &pbPtr->param.executeMethodRec;

	paramVarsP = exeMethodRecP->paramVarsP;
	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, filePath, nil, 256, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, true))
		{	if NOT(err = BAPI_NativePath(api_data, filePath))
			{	XThreadsEnterCriticalSection();
				saveXmlDoValidityCheckingDefaultValue = xmlDoValidityCheckingDefaultValue;
				xmlDoValidityCheckingDefaultValue = 1;
				if NOT(doc = xmlParseFile(filePath))
					xmlGenericError(xmlGenericErrorContext, "Could not parse document %s\n", filePath);
				else
					xmlFreeDoc(doc);
				xmlDoValidityCheckingDefaultValue = saveXmlDoValidityCheckingDefaultValue;
				XThreadsLeaveCriticalSection();
			}
		}
	}

return err;
}

#define	READ_STEP	1024
//===========================================================================================
static XErr	_read_from_file(FILE *f, BlockRef *resBlockP, long *resLenP)
{
XErr		err = noErr;
int			offset = 0;
Ptr			textP;
BlockRef	resBlock;
char		*strP;

	if (resBlock = NewBlock(READ_STEP, &err, &textP))
	{	while (strP = fgets(textP + offset, READ_STEP, f))
		{	offset += CLen(strP);
			if (err = SetBlockSize(resBlock, offset + READ_STEP))
				break;
			else
				textP = GetPtr(resBlock);
		}
		if NOT(err)
		{	if NOT(err = SetBlockSize(resBlock, offset + 1))
			{	textP = GetPtr(resBlock);
				textP[offset] = 0;
				*resBlockP = resBlock;
				*resLenP = offset;
			}
		}
		if (err)
			DisposeBlock(&resBlock);
	}
		
return err;
}

//===========================================================================================
void	_errorFunc(void *ctx, const char *fmt, ...)
{
va_list		ap;   /* points to each unnamed arg in turn */
char		*p, *sval;
int			ival;
double		dval;
CStr255		aCStr;
BufferID	id = gsOutBuffer;
XErr		err = noErr;

    va_start(ap, fmt);   /* make ap point to 1st unnamed arg */
    for (p=(char*)fmt; *p; p++)
    {  if (*p != '%')
       {
          //res = fwrite(p, 1, 1, (FILE*)ctx);
          err = BufferAddChar(id, *p);
          continue;
       }
       switch (*++p)
       {
       case 'd':
          ival = va_arg(ap, int);
          sprintf(aCStr, "%d", ival);
          //res = fwrite((Ptr)aCStr, 1, CLen(aCStr), (FILE*)ctx);
          err = BufferAddCString(id, aCStr, NO_ENC, 0);
          break;
       case 'f':
          dval = va_arg(ap, double);
          sprintf(aCStr, "%f", dval);
          //res = fwrite((Ptr)aCStr, 1, CLen(aCStr), (FILE*)ctx);
          err = BufferAddCString(id, aCStr, NO_ENC, 0);
          break;
       case 's':
          *aCStr = 0;
          sval = va_arg(ap, char *);
          //res = fwrite(sval, 1, CLen(sval), (FILE*)ctx);
          err = BufferAddCString(id, sval, NO_ENC, 0);
          break;
       default:
          //res = fwrite(p, 1, 1, (FILE*)ctx);
          err = BufferAddChar(id, *p);
          break;
       }
    }
    va_end(ap);   /* clean up when done */
    //res = ferror((FILE*)ctx);
}

//===========================================================================================
static XErr _ValidateFile(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
BlockRef	stdErr;
long		stdErrLen;

	// XMLRedirOutput must be called under critical section (and all during stdErr blockref use)
	XThreadsEnterCriticalSection();
    if NOT(err = XMLRedirOutput(_ValidateFileRedirected, (long)pbPtr, &stdErr, &stdErrLen))
	{	if (stdErrLen > 4096)
			stdErrLen = 4096;
		err = BAPI_StringToObj(pbPtr->api_data, GetPtr(stdErr), stdErrLen, &pbPtr->param.executeMethodRec.resultObjRef);
		// remember: never dispose stdErr
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr XMLRedirOutput(XErr (*_Func)(long userData), long userData, BlockRef *stdErrP, long *stdErrLenP)
{
XErr		err = noErr;	

	xmlSetGenericErrorFunc((void*)gsOutBuffer, _errorFunc);
	if NOT(err = BufferReset(gsOutBuffer))
	{	if NOT(err = _Func(userData))
		{	if NOT(err = BufferAddChar(gsOutBuffer, 0))
			{	*stdErrP = BufferGetBlockRef(gsOutBuffer, stdErrLenP);
				(*stdErrLenP)--;	// 0-terminated
			}
		}
	}

return err;
}

//===========================================================================================
static XErr _NewDoc(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP)
{
XErr				err = noErr;
long				versionUTFLen, versionLen, api_data = pbPtr->api_data;
ParameterRec		*paramVarsP;
XMLRecord			*xmlRecP;
BlockRef			xmlRecBlock, versionUTF = 0;
CStr63				version;
xmlChar*			versionP;

	paramVarsP = exeMethodRecP->paramVarsP;
	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, version, &versionLen, 63, kImplicitTypeCast))
  	{	if (xmlRecBlock = NewPtrBlock(sizeof(XMLRecord), &err, (Ptr*)&xmlRecP))
  		{	if NOT(*version)
  				versionP = (xmlChar*)"1.0";
  			else
			{	if NOT(err = XML_EncodeUTF((Byte*)version, versionLen, &versionUTF, &versionUTFLen))
					versionP = (xmlChar*)GetPtr(versionUTF);
			}
  			if NOT(err)
  			{	if NOT(xmlRecP->docP = xmlNewDoc(versionP))
      				err = XError(kBAPI_ClassError, Err_NewDocumentFailed);
  			}
  			if (versionUTF)
  				DisposeBlock(&versionUTF);
  			if NOT(err)
	  		{	xmlRecP->refCount = 1;
	      		xmlRecP->recordBlockRef = xmlRecBlock;
	      		if (err = BAPI_BufferToObj(api_data, (Ptr)&xmlRecP, sizeof(XMLRecord*), gsXmlDocClassID, true, 0, &exeMethodRecP->resultObjRef))
	  				xmlFreeDoc(xmlRecP->docP);
			}
			if (err)
				DisposeBlock(&xmlRecBlock);
		}
  	}

return err;
}

//===========================================================================================
static XErr _SaveDoc(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, XMLRecord *xmlRecP)
{
XErr			err = noErr;
//xmlNodePtr		nodeP;
long			encodingLen, res, api_data = pbPtr->api_data;
Boolean			indent;
CStr255			encoding, filePath;
char			*strP;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, filePath, nil, 256, kImplicitTypeCast))
	{	err = BAPI_RealPath(api_data, filePath, true);
		if NOT(err = BAPI_NativePath(api_data, filePath))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, encoding, &encodingLen, 256, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &indent, kImplicitTypeCast))
				{	if (*encoding)
						strP = encoding;
					else
						strP = nil;
					res = xmlSaveFormatFileEnc(filePath, xmlRecP->docP, strP, indent);
					if (res >= 0)
						err = BAPI_IntToObj(api_data, res, &exeMethodRecP->resultObjRef);
					else
						err = XError(kBAPI_ClassError, Err_SaveFailed);
				}
			}
		}
	}
			
return err;
}

//===========================================================================================
static XErr _NewRoot(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, XMLRecord *xmlRecP, Boolean isMixed)
{
XErr			err = noErr;
long			contentLen, nameLen, api_data = pbPtr->api_data;
CStr255			name, aCStr;
BlockRef		ref, nameUTF, contentUTF;
char			*contentP;
xmlNodePtr		rootP;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, &nameLen, 256, kImplicitTypeCast))
	{	if NOT(err = XML_EncodeUTF((Byte*)name, nameLen, &nameUTF, &nameLen))
		{	if (isMixed)
			{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr, &contentP, &contentLen, &ref, kImplicitTypeCast))
				{	if NOT(err = XML_EncodeUTF((Byte*)contentP, contentLen, &contentUTF, &contentLen))
					{	rootP = xmlNewDocNode(xmlRecP->docP, NULL, (Byte*)GetPtr(nameUTF), (Byte*)GetPtr(contentUTF));
						DisposeBlock(&contentUTF);
					}
					BAPI_ReleaseBlock(&ref);
				}
			}
			else
				rootP = xmlNewDocNode(xmlRecP->docP, NULL, (Byte*)GetPtr(nameUTF), NULL);
			if NOT(rootP)
				err = XError(kBAPI_ClassError, Err_NewDocNodeFailed);
			else
	        {	if (xmlAddChild((xmlNodePtr)xmlRecP->docP, rootP))
	        		err = CreateXmlNode(api_data, xmlRecP, rootP, &exeMethodRecP->resultObjRef, 0);
				else
					err = XError(kBAPI_ClassError, Err_AddChildFailed);
			}
			DisposeBlock(&nameUTF);
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	Xml_Init(Biferno_ParamBlockPtr pbPtr)
{
long				api_data = pbPtr->api_data;
XErr				err = noErr;
BAPI_MemberRecord	XmlDocMethods[TOT_METHODS] = 
			{	
				"New",			kNew,			"static void New(string version)",
				"ExtSubset",	kExtSubset,		"void ExtSubset(string rootName, string publicID, string systemID)",
				"Save",			kSave,			"int Save(string path, string encoding, boolean indent)",
				"NewRoot",		kNewRoot,		"xmlNode NewRoot(string name)",
				"NewMixedRoot",	kNewMixedRoot,	"xmlNode NewMixedRoot(string name, string content)",
				//"Validate",		kValidate,		"string Validate(void)",
				"ValidateFile",	kValidateFile,	"static string ValidateFile(string path)"
			};
			
BAPI_MemberRecord	XmlDocProperites[TOT_PROPERTIES] = 
			{	
				"root",		kRoot,		"xmlNode root"
			};

	if (err = BAPI_NewProperties(api_data, gsXmlDocClassID, XmlDocProperites, TOT_PROPERTIES, nil))
		return err;
	if (err = BAPI_NewMethods(api_data, gsXmlDocClassID, XmlDocMethods, TOT_METHODS, nil))
		return err;
	if NOT(err = BAPI_RegisterErrors(api_data, gsXmlDocClassID, START_ERR, gsXmlErrorsStr, TOT_ERRORS))
		gsOutBuffer = BufferCreate(512, &err);
return err;
}
//===========================================================================================
static XErr	Xml_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr				err = noErr;
ConstructorRec		*constructorRecP = &pbPtr->param.constructorRec;
long				api_data = pbPtr->api_data, objLen;
ParameterRec		*paramVarsP;
CStr255				filePath;
XMLRecord			*xmlRecP;
BlockRef			xmlRecBlock;

	if (message == kClone)
	{	objLen = sizeof(XMLRecord*);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&xmlRecP, &objLen, 0, nil))
		{	xmlRecP->refCount++;
			err = BAPI_BufferToObj(api_data, (Ptr)&xmlRecP, sizeof(XMLRecord*), gsXmlDocClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
	else
	{	paramVarsP = constructorRecP->varRecsP;
      	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, filePath, nil, 256, kImplicitTypeCast))
      	{	if NOT(err = BAPI_RealPath(api_data, filePath, true))
			{	if NOT(err = BAPI_NativePath(api_data, filePath))
				{	// alloc a block whose pointer put in biferno lists
	      			if (xmlRecBlock = NewPtrBlock(sizeof(XMLRecord), &err, (Ptr*)&xmlRecP))
		      		{	if (xmlRecP->docP = xmlParseFile(filePath))
			      		{	xmlRecP->refCount = 1;
			      			xmlRecP->recordBlockRef = xmlRecBlock;
			      			// note that put 4 bytes in object
			      			if (err = BAPI_BufferToObj(api_data, (Ptr)&xmlRecP, sizeof(XMLRecord*), gsXmlDocClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
		      					xmlFreeDoc(xmlRecP->docP);
		      			}
		      			else
		      				err = XError(kBAPI_ClassError, Err_DocumentParseFailed);
	      				if (err)
	      					DisposeBlock(&xmlRecBlock);
				  	}
				}
	      	}
		}
	}

return err;
}

//===========================================================================================
static XErr	Xml_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
XMLRecord		*xmlRecP;
long			objLen;
//BlockRef		block;

	objLen = sizeof(XMLRecord*);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&xmlRecP, &objLen, 0, nil))
	{	if (objLen)
			DecrementNode(xmlRecP);
    }

return err;
}

//===========================================================================================
static XErr	Xml_Primitive(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
PrimitiveRec	*primitiveRecP = &pbPtr->param.primitiveRec;
long			strLen;
char			*strP, *p;
PrimitiveUnion	*param_d;
//CStr255			buffer;
//BlockRef		ref;
long			objLen;
XMLRecord		*xmlRecP;

	if (primitiveRecP->resultWanted == kCString)
	{	objLen = sizeof(XMLRecord*);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &primitiveRecP->objRef, (Ptr)&xmlRecP, &objLen, 0, nil))
		{	param_d = &primitiveRecP->result;
			strP = "XML Document";
			strLen = CLen(strP);
			p = param_d->text.stringP;
			if (p)
			{	if (param_d->text.stringMaxStorage >= (strLen+1))
				{	CopyBlock(p, strP, strLen);
					p[strLen] = 0;
					param_d->text.stringLen = strLen;
				}
				else
				{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
					p[param_d->text.stringMaxStorage - 1] = 0;
					param_d->text.stringLen = strLen;
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
				}
			}
			else
				param_d->text.stringLen = strLen;
		}
    }
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);
 
return err;
}

//===========================================================================================
static XErr	Xml_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
//long				api_data = pbPtr->api_data;
long				objLen;
XMLRecord			*xmlRecP;

	if NOT(exeMethodRecP->bapiDocP->isStatic)
	{	objLen = sizeof(XMLRecord*);
		err = BAPI_GetObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&xmlRecP, &objLen, 0, nil);
	}
	if NOT(err)
    {	switch(exeMethodRecP->methodID)
		{	
			case kNew:
				err = _NewDoc(pbPtr, exeMethodRecP);
				break;
			
			case kExtSubset:
				err = _ExtSubset(pbPtr, exeMethodRecP, xmlRecP);
				break;
				
			case kSave:
				err = _SaveDoc(pbPtr, exeMethodRecP, xmlRecP);
				break;
			
			case kNewRoot:
				err = _NewRoot(pbPtr, exeMethodRecP, xmlRecP, false);
				break;

			case kNewMixedRoot:
				err = _NewRoot(pbPtr, exeMethodRecP, xmlRecP, true);
				break;
			
			/*case kValidate:
				err = _Validate(pbPtr, exeMethodRecP, xmlRecP);
				break;*/
			
			case kValidateFile:
				err = _ValidateFile(pbPtr);
				break;
			
			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
    }
 
return err;
}

//===========================================================================================
static XErr	Xml_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;
long				tLen, api_data = pbPtr->api_data;
//xmlChar				*key;
XMLRecord			*xmlRecP;

	tLen = sizeof(XMLRecord*);
	if NOT(err = BAPI_ReadObj(api_data, &getPropertyRec->objRef, (Ptr)&xmlRecP, &tLen, 0, nil))
	{	switch(getPropertyRec->propertyID)
		{
			case kRoot:
				err = _DocGetRootElement(pbPtr, xmlRecP, &getPropertyRec->resultObjRef);
				break;

			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	Xml_GetErrMessage(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetErrMessageRec	*getErrMessageRecP = &pbPtr->param.getErrMessageRec;

	switch(getErrMessageRecP->err)
	{
		case Err_DocumentParseFailed:
			CEquStr(getErrMessageRecP->errMessage, "Document not parsed successfully");
			break;
		case Err_EmptyDocument:
			CEquStr(getErrMessageRecP->errMessage, "The requested document is empty");
			break;
		case Err_SaveFailed:
			CEquStr(getErrMessageRecP->errMessage, "An error occurred while saving the file");
			break;
		Err_NewDocumentFailed
		default:
			*getErrMessageRecP->errMessage = 0;
			break;
	}
	
return err;
}
*/

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
unsigned long	xlib_version;

	switch(message)
	{
	case kRegister:
		BAPI_GetNumVersions(pbPtr->api_data, nil, nil, &xlib_version);
		if (xlib_version < 0x00010001)
		{	// uses RedirOutput (that is new to XLib 1.0.1)
			err = XError(kBAPI_Error, Err_BAPI_ExtensionTooNew);
			CEquStr(pbPtr->error, "XLib >= 1.0.1 needed (Biferno >= 1.0.2)");
		}
		else
		{	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "xmlDoc");
			gsXmlDocClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void xmlDoc(string filepath)");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "DOM: xmlDoc interface for Biferno");
			// BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
			//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			pbPtr->param.registerRec.nextBAPI_Dispatch = (long)xmlNode_Biferno_Dispatch;
		}
		break;
	case kInit:
		err = Xml_Init(pbPtr);
		break;
	case kShutDown:
    	BufferFree(gsOutBuffer);
    	break;
	case kRun:
    	break;
	case kExit:
    	break;
	case kConstructor:
	case kTypeCast:
	case kClone:
    	err = Xml_Constructor(pbPtr, message);
    	break;
	case kDestructor:
		err = Xml_Destructor(pbPtr);
		break;
	case kExecuteOperation:
		err = XError(kBAPI_Error, Err_IllegalOperation);
		break;
	case kExecuteMethod:
		err = Xml_ExecuteMethod(pbPtr);
		break;
	case kExecuteFunction:
		break;
	case kGetProperty:
		err = Xml_GetProperty(pbPtr);
		break;
	case kSetProperty:
		err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
		break;
	case kPrimitive:
		err = Xml_Primitive(pbPtr);
		break;
	case kGetErrMessage:
		// err = Xml_GetErrMessage(pbPtr);
		break;
	default:
		break;
	}

return err;
}
