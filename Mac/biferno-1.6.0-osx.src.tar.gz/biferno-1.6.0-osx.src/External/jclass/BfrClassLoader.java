/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BfrClassLoader.java,v 1.2 2004-03-19 13:54:40 valfer Exp $
	|______________________________________________________________________________
*/

import java.io.*;
import java.util.Hashtable;
import java.util.Properties;

public class BfrClassLoader extends ClassLoader
{
	public BfrClassLoader()
	{
	}
	public synchronized Class loadClass(String typeName, String classFilePath, boolean resolveIt) throws ClassNotFoundException
	{
		Class result = findLoadedClass(typeName);
		if (result != null)
			return result;
		byte typeData[] = getType(typeName, classFilePath);
		if (typeData == null)
			throw new ClassNotFoundException();
		result = defineClass(typeName, typeData, 0, typeData.length);
		if (result == null)
			throw new ClassFormatError();		
		if (resolveIt)
			resolveClass(result);		
	
	return result;
	}
	
	private byte[] readClassFromDisk(String classname)
	{
		System.out.println("classname="+classname);
		byte[] result;
		String complete_classname = classname.replace('.',File.separatorChar)+".class";
		try
		{
			FileInputStream fi = new FileInputStream(complete_classname);
			result = new byte[fi.available()];
			fi.read(result);
			return result;
		} catch (Exception e)
		{
			return null;
		}
	}
	
	private byte[] getType(String typeName, String classFilePath)
	{
		FileInputStream fis;
		String fileName = classFilePath;
		try
		{
			fis = new FileInputStream(fileName);
		}
		catch (FileNotFoundException e)
		{
			System.out.println("file not found");
			return null;
		}
		BufferedInputStream bis = new BufferedInputStream(fis);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try
		{
			int c = bis.read();
			while (c != -1)
			{
				out.write(c);
				c = bis.read();
			}
		} catch (IOException e)
		{
			System.out.println("io exception");
			return null;
		}
		return out.toByteArray();
	}
}

