/* this is session.c file.
 * this is part of the libspopc library sources
 * copyright � 2002 Benoit Rouits <brouits@free.fr>
 * released under the terms of GNU LGPL
 * (GNU Lesser General Public Licence).
 * libspopc offers simple API for a pop3 client (MTA).
 * See RFC 1725 for pop3 specifications.
 * more information on http://brouits.free.fr/libspopc/
 */

/*I casted 'port' to true unsigned, now, tell me if warning continues */
/*; #pragma warning(disable: 4761)*/ /* disable "integral size mismatch in argument" -warning */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef WIN32
#include <winsock.h>
#include <io.h>
#else
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#endif
#include <sys/types.h>
#define socklen_t int /* actually true on most systems */
#include "libspopc.h"

extern int pop3_recv (pop3sock_t sock, char* buf, int len);

#ifdef USE_SSL

static int SSL_UP = 0;

static char* SSL_CERT = NULL;

extern int ssl_verify_cert_chain(SSL *s,STACK_OF(X509) *sk);

void pop3_cert_setup(char *certfile)
{
	if (SSL_CERT) free(SSL_CERT);
	SSL_CERT=NULL;
	if (certfile) SSL_CERT=strdup(certfile);
}


int ssl_verify_callback(int ok, X509_STORE_CTX *ctx) {
int err;
	err = X509_STORE_CTX_get_error(ctx);
	if (err) {
		printf("SSL error #%d: %s.\n", err, X509_verify_cert_error_string(err));
		return 0;
	}
	return 1;
}



pop3sock_t ssl_prepare(const int port){
pop3sock_t sock;
	sock =(pop3sock_t)malloc(sizeof(pop3sock));
	sock->sock=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sock->sock){
		perror("ssl_prepare.socket");
                free(sock);
		return(NULL);
	}
	if ( 995 == port ) {
		if (0 == SSL_UP) SSL_UP=SSL_library_init();

		if (1 != SSL_UP) {
			close(sock->sock);
			free(sock);
			perror("Error initializing SSL");
			return(NULL);
		}
		SSL_load_error_strings();
  	    	sock->ctx = SSL_CTX_new(SSLv23_client_method());
		if (NULL == sock->ctx) {
			close(sock->sock);
			free(sock);
			perror("SSL v23 not available");
			return(NULL);
		}   
		if ( SSL_CERT != NULL ) {
			SSL_CTX_load_verify_locations(sock->ctx, SSL_CERT, 0);
			SSL_CTX_set_verify(sock->ctx, SSL_VERIFY_PEER, &ssl_verify_callback);
		}
		sock->ssl = SSL_new(sock->ctx);
		if (NULL == sock->ssl) {
			close(sock->sock);
                        SSL_CTX_free(sock->ctx);
			free(sock);
			perror("Error creating SSL context");
			return(NULL);
		}
		SSL_set_fd(sock->ssl, sock->sock);
	} else {
		sock->ssl=NULL;
		sock->ctx=NULL;
	}
	return sock;
}

#endif

pop3sock_t pop3_prepare(const char* servername, const int port, struct sockaddr_in* connection, struct hostent* server){
/* prepares the pop session and returns a socket descriptor */
pop3sock_t sock;
#ifdef _REENTRANT
struct hostent result_buffer;
char tmp[512];
int my_error;
#endif
#ifdef WIN32

	WSADATA wsaData;

	if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0)
	{
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
	}

#endif

	memset((char*)connection,0,sizeof(struct sockaddr_in));
	
#ifdef _REENTRANT
 #if defined(__sun__)||defined(HAVE_FUNC_GETHOSTBYNAME_R_5)
	server=gethostbyname_r (servername,&result_buffertmp, 512 - 1, &my_error);
 #else  /* linux */
	gethostbyname_r (servername,&result_buffer,tmp, 512 - 1, &server, &my_error);
 #endif
 #ifdef WIN32
	gethostbyname_r (servername, &result_buffer, &server);
 #endif
#else /* no _reentrant */
	server=gethostbyname(servername);
#endif
	if(!server){
		perror("pop3_prepare.gethostbyname");
		return BAD_SOCK;
	}


	memmove((char*)&(connection->sin_addr.s_addr),server->h_addr,server->h_length);
	connection->sin_family=AF_INET;
	connection->sin_port=htons(port?(unsigned short int)port:(unsigned short int)110);	/* integral size mismatch in argument - htons(port)*/

#ifdef USE_SSL
	sock = ssl_prepare(port);
	if ( BAD_SOCK == sock ) free(server);
#else
	sock=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sock){
		perror("pop3_prepare.socket");
		free(server);
	}
#endif
	return(sock);
}



char* pop3_connect(pop3sock_t sock, struct sockaddr_in* connection){
/* connects to the server through the sock and returns server's welcome */
int r;
char* buf;

#ifdef EBUG
	fprintf(stderr,"<pop3_connect>\n");
#endif

#ifdef USE_SSL
	r=connect(sock->sock,(struct sockaddr*)connection,(socklen_t)sizeof(*connection));
	if ( r!=-1  && sock->ssl ) {
		if (SSL_connect(sock->ssl) == -1) {
			fprintf(stderr, "SSL_connect failed\n");
			close(sock->sock);
			return(NULL);
		}
		if ( SSL_CERT ) {
			if ( !SSL_get_peer_certificate(sock->ssl) ) {
	 			fprintf(stderr, "SSL: failed to get peer certificate\n");
				close(sock->sock);               
				return(NULL);
	                }
			if ( !ssl_verify_cert_chain(sock->ssl, SSL_get_peer_cert_chain(sock->ssl) )) {
	 			fprintf(stderr, "SSL: failed to verify certificate chain\n");
				close(sock->sock);               
				return(NULL);
			}
		}
	}   
#else
	r=connect(sock,(struct sockaddr*)connection,(socklen_t)sizeof(*connection));
#endif

	if(r==-1){
		perror("pop3_connect.connect");
		return(NULL);
	}


	buf=(char*)malloc(512);
	if(!buf){
		perror("pop3_connect.malloc");
		return(NULL);
	}
	r=pop3_recv(sock,buf,512); /* 512 is theorically enough, but FIXME */
	buf[r]='\0';

#ifdef EBUG
	fprintf(stderr,"recv %s",buf);
	fprintf(stderr,"</pop3_connect>\n");
#endif
	return(buf);
}

void pop3_disconnect(pop3sock_t sock){
/* close socket  */
#ifdef USE_SSL
	if (sock->sock>0) close(sock->sock);
        if (NULL != sock->ssl) {
		SSL_shutdown(sock->ssl);
		free(sock->ssl);
	}
	if ( NULL != sock->ctx ) SSL_CTX_free(sock->ctx);
	free(sock);
#else
	if (sock>0) close(sock);
#endif

#ifdef WIN32
	WSACleanup();
#endif
}
