/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: pop3_bfr.c,v 1.11 2006-10-12 09:59:32 valfer Exp $
	|______________________________________________________________________________
*/
/** @file
* 	Post Office Protocol version 3 - Pop3 class implementation for Biferno
*
*	This file implements POP3 support support for Biferno using
*	the libspop library written  by .
*
*	Copyright (c) 2003, Tabasoft Sas
*
*
*	Valerio e Vincenzo Ferrucci
*/

#include "BifernoAPI.h"
#include "BfrVersion.h"
#include "libspopc.h"

//static unsigned long gsApiVersion;
static long gsPop3ClassID;

#define TOT_METHODS 4
enum {
  kGetTotMsg = 1,
  kGetIndMsg,
  kGetIndMsgSize,
  //kGetIndMsgUid,
  kDelIndMsg
};

/* #define TOT_PROPERTIES 4 */
/* enum { */
/*   knotbol = 1, */
/*   knoteol, */
/*   ksoff, */
/*   keoff */
/* }; */

/* #define TOT_COSTANTS 5 */
/* enum { */
/*   kdefaultvalue = REG_EXTENDED+REG_NEWLINE, */
/*   kextended = REG_EXTENDED, */
/*   kicase = REG_ICASE, */
/*   knosub= REG_NOSUB, */
/*   knewline = REG_NEWLINE */
/* }; */

#define	START_ERR	100
enum {
  ErrPop3 = START_ERR,
  ErrPop3BadMsgId
};

static CStr63	gsPop3ErrorsStr[] = 
  {	
    "ErrPop3",
    "ErrPop3BadMsgId"
  };
#define	TOT_ERRORS	2

//#define DEBUG
//===========================================================================================
static XErr	Pop3_Init(Biferno_ParamBlockPtr pbPtr)
{
long api_data = pbPtr->api_data;
XErr err = noErr;
BAPI_MemberRecord	Pop3Methods[TOT_METHODS] = 
  {	
    "GetTotMsg",		kGetTotMsg,			"int GetTotMsg(void)",
    "GetIndMsg",		kGetIndMsg,			"string GetIndMsg(int index, boolean onlyHead)",
    "GetIndMsgSize",	kGetIndMsgSize,		"long GetIndMsgSize(int index)",
    //"GetIndMsgUid",		kGetIndMsgUid,		"string GetIndMsgUid(int index)",
    "DelIndMsg",		kDelIndMsg,			"void DelIndMsg(int index)"
  };

if (err = BAPI_NewMethods(api_data, gsPop3ClassID, Pop3Methods, TOT_METHODS, nil))
   return err;
/* if (err = BAPI_NewProperties(api_data, gsRegexClassID, Pop3Property, TOT_PROPERTIES, nil)) */
/*    return err; */
/* if (err = BAPI_NewConstants(api_data, gsRegexClassID, Pop3Costants, TOT_COSTANTS, nil)) */
/*    return err; */
err = BAPI_RegisterErrors(api_data, gsPop3ClassID, START_ERR, gsPop3ErrorsStr, TOT_ERRORS);

return err;
}
//===========================================================================================
static XErr	Pop3_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
  XErr			err = noErr;
  ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
  long			api_data = pbPtr->api_data;
  ParameterRec	*paramVarsP;
  CStr255 server,user,password;
  popsession *popsessionP;
  char* popErrorStrP;
  
  if (clone)
    {	
      err = XError(kBAPI_Error, Err_IllegalOperation); 
    }
  else
    {	
      paramVarsP = constructorRecP->varRecsP;
      if not (err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, server, nil, 256, kImplicitTypeCast))
	{
	  if not (err = BAPI_ObjToString(api_data, &paramVarsP[1].objRef, user, nil, 256, kImplicitTypeCast))
	    {
	      if not (err = BAPI_ObjToString(api_data, &paramVarsP[2].objRef, password, nil, 256, kImplicitTypeCast))
		{
		  popErrorStrP = popbegin(server, user, password, &popsessionP);
		  if (popErrorStrP)
		    {
		      err = XError(kBAPI_ClassError, ErrPop3);
		      CEquStr(pbPtr->error, popErrorStrP);
		    }
		  else
		    {
#ifdef DEBUG 
	      printf("exp: %s-flags compile:%d -Nsub: %d\n", exp, flags,compiled.re_nsub); 
#endif
	      err = BAPI_BufferToObj(api_data, (Ptr) &popsessionP, sizeof(popsession*), gsPop3ClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		    }
		}
	    }
	}
    }
  return err;
}

//===========================================================================================
static XErr	Pop3_Destructor(Biferno_ParamBlockPtr pbPtr)
{
  XErr			err = noErr;
  DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
  popsession *popsessionP;
  long			objLen;

  objLen = sizeof(popsession*);
  if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&popsessionP, &objLen, 0, nil))
    {
      if (objLen)
      {
	popend(popsessionP);
      }
    }
  return err;
}
//===========================================================================================
static XErr	Pop3_Primitive(Biferno_ParamBlockPtr pbPtr)
{
  XErr			err = noErr;
  PrimitiveRec	*primitiveRecP = &pbPtr->param.primitiveRec;
  long		        strLen;
  char			*strP, *p;
  PrimitiveUnion	*param_d;
  //CStr255 buffer;
  //BlockRef ref;
  //long Pop3RecSize;
  popsession *popsessionP;
  long			objLen;

  if (primitiveRecP->resultWanted == kCString)
    {
      objLen = sizeof(popsession*);
      if NOT(err = BAPI_GetObj(pbPtr->api_data, &primitiveRecP->objRef, (Ptr)&popsessionP, &objLen, 0, nil))
	{
	param_d = &primitiveRecP->result;
	strP = "POP3 Connection";
	strLen = CLen(strP);
	p = param_d->text.stringP;
	if (p)
	  {	
	    if (param_d->text.stringMaxStorage >= (strLen+1))
	    {	
	      CopyBlock(p, strP, strLen);
	      p[strLen] = 0;
	      param_d->text.stringLen = strLen;
	    }
	    else
	    {	
	      CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
	      p[param_d->text.stringMaxStorage - 1] = 0;
	      param_d->text.stringLen = strLen;
	      err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
	    }
	  }
	else
	  param_d->text.stringLen = strLen;
	}
    }
  else
    err = XError(kBAPI_Error, Err_IllegalTypeCast);
  return err;
}

//===========================================================================================
static XErr _GetTotMsg(long api_data, ExecuteMethodRec *exeMethodRecP, popsession *popsessionP)
{
  return BAPI_IntToObj(api_data, popnum(popsessionP), &exeMethodRecP->resultObjRef);
}

//===========================================================================================
static XErr _GetIndMsgSize(long api_data, ExecuteMethodRec *exeMethodRecP, popsession *popsessionP, Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
long		index;
//char*		msgP;
//Boolean		onlyHead;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
		err = BAPI_LongToObj(api_data, popmsgsize(popsessionP, index), &exeMethodRecP->resultObjRef);
	else
	{	err = XError(kBAPI_ClassError, ErrPop3BadMsgId);
		CEquStr(pbPtr->error, "Bad Message Id");
	}

return err;
}

//===========================================================================================
static XErr _DelIndMsg(long api_data, ExecuteMethodRec *exeMethodRecP, popsession *popsessionP, Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
long		index;
//char*		msgP;
//Boolean		onlyHead;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
		popdelmsg (popsessionP, index);
	else
	{	err = XError(kBAPI_ClassError, ErrPop3BadMsgId);
		CEquStr(pbPtr->error, "Bad Message Id");
	}

return err;
}

//===========================================================================================
static XErr _GetIndMsg(long api_data, ExecuteMethodRec *exeMethodRecP, popsession *popsessionP, Biferno_ParamBlockPtr pbPtr, long which)
{
XErr		err = noErr;
long		index;
char*		msgP;
Boolean		onlyHead;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
	{	if (which == kGetIndMsg)
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &onlyHead, kImplicitTypeCast))
			{	if (onlyHead)
					msgP = popgethead(popsessionP, index);
				else
					msgP = popgetmsg(popsessionP, index);
			}
		}
		//else
		//	msgP = (Ptr)popgetmsguid(popsessionP, index);
		if (msgP)
			err = BAPI_StringToObj(api_data, msgP, CLen(msgP), &exeMethodRecP->resultObjRef);
	}
	else
	{	err = XError(kBAPI_ClassError, ErrPop3BadMsgId);
		CEquStr(pbPtr->error, "Bad Message Id");
	}

return err;
}
//===========================================================================================
static XErr	Pop3_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
  XErr err = noErr;
  ExecuteMethodRec *exeMethodRecP = &pbPtr->param.executeMethodRec;
  long api_data = pbPtr->api_data;
  popsession *popsessionP;
  long objLen;

  objLen = sizeof(popsession*);
  err = BAPI_GetObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&popsessionP, &objLen, 0, nil);
  if NOT(err)
    {	
      switch(exeMethodRecP->methodID)
	{	
	case kGetTotMsg:
	  err = _GetTotMsg(api_data, exeMethodRecP, popsessionP);
	  break;
	case kGetIndMsg:
	  err = _GetIndMsg(api_data, exeMethodRecP, popsessionP, pbPtr, kGetIndMsg);
	  break;
	case kGetIndMsgSize:
	  err = _GetIndMsgSize(api_data, exeMethodRecP, popsessionP, pbPtr);
	  break;
	/*case kGetIndMsgUid:
	  err = _GetIndMsg(api_data, exeMethodRecP, popsessionP, pbPtr, kGetIndMsgUid);
	  break;*/
	case kDelIndMsg:
	  err = _DelIndMsg(api_data, exeMethodRecP, popsessionP, pbPtr);
	  break;
	default:
	  err = XError(kBAPI_Error, Err_NoSuchMethod);
	  break;
	}
    }
  return err;
}
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

 switch(message)
   {
   case kRegister:
     pbPtr->param.registerRec.pluginType = kNewClassPlugin;
     CEquStr(pbPtr->param.registerRec.pluginName, "pop3");
     gsPop3ClassID = pbPtr->param.registerRec.pluginID;
     pbPtr->param.registerRec.wantDestructor = true;
     pbPtr->param.registerRec.fixedSize = true;
     CEquStr(pbPtr->param.registerRec.constructor, "void pop3 (string server, string user, string password)");
     CEquStr(pbPtr->param.registerRec.pluginDescr, "Implements the POP3 protocol for Biferno");
     //BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
     // CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
	 VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
	 if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
		CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
     break;
   case kInit:
     err = Pop3_Init(pbPtr);
     break;
   case kShutDown:
     break;
   case kRun:
     break;
   case kExit:
     break;
   case kConstructor:
     err = Pop3_Constructor(pbPtr, false);
     break;
   case kTypeCast:
   case kClone:
     err = Pop3_Constructor(pbPtr, true);
     break;
   case kDestructor:
     err = Pop3_Destructor(pbPtr);
     break;
   case kExecuteOperation:
     err = XError(kBAPI_Error, Err_IllegalOperation);
     break;
   case kExecuteMethod:
     err = Pop3_ExecuteMethod(pbPtr);
     break;
   case kExecuteFunction:
     break;
   case kGetProperty:
     //err = Pop3_GetProperty(pbPtr);
     break;
   case kSetProperty:
     //err = Pop3_SetProperty(pbPtr);
     break;
   case kPrimitive:
     err = Pop3_Primitive(pbPtr);
     break;
   case kGetErrMessage:
     break;
   default:
     break;
   }

return err;
}
