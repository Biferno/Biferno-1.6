/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: italiascuola_bfr.c,v 1.1.1.1 2003-03-25 13:07:39 valfer Exp $
	|______________________________________________________________________________
*/
/*
	BAPI (Biferno Application Programming Interface)
	
	Example:		cr2lf
	
	Description:	BAPI Function substitutes CR to LF in a string
	
	Tabasoft Sas 2001
*/

// Includes
#include 	"BifernoAPI.h"

// Globals
static long		gsPluginID;

// Constants
#define	kMolCheck			1

//===========================================================================================
static XErr	_MolCheck(long api_data, ObjRef *param, ObjRef *result)
{
XErr		err = noErr;
CStr255		str, resultString;
CStr31		tStr;
long		strLen, resultStringLen;
int			b, i, n;
Boolean		charAdded = false;

	if NOT(err = BAPI_ObjToString(api_data, param, str, &strLen, 255, kImplicitTypeCast))
	{	if ((strLen % 2) != 0)
		{	CAddChar(str, '0');
			strLen++;
			charAdded = true;
		}
		b = 255;
		n = strLen - 1;
		for (i = 0; i < n; i++)
		{
			b ^= str[i] + str[i+1];
		}
		CNumToString(b, tStr);
		if (charAdded)
			str[strLen-1] = ':';
		else
			CAddChar(str, ':');
		CAddStr(str, tStr);
		if (255 >= (5 + (4*strLen)/3))
			err = BAPI_EncodeBase64(api_data, str, CLen(str), resultString, &resultStringLen);
		else
			resultStringLen = 0;
		if NOT(err)
			err = BAPI_StringToObj(api_data, resultString, resultStringLen, result);
	}
	
	/*
	 l = Len(s)
     If l Mod 2 <> 0 Then
          s = s + "0"
          l = l +1
     End If
     b = 255
     For i = 1 To l - 1
          b = b Xor Asc(Mid(s,i,1)) Xor Asc(Mid(s,i+1,1))
     Next
     Return b
	*/
	
return err;
}

#pragma mark-
//===========================================================================================
/*
	We will have this event at Biferno start up.
*/
static XErr	_Register(Biferno_ParamBlockPtr pbPtr)
{
RegisterRec		*registerRecP = &pbPtr->param.registerRec;

	// Our extension implements a new Function (not a full class)
	registerRecP->pluginType = kNewFunctionsPlugin;
	
	// Give a name for the extension. Note that this is not the name
	// of the function (we will set it later).
	// No more than 63 chars
	CEquStr(registerRecP->pluginName, "ItaliaScuola");
	
	// Give a description of the extension (Max 255 chars)
	CEquStr(registerRecP->pluginDescr, "ItaliaScuola utils");

	// Get the plugin ID
	gsPluginID = registerRecP->pluginID;
	
return noErr;
}

//===========================================================================================
/*
	In the Init function we declare the name, prototype, etc.. of the function we implement.
*/
static XErr	_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BAPI_MemberRecord	myFunction; 
		
	CEquStr(myFunction.name, "MolChekSum");	
	myFunction.value = kMolCheck;
	CEquStr(myFunction.prototype, "string MolChekSum(string s)");	
	
	// Declare our function(s)
	err = BAPI_NewFunctions(pbPtr->api_data, gsPluginID, &myFunction, 1);

return err;
}

//===========================================================================================
/*
	In the Execute Function we run our function (finally!)
*/
static XErr	_ExecuteFunction(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*executeMethodRecP = &pbPtr->param.executeMethodRec;

	// Choose the function to execute (for now is trivial)
	switch(executeMethodRecP->methodID)
	{
		case kMolCheck:
			err = _MolCheck(pbPtr->api_data, &executeMethodRecP->paramVarsP[0].objRef,
															&executeMethodRecP->resultObjRef);
			break;
	
		default:
			// Set the error "type" to kBAPI_Error and the error "value" to Err_NoSuchFunction
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
	}
	
return err;
}

#pragma mark-
#pragma export on
//===========================================================================================
EXP XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	// In out Dispatch we handle only the messages: kRegister, kInit and kExecuteFunction
	switch(message)
	{
		case kRegister:
			err = _Register(pbPtr);
			break;
		case kInit:
			err = _Init(pbPtr);
			break;
		case kShutDown:
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kClone:
		case kDestructor:
		case kExecuteOperation:
		case kExecuteMethod:
			break;
		case kExecuteFunction:
			err = _ExecuteFunction(pbPtr);
			break;
		case kGetProperty:
		case kSetProperty:
		case kPrimitive:
		case kGetErrMessage:
		case kSuperIsChanged:
		default:
			break;
	}
	
return err;
}
#pragma export off

