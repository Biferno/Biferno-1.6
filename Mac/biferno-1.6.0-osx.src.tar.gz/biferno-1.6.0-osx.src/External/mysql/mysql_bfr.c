/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: mysql_bfr.c,v 1.42 2007-02-13 11:53:33 valfer Exp $
	|______________________________________________________________________________
*/


#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"
#ifdef MYSQL_BUILT_IN
	#include 	"StaticClasses.h"
#endif

#include 	"BDBAPI.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "my_global.h"
#include "mysql.h"

#define		MAX_FIELD_TITLE_LENGTH	63

#if MYSQL_VERSION_ID >= 40100	// >= 4.1
	#define	_41					1
	#define	MAX_PARAMETERS		64
	#define	MAX_ALLOWED_PACKET	1024 * 512	// 512 K
#endif

typedef struct
{		
	char 			title[MAX_FIELD_TITLE_LENGTH+1];
#ifdef _41
	BlockRef		bindBufferBlock;
	unsigned long	length;
	my_bool			is_null;
	Byte			pad;
	short			padShort;
#endif
} MySQLColumnDescr;


typedef struct
{		
	MYSQL_RES			*mysql_res;
#ifdef _41
	MYSQL_STMT			*mysql_stmt;
	BlockRef			bindBlock;
	MYSQL_BIND			*bindArray;
#endif
	long				totFields;
	long				curPos;
	BlockRef			columnDescrBlock;
	MySQLColumnDescr	*columnDescrP;
	Boolean				prepared;
	Boolean				sendLongData;		// used only in prepares
	Byte				cursorMode;
	Boolean				endOfSet;
#ifdef _41
	long				param_bound;		// bind actually executed
	long				param_count;		// ? in query
	BlockRef			params[MAX_PARAMETERS];
	MYSQL_BIND			bindParams[MAX_PARAMETERS];
#endif
} MySQLCursorRec;

#define	MAX_CONN_ITEM_LENGTH	63
typedef struct
{		
	MYSQL 			*connection;
	unsigned int	port;
	char			host[MAX_CONN_ITEM_LENGTH+1];
	char			user[MAX_CONN_ITEM_LENGTH+1];
	char			password[MAX_CONN_ITEM_LENGTH+1];
	char			db[MAX_CONN_ITEM_LENGTH+1];
} MySQLRec;

#define	MySQLClassName	"mysql"

static long			mySQLClassID;
static long			gsApiVersion;
static long			gMySQLDllRef = 0;
static BDBAPI_Rec	bdbRec;
static Boolean		okPrepare = false;
static CStr255		gsLastFuncName;

#ifdef MYSQL_DYNAMIC_LINK	// actually used on Windows and MacOSX
	#ifdef __VISUALCPP__
		#define	bfrStdCall
		#define	bfrStdCallInt	__stdcall
	#else
		#define	bfrStdCall		STDCALL
		#define	bfrStdCallInt
	#endif
	static void					bfrStdCall (bfrStdCallInt *mysql_data_seek_EP)(MYSQL_RES *result, my_ulonglong offset) = nil;
	static MYSQL *				bfrStdCall (bfrStdCallInt *mysql_init_EP)(MYSQL *mysql) = nil;
	static MYSQL *				bfrStdCall (bfrStdCallInt *mysql_real_connect_EP)(MYSQL *mysql, const char *host, const char *user, const char *passwd, const char *db, unsigned int port, const char *unix_socket, unsigned int clientflag) = nil;
	static void					bfrStdCall (bfrStdCallInt *mysql_free_result_EP)(MYSQL_RES *result) = nil;
	static void					bfrStdCall (bfrStdCallInt *mysql_close_EP)(MYSQL *sock) = nil;
	static int					bfrStdCall (bfrStdCallInt *mysql_query_EP)(MYSQL *mysql, const char *q) = nil;
	static MYSQL_FIELD_OFFSET 	bfrStdCall (bfrStdCallInt *mysql_field_seek_EP)(MYSQL_RES *result, MYSQL_FIELD_OFFSET offset) = nil;
	static MYSQL_ROW			bfrStdCall (bfrStdCallInt *mysql_fetch_row_EP)(MYSQL_RES *result) = nil;
	static MYSQL_FIELD *		bfrStdCall (bfrStdCallInt *mysql_fetch_field_EP)(MYSQL_RES *result) = nil;
	static MYSQL_RES *			bfrStdCall (bfrStdCallInt *mysql_store_result_EP)(MYSQL *mysql) = nil;
	static MYSQL_RES *			bfrStdCall (bfrStdCallInt *mysql_use_result_EP)(MYSQL *mysql) = nil;
	static unsigned long *		bfrStdCall (bfrStdCallInt *mysql_fetch_lengths_EP)(MYSQL_RES *result) = nil;
	static unsigned long 		bfrStdCall (bfrStdCallInt *mysql_real_escape_string_EP)(MYSQL *mysql, char *to, const char *from, unsigned long length) = nil;
	static char *		 		bfrStdCall (bfrStdCallInt *mysql_get_client_info_EP)() = nil;
	static char *		 		bfrStdCall (bfrStdCallInt *mysql_get_server_info_EP)(MYSQL *mysql) = nil;

#ifdef _41
	// prepares
	static MYSQL_STMT * 	bfrStdCall (bfrStdCallInt *mysql_stmt_init_EP)(MYSQL *mysql) = nil;
	static int			 	bfrStdCall (bfrStdCallInt *mysql_stmt_prepare_EP)(MYSQL_STMT *stmt, const char *query, unsigned long length) = nil;
	static MYSQL_RES * 		bfrStdCall (bfrStdCallInt *mysql_stmt_result_metadata_EP)(MYSQL_STMT *stmt) = nil;
	static my_bool 			bfrStdCall (bfrStdCallInt *mysql_stmt_close_EP)(MYSQL_STMT *) = nil;
	static my_bool 			bfrStdCall (bfrStdCallInt *mysql_stmt_bind_result_EP)(MYSQL_STMT *stmt, MYSQL_BIND *bind) = nil;
	static const char *		bfrStdCall (bfrStdCallInt *mysql_stmt_error_EP)(MYSQL_STMT *stmt) = nil;
	static int				bfrStdCall (bfrStdCallInt *mysql_stmt_execute_EP)(MYSQL_STMT *stmt) = nil;
	static int				bfrStdCall (bfrStdCallInt *mysql_stmt_store_result_EP)(MYSQL_STMT *stmt) = nil;
	static int				bfrStdCall (bfrStdCallInt *mysql_stmt_fetch_EP)(MYSQL_STMT *stmt) = nil;
	static unsigned int		bfrStdCall (bfrStdCallInt *mysql_stmt_field_count_EP)(MYSQL_STMT *stmt) = nil;
	static my_ulonglong		bfrStdCall (bfrStdCallInt *mysql_stmt_num_rows_EP)(MYSQL_STMT *stmt) = nil;
	static my_ulonglong		bfrStdCall (bfrStdCallInt *mysql_stmt_affected_rows_EP)(MYSQL_STMT *stmt) = nil;
	static void				bfrStdCall (bfrStdCallInt *mysql_stmt_data_seek_EP)(MYSQL_STMT *stmt, my_ulonglong offset) = nil;
	static unsigned long	bfrStdCall (bfrStdCallInt *mysql_stmt_param_count_EP)(MYSQL_STMT *stmt) = nil;
	static my_bool			bfrStdCall (bfrStdCallInt *mysql_stmt_bind_param_EP)(MYSQL_STMT *stmt, MYSQL_BIND *bind) = nil;
	static unsigned int		bfrStdCall (bfrStdCallInt *mysql_stmt_errno_EP)(MYSQL_STMT *stmt) = nil;
	static int				bfrStdCall (bfrStdCallInt *mysql_stmt_attr_set_EP)(MYSQL_STMT *stmt, enum enum_stmt_attr_type option, const void *arg) = nil;
	static my_bool			bfrStdCall (bfrStdCallInt *mysql_stmt_free_result_EP)(MYSQL_STMT *stmt) = nil;
	static my_bool			bfrStdCall (bfrStdCallInt *mysql_autocommit_EP)(MYSQL *stmt, my_bool mode) = nil;
	static my_bool			bfrStdCall (bfrStdCallInt *mysql_rollback_EP)(MYSQL *stmt) = nil;
	static my_bool			bfrStdCall (bfrStdCallInt *mysql_commit_EP)(MYSQL *stmt) = nil;
	static my_bool			bfrStdCall (bfrStdCallInt *mysql_stmt_send_long_data_EP)(MYSQL_STMT *stmt, unsigned int parameter_number, const char *data, unsigned long length) = nil;
	static my_bool			bfrStdCall (bfrStdCallInt *mysql_stmt_reset_EP)(MYSQL_STMT *stmt) = nil;

#endif

	#ifndef	mysql_error
		char * bfrStdCall (bfrStdCallInt *mysql_error_EP)(MYSQL *mysql);
	#else
		#define	mysql_error_EP	mysql_error
	#endif
	#ifndef	mysql_errno
		unsigned int bfrStdCall (bfrStdCallInt *mysql_errno_EP)(MYSQL *mysql);
	#else
		#define	mysql_errno_EP	mysql_errno
	#endif
	#ifndef	mysql_num_rows
		my_ulonglong bfrStdCall (bfrStdCallInt *mysql_num_rows_EP)(MYSQL_RES *res);
	#else
		#define	mysql_num_rows_EP	mysql_num_rows
	#endif
	#ifndef	mysql_num_fields
		unsigned int bfrStdCall (bfrStdCallInt *mysql_num_fields_EP)(MYSQL_RES *res);
	#else
		#define	mysql_num_fields_EP	mysql_num_fields
	#endif
	#ifndef	mysql_affected_rows
		my_ulonglong bfrStdCall (bfrStdCallInt *mysql_affected_rows_EP)(MYSQL *mysql);
	#else
		#define	mysql_affected_rows_EP	mysql_affected_rows
	#endif
#else
	#define		mysql_data_seek_EP				mysql_data_seek
	#define		mysql_init_EP					mysql_init
	#define		mysql_real_connect_EP			mysql_real_connect
	#define		mysql_free_result_EP			mysql_free_result
	#define		mysql_close_EP					mysql_close
	#define		mysql_query_EP					mysql_query
	#define		mysql_field_seek_EP				mysql_field_seek
	#define		mysql_fetch_row_EP				mysql_fetch_row
	#define		mysql_fetch_field_EP			mysql_fetch_field
	#define		mysql_store_result_EP			mysql_store_result
	#define		mysql_use_result_EP				mysql_use_result
	#define		mysql_fetch_lengths_EP			mysql_fetch_lengths
	#ifndef __WIN_XLIB__
		#define		mysql_real_escape_string_EP		mysql_real_escape_string
	#endif
	#define		mysql_error_EP					mysql_error
	#define		mysql_num_rows_EP				mysql_num_rows
	#define		mysql_num_fields_EP				mysql_num_fields
	#define		mysql_affected_rows_EP			mysql_affected_rows
	#define		mysql_errno_EP					mysql_errno
	#define		mysql_get_client_info_EP		mysql_get_client_info
	#define		mysql_get_server_info_EP		mysql_get_server_info
	
#ifdef _41
	// Prepares
	#define		mysql_stmt_init_EP				mysql_stmt_init
	#define		mysql_stmt_prepare_EP			mysql_stmt_prepare
	#define		mysql_stmt_result_metadata_EP	mysql_stmt_result_metadata
	#define		mysql_stmt_close_EP				mysql_stmt_close
	#define		mysql_stmt_bind_result_EP		mysql_stmt_bind_result
	#define		mysql_stmt_error_EP				mysql_stmt_error
	#define		mysql_stmt_execute_EP			mysql_stmt_execute
	#define		mysql_stmt_store_result_EP		mysql_stmt_store_result
	#define		mysql_stmt_fetch_EP				mysql_stmt_fetch
	#define		mysql_stmt_field_count_EP		mysql_stmt_field_count_
	#define		mysql_stmt_num_rows_EP			mysql_stmt_num_rows
	#define		mysql_stmt_affected_rows_EP		mysql_stmt_affected_rows
	#define		mysql_stmt_data_seek_EP			mysql_stmt_data_seek
	#define		mysql_stmt_param_count_EP		mysql_stmt_param_count
	#define		mysql_stmt_bind_param_EP		mysql_stmt_bind_param
	#define		mysql_stmt_errno_EP				mysql_stmt_errno
	#define		mysql_stmt_attr_set_EP			mysql_stmt_attr_set
	#define		mysql_stmt_free_result_EP		mysql_stmt_free_result
	#define		mysql_autocommit_EP				mysql_autocommit
	#define		mysql_rollback_EP				mysql_rollback
	#define		mysql_commit_EP					mysql_commit
	#define		mysql_stmt_send_long_data_EP	mysql_stmt_send_long_data
	#define		mysql_stmt_reset_EP				mysql_stmt_reset
	
#endif

#endif

//===========================================================================================
// format of error ":[errNumber]:[driverName->mysql]:optionString, usually name of function that caused error:message"
static void	_mySQLSetError(XErr *errP, MySQLRec *mysqlRecP, MySQLCursorRec *cursorP, char *optString, char *strError)
{
CStr15		tStr;
XErr		err = *errP;
CStr255		resultStr;

	*resultStr = 0;
	if NOT(err)
	{
	#ifdef _41
		if (cursorP && cursorP->mysql_stmt)
		{	if NOT(err = mysql_stmt_errno_EP(cursorP->mysql_stmt))
				err = ErrDBMSError;
		}
		else 
	#endif
		if (mysqlRecP)
		{	if NOT(err = mysql_errno_EP(mysqlRecP->connection))
				err = ErrDBMSError;
		}
		else
			err = ErrDBMSError;
	}
	CNumToString(err, tStr);
	CEquStr(strError, ":");
	CAddStr(strError, tStr);
	CAddStr(strError, ":mysql:");
	if (optString)
		CAddStr(strError, optString);
	if (mysqlRecP && mysqlRecP->connection)
	{	CAddStr(strError, ": ");
	#ifdef _41
		if (cursorP && cursorP->mysql_stmt)
			CAddStr(strError, (char*)mysql_stmt_error_EP(cursorP->mysql_stmt));
		else
	#endif
			CAddStr(strError, (char*)mysql_error_EP(mysqlRecP->connection));
	}
	err = XError(kBAPI_ClassError, ErrDBMSError);
	*errP = err;
}

//===========================================================================================
static XErr	_mySQLTokenizeConnString(char *strP, long len, MySQLRec *mysqlRecP)
{
Ptr		tempP;
long	tempLen;
Ptr		addrs[4];
int		k;
long	aLong;
XErr	err = noErr;

	addrs[0] = mysqlRecP->host;
	addrs[1] = mysqlRecP->user;
	addrs[2] = mysqlRecP->password;
	addrs[3] = mysqlRecP->db;
	SkipSpaceAndTab(&strP, &len);
	if (len)
	{	tempP = strP;
		tempLen = 0;
		k = 0;
		do {
			if (len && ((*strP == ',') || (*strP == ' ') || (*strP == '\t')))
			{	SkipUntilChar(&strP, &len, ',', nil);
				if (len && (*strP != ','))
					err = XError(kBAPI_Error, Err_BadSyntax);
				else if (len)
				{	strP++;
					len--;
					SkipSpaceAndTab(&strP, &len);
				}
				if (tempLen < MAX_CONN_ITEM_LENGTH)
					CopyBlock(addrs[k], tempP, tempLen);
				else
					err = XError(kBAPI_Error, Err_StringTooLong);
				if NOT(err)
				{	addrs[k][tempLen] = 0;
					tempLen = 0;
					tempP = strP;
					k++;
				}
			}
			else
			{	strP++;
				len--;
				tempLen++;
			}
		} while ((len > 0) && (k < 4) && NOT(err));
		if NOT(err)
		{	if (len)
				err = XError(kBAPI_Error, Err_BadSyntax);
			else if (tempLen && (k < 4))
			{	if (tempLen < MAX_CONN_ITEM_LENGTH)
					CopyBlock(addrs[k], tempP, tempLen);
				else
					err = XError(kBAPI_Error, Err_StringTooLong);
				addrs[k][tempLen] = 0;
			}
		}
	}
	if (strP = strchr(mysqlRecP->host, ':'))
	{	*strP++ = 0;
		CStringToNum(strP, &aLong);
		mysqlRecP->port = aLong;
	}
	else
		mysqlRecP->port = 0;

return err;
}

//===========================================================================================
static XErr	_mySQLDescribeColumns(MySQLRec *mysqlRecP, MySQLCursorRec *cursorP, char *error, Boolean alsoBind)
{
int					tSize, i, totFields;
XErr				err = noErr;
MYSQL_FIELD			*field;
MySQLColumnDescr	*colDescrP;
MYSQL_RES 			*mysql_res = cursorP->mysql_res;
#ifdef _41
	long				maxlength;
	MYSQL_BIND			*bindP;
#endif

	totFields = mysql_num_fields_EP(mysql_res);
#ifdef _41
	if (alsoBind)
	{	if NOT(cursorP->bindBlock)
		{	if (cursorP->bindBlock = NewBlock(tSize = (sizeof(MYSQL_BIND) * totFields), &err, (Ptr*)&cursorP->bindArray))
				ClearBlock(cursorP->bindArray, tSize);
			else
				return err;
		}
	}
#endif
	if (totFields >= 0)
	{	if NOT(cursorP->columnDescrBlock)
		{	cursorP->columnDescrBlock = NewBlockLocked(tSize = (sizeof(MySQLColumnDescr) * totFields), &err, (Ptr*)&colDescrP);
			ClearBlock(colDescrP, tSize);	
		}
		else
			colDescrP = (MySQLColumnDescr*)GetPtr(cursorP->columnDescrBlock);
		if NOT(err)
		{	cursorP->columnDescrP = colDescrP;
			cursorP->totFields = totFields;
			for (i = 0; (i < totFields) && NOT(err); i++, colDescrP++)
			{	if (field = mysql_fetch_field_EP(mysql_res))
				{	
					if (CLen(field->name) < MAX_FIELD_TITLE_LENGTH)
					{	CEquStr(colDescrP->title, field->name);
					#ifdef _41
						if (alsoBind)
						{	maxlength = field->max_length;	// ok becaues STMT_ATTR_UPDATE_MAX_LENGTH is set to true
							bindP = &cursorP->bindArray[i];
							if (colDescrP->bindBufferBlock)
							{	if NOT(err = SetBlockSize(colDescrP->bindBufferBlock, maxlength+1))
									bindP->buffer = GetPtr(colDescrP->bindBufferBlock);
							}
							else
								colDescrP->bindBufferBlock = NewBlock(maxlength+1, &err, (Ptr*)&bindP->buffer);
							if NOT(err)
							{	bindP->buffer_type = MYSQL_TYPE_STRING;
								bindP->buffer_length = maxlength+1;
								bindP->is_null = &colDescrP->is_null;
								bindP->length = &colDescrP->length;
							}
						}
					#endif
					}
					else
						_mySQLSetError(&err, mysqlRecP, cursorP, "Field Name is too long", error);
				}
				else
					_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_fetch_field", error);
			}
		#ifdef _41	
			if (alsoBind)
			{	if (mysql_stmt_bind_result_EP(cursorP->mysql_stmt, cursorP->bindArray))
					_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_stmt_bind_result", error);
			}
		#endif
			if (err)
				DisposeBlock(&cursorP->columnDescrBlock);
		}
	}
	else
		_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_num_fields", error);

return err;
}

//===========================================================================================
static XErr _mySQLGetProc(char *funcName, void *procAddress)
{
 	CEquStr(gsLastFuncName, funcName);

return XGetDLLSymbol(gMySQLDllRef, funcName, (long*)procAddress, false);
}

//===========================================================================================
static XErr _mySQLLoadFuncs(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

#if MYSQL_DYNAMIC_LINK 
CStr255		tempStr, dllName;

	*tempStr = 0;
#if __MACOSX__
	CEquStr(dllName, "libmysqlclient.dylib");
#elif __WIN_XLIB__
	CEquStr(dllName, "libmySQL");	// System appends ".dll"
#else
	CEquStr(dllName, "libmysqlclient.so");
#endif
 	if NOT(err = XLoadDLL(dllName, &gMySQLDllRef, tempStr, nil, false))
 	{	if (err = _mySQLGetProc("mysql_init", (long*)&mysql_init_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_real_connect", (long*)&mysql_real_connect_EP))
 			goto out;

 		if (err = _mySQLGetProc("mysql_free_result", (long*)&mysql_free_result_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_data_seek", (long*)&mysql_data_seek_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_close", (long*)&mysql_close_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_query", (long*)&mysql_query_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_field_seek", (long*)&mysql_field_seek_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_fetch_row", (long*)&mysql_fetch_row_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_fetch_field", (long*)&mysql_fetch_field_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_store_result", (long*)&mysql_store_result_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_use_result", (long*)&mysql_use_result_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_fetch_lengths", (long*)&mysql_fetch_lengths_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_get_client_info", (long*)&mysql_get_client_info_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_get_server_info", (long*)&mysql_get_server_info_EP))
 			goto out;
 		// Sometimes this symbol is unavailable (Win32), so ignore err
 		_mySQLGetProc("mysql_real_escape_string", (long*)&mysql_real_escape_string_EP);
 		if (err = _mySQLGetProc("mysql_use_result", (long*)&mysql_use_result_EP))
 			goto out;
 		if (err = _mySQLGetProc("mysql_use_result", (long*)&mysql_use_result_EP))
 			goto out;
 	#ifndef	mysql_error_EP
 		if (err = _mySQLGetProc("mysql_error", (long*)&mysql_error_EP))
 			goto out;
  	#endif

 	#ifndef	mysql_errno_EP
 		if (err = _mySQLGetProc("mysql_errno", (long*)&mysql_errno_EP))
 			goto out;
 	#endif

 	#ifndef	mysql_num_rows_EP
 		if (err = _mySQLGetProc("mysql_num_rows", (long*)&mysql_num_rows_EP))
 			goto out;
 	#endif

 	#ifndef	mysql_num_fields_EP
 		if (err = _mySQLGetProc("mysql_num_fields", (long*)&mysql_num_fields_EP))
 			goto out;
 	#endif

 	#ifndef	mysql_affected_rows_EP
 		if (err = _mySQLGetProc("mysql_affected_rows", (long*)&mysql_affected_rows_EP))
 			goto out;
 	#endif
 	
 	// PREPARES
	#ifdef _41
 		if (err = _mySQLGetProc("mysql_stmt_init", (long*)&mysql_stmt_init_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_prepare", (long*)&mysql_stmt_prepare_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_result_metadata", (long*)&mysql_stmt_result_metadata_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_close", (long*)&mysql_stmt_close_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_bind_result", (long*)&mysql_stmt_bind_result_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_error", (long*)&mysql_stmt_error_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_execute", (long*)&mysql_stmt_execute_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_store_result", (long*)&mysql_stmt_store_result_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_fetch", (long*)&mysql_stmt_fetch_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_field_count", (long*)&mysql_stmt_field_count_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_num_rows", (long*)&mysql_stmt_num_rows_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_affected_rows", (long*)&mysql_stmt_affected_rows_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_data_seek", (long*)&mysql_stmt_data_seek_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_param_count", (long*)&mysql_stmt_param_count_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_bind_param", (long*)&mysql_stmt_bind_param_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_errno", (long*)&mysql_stmt_errno_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_attr_set", (long*)&mysql_stmt_attr_set_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_free_result", (long*)&mysql_stmt_free_result_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_init", (long*)&mysql_stmt_init_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_autocommit", (long*)&mysql_autocommit_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_rollback", (long*)&mysql_rollback_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_commit", (long*)&mysql_commit_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_send_long_data", (long*)&mysql_stmt_send_long_data_EP))
 			goto outPrepare;
 		if (err = _mySQLGetProc("mysql_stmt_reset", (long*)&mysql_stmt_reset_EP))
 			goto outPrepare;
 	outPrepare:
 		if (err)
 			err = noErr;
 		else
 			okPrepare = true;
 	#endif

		CEquStr(tempStr, "");
 	}
	out:
	if (err)
	{	CEquStr(pbPtr->error, "Can't Initialize mysql client lib: ");
		CAddStr(pbPtr->error, tempStr);
		if (gMySQLDllRef)
			XFreeDLL(&gMySQLDllRef, false);
	}
#else
	//if NOT((void*)mysql_init)
	//	_mySQLSetError(&err, nil, nil, "Can't Initialize mysql library", pbPtr->error);
	okPrepare = true;
#endif
return err;
}

//===========================================================================================
static XErr	_CloseNormalCursor(long api_data, long db_api_data, Ptr cursorP, long userData, char *error)
{
XErr			err = noErr;
MySQLCursorRec	*mysqlCursorP = (MySQLCursorRec*)cursorP;

	if (mysqlCursorP->columnDescrBlock)
		DisposeBlock(&mysqlCursorP->columnDescrBlock);
	if (mysqlCursorP->mysql_res)
	{	mysql_free_result_EP(mysqlCursorP->mysql_res);
		mysqlCursorP->mysql_res = 0L;
	}
	
return err;
}

#ifdef __MWERKS__
#pragma mark-
#endif

#ifdef _41
typedef struct
{
	PrepareRec	*prepareRecP;
	MySQLRec	*mysqlRecP;
} PrepareCallBackRec;

//===========================================================================================
static XErr	_FreeCursorParameters(Ptr cursorP, Boolean free)
{
XErr					err = noErr;
MySQLCursorRec			*mysqlCursorP = (MySQLCursorRec*)cursorP;

	bdbRec.BDBAPI_DisposeParams(0, 0, mysqlCursorP->params, mysqlCursorP->param_bound);
	mysqlCursorP->param_bound = 0;	
	mysqlCursorP->param_count = 0;

return err;
}

//===========================================================================================
static XErr	_ReleasePreparedCursor(long api_data, long db_api_data, Ptr cursorP, long userData, char *error, Boolean free)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(api_data)
#endif
MySQLCursorRec		*mysqlCursorP = (MySQLCursorRec*)cursorP;
XErr				err = noErr;
MySQLColumnDescr	*colDescrP;
int					i, totFields;
Boolean				failed;
my_bool				set = true;

	_FreeCursorParameters(cursorP, free);
	if (mysqlCursorP->mysql_stmt)
		mysql_stmt_free_result_EP(mysqlCursorP->mysql_stmt);
	mysqlCursorP->mysql_res = 0L;
	if (mysqlCursorP->sendLongData)
	{	failed = mysql_stmt_reset_EP(mysqlCursorP->mysql_stmt);
		mysqlCursorP->sendLongData = false;
		// don't know if mysql_stmt_reset zero also this, so redo it
		mysql_stmt_attr_set_EP(mysqlCursorP->mysql_stmt, STMT_ATTR_UPDATE_MAX_LENGTH, &set);
	}
	if (free)
	{	if (mysqlCursorP->columnDescrBlock)
		{	colDescrP = (MySQLColumnDescr*)GetPtr(mysqlCursorP->columnDescrBlock);
			totFields = mysqlCursorP->totFields;
			for (i = 0; (i < totFields); i++, colDescrP++)
			{	if (colDescrP->bindBufferBlock)
					DisposeBlock(&colDescrP->bindBufferBlock);
			}
			DisposeBlock(&mysqlCursorP->columnDescrBlock);
		}
		if (mysqlCursorP->bindBlock)
			DisposeBlock(&mysqlCursorP->bindBlock);
		if (mysqlCursorP->mysql_stmt)
			mysql_stmt_close_EP(mysqlCursorP->mysql_stmt);
	}
	
return err;
}

//===========================================================================================
static XErr	_ClosePreparedCursor(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
	return _ReleasePreparedCursor(api_data, db_api_data, the_cursorP, userData, error, false);
}

//===========================================================================================
static XErr	_FreePreparedCursor(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
	return _ReleasePreparedCursor(api_data, db_api_data, the_cursorP, userData, error, true);
}

//===========================================================================================
static XErr	_PrepareOneCursor(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(api_data)
#endif
	MySQLCursorRec			*cursorP = (MySQLCursorRec*)the_cursorP;
	PrepareCallBackRec		*prepCBRecP = (PrepareCallBackRec*)userData;
	XErr					err = noErr;
	PrepareRec				*prepareRecP = prepCBRecP->prepareRecP;
	MySQLRec				*mysqlRecP = prepCBRecP->mysqlRecP;
	int						failed;
	my_bool					set = true;
	CStr63					curCall;
	
	cursorP->curPos = 1;
	cursorP->cursorMode = (Byte)prepareRecP->cursorMode;	
	CEquStr(curCall, "mysql_stmt_init");
	if (cursorP->mysql_stmt = mysql_stmt_init_EP(mysqlRecP->connection))
	{	CEquStr(curCall, "mysql_stmt_prepare");
		if (failed = mysql_stmt_prepare_EP(cursorP->mysql_stmt, prepareRecP->sqlStringP, prepareRecP->sqlStringLen))
		{	mysql_stmt_free_result_EP(cursorP->mysql_stmt);
			cursorP->mysql_stmt = 0;
		}
		else
		{	// Update metadata MYSQL_FIELD->max_length in mysql_stmt_store_result().
			mysql_stmt_attr_set_EP(cursorP->mysql_stmt, STMT_ATTR_UPDATE_MAX_LENGTH, &set);
		}
	}
	else
		failed = 1;
	if (failed)
	{	err = mysql_errno_EP(mysqlRecP->connection);
		_mySQLSetError(&err, mysqlRecP, cursorP, curCall, error);
		//CEquStr(error, (char*)mysql_error_EP(mysqlRecP->connection));
	}
	
	return err;
}

//===========================================================================================
static XErr	_Prepare(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
PrepareRec			*prepareRecP = &pbPtr->param.prepareRec;
PrepareCallBackRec	prepCBRec;
PrepareParams		params;

	if (prepareRecP->cursorMode == kDynamic)
		err = XError(kBAPI_ClassError, ErrBadCursorMode);
	else
	{	params.sqlStringP = prepareRecP->sqlStringP;
		params.sqlStringLen = prepareRecP->sqlStringLen;
		params.totCursors = prepareRecP->totCursors;
		//params.cursorMode = prepareRecP->cursorMode;
		params.userData = (long)mysqlRecP;
		prepCBRec.prepareRecP = prepareRecP;
		prepCBRec.mysqlRecP = mysqlRecP;
		if NOT(err = bdbRec.BDBAPI_NewPrepare(pbPtr->api_data, pbPtr->db_api_data, &params, _PrepareOneCursor, (long)&prepCBRec, pbPtr->error))
			prepareRecP->prepareID = params.prepareID;
	}
	
return err;
}

//===========================================================================================
static XErr	_FreePrepare(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
FreePrepareRec		*freePrepareRecP = &pbPtr->param.freePrepareRec;

	err = bdbRec.BDBAPI_DisposePrepare(pbPtr->api_data, pbPtr->db_api_data, freePrepareRecP->prepareID, _FreePreparedCursor, (long)mysqlRecP, pbPtr->error);
	
return err;
}

//===========================================================================================
static XErr	_GetPrepared(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
//MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
GetPreparedRec		*getPreparedRecP = &pbPtr->param.getPreparedRec;
MySQLCursorRec		*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetPreparedCursor(pbPtr->api_data, pbPtr->db_api_data, getPreparedRecP->prepareID, &getPreparedRecP->cursorID, (Ptr*)&cursorP))
	{	cursorP->prepared = true;
		cursorP->curPos = 1;
		cursorP->param_count = mysql_stmt_param_count_EP(cursorP->mysql_stmt);
	}

return err;
}

//===========================================================================================
static XErr	_BindOneCursor(MySQLRec *mysqlRecP, MySQLCursorRec *cursorP, long paramNum, long paramMode, long paramStorage, char *paramObjName, char *error)
{	
XErr					err = noErr;
BlockRef				storageBlock;
BDBAPI_ParameterDescr	*paramP, *paramDescrP;
long					paramNumZB = paramNum - 1;
MYSQL_BIND				*bindP;

	if (paramNum > MAX_PARAMETERS)
		_mySQLSetError(&err, mysqlRecP, cursorP, "_BindOneCursor: Invalid Param Num", error);	
	else if (cursorP->params[paramNumZB])	// exists
	{	paramDescrP = (BDBAPI_ParameterDescr*)GetPtr(cursorP->params[paramNumZB]);
		if (paramDescrP->valueBlock)
			DisposeBlock(&paramDescrP->valueBlock);
		DisposeBlock(&cursorP->params[paramNumZB]);
		cursorP->param_bound--;
	}
	if NOT(err)
	{	if (storageBlock = NewPtrBlock(sizeof(BDBAPI_ParameterDescr), &err, (Ptr*)&paramP))
		{	ClearBlock(paramP, sizeof(BDBAPI_ParameterDescr));
			paramP->valueStorage = paramP->length = paramStorage + 1;
			paramP->mode = paramMode;
			if (paramP->valueBlock = NewPtrBlock(paramP->valueStorage, &err, (Ptr*)&paramP->valueP))
			{	if (cursorP->param_bound < MAX_PARAMETERS)
				{	if (paramP->length >= MAX_ALLOWED_PACKET)
						cursorP->sendLongData = true;
					CEquStr(paramP->name, paramObjName);
					cursorP->params[paramNumZB] = storageBlock;
					cursorP->param_bound++;
					bindP = &cursorP->bindParams[paramNumZB];
					bindP->buffer_type= MYSQL_TYPE_STRING;
					bindP->buffer= paramP->valueP;
					bindP->buffer_length = paramP->valueStorage;
					bindP->is_null= 0;
					bindP->length = (unsigned long *)&paramP->length;
					if (cursorP->param_bound == cursorP->param_count)
					{	if (mysql_stmt_bind_param_EP(cursorP->mysql_stmt, cursorP->bindParams))
							_mySQLSetError(&err, mysqlRecP, cursorP, "_BindOneCursor: mysql_stmt_bind_param failed", error);
					}
				}
				else
					_mySQLSetError(&err, mysqlRecP, cursorP, "_BindOneCursor: Too many parameters", error);
				if (err)
					DisposeBlock(&paramP->valueBlock);
			}
			if (err)
				DisposeBlock(&storageBlock);
		}
	}
	
return err;
}

typedef struct {
				MySQLRec	*mysqlRecP;
				BindRec		*bindRecP;
				} BindRecord;

//===========================================================================================
static XErr	_BindOneCursorCB(long api_data, long db_api_data, Ptr cursorP, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(api_data)
#endif
BindRecord		*bindRecordP = (BindRecord*)userData;
BindRec			*bindRecP = bindRecordP->bindRecP;

	return _BindOneCursor(bindRecordP->mysqlRecP, (MySQLCursorRec*)cursorP, bindRecP->paramNum, bindRecP->paramMode, bindRecP->paramStorage, bindRecP->paramObjName, error);
}

//===========================================================================================
static XErr	_Bind(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
BindRec				*bindRecP = &pbPtr->param.bindRec;
MySQLCursorRec		*cursorP;
//long 				api_data = pbPtr->api_data;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, bindRecP->cursorID, (Ptr*)&cursorP))
		err = _BindOneCursor(mysqlRecP, cursorP, bindRecP->paramNum, bindRecP->paramMode, bindRecP->paramStorage, bindRecP->paramObjName, pbPtr->error);

return err;
}

//===========================================================================================
static XErr	_BindAll(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
MySQLRec		*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
BindRec			*bindRecP = &pbPtr->param.bindRec;
BindRecord		bindRecord;

	bindRecord.mysqlRecP = mysqlRecP;
	bindRecord.bindRecP = bindRecP;
	err = bdbRec.BDBAPI_PrepareLoop(pbPtr->api_data, pbPtr->db_api_data, bindRecP->prepareID, _BindOneCursorCB, (long)&bindRecord, pbPtr->error);
	
return err;
}

//===========================================================================================
// 1153 == Got a packet bigger than 'max_allowed_packet' bytes
static XErr	_SendPreparedQuery(MySQLRec *mysqlRecP, MySQLCursorRec *cursorP, Boolean canSendLongData, char *error)
{
XErr					err = noErr;
int						tot, chunkLen, index;
BlockRef				tBl;
Boolean					failed;
Ptr						vData;
long					vLen;
BDBAPI_ParameterDescr	*paramP;

	if (cursorP->sendLongData)
	{	index = 0;
		tot = MAX_PARAMETERS;
		do 
		{	if (tBl = cursorP->params[index])
			{	paramP = (BDBAPI_ParameterDescr*)GetPtr(tBl);
				if ((paramP->mode == kInputBindMode) || (paramP->mode == kInputOutputBindMode))
				{	vData = paramP->valueP;
					vLen = paramP->length;
					if (vLen > MAX_ALLOWED_PACKET)
					{	while ((vLen > 0) && NOT(err))
						{	if (vLen >= MAX_ALLOWED_PACKET)
								chunkLen = MAX_ALLOWED_PACKET;
							else
								chunkLen = vLen;
							if (failed = mysql_stmt_send_long_data_EP(cursorP->mysql_stmt, index, vData, chunkLen))
								_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_stmt_send_long_data", error);
							else
							{	vData += chunkLen;
								vLen -= chunkLen;
							}
						}
					}
				}
			}
			index++;
		} while (--tot && NOT(err));
	}
	if (mysql_stmt_execute_EP(cursorP->mysql_stmt))
		_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_stmt_execute", error);
	
return err;
}

//===========================================================================================
static Boolean 	_IsParamNull(BDBAPI_ParameterDescr *paramP, long index, long userData)
{
MYSQL_BIND			*bindP;
MySQLCursorRec		*cursorP = (MySQLCursorRec*)userData;

	bindP = &cursorP->bindParams[index];

return *bindP->is_null;
}

//===========================================================================================
static XErr	_ExecPrepared(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
ExecPreparedRec		*execPreparedRecP = &pbPtr->param.execPreparedRec;
MySQLCursorRec		*cursorP;
long				api_data = pbPtr->api_data;
long				db_api_data = pbPtr->db_api_data;
Boolean				hasInputParams;
char				*error = pbPtr->error;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, execPreparedRecP->cursorID, (Ptr*)&cursorP))
	{	if (cursorP->param_bound < cursorP->param_count)
		{	_mySQLSetError(&err, mysqlRecP, cursorP, "_ExecPrepared: some parameters were not bound", error);
			return err;
		}
		if NOT(err = bdbRec.BDBAPI_FlushParamsInputs(api_data, db_api_data, cursorP->params, cursorP->param_bound, error, &hasInputParams))
		{	if NOT(err = _SendPreparedQuery(mysqlRecP, cursorP, hasInputParams, error))
			{	if (mysql_stmt_store_result_EP(cursorP->mysql_stmt))
					_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_stmt_store_result", error);
				else
				{	if (cursorP->mysql_res = mysql_stmt_result_metadata_EP(cursorP->mysql_stmt))
						err = _mySQLDescribeColumns(mysqlRecP, cursorP, error, true);
					if NOT(err)
						err = bdbRec.BDBAPI_LoadParamsOutputs(api_data, db_api_data, cursorP->params, cursorP->param_bound, _IsParamNull, (long)cursorP, error, nil);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_BeginTran(BDBAPI_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
MySQLRec	*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;

	if (mysql_autocommit_EP(mysqlRecP->connection, false))
		_mySQLSetError(&err, mysqlRecP, nil, "mysql_autocommit", pbPtr->error);
	
return err;
}

//===========================================================================================
static XErr	_EndTran(BDBAPI_ParamBlockPtr pbPtr, Boolean toCommit)
{
XErr		err = noErr;
MySQLRec	*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
my_bool		res;

	if (toCommit)
		res = mysql_commit_EP(mysqlRecP->connection);
	else
		res = mysql_rollback_EP(mysqlRecP->connection);
	if NOT(res)
		res = mysql_autocommit_EP(mysqlRecP->connection, true);
	if (res)
		_mySQLSetError(&err, mysqlRecP, nil, "mysql_autocommit", pbPtr->error);
		
return err;
}

#endif

#ifdef __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_Connect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
MySQLRec		*mysqlRecP;
BlockRef		connBlock;
ConnectRec		*connectRecP = &pbPtr->param.connectRec;
unsigned long	client_flag;

	connBlock = 0;
	if (connBlock = NewBlockLocked(sizeof(MySQLRec), &err, (Ptr*)&mysqlRecP))
	{	ClearBlock(mysqlRecP, sizeof(MySQLRec));
		if NOT(err = _mySQLTokenizeConnString(connectRecP->connString, connectRecP->connStringLen, mysqlRecP))
		{	XThreadsEnterCriticalSection();
			if (mysqlRecP->connection = mysql_init_EP(NULL))
			{	
			#ifdef _41
				client_flag = CLIENT_MULTI_STATEMENTS;		// then you should use mysql_next_result (delayed until future versions)
			#else
				client_flag = 0;
			#endif				
				if (mysql_real_connect_EP(mysqlRecP->connection, mysqlRecP->host, mysqlRecP->user, mysqlRecP->password, mysqlRecP->db, mysqlRecP->port, NULL, client_flag))
				{	UnlockBlock(connBlock);
					connectRecP->connBufferLength = sizeof(MySQLRec);
					connectRecP->connBuffer = connBlock;
					connectRecP->connPointer = (Ptr)mysqlRecP;
				}
				else
				{	err = mysql_errno_EP(mysqlRecP->connection);
					_mySQLSetError(&err, mysqlRecP, nil, "mysql_real_connect", pbPtr->error);
					mysql_close_EP(mysqlRecP->connection);
				}
			}
			else
				_mySQLSetError(&err, nil, nil, "mysql_init", pbPtr->error);
			XThreadsLeaveCriticalSection();
		}	
	}
	if (err && connBlock)
		DisposeBlock(&connBlock);

return err;
}

//===========================================================================================
static XErr	_Disconnect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
MySQLRec		*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
DisconnectRec	*disconnectRecP = &pbPtr->param.disconnectRec;

	err = bdbRec.BDBAPI_DisposeAllCursorsSlots(pbPtr->api_data, pbPtr->db_api_data, _CloseNormalCursor, 0, pbPtr->error);
#ifdef _41
	if (okPrepare)
		err = bdbRec.BDBAPI_DisposeAllPrepares(pbPtr->api_data, pbPtr->db_api_data, _FreePreparedCursor, (long)mysqlRecP, pbPtr->error);
#endif
	mysql_close_EP(mysqlRecP->connection);
	DisposeBlock(&disconnectRecP->connBuffer);
	
return err;
}

//===========================================================================================
static XErr	_FetchRec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
MySQLCursorRec		*cursorP;
ObjRef				tObjRef, arrayObjRef;
MYSQL_ROW			row;
int					i, totFields;
long				api_data = pbPtr->api_data;
MySQLColumnDescr	*colDescrP;
Boolean				undefNull;
unsigned long		*lengtshArrayP;
CStr255				aCStr;
CStr15				tStr;
int					index, titleLen;
#ifdef _41
	int				res;
#endif

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(api_data, pbPtr->db_api_data, pbPtr->param.fetchRec.cursorID, (Ptr*)&cursorP))
	{	arrayObjRef = pbPtr->param.fetchRec.object;
		if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &arrayObjRef))
		{
		#ifdef _41
			if (cursorP->prepared)
			{	if (cursorP->mysql_stmt)
				{	res = mysql_stmt_fetch_EP(cursorP->mysql_stmt);
					if (res == MYSQL_NO_DATA)
						cursorP->endOfSet = true;
					else if (res)
						_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_stmt_fetch", pbPtr->error);
				}
				else
					_mySQLSetError(&err, mysqlRecP, cursorP, "_FetchRec: Invalid statement", pbPtr->error);
			}
			else
		#endif
			{	if (cursorP->mysql_res)
				{	if NOT(row = mysql_fetch_row_EP(cursorP->mysql_res))
						cursorP->endOfSet = true;
				}
				else
					_mySQLSetError(&err, mysqlRecP, cursorP, "_FetchRec: Invalid result set (query was not a select)", pbPtr->error);
			}
			if (NOT(err) && NOT(cursorP->endOfSet))
			{	cursorP->curPos++;
				totFields = cursorP->totFields;
				colDescrP = &cursorP->columnDescrP[0];
				undefNull = pbPtr->param.fetchRec.undefNull;
				if NOT(cursorP->prepared)
				{	if NOT(lengtshArrayP = mysql_fetch_lengths_EP(cursorP->mysql_res))
						_mySQLSetError(&err, mysqlRecP, cursorP, "_FetchRec: mysql_fetch_lengths failed", pbPtr->error);
				}
				if NOT(err)
				{	for (i = 0; (i < totFields) && NOT(err); i++, colDescrP++, lengtshArrayP++)
					{	BAPI_InvalObjRef(api_data, &tObjRef);	// set NULL
						if (cursorP->prepared)
						{
						#ifdef _41
							MYSQL_BIND *bindP = &cursorP->bindArray[i];
							if (colDescrP->length)
								err = BAPI_StringToObj(api_data, bindP->buffer, colDescrP->length, &tObjRef);
							else
							{	if (colDescrP->is_null && undefNull)
									err = BAPI_StringToObj(api_data, DB_NULL_VALUE, DB_NULL_VALUE_LEN, &tObjRef);
								else
									err = BAPI_StringToObj(api_data, "", 0, &tObjRef);
							}
						#endif
						}
						else
						{	if (row[i])
								err = BAPI_StringToObj(api_data, row[i], *lengtshArrayP, &tObjRef);
							else
							{	if (undefNull)
									err = BAPI_StringToObj(api_data, DB_NULL_VALUE, DB_NULL_VALUE_LEN, &tObjRef);
								else
									err = BAPI_StringToObj(api_data, "", 0, &tObjRef);
							}
						}
						if NOT(err)
						{	err = BAPI_ArrayAddElement(api_data, &arrayObjRef, colDescrP->title, &tObjRef);
							if (err && (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName)))
							{	index = 2;
								titleLen = CLen(colDescrP->title);
								do {
									CNumToString(index++, tStr);
									if ((titleLen + 1 + CLen(tStr)) < 255)
									{	CEquStr(aCStr, colDescrP->title);
										CAddStr(aCStr, "_");
										CAddStr(aCStr, tStr);
										err = BAPI_ArrayAddElement(api_data, &arrayObjRef, aCStr, &tObjRef);
									}
									else
									{	err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
										break;
									}
								} while (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName));
							}
						}
					}
				}
			}
			if NOT(err)
				pbPtr->param.fetchRec.object = arrayObjRef;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_Exec(BDBAPI_ParamBlockPtr pbPtr)
{
int					state;
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
ExecRec				*execRecP = &pbPtr->param.execRec;
MySQLCursorRec		*cursorP, cursoOnStack;
CStr255				funcName;

	if (execRecP->dontReturnCursor)
	{	cursorP = &cursoOnStack;
		ClearBlock(cursorP, sizeof(MySQLCursorRec));
	}
	else
		err = bdbRec.BDBAPI_NewCursorSlot(pbPtr->api_data, pbPtr->db_api_data, &execRecP->cursorID, (Ptr*)&cursorP);
	if (err)
		return err;
	if NOT(state = mysql_query_EP(mysqlRecP->connection, execRecP->sqlStringP))
	{	if ((execRecP->cursorMode == kStatic) || (execRecP->cursorMode == kDefault))
		{	CEquStr(funcName, "mysql_store_result");
			cursorP->mysql_res = mysql_store_result_EP(mysqlRecP->connection);
		}
		else
		{	CEquStr(funcName, "mysql_use_result");
			cursorP->mysql_res = mysql_use_result_EP(mysqlRecP->connection);
		}
		if (cursorP->mysql_res)
		{	if NOT(err = _mySQLDescribeColumns(mysqlRecP, cursorP, pbPtr->error, false))
			{	cursorP->cursorMode = (Byte)execRecP->cursorMode;
				cursorP->curPos = 1;
			}
			else
				mysql_free_result_EP(cursorP->mysql_res);
		}
		else
		{	err = mysql_errno_EP(mysqlRecP->connection);
			if (err)
				_mySQLSetError(&err, mysqlRecP, cursorP, funcName, pbPtr->error);
		}
	}
	else
	{	err = mysql_errno_EP(mysqlRecP->connection);
		_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_query", pbPtr->error);
	}
	if (execRecP->dontReturnCursor && NOT(err))
		_CloseNormalCursor(pbPtr->api_data, pbPtr->db_api_data, (Ptr)cursorP, 0, pbPtr->error);
	else if (err && NOT(execRecP->dontReturnCursor))
		bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, execRecP->cursorID, nil, 0, pbPtr->error);	// free the slot
		
return err;
}

//===========================================================================================
static XErr	_RealEscape(BDBAPI_ParamBlockPtr pbPtr)
{
char			*strToEncodeP, *strEncodedP;
XErr			err = noErr;
BlockRef		bl;
long 			api_data = pbPtr->api_data;
unsigned long	strEncodedLength;
long			strToEncodeLength;
MySQLRec		*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
RealEscapeRec	*realEscapeRecP = &pbPtr->param.realEscapeRec;

	if (/*mysql_real_escape_string_EP &&*/ NOT(realEscapeRecP->unescape))
	{	strToEncodeLength = realEscapeRecP->stringLen;
		strToEncodeP = realEscapeRecP->stringP;
		if (bl = NewBlockLocked((strToEncodeLength * 2) + 1, &err, &strEncodedP))
		{	strEncodedLength = mysql_real_escape_string_EP(mysqlRecP->connection, strEncodedP, strToEncodeP, strToEncodeLength); 
			err = BAPI_StringToObj(api_data, strEncodedP, strEncodedLength, &realEscapeRecP->resultObj);
			DisposeBlock(&bl);
		}
	}
	else
		err = XError(kBAPI_Error, Err_NotImplemented);

return err;
}

//===========================================================================================
static XErr	_FreeCursor(long api_data, long db_api_data, Ptr cursorP, long userData, char *error)
{
XErr			err = noErr;
MySQLRec		*mysqlRecP = (MySQLRec*)userData;

	#ifdef _41
		if (((MySQLCursorRec*)cursorP)->prepared)
			err = _ClosePreparedCursor(api_data, db_api_data, (Ptr)cursorP, (long)mysqlRecP, error);
		else
	#endif
			err = _CloseNormalCursor(api_data, db_api_data, (Ptr)cursorP, (long)mysqlRecP, error);
	
return err;
}

//===========================================================================================
static XErr	_Free(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
FreeResultRec	*freeResultRecP = &pbPtr->param.freeResultRec;
MySQLRec		*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;

	err = bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, _FreeCursor, (long)mysqlRecP, pbPtr->error);	// free the slot

	/*if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, (Ptr*)&cursorP))
	{
	#ifdef _41
		if (cursorP->prepared)
			err = _ClosePreparedCursor(pbPtr->api_data, pbPtr->db_api_data, (Ptr)cursorP, (long)mysqlRecP, pbPtr->error);
		else
	#endif
			err = _CloseNormalCursor(pbPtr->api_data, pbPtr->db_api_data, (Ptr)cursorP, (long)mysqlRecP, pbPtr->error);
		if NOT(err)
			err = bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, nil, 0, pbPtr->error);	// free the slot
	}*/
	
return err;
}

//===========================================================================================
static XErr	_GetAffectedRecs(BDBAPI_ParamBlockPtr pbPtr)
{
	XErr				err = noErr;	//, err2 = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
GetAffectedRecsRec	*getAffectedRecsRecP = &pbPtr->param.getAffectedRecsRec;
MySQLCursorRec		*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getAffectedRecsRecP->cursorID, (Ptr*)&cursorP))
	{	if (cursorP->cursorMode == kDynamic)
			_mySQLSetError(&err, mysqlRecP, cursorP, "GetAffectedRecs incompatible with dynamic cursor", pbPtr->error);
		else
		{
		#ifdef _41
			if (cursorP->prepared)
				getAffectedRecsRecP->affectedRecs = (long)mysql_stmt_affected_rows_EP(cursorP->mysql_stmt);
			else
		#endif
				getAffectedRecsRecP->affectedRecs = (long)mysql_affected_rows_EP(mysqlRecP->connection);
			if (err = mysql_errno_EP(mysqlRecP->connection))
				_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_affected_rows", pbPtr->error);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetCurRecs(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
MySQLCursorRec		*cursorP;
GetCurRecsRec		*getCurRecsRecP = &pbPtr->param.getCurRecsRec;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getCurRecsRecP->cursorID, (Ptr*)&cursorP))
	{	if ((cursorP->cursorMode == kDynamic) && NOT(cursorP->endOfSet))
			_mySQLSetError(&err, mysqlRecP, cursorP, "GetCurRecs on dynamic cursor works only after fetching all rows", pbPtr->error);
		else
		{
		#ifdef _41
			if (cursorP->prepared)
				getCurRecsRecP->curRecs = (long)mysql_stmt_num_rows_EP(cursorP->mysql_stmt);
			else
		#endif
				getCurRecsRecP->curRecs = (long)mysql_num_rows_EP(cursorP->mysql_res);
			if (err = mysql_errno_EP(mysqlRecP->connection))
				_mySQLSetError(&err, mysqlRecP, cursorP, "mysql_num_rows_EP", pbPtr->error);
		}
	}

return err;
}

//===========================================================================================
static XErr	_SeekTell(BDBAPI_ParamBlockPtr pbPtr, long which)
{
XErr				err = noErr;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;
MySQLCursorRec		*cursorP;
int					cursID;

	if (which == kSeek)
		cursID = pbPtr->param.seekRec.cursorID;
	else
		cursID = pbPtr->param.tellRec.cursorID;
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, cursID, (Ptr*)&cursorP))
	{	if (which == kSeek)
		{	if (cursorP->cursorMode == kDynamic)
			{	_mySQLSetError(&err, mysqlRecP, cursorP, "Seek incompatible with dynamic cursors", pbPtr->error);
				goto out;
			}
			else
			{
			#ifdef _41
				if (cursorP->prepared)
					mysql_stmt_data_seek_EP(cursorP->mysql_stmt, pbPtr->param.seekRec.pos-1);
				else
			#endif
					mysql_data_seek_EP(cursorP->mysql_res, pbPtr->param.seekRec.pos-1);
				if NOT(err = mysql_errno_EP(mysqlRecP->connection))
					cursorP->curPos = pbPtr->param.seekRec.pos;
			}
		}
		else
		{	pbPtr->param.tellRec.pos = cursorP->curPos;
			err = mysql_errno_EP(mysqlRecP->connection);
		}
		if (err)
			_mySQLSetError(&err, mysqlRecP, cursorP, "_SeekTell", pbPtr->error);
	}

out:
return err;
}

//===========================================================================================
static XErr	_GetSpecific(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetSpecificRec		*getSpecificRecP = &pbPtr->param.getSpecificRec;
MySQLRec			*mysqlRecP = (MySQLRec*)pbPtr->connBufferPtr;

	if NOT(CCompareStrings_cs(getSpecificRecP->name, "CLIENT_INFO"))
	{	CEquStr(getSpecificRecP->value, (char*)mysql_get_client_info_EP());
		CAddStr(getSpecificRecP->value, " (bfr extension compiled with ");
		CAddStr(getSpecificRecP->value, MYSQL_SERVER_VERSION);
		CAddStr(getSpecificRecP->value, " headers)");
	}
	else if NOT(CCompareStrings_cs(getSpecificRecP->name, "SERVER_INFO"))
		CEquStr(getSpecificRecP->value, (char*)mysql_get_server_info_EP(mysqlRecP->connection));
	else
		err = XError(kBAPI_ClassError, ErrUnknownSpecific);
	
return err;
}

//===========================================================================================
static XErr	_MySQLMapFetch(long cursorAddress, long *polyIDP, double *valueP, Boolean *isNullP)
{
XErr				err = noErr;
MySQLCursorRec		*cursorP = (MySQLCursorRec*)cursorAddress;
MYSQL_ROW			row;
unsigned long		*lengtshArrayP;
CStr31				aCStr;
int					t;
void				*p;

	if (cursorP->totFields >= 2)
	{	if (row = mysql_fetch_row_EP(cursorP->mysql_res))
		{	cursorP->curPos++;
			if (lengtshArrayP = mysql_fetch_lengths_EP(cursorP->mysql_res))
			{	if (p = row[0])
				{	t = lengtshArrayP[0];
					if (t < 32)
					{	CopyBlock(aCStr, p, t);
						aCStr[t] = 0;
						CStringToNum(aCStr, polyIDP);
					}
					else
						*polyIDP = 0;
				}
				if (p = row[1])
				{	t = lengtshArrayP[1];
					if (t < 32)
					{	CopyBlock(aCStr, p, t);
						if (t)
						{	aCStr[t] = 0;
							*valueP = CStrToReal(aCStr);
						}
						else
						{	*valueP = 0;
							*isNullP = false;
						}
					}
					else
					{	*valueP = 0;
						*isNullP = false;
					}
				}
				else
				{	*valueP = 0;
					*isNullP = true;
				}
			}
		}
		else
			cursorP->endOfSet = true;
	}
	else
	{	*polyIDP = 0;
		*valueP = 0;
	}
	
return err;
}

#ifdef __MWERKS__
#pragma mark-
#pragma export on
#endif
XErr MySQL_BDBAPI_Dispatch(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr);
//===========================================================================================
XErr MySQL_BDBAPI_Dispatch(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kConnect:
			err = _Connect(pbPtr);
			break;
		case kDisconnect:
			err = _Disconnect(pbPtr);
			break;
		case kExec:
			err = _Exec(pbPtr);
			break;
	#ifdef _41
		case kCall:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kCallExt:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kPrepare:
			if (okPrepare)
				err = _Prepare(pbPtr);
			else
				err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kFreePrepare:
			if (okPrepare)
				err = _FreePrepare(pbPtr);
			else
				err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kRowSetSize:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kGetPrepared:
			if (okPrepare)
				err = _GetPrepared(pbPtr);
			else
				err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kBind:
			if (okPrepare)
				err = _Bind(pbPtr);
			else
				err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kBindAll:
			if (okPrepare)
				err = _BindAll(pbPtr);
			else
				err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kExecPrepared:
			if (okPrepare)
				err = _ExecPrepared(pbPtr);
			else
				err = XError(kBAPI_Error, Err_NotImplemented);
			break;
	#else
		case kCall:
		case kCallExt:
		case kPrepare:
		case kFreePrepare:
		case kRowSetSize:
		case kGetPrepared:
		case kBind:
		case kBindAll:
		case kExecPrepared:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
	#endif
		case kFreeResult:
			err = _Free(pbPtr);
			break;
		case kSeek:
			err = _SeekTell(pbPtr, message);
			break;
		case kTell:
			err = _SeekTell(pbPtr, message);
			break;
		case kWarning:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kGetCurRecs:
			err = _GetCurRecs(pbPtr);
			break;
		case kGetAffectedRecs:
			err = _GetAffectedRecs(pbPtr);
			break;
		case kFetchRec:
			err = _FetchRec(pbPtr);
			break;
	#ifdef _41
		case kTransaction:
			err = _BeginTran(pbPtr);
			break;
		case kCommit:
			err = _EndTran(pbPtr, true);
			break;
		case kRollBack:
			err = _EndTran(pbPtr, false);
			break;
	#else
		case kTransaction:
		case kCommit:
		case kRollBack:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
	#endif
		case kRealEscape:
		case kRealUnescape:
			err = _RealEscape(pbPtr);
			break;
		case kGetSpecific:
			err = _GetSpecific(pbPtr);
			break;
		case kSetSpecific:
		case kLobWrite:
		case kLobRead:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		default:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
	}

return err;
}
#ifdef __MWERKS__
#pragma export off
#pragma mark-
#endif
//===========================================================================================
static XErr	MySQL_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#ifdef __MWERKS__
#pragma unused(pbPtr)
#endif

#if __UNIX_XLIB__ || __MACOSX__
	if (gMySQLDllRef)
		XFreeDLL(&gMySQLDllRef, false);
#endif

return noErr;
}

//===========================================================================================
static XErr	InitCallBacks(long api_data, BDBAPI_Rec *theRecP)
{
XErr					err = noErr;
BDBAPI_Init_CallBack	BDBAPI_Init_EP;

	if NOT(err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, "db", false), "BDBAPI_Init", (long*)&BDBAPI_Init_EP))
		err = BDBAPI_Init_EP(&bdbRec);

return err;
}

//===========================================================================================
static XErr	MySQL_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
long					api_data = pbPtr->api_data;

	if NOT(err = _mySQLLoadFuncs(pbPtr))
	{	if NOT(err = InitCallBacks(api_data, &bdbRec))
			if NOT(err = bdbRec.BDBAPI_Register("mysql", MySQL_BDBAPI_Dispatch, sizeof(MySQLCursorRec), true))
				err = BAPI_RegisterSymbol(pbPtr->api_data, mySQLClassID, "MapFetch", (long)_MySQLMapFetch);
	}

return err;
}

#ifdef __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	_mysql_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
#ifdef __MWERKS__
#pragma unused(pbPtr)
#endif
XErr				err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchMethod);

return err;
}

#ifdef __MWERKS__
#pragma export on
#endif
//===========================================================================================
#ifdef MYSQL_BUILT_IN
	XErr	mysql_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#else
	XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#endif
{
XErr		err = noErr;
char		*strP;
CStr63		mySQLHeaderVersStr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, MySQLClassName);
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft mysql (");
			CEquStr(mySQLHeaderVersStr, MYSQL_SERVER_VERSION);
			if (strP = strchr(mySQLHeaderVersStr, '.'))
			{	*strP = 0;
				CAddStr(mySQLHeaderVersStr, ".x");
			}
			CAddStr(pbPtr->param.registerRec.pluginDescr, mySQLHeaderVersStr);
			CAddStr(pbPtr->param.registerRec.pluginDescr, ") native support");
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			gsApiVersion = pbPtr->param.registerRec.api_version;
			mySQLClassID = pbPtr->param.registerRec.pluginID;
			break;
		case kInit:
			err = MySQL_Init(pbPtr);
			break;
		case kShutDown:
			err = MySQL_ShutDown(pbPtr);
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = _mysql_ExecuteMethod(pbPtr);
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteFunction:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#ifdef __MWERKS__
#pragma export off
#endif
