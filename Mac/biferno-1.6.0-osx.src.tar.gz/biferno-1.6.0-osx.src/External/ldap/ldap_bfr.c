/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: ldap_bfr.c,v 1.2 2004-10-11 14:58:22 valfer Exp $
	|______________________________________________________________________________
*/
/** @file
*
*	Valerio Ferrucci
*/

#include "BifernoAPI.h"
#include "BfrVersion.h"

#include "ldap.h"

#include <errno.h>

static unsigned long 	gsApiVersion;
static long 			gsLdapClassID;

#define	MAX_RESULTS	32
typedef struct {
				LDAPMessage 	*message;
				Boolean			busy;
				Byte			pad1;
				short			pad2;
				} LdapResult, *LdapResultP;

typedef struct {
				CStr255			hostName;
				long			portNumber;
				LDAP			*conn;
				long			lastResultIdx;
				long			totResults;
				LdapResult		result[MAX_RESULTS];
				} LDAPRec, *LDAPRecP;

#define	LDAP_DEFAULT_PORT	LDAP_PORT

// Methods
#define TOT_METHODS 2
enum {
		kSearch = 1,
		kFree
};

// Errors
#define	START_ERR	100
enum {
		ErrLdapBindError = START_ERR,
		ErrLdapSearchError,
		ErrTooManyResults,
		ErrLdapNoSuchResult,
		ErrLdapResultNotAllocated
};
static CStr63	gsLdapErrorsStr[] = 
  {	
    "ErrLdapBindError",
    "ErrLdapSearchError",
    "ErrTooManyResults",
    "ErrLdapNoSuchResult",
    "ErrLdapResultNotAllocated"
  };
#define	TOT_ERRORS	5

// Constants
#define TOT_COSTANTS 4
enum {
	kLDAP_SCOPE_DEFAULT = LDAP_SCOPE_DEFAULT,
	kLDAP_SCOPE_BASE = LDAP_SCOPE_BASE,
	kLDAP_SCOPE_ONELEVEL = LDAP_SCOPE_ONELEVEL,
	kLDAP_SCOPE_SUBTREE = LDAP_SCOPE_SUBTREE
};

//===========================================================================================
static XErr	_ldapGetError(void)
{
	return errno;
}

//===========================================================================================
// index is 1-based
static XErr	_ldapUpdateObject(long api_data, ObjRefP objRefP, int index, LDAPRec *ldapRecP)
{
XErr		err = noErr;
long		tLen;

	tLen = offsetof(LDAPRec, result) + (index * sizeof(LdapResult));
	err = BAPI_WriteObj(api_data, objRefP, ldapRecP, tLen, 1);

return err;
}

//===========================================================================================
static XErr	_ldapGetResultPointer(LDAPRec *ldapRecP, long *indexP, LdapResult	**resultP)
{
XErr	err = noErr;
long	index = *indexP;

	if (index < 0)
		index = ldapRecP->lastResultIdx;
	if ((index > 0) && (index <= MAX_RESULTS))
	{	*resultP = &ldapRecP->result[index - 1];
		if NOT((*resultP)->busy)
			err = XError(kBAPI_ClassError, ErrLdapResultNotAllocated);
		else
			*indexP = index;
	}
	else
		err = XError(kBAPI_ClassError, ErrLdapNoSuchResult);

return err;
}

//===========================================================================================
static XErr	_ldapFree(long api_data, ExecuteMethodRec *exeMethodRecP, LDAPRec *ldapRecP, char *error)
{
XErr			err = noErr;
ParameterRec 	*paramVarsP = exeMethodRecP->paramVarsP;
long			index;
LdapResult		*resultP;
LDAPMessage 	*saveMessage = nil;

	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[0].objRef, &index, kImplicitTypeCast))
	{	if NOT(err = _ldapGetResultPointer(ldapRecP, &index, &resultP))
		{	XThreadsEnterCriticalSection();
			resultP->busy = false;
			ldapRecP->totResults--;
			if NOT(err = _ldapUpdateObject(api_data, &exeMethodRecP->objRef, index, ldapRecP))
				ldap_msgfree(resultP->message);
			XThreadsLeaveCriticalSection();
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_ldapSearch(long api_data, ExecuteMethodRec *exeMethodRecP, LDAPRec *ldapRecP, char *error)
{
int				rc;
XErr			err = noErr;
CStr255			aCStr, baseDN;
Ptr				stringP;
long			tLen, theScope, stringLen;
BlockRef		ref;
ParameterRec 	*paramVarsP = exeMethodRecP->paramVarsP;
int				i;
LdapResult		*resultP;
LDAPMessage 	*message = nil;

    if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, baseDN, nil, 256, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &theScope, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &paramVarsP[2].objRef, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
			{	rc = ldap_search_ext_s(ldapRecP->conn, baseDN, theScope, stringP, NULL, 0, NULL, NULL, LDAP_NO_LIMIT, LDAP_NO_LIMIT, &message);
      			if (rc == LDAP_SUCCESS)
       			{	XThreadsEnterCriticalSection();
       				resultP = &ldapRecP->result[0];
					for (i = 0; i < MAX_RESULTS; i++, resultP++)
					{	if NOT(resultP->busy)
							break;
					}
					if (i == MAX_RESULTS)
					{	CEquStr(error, "Too many searches (call 'Free(int result)' to dispose a search result)");
						err = XError(kBAPI_ClassError, ErrTooManyResults);
					}
					else
					{	resultP->busy = true;
						resultP->message = message;
						ldapRecP->totResults++;
						ldapRecP->lastResultIdx = ++i;
						if NOT(err = _ldapUpdateObject(api_data, &exeMethodRecP->objRef, i, ldapRecP))
						{	exeMethodRecP->sideEffect = true;
							err = BAPI_IntToObj(api_data, i, &exeMethodRecP->resultObjRef);
						}
					}
					XThreadsLeaveCriticalSection();
       			}
       			else
       			{	err = XError(kBAPI_ClassError, ErrLdapSearchError);
      				CEquStr(error, ldap_err2string(rc));
      			}
				BAPI_ReleaseBlock(&ref);
			}
		}
	}

if (err)
{	if (message)
		ldap_msgfree(message);
}	
return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	Ldap_Register(Biferno_ParamBlockPtr pbPtr)
{
CStr31	tStr;
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, "ldap");
	gsLdapClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.wantDestructor = true;
	pbPtr->param.registerRec.fixedSize = true;
	CEquStr(pbPtr->param.registerRec.constructor, "void ldap(string hostName, int portNumber=389, string dn, string pwd)");
	CEquStr(pbPtr->param.registerRec.pluginDescr, "Connect to LDAP server with Biferno (LDAP API ");
 	CNumToString(LDAP_API_VERSION, tStr);
	CAddStr(pbPtr->param.registerRec.pluginDescr, tStr);
	CAddStr(pbPtr->param.registerRec.pluginDescr, ")");
	VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
	if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
		CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
	
return err;
}

//===========================================================================================
static XErr	Ldap_Init(Biferno_ParamBlockPtr pbPtr)
{
long				api_data = pbPtr->api_data;
XErr				err = noErr;
BAPI_MemberRecord	ldapCostants[TOT_COSTANTS] = 
   {	"LDAP_SCOPE_DEFAULT", 		kLDAP_SCOPE_DEFAULT,	"int",
		"LDAP_SCOPE_BASE", 			kLDAP_SCOPE_BASE,		"int",
		"LDAP_SCOPE_ONELEVEL", 		kLDAP_SCOPE_ONELEVEL,	"int",
		"LDAP_SCOPE_SUBTREE", 		kLDAP_SCOPE_SUBTREE,    "int"
   };

BAPI_MemberRecord	ldapMethods[TOT_METHODS] = 
  {	
    "Search",	kSearch,		"int Search(string base, int scope, string filter)",
    "Free",		kFree,			"void Free(int index=-1)"
  };

	if (err = BAPI_NewMethods(api_data, gsLdapClassID, ldapMethods, TOT_METHODS, nil))
   		return err;
	if (err = BAPI_NewConstants(api_data, gsLdapClassID, ldapCostants, TOT_COSTANTS, nil))
  		return err;
	err = BAPI_RegisterErrors(api_data, gsLdapClassID, START_ERR, gsLdapErrorsStr, TOT_ERRORS);
	
return err;
}

//===========================================================================================
static XErr	Ldap_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr				err = noErr;
ConstructorRec		*constructorRecP = &pbPtr->param.constructorRec;
long				api_data = pbPtr->api_data;
LDAPRec				ldapRec;
ParameterRec		*paramVarsP;
int					rc, version;
CStr255				bindDN, bindPW;
Ptr					bindDNP, bindPWP;

	if (clone)
		err = XError(kBAPI_Error, Err_IllegalOperation); 
	else
    {	ClearBlock(&ldapRec, sizeof(LDAPRec));
    	paramVarsP = constructorRecP->varRecsP;
    	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, ldapRec.hostName, nil, 256, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &ldapRec.portNumber, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[2].objRef, bindDN, nil, 256, kImplicitTypeCast))
				{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[3].objRef, bindPW, nil, 256, kImplicitTypeCast))
					{	if NOT(ldapRec.portNumber)
							ldapRec.portNumber = LDAP_DEFAULT_PORT;
						if (ldapRec.conn = ldap_init(ldapRec.hostName, ldapRec.portNumber))
			      		{	version = LDAP_VERSION3;
							rc = ldap_set_option(ldapRec.conn, LDAP_OPT_PROTOCOL_VERSION, &version);
			      			if (rc == LDAP_SUCCESS)
				      		{	if (*bindDN)
				      				bindDNP = bindDN;
				      			else
				      				bindDNP = NULL;
				      			if (*bindPW)
				      				bindPWP = bindPW;
				      			else
				      				bindPWP = NULL;
				      			rc = ldap_simple_bind_s(ldapRec.conn, bindDNP, bindPWP);
				      			if (rc == LDAP_SUCCESS)
				      				err = BAPI_BufferToObj(api_data, (Ptr)&ldapRec, sizeof(LDAPRec), gsLdapClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
				      			else
				      			{	err = XError(kBAPI_ClassError, ErrLdapBindError);
				      				CEquStr(pbPtr->error, ldap_err2string(rc));
				      			}
				      		}
							else
							{	err = _ldapGetError();
								CEquStr(pbPtr->error, "ldap_set_option-LDAP_OPT_PROTOCOL_VERSION");
							}
						}
						else
						{	err = _ldapGetError();
							CEquStr(pbPtr->error, "ldap_init");
						}
					}
				}
			}
	    }
    }
 
return err;
}

//===========================================================================================
static XErr	Ldap_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
long			objLen;
LDAPRec			ldapRec;
int				i, rc;
LdapResult		*resultP;

	objLen = sizeof(LDAPRec);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&ldapRec, &objLen, 0, nil))
	{	if (objLen)
		{	XThreadsEnterCriticalSection();
			resultP = &ldapRec.result[0];
			for (i = 0; i < MAX_RESULTS; i++, resultP++)
			{	if (resultP->busy)
					 ldap_msgfree(resultP->message);
			}
			XThreadsLeaveCriticalSection();
		}
		rc = ldap_unbind(ldapRec.conn);
    }

return err;
}

//===========================================================================================
static XErr	Ldap_Primitive(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
PrimitiveRec	*primitiveRecP = &pbPtr->param.primitiveRec;
long		    strLen;
char			*strP, *p;
PrimitiveUnion	*param_d;
char	 		buffer[512];
long			objLen;
LDAPRec			ldapRec;
CStr15			tStr;

	if (primitiveRecP->resultWanted == kCString)
    {	objLen = sizeof(LDAPRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &primitiveRecP->objRef, (Ptr)&ldapRec, &objLen, 0, nil))
		{	CEquStr(buffer, ldapRec.hostName);
			CAddStr(buffer, ":");
			CNumToString(ldapRec.portNumber, tStr);
			CAddStr(buffer, tStr);
			param_d = &primitiveRecP->result;
			strP = buffer;
			strLen = CLen(strP);
			p = param_d->text.stringP;
			if (p)
			{	if (param_d->text.stringMaxStorage >= (strLen+1))
				{		CopyBlock(p, strP, strLen);
					p[strLen] = 0;
					param_d->text.stringLen = strLen;
				}
				else
				{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
					p[param_d->text.stringMaxStorage - 1] = 0;
					param_d->text.stringLen = strLen;
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
				}
			}
			else
				param_d->text.stringLen = strLen;
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);
 
return err;
}

//===========================================================================================
static XErr	Ldap_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				api_data = pbPtr->api_data;
long				objLen;
LDAPRec				ldapRec;

	objLen = sizeof(LDAPRec);
	err = BAPI_GetObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&ldapRec, &objLen, 0, nil);
	if NOT(err)
	{	switch(exeMethodRecP->methodID)
		{	case kSearch:
				err = _ldapSearch(api_data, exeMethodRecP, &ldapRec, pbPtr->error);
				break;
			case kFree:
				err = _ldapFree(api_data, exeMethodRecP, &ldapRec, pbPtr->error);
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
	}
    
return err;
}

//===========================================================================================
static XErr	Ldap_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRecP = &pbPtr->param.getPropertyRec;
XErr			err = noErr;

	if (getPropertyRecP->isConstant)
		err = BAPI_IntToObj(pbPtr->api_data, getPropertyRecP->propertyID, &getPropertyRecP->resultObjRef);
	else
		err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
	case kRegister:
	 	err = Ldap_Register(pbPtr);
	 	break;
	case kInit:
	 	err = Ldap_Init(pbPtr);
	 	break;
	case kShutDown:
	 	break;
	case kRun:
	 	break;
	case kExit:
	 	break;
	case kConstructor:
	 	err = Ldap_Constructor(pbPtr, false);
	 	break;
	case kTypeCast:
	case kClone:
	 	err = Ldap_Constructor(pbPtr, true);
	 	break;
	case kDestructor:
	 	err = Ldap_Destructor(pbPtr);
	 	break;
	case kExecuteOperation:
	 	err = XError(kBAPI_Error, Err_IllegalOperation);
	 	break;
	case kExecuteMethod:
		err = Ldap_ExecuteMethod(pbPtr);
		break;
	case kExecuteFunction:
		break;
	case kGetProperty:
		err = Ldap_GetProperty(pbPtr);
		break;
	case kSetProperty:
		break;
	case kPrimitive:
		err = Ldap_Primitive(pbPtr);
		break;
	case kGetErrMessage:
		break;
	default:
		break;
	}

return err;
}
