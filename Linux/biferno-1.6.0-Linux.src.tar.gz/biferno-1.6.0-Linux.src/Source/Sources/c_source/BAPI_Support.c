/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BAPI_Support.c,v 1.5 2003-11-06 18:15:42 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "BifernoAPI.h"

#if __MWERKS__
#pragma export on
#endif
EXP XErr	RegisterXLibCallBacks(long callsBackPtr);
EXP long	XLibVersion(long callerVersion, XErr *errP);
EXP XErr	RegisterCallBacks(long callsBackPtr);
//EXP XErr	BAPI_InitJavaAPI(long callsBackPtr);
EXP long	BAPI_PluginBAPIVersion(XErr *errP);
//===========================================================================================
EXP XErr	RegisterXLibCallBacks(long callsBackPtr)
{
	//printf("ODBC func: %d %d\n", callsBackPtr, ((XLIB_CallBacksRec*)callsBackPtr)->XYield);
	return _X_RegisterXLibCallBacks(callsBackPtr);
}
//===========================================================================================
EXP long	XLibVersion(long callerVersion, XErr *errP)
{
	return _X_XLibVersion(callerVersion, errP);
}

//===========================================================================================
EXP XErr	RegisterCallBacks(long callsBackPtr)
{
	return _X_RegisterCallBacks(callsBackPtr);
}
/*#ifdef JAVA_ENABLED
//===========================================================================================
EXP XErr	BAPI_InitJavaAPI(long callsBackPtr)
{
	return _X_BAPI_InitJavaAPI(callsBackPtr);
}
#endif*/
//===========================================================================================
EXP long	BAPI_PluginBAPIVersion(XErr *errP)
{
	return _X_BAPI_PluginBAPIVersion(errP);
}
#if __MWERKS__
#pragma export off
#endif
