/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Volatile.c,v 1.2 2003-06-25 16:11:01 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Param.h"
#include "Entity.h"
#include "BfrParser.h"
#include "Load.h"
#include "BifernoErrors.h"
#include "Classes.h"
#include "Volatile.h"

#define	MAX_VOLATILE_SIZE	(32L * 1024L)

//===========================================================================================
XErr	ResetVolatileList(BifernoRec *bRecP)
{
XErr			err = noErr;
long			totalSize;
BfrDestructRec	destructRec;

	if NOT(err = DLM_ListInfo(bRecP->volatileList, nil, nil, nil, &totalSize))
	{	if (totalSize > bRecP->volatileMaxSize)
			bRecP->volatileMaxSize = totalSize;
		if (totalSize > MAX_VOLATILE_SIZE)
		{	bRecP->volatileResets++;
			destructRec.api_data = (long)bRecP;
			destructRec.scope = TEMP;
			DLM_ResetList(bRecP->volatileList, VariableDestructorExt, (long)&destructRec, bRecP->volatileLevel, false);
		}
	}
	
return noErr;
}

//===========================================================================================
long	GetVolatileLevel(BifernoRec	*bRecP)
{
long	volLevel;

	DLM_GetTotObjs(bRecP->volatileList, &volLevel, false);

return volLevel;
}

//===========================================================================================
long	SetVolatileLevel(BifernoRec	*bRecP)
{
long	oldVolatileLevel;

	oldVolatileLevel = bRecP->volatileLevel;
	bRecP->volatileLevel = GetVolatileLevel(bRecP);

return oldVolatileLevel;
}

//===========================================================================================
void	ResumeVolatileLevel(BifernoRec *bRecP, long oldVolatileLevel)
{
	bRecP->volatileLevel = oldVolatileLevel;
}



