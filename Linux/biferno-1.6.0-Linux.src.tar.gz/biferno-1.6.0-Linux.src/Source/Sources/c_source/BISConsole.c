/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BISConsole.c,v 1.2 2003-06-19 10:53:28 valfer Exp $
	|______________________________________________________________________________
*/
#include "X.h"
#include "Helpers.h"

// #define	BIFERNO_VERSION	"1.0b1"

#include	"BifernoAPI.h"
#include	"BifernoEngineAPI.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//==================================================
static OSErr	CLInitLogCallBack(long userData, char *string)
{
#pragma unused(userData)

	printf("%s\n", string);
	return noErr;
}

#define	MAX_RESULT	10000

//==================================================
static void	TerminateApp(void)
{
	BEngineAPI_End(0);
	EndHelpers();
	XEnd();
}

//==================================================
// Qui il main � come se fosse un Run
int main(void)
{
char 			command[512];
OSErr			err2, err;
long			objStringLen, len;
Ptr				p;
CStr255			leakingStr;
char			objString[MAX_RESULT];
long			bAPIRef;
long			userData = 0;
ObjRef			resultVarRec;
CStr255			err1Str, err2Str, type;

	err2 = err = noErr;
	CEquStr(leakingStr, "robaccia");
	
	if NOT(err = XInit())
	{	if (err = InitHelpers())
		{	printf( "InitHelper error\n");
			return 0;
		}
	}
	else
	{	printf( "XInit error\n");
		return 0;
	}
	srand(time(NULL));	
	
	if (err = BEngineAPI_Init(CLInitLogCallBack, 0))
	{	printf( "BEngineAPI_Init error\n");
		return 0;
	}

	if (err = BEngineAPI_Run(&bAPIRef, userData))
	{	printf( "BEngineAPI_Run error\n");
		return 0;
	}

	while(1)
	{	gets(command);
		p = command;
		len = CLen(command);
		ResetLeaking();
		
		if (err = BAPI_Eval(bAPIRef, 0, &p, &len, &resultVarRec))
		{	BAPI_GetErrDescription(bAPIRef, err, err1Str, err2Str, type);
			printf( "**** Error (type: %s) %d: %s \n**** %s\n", type, err, err1Str, err2Str);
		}
		else
		{	if (resultVarRec.id)
			{	if (err)
				{	BAPI_GetErrDescription(bAPIRef, err, err1Str, err2Str, type);
					printf( "**** Error (type: %s) %d: %s **** %s\n", type, err, err1Str, err2Str);
				}
				else
				{	err = BAPI_ObjToString(bAPIRef, &resultVarRec, objString, &objStringLen, MAX_RESULT-4, kExplicitTypeCast);
					if (NOT(err) || (err == Err_BufferTooSmall))
					{	objString[objStringLen] = 0;
						if (err == Err_BufferTooSmall)
							CAddStr(objString, "...");
						printf( "%s\n", objString);
					}
					else
					{	BAPI_GetErrDescription(bAPIRef, err, err1Str, err2Str, type);
						printf( "**** Error (type: %s) %d: %s \n**** %s\n", type, err, err1Str, err2Str);
					}
				}
			}
		}
		
		CheckLeaking(leakingStr);
		if (*leakingStr)
			printf( "%s\n", leakingStr);
	}
	if (err = BEngineAPI_Exit(bAPIRef, userData))
	{	printf( "BEngineAPI_Exit error\n");
		return 0;
	}

	TerminateApp();

	return 0;
}

/*//=============================
static OSErr	Init(long taskID, char *serverDirPath, short maxUsers)
{

	

return 0;
}

//=============================
static OSErr	ShutDown(long taskID)
{
}

//=============================
static OSErr	Emergency(long taskID)
{
}

//=============================
static OSErr	ServerStateChanged(long taskID)
{
}

//========================
static OSErr	Run(long taskID)
{
	// return B_ProcessFile();
}

//========================
static OSErr	Idle(long taskID)
{
}

//=============================
OSErr	HTTPControllerRegister(HTTPControllerP	httpControllerP)
{
OSErr	err = noErr;

	CEquStr (httpControllerP->action, "BIFERNO");
	CEquStr (httpControllerP->pluginName, "Biferno.plugin");
	CEquStr (httpControllerP->suffix, ".bsc");	// Biferno script
	CEquStr (httpControllerP->mimeType, "text/html");
	CEquStr(httpControllerP->version, BIFERNO_VERSION);
	CEquStr (httpControllerP->adminURL, "");
	httpControllerP->Init = Init;
	httpControllerP->Run = Run;
	httpControllerP->Idle = Idle;
	httpControllerP->Emergency = Emergency;
	httpControllerP->ServerStateChanged = ServerStateChanged;
	httpControllerP->ShutDown = ShutDown;
	httpControllerP->AccessControl = nil;
	CEquStr(httpControllerP->aboutStr, "Biferno - Tabasoft 2000");
	
return err;
}
*/
