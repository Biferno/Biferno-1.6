/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoJava.c,v 1.1.1.1 2003-03-25 13:07:41 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
//#include 	"Helpers.h"

#ifdef 	JAVA_ENABLED
#ifdef	JAVA_MODULES

#include	"JNIUtils.h"

#include 	"BifernoAPI.h"
#include 	"BifernoAPI_DLL.h"
#include	"BJNI.h"


#include 	"BifernoJava.h"


#pragma export on
//===========================================================================================
/*JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1InitJavaAPI(JNIEnv *, jclass, jint callsBackPtr)
{
	return BAPI_InitJavaAPI(callsBackPtr);
}
*/
#pragma mark-
//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_ObjToInt
 * Signature: (ILObjRef;J)I
 */
JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1ObjToInt(JNIEnv *env, jclass, jint api_data, jobject jobjRef, jlong typeCastType)
{
XErr		err = noErr;
ObjRef		objRef;
long		aLong;
	
	if NOT(err = jobject2ObjRef(env, jobjRef, &objRef, nil))
		err = BAPI_ObjToInt(api_data, &objRef, &aLong, typeCastType);

if (err)
	GenException(env, err);
return aLong;
}

//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_ObjToBoolean
 * Signature: (ILObjRef;J)Ljava/lang/Boolean;
 */
JNIEXPORT jboolean JNICALL Java_BifernoJava_BAPI_1ObjToBoolean(JNIEnv *env, jclass, jint api_data, jobject jobjRef, jlong typeCastType)
{
XErr		err = noErr;
ObjRef		objRef;
Boolean		aBool;
	
	if NOT(err = jobject2ObjRef(env, jobjRef, &objRef, nil))
		err = BAPI_ObjToBoolean(api_data, &objRef, &aBool, typeCastType);
	
if (err)
	GenException(env, err);
return aBool;
}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_ObjToDouble
 * Signature: (ILObjRef;J)Ljava/lang/Double;
 */
JNIEXPORT jobject JNICALL Java_BifernoJava_BAPI_1ObjToDouble(JNIEnv *, jclass, jint, jobject, jlong)
{

}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_ObjToString
 * Signature: (ILObjRef;I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_BifernoJava_BAPI_1ObjToString(JNIEnv *env, jclass, jint api_data, jobject jobjRef, jint typeCastType)
{
XErr		err = noErr;
ObjRef		objRef;
CStr255		aCStr;
char		*stringP;
BlockRef	ref;
long		stringLen;
jstring		theString;

	
	if NOT(err = jobject2ObjRef(env, jobjRef, &objRef, nil))
	{	if NOT(err = BAPI_GetStringBlock(api_data, &objRef, aCStr, &stringP, &stringLen, &ref, typeCastType))
		{	stringP[stringLen] = 0;
			err = CString2jstring(env, stringP, &theString, nil);
			BAPI_ReleaseStringBlock(&ref);
		}
	}

if (err)
	GenException(env, err);
return theString;
}

//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_ObjToBuffer
 * Signature: (ILObjRef;II)[C
 */
JNIEXPORT jcharArray JNICALL Java_BifernoJava_BAPI_1ObjToBuffer(JNIEnv *, jclass, jint, jobject, jint, jint)
{

}

#pragma mark-
//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_IntToObj
 * Signature: (II)LObjRef;
 */
JNIEXPORT jobject JNICALL Java_BifernoJava_BAPI_1IntToObj(JNIEnv *env, jclass, jint api_data, jint value)
{
ObjRef		objRef;
jobject 	j_objref;
XErr		err = noErr;

	if NOT(err = BAPI_IntToObj(api_data, value, &objRef))
		err = ObjRef2jobject(env, &objRef, &j_objref, nil);

if (err)
	GenException(env, err);
return j_objref;
}

//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_BooleanToObj
 * Signature: (ILjava/lang/Boolean;)LObjRef;
 */
JNIEXPORT jobject JNICALL Java_BifernoJava_BAPI_1BooleanToObj(JNIEnv *, jclass, jint, jboolean)
{

}

//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_DoubleToObj
 * Signature: (ILjava/lang/Double;)LObjRef;
 */
JNIEXPORT jobject JNICALL Java_BifernoJava_BAPI_1DoubleToObj(JNIEnv *, jclass, jint, jobject)
{

}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_StringToObj
 * Signature: (ILjava/lang/String;)LObjRef;
 */
JNIEXPORT jobject JNICALL Java_BifernoJava_BAPI_1StringToObj(JNIEnv *, jclass, jint, jstring)
{

}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_BufferToObj
 * Signature: (I[CI)LObjRef;
 */
JNIEXPORT jobject JNICALL Java_BifernoJava_BAPI_1BufferToObj(JNIEnv *, jclass, jint, jcharArray, jint)
{

}

#pragma mark-
//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_NewProperty
 * Signature: (II[LNameValueRec;ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1NewProperty(JNIEnv *, jclass, jint, jint, jobjectArray, jint, jstring)
{

}

//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_NewCostant
 * Signature: (II[CIILjava/lang/String;Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1NewCostant(JNIEnv *, jclass, jint, jint, jcharArray, jint, jint, jstring, jstring)
{

}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_NewIntCostant
 * Signature: (II[LNameValueRec;ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1NewIntCostant(JNIEnv *, jclass, jint, jint, jobjectArray, jint, jstring)
{

}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_NewBoolCostant
 * Signature: (II[LNameValueBoolRec;ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1NewBoolCostant(JNIEnv *, jclass, jint, jint, jobjectArray, jint, jstring)
{

}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_NewMethod
 * Signature: (II[LMethodNameValueRec;ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1NewMethod(JNIEnv *, jclass, jint, jint, jobjectArray, jint, jstring)
{

}


//===========================================================================================
/*
 * Class:     BifernoJava
 * Method:    BAPI_NewFunction
 * Signature: (II[LMethodNameValueRec;I)I
 */
JNIEXPORT jint JNICALL Java_BifernoJava_BAPI_1NewFunction(JNIEnv *env, jobject theObj, jint api_data, jint pluginID, jobjectArray jnvRecP, jint tots)
{

}
#pragma export off
/*XErr 	Initialize(CFragInitBlockPtr ibp);
void 	Terminate(void);
//===========================================================================================
XErr 	Initialize(CFragInitBlockPtr ibp)
{
#pragma unused(ibp)
XErr		err = noErr;
CStr255		path;

	if (ibp->fragLocator.where == kDataForkCFragLocator)
		_GetFullPath(ibp->fragLocator.u.onDisk.fileSpec, path);
	if NOT(err = XInit(path))
		err = InitHelpers();

return err;
}

//===========================================================================================
void 	Terminate(void)
{
XErr	err = noErr;

	if NOT(err = EndHelpers())
		err = XEnd();
}
*/
#endif	// end JAVA_MODULES
#endif	// end JAVA_ENABLED
