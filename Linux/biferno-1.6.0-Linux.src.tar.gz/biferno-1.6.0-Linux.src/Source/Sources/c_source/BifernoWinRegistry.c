/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoWinRegistry.c,v 1.3 2003-06-19 10:53:28 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "BifernoWinRegistry.h"

#define	BIFERNO_KEY			"SOFTWARE\\Tabasoft\\Biferno\\"

//===========================================================================================
/*
Search the key of biferno, if it doesn't exist create it and fill with values
*/
/*XErr	SetBifernoKey(char *bifernoHome, long bifernoPort, long bifernoCtlPort)
{
CStr255		subKey, versionStr;
HKEY		keyHandle, subKeyHandle;
XErr		err = noErr;
DWORD		disposition;

	CEquStr(subKey, BIFERNO_KEY);
	if NOT(err = BAPI_GetVersions(0, versionStr, nil, nil))
	{	CAddStr(subKey, versionStr);
		if NOT(err = RegCreateKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &keyHandle, &disposition))
		{	if NOT(err = RegCreateKeyEx(keyHandle, BIFERNO_HOME, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &subKeyHandle, &disposition))
			{	err = RegSetValueEx(subKeyHandle, BIFERNO_HOME, 0, REG_SZ, (const BYTE*)bifernoHome, CLen(bifernoHome));
				RegCloseKey(subKeyHandle);
				if (err)
					goto out;
			}
			if NOT(err = RegCreateKeyEx(keyHandle, BIFERNO_PORT, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &subKeyHandle, &disposition))
			{	err = RegSetValueEx(subKeyHandle, BIFERNO_PORT, 0, REG_DWORD, (const BYTE*)&bifernoPort, sizeof(DWORD));
				RegCloseKey(subKeyHandle);
				if (err)
					goto out;
			}
			if NOT(err = RegCreateKeyEx(keyHandle, BIFERNO_CTL_PORT, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &subKeyHandle, &disposition))
			{	err = RegSetValueEx(subKeyHandle, BIFERNO_CTL_PORT, 0, REG_DWORD, (const BYTE*)&bifernoCtlPort, sizeof(DWORD));
				RegCloseKey(subKeyHandle);
				if (err)
					goto out;
			}
		out:
			RegCloseKey(keyHandle);
		}
	}
		
return err;
}
*/
//===========================================================================================
XErr	SetStringKey(char *name, char *valueStr)
{
CStr255		subKey;//, versionStr;
HKEY		keyHandle, subKeyHandle;
XErr		err = noErr;
DWORD		disposition;

	CEquStr(subKey, BIFERNO_KEY);
	//if NOT(err = BAPI_GetVersions(0, versionStr, nil, nil))
	{	//CAddStr(subKey, versionStr);
		if NOT(err = RegCreateKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &keyHandle, &disposition))
		{	if NOT(err = RegCreateKeyEx(keyHandle, name, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &subKeyHandle, &disposition))
			{	err = RegSetValueEx(subKeyHandle, name, 0, REG_SZ, (const BYTE*)valueStr, CLen(valueStr));
				RegCloseKey(subKeyHandle);
			}
			RegCloseKey(keyHandle);
		}
	}
		
return err;
}

//===========================================================================================
XErr	SetLongKey(char *name, long value)
{
CStr255		subKey;
HKEY		keyHandle, subKeyHandle;
XErr		err = noErr;
DWORD		disposition;

	CEquStr(subKey, BIFERNO_KEY);
	//if NOT(err = BAPI_GetVersions(0, versionStr, nil, nil))
	{	//CAddStr(subKey, versionStr);
		if NOT(err = RegCreateKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &keyHandle, &disposition))
		{	if NOT(err = RegCreateKeyEx(keyHandle, name, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &subKeyHandle, &disposition))
			{	err = RegSetValueEx(subKeyHandle, name, 0, REG_DWORD, (const BYTE*)&value, sizeof(DWORD));
				RegCloseKey(subKeyHandle);
			}
			RegCloseKey(keyHandle);
		}
	}
		
return err;
}

//===========================================================================================
XErr	GetStringKey(char *name, char *valueStr)
{
CStr255		subKey;
HKEY		keyHandle;
XErr		err = noErr;
DWORD		keyType, keyLen;
LONG		res;

	CEquStr(subKey, BIFERNO_KEY);
	CAddStr(subKey, name);
	if NOT(err = RegOpenKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, KEY_READ, &keyHandle))
	{	keyLen = 256;
		keyType = REG_SZ;
		res = RegQueryValueEx(keyHandle, name, NULL, &keyType, (Byte*)valueStr, &keyLen);
		if (res != ERROR_SUCCESS)
			err = res;
		/*keyLen = keyNameLen = 256;
		err = RegEnumValue(keyHandle, 0, name, &keyNameLen, 0, &keyType, (Byte*)valueStr, &keyLen);
		*/
		RegCloseKey(keyHandle);
	}
	if (err == ERROR_FILE_NOT_FOUND)
	{	err = noErr;
		*valueStr = 0;
	}
	
return err;
}

//===========================================================================================
XErr	GetLongKey(char *name, long *valueP)
{
CStr255		subKey;
HKEY		keyHandle;
XErr		err = noErr;
DWORD		keyType, keyLen;
Byte		keyData[256];
int			res;

	CEquStr(subKey, BIFERNO_KEY);
	//if NOT(err = BAPI_GetVersions(0, versionStr, nil, nil))
	{	//CAddStr(subKey, versionStr);
		//CAddStr(subKey, "\\");
		CAddStr(subKey, name);
		if NOT(err = RegOpenKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, KEY_READ, &keyHandle))
		{	keyLen = 256;
			keyType = REG_DWORD;
			res = RegQueryValueEx(keyHandle, name, NULL, &keyType, keyData, &keyLen);
			if (res != ERROR_SUCCESS)
				err = res;
			/*keyLen = keyNameLen = 256;
			if NOT(err = RegEnumValue(keyHandle, 0, keyName, &keyNameLen, 0, &keyType, keyData, &keyLen))
			{	
			*/
			if NOT(err)
			{	if (keyType == REG_DWORD)
					*valueP = *(DWORD*)keyData;
				else
					err = ERROR_FILE_NOT_FOUND;
			}
			RegCloseKey(keyHandle);
		}
	}
	if (err == ERROR_FILE_NOT_FOUND)
	{	err = noErr;
		*valueP = 0;
	}
	
return err;
}

//===========================================================================================
/*
get the biferno keys return false in *foundP if not found
*/
/*XErr	GetBifernoKey(char *bifernoHome, long *bifernoPortP, long *bifernoCtlPortP, Boolean *foundP)
{
CStr255		keyToOpen, subKey, versionStr, keyName;
HKEY		keyHandle;
XErr		err = noErr;
DWORD		keyType, keyLen, keyNameLen;
Byte		keyData[256];

	CEquStr(subKey, BIFERNO_KEY);
	if NOT(err = BAPI_GetVersions(0, versionStr, nil, nil))
	{	CAddStr(subKey, versionStr);
		CAddStr(subKey, "\\");
		
		// BifernoHome
		CEquStr(keyToOpen, subKey);
		CAddStr(keyToOpen, BIFERNO_HOME);
		if NOT(err = RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyToOpen, 0, KEY_ALL_ACCESS, &keyHandle))
		{	keyLen = keyNameLen = 256;
			if (bifernoHome)
				err = RegEnumValue(keyHandle, 0, keyName, &keyNameLen, 0, &keyType, (Byte*)bifernoHome, &keyLen);
			RegCloseKey(keyHandle);
		}
		if (err)
			goto out;
		// Port
		CEquStr(keyToOpen, subKey);
		CAddStr(keyToOpen, BIFERNO_PORT);
		if NOT(err = RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyToOpen, 0, KEY_ALL_ACCESS, &keyHandle))
		{	keyLen = keyNameLen = 256;
			if NOT(err = RegEnumValue(keyHandle, 0, keyName, &keyNameLen, 0, &keyType, keyData, &keyLen))
			{	if (keyType == REG_DWORD)
					*bifernoPortP = *(DWORD*)keyData;
				else
					err = ERROR_FILE_NOT_FOUND;
			}
			RegCloseKey(keyHandle);
		}
		if (err)
			goto out;
		// Ctl Port
		CEquStr(keyToOpen, subKey);
		CAddStr(keyToOpen, BIFERNO_CTL_PORT);
		if NOT(err = RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyToOpen, 0, KEY_ALL_ACCESS, &keyHandle))
		{	keyLen = keyNameLen = 256;
			if NOT(err = RegEnumValue(keyHandle, 0, keyName, &keyNameLen, 0, &keyType, keyData, &keyLen))
			{	if (keyType == REG_DWORD)
					*bifernoCtlPortP = *(DWORD*)keyData;
				else
					err = ERROR_FILE_NOT_FOUND;
			}
			RegCloseKey(keyHandle);
		}
		if (err)
			goto out;
	out:
		if (err == ERROR_FILE_NOT_FOUND)
		{	err = noErr;
			*foundP = false;
		}
		else if NOT(err)
			*foundP = true;
	}
	
return err;
}*/
