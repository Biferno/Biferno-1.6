/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: biferno_server_win.c,v 1.24 2006-10-20 13:04:56 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"
//#include "Helpers.h"
#include "XThreadsPrivate.h"
#if WIN_SERVICE
	#include <tchar.h>
	#include "XLibServices.h"
#endif

#include 	"HTTPMgr.h"
#include 	"HTTPMrgNet.h"

#include 	"BifernoWinRegistry.h"

#include "BifernoEngineAPI.h"

XFileRef	gLogRefNum, gExtraLogRefNum, gCurrentLogRefNum;

static HTTPControllerP	gHttpControllerP;
static BlockRef			gHttpControllerBlock;

static Boolean	gsSilent, gslogPrintf;
static long		gMaxUsers;
static Boolean	gsHandlerExecuted = false;
#ifndef WIN_SERVICE
	static HANDLE	hConsoleOutput;
#endif
static Boolean	gsDone = false;

CStr255		gsUpSinceStr;
long		gsBifernoPort;

#define	MAXFD				64
#define	BIFERNO_USER		"biferno"
#define	PROGR_NAME			"Biferno"

#if WIN_SERVICE
	#define	PROGRAM_NAME	"Biferno.exe"
#else
	#define	PROGRAM_NAME	"bifernosvc.exe"	
#endif

//===========================================================================================
static void	_write_stop_ok(void)
{
char		aCStr[MAX_LOG_STRING+1];

	/*if (gLogRefNum)
	{	tLen = CLen(NORM_STOP_STR);
		WriteXFile(gLogRefNum, NORM_STOP_STR, &tLen);
	}*/
	if (gExtraLogRefNum)
	{	FormatLogString(aCStr, kQuit, '-', "", "", "", 0, nil, nil);
		gCurrentLogRefNum = gLogRefNum;
		HTTPControllerLog(0, aCStr);
		//tLen = CLen(NORM_STOP_STR);
		//WriteXFile(gLogRefNum, NORM_STOP_STR, &tLen);
	}
	DeletePID(PROGR_NAME);
}

//===========================================================================================
static void _PrintUsage(void)
{
	printf("Usage:\r\n");
	printf("biferno\t\t\t\tStart biferno server as daemon\r\n");
	printf("biferno -i \t\t\tStart biferno server in terminal mode\r\n");
	printf("biferno -f filePath\t\tProcess filePath and exit\r\n");
	printf("biferno -v \t\t\tBiferno version\r\n");
	printf("biferno --help\t\t\tThis message\r\n");
}

//===========================================================================================
static XErr	_Terminate(Boolean toShutDown, XErr theError, long threadToRemain, Boolean xInited)
{
XErr		err = noErr;

	if (toShutDown)
	{	if (gHttpControllerP->ShutDown)
			err = gHttpControllerP->ShutDown(0);
		if (err && NOT(theError))
			theError = err;
	}
	if NOT(gsSilent)
		HTTPControllerLog(0, "Exiting...\r\n");
	if (theError)
	{	CStr255	errStr;

		XErrorGetDescr(theError, errStr, nil);
		HTTPControllerLog(0, errStr);
	}
	_write_stop_ok();
	if (gLogRefNum)
	{	UnlockXFile(gLogRefNum, 0, -1);
		EndLog(&gLogRefNum);
	}
	if (gExtraLogRefNum)
		EndLog(&gExtraLogRefNum);
	if (gHttpControllerBlock)
		DisposeBlock(&gHttpControllerBlock);
	if (xInited)
		XEnd(threadToRemain);
	
return noErr;
}

#ifndef WIN_SERVICE
	BOOL	WINAPI _CtrlHandler(DWORD signal);
#endif

#if WIN_SERVICE
//===========================================================================================
static void* _SCMNotify(void* a)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(a)
#endif
	while NOT(gsDone)
	{
		UpdateStatus (-1, -1);
		Sleep(CS_TIMEOUT);
	}
	//BfrServiceLogEvent ("_SCMNotify Exited");
	
return 0;
}
//===========================================================================================
static XErr	_LaunchNotifyCSMThread(void)
{
XErr			err = noErr;
unsigned long 	threadID;

	err = XNewThread(&threadID, 0, _SCMNotify, 64 * 1024, nil);

return err;
}
#endif

//===========================================================================================
#ifndef WIN_SERVICE
BOOL	WINAPI _CtrlHandler(DWORD signal)
{
CStr255		aCStr;
char		logString[MAX_LOG_STRING+1];
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(signal)
#endif
	if NOT(gsHandlerExecuted)
	{	gsHandlerExecuted = true;
		
		sprintf(aCStr, "signal ctrl");
		FormatLogString(logString, kQuit, '-', "", "", aCStr, 0, nil, nil);
		HTTPControllerLog(0, logString);
		
		XStopServer();
		//_write_stop_ok();
		_Terminate(true, 0, 0, true);
	}
	
return false;
}
#endif

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static void myprintf(char* p)
{
#ifdef WIN_SERVICE
	#if __MWERKS__
		#pragma unused(p)
	#endif
#else
DWORD	len;
	len = CLen(p);
	WriteConsole(hConsoleOutput, p, len, &len, NULL);
#endif
}

//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *outPutStr)
{
XErr		err = noErr;
CStr255		aCStr;
long		tLen;
HTTPRecord	*httpRecordP;

	tLen = CLen(outPutStr);
	if (tLen > 250)
		tLen = 250;
	CopyBlock(aCStr, outPutStr, tLen);
	aCStr[tLen] = 0;
	CAddStr(aCStr, "\r\n");
	if NOT(gsSilent)
	{	if (taskID)
		{	httpRecordP = (HTTPRecord*)taskID;
			if (httpRecordP->param)
				err = BufferAddCString(httpRecordP->param, aCStr, NO_ENC, 0);
			else if (gslogPrintf)
				myprintf(aCStr);	
		}
		else
		{	if (gslogPrintf)
				myprintf(aCStr);
		}
	}
	if (gCurrentLogRefNum)
		err = CStringToLog(gCurrentLogRefNum, aCStr, false);
	
return err;
}

//extern Boolean gServerInLoop;

//===========================================================================================
XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif
XErr		err = noErr;
BlockRef	resultStringBlock;
long		resultLen;
BlockRef	oemStrBlock;
Ptr			oemStr;
	
	if (len)
	{	if NOT(err = SubstituteExt(textP, len, &resultStringBlock, &resultLen, "%", 1, "%%", 2, true, false))
		{	textP = GetPtr(resultStringBlock);
			if (oemStrBlock = NewBlock(resultLen + 1, &err, &oemStr))
			{	//oemStr = GetPtr(oemStrBlock);
				CharToOem(textP, oemStr);
				oemStr[resultLen] = 0;			
				printf(oemStr);
				DisposeBlock(&oemStrBlock);
			}
			DisposeBlock(&resultStringBlock);
		}
	}

return err;
}

//===========================================================================================
XErr HTTPControllerWindowOutputExt(void *taskID, BlockRef bufferH, long len)
{
Ptr			textP = GetPtr(bufferH);
XErr		err = noErr;
BlockRef	oemStrBlock;
Ptr			oemStr;

	if (len)
	{	textP = GetPtr(bufferH);
		ZapNewLines((Byte*)textP, &len);
		if (len)
		{	if NOT(err = SetBlockSize(bufferH, len + 1))	// to be sure to have the 0 final char space
			{	textP = GetPtr(bufferH);
				textP[len] = 0;
				if (oemStrBlock = NewBlock(len + 1, &err, &oemStr))
				{	//oemStr = GetPtr(oemStrBlock);
					CharToOem(textP, oemStr);
					oemStr[len] = 0;
					err = HTTPControllerWindowOutput(taskID, oemStr, len);
					DisposeBlock(&oemStrBlock);
				}
			}
		}
	}
	DisposeBlock(&bufferH);
	
return err;
}

//===========================================================================================
static void	ProcessClientRequest(long socketRef, BlockRef block, long totLen, long userData)
{
HTTPRecord		httpRecord, *httpRecordP;
XErr			err = noErr;
CStr255			aCStr;
Boolean			wasSilent, toQuit;
LONGLONG		uniqueTag;
CStr255			ip_addr, host, sid;
CStr63			appName;

	toQuit = false;
	*sid = 0;
	if NOT(err = GetClientRequest(0, socketRef, block, totLen, userData, &httpRecord, &uniqueTag, ip_addr, host))
	{	httpRecordP = &httpRecord;
		if (httpRecord.command)
		{	
		BlockRef	tblock;
		long		tLen;
		CStr255		remoteAddr, localAddr;

			*aCStr = 0;
			if NOT(err = XRemoteAddress(socketRef, remoteAddr))
			{	if NOT(err = XLocalAddress(socketRef, localAddr))
				{	if (CCompareStrings_cs(remoteAddr, localAddr))
						CEquStr(aCStr, "Forbidden");
					else
					{	if (wasSilent = gsSilent)
							gsSilent = false;
						switch(httpRecord.command)
						{	case kFlush:
								httpRecord.param = BufferCreate(255, &err);
								BufferAddLong(httpRecord.param, 0);		// final length (fill it later)
								gHttpControllerP->ServerStateChanged(&httpRecord, httpRecord.command, nil);
								break;
							case kReload:
								httpRecord.param = BufferCreate(255, &err);
								BufferAddLong(httpRecord.param, 0);		// final length (fill it later)
								gHttpControllerP->ServerStateChanged(&httpRecord, httpRecord.command, nil);
								break;
							case kQuit:
								toQuit = true;
								CEquStr(aCStr, "Ok, biferno stopped");
								break;
							case kGetVersion:
								httpRecord.param = BufferCreate(255, &err);
								BufferAddLong(httpRecord.param, 0);		// final length (fill it later)
								gHttpControllerP->ServerStateChanged(&httpRecord, httpRecord.command, nil);
								break;
							case kCheck:
								CEquStr(aCStr, "Biferno running");
								break;
							default:
								CEquStr(aCStr, "Err, unknown command sent to biferno");
								break;
						}
						if (wasSilent)
							gsSilent = true;
					}
					if (NOT(*aCStr) && NOT(httpRecord.param))
						CEquStr(aCStr, "Err, can't display output");
					if (*aCStr)
					{	Ptr		p;
					
						tLen = CLen(aCStr);
						if (tblock = NewBlockLocked(4 + tLen, &err, &p))
						{	*(long*)p = XHostToNetwork(tLen);
							CopyBlock(p + 4, aCStr, tLen);
							HTTPControllerSendReply(&httpRecord, tblock, 4 + tLen);
						}
					}
					else if (httpRecord.param)
					{	
					Ptr			dataPtr;
					
						tblock = BufferGetBlockRefExtSize(httpRecord.param, &tLen, &dataPtr);
						*(long*)dataPtr = XHostToNetwork(tLen - 4);	// prefixed final length
						HTTPControllerSendReply(&httpRecord, tblock, tLen);
						BufferClose(httpRecord.param);
					}
					FormatLogString(aCStr, httpRecord.command, 'o', "", "", "", uniqueTag, nil, nil);
					HTTPControllerLog(0, aCStr);
				}
			}
		}
		else if (gHttpControllerP->Run)
		{	err = gHttpControllerP->Run(&httpRecord, true, uniqueTag, sid, aCStr, appName);
			LogExitRun(&httpRecord, ip_addr, host, aCStr, uniqueTag, sid, appName);
		}
	}
	else
		httpRecordP = nil;

	if (err)
	{	CStr255	errStr;

		XErrorGetDescr(err, errStr, nil);
		HTTPControllerLog(httpRecordP, errStr);
	}
	
	if (toQuit)
	{	XStopServer();
		//_write_stop_ok();
		/*_Terminate(true, err, 0, true);
		gsHandlerExecuted = true;
		GenerateConsoleCtrlEvent(CTRL_C_EVENT, 0);
		*/
		//exit(0);
	}
}

int ServiceSpecific(int argc, char *argv[]);

//===========================================================================================
static XErr _SetWhichKey(void)
{
CStr255		executablePath;
XErr		err = 0;

	GetModuleFileName(GetModuleHandle(PROGRAM_NAME), executablePath, 255);
#if WIN_SERVICE
	if NOT(err = SetStringKey(BIFERNO_SERVICE_PATH_KEYNAME, executablePath))
		err = SetStringKey(BIFERNO_WHICH_KEYNAME, "SERVICE");
#else
	if NOT(err = SetStringKey(BIFERNO_CONSOLE_PATH_KEYNAME, executablePath))
		err = SetStringKey(BIFERNO_WHICH_KEYNAME, "CONSOLE");
#endif

return err;
}
//===========================================================================================
#if WIN_SERVICE
	int ServiceSpecific(int argc, char *argv[])
#else
	int main(int argc, char *argv[])
#endif
{
Byte				theFld = 1;
long				lastCheck = 0;
XErr				err = 0;	//, err2 = 0;
CStr255				logFilePath, serverPathCStr, fileToProcess;
Boolean				toShutDown;
CStr255				logExtraFilePath, bifernoHome, fileToProcess_temp;
Boolean				xInited = false, initLogFile;
long				bifernoCtlPort;

	gLogRefNum = gExtraLogRefNum = gCurrentLogRefNum = 0;

#if WIN_SERVICE
	UpdateStatus (-1, -1); // Now change to status; increment the checkpoint
	gsSilent = true;
#else
	gsSilent = false;
#endif

	gLogRefNum = 0;
	gslogPrintf = true;
	*fileToProcess = 0;
	toShutDown = false;
	gHttpControllerBlock = 0;
	gsDone = false;
	
	if NOT(GetBifernoHome(bifernoHome))
	{	printf("%s\r\n", bifernoHome);
		return -1;
	}
			
	if (err = GetLongKey(BIFERNO_PORT_KEYNAME, &gsBifernoPort))
		return err;
	if NOT(gsBifernoPort)
	{	gsBifernoPort = BIFERNO_WIN_PORT;
		if (err = SetLongKey(BIFERNO_PORT_KEYNAME, gsBifernoPort))
			return err;
	}
	
	if (err = GetLongKey(BIFERNO_CTL_PORT_KEYNAME, &bifernoCtlPort))
		return err;
	if NOT(bifernoCtlPort)
	{	bifernoCtlPort = BIFERNO_SENTINEL_WIN_PORT;
		if (err = SetLongKey(BIFERNO_CTL_PORT_KEYNAME, bifernoCtlPort))
			return err;
	}
			
#ifndef WIN_SERVICE
	hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
#endif
	
	xInited = false;
	if (err = XInit(bifernoHome))
		goto out;
	xInited = true;

#ifndef WIN_SERVICE
	if NOT(SetConsoleCtrlHandler(_CtrlHandler, TRUE))
    {	err = XWinGetLastError();
    	printf("SetConsoleCtrlHandler failed (%d)\r\n", err);
		goto out;
    }
#endif

	if NOT(err = XGetApplicationFolderPath(logFilePath))
	{	CEquStr(logExtraFilePath, logFilePath);
		CAddStr(logFilePath, "BifernoServer.log");
		CAddStr(logExtraFilePath, "BifernoServer.extra.log");
	}
	else
    {	printf("XGetApplicationFolderPath error %s\r\n", err);
		goto out;
    }
		
	XCurrentDateTimeToString(gsUpSinceStr, kComplete);
	switch(argc)
	{
		case 1:
			initLogFile = true;
			break;
			
		case 2:
			initLogFile = false;
			if NOT(CCompareStrings_cs(argv[1], "-i"))
			{	
				;	// interactive
			}
			else if NOT(CCompareStrings_cs(argv[1], "-v"))
			{	
				CEquStr(fileToProcess, "Biferno version: ");
				BEngineAPI_GetVersions(logFilePath, nil, nil);
				CAddStr(fileToProcess, logFilePath);
				CAddStr(fileToProcess, "\r\n");
				printf(fileToProcess);
				return err;
			}
			else
			{	_PrintUsage();
				return err;
			}
			break;
	
		case 3:
			initLogFile = false;
			if NOT(CCompareStrings_cs(argv[1], "-f"))
			{	CEquStr(fileToProcess_temp, argv[2]);
				if (strchr(fileToProcess_temp, ':') && strchr(fileToProcess_temp, '\\'))
				{	// absolute win native path
					FilePathWin32ToXLib(fileToProcess_temp);
					CEquStr(fileToProcess, fileToProcess_temp);
				}	
				else if (*fileToProcess_temp == '/')
				{	// absolute xlib path
					CEquStr(fileToProcess, fileToProcess_temp);
				}
				else
				{	// relative path
					GetCurrentDirectory(255, fileToProcess);
					FilePathWin32ToXLib(fileToProcess);
					CAddChar(fileToProcess, '/');
					CSubstitute(fileToProcess_temp, '\\', '/');	// was native?
					CAddStr(fileToProcess, fileToProcess_temp);
					printf(fileToProcess);
					printf("\r\n");
				}
				gsSilent = true;
			}
			else
			{	_PrintUsage();
				return err;
			}
			break;
			
		default:
			initLogFile = false;
			_PrintUsage();
			return err;
	}

	if (initLogFile)
	{
	Boolean	isLocked;
	
		CheckLogFile(logFilePath, &isLocked/*, false*/);
		if (isLocked)
		{
		XFileRef	tLogRefNum;
			
			CAddStr(logFilePath, "_CANT_INIT_BIFERNO_TWICE");
			err = OpenXFile(logFilePath, CREATE_FILE_ALWAYS, READ_WRITE_PERM, false, &tLogRefNum);
			goto out;
		}
		err = InitLog(logFilePath, &gLogRefNum);
		if (err)
			goto out;
		if (gLogRefNum)
		{	if (err = LockXFile(gLogRefNum, 0, -1, false))
				goto out;
		}
		if (err = InitLog(logExtraFilePath, &gExtraLogRefNum))
			goto out;
		gCurrentLogRefNum = gExtraLogRefNum;
	}
	else
		gLogRefNum = 0;

	if NOT(gsSilent)
		HTTPControllerLog(0, "Starting Biferno Server...\r\n");

	
	gHttpControllerBlock = 0;
	GetXApplicationCurrentDir(serverPathCStr);

	HTTPControllerLog(0, "Initializing...\r\n");
	
	gMaxUsers = 32;	// default
	WritePID(PROGR_NAME, GetCurrentProcessId());
	if (gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err, (Ptr*)&gHttpControllerP))
	{	//gHttpControllerP = (HTTPControllerP)GetPtr(gHttpControllerBlock);
		ClearBlock(gHttpControllerP, sizeof(HTTPController));
		if NOT(err = HTTPControllerRegister(gHttpControllerP))
		{	if (gHttpControllerP->Init)
			{	if NOT(err = gHttpControllerP->Init(0, &gMaxUsers, false, logFilePath))
				{	toShutDown = true;
					if (*fileToProcess)
					{	gsSilent = false;
						err = gHttpControllerP->Process(0L, fileToProcess);
					}
					else
					{
					CStr255		aCStr, tStr;
					
						CEquStr(aCStr, "Biferno for Windows is running: version ");
						BEngineAPI_GetVersions(tStr, nil, nil);
						CAddStr(aCStr, tStr);
						CAddStr(aCStr, "\r\n");
						HTTPControllerLog(0, aCStr);
						
						CEquStr(aCStr, "Port: ");
						CNumToString(gsBifernoPort, tStr);
						CAddStr(aCStr, tStr);
						CAddStr(aCStr, "\r\n");
						HTTPControllerLog(0, aCStr);
						
						HTTPControllerLog(0, "Accepting connections...\r\n");

#if WIN_SERVICE
	UpdateStatus (SERVICE_RUNNING, -1); // Now change to status; increment the checkpoint
	BfrServiceLogEvent ("SERVICE_RUNNING");
	_LaunchNotifyCSMThread();
#else
	gslogPrintf = true;
#endif
						_SetWhichKey();
						gCurrentLogRefNum = gLogRefNum;
						FormatLogString(aCStr, kStartup, '-', "", "", "--------------------------------------------", 0, nil, nil);
						HTTPControllerLog(0, aCStr);
						err = XServerLoop(gsBifernoPort, gMaxUsers, ProcessClientRequest, 0L, true, true, nil, nil);
						FormatLogString(aCStr, kQuit, '-', "", "", "from bifernoctl", 0, nil, nil);
						HTTPControllerLog(0, aCStr);
						gCurrentLogRefNum = gExtraLogRefNum;
						if (err)
							goto out;
					}
				}
			}
		}
	}	
	
out:
#if WIN_SERVICE
	gsDone = true;
	BfrServiceLogEvent ("_Terminate");
#endif
_Terminate(toShutDown, err, 0, xInited);
#if WIN_SERVICE
	BfrServiceLogEvent ("_Terminate ok");
#endif
return err;
}