/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Classes.c,v 1.36 2008-11-27 15:27:48 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Load.h"
#include "Param.h"
#include "BifernoErrors.h"
#include "Entity.h"
#include "BfrParser.h"
#include "Volatile.h"
#include "Reference.h"
#include "Run.h"

#include "Classes.h"
#include "CDivert.h"

extern DispatcherData				gsDispatcherData;	// in Dispatcher.c
extern CStr255						globalErrStr;
extern BlockRef						gsCallBacksBlock;
extern CStr63						gBifernoErrorsStr[];
extern PluginRecord					*gClassRecordBlockP;
extern XErr							gMemoryFullError;
extern Ref_GetTargetCallBack		ref_GetTarget;

static char	gOperStr[LAST_OP][3] = {
							"*",	// EVAL_MULT = 1,				// *						0
							"/",	// EVAL_DIV,					// /						0
							"%",	// EVAL_MOD,					// %						0
							"+",	// EVAL_ADD,					// +						1
							"-",	// EVAL_MINUS,					// -						1
							">>",	// EVAL_SHIFTR,					// >>						2
							"<<",	// EVAL_SHIFTL,					// <<						2
							">",	// EVAL_GTH ,					// >						3
							"<",	// EVAL_LTH,					// <						3
							">=",	// EVAL_GEQ,					// >=						3
							"<=",	// EVAL_LEQ,					// <=						3
							"==",	// EVAL_EQUA,					// ==						4
							"!=",	// EVAL_NEQUA,					// !=						4
							"&",	// EVAL_ARAND,					// &						5
							"|",	// EVAL_AROR					// |						6
							"&&",	// EVAL_LOGIC_AND,				// &&						7		// Never sent to classes
							"||"	// EVAL_LOGIC_OR,				// ||						8		// Never sent to classes
							//"?",	// EVAL_TERNARY_QUESTIONMARK,	// ?						9		// Never sent to classes
							//":"		// EVAL_TERNARY_SEMICOLON		// :						9		// Never sent to classes
							};

//static	XFileRef	dumpXrefNum = 0;

typedef struct {
				ObjRecord	thisObjRef;
				ObjRecord	superObjRef;
				long		methodInExecutionClass;
				long		visibilityClass;
				} StateRec, *StateRecP;


//===========================================================================================
// expect classID to be negative
DLMRef	GetUserClassDLMList(BifernoRecP bRecP, long classID)
{
//XErr	err = noErr;
DLMRef	list = 0;

#ifdef MEM_DEBUG
	if (classID >= 0)
		return 0;
#endif	
	
	if IS_LOCAL(classID)
		list = bRecP->local.classList;
	else
		list = bRecP->application.classList;

return list;
}

//===========================================================================================
// expect classID to be negative
XErr	GetUserClassRecord(BifernoRecP bRecP, long classID, Ptr dataP, long *dataLenP, long offset, long *userDataP)
{
XErr	err = noErr;

#ifdef MEM_DEBUG
	if (classID >= 0)
		return XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
#endif	
	
	if IS_LOCAL(classID)
	{	classID += LOCAL_ID_OFFSET;
		err = DLM_GetObj(bRecP->local.classList, -classID, dataP, dataLenP, offset, userDataP);
	}
	else
		err = DLM_GetObj(bRecP->application.classList, -classID, dataP, dataLenP, offset, userDataP);

return err;
}

//===========================================================================================
// expect classID to be negative
XErr	ModifyUserClassRecord(BifernoRecP bRecP, long classID, Ptr dataP, long dataLen, long userData, DLMLoopCallBack callBack, long param, DLMLoopCallBack notifyProc)
{
XErr	err = noErr;

#ifdef MEM_DEBUG
	if (classID >= 0)
		return XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
#endif	
	
	if IS_LOCAL(classID)
	{	classID += LOCAL_ID_OFFSET;
		err = DLM_ModifyObj(bRecP->local.classList, -classID, dataP, dataLen, userData, callBack, param, notifyProc);
	}
	else
		err = DLM_ModifyObj(bRecP->application.classList, -classID, dataP, dataLen, userData, callBack, param, notifyProc);

return err;
}

//===========================================================================================
long	GetUserClassID(BifernoRecP bRecP, char *className)
{
long	objID;
	
	if (objID = -DLM_GetObjID(bRecP->local.classList, className, nil, nil))
		objID -= LOCAL_ID_OFFSET;
	else
		objID = -DLM_GetObjID(bRecP->application.classList, className, nil, nil);

return objID;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// expect classID to be negative
/*DLMRef	GetUserFunctionDLMList(BifernoRecP bRecP, long *funcObjIDP)
{
XErr	err = noErr;
DLMRef	list = 0;
long	funcID = *funcObjIDP;

#ifdef MEM_DEBUG
	if (funcID >= 0)
		return 0;
#endif	
	
	if IS_LOCAL(funcID)
	{	list = bRecP->local.funcsList;
		*funcObjIDP = -(funcID + LOCAL_ID_OFFSET);
	}
	else
	{	list = bRecP->application.funcsList;
		*funcObjIDP = -funcID;
	}

return list;
}
*/
//===========================================================================================
//ex long	GetUserFunctionObjID(BifernoRecP bRecP, char *funcName, BlockRef *membIdentBlockP)
XErr	GetUserFunctionInfo(BifernoRecP bRecP, char *funcName, BlockRef *membIdentBlockP, Boolean *existsP, Boolean *isApplicationP)
{
long			realObjID, tLen, objID, length;
MemberAction 	*membIdentP;
Boolean			allocated = false;
XErr			err = noErr;
DLMRef			list;

	*existsP = false;
	if (realObjID = DLM_GetObjIDExt(bRecP->local.funcsList, funcName, nil, nil, &length))
	{	
		objID = -realObjID - LOCAL_ID_OFFSET;
		list = bRecP->local.funcsList;
		*existsP = true;
		if (isApplicationP)
			*isApplicationP = false;
	}
	else
	{	
		if (realObjID = DLM_GetObjIDExt(bRecP->application.funcsList, funcName, nil, nil, &length))
		{	
			objID = -realObjID;
			list = bRecP->application.funcsList;
			*existsP = true;
			if (isApplicationP)
				*isApplicationP = true;
		}
	}

	if (membIdentBlockP && *existsP)
	{	
		tLen = sizeof(MemberAction) - sizeof(BAPI_Doc) + length;	
		if (*membIdentBlockP = NewBlockLocked(tLen, &err, (Ptr*)&membIdentP))
		{	
			allocated = true;
			membIdentP->id = realObjID;
			if NOT(err = DLM_GetObj(list, realObjID, (Ptr)&membIdentP->doc, &length, 0, nil))
				INVAL(membIdentP->objRef);
			//membIdentP->infos.biferno.id = objID;
		}
	}

	if (err && allocated && *membIdentBlockP)
		DisposeBlock(membIdentBlockP);

return err;
}

//===========================================================================================
// expect classID to be negative
/*XErr	GetUserFunctionRecord(BifernoRecP bRecP, long classID, Ptr dataP, long *dataLenP, long offset, long *userDataP)
{
XErr	err = noErr;

#ifdef MEM_DEBUG
	if (classID >= 0)
		return XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
#endif
	
	if IS_LOCAL(classID)
	{	classID += LOCAL_ID_OFFSET;
		err = DLM_GetObj(bRecP->local.funcsList, -classID, dataP, dataLenP, offset, userDataP);
	}
	else
		err = DLM_GetObj(bRecP->application.funcsList, -classID, dataP, dataLenP, offset, userDataP);

return err;
}
*/

#if __MWERKS__
#pragma mark-
#endif

/*
static XErr	BifernoExecuteFunction(Biferno_ParamBlockPtr pbPtr);
//===========================================================================================
static XErr	_AddToStack(BifernoRecP bRecP, DLMRef funcList, long funcObjID, char *methodName, ParameterRec *paramVarsP, long totParams)
{
StackItem 	*stackP;
long		totSize, i, tot;
XErr		err = noErr;

	stackP = bRecP->stack;
	tot = bRecP->stackItems;
	for (i = 0; i < tot; i++, stackP++)
	{	if ((stackP->funcList == funcList) && (stackP->funcID == funcObjID))
			break;
	}
	if (i >= tot)	// not found -> add to stack
	{	if (i < MAX_FUNCTION_INSTACK)
		{	stackP->funcList = funcList;
			stackP->funcID = funcObjID;
			stackP->paramVarsP = paramVarsP;
			stackP->totParams = totParams;
			CEquStr(stackP->methodName, methodName);
			bRecP->stackItems++;
		}
		else
			err = XError(kBAPI_Error, Err_StackOverflow);
	}
	else	// found -> recursive, must launch thread
	{	err = XError(kBAPI_Error, Err_SuspendFunction);
	
		totSize = sizeof(ParameterRec) * totParams;
		if (stackP->paramVarsBlock = NewPtrBlock(totSize, &err))
		{	stackP->paramVarsP = (ParameterRec*)GetPtr(stackP->paramVarsBlock);
			CopyBlock(stackP->paramVarsP, paramVarsP, totSize);
			stackP->totParams = totParams;
			bRecP->stackInnerToExecute = i;
			stackP->lastStatementP = bRecP->lastStatementP;
			stackP->lastStatementLen = bRecP->lastStatementLen;
			
		}
	}
	
return err;
}

//===========================================================================================
static void	_RemoveFromStack(BifernoRecP bRecP)
{
	bRecP->stackItems--;
}

//===========================================================================================
static XErr		_StackExecuteInnerFunc(BifernoRecP bRecP, Ptr *lastStatementP, long *lastStatementLenP)
{	
XErr				err = noErr;
StackItem			*stackP = &bRecP->stack[bRecP->stackInnerToExecute];
BlockRef			block;
long				slot;
Biferno_ParamBlock	*pbPtr;
ExecuteMethodRec	*execRecP;

	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot, &block))
	{	execRecP = &pbPtr->param.executeMethodRec;
		execRecP->objRef.id = 0;		// for now only funcs
		CEquStr(execRecP->methodName, stackP->methodName);
		
		// Debug
		{
		long		value;
		
		BAPI_ObjToInt((long)bRecP, &stackP->paramVarsP->objRef, &value, kExplicitTypeCast);
		}
		execRecP->paramVarsP = stackP->paramVarsP;
		execRecP->totParams = stackP->totParams;
		execRecP->methodID = stackP->funcID;
		pbPtr->plugin_global_data = stackP->funcID;
		bRecP->stackItems--;
		err = BifernoExecuteFunction(pbPtr);
		bRecP->stackItems++;
		DisposeBlock(&stackP->paramVarsBlock);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot, block);
		*lastStatementP = stackP->lastStatementP;
		*lastStatementLenP = stackP->lastStatementLen;
	}

return err;
}				
*/
//===========================================================================================
static XErr	_GetSuperObj(long api_data, ObjRecord *objRefP, ObjRecord *supObjRefP)
{
//XErr			err = noErr;
//long			tLen;

	return BAPI_GetSuperObj(api_data, OBJREF_P(objRefP), OBJREF_P(supObjRefP));
	/*if (objRefP->id)
	{	tLen = sizeof(ObjRecord);
		err = BAPI_GetObj(api_data, objRefP, (Ptr)supObjRefP, &tLen, offsetof(BifernoInstance, superObjRef)+1, nil);
	}
	
return err;*/
}

//===========================================================================================
static void	_GetState(BifernoRecP bRecP, StateRecP stateRecP)
{
	stateRecP->thisObjRef = bRecP->thisObjRef;
	stateRecP->superObjRef = bRecP->superObjRef;
	stateRecP->methodInExecutionClass = bRecP->methodInExecutionClass;
	stateRecP->visibilityClass = bRecP->visibilityClass;
}

//===========================================================================================
static XErr	_SetNewState(BifernoRecP bRecP, ObjRecord *thisObjRefP, long extendedClassID, Boolean expectSuperInConstructor, ObjRecord *superObjRefP)
{
XErr	err = noErr;

	bRecP->thisObjRef = *thisObjRefP;
	bRecP->methodInExecutionClass = thisObjRefP->classID;
	bRecP->visibilityClass = thisObjRefP->classID;
	if (extendedClassID || expectSuperInConstructor)
	{	if (superObjRefP)
			bRecP->superObjRef = *superObjRefP;
		else if (thisObjRefP && thisObjRefP->id && (bRecP->executingConstructor != thisObjRefP->classID))
			err = _GetSuperObj((long)bRecP, thisObjRefP, &bRecP->superObjRef);
		else
			bRecP->superObjRef.id = bRecP->superObjRef.classID = 0;
	}
	else
		bRecP->superObjRef.id = bRecP->superObjRef.classID = 0;

return err;
}

//===========================================================================================
static void	_ResetState(BifernoRecP bRecP, StateRecP stateRecP)
{
	bRecP->thisObjRef = stateRecP->thisObjRef;
	bRecP->superObjRef = stateRecP->superObjRef;
	bRecP->methodInExecutionClass = stateRecP->methodInExecutionClass;
	bRecP->visibilityClass = stateRecP->visibilityClass;
}

//===========================================================================================
/*static XErr	_LoadSuperObj(BifernoRecP bRecP, ObjRecord *supObjP, ObjRecordObjRecord *thisObjRefP)
{
XErr		err = noErr;
ObjRecord		instanceSuperObjRef;
		
	if NOT(err = BAPI_NewSuperObj((long)bRecP, thisObjRefP, supObjP, &instanceSuperObjRef))
		err = DLM_TurnOnFlag(supObjP->list, supObjP->id, kNoDestructor, kDLMElements);
	
	
	instance_supObjP = &instanceP->superObjRef;
	if NOT(err = DLM_CopyObj(supObjP->list, supObjP->id, instanceP->list, "", -1, &instanceP->superObjRef.id))
	{	if NOT(err = DLM_TurnOnFlag(supObjP->list, supObjP->id, kNoDestructor, kDLMElements))
		{	instance_supObjP->list = instanceP->list;
			instance_supObjP->classID = supObjP->classID;
			instance_supObjP->scope = theScope;
			instance_supObjP->type = supObjP->type;
			err = BAPI_ModifyObj((long)bRecP, thisObjRefP, (Ptr)instanceP, sizeof(BifernoInstance));
		}
	}

return err;
}
*/
//===========================================================================================
static XErr	_FillInstanceWithDefaults(BifernoRecP bRecP, BifernoClass *bifernoClassP, BifernoInstance *instanceP, long instanceScope)
{
XErr			err = noErr;
DLMRef			list;
long			tLen, totProperties;
//BifernoProperty	bProperty;
CStr63			propName;
int				i;
BAPI_Doc		bProperty;

	list = bifernoClassP->properties;
	tLen = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
	totProperties = bifernoClassP->totNonStatic;
	for (i = 1; (i <= totProperties) && NOT(err); i++)
	{	if NOT(err = DLM_GetIndObj(list, i, (Ptr)&bProperty, &tLen, 0, nil, nil, propName, false, false))
		{	if NOT(bProperty.isStatic)
				err = DefaultProperty(bRecP, &bProperty, propName, instanceP->list, instanceScope, false, nil);
		}
	}

return err;
}

//===========================================================================================
/*static XErr	_CallSuperObjConstructor(long api_data, ConstructorRec *constructorRecP, BifernoClass *bifernoClassP)
{
XErr	err = noErr;
ObjRecord	tempObjRef, *objP;
long	superObjID;

	/*if NOT(err = CL_Constructor(api_data, TEMP, VARIABLE, nil, bifernoClassP->extendedClassID, constructorRecP->varRecsP, constructorRecP->totVars, &tempObjRef))
	{	if NOT(err = DLM_CopyObj(tempObjRef.list, tempObjRef.id, instanceP->list, "", -1, &superObjID))
		{	if NOT(err = DLM_TurnOnFlag(tempObjRef.list, tempObjRef.id, kNoDestructor, kDLMElements))
			{	objP = superObjRefP;
				objP->list = instanceP->list;
				objP->id = superObjID;
				objP->classID = bifernoClassP->extendedClassID;
				objP->scope = constructorRecP->scope;
				objP->type = constructorRecP->type;
			}
		}
	}

return err;
}*/

//===========================================================================================
static Boolean	_CantAccessMember(BifernoRecP bRecP, Byte visibility, long classOwner)
{
Boolean			res = true;
XErr			err = noErr;
BifernoClass	bifernoClass;
int				clID;
long			executingClass = bRecP->visibilityClass;

	switch(visibility)
	{
		case kPublic:
			res = false;
			break;
		case kPrivate:
			res = (executingClass != classOwner);
			break;
		case kProtected:
			if (executingClass == classOwner)
				res = false;
			else
			{	clID = -executingClass;
				while (NOT(err))
				{	if NOT(err = GetBifernoClassRec(bRecP, clID, &bifernoClass))
					{	if (bifernoClass.extendedClassID)
						{	if NOT(res = (bifernoClass.extendedClassID != classOwner))
								break;
							else
								clID = -bifernoClass.extendedClassID;
						}
						else
						{	res = true;
							break;
						}
					}
				}
			}
			break;
	}
	
return res;
}

//===========================================================================================
/*void DumpStack(char *funcName)
{
CStr255		aCStr;
long		tLen;

	if (gInExecuteBFunc)
	{	if NOT(dumpXrefNum)
			OpenXFile("DumpStack.txt", CREATE_FILE_ALWAYS, READ_WRITE_PERM, USE_CACHE, &dumpXrefNum);
		sprintf(aCStr, "Funzione: %s\tStack Space: %d\r", funcName, StackSpace());
		tLen = CLen(aCStr);
		WriteXFile(dumpXrefNum, aCStr, &tLen);
	}
}*/

//===========================================================================================
char*	_GetOperationStringP(long operation)
{
char	*strP;

	if (operation <= LAST_OP)
		strP = gOperStr[operation-1];
	else
		strP = nil;

return strP;
}

//===========================================================================================
static XErr	_OperationToStringObj(long api_data, long operation, ObjRecord *objRefP)
{
char	*strP;
XErr	err = noErr;

	if (operation <= LAST_OP)
		strP = gOperStr[operation-1];
	else
		err = XError(kBAPI_Error, Err_UnknownOperator);
	if NOT(err)
		err = BAPI_StringToObj(api_data, strP, CLen(strP), OBJREF_P(objRefP));
	
return err;
}

//===========================================================================================
/*static void	_SaveState(Biferno_ParamBlockPtr pbPtr, long *save_curMethodClassP)
{
BifernoRecP		bRecP = (BifernoRecP)pbPtr->api_data;

	*save_curMethodClassP = bRecP->methodInExecutionClass;
	bRecP->methodInExecutionClass = -(long)pbPtr->plugin_global_dataP;
}*/

//===========================================================================================
/*static void	_SetState(Biferno_ParamBlockPtr pbPtr, long save_curMethodClass)
{
BifernoRecP		bRecP = (BifernoRecP)pbPtr->api_data;

	bRecP->methodInExecutionClass = save_curMethodClass;
}*/

//===========================================================================================
/* Usually we clone parameters. We only cpy it if:
	- they are for address
	- it is in not in the volatile list
	- there is no need of typecast
*/
static XErr	_ParamToLocal(long api_data, ObjRecord *objRefP, char *paramName, long requestedClassID, long arrayElemRequestedClassID, long arrayElemRequestedLevel/*, Boolean forAddress, ObjRecord *clonedObjRefP, Boolean *onlyCopiedP*/)
{
long			cID;
ObjRecord		newObjRef, clonedObjRef;
ParameterRec	parameter;
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			wantConstant;
ArraySpecs		arSpec;

	INVAL(newObjRef);
	INVAL(clonedObjRef);
	if (requestedClassID == CLASSID_UNSPECIFIED)
		requestedClassID = 0;
	*parameter.name = 0;
	cID = objRefP->classID;
	parameter.objRef = OBJREF(*objRefP);
	
	/*
	param byRef require Eval after function only in the following two cases:
	
		- volatile (or immediate) (in &a.length?)
	
	*/
	if NOT(err)
	{	if (requestedClassID && (requestedClassID != objRefP->classID))
			err = BAPI_TypeCast(api_data, OBJREF_P(objRefP), requestedClassID, OBJREF_P(&newObjRef), kExplicitTypeCast);
		else
			newObjRef = *objRefP;
		if NOT(err)
		{	
		Boolean	fixedSize;
		
			if NOT(requestedClassID)
				fixedSize = false;
			else
				err = BAPI_FixedSize(api_data, requestedClassID, &fixedSize);
			if NOT(err)
			{	wantConstant = false;
				if NOT(err = CloneObject(api_data, &newObjRef, paramName, bRecP->localList, LOCAL, requestedClassID, arrayElemRequestedClassID, wantConstant, fixedSize, &clonedObjRef.id, &arSpec, false))
				{	if (arrayElemRequestedClassID && arrayElemRequestedLevel)
					{	if (newObjRef.classID == gsDispatcherData.refConstructor)
						{
						ObjRecord	targetObjRef;
						
							if NOT(err = ref_GetTarget(api_data, (ObjRefP)&newObjRef, (ObjRefP)&targetObjRef, true))
							{	if (targetObjRef.classID == gsDispatcherData.arrayConstructor)
									err = GetArraySpecs(api_data, &targetObjRef, &arSpec);
							}
						}
						if NOT(err)
						{	if (arrayElemRequestedClassID == gsDispatcherData.arrayConstructor)
							{	if (arSpec.arrayElemAeLevel < arrayElemRequestedLevel)
									err = XError(kBAPI_Error, Err_ArrayMismatch);
							}
							else
							{	if (arSpec.arrayElemAeLevel != arrayElemRequestedLevel - 1)
									err = XError(kBAPI_Error, Err_ArrayMismatch);
							}
						}
					}
					if NOT(err)
					{	clonedObjRef.list = bRecP->localList;
						if (requestedClassID)
							clonedObjRef.classID = requestedClassID;
						clonedObjRef.scope = LOCAL;
						clonedObjRef.type = objRefP->type;	//VARIABLE;				
					}
				}
			}
		}
	}
	
return err;
}

// Parameter
typedef struct {
				ObjRecord	objRef;
				Boolean		onlyCopied;
				Boolean		isConstant;
				short		pad2;
				} ObjRefExt, *ObjRefExtP;

//===========================================================================================
static XErr	_GiveNameToParam(BAPI_Doc *bisFunctionP, ParameterRec *tParamVars, /*ProtoParam *intProtoParamP,*/ BAPI_ParameterDoc **protoParamPPtr,/*, long totProtoParams, */long *tempClassIDP, long *tempArrayElemClassIDP, long *tempArrayElemLevelP, long i)
{	
XErr				err = noErr;
CStr7				tStr;
BAPI_ParameterDoc	*protoParamP = *protoParamPPtr;

	if (i >= bisFunctionP->totParams)
	{	protoParamP = nil;
		if NOT(*tParamVars->name)
		{	if (NOT(IS_IMMEDIATE(tParamVars->objRef)) && OBJ_ID(tParamVars->objRef))
				err = DLM_GetInfo(OBJ_LIST(tParamVars->objRef), OBJ_ID(tParamVars->objRef), nil, nil, tParamVars->name);
			if NOT(err)
			{	//if (NOT(*tParamVars->name) || (_NameExists(tParamVars->name, intProtoParamP, totProtoParams)))
				{	CNumToString(i+1, tStr);
					CEquStr(tParamVars->name, "_");
					CAddStr(tParamVars->name, tStr);
				}
			}
		}
		*tempClassIDP = OBJ_CLASSID(tParamVars->objRef);
		*tempArrayElemClassIDP = 0;	//CLASSID_UNSPECIFIED;
		*tempArrayElemLevelP = 0;
		*protoParamPPtr = protoParamP;
	}
	else
	{	*tempClassIDP = protoParamP->classID;
		*tempArrayElemClassIDP = protoParamP->aeClassID;
		*tempArrayElemLevelP = protoParamP->aeLevel;
		if NOT(*tParamVars->name)
			CEquStr(tParamVars->name, protoParamP->name);
	}

return err;
}

//===========================================================================================
static XErr	_SetFunctionLocalList(BifernoRecP bRecP, BAPI_Doc *bisFunctionP, ParameterRec *paramVarsP, long totParams)
{
XErr				err = noErr;
ParameterRec		*tParamVars;
long				api_data = (long)bRecP;
DLMRef				destList;
int					i;
BAPI_ParameterDoc	*saveProtoParamP, *protoParamP;
DLMRef				saveLocalList;
long				tempArrayElemLevel, tempArrayElemClassID, tempClassID;
BfrDestructRec		destructRec;

	protoParamP = nil;
	saveLocalList = bRecP->localList;
	i = 0;
	err = DLM_Create(&bRecP->localList, NAMECS_LIST, LOCAL_LIST);
	if (err)
		bRecP->localList = saveLocalList;
	else
	{	if (totParams)
		{	destList = bRecP->localList;
			tParamVars = &paramVarsP[0];
			if (bisFunctionP->totParams)
				protoParamP = bisFunctionP->params;
			saveProtoParamP = protoParamP;
			for (i = 0; (i < totParams) && NOT(err); i++, tParamVars++)
			{	if NOT(err = _GiveNameToParam(bisFunctionP, tParamVars, &protoParamP, &tempClassID, &tempArrayElemClassID, &tempArrayElemLevel, i))
				{	if (OBJ_ID(tParamVars->objRef))
						err = _ParamToLocal(api_data, OBJRECORD_P(&tParamVars->objRef), tParamVars->name, tempClassID, tempArrayElemClassID, tempArrayElemLevel);
					else
					{	if (protoParamP)
						{	if (protoParamP->classID == CLASSID_UNSPECIFIED)
								err = BufferToObjExt(api_data, "", 0, kStringClassID, false, protoParamP->name, LOCAL, VARIABLE, nil);
							else if (protoParamP->classID)
								err = BufferToObjExt(api_data, "", 0, protoParamP->classID, false, protoParamP->name, LOCAL, VARIABLE, nil);
							else
								err = XError(kBAPI_Error, Err_PrototypeMismatch); 
						}
						else
							err = XError(kBAPI_Error, Err_PrototypeMismatch); 
					}
					if (protoParamP)
						protoParamP++;
				}
			}
			if (err)
			{	destructRec.api_data = api_data;
				destructRec.scope = LOCAL;
				DLM_Dispose(&bRecP->localList, VariableDestructorExt, (long)&destructRec);
				bRecP->localList = saveLocalList;
				if NOT(bRecP->currentCtx.currentOffset)
					bRecP->currentCtx.currentOffset = BfrGetOffset(bRecP, paramVarsP[i-1].privateData);
			}
		}
	}
		
return err;
}

typedef struct {
		XErr			err;
		BifernoRecP		bRecP;
		long			saveMethodInExecutionList;
		long			saveMethodInExecutionID; 
		long			saveDefaultScope; 
		long			saveTot_graf_pars; 
		long			tLen; 
		long			saveLastFunctionReturnType; 
		long			totToReturn; 
		long			classID; 
		long			saveLine; 
		long			saveBisFunctionInitLine;
		CacheResult		*saveCurFileP;
		DLMRef			saveLocalList;
		Ptr				tPtr;
		Boolean			saveInTag;
		BlockRef		objsToReturnBlockRef;
		long			slot;
		BlockRef		block;
		Ptr					lastStatementP;
		long				lastStatementLen;
		} _ExecuteBifernoFunctionStack;

//===========================================================================================
static XErr	_CallUserVariablesDestructors(BifernoRecP bRecP, DLMRef list)
{
XErr				err = noErr;
Boolean				saveExit, saveStop; 
BfrDestructRec		destructRec;

	saveExit = bRecP->_exit;
	saveStop = bRecP->currentCtx._stop;
	bRecP->_exit = false;
	bRecP->currentCtx._stop = false;
	if (list)
	{	destructRec.api_data = (long)bRecP;
		destructRec.scope = LOCAL;
		err = DLM_Loop(list, BifernoDestructorCallBack_CheckFlags, (long)&destructRec, true, true);
	}
	bRecP->_exit = saveExit;
	bRecP->currentCtx._stop = saveStop;

return err;
}

//===========================================================================================
static XErr	_SetReturnValue(BifernoRecP bRecP, BAPI_Doc *bisFunctionP, ObjRecordP resultVarRecP)
{
XErr	err = noErr;
long	classID;

	if (classID = bisFunctionP->returnClassID)
	{	if NOT(bRecP->lastFuncResultObj.id)
		{	if (NOT(bRecP->currentCtx._stop) && NOT(bRecP->_exit))
				err = XError(kBAPI_Error, Err_ReturnValueRequired);
		}
		else if ((classID != CLASSID_UNSPECIFIED) && (classID != bRecP->lastFuncResultObj.classID && resultVarRecP))
			err = CoercionToRequestedType((long)bRecP, &bRecP->lastFuncResultObj, classID, resultVarRecP, kImplicitTypeCast);
		else if (resultVarRecP)
			*resultVarRecP = bRecP->lastFuncResultObj;	// this is in temp list
	}
	else if (bRecP->lastFuncResultObj.id)
		err = XError(kBAPI_Error, Err_FunctionIsVoid);
	else if (resultVarRecP)
		BAPI_InvalObjRef((long)bRecP, OBJREF_P(resultVarRecP));

return err;
}

//===========================================================================================
static XErr	_CheckSuperRequested(BifernoRecP bRecP, Boolean superRequested)
{
XErr	err = noErr;

	if (superRequested && NOT(bRecP->superObjRef.id))
		err = XError(kBAPI_Error, Err_SuperConstructorRequired);

return err;
}

//===========================================================================================
static XErr	_ExecuteBifernoFunction(long api_data, ParameterRec *paramVarsP, long totParams, BAPI_Doc *bisFunctionP, Boolean superRequested, long bapiDocID, ObjRecordP resultVarRecP)
{
XErr			err = noErr, err2 = noErr, releaseErr = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
long			tLen;
DLMRef			saveLocalList;
Ptr				tPtr;
long			oldVolatileLevel;
Ptr				saveP;
long			saveLen;
BfrDestructRec	destructRec;
CallerCtx		saveCallerCtx;

	if (api_data)
	{	oldVolatileLevel = SetVolatileLevel(bRecP);
		if (bisFunctionP->totParams > totParams)
			err = XError(kBAPI_Error, Err_PrototypeMismatch);
		else
		{	saveLocalList = bRecP->localList;
			if NOT(err = _SetFunctionLocalList(bRecP, bisFunctionP, paramVarsP, totParams/*, &objsToReturnBlockRef, &totToReturn*/))
			{	
				// Add a stack item
				BfrMoreStack(bRecP, bisFunctionP);
				
				// get the function body text
				tPtr = saveP = ((Ptr)bisFunctionP) + bisFunctionP->len;
				tLen = saveLen = bisFunctionP->ident.b.funcLength;
				
				// save context
				saveCallerCtx = bRecP->currentCtx;
				
				// replace context
				bRecP->currentCtx.returnClassID = bisFunctionP->returnClassID;
				bRecP->currentCtx.returnAeClass = bisFunctionP->returnAeClass;
				bRecP->currentCtx.returnAeLevel = bisFunctionP->returnAeLevel;
				bRecP->currentCtx.curMethodList = bisFunctionP->ident.b.list;
				bRecP->currentCtx.tot_graf_pars = 0;
				bRecP->currentCtx.defaultScope = LOCAL;
				bRecP->currentCtx.currentLine = 0;
				bRecP->currentCtx.methodInExecutionID = bapiDocID;
				bRecP->currentCtx.inTag = true;
				bRecP->currentCtx.bisFunctionInitLine = bisFunctionP->ident.b.fileLine;
				bRecP->currentCtx.leftMemberClass = 0;			// leftMemberClass must not be inherited in methods or function
				bRecP->currentCtx.switchObject.id = 0;			// leftMemberClass must not be inherited in methods or function
				bRecP->currentCtx.lastMultiStrStart = bRecP->currentCtx.lastMultiStrEnd = 0;
				CEquStr(bRecP->currentCtx.currentExecFile, bisFunctionP->ident.b.sourceFile.filePath);
				bRecP->currentCtx.processing = kProcessingFunction;
				
				//============= Init execution of code (the while manages goto/label inside the function)
				do
				{	if NOT(err = ProcessBlock(api_data, &tPtr, &tLen, 0))
					{	if (*bRecP->curLabelName)
						{	if NOT(err = GotoWasFound(api_data, &tPtr, &tLen, saveP, saveLen, 0, 0, saveCallerCtx.currentLine, false))
							{	if (*bRecP->curLabelName)
								{	NewMsgRecord(api_data, kLABEL_BAD, bRecP->curLabelName, 0, 0);
									err = XError(kBAPI_Error, Err_LabelNotFound);
								}
							}
						}
						else
							break;
					}
				} while NOT(err);
				//============= End execution of code
												
				// if the function contained "return" now is time to reset it
				bRecP->_return = false;
				
				// last stuff to complete execution of func
				if NOT(err)
				{	err = _SetReturnValue(bRecP, bisFunctionP, resultVarRecP);
					BAPI_InvalObjRef(api_data, OBJREF_P(&bRecP->lastFuncResultObj));
					err2 = _CallUserVariablesDestructors(bRecP, bRecP->localList);
					if (err2 && NOT(err))
						err = err2;
					if NOT(err)
						err = _CheckSuperRequested(bRecP, superRequested);
					if (err)
					{	// check to see if we are in resume-mode (note that in ProcessBlock resume is already checked)
						if NOT(bRecP->currentCtx.currentOffset)
							bRecP->currentCtx.currentOffset = BfrGetOffset(bRecP, tLen);
						if NOT(COMPILING(api_data))
						{	if (bRecP && (err || (err = gMemoryFullError)) && NOT(bRecP->_suspendResume))
							{	bRecP->criticalMem = (err == XError(kXLibError, ErrXMemory_Full)) || (err == XError(kBAPI_Error, Err_MemoryFull));
								if NOT(bRecP->criticalMem)
									err = CheckIfResume(api_data, err, nil, nil);
							}
						}
					}
				}

				if (NOT(err) || bRecP->resumeAlwaysCaller)
				{	// note that we can arrive here also if err != 0
					BfrLessStack(bRecP, bisFunctionP);
					destructRec.api_data = (long)bRecP;
					destructRec.scope = LOCAL;
					err2 = DLM_Dispose(&bRecP->localList, VariableDestructor, (long)&destructRec);
					if (NOT(err) && err2)
						err = err2;
					// resume previous context
					bRecP->currentCtx = saveCallerCtx;
					// set the old local list
					bRecP->localList = saveLocalList;
				}
				else
				{	// remain on present context
					if (resultVarRecP)	
						BAPI_InvalObjRef(api_data, OBJREF_P(resultVarRecP));
					bRecP->stopEval = true;
					// dispose the current file struct to remain on error code
					if (bRecP->currentCtx.processing != kProcessingInclude)
					{	if (bRecP->curFile.fileData)
						{	bRecP->curFile.dontCache = true;
							if (releaseErr = CFReleaseFile(&bRecP->curFile, 0))
								CDebugStr("_ExecuteBifernoFunction: releaseErr != 0");
							bRecP->noParamSmartRetry = true;	// the source is disposed, so saveP in _GetFunctionParam(smart) can be invalid
							bRecP->curFile = bisFunctionP->ident.b.sourceFile;
							bRecP->curFile.fileData = 0;		// don't dispose of it
							bRecP->stopEval = true;
						}
					}
				}
			}
		}
		ResumeVolatileLevel(bRecP, oldVolatileLevel);
	}

return err;
}

//===========================================================================================
static XErr	_LaunchConstructorMethod(long api_data, BifernoClass *bClassP, ObjRecord *thisObjRefP, ObjRecord *superObjRefP, ParameterRec *paramVarsP, long totParams, Boolean expectSuperInConstructor, ObjRecordP returnedSuperP, ObjRecordP resultObjRefP)
{
XErr			err = noErr;
BAPI_Doc		*bisFunctionP;
StateRec		stateRec;
BifernoRecP 	bRecP = (BifernoRecP)api_data;

	bisFunctionP = (BAPI_Doc*)GetPtr(bClassP->constructorDoc);
	_GetState(bRecP, &stateRec);
	if NOT(err = _SetNewState(bRecP, thisObjRefP, bClassP->extendedClassID, expectSuperInConstructor, superObjRefP))
	{	err = _ExecuteBifernoFunction(api_data, paramVarsP, totParams, bisFunctionP, /*totalLen, */expectSuperInConstructor, kConstrID, resultObjRefP);
		if (returnedSuperP)
			*returnedSuperP = bRecP->superObjRef;
	}
	if NOT(err)
		_ResetState(bRecP, &stateRec);

return err;
}

//===========================================================================================
static XErr	_LaunchBifernoMethod(long api_data, BifernoClass *bClassP, ObjRecord *thisObjRefP, ObjRecord *superObjRefP, ParameterRec *paramVarsP, long totParams, long function_list, long function_id, Boolean expectSuperInConstructor, ObjRecordP returnedSuperP, ObjRecordP resultObjRefP)
{
XErr			err = noErr;
long			totalLen;
BAPI_Doc		*bisFunctionP;
BlockRef		bisFunctionBl;
StateRec		stateRec;
BifernoRecP 	bRecP = (BifernoRecP)api_data;

	if NOT(err = GetBifernoFunctionRec(function_list, function_id, (Ptr*)&bisFunctionP, &bisFunctionBl, &totalLen))
	{	_GetState(bRecP, &stateRec);
		if NOT(err = _SetNewState(bRecP, thisObjRefP, bClassP->extendedClassID, expectSuperInConstructor, superObjRefP))
		{	err = _ExecuteBifernoFunction(api_data, paramVarsP, totParams, bisFunctionP, /*totalLen, */expectSuperInConstructor, function_id, resultObjRefP);
			if (returnedSuperP)
				*returnedSuperP = bRecP->superObjRef;
		}
		if NOT(err)
			_ResetState(bRecP, &stateRec);
		DisposeBlock(&bisFunctionBl);
	}

return err;
}

//===========================================================================================
static XErr	_LaunchBifernoStaticMethod(long api_data, long classID, ParameterRec *paramVarsP, long totParams, long function_list, long function_id, Boolean expectSuperInConstructor, ObjRecordP resultObjRefP)
{
XErr			err = noErr;
long			totalLen;
BAPI_Doc		*bisFunctionP;
BlockRef		bisFunctionBl;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
StateRec		stateRec;

	if NOT(err = GetBifernoFunctionRec(function_list, function_id, (Ptr*)&bisFunctionP, &bisFunctionBl, &totalLen))
	{	_GetState(bRecP, &stateRec);
		bRecP->methodInExecutionClass = classID;
		bRecP->visibilityClass = classID;
		bRecP->thisObjRef.id = bRecP->superObjRef.id = 0;
		err = _ExecuteBifernoFunction(api_data, paramVarsP, totParams, bisFunctionP, /*totalLen, */expectSuperInConstructor, function_id, resultObjRefP);
		if NOT(err)
			_ResetState(bRecP, &stateRec);
		DisposeBlock(&bisFunctionBl);
	}

return err;
}

//===========================================================================================
static XErr	_CallTypeCastMethod(long api_data, Biferno_ParamBlockPtr pbPtr, BifernoClass *bifernoClassP, ObjRecord *thisObjRefP, long methodObjID, ObjRecord *returnValueP, Boolean *divertedP)
{
XErr		err = noErr;

	if (methodObjID)
	{	*divertedP = false;
		err = _LaunchBifernoMethod(api_data, bifernoClassP, thisObjRefP, nil, nil, 0, bifernoClassP->methods, methodObjID, false, nil, returnValueP);
	}
	else if (bifernoClassP->extendedClassID && pbPtr)	// TypeCast to Obj doesn't simply divert, see caller if pbPtr == nil
	{	ObjRecord	superObjRef;

		*divertedP = true;
		if NOT(err = _GetSuperObj(api_data, thisObjRefP, &superObjRef))
			err = CDivert(kPrimitive, pbPtr, &superObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BifernoGetErrorName(long api_data, long classID, long errValue, char *errName)
{
BifernoClass 	*bifernoClassP = nil;
//BlockRef		bifernoClassBlock = 0;
long			tLen, objID;
uint32_t		bifernoClassSlot;
XErr			err = noErr;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
CStr15			tStr;

	if (errValue)
	{	if NOT(err = GetBifernoClassRecAlloc(bRecP, -classID, &bifernoClassP, /*&bifernoClassBlock, */&bifernoClassSlot))
		{	CNumToString(errValue, tStr);
			if (objID = DLM_GetObjID(bifernoClassP->errors, tStr, nil, nil))
			{	tLen = 63;
				err = DLM_GetObj(bifernoClassP->errors, objID, errName, &tLen, 0, nil);
				if (err == XError(kXHelperError, DLM_Err_NoMoreDataInObject))
					err = noErr;
				errName[tLen] = 0;
			}
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot/*, bifernoClassBlock*/);
		}
	}
	else
		CEquStr(errName, "Unknown error");

return err;
}

//===========================================================================================
XErr	CheckIfStatic(MemberAction *membIdentP, ObjRecordP objRefP, Boolean fromTryCurrent, Boolean getInfo, Boolean gettingReference)
{	
XErr	err = noErr;

	if (NOT(getInfo) && NOT(gettingReference))
	{	if (membIdentP->doc.isStatic)
		{	if (objRefP->id)
			{	if (fromTryCurrent)
					membIdentP->objRef.id = 0;
				else
					err = XError(kBAPI_Error, Err_MemberIsStatic);
			}
		}
		else if (NOT(objRefP->id) && NOT(getInfo))
			err = XError(kBAPI_Error, Err_MemberIsNotStatic);
	}
	
return err;
}
			
//===========================================================================================
XErr	BifernoClassHasMember(long api_data, char *memberName, long classID, ObjRecord *objRefP, BlockRef *membIdentBlockP, MemberAction **membActionP, int followChar, Boolean *memberExistsP, Boolean fromTryCurrent, SuperIsChangedNotify **notifyP, Boolean getInfo, Boolean gettingReference)
{
long			memberClassID, extID, objID;
uint32_t		bifernoClassSlot;
XErr			err = noErr;
BifernoClass 	*bifernoClassP = nil;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
Boolean			result, allocated = false;
uint32_t		slot = -1;
long			docLength;
MemberAction 	*membIdentP;
DLMRef			list;

	result = false;
	if (membIdentBlockP)
		*membIdentBlockP = 0;
	if NOT(err = GetBifernoClassRecAlloc(bRecP, -classID, &bifernoClassP, &bifernoClassSlot))
	{	if (followChar)
		{	if (followChar == '(')
			{	if (objID = DLM_GetObjIDExt(bifernoClassP->methods, memberName, nil, nil, &docLength))
				{	/*if (objID == bifernoClassP->constructorObjID)
						objID = 0;	// the constructor is not a real method, it has to be treated as "constructor"
					else*/
					memberClassID = classID;	// the class the method belongs to
					list = bifernoClassP->methods;
				}
			}
			else
			{	followChar = 0;
				if (objID = DLM_GetObjIDExt(bifernoClassP->properties, memberName, nil, &memberClassID, &docLength))
					list = bifernoClassP->properties;
			}
		}
		else	// look in both
		{
			/*
			if (objID = DLM_GetObjIDExt(bifernoClassP->methods, memberName, nil, nil, &docLength))
			{	memberClassID = classID;
				list = bifernoClassP->methods;
			}
			else
			{	objID = DLM_GetObjIDExt(bifernoClassP->properties, memberName, nil, &memberClassID, &docLength);
				list = bifernoClassP->properties;
			}
			*/
			if (objID = DLM_GetObjIDExt(bifernoClassP->properties, memberName, nil, &memberClassID, &docLength))
				list = bifernoClassP->properties;
			else
			{	objID = DLM_GetObjIDExt(bifernoClassP->methods, memberName, nil, nil, &docLength);
				memberClassID = classID;
				list = bifernoClassP->methods;
			}
		}
		if (objID)
		{	
		long	tLen;
		
			if (membIdentBlockP)
			{	tLen = sizeof(MemberAction) - sizeof(BAPI_Doc) + docLength;
				// if pass nil as membActionP always a BlockRef is allocated
				if (membActionP && (tLen == POOL_PROPERTY_ACTION_SIZE))
				{	if NOT(err = PoolNewPtr(gsDispatcherData.propertyActionPool, (Ptr*)&membIdentP, &slot))
					{	ClearBlock(membIdentP, tLen);
						membIdentP->slot = slot;
						*membIdentBlockP = 0;
					}
				}
				else
				{	if (*membIdentBlockP = NewBlockLocked(tLen, &err, (Ptr*)&membIdentP))
						ClearBlock(membIdentP, tLen);
				}
				if NOT(err)
				{	allocated = true;
					if (membActionP)
						*membActionP = membIdentP;
					membIdentP->id = objID;
					if NOT(getInfo)
						membIdentP->objRef = *objRefP;
					if NOT(err = DLM_GetObj(list, objID, (Ptr)&membIdentP->doc, &docLength, 0, nil))
					{	if ((membIdentP->doc.type == kProperty) || (membIdentP->doc.type == kConstant) || (membIdentP->doc.type == kError))
						{	err = CheckIfStatic(membIdentP, objRefP, fromTryCurrent, getInfo, gettingReference);
							/*if NOT(getInfo)
							{	if (membIdentP->doc.isStatic)
								{	if (objRefP->id)
									{	if (fromTryCurrent)
											membIdentP->objRef.id = 0;
										else
											err = XError(kBAPI_Error, Err_MemberIsStatic);
									}
								}
								else if (NOT(objRefP->id) && NOT(getInfo))
									err = XError(kBAPI_Error, Err_MemberIsNotStatic);
							}*/
							if NOT(err)
							{	if (notifyP && *notifyP)
								{	char *propP = (*notifyP)->propertyName[(*notifyP)->tot-1];
									
									if NOT(*propP)
										CEquStr(propP, membIdentP->doc.name);
								}
							}
						}
						else
						{	if NOT(err = DLM_GetObj(bifernoClassP->methods, objID, (Ptr)&membIdentP->doc, &docLength, 0, nil))
							{	err = CheckIfStatic(membIdentP, objRefP, fromTryCurrent, getInfo, gettingReference);
								/*if NOT(getInfo)
								{	if (NOT(membIdentP->doc.isStatic) && NOT(objRefP->id) && NOT(getInfo))
										err = XError(kBAPI_Error, Err_MemberIsNotStatic);
								}*/
							}
						}
					}
				}
			}
			result = true;
		}
		else if NOT(getInfo)
		{	while (NOT(objID) && NOT(err))
			{	if (extID = bifernoClassP->extendedClassID)
				{	if NOT(err = GetMemberInfo(api_data, memberName, extID, objRefP, membIdentBlockP, membActionP, followChar, &result, fromTryCurrent, notifyP, false, gettingReference))
					{	if (result)
						{	
						Byte			vis;
						
							membIdentP = *membActionP;	//(MemberAction*)GetPtr(*membIdentBlockP);
							if NOT(err = CheckIfStatic(membIdentP, objRefP, fromTryCurrent, getInfo, gettingReference))
							{	if (objRefP->id)	// if it's not static
								{	if (membIdentP->doc.type == kMethod)
										vis = membIdentP->doc.info.method.visibility;
									else
										vis = membIdentP->doc.info.property.visibility;
									if NOT(err = FillNotifyItem(objRefP, memberName, notifyP, vis))
									{	if NOT(err = BAPI_GetSuperObj(api_data, OBJREF_P(objRefP), OBJREF_P(&membIdentP->objRef)));
											*objRefP = membIdentP->objRef;
									}
								}
							}
							break;
						}
						else
						{	if (extID > 0)
							{	PluginRecord	*plugRecP = &gClassRecordBlockP[extID-1];	// try to see upper
								
								if (extID = plugRecP->extendedPluginID)	// Note: C Classes can extend only C Classes (so extID >= 0)
									err = CClassHasMember(api_data, memberName, extID, objRefP, membIdentBlockP, membActionP, followChar, &result, fromTryCurrent, notifyP, false, gettingReference);
								break;		// -> Can't return to Biferno Classes
							}
							else
							{	PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
								bifernoClassP = nil;
								err = GetBifernoClassRecAlloc(bRecP, -extID, &bifernoClassP, &bifernoClassSlot);		// try to see upper
							}
						}
					}
				}
				else
					break;
			}
		}
		if (bifernoClassP)
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
	}
	if (memberExistsP)
		*memberExistsP = result;
	if (err && allocated)
	{	if (*membIdentBlockP)
			DisposeBlock(membIdentBlockP);
		else
			PoolDisposePtr(gsDispatcherData.propertyActionPool, slot);
	}
	
return err;
}

//===========================================================================================
XErr	DestructVariableWithAllSupers(long api_data, ObjRecordP objRefP)
{								
BfrDestructRec	destructRec;
XErr			err = noErr;
ObjRecord		tObjRef, superObjRef;

	destructRec.api_data = api_data;
	tObjRef = *objRefP;
	do
	{
		destructRec.scope = tObjRef.scope;
		if NOT(err = VariableDestructor(tObjRef.list, tObjRef.id, 0, tObjRef.classID, (long)&destructRec))
		{	if NOT(err = _GetSuperObj(api_data, &tObjRef, &superObjRef))
				tObjRef = superObjRef;
			else
			{	if ((err == XError(kBAPI_Error, Err_ObjectNotFound)) || (err == XError(kBAPI_Error, Err_VariableNotInitialized)))
					err = noErr;
				break;
			}	
		}
	} while NOT(err);
	
return err;
}

//===========================================================================================
static XErr	_CloneProperty(DLMRef dlRef, long objID, unsigned short flags, long userData, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
#endif
XErr			err = noErr;
//ParameterRec	parameter;
ObjRecord		tObjRef;
ObjRef			tempObjRef;
BfrDestructRec	*destructRecP = (BfrDestructRec*)param;

	INVAL(tObjRef);
	OBJ_ID(tempObjRef) = objID;
	OBJ_LIST(tempObjRef) = dlRef;
	OBJ_CLASSID(tempObjRef) = userData;
	if (ContainsReference(OBJRECORD_P(&tempObjRef)))
	{	OBJ_TYPE(tempObjRef) = VARIABLE;
		OBJ_SCOPE(tempObjRef) = TEMP;
		if NOT(err = BAPI_Clone(destructRecP->api_data, &tempObjRef, OBJREF_P(&tObjRef), true))
		{	if NOT(err = DLM_ModifyObjExt(dlRef, objID, tObjRef.list, tObjRef.id, VariableDestructorExt, param, nil))
			{	// property is cloned, so will be destruct
				DLM_TurnOffFlag(dlRef, objID, kNoDestructor, kDLMWhole);
				err = DLM_TurnOnFlag(tObjRef.list, tObjRef.id, kNoDestructor, kDLMWhole);
			}
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	_CloneSuper(DLMRef dlRef, long objID, long flags, long userData, long api_data, ObjRecordP newSuperP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
XErr			err = noErr;
ParameterRec	parameter;
ObjRef			tempObjRef;

	OBJ_ID(tempObjRef) = objID;
	OBJ_LIST(tempObjRef) = dlRef;
	OBJ_CLASSID(tempObjRef) = userData;
	if (ContainsReference(OBJRECORD_P(&tempObjRef)))
	{	OBJ_TYPE(tempObjRef) = VARIABLE;
		OBJ_SCOPE(tempObjRef) = TEMP;
		err = BAPI_Clone(api_data, &tempObjRef, OBJREF_P(newSuperP));
	}
	else
		*newSuperP = OBJRECORD(parameter.objRef);
	
return err;
}
*/
//===========================================================================================
static XErr	_CloneSuper(long api_data, ObjRecordP superObjrefP, ObjRecordP newSuperP)
{
XErr	err = noErr;

	if (ContainsReference(OBJRECORD_P(superObjrefP)))
		err = BAPI_Clone(api_data, OBJREF_P(superObjrefP), OBJREF_P(newSuperP), true);
	else
		*newSuperP = *superObjrefP;
	
return err;
}

//===========================================================================================
XErr	BifernoDestructorCallBack(DLMRef dlRef, long objID, long flags, long classID, long scope, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
#endif
ObjRecord			varRec;
XErr				err = noErr;
BifernoInstance		instance;
long				tLen;
BfrDestructRec		destructRec;

	if (classID < 0)
	{	tLen = sizeof(BifernoInstance);	
		err = DLM_GetObj(dlRef, objID, (Ptr)&instance, &tLen, 0, nil);
		if (err == XError(kXHelperError, DLM_Err_NoMoreDataInObject))
			err = noErr;
		else if NOT(err)
		{	destructRec.api_data = api_data;
			destructRec.scope = scope;
			if NOT(err = DLM_Loop(instance.list, BifernoDestructorCallBack_CheckFlags, (long)&destructRec, true, true))
			{	varRec.id = objID;
				varRec.classID = classID;
				varRec.list = dlRef;
				varRec.scope = scope;
				err = CL_Destructor(api_data, &varRec);
			}
		}
	}

return err;
}

//===========================================================================================
XErr	BifernoDestructorCallBack_CheckFlags(DLMRef dlRef, long objID, unsigned short flags, long classID, long userData)
{
BfrDestructRec	*destructRecP = (BfrDestructRec*)userData;

	if (flags & kNoDestructor)
		return noErr;
	else
		return BifernoDestructorCallBack(dlRef, objID, flags, classID, destructRecP->scope, destructRecP->api_data);
}

//===========================================================================================
/*static XErr	_DisposeMethod(DLMRef dlRef, long objID, long flags, long classID, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags, classID, api_data)
BlockRef		protoParamBlock;
XErr			err = noErr;
long			tLen;

	tLen = sizeof(BlockRef);
	if NOT(err = DLM_GetObj(dlRef, objID, (Ptr)&protoParamBlock, &tLen, offsetof(BifernoFunc, protoParamBlock)+1, nil))
	{	if (protoParamBlock)
			DisposeBlock(&protoParamBlock);
	}

return err;
}
*/
//===========================================================================================
XErr	DisposeBifernoClass(DLMRef dlRef, long objID, unsigned short flags, long classID, long userData)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(classID, flags)
#endif
XErr			err = noErr;
long			tLen;
BifernoClass	bifernoClass;
BfrDestructRec	*destructRecP = (BfrDestructRec*)userData;
XErr			(*_destrFunc)(DLMRef *dlRefP, DLMLoopCallBack callBack, long param);
	
	tLen = sizeof(BifernoClass);
	if NOT(err = DLM_GetObj(dlRef, objID, (Ptr)&bifernoClass, &tLen, 0, nil))
	{	
		if (destructRecP->scope == APPLICATION || destructRecP->scope == PERSISTENT)
			_destrFunc = DLM_DisposeGlobal;
		else
			_destrFunc = DLM_Dispose;
		
		if (bifernoClass.properties)
			err = _destrFunc(&bifernoClass.properties, nil, 0L);
		if (bifernoClass.methods)
			err = _destrFunc(&bifernoClass.methods, nil, 0L);
		if (bifernoClass.staticProperties)
			err = _destrFunc(&bifernoClass.staticProperties, VariableDestructorExt, userData);
		if (bifernoClass.errors)
			err = _destrFunc(&bifernoClass.errors, nil, 0L);
		if (bifernoClass.constructorDoc)
			DisposeBlock(&bifernoClass.constructorDoc);
	}

return err;
}
				
//===========================================================================================
/*static XErr	_EmptyObject(long api_data, BifernoProperty *propertyRecP, long classID, long extendedClassID, Boolean fixedSize, char *nameP, DLMRef instanceList, ObjRecord *resultObjRefP)
{	
long		extendedClassID, destID, curID, flags;
ObjRecord		superObj;
DLMRef		curList;
Boolean		superFixedSize;
XErr		err = noErr;

	if (propertyRecP->fixedSize)
		flags = kFixedSize;
	else
		flags = 0L;
	destID = DLM_NewObj(instanceList, nameP, "", 0, classID, flags, &err);
	if (extendedClassID = extendedClassID)
	{	superFixedSize = propertyRecP->superFixedSize;
		curList = instanceList;
		curID = destID;
		do
		{	if NOT(err = BAPI_BufferToObj(api_data, "", 0, extendedClassID, superFixedSize, nil, TEMP, VARIABLE, &superObj))
			{	if NOT(err = DLM_NewSuperObj(curList, curID, superObj.list, superObj.id, &curList, &curID))
				{	if NOT(err = BAPI_ExtendedClass(api_data, extendedClassID, &extendedClassID))
					{	if (extendedClassID)
							err = BAPI_FixedSize(api_data, extendedClassID, &superFixedSize);
					}
				}
			}
		} while (extendedClassID && NOT(err));
	}
	if NOT(err)
	{	if (resultObjRefP)
		{	resultObjRefP->list = instanceList;
			resultObjRefP->id = destID;
			resultObjRefP->classID = classID;
		}
	}

return err;
}*/

//===========================================================================================
XErr	DefaultProperty(BifernoRecP bRecP, BAPI_Doc *propertyRecP, char *propName, DLMRef instanceList, long instanceScope, Boolean isStatic, ObjRecord *resultObjRefP)
{
XErr		err = noErr;
Ptr			tempP;
long		saveLine, parNum, tempLen;
ObjRecord		tObjRef;
long		api_data = (long)bRecP;
//int			arrayLevel;
char		*nameP;
long		destID;
CStr255		aCStr;

	if (isStatic)
		nameP = propName;
	else
		nameP = nil;
	if (*propertyRecP->info.property.defaultStr)
	{	tempP = propertyRecP->info.property.defaultStr;
		tempLen = CLen(tempP);
		parNum = 0;
		saveLine = bRecP->currentCtx.currentLine;
		bRecP->currentCtx.currentLine = 0;
		err = Evaluate(api_data, propertyRecP->returnClassID, kExplicitTypeCast, &tempP, &tempLen, nil, &tObjRef, kNoFlowControl, &parNum, true/*, nil*/);
		bRecP->currentCtx.currentLine = saveLine;
		if (parNum)
			err = XError(kBAPI_Error, Err_RoundBracketExpected);
		if NOT(err)
		{
		Boolean	fixedSize;
		long	clID = propertyRecP->returnAeClass;
		
			if NOT(clID)
				fixedSize = false;
			else
				err = BAPI_FixedSize(api_data, clID, &fixedSize);
			if NOT(err)
				err = CloneObject(api_data, &tObjRef, nameP, instanceList, instanceScope, propertyRecP->returnClassID, clID, false, fixedSize, &destID, nil, true);
		}
		if (NOT(err) && resultObjRefP)
		{	resultObjRefP->list = instanceList;
			resultObjRefP->id = destID;
			resultObjRefP->classID = propertyRecP->returnClassID;
		}
	}
	else
	{	
		err = CreateEmptyObject(api_data, nameP, instanceList, instanceScope, propertyRecP->returnClassID, propertyRecP->returnAeLevel, propertyRecP->returnAeClass, -1, false, resultObjRefP);
		/*
		ClearBlock(&tObjRef, sizeof(ObjRecord));
		tObjRef.list = instanceList;
		tObjRef.classID = propertyRecP->classID;
		arrayLevel = propertyRecP->header.arrayLevel;
		if (propertyRecP->classID == gsDispatcherData.arrayConstructor)
		{	DLMRef 				arrayDLRef;
			long				objID;
			
			tObjRef.id = DLM_NewArray(tObjRef.list, nameP, gsDispatcherData.arrayConstructor, 0, 0, &err);
			if (propertyRecP->header.arrayElementClassID)	// something like string[][]
			{	if (NOT(err) && (--arrayLevel > 0))
				{	do {
						if NOT(err = DLM_GetArrayInfo(tObjRef.list, tObjRef.id, &arrayDLRef, nil, nil))
						{	objID = DLM_NewArray(arrayDLRef, "1", gsDispatcherData.arrayConstructor, 0, 0, &err);
							if NOT(err = DLM_SetArrayDim(tObjRef.list, tObjRef.id, 1, true, nil, 0))	// only to update arMaxDim
							{	tObjRef.list = arrayDLRef;
								tObjRef.id = objID;
							}
						}
					} while (NOT(err) && (--arrayLevel > 0));
				}
			}
			if (NOT(err) && resultObjRefP)
			{	*resultObjRefP = tObjRef;
				resultObjRefP->classID = propertyRecP->classID;
			}
		}
		else
		{	long classID = propertyRecP->classID;
			// destID = DLM_NewObj(tObjRef.list, nameP, "", 0, propertyRecP->classID, 0L, &err);
			if (classID == kBooleanClassID)
				err = CL_BooleanToObj(api_data, false, resultObjRefP);
			else if ((classID == kStringClassID) || (classID == CLASSID_UNSPECIFIED))
				err = CL_StringToObj(api_data, "", 0, resultObjRefP);
			else if (classID == kDoubleClassID)
				err = CL_DoubleToObj(api_data, 0, resultObjRefP);
			else if (classID == kLongClassID)
				err = CL_LongToObj(api_data, 0, resultObjRefP);
			else if (classID == kIntClassID)
				err = CL_IntToObj(api_data, 0, resultObjRefP);
			else if (classID == kUnsignedClassID)
				err = CL_UnsignedToObj(api_data, 0, resultObjRefP);
			else if (classID == kCharClassID)
				err = CL_CharToObj(api_data, 0, resultObjRefP);
			else
			{	Boolean		fixedSize;
			
				if NOT(err = BAPI_FixedSize(api_data, classID, &fixedSize))
				{	destID = DLM_NewObj(tObjRef.list, nameP, "", fixedSize, classID, 0L, &err);
					if NOT(err)
					{	if (resultObjRefP)
						{	resultObjRefP->list = tObjRef.list;
							resultObjRefP->id = destID;
							resultObjRefP->classID = propertyRecP->classID;
						}
					}
				}
			}
		}*/
	}
	if (err)
	{	
	long	propNameLen;
	
		if (propName)
			propNameLen = CLen(propName);
		else
			propNameLen = 1;	// "?"
		if ((CLen(propertyRecP->prototype) + 1 + propNameLen + 3 + CLen(propertyRecP->info.property.defaultStr)) <= 255)
		{	CEquStr(aCStr, propertyRecP->prototype);
			CAddStr(aCStr, " ");
			CAddStr(aCStr, " = ");
			CAddStr(aCStr, propertyRecP->info.property.defaultStr);
			NewMsgRecord(api_data, kDOING, aCStr, 0, 0);
		}
	}

return err;
}
				
//===========================================================================================
XErr	GetBifernoClassRecAlloc(BifernoRecP bRecP, long classObjID, BifernoClass **bifernoClassPPtr, uint32_t *slotP)
{
XErr			err = noErr;
long			tLen;

	if NOT(err = PoolNewPtr(gsDispatcherData.bifernoClassPool, (Ptr*)bifernoClassPPtr, slotP))
	{	tLen = sizeof(BifernoClass);
		if (err = GetUserClassRecord(bRecP, -classObjID, (Ptr)*bifernoClassPPtr, &tLen, 0, nil))
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, *slotP);
	}
	
return err;
}

//===========================================================================================
// wants classObjID > 0
XErr	GetBifernoClassRec(BifernoRecP bRecP, long classObjID, BifernoClass	*bifernoClassP)
{
XErr			err = noErr;
long			tLen;

	tLen = sizeof(BifernoClass);
	// ex err = DLM_GetObj(bRecP->application.classesList, classObjID, (Ptr)bifernoClassP, &tLen, 0, nil);
	err = GetUserClassRecord(bRecP, -classObjID, (Ptr)bifernoClassP, &tLen, 0, nil);
	
return err;
}

//===========================================================================================
// wants classObjID > 0
XErr	GetBifernoFunctionRec(DLMRef list, long funcObjID, Ptr *recP, BlockRef *bRefP, long *totalLenP)
{
XErr		err = noErr;
long		tLen;
BlockRef	bl = 0;
Ptr			p;

	if NOT(err = DLM_GetObj(list, funcObjID, nil, &tLen, 0, nil))
	{	if (bl = NewBlockLocked(tLen, &err, &p))
		{	//LockBlock(bl);
			//p = GetPtr(bl);
			if NOT(err = DLM_GetObj(list, funcObjID, p, &tLen, 0, nil))
			{	if (recP)
					*recP = p;
				if (bRefP)
					*bRefP = bl;
				if (totalLenP)
					*totalLenP = tLen;
			}
		}
	}

if (err && bl)
	DisposeBlock(&bl);
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	BifernoSetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
SetPropertyRec		*setPropertyRec = &pbPtr->param.setPropertyRec;
BAPI_Doc			*propDocP = setPropertyRec->bapiDocP;
BifernoRecP			bRecP = (BifernoRecP)pbPtr->api_data;
long				api_data = pbPtr->api_data;
long				propObjID, tLen;
BifernoClass 		*bifernoClassP;
ObjRecord			tempObjRef;
long				classID;
Boolean				isStatic, toDestr, sameObj = false;
Boolean				needSer;
BfrDestructRec		destructRec;
uint32_t			bifernoClassSlot;

	propObjID = setPropertyRec->propertyID;
	if (propDocP->isStatic)
	{	isStatic = true;
		//propObjID = -propObjID;
		needSer = false;
	}
	else
	{	isStatic = false;
		err = BAPI_NeedSerialize(api_data, &setPropertyRec->objRef, &needSer);
	}
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if NOT(err = GetBifernoClassRecAlloc(bRecP, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
		{	classID = -(long)pbPtr->plugin_global_dataP;
			/*propObjID = setPropertyRec->propertyID;
			if (propObjID < 0)
			{	isStatic = true;
				propObjID = -propObjID;
			}
			else
				isStatic = false;*/
			//tLen = sizeof(PropertyHeader);
			//if NOT(err = DLM_GetObj(bifernoClassP->properties, propObjID, (Ptr)&propHeader, &tLen, offsetof(BifernoProperty, header)+1, nil))
			{	if (propDocP->type == kError)
					err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
				else
				{	if (_CantAccessMember(bRecP,  /*bRecP->methodInExecutionClass, */propDocP->info.property.visibility, classID))
						err = XError(kBAPI_Error, Err_CantAccessThisMember);
					else
					{	if (isStatic)
						{	unsigned short	flags;
						
							propObjID -= bifernoClassP->totNonStatic;	// shift because list contains only static
							if NOT(err = DLM_GetInfo(bifernoClassP->staticProperties, propObjID, &flags, &tempObjRef.classID, nil))
							{	if (flags & kCostant)
									err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
								else
								{	tempObjRef.list = bifernoClassP->staticProperties;
									tempObjRef.id = propObjID;
									tempObjRef.scope = OBJ_SCOPE(setPropertyRec->objRef);	//ex 0;
									tempObjRef.type = VARIABLE;
								}
							}
						}
						else
						{	BifernoInstance		instance;
							
							tLen = sizeof(BifernoInstance);
							err = BAPI_ReadObj(pbPtr->api_data, &setPropertyRec->objRef, (Ptr)&instance, &tLen, 0, nil);
							if (err == XError(kBAPI_Error, Err_VariableNotInitialized))
							{	err = XError(kBAPI_Error, Err_IllegalSetProperty);
								// toInitialize = true;
							}
							if NOT(err)
							{	//if NOT(toInitialize)
								//	err = DLM_GetInfo(instance.list, propObjID, nil, &tempObjRef.classID, nil)
								//tLen = sizeof(long);
								//err = DLM_GetObj(bifernoClassP->properties, propObjID, (Ptr)&tempObjRef.classID, &tLen, offsetof(BifernoProperty, classID)+1, nil);
								//if NOT(err)
								{	if (propDocP->info.property.isConst)
										err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
									else
									{	/*if (toInitialize)
											INVAL(tempObjRef);
										else
										{	*/
										tempObjRef.list = instance.list;
										tempObjRef.id = propObjID;		// here we assume that property in instance are ordered as property in classRec 
										tempObjRef.scope = OBJ_SCOPE(setPropertyRec->objRef);	//ex 0;
										tempObjRef.type = VARIABLE;
										tempObjRef.classID = propDocP->returnClassID;
										//}
									}
								}
							}
						}
					}
				}
			}
			if NOT(err)
			{	if (setPropertyRec->propertyDim/* && NOT(toInitialize)*/)
				{	// Note: this depends on structs DLM_ArrayIndexRec == ArrayIndexRec
					err = DLM_ResolveArrayElem(tempObjRef.list, tempObjRef.id, (DLM_ArrayIndexRec*)setPropertyRec->propertyIndex, (short)setPropertyRec->propertyDim, nil, true, nil, &tempObjRef.list, &tempObjRef.id, &tempObjRef.classID, 0L, 0L, nil, 0L, nil);
					if (err && (err == XError(kXHelperError, DLM_Err_ObjectNotFound)))
						err = XError(kBAPI_Error, Err_ArrayElementNotFound);
				}
				if NOT(err)
				{	XErr		err2 = noErr;
					DLMRef		tempList;
					long		tempID;
					Boolean		isImm;
					ObjRecord	valueObjRef;
					
					if ((tempObjRef.classID == gsDispatcherData.arrayConstructor) && propDocP->returnClassID)
					{	
					Boolean		fixedSize;
					
						if NOT(tempObjRef.classID)
							fixedSize = false;
						else
							err = BAPI_FixedSize(api_data, tempObjRef.classID, &fixedSize);
						if NOT(err)
						{	if NOT(err = CloneObject(api_data, OBJRECORD_P(&setPropertyRec->value), nil, bRecP->volatileList, TEMP, tempObjRef.classID, propDocP->returnAeClass, false, fixedSize, &tempID, nil, true))
							{	tempList = bRecP->volatileList;
								isImm = false;
							}
						}
					}
					else
					{	if NOT(isImm = IS_IMMEDIATE(setPropertyRec->value))
						{	tempList = OBJ_LIST(setPropertyRec->value);
							tempID = OBJ_ID(setPropertyRec->value);
						}
					}
					if (NOT(err) && (isImm || NOT(sameObj = SameObj(tempObjRef.list, tempObjRef.id, tempList, tempID))))
					{	if NOT(err = IsToDestruct(&tempObjRef, &toDestr))
						{	if (toDestr)
							{	destructRec.api_data = api_data;
								destructRec.scope = tempObjRef.scope;
								err = DestructVariableWithAllSupers(api_data, &tempObjRef);
								// err = VariableDestructorExt(tempObjRef.list, tempObjRef.id, 0, tempObjRef.classID, (long)&destructRec);
							}
							if NOT(err)
							{	
							ObjRecord	theValue;
							
								// ex if NOT(err = DLM_ModifyObjExt(tempObjRef.list, tempObjRef.id, tempList, tempID, VariableDestructorExt, api_data))
								valueObjRef = OBJRECORD(setPropertyRec->value);
								if NOT(isImm)
								{	valueObjRef.list = tempList;
									valueObjRef.id = tempID;
								}
								// ex if (propDocP->returnClassID != valueObjRef.classID)
								if (tempObjRef.classID && (tempObjRef.classID != valueObjRef.classID))
									err = BAPI_TypeCast(api_data, OBJREF_P(&valueObjRef), propDocP->returnClassID, OBJREF_P(&theValue), kExplicitTypeCast);
								else
									theValue = valueObjRef;
								if NOT(err)
								{	if NOT(err = BAPI_ReplaceObj(api_data, &OBJREF(tempObjRef), OBJREF_P(&theValue), false))
									{	if NOT(isImm)	
										{	if (tempList == bRecP->volatileList)
											{	if (DLM_IsArray(tempList, tempID))
													DLM_TurnOffFlag(tempList, tempID, kIsArray, kDLMMain);
												err = DLM_TurnOnFlag(tempList, tempID, kNoDestructor, kDLMWhole);
											}
											else
												CDebugStr("BifernoSetProperty: non doveva succedere");
										}
									}
									else	// if NOT(toInitialize)
										err2 = DLM_TurnOnFlag(tempObjRef.list, tempObjRef.id, kNoDestructor, kDLMElements);
								}
							}
						}
					}
				}
			}
			// call: void SetProperty(string propertyName)
			if (NOT(err) && NOT(sameObj) && bifernoClassP->setPropertyObjID && ((bRecP->currentCtx.curMethodList != bifernoClassP->methods) || (bRecP->currentCtx.methodInExecutionID != bifernoClassP->setPropertyObjID)) && (propDocP->info.property.visibility != kPrivate))
			{	ParameterRec	param;

				BAPI_ClearParameterRec(api_data, &param);
				if NOT(err = BAPI_StringToObj(api_data, setPropertyRec->propertyName, CLen(setPropertyRec->propertyName), &param.objRef))
					err = _LaunchBifernoMethod(api_data, bifernoClassP, OBJRECORD_P(&setPropertyRec->objRef), nil, &param, 1, bifernoClassP->methods, bifernoClassP->setPropertyObjID, false, nil, nil);
			}
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static XErr	BifernoGetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;
BAPI_Doc			*propDocP = getPropertyRec->bapiDocP;
BifernoRecP			bRecP = (BifernoRecP)pbPtr->api_data;
long				api_data = pbPtr->api_data;
uint32_t			bifernoClassSlot;
long				propObjID, tLen;
BifernoClass 		*bifernoClassP;
//BlockRef			bifernoClassBlock;
ObjRecord				tempObjRef;
//ParameterRec		param;
long				classID;
//PropertyHeader		propHeader;
Boolean				isStatic;
Boolean				needSer;

	propObjID = getPropertyRec->propertyID;
	if (propDocP->isStatic)	// static
	{	isStatic = true;
		//propObjID = -propObjID;
		needSer = false;
	}
	else
	{	isStatic = false;
		err = BAPI_NeedSerialize(api_data, &getPropertyRec->objRef, &needSer);
	}
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if NOT(err = GetBifernoClassRecAlloc(bRecP, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
		{	classID = -(long)pbPtr->plugin_global_dataP;
			/*if (propObjID < 0)
			{	isStatic = true;
				propObjID = -propObjID;
			}
			else
				isStatic = false;*/
			//tLen = sizeof(PropertyHeader);
			//if NOT(err = DLM_GetObj(bifernoClassP->properties, propObjID, (Ptr)&propHeader, &tLen, offsetof(BifernoProperty, header)+1, nil))
			{	if (_CantAccessMember(bRecP,  /*bRecP->methodInExecutionClass, */propDocP->info.property.visibility, classID))
					err = XError(kBAPI_Error, Err_CantAccessThisMember);
				else
				{	if (isStatic)
					{	unsigned short	flags;
					
						propObjID -= bifernoClassP->totNonStatic;	// shift because list contains only static
						tempObjRef.id = propObjID;
						tempObjRef.list = bifernoClassP->staticProperties;
						if IS_LOCAL(classID)
							tempObjRef.scope = GLOBAL;
						else
							tempObjRef.scope = APPLICATION;
						if NOT(err = DLM_GetInfo(bifernoClassP->staticProperties, propObjID, &flags, &tempObjRef.classID, nil))
						{	if (flags & kCostant)
								tempObjRef.type = CONSTANT;
							else
								tempObjRef.type = VARIABLE;
						}
					}
					else
					{	BifernoInstance		instance;
							
						tLen = sizeof(BifernoInstance);
						if NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&instance, &tLen, 0, nil))
						{	if NOT(err = DLM_GetInfo(instance.list, propObjID, nil, &tempObjRef.classID, nil))
							{	tempObjRef.list = instance.list;
								tempObjRef.id = propObjID;		// here we assume that property in instance are ordered as property in classRec 
								tempObjRef.scope = OBJ_SCOPE(getPropertyRec->objRef);
								if (propDocP->info.property.isConst)
									tempObjRef.type = CONSTANT;	// OBJ_TYPE(getPropertyRec->objRef);
								else
									tempObjRef.type = VARIABLE;
							}
						}
					}
				}
			}
			if NOT(err)
			{	if (getPropertyRec->propertyDim)
				{	// Note: this depends on structs DLM_ArrayIndexRec == ArrayIndexRec
					err = DLM_ResolveArrayElem(tempObjRef.list, tempObjRef.id, (DLM_ArrayIndexRec*)getPropertyRec->propertyIndex, (short)getPropertyRec->propertyDim, nil, false, nil, &tempObjRef.list, &tempObjRef.id, &tempObjRef.classID, 0, 0, nil, 0, nil);
					if (err && (err == XError(kXHelperError, DLM_Err_ObjectNotFound)))
						err = XError(kBAPI_Error, Err_ArrayElementNotFound);
					
				}
				if NOT(err)
				{	getPropertyRec->resultObjRef = OBJREF(tempObjRef);
					/*param.objRef = tempObjRef;
					*param.name = 0;
					param.expLen = 0;
					param.expP = nil;
					err = CL_Clone(api_data, TEMP, tempObjRef.type, nil, tempObjRef.classID, &param, 1, 0, &getPropertyRec->resultObjRef);
					*/			
				}
			}
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
			//DisposeBlock(&bifernoClassBlock);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
// Don't dispose instance itself
static XErr	BifernoDestructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr, err2 = noErr;
uint32_t		bifernoClassSlot; 
long			api_data = pbPtr->api_data;
BifernoRecP		bRecP = (BifernoRecP)api_data;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
ObjRecord		saveObjRefInDestruction, *thisObjRefP;
long			tLen;	//, classID = -(long)pbPtr->plugin_global_dataP;
BifernoClass	*bifernoClassP;
//ErrorMsgRecord	*saveErrMessageRecP = nil;
//BlockRef		saveErrMessageRecBlock = 0;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(long);
		if NOT(err2 = GetBifernoClassRecAlloc(bRecP, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
		{	if (bifernoClassP->destructorObjID && NOT(bifernoClassP->flags & kDontExecuteDestructor))
			{	/*if (GetTotMsgRecords(api_data))
				{	if (saveErrMessageRecBlock = NewBlockLocked(sizeof(ErrorMsgRecord), nil, (Ptr*)&saveErrMessageRecP))
						GetMsgRecords(api_data, saveErrMessageRecP);
				}*/
				thisObjRefP = OBJRECORD_P(&destructorRecP->objRef);		
				saveObjRefInDestruction = bRecP->objRefInDestruction;
				bRecP->objRefInDestruction = *thisObjRefP;
				err = _LaunchBifernoMethod(api_data, bifernoClassP, thisObjRefP, nil, nil, 0, bifernoClassP->methods, bifernoClassP->destructorObjID, false, nil, nil);
				bRecP->objRefInDestruction = saveObjRefInDestruction;
				/*if (saveErrMessageRecP)
				{	SetMsgRecords(api_data, saveErrMessageRecP);
					DisposeBlock(&saveErrMessageRecBlock);
				}
				else
					ResetMsgRecords(api_data);*/
				if (err)
				{	XErr			err2 = noErr;
					
					bifernoClassP->flags |= kDontExecuteDestructor;		// Errare � umano, ma perseverare...
					err2 = ModifyUserClassRecord(bRecP, -(long)pbPtr->plugin_global_dataP, (Ptr)bifernoClassP, sizeof(BifernoClass), -1, nil, 0, nil);
				}
			}
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	BifernoExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*executeMethodRecP = &pbPtr->param.executeMethodRec;
BAPI_Doc			*methDocP = executeMethodRecP->bapiDocP;
BifernoRecP			bRecP = (BifernoRecP)pbPtr->api_data;
uint32_t			bifernoClassSlot;
long				api_data = pbPtr->api_data;
long				methodObjID;
BifernoClass 		*bifernoClassP;
long				classID;
//Byte				visibility;
Boolean				saveSideEffect, isStatic;
Boolean				needSer;

	methodObjID = executeMethodRecP->methodID;
	if (methDocP->isStatic)
	{	isStatic = true;
		//methodObjID = -methodObjID;
		needSer = false;
	}
	else
	{	isStatic = false;
		err = BAPI_NeedSerialize(api_data, &executeMethodRecP->objRef, &needSer);
	}
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if NOT(err = GetBifernoClassRecAlloc(bRecP, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
		{	classID = -(long)pbPtr->plugin_global_dataP;
			/*methodObjID = executeMethodRecP->methodID;
			if (methodObjID < 0)
			{	isStatic = true;
				methodObjID = -methodObjID;
			}
			else
				isStatic = false;*/
			//tLen = sizeof(Byte);
			//if NOT(err = DLM_GetObj(bifernoClassP->methods, methodObjID, (Ptr)&visibility, &tLen, offsetof(BifernoFunc, visibility)+1, nil))
			{	if (_CantAccessMember(bRecP,  /*bRecP->methodInExecutionClass, */methDocP->info.method.visibility, classID))
					err = XError(kBAPI_Error, Err_CantAccessThisMember);
			}
			if NOT(err)
			{	saveSideEffect = bRecP->sideEffect;
				bRecP->sideEffect = false;
				err = _LaunchBifernoMethod(api_data, bifernoClassP, OBJRECORD_P(&executeMethodRecP->objRef), nil, executeMethodRecP->paramVarsP, executeMethodRecP->totParams, bifernoClassP->methods, methodObjID, false, nil, OBJRECORD_P(&executeMethodRecP->resultObjRef));
				executeMethodRecP->sideEffect = false;	// bRecP->sideEffect;
				/*
				ex: executeMethodRecP->sideEffect = bRecP->sideEffect;
				non credo che ci sia bisogno del side effect per i metodi Biferno in quanto la GetProperty
				torna l'objref vero, non una copia (come per le classi C)
				
				proviamo...
				*/
				bRecP->sideEffect = saveSideEffect;
			}
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static XErr	BifernoExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				saveCloneID, api_data = pbPtr->api_data;
uint32_t			bifernoClassSlot;
BifernoRecP			bRecP = (BifernoRecP)api_data;
ExecuteOperationRec	*executeOperationRecP = &pbPtr->param.executeOperationRec;
ObjRecord			clonedObjRef, *thisObjRefP;
ParameterRec 		paramVar[2];
BifernoClass 		*bifernoClassP;
Boolean				isComp, needSer;
long				operationObjID;

	if NOT(err = BAPI_NeedSerialize(api_data, &executeOperationRecP->objRef1, &needSer))
	{	if NOT(needSer)
			err = BAPI_NeedSerialize(api_data, &executeOperationRecP->objRef2, &needSer);
		if NOT(err)
		{	if (needSer)
				XThreadsEnterCriticalSection();
			if NOT(err = GetBifernoClassRecAlloc(bRecP, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
			{	thisObjRefP = OBJRECORD_P(&executeOperationRecP->objRef1);
				
				switch(executeOperationRecP->operation)
				{
					case EVAL_GTH:
					case EVAL_LTH:
					case EVAL_GEQ:
					case EVAL_LEQ:
					case EVAL_EQUA:
					case EVAL_NEQUA:
						operationObjID = bifernoClassP->compareObjID;
						isComp = true;
						break;
					
					default:
						operationObjID = bifernoClassP->operationObjID;
						isComp = false;
						break;
				}
				
				if (operationObjID)
				{	INVAL(paramVar[0].objRef);
					*paramVar[0].name = 0;
					//paramVar[0].expP = nil;
					//paramVar[0].expLen = 0;
					if (OBJ_CLASSID(executeOperationRecP->objRef2) != thisObjRefP->classID)
						err = CL_TypeCast(api_data, OBJRECORD_P(&executeOperationRecP->objRef2), thisObjRefP->classID, OBJRECORD_P(&paramVar[0].objRef), kExplicitTypeCast);
					else
						paramVar[0].objRef = executeOperationRecP->objRef2;
					if NOT(err)
					{	INVAL(paramVar[1].objRef);
						//paramVar[1].expP = nil;
						//paramVar[1].expLen = 0;
						*paramVar[1].name = 0;
						if NOT(err = _OperationToStringObj(api_data, executeOperationRecP->operation, OBJRECORD_P(&paramVar[1].objRef)))
						{	saveCloneID = bifernoClassP->cloneObjID;
							bifernoClassP->cloneObjID = 0;	// don't call clone
							INVAL(clonedObjRef);
							err = BAPI_Clone(api_data, OBJREF_P(thisObjRefP), OBJREF_P(&clonedObjRef), true);
							bifernoClassP->cloneObjID = saveCloneID;
							if NOT(err)
							{	if NOT(err = _LaunchBifernoMethod(api_data, bifernoClassP, &clonedObjRef, nil, paramVar, 2, bifernoClassP->methods, operationObjID, false, nil, OBJRECORD_P(&executeOperationRecP->resultObjRef)))
								{	if NOT(isComp)
										executeOperationRecP->resultObjRef = OBJREF(clonedObjRef);
								}
							}
						}
					}
				}
				else if (bifernoClassP->extendedClassID)
				{	ObjRecord	superObjRef;
				
					if NOT(err = _GetSuperObj(api_data, thisObjRefP, &superObjRef))
						err = CDivert(kExecuteOperation, pbPtr, &superObjRef);
				}
				else
					err = XError(kBAPI_Error, Err_IllegalOperation);
				PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
			}
			if (needSer)
				XThreadsLeaveCriticalSection();
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_SetNoDestrProperty(DLMRef dlRef, long objID, unsigned short flags, long userData, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags, userData)
#endif
long	firstToSet = ((BfrDestructRec*)param)->scope;

	if (objID >= firstToSet)
		return DLM_TurnOnFlag(dlRef, objID, kNoDestructor, kDLMWhole);
	else
		return noErr;
}


//===========================================================================================
static XErr	BifernoClone(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
long			classObjID = (long)pbPtr->plugin_global_dataP;
long 			idErr, tLen, api_data = pbPtr->api_data;
uint32_t		bifernoClassSlot;
BifernoRecP		bRecP = (BifernoRecP)api_data;
BifernoInstance	instance, instanceSource;		
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
BifernoClass 	*bifernoClassP;
ObjRecord		newSuperObjRef, superObjRef, *thisObjRefP;
Boolean			needSer;
BfrDestructRec	destructRec;
ObjRecord		*resultObjRefP = OBJRECORD_P(&constructorRecP->resultObjRef);

	INVAL(newSuperObjRef);
	INVAL(superObjRef);
	thisObjRefP = OBJRECORD_P(&constructorRecP->varRecsP[0].objRef);
	if NOT(err = BAPI_NeedSerialize(api_data, OBJREF_P(thisObjRefP), &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if (thisObjRefP->classID == -(long)pbPtr->plugin_global_dataP)
		{	if NOT(err = GetBifernoClassRecAlloc(bRecP, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
			{	tLen = sizeof(BifernoInstance);
				err = DLM_GetObj(thisObjRefP->list, thisObjRefP->id, (Ptr)&instanceSource, &tLen, 0, nil);
				if (err == XError(kXHelperError, DLM_Err_NoMoreDataInObject))
				{	err = XError(kBAPI_Error, Err_VariableNotInitialized);
					// err = BAPI_BufferToObj(api_data, "", 0, -classObjID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
				}
				else if NOT(err)
				{	// DLM_CloneList copies the entire instance list + all the super lists
					if NOT(err = DLM_CloneList(instanceSource.list, &instance.list))
					{	if (bifernoClassP->extendedClassID)
						{	if NOT(err = _GetSuperObj((long)bRecP, thisObjRefP, &superObjRef))
							{	// Clone the super (with its supers)
								// ex if NOT(err = _CloneSuper(superObjRef.list, superObjRef.id, 0L, superObjRef.classID, api_data, &newSuperObjRef))
								if NOT(err = _CloneSuper(api_data, &superObjRef, &newSuperObjRef))
								{	// BAPI_NewObjWithSuper copies the obj with his super (and supers of super) in the list
									if NOT(err = BAPI_BufferToObjWithSuper(api_data, (Ptr)&instance, sizeof(BifernoInstance), -classObjID, true, OBJREF_P(&newSuperObjRef), constructorRecP->privateData, OBJREF_P(resultObjRefP)))
										;//err = DLM_TurnOnFlag(newSuperObjRef.list, newSuperObjRef.id, kNoDestructor, kDLMWhole);
								}
							}
						}
						else
							err = BAPI_BufferToObj(api_data, (Ptr)&instance, sizeof(BifernoInstance), -classObjID, true, constructorRecP->privateData, OBJREF_P(resultObjRefP));
						if (err)
							DLM_Dispose(&instance.list, nil, 0);
						else
						{	/* if something would go wrong before end of clone, list will be disposed here
							and destructor of object in future must be avoided
							if clone is successfull, then we will turn NoDestructor off	*/
							DLM_TurnOnFlag(resultObjRefP->list, resultObjRefP->id, kNoDestructor, kDLMWhole);
							destructRec.api_data = api_data;
							destructRec.scope = OBJ_SCOPE_P(thisObjRefP);
							if NOT(err)
							{	// Loop on instance list to see if some reference has to be duplicated (cloned)
								if (err = DLM_LoopExt(instance.list, _CloneProperty, (long)&destructRec, true, false, &idErr))
								{	// Set no destructor to only copied objects
									// put in scope the first element to set no destructor
									destructRec.scope = idErr;
									DLM_Loop(instance.list, _SetNoDestrProperty, (long)&destructRec, true, false);
								}
								else
								{	if (bifernoClassP->cloneObjID)
									{	ObjRecordP		superObjRefP;
									
										if (bifernoClassP->extendedClassID)
										{	if NOT(err = _GetSuperObj((long)bRecP, resultObjRefP, &superObjRef))
												superObjRefP = &superObjRef;
										}
										else
											superObjRefP = nil;
										if NOT(err)
											err = _LaunchBifernoMethod(api_data, bifernoClassP, resultObjRefP, superObjRefP, nil, 0, bifernoClassP->methods, bifernoClassP->cloneObjID, false, nil, nil);
									}
								}
							}
							if (err)
							{	/*if (bifernoClassP->extendedClassID)
								{	destructRec.api_data = api_data;
									destructRec.scope = newSuperObjRef.scope;
									VariableDestructor(newSuperObjRef.list, newSuperObjRef.id, 0, newSuperObjRef.classID, (long)&destructRec);
								}
								// Only property really cloned will be destructed
								// DLM_Dispose(&instance.list, VariableDestructor, (long)&destructRec);
								*/
								DestructVariableWithAllSupers(api_data, resultObjRefP);
								UndefVariable(api_data, OBJREF_P(resultObjRefP), false);
							}
							else
								DLM_TurnOffFlag(resultObjRefP->list, resultObjRefP->id, kNoDestructor, kDLMWhole);
						}
					}
				}
				/*if NOT(err)
				{
					if (bifernoClassP->cloneObjID)
					{	ObjRecordP		superObjRefP;
					
						if (bifernoClassP->extendedClassID)
						{	if NOT(err = _GetSuperObj((long)bRecP, OBJRECORD_P(resultObjRefP), &superObjRef))
								superObjRefP = &superObjRef;
						}
						else
							superObjRefP = nil;
						if NOT(err)
							err = _LaunchBifernoMethod(api_data, bifernoClassP, OBJRECORD_P(resultObjRefP), superObjRefP, nil, 0, bifernoClassP->methods, bifernoClassP->cloneObjID, false, nil, nil);
					}
					if (err)
						DLM_DeleteObj(OBJ_LIST_P(resultObjRefP), OBJ_ID_P(resultObjRefP), nil, 0);
				}*/
				PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
			}
		}
		else
			err = XError(kBAPI_Error, Err_IllegalOperation);
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
XErr	BifernoDisposeInstanceList(long api_data, DLMRef dlRef, long objID, long scope)
{	
XErr			err = noErr;
BifernoInstance	instance;
long			tLen;
BfrDestructRec	destructRec;

	tLen = sizeof(BifernoInstance);	
	err = DLM_GetObj(dlRef, objID, (Ptr)&instance, &tLen, 0, nil);
	if (err == XError(kXHelperError, DLM_Err_NoMoreDataInObject))
		err = noErr;
	else if NOT(err)
	{	destructRec.api_data = api_data;
		destructRec.scope = scope;
		err = DLM_Dispose(&instance.list, VariableDestructor, (long)&destructRec);	// questa distrugge anche i super
	}
	
return err;
}

//===========================================================================================
XErr	BifernoSetSuper(long api_data, ObjRecord *thisObjRef, ObjRecord *superObjRef, ObjRecord *instSupObjRefPtr)
{
ObjRecord	instanceSuperObjRef;
XErr		err = noErr;
Boolean		needSer;

	if NOT(err = BAPI_NeedSerialize(api_data, OBJREF_P(thisObjRef), &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		// Set a new SuperObj
		if NOT(err = BAPI_SetSuperObj(api_data, OBJREF_P(thisObjRef), OBJREF_P(superObjRef), OBJREF_P(&instanceSuperObjRef)))
		{	if NOT(err = DLM_TurnOnFlag(superObjRef->list, superObjRef->id, kNoDestructor, kDLMWhole))
			{	if (instSupObjRefPtr)
					*instSupObjRefPtr = instanceSuperObjRef;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static XErr	BifernoConstructor(Biferno_ParamBlockPtr pbPtr)
{
	XErr			err = noErr;
	BifernoClass	*bifernoClassP;
	long			tscope, classObjID = (long)pbPtr->plugin_global_dataP;
	uint32_t		bifernoClassSlot;
	long 			api_data = pbPtr->api_data;
	BifernoRecP		bRecP = (BifernoRecP)api_data;
	BifernoInstance	instance;		
	ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
	long			listGlobal;
	ObjRecord		*resultObjRefP;
	Boolean			hasConstructor, expectSuperInConstructor, destructedOnErr;
	ObjRecord		superObjRef;
	BfrDestructRec	destructRec;
	BAPI_Doc 		*docP;
	unsigned short	flags;
	
	INVAL(superObjRef);
	if NOT(err = GetBifernoClassRecAlloc(bRecP, classObjID, &bifernoClassP, &bifernoClassSlot))
	{	expectSuperInConstructor = false;
		tscope = BAPI_ConstructorScope(api_data, constructorRecP->privateData);
		// ex if ((tscope == APPLICATION) || (tscope == PERSISTENT))
		if (tscope > GLOBAL)
			listGlobal = GLOBAL_LIST;
		else
			listGlobal = LOCAL_LIST;
		// only extending classes can avoid contructor
		hasConstructor = (bifernoClassP->constructorDoc != 0);
		/*
		if (NOT(hasConstructor) && NOT(bifernoClassP->extendedClassID))
			err = XError(kBAPI_Error, Err_ClassIsStatic);
		else
		*/
		{	ClearBlock(&instance, sizeof(BifernoInstance));
			// Create Instance list
			if NOT(err = DLM_Create(&instance.list, ID_LIST, listGlobal))	// no names list
			{	destructedOnErr = false;
				// Call constructor of extended class
				if (bifernoClassP->extendedClassID)
				{	if (hasConstructor)
					{	superObjRef.id = 0;
						superObjRef.classID = bifernoClassP->extendedClassID;
						expectSuperInConstructor = true;
					}
					else
					{	if NOT(err = GetContructorDoc(api_data, bifernoClassP->extendedClassID, &docP))
							err = CL_Constructor(api_data, TEMP, VARIABLE, nil, bifernoClassP->extendedClassID, constructorRecP->varRecsP, constructorRecP->totVars, docP, &superObjRef);
					}
				}
				else
					superObjRef.id = superObjRef.classID = 0;
				if NOT(err)
				{	if NOT(err = _FillInstanceWithDefaults(bRecP, bifernoClassP, &instance, tscope))	
					{	// Create "this"
						resultObjRefP = OBJRECORD_P(&constructorRecP->resultObjRef);
						if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&instance, sizeof(BifernoInstance), -classObjID, true, constructorRecP->privateData, OBJREF_P(resultObjRefP)))
						{	
							// set flag kIsDlm
							if not(err = DLM_GetInfo(resultObjRefP->list, resultObjRefP->id, &flags, nil, nil))
							{
								flags |= kIsDlm;
								if not(err = DLM_SetObjFlag(resultObjRefP->list, resultObjRefP->id, flags))
								{
									if (hasConstructor)
									{	long saveExecutingConstructor;
										
										saveExecutingConstructor = bRecP->executingConstructor;
										bRecP->executingConstructor = -classObjID;
										err = _LaunchConstructorMethod(api_data, bifernoClassP, resultObjRefP, &superObjRef, constructorRecP->varRecsP, constructorRecP->totVars, expectSuperInConstructor, &superObjRef, nil);
										bRecP->executingConstructor = saveExecutingConstructor;
									}
									if NOT(err)
									{	if (bifernoClassP->extendedClassID && NOT(expectSuperInConstructor))
											err = BifernoSetSuper(api_data, resultObjRefP, &superObjRef, nil);
									}
									if (err)
									{	DestructVariableWithAllSupers(api_data, resultObjRefP);
										DLM_TurnOnFlag(OBJ_LIST_P(resultObjRefP), OBJ_ID_P(resultObjRefP), kNoDestructor, kDLMWhole);
										UndefVariable(api_data, OBJREF_P(resultObjRefP), false);
										destructedOnErr = true;
									}
								}
							}
						}
					}
				}
				if (err)
				{	if NOT(destructedOnErr)
					{	destructRec.api_data = api_data;
						destructRec.scope = tscope;
						DLM_Dispose(&instance.list, VariableDestructor, (long)&destructRec);
					}
				}
			}
		}
		PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
		//DisposeBlock(&bifernoClassBlock);
	}

return err;
}

//===========================================================================================
static XErr	BifernoGetErrMessage(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetErrMessageRec	*getErrMessageP = &pbPtr->param.getErrMessageRec;
ObjRecord			returnValue;
long				api_data = pbPtr->api_data;
uint32_t			bifernoClassSlot;
ParameterRec 		paramVar;
BifernoClass		*bifernoClassP;

	BAPI_ClearParameterRec(api_data, &paramVar);
	if NOT(err = GetBifernoClassRecAlloc((BifernoRecP)api_data, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
	{	if (bifernoClassP->getErrMessageObjID)
		{	if NOT(err = BAPI_IntToObj(api_data, getErrMessageP->err, &paramVar.objRef))
			{	err = _LaunchBifernoStaticMethod(api_data, -(long)pbPtr->plugin_global_dataP, &paramVar, 1, bifernoClassP->methods, bifernoClassP->getErrMessageObjID, false, &returnValue);
				if NOT(err)
					err = BAPI_ObjToString(api_data, OBJREF_P(&returnValue), getErrMessageP->errMessage, nil, 255, kExplicitTypeCast);
			}
		}
		else if (bifernoClassP->extendedClassID)
		{	ObjRecord	superObjRef;
		
			superObjRef.list = 0;
			superObjRef.id = 0;
			superObjRef.classID = bifernoClassP->extendedClassID;
			superObjRef.scope = 0;	
			superObjRef.type = 0;	
			err = CDivert(kGetErrMessage, pbPtr, &superObjRef);
		}
		if (err)
		{	CStr255		eNameStr; 
		
			FillErrorStrings(api_data, -(long)pbPtr->plugin_global_dataP, err, nil, eNameStr, nil, nil, nil, nil, nil);
			CEquStr(getErrMessageP->errMessage, bifernoClassP->className);
			CAddStr(getErrMessageP->errMessage, ".GetErrMessage caused error: ");
			if (*eNameStr)
				CAddStr(getErrMessageP->errMessage, eNameStr);
			err = noErr;
		}
		PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
	}
	
return err;
}

//===========================================================================================
/*static XErr	BifernoGetErrNumber(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
GetErrNumber	*getErrNumberP = &pbPtr->param.getErrNumber;
ObjRecord			returnValue;
long			bifernoClassSlot, api_data = pbPtr->api_data;
ParameterRec 	paramVar;
BlockRef		bifernoClassBlock;
BifernoClass	*bifernoClassP;

	if NOT(err = GetBifernoClassRecAlloc((BifernoRecP)api_data, pbPtr->plugin_global_data, &bifernoClassP, &bifernoClassBlock, &bifernoClassSlot))
	{	if (bifernoClassP->getErrNumberObjID)
		{	paramVar.expP = nil;
			paramVar.expLen = 0;
			CEquStr(paramVar.name, "errNumber");
			if NOT(err = BAPI_StringToConstObj(api_data, getErrNumberP->errName, CLen(getErrNumberP->errName), &paramVar.objRef))
			{	if NOT(err = _LaunchBifernoStaticMethod(api_data, pbPtr->plugin_global_data, &paramVar, 1, bifernoClassP->methods, bifernoClassP->getErrNumberObjID, false, &returnValue))
					err = BAPI_ObjToInt(api_data, &returnValue, &getErrNumberP->errNumber, kExplicitTypeCast);
			}
		}
		else if (bifernoClassP->extendedClassID)
		{	ObjRecord	superObjRef;
		
			superObjRef.list = 0;
			superObjRef.id = 0;
			superObjRef.classID = bifernoClassP->extendedClassID;
			superObjRef.scope = 0;	
			superObjRef.type = 0;	
			err = CDivert(kGetErrNumber, pbPtr, &superObjRef);
		}
		PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot, bifernoClassBlock);
		//DisposeBlock(&bifernoClassBlock);
	}
	
return err;
}*/

//===========================================================================================
static XErr	BifernoTypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
PrimitiveUnion	*param_d;
long			tostringObjID, api_data = pbPtr->api_data;
uint32_t		bifernoClassSlot;
ObjRecord		*sourceObjP, returnValue;
//BifernoRecP 	bRecP = (BifernoRecP)api_data;
BifernoClass	*bifernoClassP;
Boolean			diverted;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(api_data, &typeCast->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		sourceObjP = OBJRECORD_P(&typeCast->objRef);
		if NOT(err)
		{	if NOT(err = GetBifernoClassRecAlloc((BifernoRecP)api_data, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
			{	param_d = &typeCast->result;
				switch(typeCast->resultWanted)
				{	case kInt:
						if (NOT(err = _CallTypeCastMethod(api_data, pbPtr, bifernoClassP, sourceObjP, bifernoClassP->tointObjID, &returnValue, &diverted)) && NOT(diverted))
							err = BAPI_ObjToInt(api_data, OBJREF_P(&returnValue), &param_d->intValue, typeCast->typeCastType);
						break;
					case kLong:
						if (NOT(err = _CallTypeCastMethod(api_data, pbPtr, bifernoClassP, sourceObjP, bifernoClassP->tolongObjID, &returnValue, &diverted)) && NOT(diverted))
							err = BAPI_ObjToLong(api_data, OBJREF_P(&returnValue), &param_d->longValue, typeCast->typeCastType);
						break;
					case kUnsigned:
						if (NOT(err = _CallTypeCastMethod(api_data, pbPtr, bifernoClassP, sourceObjP, bifernoClassP->tounsignedObjID, &returnValue, &diverted)) && NOT(diverted))
							err = BAPI_ObjToUnsigned(api_data, OBJREF_P(&returnValue), &param_d->uIntValue, typeCast->typeCastType);
						break;
					case kDouble:
						if (NOT(err = _CallTypeCastMethod(api_data, pbPtr, bifernoClassP, sourceObjP, bifernoClassP->todoubleObjID, &returnValue, &diverted)) && NOT(diverted))
							err = BAPI_ObjToDouble(api_data, OBJREF_P(&returnValue), &param_d->doubleValue, typeCast->typeCastType);
						break;
					case kBool:
						if (NOT(err = _CallTypeCastMethod(api_data, pbPtr, bifernoClassP, sourceObjP, bifernoClassP->tobooleanObjID, &returnValue, &diverted)) && NOT(diverted))
							err = BAPI_ObjToBoolean(api_data, OBJREF_P(&returnValue), &param_d->boolValue, typeCast->typeCastType);
						break;
					case kCString:
						switch(param_d->text.variant)
						{
							case kForConstructor:
								if (bifernoClassP->to_construct_stringObjID)
									tostringObjID = bifernoClassP->to_construct_stringObjID;
								else
									tostringObjID = bifernoClassP->tostringObjID;
								break;
							case kForDebug:
								if (bifernoClassP->to_debug_stringObjID)
									tostringObjID = bifernoClassP->to_debug_stringObjID;
								else
									tostringObjID = bifernoClassP->tostringObjID;
								break;
							default:
								tostringObjID = bifernoClassP->tostringObjID;
								break;
						}
						if (NOT(err = _CallTypeCastMethod(api_data, pbPtr, bifernoClassP, sourceObjP, tostringObjID, &returnValue, &diverted)) && NOT(diverted))
							err = BAPI_ObjToString(api_data, OBJREF_P(&returnValue), param_d->text.stringP, &param_d->text.stringLen, param_d->text.stringMaxStorage, typeCast->typeCastType);
						
						if (NOT(bifernoClassP->tostringObjID) && (err == XError(kBAPI_Error, Err_IllegalTypeCast)) && (param_d->text.variant == kForDebug))
							err = XError(kBAPI_Error, Err_BAPI_ObjNotPrintable);					
						break;
					case kChar:
						if (NOT(err = _CallTypeCastMethod(api_data, pbPtr, bifernoClassP, sourceObjP, bifernoClassP->tocharObjID, &returnValue, &diverted)) && NOT(diverted))
							err = BAPI_ObjToChar(api_data, OBJREF_P(&returnValue), param_d->theChar, typeCast->typeCastType);
						break;
					/*case kObj:
						CEquStr(methodName, "to");
						BAPI_NameFromClassID(api_data, param_d->objRef.classID, tempStr);
						CAddStr(methodName, tempStr);
						paramVar.objRef = *sourceObjP;
						*paramVar.name = 0;
						paramVar.expP = nil;
						paramVar.expLen = 0;
						methodObjID = DLM_GetObjID(bifernoClassP->methods, methodName, nil, nil);
						err = _CallTypeCastMethod(pbPtr, bifernoClassP, sourceObjP, methodObjID, &param_d->objRef, &diverted);
						break;*/
					default:
						CDebugStr("Unknown TypeCast Parameter");
						break;
				}
				PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static Boolean	SameFamily(long api_data, ObjRecordP objRefP, long requestedClassID, XErr *errP)
{								
XErr			err = noErr;
ObjRecord		tempObjRef, superObjRef;
Boolean			result = false;

	tempObjRef = *objRefP;
	do
	{
		if NOT(err = _GetSuperObj(api_data, &tempObjRef, &superObjRef))
		{	if (superObjRef.classID == requestedClassID)
			{	result = true;
				break;
			}
			else
				tempObjRef = superObjRef;
		}
		else
		{	if ((err == XError(kBAPI_Error, Err_ObjectNotFound)) || (err == XError(kBAPI_Error, Err_VariableNotInitialized)))
				err = noErr;
			break;
		}	
	} while NOT(err);

*errP = err;
return result;
}

//===========================================================================================
XErr	BifernoTypeCastToObject(long api_data, ObjRecord *sourceObjP, long requestedClassID, long typeCastType, ObjRecord *resultObjRefP)
{
XErr			err = noErr;
long			methodObjID;
uint32_t		bifernoClassSlot;
CStr255			methodName;
CStr63			tempStr;
ParameterRec 	paramVar;
BifernoClass	*bifernoClassP;
Boolean			diverted, sameFamily;

	if NOT(err = GetBifernoClassRecAlloc((BifernoRecP)api_data, -sourceObjP->classID, &bifernoClassP, &bifernoClassSlot))
	{	CEquStr(methodName, "to");
		BAPI_NameFromClassID(api_data, requestedClassID, tempStr);
		CAddStr(methodName, tempStr);
		paramVar.objRef = OBJREF(*sourceObjP);
		*paramVar.name = 0;
		methodObjID = DLM_GetObjID(bifernoClassP->methods, methodName, nil, nil);
		if (methodObjID)
			err = _CallTypeCastMethod(api_data, nil, bifernoClassP, sourceObjP, methodObjID, resultObjRefP, &diverted);
		else if (bifernoClassP->extendedClassID)
		{	
			sameFamily = SameFamily(api_data, sourceObjP, requestedClassID, &err);
			if not(err)
			{	
				if (sameFamily)
					*resultObjRefP = *sourceObjP;
				else
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
				/*{
					ObjRecord	superObjRef;

					if NOT(err = _GetSuperObj(api_data, sourceObjP, &superObjRef))
					{	if (superObjRef.classID == requestedClassID)
							*resultObjRefP = *sourceObjP;	//superObjRef;
						else
							err = CL_TypeCast(api_data, &superObjRef, requestedClassID, resultObjRefP, typeCastType);
					}
				}*/
			}
		}
		else
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
		PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
	}

return err;
}

//===========================================================================================
/*static XErr	BifernoGetSuperObj(Biferno_ParamBlockPtr pbPtr)
{
	return _GetSuperObj(pbPtr->api_data, &pbPtr->param.getSuperObjRec.objRef, &pbPtr->param.getSuperObjRec.superObjRef);
}*/

//===========================================================================================
static XErr	BifernoSuperIsChanged(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BifernoClass		*bifernoClassP;
long				api_data = pbPtr->api_data;
uint32_t			bifernoClassSlot;
char				*propNameP;
ParameterRec		param;
ObjRecord			*objRefP, supObjRef;
BifernoRecP			bRecP = (BifernoRecP)api_data;
Boolean				needSer;
SuperIsChangedRec	*superIsChangedRecP = &pbPtr->param.superIsChangedRec;

	if NOT(err = BAPI_NeedSerialize(api_data, &superIsChangedRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if NOT(err = GetBifernoClassRecAlloc(bRecP, (long)pbPtr->plugin_global_dataP, &bifernoClassP, &bifernoClassSlot))
		{	if (bifernoClassP->superIsChangedObjID)
			{	if ((bRecP->currentCtx.curMethodList != bifernoClassP->methods) || (bRecP->currentCtx.methodInExecutionID != bifernoClassP->superIsChangedObjID))
				{	objRefP = OBJRECORD_P(&superIsChangedRecP->objRef);
					if NOT(err = _GetSuperObj(api_data, objRefP, &supObjRef))
					{	if (supObjRef.id)
						{	propNameP = superIsChangedRecP->propertyName;
							BAPI_ClearParameterRec(api_data, &param);
							if NOT(err = BAPI_StringToObj(api_data, propNameP, CLen(propNameP), &param.objRef))
								err = _LaunchBifernoMethod(api_data, bifernoClassP, objRefP, &supObjRef, &param, 1, bifernoClassP->methods, bifernoClassP->superIsChangedObjID, false, nil, nil);
						}
					}
				}
			}
			PoolDisposePtr(gsDispatcherData.bifernoClassPool, bifernoClassSlot);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static XErr	BifernoExecuteFunction(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				saveVisibilityClass, saveCurMethodClass, funcObjID, api_data = pbPtr->api_data;
BifernoRecP 		bRecP = (BifernoRecP)api_data;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
BAPI_Doc			*funcDocP = exeMethodRecP->bapiDocP;

	funcObjID = /*-*/(long)pbPtr->plugin_global_dataP;
	// ex funcList = bRecP->application.functionList;
	//funcList = GetUserFunctionDLMList(bRecP, &funcObjID);
	//if NOT(err = GetBifernoFunctionRec(funcList, funcObjID, (Ptr*)&bisFunctionP, &bisFunctionBl, &totalLen))
	{	saveCurMethodClass = bRecP->methodInExecutionClass;
		saveVisibilityClass = bRecP->visibilityClass;
		bRecP->methodInExecutionClass = 0;		// In functions no class implicit property calls
		bRecP->visibilityClass = 0;
		err = _ExecuteBifernoFunction(api_data, exeMethodRecP->paramVarsP, exeMethodRecP->totParams, funcDocP/*, funcDocP->len*/, false, funcObjID, OBJRECORD_P(&exeMethodRecP->resultObjRef));
		if NOT(err)
		{	bRecP->methodInExecutionClass = saveCurMethodClass;
			bRecP->visibilityClass = saveVisibilityClass;
		}
		//DisposeBlock(&bisFunctionBl);
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BifernoCode_Call(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;

	DumpStack("BifernoCode_Call");
	switch(message)
	{
		case kRegister:
		case kInit:
		case kShutDown:
		case kRun:
		case kExit:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
		case kConstructor:
		case kTypeCast:
			err = BifernoConstructor(pbPtr);
			break;
		case kClone:
			err = BifernoClone(pbPtr);
			break;
		case kDestructor:
			err = BifernoDestructor(pbPtr);
			break;
		case kExecuteOperation:
			err = BifernoExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = BifernoExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			err = BifernoExecuteFunction(pbPtr);
			break;
		case kGetProperty:
			err = BifernoGetProperty(pbPtr);
			break;
		case kSetProperty:
			err = BifernoSetProperty(pbPtr);
			break;
		case kPrimitive:
			err = BifernoTypeCast(pbPtr);
			break;
		case kGetErrMessage:
			err = BifernoGetErrMessage(pbPtr);
			break;
		/*case kGetErrNumber:
			err = BifernoGetErrNumber(pbPtr);
			break;*/
		/*case kGetSuperObj:
			err = BifernoGetSuperObj(pbPtr);
			break;*/
		case kSuperIsChanged:
			err = BifernoSuperIsChanged(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}

