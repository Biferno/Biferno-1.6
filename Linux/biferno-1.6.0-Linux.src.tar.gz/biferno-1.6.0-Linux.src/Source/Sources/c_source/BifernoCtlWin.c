/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoCtlWin.c,v 1.11 2006-10-09 10:41:57 valfer Exp $
	|______________________________________________________________________________
*/
#include "resource.h"

#include 	"HTTPMgr.h"
#include 	"HTTPMrgNet.h"
#include 	"BifernoWinRegistry.h"
#include 	"BfrVersion.h"

#include	"XLib.h"
#include	"XLibPrivate.h"
#include 	"XFilesWinPrivate.h"

#define MAX_LOADSTRING 100

// Global Variables
static	HWND			gsWindow;
static	HINSTANCE		gsHInst;
static	TCHAR			szTitle[MAX_LOADSTRING];								// The title bar text
static	TCHAR			szWindowClass[MAX_LOADSTRING];								// The title bar text

static Ptr		gsActualTextP;
static long		gsActualTextLength;
static BlockRef	gsLastResponseBlock;

static CStr255	gsLogFilePath, gsPidFilePath, gsCtlLogFilePath;
static XFileRef	gsLogRefNum = 0;

static long		gsBifernoPort, gsBifernoCtlPort;
static CStr255	gsInfoStr;

/*XErr HTTPControllerLog(long a, char *b)
{


return noErr;
}*/

//===========================================================================================
static XErr	_SetMessageText(char *message)
{
BlockRef	messageBlock;
long		messageBlockLength = CLen(message);
XErr		err = noErr;
Ptr			p;
RECT		winRect;

	if (messageBlock = NewBlock(messageBlockLength, &err, &p))
	{	//p = GetPtr(messageBlock);
		CopyBlock(p, message, messageBlockLength);
		if (gsLastResponseBlock)
			DisposeBlock(&gsLastResponseBlock);
		gsLastResponseBlock = messageBlock;
		gsActualTextP = p;
		gsActualTextLength = messageBlockLength;

		ShowWindow(gsWindow, SW_SHOW);
		GetWindowRect(gsWindow, &winRect);
		InvalidateRect(gsWindow, &winRect, true);
		UpdateWindow(gsWindow);
	}

return err;
}

//===========================================================================================
static XErr	_StartBifernoService(void)
{

SC_HANDLE				serviceHandle, scManagerHandle;
XErr					err = noErr;

	scManagerHandle = OpenSCManager(nil, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CREATE_SERVICE);
	if (scManagerHandle && (scManagerHandle != INVALID_HANDLE_VALUE))
	{	serviceHandle = OpenService(
				scManagerHandle, 
				"bifernosvc",
				SERVICE_ALL_ACCESS);
		if (serviceHandle && (serviceHandle != INVALID_HANDLE_VALUE))
		{	if NOT(StartService(serviceHandle, 0L, NULL))
				err = GetLastError();
		}
		else
			err = GetLastError();
		if (serviceHandle && (serviceHandle != INVALID_HANDLE_VALUE))
			CloseServiceHandle(serviceHandle);
		if (scManagerHandle && (scManagerHandle != INVALID_HANDLE_VALUE))
			CloseServiceHandle(scManagerHandle);
	}
	else
		err = GetLastError();

	if NOT(err)
		_SetMessageText("Biferno Service started");
	
return err;
}


//===========================================================================================
static XErr	_InstallBifernoService(void)
{
SC_HANDLE				serviceHandle, scManagerHandle;
XErr					err = noErr;
SERVICE_DESCRIPTION		servDescr;
CStr255					bifernoWinSvcStr, bifernoSvcStr, cServDescr;
Boolean					already = false;

	GetStringKey(BIFERNO_SERVICE_PATH_KEYNAME, bifernoWinSvcStr);
	if NOT(*bifernoWinSvcStr)
	{	XGetApplicationFolderPath(bifernoSvcStr);
		CAddStr(bifernoSvcStr, "bifernosvc.exe");
		_GetWinFullPath(bifernoSvcStr, bifernoWinSvcStr);
	}
	scManagerHandle = OpenSCManager(nil, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CREATE_SERVICE);
	if (scManagerHandle && (scManagerHandle != INVALID_HANDLE_VALUE))
	{	serviceHandle = CreateService(
				scManagerHandle, 
				"bifernosvc", 
				"bifernosvc",
				SERVICE_ALL_ACCESS,
				SERVICE_WIN32_OWN_PROCESS,
				SERVICE_AUTO_START,
				SERVICE_ERROR_NORMAL,
				bifernoWinSvcStr,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL);
		if (NOT(serviceHandle) || (serviceHandle == INVALID_HANDLE_VALUE))
		{	err = GetLastError();
			if (err == ERROR_SERVICE_EXISTS)
			{	err = noErr;
				already = true;
			}
			serviceHandle = nil;
		}
		if (NOT(err) && serviceHandle)
		{	CEquStr(cServDescr, "Biferno Application Server");
			servDescr.lpDescription = cServDescr;
			ChangeServiceConfig2(serviceHandle, SERVICE_CONFIG_DESCRIPTION, &servDescr);
			if NOT(StartService(serviceHandle, 0L, NULL))
				err = GetLastError();
		}
		if (serviceHandle && (serviceHandle != INVALID_HANDLE_VALUE))
			CloseServiceHandle(serviceHandle);
		if (scManagerHandle && (scManagerHandle != INVALID_HANDLE_VALUE))
			CloseServiceHandle(scManagerHandle);
	}
	else
		err = GetLastError();

	if NOT(err)
	{	// \r\nTo uninstall it use the Registry Editor\r\n(regedit)
		if (already)
			_SetMessageText("Biferno Service already installed\r\n");
		else
			_SetMessageText("Biferno Service installed");
	}
	
return err;
}

//===========================================================================================
static XErr	_SetMessageLongText(BlockRef messageBlock, long	messageBlockLength)
{
XErr		err = noErr;
RECT		winRect;

	if (gsLastResponseBlock)
		DisposeBlock(&gsLastResponseBlock);
	gsLastResponseBlock = messageBlock;
	gsActualTextP = GetPtr(messageBlock);
	gsActualTextLength = messageBlockLength;

	ShowWindow(gsWindow, SW_SHOW);
	GetWindowRect(gsWindow, &winRect);
	InvalidateRect(gsWindow, &winRect, true);
	UpdateWindow(gsWindow);

return err;
}

//===========================================================================================
static XErr	_SendMessage(HWND hWnd, long message, Boolean update, long timeout)
{
BlockRef	block, serverResponse;
long		whichStrLen, dataToSendLen, serverResponseLen;
Ptr			respP, p;
XErr		err = noErr;
CStr255		errString, errString2, whichStr;

	GetStringKey(BIFERNO_WHICH_KEYNAME, whichStr);
	if NOT(CCompareStrings(whichStr, "CONSOLE"))
		CEquStr(whichStr, "Biferno is running in Console:\r\n\r\n");
	else
		CEquStr(whichStr, "Biferno is running as a Service:\r\n\r\n");
	whichStrLen = CLen(whichStr);
	
	if (update)
		_SetMessageText("...");
	
	dataToSendLen = 8;
	if (block = NewBlockLocked(4 + dataToSendLen, &err, &p))
	{	// prefix length
		*(long*)p = XHostToNetwork(dataToSendLen);
		*(long*)(p + 4) = 0;
		*(long*)(p + 8) = message;
		err = XClientCall("", gsBifernoPort, block, 4 + dataToSendLen, &serverResponse, &serverResponseLen, nil, errString, nil, 0, timeout, EXPECT_PREFIXED);
		if (err == WSAECONNREFUSED)
		{	if (update)
				_SetMessageText("Biferno is not running");
		}
		else if (err && update)
		{	XErrorGetDescr(err, errString, errString2);
			CAddStr(errString, ": ");
			CAddStr(errString, errString2);
			_SetMessageText(errString);
		}
		else if (update)
		{	if NOT(err = SetBlockSize(serverResponse, whichStrLen + serverResponseLen + 1))
			{	respP = GetPtr(serverResponse);
				CopyBlock(respP + whichStrLen, respP, serverResponseLen);
				CopyBlock(respP, whichStr, whichStrLen);
				_SetMessageLongText(serverResponse, serverResponseLen + whichStrLen);
			}
		}
		DisposeBlock(&block);
	}

return err;
}

//===========================================================================================
static XErr	_StopBiferno(void)
{
Boolean		first;
XErr		err = noErr;

	_SetMessageText("stopping biferno ...");
	first = true;
	while NOT(err)
	{	if NOT(err = _SendMessage(gsWindow, kQuit, false, NO_TIMEOUT))		// Quit message has to be sent twice
		{	if (first)
				first = false;
		}
	}
	if (NOT(first) && (err == WSAECONNREFUSED))
		err = noErr;
	if (err == XError(kXLibError, ErrConnectionBroken))
		err = noErr;
	_SetMessageText("... ok, biferno stopped");
	
return err;
}

//===========================================================================================
static XErr	_LaunchBifernoExe(void)
{
XFilePath				bifernoPath;
XErr					err = noErr;
STARTUPINFO				si;
PROCESS_INFORMATION		piProcessB;
CStr255					errString, errString2;

	GetStringKey(BIFERNO_CONSOLE_PATH_KEYNAME, bifernoPath);
	if NOT(*bifernoPath)
	{	XGetApplicationFolderPath(bifernoPath);
		CAddStr(bifernoPath, "Biferno.exe");
		FilePathXLibToWin32(bifernoPath);
	}
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	if NOT(CreateProcess(bifernoPath, "", NULL, NULL, false, 0L, NULL, NULL, &si, &piProcessB))
 	{	err = GetLastError();
		XErrorGetDescr(err, errString, errString2);
		CAddStr(errString, ": ");
		CAddStr(errString, errString2);
		_SetMessageText(errString);
	}
	else
		_SetMessageText("Biferno launched");
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	PaintWin(HWND hWnd, char *szHello)
{
RECT			rt;
PAINTSTRUCT 	ps;
HDC				hdc;
			
	hdc = BeginPaint(hWnd, &ps);
	//GetWindowRect(hWnd, &rt);
	GetClientRect(hWnd, &rt);
	if (gsActualTextP)
		DrawText(hdc, gsActualTextP, gsActualTextLength, &rt, DT_LEFT);
	else
		DrawText(hdc, szHello, CLen(szHello), &rt, DT_CENTER);
	EndPaint(hWnd, &ps);

return noErr;
}

//===========================================================================================
/*static BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   gsHInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, 300, 300, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

	if (hWndP)
		*hWndP = hWnd;
   return TRUE;
}*/

//===========================================================================================
static LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

//===========================================================================================
static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
int				wmId, wmEvent;
//PAINTSTRUCT		ps;
//HDC				hdc;
XErr			err = noErr;
TCHAR			szHello[MAX_LOADSTRING];
CStr255			aCStr, tStr;

	LoadString(gsHInst, IDS_HELLO, szHello, MAX_LOADSTRING);
	switch (message) 
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(gsHInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				case IDM_BSTART:
					if (_SendMessage(hWnd, kGetVersion, true, NO_TIMEOUT))	// Don't launch if is already up
						err = _LaunchBifernoExe();
					break;
				case IDM_BSTOP:
					err = _StopBiferno();
					break;
				case IDM_BFLUSH:
					err = _SendMessage(hWnd, kFlush, true, NO_TIMEOUT);
					break;
				case IDM_BRELOAD:
					err = _SendMessage(hWnd, kReload, true, NO_TIMEOUT);
					break;
				case IDM_BVERSION:					
					err = _SendMessage(hWnd, kGetVersion, true, NO_TIMEOUT);
					break;
				case IDM_CTL_INFO:
					CEquStr(aCStr, "BifernoCtl port: ");
					CNumToString(gsBifernoCtlPort, tStr);
					CAddStr(aCStr, tStr);
					_SetMessageText(aCStr);
					break;
				
				case IDM_BSTART_BKG:
					if (err = _StartBifernoService())
					{	XErrorGetDescr(err, aCStr, nil);
						_SetMessageText(aCStr);
					}
					break;
				  
				  return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_PAINT:
			PaintWin(hWnd, szHello);
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

//===========================================================================================
static ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_BIFERNOCTL);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_BIFERNOCTL;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//===========================================================================================
static BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
HWND	hWnd;

	gsHInst = hInstance;		// Store instance handle in our global variable
	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, 300, 300, NULL, NULL, hInstance, NULL);
	if NOT(hWnd)
		return FALSE;
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
  
return true;
}

//===========================================================================================
static void	_sentinelCallBack(char *message, long userData)
{
#if __MWERKS__
#pragma unused(userData)
#endif

CStr255		ctStr;
long		lenToWrite;
XErr		err = noErr;

	XCurrentDateTimeToString(ctStr, kComplete);
	CAddStr(ctStr, "\t");
	CAddStr(ctStr, message);
	CAddStr(ctStr, EOL_STRING);
	lenToWrite = CLen(ctStr);
	err = WriteXFile(gsLogRefNum, ctStr, &lenToWrite);
}

//===========================================================================================
static void	_killCallBack(unsigned long pid, long userData)
{
HANDLE	procHandle;

	if (procHandle = OpenProcess(PROCESS_TERMINATE, FALSE, pid))
		TerminateProcess(procHandle, 1);
}

//===========================================================================================
/*static void	_Process(long socketRef, BlockRef buff, long buffLen, long userData)
{
CStr255		errString2, aCStr, exePath;
XErr		err = noErr;
int			tLen;
BlockRef	responseBlock;
Ptr			p;
Boolean		isService;

	XThreadsEnterCriticalSection();
	
		if (_SendMessage(gsWindow, kGetVersion, true, SENTINEL_BFR_TIMEOUT))	// Don't launch if is already up
		{	SentinelCheck(gsLogFilePath, gsPidFilePath, _sentinelCallBack, 0, _killCallBack, 0);
			isService = _GetBifernoPath(exePath)
			if (isService)
			if NOT(err = _LaunchBiferno(false))
				XDelay(60L * 5L);		// wait 5 seconds
		}
		
		if (err)
		{	XErrorGetDescr(err, aCStr, errString2);
			CAddStr(aCStr, ": ");
			CAddStr(aCStr, errString2);
		}
		else
			CEquStr(aCStr, "ok, biferno checked");
		tLen = CLen(aCStr);
		if (responseBlock = NewBlockLocked(4 + tLen, &err, &p))
		{	*(long*)p = XHostToNetwork(tLen);
			CopyBlock(p + 4, aCStr, tLen);
			err = XServerSendToClient(socketRef, responseBlock, 4 + tLen);
			DisposeBlock(&responseBlock);
		}

	XThreadsLeaveCriticalSection();
}

//===========================================================================================
static void* _ServerEntryPoint(void* args)
{
CStr255		aCStr;
XErr		err = noErr;

	if NOT(err = GetLongKey(BIFERNO_CTL_PORT_KEYNAME, &gsBifernoCtlPort))
	{	if NOT(gsBifernoCtlPort)
			gsBifernoCtlPort = BIFERNO_SENTINEL_WIN_PORT;
		if (err = XServerLoop(gsBifernoCtlPort, 12, _Process, 0L, true, true, nil, aCStr))
		{	printf(aCStr);
			printf("\n");
		}
	}
	
return (void*)err;
}
*/
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
MSG				msg;
HACCEL			hAccelTable;
XErr			err = noErr;
unsigned long	/*serverThreadID, */lastCheck;
CStr255			versionStr;

	if (err = XInit(nil))
		return false;
	
	gsActualTextP = nil;
	gsActualTextLength = 0;
	gsLastResponseBlock = 0;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_BIFERNOCTL, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Log and pid files
	XGetApplicationFolderPath(gsLogFilePath);
	CAddStr(gsLogFilePath, "BifernoServer.log");
	XGetApplicationFolderPath(gsPidFilePath);
	CAddStr(gsPidFilePath, BIFERNO_PID_FILE);
	XGetApplicationFolderPath(gsCtlLogFilePath);
	CAddStr(gsCtlLogFilePath, "bifernoctl.log");
	InitLog(gsCtlLogFilePath, &gsLogRefNum);
	
	if NOT(err = GetLongKey(BIFERNO_PORT_KEYNAME, &gsBifernoPort))
	{	if NOT(gsBifernoPort)
			gsBifernoPort = BIFERNO_WIN_PORT;
	}
	else
		return false;
	
	// Perform application initialization:
	if NOT(InitInstance(hInstance, nCmdShow)) 
		return FALSE;
	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_BIFERNOCTL);

	// Server:
	//if (err = XNewThread(&serverThreadID, 0, _ServerEntryPoint, 256L * 1024L, 0))
	//	goto out;

	// Main message loop:
	//_SendMessage(gsWindow, kGetVersion, true, NO_TIMEOUT);
	VersionToString(CUR_BIFERNO_VERSION, versionStr, DEVELOPMENT_VERS_STR);
	sprintf(gsInfoStr, "BifernoCtl\r\nBiferno Version %s", versionStr);
	if NOT(CCompareStrings_cs(STATUS_VERS_STR, "unstable"))
		CAddStr(gsInfoStr, "u");
		
	_SetMessageText(gsInfoStr);
	
	lastCheck = 0;
	while (GetMessage(&msg, NULL, 0, 0)) 
	{	if NOT(TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{	TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		/*if ((XGetTicks() - lastCheck) > 60)
		{	_SendMessage(gsWindow, kGetVersion, true);
			lastCheck = XGetTicks();
		}*/
	}
	if (gsLogRefNum)
		EndLog(&gsLogRefNum);
		
	XEnd(1);	// there is the server thread, but dont't wait fot it and quit

//out:
return msg.wParam;
}

