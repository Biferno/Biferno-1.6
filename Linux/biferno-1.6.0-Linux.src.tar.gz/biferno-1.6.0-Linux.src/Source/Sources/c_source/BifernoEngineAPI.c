/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoEngineAPI.c,v 1.31 2008-02-05 17:28:13 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "HTTPMgr.h"
#include "HTTPMrgNet.h"

#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Flower.h"
#include "BfrSession.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "BifernoErrors.h"
#include "Load.h"
#include "Input.h"
#include "Entity.h"
#include "Application.h"
#include "Classes.h"
#include "StaticClasses.h"
#include "BfrParser.h"

#include "Multipart.h"
#include "HttpPage.h"
#include "Reference.h"
#include "BfrError.h"

#include <stdio.h>
#include <string.h>

// Volatile of Biferno
volatile unsigned long	gsBifernoCurrentUsers;

// Globals of Biferno
XErr							gMemoryFullError;
long							gMaxUsers, gPoolFactor;
Page_GetOutputCallBack			page_GetOutput;
Ref_GetTargetCallBack			ref_GetTarget;
Ref_NewReferenceCallBack		ref_NewReference;
Ref_GetTargetClassCallBack		ref_GetTargetClass;
Page_PrintCallBack				page_Print;
Multipart_NewObjectCallBack		multiPart_NewObject;
//Error_UpdateEMsgRecordCallBack	error_UpdateEMsgRecord; 
BlockRef						gsCallBacksBlock;
PluginRecord					*gClassRecordBlockP;
BlockRef						gDefaultsBlock;
long							gTotDefaults;
Boolean							gsLocally;
DispatcherData					gsDispatcherData;
Biferno_Dispatch				gStaticClassEntryPoint[MAX_STATIC_CLASSES];
long							gTotStaticClasses;
XDateTimeRec					gUpSinceXDT;
long							gRunID;
BAPI_ModifyHook 				gsRefModifyHook;
XFilePath						gBifernoSpoolPath;
CStr255							gPersistentFolder;

// Static
static long				gsBifernoStop;
static Boolean			gEmergencyCalled;
static unsigned long	gLastSessionGarbageCollection = 0;
static Boolean			gBifernoAbort = false;

// Extern
extern	DispatcherData	gsDispatcherData;
extern 	unsigned long	gTotalApplicationMemory;
extern	Boolean			gsLocally;
extern	XFileRef		gLogRefNum, gExtraLogRefNum, gCurrentLogRefNum;
extern	Boolean			gExitForced;

//===========================================================================================
XErr	BifernoYield(unsigned long *lastTicksP)
{
	if (gBifernoAbort)
		return XError(kBAPI_Error, Err_ProcessShutDown);
	else
		return XYield(lastTicksP);
}

//===========================================================================================
XErr	BifernoEnter(void)
{
XErr	err = noErr;

	if (gMemoryFullError)
		gMemoryFullError = noErr;

	// If cache is flushing, wait.
	if NOT(err = XThreadsWaitSemaphore(&gsBifernoStop, kBifernoWaitTimeout))
	{	gsBifernoCurrentUsers++;
		err = XThreadsSemaphoreGreen(&gsBifernoStop);
	}	
	if (err)
		return err;
	
return err;
}

//===========================================================================================
XErr	BifernoStop(LogCallBack	logCallBack, void *userData, long usersToRemain, CmdType cmdType, LONGLONG uniqueid)
{
XErr			err = noErr;
unsigned long 	initMilliSecs, millisecs, lastTicks = 0;
CStr255			logStr;
char			message[MAX_LOG_STRING+1];

	if (gExitForced)
		return noErr;
	if (logCallBack)
	{	FormatLogString(message, cmdType, '-', "", "", "bifernostop: init", uniqueid, nil, nil);
		logCallBack(userData, message);
	}
	if NOT(err = XThreadsWaitSemaphore(&gsBifernoStop, kBifernoWaitTimeout))
	{	// Wait that users exit
		if ((gsBifernoCurrentUsers > (unsigned long)usersToRemain) && logCallBack)
		{	sprintf(logStr, "bifernostop: %d user/s to wait (%d, wait %d secs) ...", (int)(gsBifernoCurrentUsers - usersToRemain), (int)usersToRemain, (int)(kBifernoWaitTimeout/1000));
			FormatLogString(message, cmdType, '-', "", "", logStr, uniqueid, nil, nil);
			logCallBack(userData, message);
		}
		XGetMilliseconds(&initMilliSecs);
		while ((gsBifernoCurrentUsers > (unsigned long)usersToRemain) && NOT(err) && NOT(gExitForced))
		{	
		#ifndef __MAC_XLIB__
			XDelay(60);
		#endif
			if NOT(err = XYield(&lastTicks))
			{	XGetMilliseconds(&millisecs);
				if ((millisecs - initMilliSecs) > kBifernoWaitTimeout)
					err = XError(kXLibError, ErrXThreads_Timeout);
			}
		}
		if (err == XError(kXLibError, ErrXThreads_Timeout))
		{	if (logCallBack)
			{	sprintf(logStr, "bifernostop: %d user/s yet running (wait %d secs) -> X ...", (int)(gsBifernoCurrentUsers - usersToRemain), (int)(kBifernoWaitTimeout/1000));
				FormatLogString(message, cmdType, '-', "", "", logStr, uniqueid, nil, nil);
				logCallBack(userData, message);
			}
			err = noErr;
			gBifernoAbort = true;
			XGetMilliseconds(&initMilliSecs);
			while ((gsBifernoCurrentUsers > (unsigned long)usersToRemain) && NOT(err) && NOT(gExitForced))
			{	
			#ifndef __MAC_XLIB__
				XDelay(60);
			#endif
				if NOT(err = XYield(&lastTicks))
				{	XGetMilliseconds(&millisecs);
					if ((millisecs - initMilliSecs) > kBifernoWaitTimeout)
						err = XError(kXLibError, ErrXThreads_Timeout);
				}
			}
			gBifernoAbort = false;
		}
		if (err)
		{	// Sorry, we couldn't stop the terrible stream of requests
			if (logCallBack)
			{	sprintf(logStr, "bifernostop: %d user/s", (int)(gsBifernoCurrentUsers - usersToRemain));
				FormatLogString(message, cmdType, '-', "", "", logStr, uniqueid, nil, nil);
				logCallBack(userData, message);
			}
			XThreadsSemaphoreGreen(&gsBifernoStop);
		}
	}
	if (logCallBack)
	{	FormatLogString(message, cmdType, '-', "", "", "bifernostop: end", uniqueid, nil, nil);
		logCallBack(userData, message);
	}
	
return err;
}

//===========================================================================================
XErr	BifernoResume(void)
{
XErr		err = noErr;

	err = XThreadsSemaphoreGreen(&gsBifernoStop);
	gBifernoAbort = false;

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#ifdef __LITTLE_ENDIAN__
	#define	SLASH_SPACE		' /'
#else
	#define	SLASH_SPACE		'/ '
#endif

//===========================================================================================
static XErr	_BifernoConf(long *maxUsersP, long *poolFactorP, long webServerMaxUsers, LogCallBack logCallBack, void *userData)
{
XFileRef		fileRef;
long			eof;
BlockRef		block = nil;
XErr			err = noErr, err2 = noErr;
XFilePath		filePath;
Ptr				textP;
CStr63			tagName;
long			*longP;
CStr255			logStr;
long			charset = 0;	// 1 = unix, 2 = mac
	
	*maxUsersP = *poolFactorP = 0;
	XGetApplicationFolderPath(filePath);
	CAddStr(filePath, "biferno.conf");
	logCallBack(userData, "loading biferno.conf ...");
	logCallBack(userData, filePath);
	if (CheckPath(filePath, false))		// does not exists
	{
		if NOT(err = OpenXFile(filePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &fileRef))
		{
			logCallBack(userData, "biferno.conf did not exist -> creating ...");
			eof = 10;
			if (err = WriteXFile(fileRef, "CHAR_SET	1", &eof))
			{
				sprintf(logStr, "biferno.conf write error: %d", err);
				logCallBack(userData, logStr);
			}
			err = CloseXFile(&fileRef);
			if (err)
			{
				sprintf(logStr, "biferno.conf close error: %d", err);
				logCallBack(userData, logStr);
			}
		}
	}
	if NOT(err = OpenXFile(filePath, OPEN_FILE_ALWAYS, READ_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof)
			{	if (block = NewBlockLocked(eof, &err, &textP))
				{	if NOT(err = ReadXFile(fileRef, textP, &eof))
					{	do {
							SkipSpaceAndTabCRLF(&textP, &eof, nil);
							if (eof > 0)
							{	if NOT(err = GetEntityName(0L, &textP, &eof, tagName, true))
								{	if NOT(CCompareStrings_cs(tagName, "MAX_USERS"))
									{	longP = maxUsersP;
										CEquStr(logStr, "MAX_USERS -> ");
									}
									else if NOT(CCompareStrings_cs(tagName, "POOL_FACTOR"))
									{	longP = poolFactorP;
										CEquStr(logStr, "POOL_FACTOR -> ");
									}
									else if NOT(CCompareStrings_cs(tagName, "CHAR_SET"))
									{	longP = &charset;
										CEquStr(logStr, "CHAR_SET -> ");
									}
									else
									{	CEquStr(filePath, "Syntax error in biferno.conf: ");
										CAddStr(filePath, tagName);
										CAddStr(filePath, "?");
										err = logCallBack(userData, filePath);
										longP = nil;
									}
									if (longP)
									{	SkipSpaceAndTab(&textP, &eof);
										if NOT(err = GetEntityName(0L, &textP, &eof, tagName, true))
										{	
											CStringToNum(tagName, longP);
											// log
											CAddStr(logStr, tagName);
											CAddStr(logStr, " -> ");
											CNumToString(*longP, tagName);
											CAddStr(logStr, tagName);
											logCallBack(userData, logStr);
										}
									}
									else
									{	textP++;
										eof--;
									}
								}
							}	
						} while (NOT(err) && (eof > 0));
					}
				}
			}
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	else
	{	sprintf(logStr, "Error opening file: %s (%d)", filePath, (int)err);
		logCallBack(userData, logStr);
	}
	if NOT(err)
	{	if (*maxUsersP <= 0)
			*maxUsersP = webServerMaxUsers;
		else if (*maxUsersP > 10000)
			*maxUsersP = 32;
		if ((*poolFactorP <= 0) || (*poolFactorP > 10))
			*poolFactorP = 1;
		if (charset == CHARSET_UNIX || charset == CHARSET_MAC)
			SetCharacterSetGlobal(charset);
		else
		{
			#if __MAC_XLIB__ || __MACOSX__
				SetCharacterSetGlobal(CHARSET_MAC);
			#else
				SetCharacterSetGlobal(CHARSET_UNIX);
			#endif
		}
		logCallBack(userData, "... biferno.conf loaded");
	}	
	else
	{	
		sprintf(logStr, "biferno.conf error: %d", err);
		logCallBack(userData, logStr);
	}	
		
if (block)
	DisposeBlock(&block);
return err;
}

//===========================================================================================
XErr	BEngineAPI_GetVersions(char *versionStr, char *versionAPIStr, char *xlibVersStr)
{
	return BAPI_GetVersions(0, versionStr, versionAPIStr, xlibVersStr);
}

//===========================================================================================
void	BEngineAPI_Suspend(void)
{
	gBifernoAbort = true;
}

//===========================================================================================
void	BEngineAPI_Resume(void)
{
	gBifernoAbort = false;
}

//===========================================================================================
void	BEngineAPI_Emergency(void *userData)
{
XFileRef 	xrefNum;
XErr		err = noErr;
XFilePath	filePath;

	if NOT(gEmergencyCalled)
	{	gEmergencyCalled = true;
		gMemoryFullError = XError(kBAPI_Error, Err_MemoryFull);
		HTTPControllerSetMonoThread(userData);
		XGetApplicationFolderPath(filePath);
		CAddStr(filePath, BIFERNO_MEMORY_ERROR_FILE);
		if NOT(err = OpenXFile(filePath, CREATE_FILE_ALWAYS, READ_PERM, false, &xrefNum))
			CloseXFile(&xrefNum);
	}
}

//===========================================================================================
XErr	BEngineAPI_Idle(LogCallBack logCallBack, void *userData)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(logCallBack, userData)
#endif
XErr			err = noErr;
unsigned long	now;

	XGetSeconds(&now);
	if ((now - gLastSessionGarbageCollection) > SESSION_GARBAGE_COLLECTION_INTERVAL)
	{	/*
		Dont stop Biferno, otherwise users get process shut down randomly
		Make things without stopping
		*/
		Session_GarbageCollection();
		gLastSessionGarbageCollection = now;
	}
	XIdle();
	
return err;
}

//===========================================================================================
XErr	BEngineAPI_Flush(LogCallBack logCallBack, void *userData, LONGLONG uniqueid)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(logCallBack, userData)
#endif
XErr		err = noErr;
XFileRef	saveLogRef;

	if NOT(err = BifernoStop(logCallBack, userData, 0, kFlush, uniqueid))
	{	saveLogRef = gCurrentLogRefNum;
		gCurrentLogRefNum = gExtraLogRefNum;
		HTTPControllerLog(0, "=------------------------------------------------------------------------------=");
		if (logCallBack)
			logCallBack(userData, "Flushing...");
		err = CFFlush(true);
		if (logCallBack)
			logCallBack(userData, "...ok");
		gCurrentLogRefNum = saveLogRef;
		BifernoResume();
	}

return err;
}

//===========================================================================================
XErr	BEngineAPI_Reload(LogCallBack logCallBack, void *userData, LONGLONG uniqueid)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(logCallBack, userData)
#endif
XErr		err = noErr;
XFileRef	saveLogRef;

	if NOT(err = BifernoStop(logCallBack, userData, 0, kReload, uniqueid))
	{	saveLogRef = gCurrentLogRefNum;
		gCurrentLogRefNum = gExtraLogRefNum;
		HTTPControllerLog(0, "=------------------------------------------------------------------------------=");
		if (logCallBack)
			logCallBack(userData, "Reloading...");
		CL_ShutDown(logCallBack, userData);
		CL_Init(logCallBack, userData, gMaxUsers);
		if (logCallBack)
			logCallBack(userData, "...ok");
		gCurrentLogRefNum = saveLogRef;
		BifernoResume();
	}

return err;
}

//===========================================================================================
XErr	BEngineAPI_Init(long *maxUsersP, LogCallBack logCallBack, void *userData, Boolean locally, char *messageErr)
{	
XErr			err = noErr;
CStr63			bifernoVers, bapiVers, xlibVers;
CStr255			logStr;
unsigned long	totMemoryPerUserSize = 0, tSize, secs;

	// Inits
	if (logCallBack)
	{	
		CEquStr(logStr, "On: ");
		XCurrentDateTimeToString(bifernoVers, kComplete);
		CAddStr(logStr, bifernoVers);
		if (err = logCallBack(userData, logStr))
			return err;

		if (err = logCallBack(userData, "========================="))
			return err;
		if (err = logCallBack(userData, "======== BIFERNO ========"))
			return err;
		if (err = logCallBack(userData, "========================="))
			return err;
	}
	if (err = _BifernoConf(&gMaxUsers, &gPoolFactor, *maxUsersP, logCallBack, userData))
		return err;
	gsBifernoStop = XThreadsCreateSemaphore(_GREEN, &err);
	if (err)
		return err;

	if (maxUsersP)
		*maxUsersP = gMaxUsers;
	
	XGetApplicationFolderPath(logStr);
	CAddStr(logStr, BIFERNO_MEMORY_ERROR_FILE);
	if NOT(CheckPath(logStr, false))
		DeleteXFile(logStr);
	gMemoryFullError = noErr;
	gEmergencyCalled = false;
	gBifernoAbort = false;
	
	ClearBlock(&gsDispatcherData, sizeof(DispatcherData));
	// evalPool
	tSize = sizeof(EvalObjRef) * MAX_EXPRESSINPARENT;
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 2, &gsDispatcherData.evalPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating eval pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 2;
	
	// bifernoRecPool
	tSize = sizeof(BifernoRec);
	if (err = NewPool(tSize, gMaxUsers, &gsDispatcherData.bifernoRecPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating Biferno Rec pool");
		return err;
	}
	totMemoryPerUserSize += tSize;
	
	// paramBlockPool
	tSize = sizeof(Biferno_ParamBlock);
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 10, &gsDispatcherData.paramBlockPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating param Block pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 10;

	// processObjectPool
	tSize = sizeof(ProcessObjectCallRecord);
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 5, &gsDispatcherData.processObjectPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating Process Object pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 5;

	// memberLoopPool
	tSize = sizeof(MemberLoopCallRecord);
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 5, &gsDispatcherData.memberLoopPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating Member Loop pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 5;

	// notifySuperIsChangedPool
	tSize = sizeof(SuperIsChangedNotify);
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 2, &gsDispatcherData.notifySuperIsChangedPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating SuperIsChanged pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 2;

	// bifernoClassPool
	tSize = sizeof(BifernoClass);
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 2, &gsDispatcherData.bifernoClassPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating bifernoClass pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 2;
	
	// cacheResPool
	tSize = sizeof(CacheResult);
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 2, &gsDispatcherData.cacheResPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating cacheRes pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 2;
	
	// memberAction Pool
	tSize = POOL_PROPERTY_ACTION_SIZE;
	if (err = NewPool(tSize, gPoolFactor * gMaxUsers * 2, &gsDispatcherData.propertyActionPool))
	{	if (logCallBack)
			logCallBack(userData, " Error creating memberAction pool");
		return err;
	}
	totMemoryPerUserSize += gPoolFactor * tSize * 2;
	
	gsLocally = locally;
	err = CL_Init(logCallBack, userData, gMaxUsers);
	if NOT(err)
	{	// threadDataPool (call this after CL_Init (otherwise gsDispatcherData.totClass is 0 -> bug))
		tSize = sizeof(BRunThreadClassRec) * gsDispatcherData.totClass;
		if (err = NewPool(tSize, gMaxUsers, &gsDispatcherData.threadDataPool))
		{	if (logCallBack)
				logCallBack(userData, " Error creating param Block pool");
			return err;
		}
		totMemoryPerUserSize += tSize;
	}
	if (NOT(err) && logCallBack)
	{
	CStr255			aCStr;
	CStr15			tStr;
	unsigned long	totPerUser, totPerAllUsers, totBaseMem;
	
		logCallBack(userData, "");
		logCallBack(userData, "Memory Preallocation:");
		totMemoryPerUserSize += HTTP_THREAD_STACK_SIZE;		// for the thread
		totPerUser = totMemoryPerUserSize;
		totPerAllUsers = totPerUser * gMaxUsers;
		totBaseMem = gTotalApplicationMemory + (HTTP_THREAD_STACK_SIZE * gMaxUsers) - totPerAllUsers;
		CNumToString(totBaseMem/1024, aCStr);
		CAddStr(aCStr, "K + (");
		CNumToString(totPerUser/1024, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, "K x ");
		CNumToString(gMaxUsers, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, " users) = ");
		CNumToString((totBaseMem+totPerAllUsers)/1024, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, "K");
		logCallBack(userData, aCStr);

		if (gPoolFactor != 1)
		{	CEquStr(aCStr, "Pool factor is: ");
			CNumToString(gPoolFactor, tStr);
			CAddStr(aCStr, tStr);
			logCallBack(userData, aCStr);
		}
	}
	
	if NOT(err)
	{	if (err = logCallBack(userData, " "))
			return err;
		if (err = logCallBack(userData, "========================="))
			return err;
		// Biferno Version
		BEngineAPI_GetVersions(bifernoVers, bapiVers, xlibVers);
		sprintf(logStr, "Biferno Version is: %s", bifernoVers);
		if (err = logCallBack(userData, logStr))
			return err;
		sprintf(logStr, "BAPI: %s, XLib: %s", bapiVers, xlibVers);
		if (err = logCallBack(userData, logStr))
			return err;

		XGetSeconds(&secs);
		SecondsToXDateTime(secs, &gUpSinceXDT);

		if (err = logCallBack(userData, " "))
			return err;
		
		BAPI_GetBifernoHome(0, gBifernoSpoolPath);		// file:/...
		if (gBifernoSpoolPath[CLen(gBifernoSpoolPath)-1] != '/')
			CAddChar(gBifernoSpoolPath, '/');
		CAddStr(gBifernoSpoolPath, "BifernoSpool/");
	}
	
	if (err)
		FillErrorStrings(0, 0, err, nil, messageErr, nil, nil, nil, nil, nil);
		
	
return err;
}

//===========================================================================================
XErr	BEngineAPI_End(LogCallBack logCallBack, void *userData, LONGLONG uniqueid)
{
XErr			err = noErr;

	logCallBack(userData, "ShutDown: cleanup threads, please wait...");
	if NOT(err = BifernoStop(logCallBack, userData, 0, kQuit, uniqueid))
	{	logCallBack(userData, "ShutDown...");	
		err = CL_ShutDown(logCallBack, userData);
		DeletePool(gsDispatcherData.evalPool);
		DeletePool(gsDispatcherData.bifernoRecPool);
		DeletePool(gsDispatcherData.paramBlockPool);
		DeletePool(gsDispatcherData.processObjectPool);
		DeletePool(gsDispatcherData.memberLoopPool);
		DeletePool(gsDispatcherData.notifySuperIsChangedPool);
		DeletePool(gsDispatcherData.bifernoClassPool);
		DeletePool(gsDispatcherData.cacheResPool);
		DeletePool(gsDispatcherData.propertyActionPool);
		DeletePool(gsDispatcherData.threadDataPool);
		logCallBack(userData, "...ok");
		// don't dispose XThreadsCloseSemaphore(gsBifernoStop);
	}
	
return err;
}

