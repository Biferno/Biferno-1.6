/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Param.c,v 1.36 2008-12-02 11:04:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Param.h"
#include "BfrParser.h"
#include "BifernoErrors.h"

extern 	DispatcherData	gsDispatcherData;

//===========================================================================================
/*static XErr 	_AddressParam(long api_data, Ptr *oldFilePPtr, long *lenP, Byte *lastCharP, ParameterRec *resultParamP, long flags, ObjRecordP resultObjRefP)
{
XErr		err = noErr;
Boolean		noPostIncr = true;
CStr63		varName;
Ptr			aPtr;
long		len;
BifernoRecP	bRecP = (BifernoRecP)api_data;
Boolean		saveRIR, saveNoImmediate;

	aPtr = *oldFilePPtr;
	len = *lenP;
	aPtr++;
	len--;
	resultParamP->expP = aPtr;
	resultParamP->expLen = len;
	saveNoImmediate = bRecP->noImmediate;
	bRecP->noImmediate = true;
	saveRIR = RESULT_IS_RELEVANT(api_data);
	RESULT_IS_RELEVANT(api_data) = true;
	err = EvalVariable(api_data, &aPtr, &len, kExplicitTypeCast, nil, false, false, nil, resultObjRefP, varName, &noPostIncr, kAddressParameter, false, nil);
	RESULT_IS_RELEVANT(api_data) = saveRIR;
	bRecP->noImmediate = saveNoImmediate;
	if NOT(err)
	{	if (COMPILING(api_data) && (flags & kLoadParamOnStack))
			err = BIC_LoadParam(api_data, resultObjRefP);
		else
		{	if IS_IMMEDIATE_P(resultObjRefP)
				CDebugStr("_AddressParam: non doveva mai accadere");
		}
		SkipSpaceAndTabCRLF(&aPtr, &len, &bRecP->currentCtx.currentLine);
		if (len && (*aPtr == ','))
		{	*lastCharP = ',';
			aPtr++;
			len--;
		}
		else if (len && (*aPtr == ')'))
		{	*lastCharP = ')';
			aPtr++;
			len--;
		}
		//}
	}
	else
	{	if (err == XError(kBAPI_Error, Err_EmptyName))
			err = XError(kBAPI_Error, Err_BadSyntax);
		// to remove: Removed on 14/7/2003, error if &a and a not defined
		else if (err == XError(kBAPI_Error, Err_UndefinedIdentifier))	// for address
		{	INVAL_P(resultObjRefP);
			SkipOneParameter(&aPtr, &len, lastCharP, kNoFlowControl + kStopOnCR + kStopOnComma, false);
			err = noErr;
		}
	}
	
if NOT(err)
{	*oldFilePPtr = aPtr;
	*lenP = len;
}
return err;
}*/

//===========================================================================================
static void	_CheckQuotas(Byte ch, long *back_slashCntP, Boolean *inSingleApStringP, Boolean *inDoubleApStringP)
{
long	back_slashCnt;

	back_slashCnt = *back_slashCntP;
	if (ch == '\\')
		back_slashCnt++;
	else if ((ch != '\"') && (ch != '\''))
		back_slashCnt = 0;
	if (ch == '\"')
	{	if (NOT(back_slashCnt & 1) && NOT(*inSingleApStringP))
			*inDoubleApStringP = *inDoubleApStringP ? false : true;
		back_slashCnt = 0;
	}
	else if (ch == '\'')
	{	if (NOT(back_slashCnt & 1) && NOT(*inDoubleApStringP))
			*inSingleApStringP = *inSingleApStringP ? false : true;
		back_slashCnt = 0;
	}
	*back_slashCntP = back_slashCnt;
}

//===========================================================================================
static XErr	_GetFunctionParam(BifernoRecP bRecP, long constructor, Ptr *oldFilePPtr, long *lenP, long *paramVarsBuffIDPtr, ParameterRec **paramVarsPPtr, long *totParams, Boolean smart, BAPI_Doc *docP)
{
XErr			err = noErr;
Ptr				saveP, tempP;
long			saveLen, saveCurMethodClass, paramVarsID, i, len, api_data = (long)bRecP;
Byte			lastChar;
Boolean			saveLoadingOnStack, moved, isDefault;
ParameterRec	*paramVarsP;
BlockRef		block;
BlockRef		protoParamBlock = 0;

	paramVarsID = 0;
	tempP = *oldFilePPtr;
	len = *lenP;
	if (len && (*tempP == '('))
	{	tempP++;
		len--;
	}
	else
		return XError(kBAPI_Error, Err_RoundBracketExpected);

	if (paramVarsID = BufferCreate(sizeof(ParameterRec) * 4, &err))
	{	block = BufferGetBlockRefExt(paramVarsID, (Ptr*)&paramVarsP);
		LockBlock(block);
		i = 0;
		lastChar = 0;
		while ((lastChar != ')') && NOT(err) && (len > 0))
		{	if NOT(err = BufferCheck(paramVarsID, sizeof(ParameterRec) * (i+1), &moved))
			{	if (moved)
				{	block = BufferGetBlockRefExt(paramVarsID, (Ptr*)&paramVarsP);
					// Don't lock again, SetHandleSize relocked it (if was locked)
				}
			}
			if NOT(err)
			{	
			CStr255		saveClass_error_note;
			long		saveCurrentLine, saveLastClassIDErrorCalled;
			
				BAPI_ClearParameterRec(api_data, &paramVarsP[i]);
				if (smart)
				{	saveCurMethodClass = bRecP->methodInExecutionClass;
					bRecP->methodInExecutionClass = constructor;
					saveP = tempP;
					saveLen = len;
					saveCurrentLine = bRecP->currentCtx.currentLine;
					saveLastClassIDErrorCalled = bRecP->lastClassIDErrorCalled;
				}
				if (*bRecP->class_error_note)
					CEquStr(saveClass_error_note, bRecP->class_error_note);
				else
					*saveClass_error_note = 0;
				err = GetOneParameter(api_data, &tempP, &len, &lastChar, &paramVarsP[i], &isDefault, false, false, kStopOnComma + kLoadParamOnStack, docP, i);
				if (smart)
				{	bRecP->methodInExecutionClass = saveCurMethodClass;
					if (err && (saveCurMethodClass < 0) && NOT(bRecP->noParamSmartRetry))
					{	
					ErrorMsgRecord	saveMsgRec;
					
						bRecP->lastClassIDErrorCalled = saveLastClassIDErrorCalled;
						bRecP->currentCtx.currentLine = saveCurrentLine;
						if (*saveClass_error_note)
							CEquStr(bRecP->class_error_note, saveClass_error_note);
						saveMsgRec = bRecP->errMessageRec;
						BAPI_ResetError(api_data);
						if NOT(err = GetOneParameter(api_data, &saveP, &saveLen, &lastChar, &paramVarsP[i], &isDefault, false, false, kStopOnComma, docP, i))
						{	tempP = saveP;
							len = saveLen;
							bRecP->currentCtx.currentOffset = 0;
						}
						else
							bRecP->errMessageRec = saveMsgRec;
					}
				}
				if NOT(err)
				{	if ((lastChar != ',') && (lastChar != ')'))
						err = XError(kBAPI_Error, Err_BadSyntax);
				}
				if (OBJ_ID(paramVarsP[i].objRef))
					i++;
				else if (isDefault)
				{
					i++;
					if COMPILING(api_data)
						err = BIC_LoadParam(api_data, nil);
				}
			}
		}
		if (NOT(err) && (lastChar != ')'))
			err = XError(kBAPI_Error, Err_RoundBracketExpected);
		if NOT(err)
		{	
			// if NOT(COMPILING(api_data))
			{	if ((i == 1) && isDefault && NOT(*paramVarsP[0].name))
					i = 0;
			}
			*totParams = i;
		}
	}

*oldFilePPtr = tempP;
*lenP = len;
if (err)
{	if NOT(bRecP->currentCtx.currentOffset)
		bRecP->currentCtx.currentOffset = BfrGetOffset(bRecP, len);
	if (paramVarsID)
		BufferFree(paramVarsID);
	*paramVarsBuffIDPtr = nil;
	*paramVarsPPtr = nil;
}
else
{	*paramVarsBuffIDPtr = paramVarsID;
	*paramVarsPPtr = paramVarsP;
}
if COMPILING(api_data)
{	if (protoParamBlock)
		DisposeBlock(&protoParamBlock);
	COMP(api_data)->loadingOnStack = saveLoadingOnStack;
}
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void 	SkipOneParameter(BifernoRecP bRecP, Ptr *oldFilePPtr, long *lenP, Byte *lastCharP, long flags, Boolean stopOnCRAnyway, Boolean leaveLast)
{
Ptr				tempP;
long			advance, back_slashCnt, parNum, len;
int				ch;
Boolean			finished;
Boolean 		inSingleApString, inDoubleApString;

	tempP = *oldFilePPtr;
	len = *lenP;
	parNum = 0;
	finished = false;
	back_slashCnt = 0;
	inSingleApString = inDoubleApString = false;
	//if (lastNewLineSizeP)
	//	*lastNewLineSizeP = 0;
	while ((len > 0) && NOT(finished)) 
	{
		ch = len ? *tempP : 0;
		_CheckQuotas((Byte)ch, &back_slashCnt, &inSingleApString, &inDoubleApString);
		if (NOT(inSingleApString) && NOT(inDoubleApString))
		{	switch(ch)
			{
				case ',':
					if (flags & kStopOnComma)
					{	if NOT(parNum)
						{	finished = true;
							*lastCharP = ch;
						}
					}
					break;
				case '$':
					if (flags & kStopOnDollar)
					{	if NOT(parNum)
						{	finished = true;
							*lastCharP = ch;
						}
					}
					break;
				case '.':
					if ((flags & kStopOnPeriod) || ((len > 2) && (*(short*)(tempP+1) == '..')))	// ... (in prototypes: int a = 4 ...)
					{	if NOT(parNum)
						{	finished = true;
							*lastCharP = ch;
						}
					}
					break;
				case ';':
					if NOT(parNum)
					{	if (lastCharP)
							*lastCharP = ';';
						finished = true;
					}
					break;
				case '(':
					parNum++;
					break;
				case ')':
					if (--parNum < 0)
					{	finished = true;
						*lastCharP = ch;
					}
					break;
				case '}':
					*lastCharP = ch;
					goto out;
				default:
					if (IsNewLine(tempP, len, &advance))
					{	if ((flags & kStopOnCR) && NOT(parNum))
						{	finished = true;
							*lastCharP = 0;
							goto out;
						}
						else
						{	tempP += --advance;
							len -= advance;
							if (bRecP)
								bRecP->currentCtx.currentLine++;
						}
					}
					break;					
			}	
		}
		else if (stopOnCRAnyway)
		{	if (IsNewLine(tempP, len, &advance))
			{	if ((flags & kStopOnCR) && NOT(parNum))
				{	finished = true;
					*lastCharP = 0;
					goto out;
				}
				else
				{	tempP += --advance;
					len -= advance;
					if (bRecP)
						bRecP->currentCtx.currentLine++;
				}
			}
		}
		if (NOT(finished) || NOT(leaveLast))
		{	tempP++;
			len--;
		}
	}

out:
*oldFilePPtr = tempP;
*lenP = len;
}

//===========================================================================================
static Boolean 	_PreParam(BifernoRecP bRunP, Byte ch, long flags, Ptr *oldFilePPtr, long *lenP, Byte *lastCharP, Boolean *isDefaultP, Boolean advance)
{
Ptr		aPtr = *oldFilePPtr;
long	len = *lenP;
Byte	lastChar;
Boolean	isDefault = *isDefaultP, res = false;

	if (lastCharP)
		lastChar = *lastCharP;
	if (ch == ')')
	{	if (advance)
		{	aPtr++;
			len--;
		}
		lastChar = ')';
		isDefault = true;
		res = true;
	}
	if ((flags & kStopOnDollar) && (ch == '$'))
	{	if (advance)
		{	aPtr++;
			len--;
		}
		lastChar = '$';
		isDefault = true;
		res = true;
	}
	// here advance aPtr also if advance == false
	if ((flags & kStopOnCR) && (IsNewLineExt(&aPtr, &len, &bRunP->currentCtx.currentLine)))
	{	isDefault = true;
		res = true;
	}
	if ((ch == ',') || (ch == ';'))
	{	if (advance)
		{	aPtr++;
			len--;
		}
		lastChar = ch;
		isDefault = true;
		res = true;
	}
	*oldFilePPtr = aPtr;
	*lenP = len;
	if (lastCharP)
		*lastCharP = lastChar;
	*isDefaultP = isDefault;

return res;
}

//===========================================================================================
static BAPI_ParameterDoc* _GetParamDoc(BAPI_Doc *docP, long index, char *userParamName, XErr *errP)
{
long				totPars, i;
BAPI_ParameterDoc	*protoParamP = nil;

	if (docP)
	{	totPars = docP->totParams;
		if (*userParamName && NOT(docP->info.method.noNames))
		{	protoParamP = &docP->params[0];
			for (i = 0; i < totPars; i++, protoParamP++)
			{	if NOT(CCompareStrings_cs(userParamName, protoParamP->name))
					break;
			}
			if (i == totPars)
			{	protoParamP = nil;
				if (errP)
					*errP = XError(kBAPI_Error, Err_InvalidParameterName);
			}
		}
		else if (index < totPars)
			protoParamP = &docP->params[index];
		else
		{	if (errP)
				*errP = XError(kBAPI_Error, Err_InvalidParameter);
		}
	}
	
return protoParamP;
}

//===========================================================================================
static XErr 	_CheckRefParam(long api_data, Ptr *oldFilePPtr, long *lenP, Byte *lastCharP, ParameterRec *resultParamP, Boolean *isDefaultP, long flags, BAPI_Doc *docP, long index)
{
XErr				err = noErr;
Ptr					aPtr;
long				numPar, len;
BAPI_ParameterDoc	*protoParamP;
Boolean				fixedSize;
ObjRecord			varObj, tempObj;
CStr63				varName;
Byte				lastChar;
BifernoRecP			bRunP = (BifernoRecP)api_data;

	aPtr = *oldFilePPtr;
	len = *lenP;
	aPtr++;
	len--;	// skip the '&'
	if (protoParamP = _GetParamDoc(docP, index, resultParamP->name, &err))
	{	if (protoParamP->targetClassID)
		{	if ((protoParamP->targetClassID == gsDispatcherData.arrayConstructor) || protoParamP->aeLevel)
			{	tempObj.classID = gsDispatcherData.arrayConstructor;
				tempObj.list = bRunP->volatileList;
				tempObj.type = VARIABLE;
				tempObj.scope = TEMP;
				err = CreateEmptyArray(nil, bRunP->volatileList, protoParamP->aeLevel, protoParamP->aeClassID, 0, &tempObj.id);
			}
			else if (protoParamP->targetClassID == CLASSID_UNSPECIFIED)
				err = XError(kBAPI_Error, Err_InvalidParameter);
			else
			{	if NOT(err = BAPI_FixedSize(api_data, protoParamP->targetClassID, &fixedSize))
				{	INVAL(tempObj);
					err = CreateEmptyObject(api_data, nil, bRunP->volatileList, VARIABLE, protoParamP->targetClassID, 0, 0, 0, false, &tempObj);
					// ex err = BAPI_BufferToObj(api_data, nil, 0, protoParamP->targetClassID, fixedSize, nil, (ObjRefP)&tempObj);
				}
			}
			if NOT(err)
			{	numPar = 0;
				*varName = 0;
				INVAL(varObj);
				if NOT(err = EvalVariable(api_data, &aPtr, &len, kExplicitTypeCast, &tempObj, false, false, &numPar, &varObj, varName, nil, flags, false, nil/*, nil*/))
				{	lastChar = RemoveEndChar(&aPtr, &len, flags, &bRunP->currentCtx.currentLine, (Boolean)(lastCharP != nil));;
					err = BAPI_MakeRef(api_data, (ObjRefP)&varObj, &resultParamP->objRef);
				}
			}
		}
		else
			err = XError(kBAPI_Error, Err_InvalidParameter);
	}


if NOT(err)
{	if (isDefaultP)
		*isDefaultP = false;
	if (lastCharP)
		*lastCharP = lastChar;
	*oldFilePPtr = aPtr;
	*lenP = len;
}
return err;
}

//===========================================================================================
XErr 	GetOneParameter(long api_data, Ptr *oldFilePPtr, long *lenP, Byte *lastCharP, ParameterRec *resultParamP, Boolean *isDefaultP, Boolean dontAcceptEmpty, Boolean noParamName, long flags, BAPI_Doc *docP, long i)
{
Ptr			aPtr;
long		saveLine, parNum, len;
XErr		err = noErr;
Byte		lastChar = 0;
ObjRecordP	resultObjRefP;
BifernoRecP	bRunP = (BifernoRecP)api_data;
int			ch;
Boolean		saveAssignment, isDefault;
char		varName[MAX_VARIABLE_NAME_LENGTH];

	if NOT(resultParamP)
		CDebugStr("GetOneParameter: invalid resultParamP (call SkipOneParameter instead)");
	aPtr = *oldFilePPtr;
	len = *lenP;
	//setErrMsg = false;
	isDefault = false;
	saveLine = bRunP->currentCtx.currentLine;
	if (isDefaultP)
		*isDefaultP = false;
	SkipSmart(bRunP, &aPtr, &len);
	BAPI_ClearParameterRec(api_data, resultParamP);
	resultParamP->privateData = len;
	saveAssignment = bRunP->assignment;
	if (len)
	{	resultObjRefP = OBJRECORD_P(&resultParamP->objRef);
		ch = *aPtr;
		if (ch == ':')
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	if (_PreParam(bRunP, (Byte)ch, flags, &aPtr, &len, &lastChar, &isDefault, (Boolean)(lastCharP != nil)))
				goto out;
			flags |= kStopOnComma | kNoFlowControl | kStopOnSemicolon;
			parNum = 0;
			bRunP->assignment = false;
			//saveSuspendMsgs = bRunP->currentCtx.suspendMsgs;
			//bRunP->currentCtx.suspendMsgs = true;
			err = Evaluate(api_data, 0, 0, &aPtr, &len, varName, resultObjRefP, flags, &parNum, true/*, &setErrMsg*/);
			//bRunP->currentCtx.suspendMsgs = saveSuspendMsgs;
			if NOT(err)
			{	if NOT(VALID_P(resultObjRefP))
				{	err = XError(kBAPI_Error, Err_InvalidParameter);
					bRunP->currentCtx.currentLine = saveLine;
				}
				else
				{	if (COMPILING(api_data) && (flags & kLoadParamOnStack))
						err = BIC_LoadParam(api_data, resultObjRefP);
					if NOT(err)
					{	lastChar = RemoveEndChar(&aPtr, &len, flags, &bRunP->currentCtx.currentLine, (Boolean)(lastCharP != nil));
						if (parNum)
							err = XError(kBAPI_Error, Err_RoundBracketExpected);
						else if (lastChar == ':')
						{	if (len)
							{	if (noParamName)
									err = XError(kBAPI_Error, Err_BadSyntax);
								else
								{	if COMPILING(api_data)
										*(ObjRecordP)&resultParamP->name = *resultObjRefP;
									else
									{	if (err = BAPI_ObjToString(api_data, OBJREF_P(resultObjRefP), resultParamP->name, nil, 63, kImplicitTypeCast))
										{	if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
												err = XError(kBAPI_Error, Err_ParameterNameTooLong);
										}
									}
									if NOT(err)
									{	SkipSpaceAndTab(&aPtr, &len);
										/*if (len && (*aPtr == '&'))
											err = _AddressParam(api_data, &aPtr, &len, &lastChar, resultParamP, flags, resultObjRefP);
										else*/
										{	flags &= (0xFFFFFFFF ^ kStopOnSemicolon);	// don't stop on semicolon
											SkipSpaceAndTabCRLF(&aPtr, &len, &bRunP->currentCtx.currentLine);
											if (_PreParam(bRunP, *aPtr, flags, &aPtr, &len, &lastChar, &isDefault, (Boolean)(lastCharP != nil)))
											{	if ((lastChar == ')')  || (lastChar == ','))
												{	ClearBlock(resultObjRefP, sizeof(ObjRecord));
													goto out;
												}
												else
													err = XError(kBAPI_Error, Err_BadSyntax);
											}
											else
											{	parNum = 0;
												INVAL_P(resultObjRefP);
												bRunP->assignment = false;
												//setErrMsg = false;
												//saveSuspendMsgs = bRunP->currentCtx.suspendMsgs;
												//bRunP->currentCtx.suspendMsgs = true;
												err = Evaluate(api_data, 0, 0, &aPtr, &len, varName, resultObjRefP, flags, &parNum, true/*, &setErrMsg*/);
												//bRunP->currentCtx.suspendMsgs = saveSuspendMsgs;
												if NOT(err)
												{	if NOT(VALID_P(resultObjRefP))
													{	err = XError(kBAPI_Error, Err_InvalidParameter);
														bRunP->currentCtx.currentLine = saveLine;
													}
													else
													{	if (parNum)
															err = XError(kBAPI_Error, Err_RoundBracketExpected);
														else
														{	lastChar = RemoveEndChar(&aPtr, &len, flags, &bRunP->currentCtx.currentLine, true);
															if (COMPILING(api_data) && (flags & kLoadParamOnStack))
															{	if NOT(err = BIC_LoadParam(api_data, resultObjRefP))
																{	
																	//if (loadOpcodeBuffer)
																	//	err = BIC_SaveLastOpcode(api_data, loadOpcodeBuffer, true);
																}
															}
														}
													}
												}
												else if (NOT(bRunP->assignment) && (err == XError(kBAPI_Error, Err_UndefinedIdentifier)) && docP && len && (*aPtr == '&'))
												{	if (err = _CheckRefParam(api_data, &aPtr, &len, &lastChar, resultParamP, &isDefault, flags, docP, i))
													{	//if (bRunP->currentCtx.pendingMsgs)
															NewMsgRecord(api_data, kDOING, varName, 0, 0);
													}
												}
											}
										}
									}
								}
							}
							else
								err = XError(kBAPI_Error, Err_BadSyntax);
						}
					}
				}
			}
			else if (NOT(bRunP->assignment) && (err == XError(kBAPI_Error, Err_UndefinedIdentifier)) && docP && len && (*aPtr == '&'))
			{	
				if (err)
					bRunP->currentCtx.currentOffset = 0;
				if (err = _CheckRefParam(api_data, &aPtr, &len, &lastChar, resultParamP, &isDefault, flags, docP, i))
				{	//if (bRunP->currentCtx.pendingMsgs)
						NewMsgRecord(api_data, kDOING, varName, 0, 0);
				}
			}
		}
	}

out:
bRunP->assignment = saveAssignment;
if NOT(err)
{	if (lastCharP)
		*lastCharP = lastChar;
	if (isDefault)
	{	if (dontAcceptEmpty)
			err = XError(kBAPI_Error, Err_EmptyExpression);
		else if (isDefaultP)
			*isDefaultP = true;
	}
	*oldFilePPtr = aPtr;
	*lenP = len;
}
else
{	
BAPI_ParameterDoc	*protoParamP;
char				*strP;

	if (*resultParamP->name)
		strP = resultParamP->name;
	else if (protoParamP = _GetParamDoc(docP, i, resultParamP->name, nil))
		strP = protoParamP->name;
	else
		strP = nil;
	//if (bRunP->currentCtx.pendingMsgs)
		NewMsgRecord(api_data, kDOING, varName, 0, 0);
	//if (strP)
	//	NewMsgRecord(api_data, kPARAMETER, strP, 0, 0);
}
return err;
}

//===========================================================================================
XErr	GetFunctionParametersSmart(BifernoRecP bRecP, long constructor, Ptr *oldFilePPtr, long *lenP, long *paramVarsBuffIDPtr, ParameterRec **paramVarsPPtr, long *totParams, BAPI_Doc *docP)
{
	return _GetFunctionParam(bRecP, constructor, oldFilePPtr, lenP, paramVarsBuffIDPtr, paramVarsPPtr, totParams, true, docP);
}

//===========================================================================================
XErr	GetFunctionParameters(long api_data, Ptr *oldFilePPtr, long *lenP, long *paramVarsBuffIDPtr, ParameterRec **paramVarsPPtr, long *totParams, BAPI_Doc *docP)
{
	return _GetFunctionParam((BifernoRecP)api_data, 0, oldFilePPtr, lenP, paramVarsBuffIDPtr, paramVarsPPtr, totParams, false, docP);
}

