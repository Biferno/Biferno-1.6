/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: bifernoctl.c,v 1.11 2006-10-09 10:41:57 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"
//#include 	"Helpers.h"
#include 	"HTTPMgr.h"
#include 	"HTTPMrgNet.h"

#include <signal.h>
#include <errno.h>
#include <stdlib.h>

//extern CStr255	globalErrStr;

#define	BIFERNOCTL_VERSION_STRING	"bifernoctl version 1.0\n\n"

static Boolean		gsRestarting;

int SentinelCommand(char *command, char *bifernoHomeStr);

//===========================================================================================
void _PrintUsage(void)
{
	printf("Usage:\n");
	printf("bifernoctl start\tStart biferno\n");
	printf("bifernoctl stop\t\tStop biferno\n");
	printf("bifernoctl restart\tRestart biferno\n");
	printf("bifernoctl flush\tFlush biferno\n");
	printf("bifernoctl reload\tReload biferno\n");
	printf("bifernoctl version\tbiferno version\n");
	printf("bifernoctl ctlversion\tbifernoctl version\n");
	printf("\n");
	printf("bifernoctl -f stop\tStop biferno (forced)\n");
	printf("bifernoctl -f restart\tRestart biferno (with forced quit)\n");
	printf("\n");
	printf("bifernoctl -s start\tStart bifernoctl sentinel process\n");
	printf("bifernoctl -s stop\tStop bifernoctl sentinel process\n");
	printf("\n");

	printf("bifernoctl --help\tThis message\n");
	printf("\n");
}

//===========================================================================================
static XErr	_SendMessage(long message, BlockRef *serverBlockP, long *serverResponseLenP, long timeout)
{
BlockRef	block, serverResponse;
long		dataToSendLen, serverResponseLen;
Ptr			p;
XErr		err = noErr;
CStr255		errString;

	dataToSendLen = 8;
	if (block = NewBlockLocked(4 + dataToSendLen, &err, &p))
	{	// prefix length
		*(long*)p = XHostToNetwork(dataToSendLen);
		*(long*)(p + 4) = 0;
		*(long*)(p + 8) = message;
		if NOT(err = XClientCall("", 0L, block, 4 + dataToSendLen, &serverResponse, &serverResponseLen, BIFERNO_UNIX_FILE, errString, nil, 0, timeout, EXPECT_PREFIXED))
		{	if (message == kQuit)
			{	*serverBlockP = serverResponse;
				*serverResponseLenP = serverResponseLen;
			}
			else
			{	printf("biferno responded:\n");
				printf(GetPtr(serverResponse));
				DisposeBlock(&serverResponse);
			}
		}
		else if (*errString)
		{	printf(errString);
			printf("\n");
		}
		DisposeBlock(&block);
	}

return err;
}

//===========================================================================================
static XErr	_StopBiferno(Boolean forced)
{
BlockRef	quitResponseBlock;
long		msg, quitResponseBlockLen;
Boolean		first;
XErr		err = noErr;

	/*if (forced)
		msg = kQuitForced;
	else*/
		msg = kQuit;
	first = true;
	while NOT(err)
	{	if NOT(err = _SendMessage(msg, &quitResponseBlock, &quitResponseBlockLen, 60))		// Quit message has to be sent twice
		{	if (first)
			{	printf("biferno responded:\n");
				printf(GetPtr(quitResponseBlock));
				first = false;
			}
			DisposeBlock(&quitResponseBlock);
		}
	}
	if (NOT(first) && ((err == ECONNREFUSED) || (err == EDEADLK) || (err == EAGAIN)))
	{	
		err = noErr;
	}
	if (err == XError(kXLibError, ErrConnectionBroken))
		err = noErr;

return err;
}

//===========================================================================================
void	_Bash(char *bashStr, char *sysStr)
{
FILE	*p;
size_t	size;
int		e;

	printf(bashStr);
	*sysStr = 0;
	errno = 0;
	if (p = popen(bashStr, "r"))
	{	size = fread(sysStr, 1, 250, p);
		if (size >= 0)
			sysStr[size-1] = 0;	// 0 terminated
		else
			sprintf(sysStr, "Error on fread(): %d (%s)", e = ferror(p), strerror(e));
		printf(sysStr);
		printf("...\n");
		if (pclose(p))
			sprintf(sysStr, "Error on pclose(): %s", strerror(ferror(p)));
	}
	else
		sprintf(sysStr, "Error on popen(): %s", strerror(errno));
}

//===========================================================================================
static void	_HandleErr(XErr theError)
{
	// printf("%d\n", theError);
	if (theError)
	{	CStr255	errStr;

		XErrorGetDescr(theError, errStr, nil);
		CAddStr(errStr, "\n");
		printf(errStr);
		
		/*if (*globalErrStr)
		{	printf(globalErrStr);
			printf("\n");
		}*/
	}
}

//===========================================================================================
/*static void	_ReadPID(char *pidStr)
{
XFileRef	xrefNum;
long		eof;
XErr		err = noErr;
CStr255		path;
	
	*pidStr = 0;
	if NOT(err = XGetApplicationFolderPath(path))
	{	CAddStr(path, "biferno.pid");
		if NOT(err = OpenXFile(path, OPEN_FILE_EXISTING, READ_PERM, true, &xrefNum))
		{	if NOT(err = GetXEOF(xrefNum, &eof))
			{	if (eof < 255)
				{	err = ReadXFile(xrefNum, pidStr, &eof);
					*(pidStr + eof) = 0;
				}
			}
			CloseXFile(&xrefNum);
		}
	}
	
	if (err)
		_HandleErr(err);
	
}*/

//===========================================================================================
static void	catch_pipe_signal(int signo)
{
	if NOT(gsRestarting)
	{	printf("-- ");
		XEnd(0);
		printf("--\n");
		exit(0);
	}
}

//===========================================================================================
static XErr	do_command(char *str, Boolean forced)
{
XErr				err = noErr;
//unsigned long		serverThreadID;
CStr255				sysStr;

	if NOT(CCompareStrings_cs(str, "start"))
	{	printf("starting biferno...\n");
		_Bash("bifernod\n", sysStr);
		//exit(0);
	}
	else if NOT(CCompareStrings_cs(str, "stop"))
	{	printf("stopping biferno...\n");
		gsRestarting = false;
		err = _StopBiferno(forced);
	}
	else if NOT(CCompareStrings_cs(str, "restart"))
	{	printf("stopping biferno...\n");
		gsRestarting = true;
		err = _StopBiferno(forced);
		printf("starting biferno...\n");
		_Bash("bifernod\n", sysStr);
	}
	else if NOT(CCompareStrings_cs(str, "flush"))
	{	printf("flushing biferno...\n");
		err = _SendMessage(kFlush, nil, nil, NO_TIMEOUT);
	}
	else if NOT(CCompareStrings_cs(str, "reload"))
	{	printf("reloading biferno...\n");
		err = _SendMessage(kReload, nil, nil, NO_TIMEOUT);
	}
	else if NOT(CCompareStrings_cs(str, "version"))
		err = _SendMessage(kGetVersion, nil, nil, NO_TIMEOUT);
	else if NOT(CCompareStrings_cs(str, "ctlversion"))
		printf(BIFERNOCTL_VERSION_STRING);
	else
		_PrintUsage();

return err;
}

//===========================================================================================
int main(int argc, char *argv[])
{
XErr				err = 0;	//, err2 = 0;
//CStr255				pidStr, aCStr;
struct sigaction	sa_old;
struct sigaction	sa_new;
int					return_res = 0;
CStr255				bifernoHomeStr;
		
	if ((argc == 2) && NOT(CCompareStrings_cs(argv[1], "version")))	// only bifernoctl version from non-root user
		;// ok
	else if (geteuid())
	{	printf("Only root can launch this command: %d (e=%d)\n", getuid(), geteuid());
		return_res = 1;
		goto out;
	}

	if NOT(GetBifernoHome(bifernoHomeStr))
	{	printf(bifernoHomeStr/*"Biferno Error: BIFERNOHOME is not defined\n"*/);
		exit(1);
	}

	if ((argc == 3) && NOT(CCompareStrings_cs(argv[1], "-s")))
	{	return_res = SentinelCommand(argv[2], bifernoHomeStr);
		goto out;
	}
	else if ((argc == 2) && NOT(CCompareStrings_cs(argv[1], "-s")))
	{	return_res = SentinelCommand("start", bifernoHomeStr);
		goto out;
	}

 	sa_new.sa_handler = catch_pipe_signal;
	sigfillset(&sa_new.sa_mask);
	sa_new.sa_flags = 0;
	sigaction(SIGPIPE, &sa_new, &sa_old);	

	if (err = XInit(bifernoHomeStr))
	{	_HandleErr(err);
		return_res = 2;
		goto out;
	}
	
	switch(argc)
	{
		case 1:
			_PrintUsage();
			break;
			
		case 2:
			err = do_command(argv[1], false);
			break;
	
		case 3:
			if NOT(CCompareStrings_cs(argv[1], "-s"))
				;	// shoyld never pass here
			else if NOT(CCompareStrings_cs(argv[1], "-f"))
				err = do_command(argv[2], true);
			else
				_PrintUsage();
			break;
	
		default:
			_PrintUsage();
			break;
	}

	if (err)
	{	_HandleErr(err);
		return_res = err;
	}
	
	XEnd(0);

out:
return return_res;
}


