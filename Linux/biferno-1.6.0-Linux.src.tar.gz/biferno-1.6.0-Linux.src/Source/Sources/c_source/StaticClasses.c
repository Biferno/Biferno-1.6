/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: StaticClasses.c,v 1.6 2008-06-13 14:32:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#include	"XLib.h"
#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"


extern	Biferno_Dispatch	gStaticClassEntryPoint[MAX_STATIC_CLASSES];
extern	long				gTotStaticClasses;

#define	__NEWCLASS(x)		if (gTotStaticClasses < MAX_STATIC_CLASSES){gStaticClassEntryPoint[gTotStaticClasses++] = x;}

//===========================================================================================
void	StaticClasses(void)
{
	// Here the 7 - primitives (absolutely in this order)
	__NEWCLASS(bool_Biferno_Dispatch);
	__NEWCLASS(string_Biferno_Dispatch);
	__NEWCLASS(double_Biferno_Dispatch);
	__NEWCLASS(long_Biferno_Dispatch);
	__NEWCLASS(unsigned_Biferno_Dispatch);	
	__NEWCLASS(int_Biferno_Dispatch);
	__NEWCLASS(char_Biferno_Dispatch);

	//--- this MUST be the first after the primitives (see Run.c:SendRunEvents)
	__NEWCLASS(httpPage_Dispatch);
	//---
	
	__NEWCLASS(reference_Dispatch);
	__NEWCLASS(header_Dispatch);
	__NEWCLASS(request_Dispatch);
	__NEWCLASS(client_Dispatch);
	__NEWCLASS(serverInfo_Dispatch);
	__NEWCLASS(multiPart_Biferno_Dispatch);
	__NEWCLASS(search_Dispatch);
	
	__NEWCLASS(biferno_Dispatch);
	__NEWCLASS(memberInfo_Dispatch);
	__NEWCLASS(classInfo_Dispatch);
	__NEWCLASS(curApp_Dispatch);
	__NEWCLASS(bifernoUnix_Dispatch);
	__NEWCLASS(curScript_Dispatch);
	__NEWCLASS(curFile_Dispatch);
	__NEWCLASS(objSpec_Dispatch);
	__NEWCLASS(BifernoUtils_Biferno_Dispatch);

/*#ifdef JAVA_ENABLED
	__NEWCLASS(byte_Biferno_Dispatch);
	__NEWCLASS(short_Biferno_Dispatch);
	__NEWCLASS(float_Biferno_Dispatch);
#endif*/

#ifdef CONVERTIMAGE_BUILT_IN
	__NEWCLASS(ConvertImage_Biferno_Dispatch);
#endif
	
/*#ifdef JAVA_ENABLED
	__NEWCLASS(jclass_Biferno_Dispatch);
#endif*/

	__NEWCLASS(array_Biferno_Dispatch);
	__NEWCLASS(time_Biferno_Dispatch);
	__NEWCLASS(db_Dispatch);
#ifdef ODBC_BUILT_IN
	__NEWCLASS(odbc_Dispatch);
#endif	
	__NEWCLASS(file_Dispatch);
	__NEWCLASS(folder_Dispatch);
	__NEWCLASS(cacheItem_Dispatch);

	__NEWCLASS(error_Biferno_Dispatch);
	
	//__NEWCLASS(BifernoFunctions_Biferno_Dispatch);
	__NEWCLASS(BifernoAnsi_Biferno_Dispatch);

	__NEWCLASS(Math_Biferno_Dispatch);
#ifdef WITH_SENDMAIL
	__NEWCLASS(sendMail_Dispatch);
#endif

#if __MAC_XLIB__ && WITH_QUICKBASE
	__NEWCLASS(quickbase_Dispatch);
#endif

#if MYSQL_BUILT_IN
	__NEWCLASS(mysql_Dispatch);
#endif
#if POSTGRES_BUILT_IN
	__NEWCLASS(postgres_Dispatch);
#endif

/*#if WITH_POSTGRES
	__NEWCLASS(postgres_Dispatch);
#endif
*/

#if WITH_OCI
	__NEWCLASS(boci_Dispatch);
#endif

	__NEWCLASS(stackItem_Dispatch);
	__NEWCLASS(collection_Dispatch);
	
}

