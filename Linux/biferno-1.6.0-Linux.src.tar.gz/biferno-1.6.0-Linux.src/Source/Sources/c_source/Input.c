/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Input.c,v 1.19 2007-09-25 14:13:05 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "BifernoErrors.h"
#include "Entity.h"
#include "Input.h"
#include "Volatile.h"
#include "BfrParser.h"

#include <string.h>

extern 	DispatcherData	gsDispatcherData;
extern	PluginRecord	*gClassRecordBlockP;

#define	NO_DECODE	false
#define	DECODE		true

#define kTagLen		20		// = StringLen("Content-Disposition:");

#define kInitLen	30		//len of "multipart/form-data; boundary="

#ifdef __LITTLE_ENDIAN__
	#define HEADER_END			0x0A0D0A0D		// '\n\r\n\r' (Visual C++ doesn't want this)
	#define HEADER_END_LINE		0x0A0D			// '\n\r'
	#define	NAME_TAG			'eman'
	#define	TRUE_STRING			'eurt'
	#define	FALSE_STRING		'slaf'
#else
	#define HEADER_END			'\r\n\r\n'
	#define HEADER_END_LINE		'\r\n'
	#define	NAME_TAG			'name'
	#define	TRUE_STRING			'true'
	#define	FALSE_STRING		'fals'
#endif

extern XErr	(*multiPart_NewObject)(long api_data, char *textP, long textLen, char *filePath, char *contentType, ObjRecord *result);

//===========================================================================================
static Boolean	SecurCompareBlock(void *aPtr_p, long sourceMaxLen, void *bPtr_p, long size)
{
Boolean		res;

	if (sourceMaxLen >= size)
		res = CompareBlock(aPtr_p, bPtr_p, size);
	else
		res = true;		// different
		
return res;
}

//===========================================================================================
static XErr	_PopulateArray(long api_data, char *varName, ArrayIndexRec *mCoords, long mCoordsDim, long objID, long classID, ObjRecord *objRefP)
{
XErr			err = noErr;
ObjRecord		resultObjRec, arrayObjref;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			fixedSize;
long			arrayElemClass, arrayDim;
Boolean			expanded;
BfrDestructRec	destructRec;
ObjRecord		valueObjRef = *objRefP, lastArray;

	if (objID)
	{	arrayObjref.list = bRecP->localList;
		arrayObjref.id = objID;
		arrayObjref.classID = classID;
		arrayObjref.scope = LOCAL;
		arrayObjref.type = VARIABLE;
	}
	else
	{	PluginRecord*	plugRecP;
	
		plugRecP = GetPluginRecFromClassID(nil, classID);
		fixedSize = plugRecP->fixedSize;
		INVAL(arrayObjref);
		err = ArrayToObjExt(api_data, fixedSize, varName, LOCAL, VARIABLE, nil, 0, nil, OBJREF_P(&arrayObjref));
	}
	if NOT(err)
	{	if (mCoordsDim > 1)
		{	err = BAPI_ElementOfArrayExt(api_data, (ObjRef*)&arrayObjref, mCoords, (short)(mCoordsDim-1), (ObjRef*)&lastArray);	// get the last array of chain
			if (err == XError(kBAPI_Error, Err_OutOfBoundary))													// doesn't exist yet (ResolveArrayElement will allocate it)
			{	arrayElemClass = 0;		// no typecast
				err = noErr;
			}
			else if NOT(err)
				err = DLM_GetArrayInfo(lastArray.list, lastArray.id, nil, nil, &arrayDim, &arrayElemClass);
		}
		else
			err = DLM_GetArrayInfo(arrayObjref.list, arrayObjref.id, nil, nil, &arrayDim, &arrayElemClass);		// this is also the last
		if NOT(err)
		{	if (arrayElemClass && (arrayElemClass != objRefP->classID))
			{	INVAL(valueObjRef);
				err = BAPI_TypeCast(api_data, (ObjRef*)objRefP, arrayElemClass, (ObjRef*)&valueObjRef, kExplicitTypeCast);
			}
			if NOT(err)
			{	if ((mCoordsDim == 1) && NOT(mCoords->ind))
					mCoords->ind = arrayDim + 1;
				INVAL(resultObjRec);
				if NOT(err = ResolveArrayElement(api_data, OBJREF_P(&arrayObjref), mCoords, (short)mCoordsDim, nil, &expanded, OBJREF_P(&valueObjRef), OBJREF_P(&resultObjRec), nil))
				{	if NOT(expanded)
					{	destructRec.api_data = api_data;
						destructRec.scope = resultObjRec.scope;
						err = DLM_ModifyObjExt(resultObjRec.list, resultObjRec.id, valueObjRef.list, valueObjRef.id, VariableDestructorExt, (long)&destructRec, nil);
					}
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_StoreThisVariable(long api_data, char *varName, Ptr saveP, long len, long classID, ArrayIndexRec *mCoords, long mCoordsDim, Boolean toDecode, Boolean isFile, char *fileName, char *contentType)
{
Ptr				valueP;
XErr			err = noErr, err2 = noErr;
long			foundClassID;
BlockRef		resultBlock = 0;
long			objID;
BifernoRecP		bRecP;
ObjRecord		tempObjRef, objRef, previousObjRef;
BAPI_Doc 		*docP;
ParameterRec	param;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if NOT(classID)
		classID = kStringClassID;
	if (toDecode)
	{	if NOT(err = DecodeURL((Byte*)saveP, len, &resultBlock, &len, true, nil))
		{	LockBlock(resultBlock);
			valueP = GetPtr(resultBlock);
		}
	}
	else
		valueP = saveP;
	if NOT(err)
	{	// check if already exists
		objID = DLM_GetObjID(bRecP->localList, varName, nil, &foundClassID);
		if (objID && NOT(mCoordsDim))	// already exists? (array elements can be duplicated)
		{	if (isFile)
				err = XError(kBAPI_Error, Err_MultipartObjectDuplicated);
			else if (foundClassID != classID)
			{	err = XError(kBAPI_Error, Err_VariableDuplicatedInURL);
				NewMsgRecord(api_data, kNote, "A variable of a different class already exists with this name", 0, 0);
			}
			else if ((classID != kStringClassID) || (foundClassID != kStringClassID))
			{	err = XError(kBAPI_Error, Err_VariableDuplicatedInURL);
				NewMsgRecord(api_data, kNote, "Only strings can be declarated twice in URL", 0, 0);
			}
		}
		if NOT(err)
		{	// Build the value object (in TEMP)
			INVAL(objRef);
			if (isFile)
				err = multiPart_NewObject(api_data, valueP, len, fileName, contentType, &objRef);
			else if NOT(err = CL_StringToObj(api_data, valueP, len, CONSTANT, &objRef))
			{	BAPI_ClearParameterRec(api_data, &param);
				param.objRef = OBJREF(objRef);
				if NOT(err = GetContructorDoc(api_data, classID, &docP))
				{	INVAL(objRef);
					if (err = CL_Constructor(api_data, TEMP, VARIABLE,  nil, classID, &param, 1, docP, &objRef))
					{	NewMsgRecord(api_data, kVARIABLE, varName, 0, 0);
						INVAL(param.objRef);
						if (err2 = UpdateErrObject(api_data, err, OBJRECORD_P(&param.objRef), nil))
							err = err2;
					}
				}
			}
			if NOT(err)
			{	if (mCoordsDim)																	// i.e. a[10]=...
				{	if NOT(err = _PopulateArray(api_data, varName, mCoords, mCoordsDim, objID, classID, &objRef))
						err = DLM_TurnOnFlag(objRef.list, objRef.id, kNoDestructor, kDLMWhole);
				}
				else
				{	if (objID)					// already exists? (note that only for strings we do concat (see check above))
					{	INVAL(tempObjRef);
						previousObjRef.list = bRecP->localList;
						previousObjRef.id = objID;
						previousObjRef.classID = 0;
						previousObjRef.scope = 0;
						previousObjRef.type = 0;
						if NOT(err = StringToConstObj(api_data, ", ", 2, OBJREF_P(&tempObjRef)))
						{	if NOT(err = BAPI_ConcatObjs(api_data, OBJREF_P(&previousObjRef), OBJREF_P(&tempObjRef)))
								err = BAPI_ConcatObjs(api_data, OBJREF_P(&previousObjRef), OBJREF_P(&objRef));
						}
						if (err)
							CL_Destructor(api_data, &objRef);
					}
					else
					{	tempObjRef = objRef;
						if NOT(err = CopyObjectExt(api_data, OBJREF_P(&objRef), varName, LOCAL, VARIABLE, OBJREF_P(&objRef)))
						{	if NOT(IS_IMMEDIATE(tempObjRef))										// we just copied the object (-> no destructor on the source obj) 
								err = DLM_TurnOnFlag(OBJ_LIST(tempObjRef), OBJ_ID(tempObjRef), kNoDestructor, kDLMElements);
						}
					}
				}
			}
		}
	}
	if (resultBlock)
		DisposeBlock(&resultBlock);

return err;
}

//===========================================================================================
static Boolean	_IsPrimitive(long classID)
{
	switch(classID)
	{
		case kBooleanClassID:
		case kStringClassID:
		case kDoubleClassID:
		case kLongClassID:
		case kUnsignedClassID:
		case kIntClassID:
		case kCharClassID:
			return true;
			
		default:
			return false;
	}


return false;
}

//===========================================================================================
static XErr 	_GetVarNameAndIndex(long api_data, Ptr *inputPPtr, long *inputLenPtr, char *varName, ArrayIndexRec *mCoords, long *mCoordsDimP, long *classIDP, long *constNameLengthP)
{
XErr		err = noErr;
Ptr			tempP;
long		tempLen;
CStr63		entity;
Boolean		isConstructor;

	tempP = *inputPPtr;
	tempLen = *inputLenPtr;
	*classIDP = *constNameLengthP = 0;
	*entity = 0;
	isConstructor = IsConstructor(api_data, &tempP, &tempLen, entity, false, classIDP, true, nil, &err);
	if (err)
		return err;
	if (isConstructor)						// the user wants a vriable of a particular class
	{	if NOT(_IsPrimitive(*classIDP))
			err = XError(kBAPI_Error, Err_BadSyntaxInURL);
		else
		{	if NOT(err = GetEntityName(api_data, &tempP, &tempLen, varName, false))
			{	if (tempLen && (*tempP == ')'))	// ), Note that "fromInput" of IsConstructor was true, so it skipped also the '(' char
				{	tempP++;
					tempLen--;
				}
				else
				{	tempP += 3;					// %NN (if we we have not decoded yet)
					tempLen -= 3;
				}
				if (DLM_GetObjID(gsDispatcherData.reservedKeyword, varName, nil, nil))
					err = XError(kBAPI_Error, Err_ReservedKeyword);
				else
				{	/*if (isConstructor)			// can't have a constructo and an index (int(a[1]) -> error)
					{	mCoords->ind = 0;
						*mCoords->ind_name = 0;
						*mCoordsDimP = 0;
						*constNameLengthP = CLen(entity);
					}
					else*/
					err = ResolveArryItem(api_data, &tempP, &tempLen, nil, mCoords, mCoordsDimP, true, nil, nil);
				}
			}
		}
	}
	else if (*entity)						// in this case entity contains the name of the variable
	{	CEquStr(varName, entity);
		if (tempLen && (*tempP == '.'))		// for cases like: "CercaIMG.x - CercaIMG.y in image Button"
		{	tempP++;
			tempLen--;
			if NOT(err = GetEntityName(api_data, &tempP, &tempLen, entity, false))
			{	CAddChar(varName, '_');
				CAddStr(varName, entity);	// [name variable]_x or [name variable]_y
			}
		}
		if NOT(err)
		{	if (DLM_GetObjID(gsDispatcherData.reservedKeyword, varName, nil, nil))
				err = XError(kBAPI_Error, Err_ReservedKeyword);
			else							// i.e a[1]
				err = ResolveArryItem(api_data, &tempP, &tempLen, nil, mCoords, mCoordsDimP, true, nil, nil);
		}
	}
	else
		err = XError(kBAPI_Error, Err_EmptyName);

*inputPPtr = tempP;
*inputLenPtr = tempLen;
return err;
}

//===========================================================================================
static XErr 	_NewVariableFromInput(long api_data, Ptr *inputPPtr, long *inputLenPtr)
{
Ptr				tempP, saveP;
long			tempLen, classID, mCoordsDim;
CStr63			varName;
long			constrNameLength, len;
XErr			err = noErr;
ArrayIndexRec	mCoords[MAX_ARRAYINDEX];

	tempP = *inputPPtr;
	tempLen = *inputLenPtr;
	if (tempLen && (*tempP == '&'))
	{	tempP++;
		tempLen--;
	}
	// skip amp
	if (tempLen > 3 && not(CompareBlock(tempP, "amp;", 4)))
	{	tempP += 4;
		tempLen -= 4;
	}
	classID = 0;
	if (tempLen)
	{	if NOT(err = _GetVarNameAndIndex(api_data, &tempP, &tempLen, varName, mCoords, &mCoordsDim, &classID, &constrNameLength))
		{	if (tempLen)
			{	if (tempLen && (*tempP == '='))		// Value of variabile
				{	tempP++;
					tempLen--;
					saveP = tempP;
					while (tempLen && (*tempP != '&'))
					{	tempP++;
						tempLen--;
					}
					// skip amp
					if (tempLen > 3 && not(CompareBlock(tempP, "amp;", 4)))
					{	tempP += 4;
						tempLen -= 4;
					}
					len = tempP - saveP;
					if ((len == 2) && (*(short*)(tempP-2) == HEADER_END_LINE))
						len = 0;
					else if ((len == 6) && Begins(tempP-6, len, "%0D%0A", 6))
						len = 0;
					err = _StoreThisVariable(api_data, varName, saveP, len, classID, /*constrNameLength, */mCoords, mCoordsDim, DECODE, false, nil, nil);
				}
				else
					err = XError(kBAPI_Error, Err_BadSyntaxInURL);
			}
			else
				err = XError(kBAPI_Error, Err_BadSyntaxInURL);
		}
	}

if (err)
	NewMsgRecord(api_data, kDOINGURL, *inputPPtr, *inputLenPtr, 0);
*inputPPtr = tempP;
*inputLenPtr = tempLen;
return err;
}


//===========================================================================================
static XErr	_MultiPartFormDataFillList(long api_data, register Ptr buffP, long postLen)
{
long			constrNameLength, errLen, boundaryLen, len;
register int	i;
register Ptr	fileP,tagP, boundaryP;
XErr			err = noErr;
CStr255			contentType, filename, name;
Boolean			isFile;
long			buffLen;
long			varClass, mCoordsDim;
ArrayIndexRec	mCoords[MAX_ARRAYINDEX];
Ptr				errP, saveP;
	
	len = postLen;
	boundaryP = buffP;
	boundaryLen = 0;
	while ((*(short*)buffP != HEADER_END_LINE) && len)
	{	boundaryLen++;
		len--;
		buffP++;
	}
	buffP += sizeof(short);
	len -= sizeof(short);
	tagP = buffP;
	errP = buffP;
	errLen = len;
	while ((len > 0) && NOT(err))
	{	if NOT(SecurCompareBlock(buffP, len, tagP, kTagLen))
		{	buffP += kTagLen;
			len -= kTagLen;
			while((len > 0) && NOT(err))
			{	if ((len >= 6) && (*(long*)buffP == NAME_TAG))
				{	buffP += 6;			//name="
					len -= 6;
					i = 1;
					// Name of variabile
					saveP = buffP;	// use register
					errP = buffP;
					errLen = len;
					if (err = _GetVarNameAndIndex(api_data, &saveP, &len, name, mCoords, &mCoordsDim, &varClass, &constrNameLength))
						goto out;
					buffP = saveP;
					if (len > 0)
					{	buffP++;
						len--;
					}
					else
					{	err = XError(kBAPI_Error, Err_BadSyntaxInURL);
						goto out;
					}
					if ((len >= 12) && Begins(buffP, len, "; filename", 10))
					{	buffP += 12;	// ; filename="
						len -= 12;
						if (len > 0)
						{	i = 0;
							while(len && (*buffP != '\"') && (i < 255))
							{	filename[i++] = *buffP++;
								len--;
							}
							filename[i] = 0;
							IsoToNative(filename, i);
							if (len)
							{	buffP++;
								len--;
							}
							isFile = true;
						}
					}
					else
					{	*filename = 0;
						isFile = false;
					}
					*contentType = 0;
					while((len > 0) && ((len < 4) || (*(long*)buffP != HEADER_END)))
					{	if NOT(SecurCompareBlock(buffP, len, "Content-Type:", 13))
						{	buffP += 13;
							len -= 13;
							if (len && (*buffP == ' '))
							{	buffP++;
								len--;
							}
							i = 0;
							while(len && (*(short*)buffP != HEADER_END_LINE) && (i < 255))
							{	contentType[i++] = *buffP++;
								len--;
							}
							contentType[i] = 0;
						}
						else
						{	buffP++;
							len--;
						}
					}
					buffP += 4;
					len -= 4;
					if (len <= 0)
					{	err = XError(kBAPI_Error, Err_BadSyntaxInURL);
						goto out;
					}
					if (isFile)
					{	buffLen = 0;
						fileP = buffP;
						while(len && SecurCompareBlock(buffP, len, boundaryP, boundaryLen))
						{	buffP++;
							buffLen++;
							len--;
						}
						if (buffLen >= 2)
							buffLen -= 2;
						err = _StoreThisVariable(api_data, name, fileP, buffLen, varClass, /*constrNameLength, */mCoords, mCoordsDim, NO_DECODE, true, filename, contentType);
					}
					else
					{	saveP = buffP;
						while(len && SecurCompareBlock(buffP, len, boundaryP, boundaryLen))
						{	buffP++;
							len--;
							buffLen++;
						}
						buffLen = buffP - saveP;
						if (*(short*)(buffP-2) == HEADER_END_LINE)
							buffLen -= 2;
						IsoToNative(saveP, buffLen);
						err = _StoreThisVariable(api_data, name, saveP, buffLen, varClass, /*constrNameLength, */mCoords, mCoordsDim, NO_DECODE, false, nil, nil);
					}
					buffP += boundaryLen;
					len -= boundaryLen;
					break;
				}
				len--;
				buffP++;
			}
		}
		else
		{	len--;
			buffP++;
		}
	}

out:
if (err)
	NewMsgRecord(api_data, kDOING, errP, errLen, 0);
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	GetInputParameters(long api_data, BlockRef *inputArgsBlockP, long inputLen, char *contentType)
{
XErr	err = noErr;

	if (inputArgsBlockP && inputLen)
	{	char		*inputP;
		long		contTypeLen;
		Boolean		skip = false, isMultipart = false;
		
		LockBlock(*inputArgsBlockP);
		inputP = GetPtr(*inputArgsBlockP);
		if (contentType)
		{
			contTypeLen = CLen(contentType);
			if (CBegins(contentType, "text/", false))
				skip = true;
			else if (contTypeLen > 8)
			{	CUp2LowerStr(contentType, 0);
				if (NOT(SecurCompareBlock(contentType, contTypeLen, "multipart", 9)))
					isMultipart = true;
			}
		}	
		if not(skip)
		{
			if (isMultipart)
				err = _MultiPartFormDataFillList(api_data, inputP, inputLen);
			else	
			{	while((inputLen > 0) && NOT(err))
					err = _NewVariableFromInput(api_data, &inputP, &inputLen);
			}
		}
		DisposeBlock(inputArgsBlockP);
		*inputArgsBlockP = 0;
		if NOT(err)
			err = ResetVolatileList((BifernoRec*)api_data);
	}
	
return err;
}

