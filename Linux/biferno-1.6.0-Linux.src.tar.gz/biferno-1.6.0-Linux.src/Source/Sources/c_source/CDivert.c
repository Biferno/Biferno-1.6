/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: CDivert.c,v 1.4 2005-11-04 14:15:18 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Dispatcher.h"
#include "Variable.h"

#include "CDivert.h"

//===========================================================================================
/*static XErr	SetMyType(Biferno_ParamBlockPtr pbPtr, ObjRecord *objRefP, long destClassID)
{
	objRefP->classID = destClassID;
	return BAPI_ModifyObjClassID(pbPtr->api_data, objRefP, destClassID);
}*/

//===========================================================================================
/*static XErr	_CloneFastInTemp(long api_data, ObjRecord *objRef, ObjRecord *resultObjRefP)
{
ParameterRec	param;
XErr			err = noErr;

	BAPI_ClearParameterRec(api_data, &param);
	param.objRef = *objRef;
	err = CL_Clone(api_data, TEMP, VARIABLE, nil, objRef->classID, &param, 1, 0, resultObjRefP);

return err;
}

#if __MWERKS__
#pragma mark-
#endif
*/
//===========================================================================================
/* 	Basically your object contains only the super
	Nota that class must return Err_BAPI_MessageNotHandled only if they 
	don't have constructor at all (handle all or nothing, no middle ways!)
*/
static XErr		_CDivert_Constructor(PluginRecord *plugRecP, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ConstructorRec	*constrP = &pbPtr->param.constructorRec;
//CStr63			saveName;
ObjRecord		tempSuperObjRef;
long			savePrivateData;
ObjRef			saveConstrResult;

	savePrivateData = constrP->privateData;
	//CEquStr(saveName, constrP->resultObjName);
	//saveScope = constrP->scope;
	constrP->privateData = 0;
	//*constrP->resultObjName = 0;
	//constrP->scope = TEMP;
	saveConstrResult = constrP->resultObjRef;
	INVAL(constrP->resultObjRef);
	if NOT(err = BAPI_Accessor(api_data, plugRecP->extendedPluginID, kConstructor, pbPtr))
	{	tempSuperObjRef = *(ObjRecord*)&constrP->resultObjRef;
		constrP->resultObjRef = saveConstrResult;
		if NOT(err = BAPI_BufferToObjWithSuper(api_data, "", 0, plugRecP->pluginID, true, OBJREF_P(&tempSuperObjRef), savePrivateData, &constrP->resultObjRef))
			;//err = DLM_TurnOnFlag(tempSuperObjRef.list, tempSuperObjRef.id, kNoDestructor, kDLMWhole);
		
		/*
ObjRecord			superObjRef, *objRefP;
ParameterRec	param;
		objRefP = &constrP->resultObjRef;
		superObjRef = *objRefP;
		objRefP->classID = plugRecP->pluginID;
		if NOT(err = BAPI_ModifyObjClassID(api_data, objRefP, plugRecP->pluginID))
		{	
		
			BAPI_ClearParameterRec(api_data, &param);
			param.objRef = superObjRef;
			if NOT(err = CL_Clone(api_data, TEMP, VARIABLE, nil, superObjRef.classID, &param, 1, superObjRef.classID, &superObjRef))
				err = BAPI_NewSuperObj(api_data, objRefP, &superObjRef, nil);
		}
		*/
	}
		
return err;
}

//===========================================================================================
static XErr		_CDivert_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ObjRecord	superObjRef;

	if NOT(err = BAPI_GetSuperObj(pbPtr->api_data, &pbPtr->param.destructorRec.objRef, OBJREF_P(&superObjRef)))
		err = CDivert(kDestructor, pbPtr, &superObjRef);
		
return err;
}

//===========================================================================================
static XErr		_CDivert_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ObjRecord	superObjRef, *objP, saveObj;//, newObjRef;
long		api_data = pbPtr->api_data;

	objP = OBJRECORD_P(&pbPtr->param.executeOperationRec.objRef1);
	saveObj = *objP;
	if NOT(err = BAPI_GetSuperObj(api_data, OBJREF_P(objP), OBJREF_P(&superObjRef)))
	{	if NOT(err = CDivert(kExecuteOperation, pbPtr, (ObjRecord*)&superObjRef))
			err = CL_SuperIsChanged(api_data, &saveObj, nil);
	}
		
return err;
}

//===========================================================================================
static XErr		_CDivert_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ObjRecord		*objP, superObjRef;

	objP = OBJRECORD_P(&pbPtr->param.primitiveRec.objRef);
	if NOT(err = BAPI_GetSuperObj(pbPtr->api_data, OBJREF_P(objP), OBJREF_P(&superObjRef)))
		err = CDivert(kPrimitive, pbPtr, &superObjRef);
		
return err;
}

//===========================================================================================
static XErr		_CDivert_GetErrMessage(PluginRecord *plugRecP, Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ObjRecord	superObjRef;

	superObjRef.id = 0;
	superObjRef.classID = plugRecP->extendedPluginID;
	err = CDivert(kGetErrMessage, pbPtr, &superObjRef);
		
return err;
}

//===========================================================================================
/*static XErr		_CDivert_GetErrNumber(PluginRecord *plugRecP, Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ObjRecord		superObjRef;

	superObjRef.id = 0;
	superObjRef.classID = plugRecP->extendedPluginID;
	err = CDivert(kGetErrNumber, pbPtr, &superObjRef);
		
return err;
}*/

//===========================================================================================
/*	If we are here object contains only the super
*/
/*static XErr		_CDivert_GetSuperObj(PluginRecord *plugRecP, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
GetSuperObjRec	*getSuperObjP = &pbPtr->param.getSuperObjRec;
	
	getSuperObjP->superObjRef = getSuperObjP->objRef;
	getSuperObjP->superObjRef.classID = plugRecP->extendedPluginID;
		
return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	CDivert(Biferno_Message message, Biferno_ParamBlockPtr pbPtr, ObjRecord *superObjRef)
{
XErr		err = noErr;
long 		api_data;
uint32_t	*plugin_global_dataP;
uint32_t	*plugin_run_dataP;
long		parentClass;
ObjRecord	saveObjRef;

	if (superObjRef && superObjRef->classID)
		parentClass = superObjRef->classID;
	else
		parentClass = 0;
	api_data = pbPtr->api_data;
	plugin_global_dataP = pbPtr->plugin_global_dataP;
	plugin_run_dataP = pbPtr->plugin_run_dataP;
	switch(message)
	{	case kRegister:
		case kInit:
		case kShutDown:
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
		case kDestructor:
			pbPtr->param.destructorRec.objRef = OBJREF(*superObjRef);
			err = BAPI_Accessor(api_data, superObjRef->classID, message, pbPtr);
			break;
		case kExecuteOperation:
			{
			ExecuteOperationRec		*exRecP = &pbPtr->param.executeOperationRec;
			long					childClass;
			ObjRecord				tempObjRef;
			
				childClass = ((ObjRecord*)&exRecP->objRef1)->classID;
				exRecP->objRef1 = OBJREF(*superObjRef);
				INVAL(tempObjRef);
				if NOT(err = CL_TypeCast(api_data, OBJRECORD_P(&exRecP->objRef2), parentClass, &tempObjRef/*OBJRECORD_P(&exRecP->objRef2)*/, kExplicitTypeCast))
				{	exRecP->objRef2 = *(ObjRef*)&tempObjRef;
					err = BAPI_Accessor(api_data, parentClass, message, pbPtr);
						// err = CL_TypeCast(api_data, &exRecP->objRef1, childClass, &exRecP->objRef1, kExplicitTypeCast);
				}
			}
			break;
		case kExecuteMethod:
			{
			ExecuteMethodRec		*exMethRecP = &pbPtr->param.executeMethodRec;
			
				saveObjRef = OBJRECORD(exMethRecP->objRef);
				exMethRecP->objRef = OBJREF(*superObjRef);
				//if NOT(err = CL_TypeCast(api_data, &exMethRecP->objRef, parentClass, &exMethRecP->objRef, kExplicitTypeCast))
					err = BAPI_Accessor(api_data, parentClass, message, pbPtr);
				exMethRecP->objRef = OBJREF(saveObjRef);
			}
			break;
		case kExecuteFunction:
			{
			//ExecuteMethodRec		*exFuncRecP = &pbPtr->param.executeMethodRec;
			
				err = BAPI_Accessor(api_data, parentClass, message, pbPtr);
			}
			break;
		case kGetProperty:
			{
			GetPropertyRec			*getPropRecP = &pbPtr->param.getPropertyRec;
			
				saveObjRef = OBJRECORD(getPropRecP->objRef);
				getPropRecP->objRef = OBJREF(*superObjRef);
				//if NOT(err = CL_TypeCast(api_data, &getPropRecP->objRef, parentClass, &getPropRecP->objRef, kExplicitTypeCast))
				err = BAPI_Accessor(api_data, parentClass, message, pbPtr);
				getPropRecP->objRef = OBJREF(saveObjRef);
			}
			break;
		case kSetProperty:
			{
			SetPropertyRec			*setPropRecP = &pbPtr->param.setPropertyRec;
			//ObjRecord					originaleObjRef, newObjRef;
			
				//originaleObjRef = setPropRecP->objRef;
				//if NOT(err = CL_TypeCast(api_data, &originaleObjRef, parentClass, &setPropRecP->objRef, kExplicitTypeCast))
				{	saveObjRef = OBJRECORD(setPropRecP->objRef);
					setPropRecP->objRef = OBJREF(*superObjRef);
					if NOT(err = BAPI_Accessor(api_data, parentClass, message, pbPtr))
					{	/*if NOT(err = CL_TypeCast(api_data, &setPropRecP->objRef, childClass, &newObjRef, kExplicitTypeCast))
						{	ModifyVariable(api_data, &originaleObjRef, &newObjRef);
						
						}*/
					}
					setPropRecP->objRef = OBJREF(saveObjRef);
				}
			}
			break;
		case kPrimitive:
			{
			PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;

				saveObjRef = OBJRECORD(typeCast->objRef);
				typeCast->objRef = OBJREF(*superObjRef);
				err = BAPI_Accessor(api_data, parentClass, message, pbPtr);
				typeCast->objRef = OBJREF(saveObjRef);
			}
			break;
		case kGetErrMessage:
			err = BAPI_Accessor(api_data, parentClass, message, pbPtr);
			break;
		/*case kGetErrNumber:
			err = BAPI_Accessor(api_data, parentClass, message, pbPtr);
			break;*/
		/*case kGetSuperObj:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);		// impossible to hanlde
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	pbPtr->api_data = api_data;
	pbPtr->plugin_global_dataP = plugin_global_dataP;
	pbPtr->plugin_run_dataP = plugin_run_dataP;

return err;
}

//===========================================================================================
// Invoked if an extending class returned Err_BAPI_MessageNotHandled
XErr	CDivertDispatcher(Biferno_Message message, Biferno_ParamBlockPtr pbPtr, PluginRecord *plugRecP)
{
XErr		err = noErr;

	switch(message)
	{	case kRegister:
		case kInit:
		case kShutDown:
		case kRun:
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = _CDivert_Constructor(plugRecP, pbPtr);
			break;
		case kDestructor:
			err = _CDivert_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = _CDivert_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);				// non dovrebbe succedere mai
			break;
		case kExecuteFunction:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);				// non dovrebbe succedere mai
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);				// non dovrebbe succedere mai
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);				// non dovrebbe succedere mai
			break;
		case kPrimitive:
			err = _CDivert_TypeCast(pbPtr);
			break;
		case kGetErrMessage:
			err = _CDivert_GetErrMessage(plugRecP, pbPtr);
			break;
		case kSuperIsChanged:
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}



