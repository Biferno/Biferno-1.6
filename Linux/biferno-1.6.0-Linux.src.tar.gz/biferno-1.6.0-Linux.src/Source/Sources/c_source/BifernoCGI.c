/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoCGI.c,v 1.16 2006-07-19 10:23:10 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

#include "HTTPMgr.h"
#include "HTTPMrgNet.h"

#include "XThreadsPrivate.h"

//#define	BIFERNO_WSAPI_PLUGIN_VERSION	"1.0"

#include	"BifernoAPI.h"
#include	"BifernoEngineAPI.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

//static XFilePath 	gsCurAppDir;
//static long			gsCurAppDirLen;

#define	BFADMIN_INDEX_FILE			"index.bfr"
#define	BFADMIN_INDEX_FILE_LENGTH	9

#define	START_SCRIPT	"\r\n============= BEGIN BIFERNO SCRIPT OUTPUT ===\r\n"
#define	END_SCRIPT		"\r\n============= END BIFERNO SCRIPT OUTPUT =====\r\n"

extern XFileRef	gLogRefNum, gExtraLogRefNum, gCurrentLogRefNum;

//===========================================================================================
static XErr _GetPhysURL(void *taskID, char *serverDir, BlockRef fullRequest, long fullRequestLen, BlockRef *blockP, long *lenP, Boolean *isAdminP)
{
Ptr		p, phisURL;
XErr	err = noErr;
long	tot, servDirLen;

	phisURL = GetPtr(fullRequest);
	URLFromFullRequest(&phisURL, &fullRequestLen);
	if (FindStringInText(BADMIN_FOLDER, BADMIN_FOLDER_LEN, phisURL, fullRequestLen, nil, true, false))
	{	servDirLen = CLen(serverDir) - 1;	// for finale '/'
		tot = servDirLen+fullRequestLen;
		if (*blockP = NewPtrBlock(tot + 1 + BFADMIN_INDEX_FILE_LENGTH, &err, &p))
		{	//p = GetPtr(*blockP);
			CopyBlock(p, serverDir, servDirLen);
			CopyBlock(p + servDirLen, phisURL, fullRequestLen);
			p[tot] = 0;
			if (p[tot-1] == '/')
			{	CAddStr(p, BFADMIN_INDEX_FILE);
				tot += BFADMIN_INDEX_FILE_LENGTH;
			}
			*lenP = tot;
			*isAdminP = true;
		}
	}
	else
	{	err = HTTPControllerGetPhysURL(taskID, blockP, lenP);
		*isAdminP = false;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static void	Suspend(void *taskID)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif

	BEngineAPI_Suspend();
}

//===========================================================================================
static void	Resume(void *taskID)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif

	BEngineAPI_Resume();
}

//===========================================================================================
static XErr	Init(void *taskID, long *maxUsersP, Boolean locally, char *messageErr)
{
XErr	err = noErr;

	//if NOT(err = GetXApplicationCurrentDir(gsCurAppDir))
	//{	gsCurAppDirLen = CLen(gsCurAppDir);
		err = BEngineAPI_Init(maxUsersP, HTTPControllerLog, taskID, locally, messageErr);
	//}
	
return err;
}

//===========================================================================================
static XErr	ShutDown(void *taskID)
{
XErr		err = noErr;
CStr255		aCStr, eNameStr, eMsg;
long		eNum;

	err = BEngineAPI_End(HTTPControllerLog, taskID, 0);
	if (err)
	{	XErrorGetDescr(err, eNameStr, eMsg);
		XErrorGetTypeValue(err, &eNum, nil);
		sprintf(aCStr, "Error %d: %s %s", (int)eNum, eNameStr, eMsg);
		HTTPControllerLog(taskID, aCStr);
	}

return err;
}

//===========================================================================================
static XErr	Process(void *taskID, char *filePath)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif
XErr		err = noErr;
BlockRef	resultText, inputBl = 0, *inputBlP = nil;
long		inputLen = 0, resultLen;
char		*strP;
XErr		the_error = noErr;

#if CHECK_LEAKING
long		leaksHnd;
CStr255		aCStr, logStr;
Boolean		checkLeak;

	checkLeak = ResetLeaking();
#endif

#ifdef __MAC_XLIB__
	Prof_CLEAR;
	Prof_ON;
#endif
	//TRACE("strchr");
	if (strP = strchr(filePath ,'?'))
	{	Ptr	inputBlockPtr;
	
		if (inputLen = CLen(filePath) - (strP + 1 - filePath))
		{	if (inputBl = NewBlockLocked(inputLen, &err, (Ptr*)&inputBlockPtr))
			{	//LockBlock(inputBl);
				CopyBlock(inputBlockPtr/*GetPtr(inputBl)*/, strP+1, inputLen);
				*strP = 0;
				inputBlP = &inputBl;
			}
		}
		else
			*strP = 0;
	}	
	
	if NOT(err)
	{	//TRACE("BEngineAPI_Run");
		HTTPControllerWindowOutput(taskID, filePath, CLen(filePath));
		HTTPControllerWindowOutput(taskID, START_SCRIPT, CLen(START_SCRIPT));
		//HTTPControllerWindowOutput(taskID, "\r\n=========\r\n", 11);
		BEngineAPI_Run(0, "", filePath, "", nil, 0, inputBlP, inputLen, "", &resultText, &resultLen, HTTPControllerWindowOutput, kIsLocalFile, 0, nil, nil, &the_error);
		if (inputBl)
			DisposeBlock(&inputBl);
		if (the_error)
		{	if (err = HTML2Txt(&resultText, &resultLen, false))
				DisposeBlock(&resultText);
			else
				err = HTTPControllerWindowOutputExt(taskID, resultText, resultLen);
		}
		else
		{	if (resultText)
				DisposeBlock(&resultText);
		}
		HTTPControllerWindowOutput(taskID, END_SCRIPT, CLen(END_SCRIPT));
		BEngineAPI_Idle(HTTPControllerLog, 0);
	}
#ifdef __MAC_XLIB__
	Prof_OFF;
	Prof_DUMP;
#endif

#if CHECK_LEAKING
if (checkLeak)
{	CheckLeaking(aCStr, nil, &leaksHnd);
	if (*aCStr)
	{	
		#ifdef __UNIX_XLIB__
			sprintf(logStr, "%s\n", aCStr);
			// printf(logStr);
		#elif __MAC_XLIB__
			sprintf(logStr, "%s", aCStr);
			SysBeep(3);
		#else	// Win32
			sprintf(logStr, "%s", aCStr);
			//Beep(400, 100);
		#endif
	}
}
#endif
return err;
}

//#define	DUMP_FULL_REQUESTS	1

#ifdef DUMP_FULL_REQUESTS
static XFileRef			gsDumpFileRef = 0;
static unsigned long	gsCount = 0;
//===========================================================================================
static void	_DumpCnt(unsigned long cnt)
{
CStr63	aCStr;
long	tLen;

	CNumToString(cnt, aCStr);
	CAddStr(aCStr, " ok\r\n");
	tLen = CLen(aCStr);
	WriteXFile(gsDumpFileRef, aCStr, &tLen);
}

//===========================================================================================
static unsigned long	_DumpFullRequest(long taskID, BlockRef headBlock, long headBlockLen, char *method, BlockRef inputArgBlock, long inputArgLen)
{
CStr255			ipAddress, dateStr, filePath;
XErr			err = noErr;
long			tLen;
unsigned long	cnt;

	if NOT(gsDumpFileRef)
	{	HTTPControllerLog(taskID, "Dump Full Requests is on");
		if NOT(err = XGetApplicationFolderPath(filePath))
		{	CAddStr(filePath, "BifernoFullRequests.log");
			err = OpenXFile(filePath, CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &gsDumpFileRef);
		}
	}
	if NOT(err)
	{	XCurrentDateTimeToString(dateStr, kComplete);
		HTTPControllerGetIPAddress(taskID, ipAddress);
		CAddStr(dateStr, "\t");
		CAddStr(dateStr, ipAddress);
		cnt = ++gsCount;
		CNumToString(cnt, ipAddress);
		CAddStr(dateStr, "\t");
		CAddStr(dateStr, ipAddress);
		CAddStr(dateStr, "\r\n");
		tLen = CLen(dateStr);
		if NOT(err = WriteXFile(gsDumpFileRef, dateStr, &tLen))
		{	if NOT(err = WriteXFile(gsDumpFileRef, GetPtr(headBlock), &headBlockLen))
			{	if NOT(strcmp(method, "POST"))
				{	if NOT(err = WriteXFile(gsDumpFileRef, GetPtr(inputArgBlock), &inputArgLen))
					{	inputArgLen = 4;
						err = WriteXFile(gsDumpFileRef, "\r\n\r\n", &inputArgLen);
					}
				}
			}
		}	
	}

return cnt;
}
#endif

//===========================================================================================
static XErr	Run(void *taskID, Boolean prefixLengthInResult, LONGLONG uniqueID, char *sid, char *response, char *appName)
{
long		filePathLen;
XErr		err = noErr;
char		*filePath;
long		headBlockLen, resultLen;
long		inputArgLen;
BlockRef	inputArgBlock, headBlock, htmlErrBlock, resultText, physURL_block;
CStr255		serverDir, contentType, method, serverName;
Boolean		isAdmin;
short		flags = 0;
int			off;

#ifdef DUMP_FULL_REQUESTS
	unsigned long	cnt;
#endif

#if CHECK_LEAKING
long		leaksHnd, leaksPtr;
CStr255		logStr;
Boolean		checkLeak;

	checkLeak = ResetLeaking();
#endif
	
#ifdef __MAC_XLIB__
	Prof_CLEAR;
	Prof_ON;
#endif

	headBlock = nil;
	*contentType = 0;
	if NOT(err = HTTPControllerGetServerName(taskID, serverName))
	{	if NOT(err = HTTPControllerGetFullRequest(taskID, &headBlock, &headBlockLen))	
		{	if NOT(err = HTTPControllerGetServerDir(taskID, serverDir))
			{	resultText = 0;
				htmlErrBlock = 0;
				if NOT(err = _GetPhysURL(taskID, serverDir, headBlock, headBlockLen, &physURL_block, &filePathLen, &isAdmin))
				{	if (isAdmin)
						flags |= kIsAdmin;
					if (prefixLengthInResult)
						flags |= kPrefixLengthInResult;
					filePath = GetPtr(physURL_block);
					if (filePathLen)
					{	if NOT(err = HTTPControllerGetMethod(taskID, method))
						{	inputArgBlock = 0;
							if NOT(strcmp(method, "POST"))
							{	if NOT(err = HTTPControllerGetPostArgs(taskID, &inputArgBlock, &inputArgLen))
									err = HTTPControllerGetContentType(taskID, contentType);
								flags |= kIsPost;	//isPost = true;
							}
							else
							{	if NOT(strcmp(method, "HEAD"))
									flags |= kOnlyHead;
								err = HTTPControllerGetSearchArgs(taskID, &inputArgBlock, &inputArgLen);
								//isPost = false;
							}
						#ifdef DUMP_FULL_REQUESTS
							cnt = _DumpFullRequest(taskID, headBlock, headBlockLen, method, inputArgBlock, inputArgLen);
						#endif
							if NOT(err)
							{	BEngineAPI_Run(taskID, serverName, filePath, serverDir, headBlock, headBlockLen, &inputArgBlock, inputArgLen, contentType, &resultText, &resultLen, nil, flags, uniqueID, sid, appName, nil);
								off = (prefixLengthInResult ? 4 : 0);
								FirstLine(GetPtr(resultText) + off, resultLen - off, response);
								err = HTTPControllerSendReply(taskID, resultText, resultLen);
							}
							if (inputArgBlock)
								DisposeBlock(&inputArgBlock);
							BEngineAPI_Idle(HTTPControllerLog, taskID);
						}
					}
					else	
						err = XError(kXLibError, ErrXFiles_FileNotFound);
					DisposeBlock(&physURL_block);
				}
			}
			DisposeBlock(&headBlock);
		}
	}


#ifdef __MAC_XLIB__
	Prof_OFF;
	Prof_DUMP;
#endif
#if CHECK_LEAKING
// Check for leaking (note here reuse serverName and serverDir to save stack space)
// logStr = log string
// serverDir = leakingStr
if (checkLeak)
{
XFileRef	saveLogRef;

	__XThreadsEnterCriticalSection();		// to redirect logging
	saveLogRef = gCurrentLogRefNum;
	gCurrentLogRefNum = gExtraLogRefNum;
	CheckLeaking(serverDir, &leaksPtr, &leaksHnd);
	if (*serverDir)
	{	HTTPControllerLog(0, "=------------------------------------------------------------------------------=");
		if ((leaksPtr < 0) || (leaksHnd < 0))
		{	CEquStr(serverDir, "Biferno GC: Some Resources were released");
			if (leaksPtr)
			{	CAddStr(serverDir, " (");
				CNumToString(leaksPtr, logStr);
				CAddStr(serverDir, logStr);
				CAddStr(serverDir, " ptrs)");
			}
			if (leaksHnd)
			{	CAddStr(serverDir, " (");
				CNumToString(leaksHnd, logStr);
				CAddStr(serverDir, logStr);
				CAddStr(serverDir, " handles)");
			}
		}
		#ifdef __UNIX_XLIB__
			#ifdef __UNIX_SERVER__
				// TRACE(serverDir);
				sprintf(logStr, "%s\n", serverDir);
				HTTPControllerLog(taskID, logStr);
				printf(logStr);
				//ex printf(logStr);
			#else
			{	BlockRef	bl;
				XErr		err2;
				long		tLen;
			
					sprintf(logStr, "<p> %s <p>", serverDir);
					tLen = CLen(logStr);
					bl = NewBlock(tLen + 1, &err);
					CopyBlock(GetPtr(bl), logStr, tLen + 1);
					err2 = HTTPControllerSendReply(taskID, bl, tLen);
			}
			#endif
		#elif __MAC_ACGI__
			if ((resultLen) > MACACGI_DIM_REQUIRES_SENDPARTIAL)
			{	// if 1 is ok because HTTPControllerSendReply will dispose it later
				if (leaksHnd > 1)
				{	SysBeep(3);
					//CDebugStr("SEND PARTIAL is active");
				}
			}
			else
			{	sprintf(logStr, "%s", serverDir);
				SysBeep(3);
				HTTPControllerLog(taskID, logStr);
			}
		#else
			sprintf(logStr, "%s", serverDir);
			#if __MAC_XLIB__
				SysBeep(3);
				HTTPControllerLog(taskID, logStr);
			#else	// Win32
				Beep(400, 100);
				#ifdef __WIN_ISAPI__
					HTTPControllerLog(taskID, logStr);
				#else
					HTTPControllerLog(0, logStr);
				#endif
			#endif
			
		#endif
	}
	gCurrentLogRefNum = saveLogRef;
	__XThreadsLeaveCriticalSection();
}
#endif
#ifdef DUMP_FULL_REQUESTS
	_DumpCnt(cnt);
#endif
return err;
}

//===========================================================================================
static XErr	Emergency(void *taskID)
{
	BEngineAPI_Emergency(taskID);
	
return noErr;
}

//===========================================================================================
static XErr	ServerStateChanged(void *taskID, long which, char *versStr)
{
XErr		err = noErr;
CStr255		aCStr, tStr, eNameStr, eMsg;
long		eNum;
XFileRef	saveLogRef;

	switch (which)
	{	
		case kFlush:
			err = BEngineAPI_Flush(HTTPControllerLog, taskID, 0);
			break;

		case kReload:
			err = BEngineAPI_Reload(HTTPControllerLog, taskID, 0);
			break;
		
		case kGetVersion:
			CEquStr(aCStr, "Biferno version: ");
			BEngineAPI_GetVersions(tStr, nil, nil);
			CAddStr(aCStr, tStr);
			if (versStr)
				CEquStr(versStr, aCStr);
			else
			{	CAddChar(aCStr, '\n');
				XThreadsEnterCriticalSection();	// to redirect log
				saveLogRef = gCurrentLogRefNum;
				gCurrentLogRefNum = gExtraLogRefNum;
				HTTPControllerLog(0, "=------------------------------------------------------------------------------=");
				HTTPControllerLog(taskID, aCStr);
				gCurrentLogRefNum = saveLogRef;
				XThreadsLeaveCriticalSection();
			}
			break;
		
		default:
			break;
	}
	
	if (err)
	{	XErrorGetDescr(err, eNameStr, eMsg);
		XErrorGetTypeValue(err, &eNum, nil);
		sprintf(aCStr, "Error %d: %s %s", (int)eNum, eNameStr, eMsg);
		HTTPControllerLog(taskID, aCStr);
	}

return err;
}

//===========================================================================================
static XErr	Idle(void *taskID)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif
return noErr;
}

//===========================================================================================
XErr	HTTPControllerRegister(HTTPControllerP	httpControllerP)
{
XErr		err = noErr;
CStr255		versionStr;
	
	CEquStr (httpControllerP->action, "BIFERNO");
	CEquStr (httpControllerP->pluginName, "Tabasoft Biferno");
	CEquStr (httpControllerP->suffix, ".bfr");	// Biferno script
	CEquStr (httpControllerP->mimeType, "text/html");
	BAPI_GetVersions(0, versionStr, nil, nil);
	CEquStr(httpControllerP->version, versionStr);
	CEquStr (httpControllerP->adminURL, "bifernoadmin");
	httpControllerP->Init = Init;
	httpControllerP->Run = Run;
	httpControllerP->Process = Process;
	httpControllerP->Idle = Idle;
	httpControllerP->Emergency = Emergency;
	httpControllerP->ServerStateChanged = ServerStateChanged;
	httpControllerP->ShutDown = ShutDown;
	httpControllerP->Suspend = Suspend;
	httpControllerP->Resume = Resume;
	httpControllerP->AccessControl = nil;
	CEquStr(httpControllerP->aboutStr, "Biferno - Tabasoft");
	
return err;
}
