/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: bifernosentinel.c,v 1.14 2006-10-09 10:41:57 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"
//#include 	"Helpers.h"
#include 	"HTTPMrgNet.h"
#include 	"HTTPMgr.h"
#include 	"XFilesUnixPrivate.h"

#include <signal.h>
#include <syslog.h>
#include <errno.h>
#include <pwd.h>
#include <stdlib.h>

//extern CStr255	globalErrStr;

#define	DEFAULT_CHECK_PERIOD	2	// minutes
#define	MAXFD					64
#define	PROGRAM_NAME			"bifernoctl"

static	XFileRef			gLogRefNum = 0;
static	XFilePath			gsBifernoServerLogFile, gsBifernoPidLogFile;

//unsigned long	_GetPIDNumber(char *pidFilePath);

//===========================================================================================
static XErr	_myPrintf(char *message)
{
CStr255		ctStr;
long		lenToWrite;
XErr		err = noErr;

	XCurrentDateTimeToString(ctStr, kComplete);
	CAddStr(ctStr, "\t");
	CAddStr(ctStr, message);
	CAddStr(ctStr, "\n");
	lenToWrite = CLen(ctStr);
	err = WriteXFile(gLogRefNum, ctStr, &lenToWrite);
	//printf(ctStr);
	
	
	/*
	printf(message);
	if (gLogRefNum)
		CStringToLog(gLogRefNum, message);
	*/
	return noErr;
}

//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *aCStr)
{
#pragma unused(taskID)
	return _myPrintf(aCStr);
}

//===========================================================================================
static void	_sentinelCallBack(char *message, long userData)
{
#pragma unused(userData)

	_myPrintf(message);
}

//===========================================================================================
static void	_killCallBack(unsigned long pid, long userData)
{
	kill(pid, SIGKILL);
}

//===========================================================================================
static XErr	_SendMessage(long message)
{
BlockRef	block, serverResponse;
long		dataToSendLen, serverResponseLen;
Ptr			p;
XErr		err = noErr;

	dataToSendLen = 8;
	if (block = NewBlockLocked(4 + dataToSendLen, &err, &p))
	{	// prefix length
		*(long*)p = XHostToNetwork(dataToSendLen);
		*(long*)(p + 4) = 0;
		*(long*)(p + 8) = message;
		if NOT(err = XClientCall("", 0L, block, 4 + dataToSendLen, &serverResponse, &serverResponseLen, BIFERNO_UNIX_FILE, nil, nil, 0, SENTINEL_BFR_TIMEOUT, EXPECT_PREFIXED))
			DisposeBlock(&serverResponse);
		DisposeBlock(&block);
	}

return err;
}

void	_Bash(char *bashStr, char *sysStr);

//===========================================================================================
static void	_StartBiferno(void)
{
CStr255		sysStr, scriptInit;

#ifdef __MACOSX__
	CEquStr(scriptInit, "/Library/StartupItems/Biferno/Biferno");
#else
	CEquStr(scriptInit, "/etc/init.d/biferno");
#endif
	if NOT(CheckPath(scriptInit, true))
	{	CAddStr(scriptInit, " start\n");
		_Bash(scriptInit, sysStr);
	}
	else
		_Bash("bifernod\n", sysStr);
}

//===========================================================================================
/*static void	_Bash(char *bashStr, char *sysStr)
{
FILE	*p;
size_t	size;
	
	XThreadsEnterCriticalSection();
	*sysStr = 0;
	if (p = popen(bashStr, "r"))
	{	size = fread(sysStr, 1, 250, p);
		if (size >= 0)
			sysStr[size-1] = 0;	// per il \n finale
		else
			sprintf(sysStr, "Error on fread(): %d (%s)", ferror(p), strerror());
		if (pclose(p))
			sprintf(sysStr, "Error on pclose(): %s", strerror());
	}
	else
		sprintf(sysStr, "Error on popen(): %s", strerror());
	XThreadsLeaveCriticalSection();
}*/

//===========================================================================================
static void	_HandleErr(XErr theError)
{
	if (theError)
	{	CStr255	errStr;

		XErrorGetDescr(theError, errStr, nil);
		CAddStr(errStr, "\n");
		_myPrintf(errStr);
		
		/*if (*globalErrStr)
		{	_myPrintf(globalErrStr);
			_myPrintf("\n");
		}*/
	}
}

//===========================================================================================
static void	_DaemonInit(char *pname, char *bifernohomePath)
{
pid_t		pid;
int			i;
//CStr255		appFolderPath;

	if ((pid = fork()) != 0)
		exit(0);		// parent terminates
	setsid();
	signal(SIGHUP, SIG_IGN);
	if ((pid = fork()) != 0)
		exit(0);		// 1st child terminates
		
	chdir(bifernohomePath);
	umask(0);
	for (i = 0; i < MAXFD; i++)
		close(i);
	openlog(pname, LOG_PID, LOG_DAEMON);
}

//===========================================================================================
static XErr	_CheckBiferno(void)
{
XErr		err = noErr;
//CStr255		sysStr;

	_myPrintf("Checking Biferno...");
	err = _SendMessage(kCheck);
	if ((err == ECONNREFUSED) || (err == ENOENT))
	{	
		SentinelCheck(gsBifernoServerLogFile, gsBifernoPidLogFile, _sentinelCallBack, 0, _killCallBack, 0);
		//_Bash("bifernod", sysStr);
		_StartBiferno();
		XDelay(60L * 5L);		// wait 5 seconds
		_myPrintf("...Biferno launched");
		err = noErr;
	}
	else
		_myPrintf("...Biferno is running");
	
return err;
}

//===========================================================================================
static void	_Process(long socketRef, BlockRef block, long totLen, long userData)
{
XErr		err = noErr;
CStr255		aCStr;
long		tLen;
BlockRef	responseBlock;
Ptr			p;

	XThreadsEnterCriticalSection();
	_CheckBiferno();
	CEquStr(aCStr, "ok, Biferno checked");
	tLen = CLen(aCStr);
	if (responseBlock = NewBlockLocked(tLen + sizeof(long), &err, &p))
	{	*(long*)p = XHostToNetwork(tLen);	// prefixed final length
		CopyBlock(p + sizeof(long), aCStr, tLen);
		_myPrintf("...respond to client");
		err = XServerSendToClient(socketRef, responseBlock, tLen + sizeof(long));
		DisposeBlock(&responseBlock);
	}
	XThreadsLeaveCriticalSection();
}

#pragma mark-
//===========================================================================================
static void	_ClosePID(XFileRef	xrefNum)
{
	CloseXFile(&xrefNum);
	DeletePID(PROGRAM_NAME);
}

//===========================================================================================
static void	_PidName(char *pidPath, char *bifernoHome)
{
char		*strP;

	//if (strP = getenv("BIFERNOHOME"))
	strP = bifernoHome;
	CEquStr(pidPath, strP);
	if (strP[CLen(strP) - 1] != '/')
		CAddChar(pidPath, '/');
	CAddStr(pidPath, PROGRAM_NAME);
	CAddStr(pidPath, ".pid");
	//}
	//else
	//	*pidPath = 0;
}

//===========================================================================================
static Boolean _CanStart(XFileRef *xrefNumP, Boolean writePID, char *bifernoHome)
{
CStr255		aCStr, pidPath;
Boolean		res = false;
XFileRef	xrefNum;
XErr		err = noErr;
long		openMode, tLen;

	_PidName(pidPath, bifernoHome);
	if (writePID)
		openMode = CREATE_FILE_ALWAYS;
	else
		openMode = OPEN_FILE_ALWAYS;
	if NOT(err = OpenXFile(pidPath, openMode, READ_WRITE_PERM, true, &xrefNum))
	{	if NOT(err = LockXFile(xrefNum, 0, -1, false))
		{	if (writePID)
			{	CNumToString(getpid(), aCStr);
				tLen = CLen(aCStr);
				if NOT(err = SetXFPos(xrefNum, FROM_START, 0))
				{	if NOT(err = WriteXFile(xrefNum, aCStr, &tLen))
					{	if NOT(err = SetXEOF(xrefNum, tLen))
							err = FlushXFile(xrefNum);
					}
				}
			}
			res = true;
		}
		if (xrefNumP)
			*xrefNumP = xrefNum;
		else
			CloseXFile(&xrefNum);
	}

return res;
}

//===========================================================================================
int SentinelCommand(char *command, char *bifernoHomeStr)
{
short				err = noErr;
	CStr255				logFilePath, aCStr;	//, tStr;
//unsigned long		lastTicks;
//long				aLong;
unsigned long		pid;
XFileRef			pidRefNum;
CStr255				pidPath;
CStr255				sysStr;
//char				*bifHomeP;
	
	if NOT(CCompareStrings_cs(command, "start"))
	{	printf("\n");
		printf("starting bifernoctl sentinel process ...\n");
		/*if NOT(bifHomeP = getenv("BIFERNOHOME"))
		{	printf("Error: BIFERNOHOME is not defined\n");
			exit(1);
		}
		else
			CEquStr(bifernoHomeStr, bifHomeP);
		*/
		if (_CanStart(nil, false, bifernoHomeStr))
		{	printf("... ok\n");
			
			_DaemonInit(PROGRAM_NAME, bifernoHomeStr);
			_CanStart(&pidRefNum, true, bifernoHomeStr);
			if NOT(err = XInit(bifernoHomeStr/*getenv("BIFERNOHOME")*/))
			{	if NOT(err = XGetApplicationFolderPath(logFilePath))
				{	CEquStr(gsBifernoServerLogFile, logFilePath);
					CAddStr(gsBifernoServerLogFile, "BifernoServer.log");
					CEquStr(gsBifernoPidLogFile, logFilePath);
					CAddStr(gsBifernoPidLogFile, BIFERNO_PID_FILE);
					CAddStr(logFilePath, "bifernosentinel.log");
					if NOT(err = InitLog(logFilePath, &gLogRefNum))
					{	_myPrintf("biferno sentinel: accepting connections...");
						if (err = XServerLoop(0, 12, _Process, 0L, true, true, BIFERNOSENTINEL_UNIX_FILE, aCStr))
						{	_myPrintf(aCStr);
							_myPrintf("\n");
						}
						if (gLogRefNum)
							EndLog(&gLogRefNum);
					}
				}
				XEnd(0);
			}
			_ClosePID(pidRefNum);
		}
		else
			printf("... failed (already running)\n");
	}
	else if NOT(CCompareStrings_cs(command, "stop"))
	{	printf("\n");
		_PidName(pidPath, bifernoHomeStr);
		if (pid = GetPIDNumber(pidPath))
		{	sprintf(pidPath, "kill %d", pid);
			_Bash(pidPath, sysStr);
			if NOT(*sysStr)
				printf("ok, bifernoctl sentinel process stopped\n");
		}
		else
			printf("no pid available, use kill command\n");
	}
	else
		_PrintUsage();

return err;
}


