/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Flower.c,v 1.33 2008-11-27 15:27:49 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Param.h"
#include "Entity.h"
#include "BfrParser.h"
#include "Load.h"
#include "BifernoErrors.h"
#include "Classes.h"
#include "Volatile.h"
#include "Run.h"

extern 	DispatcherData	gsDispatcherData;
extern	XErr			gMemoryFullError;
extern	BAPIErrorRecord	gBifernoErrorsRec[];

#include <stdio.h>
#include <string.h>

//===========================================================================================
static XErr _UpdateBreaksBra(BifernoRecP bRecP, long continueOffset, long breakOffset)
{
long	opcodeOff, totBreaks = bRecP->totBreakOffset, *breakOffsetP;
XErr	err = noErr;

	if (totBreaks)
	{	breakOffsetP = &bRecP->breakOffset[0];
		do {
			opcodeOff = *breakOffsetP++;
			if (opcodeOff > 0)
				err = BIC_BranchUpdateOffset((long)bRecP, opcodeOff, breakOffset);
			else
				err = BIC_BranchUpdateOffset((long)bRecP, -opcodeOff, continueOffset);
		} while (--totBreaks);
	}
	
return err;
}

//===========================================================================================
// skip TAB CR LF Comments CloseTags
static XErr	_SkipBeforeBlock(BifernoRecP bRecP, Ptr *thePPtr, long *lenP)	
{
Ptr		tempP;
long	len, *lineP = &bRecP->currentCtx.currentLine;
XErr	err = noErr;

	tempP = *thePPtr;
	len = *lenP;
	if (len > 0)
	{	do {	
			SkipSpaceAndTabCRLF(&tempP, &len, lineP);
			if (IsEndTagExt(bRecP, &tempP, &len, &err))
			{	if NOT(err)
					SkipSpaceAndTabCRLF(&tempP, &len, lineP);
				else
					break;
			}
			else if (IsCommentExt(bRecP, &tempP, &len, nil, nil, false))
				SkipSpaceAndTabCRLF(&tempP, &len, lineP);
			else
				break;
		} while (len > 0);
		*thePPtr = tempP;
		*lenP = len;
	}

return err;
}

/*XErr	_Check(long api_data, char *opt)
{
Byte		errRec[1440];
long		tLen;
XErr		err = noErr;
Boolean		exists;
ObjRecord	errRef;

	printf(opt);
	printf("\n");
	BAPI_IsVariableDefined(api_data, "err", GLOBAL, &exists, OBJREF_P(&errRef));
	if (exists)
	{	tLen = 1440;
		if NOT(err = BAPI_ReadObj(api_data, &errRef, (Ptr)&errRec, &tLen, 0, nil))
			printf("%d\n", tLen);
	}
	else
		printf("err is undef\n");
}
*/
//===========================================================================================
static XErr 	_Condition(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean notMode, Boolean *resultP, char lastCharWanted, Boolean donAcceptEmpty, long *opcodeOffsetP, long brOffset, Boolean negativeBranch, Boolean allowSemicolon, Boolean skipForced)
{
Ptr				tempP;
long			len;//, flags = 0;
ParameterRec	paramVar, *paramP;
XErr			err = noErr;
Byte			lastChar;
Boolean			isDefault;

	tempP = *oldFilePPtr;
	len = *lenP;

	if (skipForced)
		resultP = nil;
	if (resultP)
	{	*resultP = true;
		paramP = &paramVar;
	}
	else if COMPILING(api_data)
		paramP = &paramVar;
	else
		paramP = nil;
	if (paramP)
		err = GetOneParameter(api_data, &tempP, &len, &lastChar, paramP, &isDefault, donAcceptEmpty, true, 0, nil, 0);
	else
		SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, 0L, false, false);
	if NOT(err)
	{	if (allowSemicolon && len && (*tempP == ';'))
		{	tempP++;
			len--;
			if (lastCharWanted != lastChar/*ex ';'*/)
				err = XError(kBAPI_Error, Err_BadSyntax);
		}
		else if (lastChar != lastCharWanted)
			err = XError(kBAPI_Error, Err_BadSyntax);
		if (NOT(err) && (resultP || COMPILING(api_data)))
		{	if COMPILING(api_data)
			{	if (negativeBranch)
					notMode = NOT(notMode);
				if NOT(err = BIC_Branch(api_data, notMode, false, OBJRECORD_P(&paramP->objRef), brOffset, opcodeOffsetP, false))
				{	if (resultP)
						*resultP = true;
				}
			}
			else
			{	if (isDefault)
					*resultP = true;
				else
					err = BAPI_ObjToBoolean(api_data, &paramP->objRef, resultP, kExplicitTypeCast);
				if (notMode)
					*resultP = NOT(*resultP);
			}
		}
	}
	/*if (len && (*tempP == ';'))
	{	tempP++;
		len--;
	}*/

if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_ForStart(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean execute)
{
Ptr				tempP;
long			saveLine, len;
Byte			lastChar;
ParameterRec	paramVar, *paramP;
XErr			err = noErr;
BifernoRecP		bRunP = (BifernoRecP)api_data;

	tempP = *oldFilePPtr;
	len = *lenP;
	if (len && (*tempP == '('))
	{	tempP++;
		len--;
	}
	else
		return XError(kBAPI_Error, Err_RoundBracketExpected);

	if (execute)
		paramP = &paramVar;
	else
		paramP = nil;
	lastChar = 0;
	saveLine = bRunP->currentCtx.currentLine;
	while (((lastChar != ';') && (lastChar != ')')) && (len > 0) && NOT(err))
	{	if (paramP)
			err = GetOneParameter(api_data, &tempP, &len, &lastChar, paramP, nil, false, true, 0, nil, 0);
		else
			SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, 0L, false, false);
		if NOT(err)
		{	if (lastChar != ',')
				break;
		}
	}
	if NOT(err)
	{	/*if (len && (*tempP == ';'))
		{	tempP++;
			len--;
		}
		else
		*/
		if (lastChar != ';')
			err = XError(kBAPI_Error, Err_BadSyntax);
		//if (lastChar != ';')// && (lastChar != ')'))
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
else
	bRunP->currentCtx.currentLine = saveLine;
return err;
}

//===========================================================================================
static XErr 	_ForIncrement(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean execute, Boolean wantEndPar)
{
Ptr				tempP;
long			saveLine, len;
Byte			lastChar;
ParameterRec	paramVar, *paramP;
XErr			err = noErr;
BifernoRecP		bRunP = (BifernoRecP)api_data;

	tempP = *oldFilePPtr;
	len = *lenP;

	if (execute)
		paramP = &paramVar;
	else
		paramP = nil;
	lastChar = 0;
	saveLine = bRunP->currentCtx.currentLine;
	while ((lastChar != ')') && (len > 0) && NOT(err))
	{	if (paramP)
			err = GetOneParameter(api_data, &tempP, &len, &lastChar, paramP, nil, false, true, 0, nil, 0);
		else
			SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, 0L, false, false);
		if NOT(err)
		{	if (lastChar != ',')
				break;
		}
	}
	if NOT(err)
	{	if (wantEndPar && (lastChar != ')'))
			err = XError(kBAPI_Error, Err_BadSyntax);
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
else
	bRunP->currentCtx.currentLine = saveLine;
return err;
}

//===========================================================================================
static Boolean	_SkipUntilCharExt(BifernoRecP bRecP, Ptr *oldFilePP, long *lenP, int charUntil, long *lineP, Boolean onThisLine)
{
Ptr			oldFileP;
long		len;
Boolean		newLine, inDoubleApString, inSingleApString, found = false;
int			ch, back_slashCnt;

	oldFileP = *oldFilePP;
	if ((*lenP > 0) && (*oldFileP != charUntil))
	{	len = *lenP;
		back_slashCnt = 0;
		inSingleApString = inDoubleApString = false;
		do {	
			if NOT(IsCommentExt(bRecP, &oldFileP, &len, &newLine, nil, false))
			{	ch = len ? *oldFileP : 0;
				if (ch == '\\')
					back_slashCnt++;
				else if ((ch != '\"') && (ch != '\''))
					back_slashCnt = 0;
				if (ch == '\"')
				{	if (NOT(back_slashCnt & 1) && NOT(inSingleApString))
						inDoubleApString = inDoubleApString ? false : true;
					back_slashCnt = 0;
				}
				else if (ch == '\'')
				{	if (NOT(back_slashCnt & 1) && NOT(inDoubleApString))
						inSingleApString = inSingleApString ? false : true;
					back_slashCnt = 0;
				}
				if (newLine || IsNewLine(oldFileP, len, nil))
				{	if (lineP)
						(*lineP)++;
					if (onThisLine)
						break;
				}
				if ((ch == charUntil) && NOT(inSingleApString) && NOT(inDoubleApString))
				{	found = true;
					break;
				}
				oldFileP++;
				len--;
			}
		} while (len > 0);
		*oldFilePP = oldFileP;
		*lenP = len;
	}
	
return found;
}


//===========================================================================================
static XErr _CheckIfGoto(BifernoRecP bRecP, Ptr *oldFilePPtr, long *lenP, Ptr blockP, long blockMaxLen, long flags, long saveLine, long curGraphs, Boolean *foundP)
{	
XErr		err = noErr;
Ptr			tempP;
long		len;

	tempP = *oldFilePPtr;
	len = *lenP;
	*foundP = false;
	if (*bRecP->curLabelName)
	{	if NOT(err = GotoWasFound((long)bRecP, &tempP, &len, blockP, blockMaxLen, curGraphs, flags, saveLine, false))
		{	if (bRecP->_break)
				;//bRecP->_break = false;
			else
				*foundP = true;	// found label in this loop
		}
	}

if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_GetCaseValue(BifernoRecP bRecP, Ptr *oldFilePPtr, long *lenP, ParameterRec *paramP)
{
XErr		err = noErr;
Ptr			tempP;
long		len;
Byte		lastChar;
//Boolean		saveInCase;

	tempP = *oldFilePPtr;
	len = *lenP;
	//saveInCase = bRecP->inCase;
	//bRecP->inCase = true;
	err = GetOneParameter((long)bRecP, &tempP, &len, &lastChar, paramP, nil, true, true, kInCase, nil, 0);
	//bRecP->inCase = saveInCase;
	
	/*if NOT(IsText(api_data, &tempP, &len, objRefP, &err))
	{	*constrName = 0;
		if (IsConstructor(api_data, &tempP, &len, constrName, false, &constructor, false, &isSuper, &constrErr) && NOT(constrErr))
		{	if NOT(err = DoConstructor(api_data, constructor, &tempP, &len, false, false, objRefP, nil, isSuper))
			{	if (NOT(IS_IMMEDIATE_P(objRefP)) && (objRefP->type != CONSTANT))
					err = XError(kBAPI_Error, Err_IllegalConstantExpression);
			}
		}
		else
			err = XError(kBAPI_Error, Err_IllegalConstantExpression);
	}*/

if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}		
return err;
}

//===========================================================================================
static XErr 	_CaseOfSwitch(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean skipForced, Boolean *switchMatchedP, long *switchFlagP)
{
Ptr				saveP, tempP;
long			tLen, saveLen, flags, len;
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			match;
//char			lastChar;
ObjRecord		resultObjRef;
ParameterRec	param;

	if (skipForced || NOT(bRecP->currentCtx.switchObject.id))
		return XError(kBAPI_Error, Err_IllegalFlowControl);

	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTab(&tempP, &len);
		
	saveP = tempP;
	saveLen = len;
	if NOT(_SkipUntilCharExt(bRecP, &tempP, &len, ':', nil, true))
		return XError(kBAPI_Error, Err_BadSyntax);
	tLen = saveLen - len;
	if (len)
	{	tempP++;
		len--;
	}
	else
		return XError(kBAPI_Error, Err_BadSyntax);
	if NOT(err)
	{	if (*switchMatchedP)
			match = true;
		else
		{	if NOT(err = _GetCaseValue(bRecP, &saveP, &tLen, &param))
			{	if NOT(err = CL_ExecuteOperation(api_data, &bRecP->currentCtx.switchObject, OBJRECORD_P(&param.objRef), EVAL_EQUA, &resultObjRef))
					err = BAPI_ObjToBoolean(api_data, OBJREF_P(&resultObjRef), &match, kExplicitTypeCast);
			}
		}
		if NOT(err)
		{	flags = 0;
			if (match)
			{	*switchMatchedP = true;
				err = ProcessBlock(api_data, &tempP, &len, flags);
			}
			else
				SkipBlock(api_data, &tempP, &len, flags, nil, switchFlagP);
		}
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BifernoGetFile(BifernoRecP bRecP, XFilePathPtr filePath, CacheResult *cacheResP, Boolean neverCache)
{
XErr	err = noErr;
	
	if NOT(err = CFGetFile(filePath, cacheResP))
	{	if (neverCache || bRecP->mainPathContainsBifernoAdmin)
			cacheResP->dontCache = true;
		else
			cacheResP->dontCache = NOT(bRecP->application.cacheActive);
	}
	
return err;
}

//===========================================================================================
XErr	GotoWasFound(long api_data, Ptr *oldFilePPtr, long *lenP, Ptr startP, long startLen, long curGraphs, long flags, long saveLine, Boolean fromMain)
{
Ptr				save2P, saveP, tempP;
long			save2Line, saveCurGraphs, save2Len, saveLen, tempLen, len;
BifernoRecP		bRecP = (BifernoRecP)api_data;
XErr			err = noErr;

	tempP = saveP = *oldFilePPtr;
	len = saveLen = *lenP;
	while (*bRecP->curLabelName && len && NOT(err))
	{	// search down
		if (fromMain)
		{	while (*bRecP->curLabelName && len)
			{
				err = SkipBlock(api_data, &tempP, &len, flags, bRecP->curLabelName, nil);
			} 
		}
		else if NOT(curGraphs)
			err = SkipBlock(api_data, &tempP, &len, flags, bRecP->curLabelName, nil);
		else
		{	while ((bRecP->currentCtx.tot_graf_pars != curGraphs) && NOT(err) && *bRecP->curLabelName)
			{
				err = SkipBlock(api_data, &tempP, &len, flags, bRecP->curLabelName, nil);
			}
		}
		if NOT(err)		// look after
		{	if (*bRecP->curLabelName && startP)
			{	// save point1 (were we arrived)
				save2P = tempP;
				save2Len = len;
				saveCurGraphs = bRecP->currentCtx.tot_graf_pars;
				save2Line = bRecP->currentCtx.currentLine;
				
				// search from start of block until point1
				tempP = startP;
				len = startLen;
				bRecP->currentCtx.tot_graf_pars = (short)curGraphs;
				bRecP->currentCtx.currentLine = saveLine;
				tempLen = saveP - startP;	// search only until point1
				err = SkipBlock(api_data, &tempP, &tempLen, flags, bRecP->curLabelName, nil);	// look before
			}	
			if NOT(err)
			{	if (*bRecP->curLabelName)		// didn't find it
				{	tempP = save2P;
					len = save2Len;
					bRecP->currentCtx.tot_graf_pars = (short)saveCurGraphs;
					bRecP->currentCtx.currentLine = save2Line;
					break;
				}
				else if (len)
					len = startLen - (tempP - startP);
			}
		}
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
/*XErr	ProcessBlock(long api_data, Ptr *textPPtr, long *lenP, long flags)
{
XErr			err = noErr;
Ptr				pToAdd, textP;
long			diff, saveCurrentLine, retSize, tot_graf_pars, lToAdd, len;
BifernoRecP 	bRecP;
Boolean			blockDone;

	if NOT(len = *lenP)
		return noErr;
		
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	// Yields and abort/timeout checks
	if (err = BifernoYield(&bRecP->lastYield))
		return err;
	bRecP->finalTicks = XGetTicks();
	diff = bRecP->finalTicks - bRecP->startTicks;
	if (bRecP->startTicks && bRecP->timeOut && ((unsigned long)diff > bRecP->timeOut))
		return XError(kBAPI_Error, Err_Timeout);

	if (_BifernoCheckStackSpace(bRecP))
	{	_ProcessBlock_Params	params;
		unsigned long			threadID;
		unsigned long			saveStackPoint;
	#ifdef JAVA_ENABLED
		long					saveEnvP;
	#endif
		
		params.api_data = api_data;
		params.textP = *textPPtr;
		params.len = *lenP;
		params.flags = flags;
	#ifdef JAVA_ENABLED
		saveEnvP = bRecP->theEnvP;
		bRecP->theEnvP = 0L;	// to reload
	#endif
		saveStackPoint = bRecP->stackBasePointer;
		bRecP->stackBasePointer = 0;
		bRecP->curThreads++;
		bRecP->maxThreads++;
		err = XNewThread(&threadID, kWaitEndOfThread, _ProcessBlock_Func, 64L * 1024L, (void*)&params);
		bRecP->curThreads--;
		bRecP->stackBasePointer = saveStackPoint;
	#ifdef JAVA_ENABLED
		bRecP->theEnvP = saveEnvP;
	#endif
		if NOT(err)
		{	*textPPtr = params.textP;
			*lenP = params.len;
		}
		return err;
	}
	
	//if NOT(bRecP->noResetVolatile)
	ResetVolatileList(bRecP);
	
	saveCurrentLine = bRecP->currentCtx.currentLine;
	textP = *textPPtr;
	if (len && bRecP->inTag && (*textP == '{'))
	{	textP++;
		len--;
		tot_graf_pars = bRecP->tot_graf_pars;
		if (tot_graf_pars < MAX_PARCHECKS)
			bRecP->toBalance[tot_graf_pars] = (short)bRecP->currentLine;
		bRecP->tot_graf_pars++;
	}	
	if (NOT(err) && len)
	{	pToAdd = textP;
		lToAdd = 0;
		blockDone = false;
		do {
			if (bRecP->inTag || IsInitTagExt(bRecP, &textP, &len))
			{	if NOT(err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false))
				{	err = _ProcessBisBlock(api_data, &textP, &len, flags, &blockDone);
					pToAdd = textP;
					lToAdd = 0;
				}
			}
			else if (NOT(bRecP->inTag) && IsEndTag(textP, len))
			{	if (bRecP->inOtherTag)
				{	bRecP->inOtherTag--;
					goto normalText;
				}
				else
					err = XError(kBAPI_Error, Err_BadSyntax);
			}
			else
			{	
			normalText:
				if (len && (*textP == '$'))
				{	if ((len > 1) && (*(textP+1) == '$'))
					{	textP++;
						len--;
						lToAdd++;
						if NOT(err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false))
						{	textP++;
							len--;
							pToAdd = textP;
							lToAdd = 0;
						}
					}
					else if NOT(err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false))
					{
					Byte	lastChar;
					Ptr		saveP;
					long	saveLen;
					
						saveP = textP;
						saveLen = len;
						textP++;
						len--;
						SkipOneParameter(&textP, &len, &lastChar, kStopOnDollar + kStopOnCR, true);
						if ((lastChar == '$'))
						{	saveLen = (saveLen - len);
							err = DoPrint(api_data, &saveP, &saveLen, true);
						}
						else
							err = BAPI_StandardOutput(api_data, saveP, (saveLen - len), false);
						// ex if (err == XError(kBAPI_Error, Err_BAPI_DollarNotFound))
						if (err)
							err = CheckIfResume(api_data, err, &textP, &len);
						if NOT(err)
						{	pToAdd = textP;
							lToAdd = 0;
						}
						continue;
					}
				}
				if NOT(err)
				{	if (IsNewLine(textP, len, &retSize))
					{	lToAdd += retSize;			
						textP += retSize;
						len -= retSize;
						bRecP->currentLine++;
						if (flags & kOnlyOneStatement)
						{	if (bRecP->currentLine == (saveCurrentLine + 1))
								blockDone = true;
						}
					}
					else if (len)
					{	lToAdd++;			
						textP++;
						len--;
					}
				}
			}
		} while (NOT(err) && (len > 0) && NOT(bRecP->_exit) && NOT(bRecP->_stop) && NOT(bRecP->_return) && NOT(bRecP->_break) && NOT(bRecP->_continue) && NOT(blockDone));
	}
	//if (bRecP && bRecP->stopEval)
	//	bRecP->stopEval = false;
	if NOT(err)
	{	err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false);
		*lenP = len;
		*textPPtr = textP;
	}

return err;
}*/

//===========================================================================================
void	ProcessMain(long api_data, Ptr textP, long textLen, Boolean checkPars, XErr *theErrorP)
{
XErr			err = noErr;
BifernoRecP 	bRecP;
Ptr				saveTextP;
long			saveLen;

	if NOT(bRecP = (BifernoRecP)api_data)
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
	{	bRecP->currentCtx.currentLine++;
		saveTextP = textP;
		saveLen = textLen;
		while ((textLen > 0) && NOT(err))
		{	if (bRecP->_exit || bRecP->currentCtx._stop)
			{	bRecP->currentCtx.tot_graf_pars = 0;
				break;
			}
			else
			{	if NOT(err = ProcessBlock(api_data, &textP, &textLen, 0))
				{	if (*bRecP->curLabelName)
					{	if NOT(err = GotoWasFound(api_data, &textP, &textLen, saveTextP, saveLen, 0, 0, 1, true))
						{	if (bRecP->_break)
							{	NewMsgRecord(api_data, kLABEL_BAD, bRecP->curLabelName, 0, 0);
								//CStringToErrMessage(api_data, bRecP->curLabelName);
								err = XError(kBAPI_Error, Err_LabelNotFound);
								if NOT(bRecP->criticalMem)
									err = CheckIfResume(api_data, err, &textP, &textLen);
								if (err)
									break;
							}
						}
					}
				}
				if (bRecP->_exit || bRecP->currentCtx._stop)
					bRecP->currentCtx.tot_graf_pars = 0;
			}
		}
		if (NOT(err) && checkPars && (bRecP->currentCtx.tot_graf_pars > 0))
		{	if (bRecP->currentCtx.tot_graf_pars < MAX_PARCHECKS)
				bRecP->currentCtx.currentLine = bRecP->currentCtx.toBalance[bRecP->currentCtx.tot_graf_pars-1];
			err = XError(kBAPI_Error, Err_CurlyBracketExpected);
			if NOT(bRecP->criticalMem)
				err = CheckIfResume(api_data, err, &textP, &textLen);
		}
		/*if NOT(err)
		{	*textPPtr = textP;
			*textLenP = textLen;
		}*/
	}

	if (err)
	{	//XErr	err2 = noErr;
	
		if (theErrorP)
			*theErrorP = err;
		//if NOT(*bRecP->errCacheFileRec.filePath)	// already set?
		//	bRecP->errCacheFileRec = bRecP->curFile;
	}
}

//===========================================================================================
XErr	CheckIfResume(long api_data, XErr theError, Ptr *expressPPtr, long *expressLenP)
{
BifernoRec	*bRecP;
XErr		err = noErr;
ObjRecord	errObjRef;
Boolean		canResume;

	if (bRecP = (BifernoRecP)api_data)
	{	if (theError && NOT(bRecP->lastClassIDErrorCalled) && bRecP->methodInExecutionClass)
			bRecP->lastClassIDErrorCalled = bRecP->methodInExecutionClass;
		INVAL(errObjRef);
		if NOT(err = UpdateErrObject(api_data, theError, &errObjRef, &canResume))
		{	if (bRecP->onErrorResume && canResume && NOT(bRecP->inDebugPage))
			{	theError = err;
				if (NOT(err) && expressPPtr && expressLenP)
					err = SkipBisBlock(api_data, expressPPtr, expressLenP, kOnlyOneStatement, nil, nil, nil/*, nil, nil*/);
				if (*bRecP->onErrorFunc)
				{	ParameterRec	paramVars;
					long			saveOnErrorResume;
					
					paramVars.objRef = OBJREF(errObjRef);
					*paramVars.name = 0;
					
					saveOnErrorResume = bRecP->onErrorResume;
					bRecP->onErrorResume = 0;
					if NOT(err = BAPI_ExecuteFunction(api_data, &paramVars, 1, bRecP->onErrorFunc, nil))
						bRecP->onErrorResume = saveOnErrorResume;
				}
				if NOT(err)
				{	*bRecP->class_error_note = 0;
					bRecP->lastClassIDErrorCalled = 0;
					// bRecP->currentCtx.processing = kNone;
					BAPI_ResetError(api_data);
				}
			}
			else
				err = theError;
		}
	}
	else
		err = theError;

return err;
}

//===========================================================================================
XErr	EvalWithResume(long api_data, Ptr *expressPPtr, long *expressLenP, long flags, ObjRecordP resultVarRecP)
{
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
	
	if (*expressLenP > 0)
	{	flags |= kStopOnCR;
		err = Eval(api_data, 0, 0, expressPPtr, expressLenP, flags, resultVarRecP);
	}
	else
		err = noErr;

	if NOT(COMPILING(api_data))
	{	if (bRecP && (err || /*(err = bRecP->exceptionError) ||*/ (err = gMemoryFullError)) && NOT(bRecP->_suspendResume))
		{	bRecP->criticalMem = (err == XError(kXLibError, ErrXMemory_Full)) || (err == XError(kBAPI_Error, Err_MemoryFull));
			if NOT(bRecP->criticalMem)
				err = CheckIfResume(api_data, err, expressPPtr, expressLenP);
		}
	}
	
return err;
}

//===========================================================================================
XErr 	IncludeFile(long api_data, XFilePathPtr filePath, Boolean neverCache, char *executeAsFunctionWithName)
{
XErr			err = noErr, err2 = noErr;
CacheResult		cacheToRelease, saveCurFile;
BifernoRecP		bRecP = (BifernoRecP)api_data;
CStr255			saveCurBasePath;
CallerCtx		saveCurrentCtx;
Boolean			moreStack;
	
	if (bRecP->totIncludes++ >= MAX_INCLUDES)
		return XError(kBAPI_Error, Err_TooManyIncludes);
	if NOT(err = BifernoGetFile(bRecP, filePath, &cacheToRelease, neverCache))
	{	
	char			*tP;
	Ptr				textP;
	long			textLen;
	
		// save context
		saveCurrentCtx = bRecP->currentCtx;

		// replace context
		CEquStr(bRecP->currentCtx.currentExecFile, filePath);
		bRecP->currentCtx.bisFunctionInitLine = 0;
		bRecP->currentCtx.processing = kProcessingInclude;
		bRecP->currentCtx.currentLine = 0;
		bRecP->currentCtx.inTag = false;
		bRecP->currentCtx.lastMultiStrStart = bRecP->currentCtx.lastMultiStrEnd = 0;
		bRecP->currentCtx.tot_graf_pars = 0;
		bRecP->currentCtx.lastLoadLine = 0;
		bRecP->currentCtx._stop = false;

		// curFile
		saveCurFile = bRecP->curFile;
		bRecP->curFile = cacheToRelease;

		// curBasePath
		CEquStr(saveCurBasePath, bRecP->curBasePath);
		CEquStr(bRecP->curBasePath, filePath);
		if (tP = strrchr(bRecP->curBasePath, '/'))
			bRecP->curBasePath[tP - bRecP->curBasePath + 1] = 0;
		else
			bRecP->curBasePath[0] = 0;
		
		// get source code
		textP = GetPtr(cacheToRelease.fileData);
		textLen = cacheToRelease.fileSize;
		
		// trick to execute a file as a function call
		if (executeAsFunctionWithName && *executeAsFunctionWithName)
		{
		CStr255		virtualProto;
		long		saveScope, virtualProtoLen;
		BlockRef	virtualFileBlock;
		Ptr			virtualCodeP;
		
			bRecP->currentCtx.currentLine++;
			sprintf(virtualProto, "%s(){?>", DEBUG_FUNCTION_NAME);
			virtualProtoLen = CLen(virtualProto);
			if (virtualFileBlock = NewBlock(virtualProtoLen + textLen + 3, &err, &virtualCodeP))
			{	CopyBlock(virtualCodeP, virtualProto, virtualProtoLen);
				CopyBlock(virtualCodeP + virtualProtoLen, textP, textLen);
				CopyBlock(virtualCodeP + virtualProtoLen + textLen, "<?}", 3);
				textLen += virtualProtoLen + 3;
				saveScope = bRecP->lastScope;
				bRecP->lastScope = LOCAL;
				err = LoadBifernoFunction(api_data, &virtualCodeP, &textLen, nil);
				bRecP->lastScope = saveScope;
				if NOT(err)
				{	bRecP->currentCtx.currentLine = 1;
					if (err = BAPI_ExecuteFunction(api_data, nil, 0, DEBUG_FUNCTION_NAME, nil))
						;	//RemoveLastStackItem(bRecP);
				}
				DisposeBlock(&virtualFileBlock);
			}
			moreStack = false;
		}
		else
		{	
			BfrMoreIncludeStack(bRecP, saveCurrentCtx.currentExecFile, saveCurrentCtx.currentLine);
			moreStack = true;
			ProcessMain(api_data, textP, textLen, true, &err);
		}
		
		if (err)
			cacheToRelease = saveCurFile;		// remain on current
		else
		{	
			if (moreStack)
				BfrLessIncludeStack(bRecP);
			CEquStr(bRecP->curBasePath, saveCurBasePath);
			cacheToRelease.dontCache = bRecP->curFile.dontCache;
			bRecP->curFile = saveCurFile;
			bRecP->currentCtx = saveCurrentCtx;
		}			

		if (*cacheToRelease.filePath)
		{	SetScriptCache(bRecP, &cacheToRelease);
			if (cacheToRelease.fileData)
				err2 = CFReleaseFile(&cacheToRelease, 0);
			if (NOT(err) && err2)
				err = err2;
		}
	}
	else
		NewMsgRecord(api_data, kFILE_BAD, filePath, 0, 0);
	bRecP->totIncludes--;
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr 	_DoGoto(long api_data, Ptr *oldFilePPtr, long *lenP)
{
Ptr				tempP;
long			gotoOpcodeOffset, len;
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
CStr63			labelName;

	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTab(&tempP, &len);
	if NOT(err = GetEntityName(api_data, &tempP, &len, labelName, false))
	{	
		if COMPILING(api_data)
		{	if NOT(err = BIC_AddGoto(api_data, labelName))
				err = BIC_Branch(api_data, false, true, nil, INVALID_ABSOLUTE_BR_OFFSET, &gotoOpcodeOffset, false);
		}
		else
		{	CEquStr(bRecP->curLabelName, labelName);
			CAddChar(bRecP->curLabelName, ':');
			//if NOT(CCompareStrings(bRecP->curLabelName, "fine:"))
			//	Debugger();
			bRecP->_break = true;
		}
	}

if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_DoInclude(long api_data, Ptr *oldFilePPtr, long *lenP)
{
XErr			err = noErr;
Ptr				tempP;
long			filePathLen, len;
ParameterRec	filePathParam;
CStr255			tStr, filePath;
BifernoRecP		bRecP;

	tempP = *oldFilePPtr;
	len = *lenP;
	bRecP = (BifernoRecP)api_data;
	SkipSpaceAndTab(&tempP, &len);
	if (len && (*tempP == '('))
	{	tempP++;
		len--;
		if NOT(err = GetOneParameter(api_data, &tempP, &len, nil, &filePathParam, nil, true, true, kLoadParamOnStack, nil, 0))
		{	
			if COMPILING(api_data)
			{
				err = BIC_FlowControl(api_data, k_Include, (ObjRecordP)&filePathParam.objRef);
			}
			else
			{
				if NOT(err = BAPI_ObjToString(api_data, &filePathParam.objRef, filePath, &filePathLen, 255, kImplicitTypeCast))
				{	
					CEquStr(tStr, filePath);
					if NOT(err = BAPI_RealPath(api_data, tStr, true))
					{	
						err = IncludeFile(api_data, tStr, false, nil);
					}
				}
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_RoundBracketExpected);

if NOT(err)
{	
	if (len && (*tempP == ')'))
	{	tempP++;
		len--;
	}
	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_DoFor(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean skipForced)
{
Ptr			loopP, tempP;
long		continueOffset, breakOffset, braOffset, forBodyOffset = 0, saveLastLoopFlags, saveLastLoopCurGraph, flags, curGraphs, saveLine, saveIncremLen, saveConditLen, 
			loopMaxLen = 0, len, conditLen, incremLen;
XErr		err = noErr;
Boolean		toContinue;
Ptr			saveP, incremStrP, saveIncremStrP, conditStrP, saveConditStrP;
Boolean		saveInSwitch, saveInTag, *exitP, *stopP, *breakP, *returnP;
BifernoRecP	bRecP = (BifernoRecP)api_data;
int			incremLine, conditLine;
Byte		lastChar;
long		saveTotBreakOffset;
BlockRef	saveBreakOff = 0;

	tempP = *oldFilePPtr;
	len = *lenP;
	loopP = nil;
	SkipSpaceAndTab(&tempP, &len);
	if NOT(err = _ForStart(api_data, &tempP, &len, (Boolean)NOT(skipForced)))
	{	SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
		saveP = tempP;
		conditLine = bRecP->currentCtx.currentLine;
		if (COMPILING(api_data))
		{	SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, 0L, false, false);
			if (lastChar != ';')
				return XError(kBAPI_Error, Err_BadSyntax);
			if (err = BIC_Branch(api_data, false, true, nil, INVALID_ABSOLUTE_BR_OFFSET, &braOffset, false))
				return err;
			if (err = BIC_GetOffset(api_data, &forBodyOffset))
				return err;
			toContinue = true;
		}
		else
		{	if (err = _Condition(api_data, &tempP, &len, false, nil, ';', false, nil, INVALID_ABSOLUTE_BR_OFFSET, false, false, skipForced))
				return err;
		}
		if NOT(saveBreakOff = NewBlock(MAX_BREAKS_IN_LOOP * sizeof(long), &err, nil))
			return err;
		conditStrP = saveConditStrP = saveP;
		conditLen = saveConditLen = tempP-saveP;

		SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
		saveP = tempP;
		incremLine = bRecP->currentCtx.currentLine;
		if (err = _ForIncrement(api_data, &tempP, &len, false, true))
			return err;
		incremStrP = saveIncremStrP = saveP;
		incremLen = saveIncremLen = tempP-saveP;
		if NOT(err = _SkipBeforeBlock(bRecP, &tempP, &len))
		{	if NOT(len)
				err = XError(kBAPI_Error, Err_BadSyntax);
			else if (*tempP != '{')
				flags = kOnlyOneStatement;
			else
				flags = 0;
			if NOT(err)
			{	curGraphs = bRecP->currentCtx.tot_graf_pars;
				if (NOT(err) && len)
				{	exitP = &((BifernoRecP)api_data)->_exit;
					stopP = &((BifernoRecP)api_data)->currentCtx._stop;
					breakP = &((BifernoRecP)api_data)->_break;
					returnP = &((BifernoRecP)api_data)->_return;
					saveLine = bRecP->currentCtx.currentLine;
					if (skipForced)
						err = SkipBlock(api_data, &tempP, &len, flags, nil, nil);
					else
					{	if (COMPILING(api_data))
							toContinue = true;
						else
							err = _Condition(api_data, &conditStrP, &conditLen, false, &toContinue, ';', false, nil, INVALID_ABSOLUTE_BR_OFFSET, false, false, skipForced);
						if NOT(err)
						{	if (toContinue)		
							{	bRecP->inLoop++;
								saveInTag = bRecP->currentCtx.inTag;
								saveLastLoopCurGraph = bRecP->lastLoopCurGraph;
								saveLastLoopFlags = bRecP->lastLoopFlags;
								saveInSwitch = bRecP->inSwitch;
								CopyBlock(GetPtr(saveBreakOff), bRecP->breakOffset, bRecP->totBreakOffset);
								saveTotBreakOffset = bRecP->totBreakOffset;
								bRecP->totBreakOffset = 0;
								bRecP->inSwitch = false;
								bRecP->lastLoopFlags = (short)flags;
								do
								{	conditStrP = saveConditStrP;
									conditLen = saveConditLen;
									bRecP->currentCtx.currentLine = saveLine;
									loopP = tempP;
									loopMaxLen = len;
									bRecP->_continue = false;
									bRecP->currentCtx.inTag = saveInTag;
									bRecP->lastLoopCurGraph = curGraphs;
								init:	
									if NOT(err = ProcessBlock(api_data, &loopP, &loopMaxLen, flags))
									{	if (*exitP)
											break;
										else if (*breakP)
										{	if (*bRecP->curLabelName)
											{	if NOT(err = GotoWasFound(api_data, &loopP, &loopMaxLen, tempP, len, curGraphs, flags, saveLine, false))
												{	if (*breakP)
													{	// *breakP = false;
														break;
													}
													else
														goto init;	// found label in this loop
												}
											}
											else
											{	*breakP = false;
												break;
											}
										}
										else if (*returnP)
										{	*returnP = false;
											break;
										}
										else if (*stopP)
										{	//*stopP = false;
											break;
										}
										else
										{	if COMPILING(api_data)
												BIC_GetOffset(api_data, &continueOffset);
											err = _ForIncrement(api_data, &incremStrP, &incremLen, true, false);
											if (err)
												bRecP->currentCtx.currentLine = incremLine;
											else
											{	incremStrP = saveIncremStrP;
												incremLen = saveIncremLen;
												if COMPILING(api_data)
													err = BIC_BranchUpdateOffset(api_data, braOffset, INVALID_ABSOLUTE_BR_OFFSET);
											}
										}
										if NOT(err)
										{	if (err = _Condition(api_data, &conditStrP, &conditLen, false, &toContinue, ';', false, nil, forBodyOffset, true, false, skipForced))
												bRecP->currentCtx.currentLine = conditLine;
											if COMPILING(api_data)
											{	toContinue = false;
												BIC_GetOffset(api_data, &breakOffset);
												_UpdateBreaksBra(bRecP, continueOffset, breakOffset);
											}
										}
									}
									if (NOT(err) && (curGraphs != bRecP->currentCtx.tot_graf_pars))
										err = XError(kBAPI_Error, Err_CurlyBracketNotBalanced);
								} while (NOT(err) && toContinue);
								bRecP->_continue = false;
								bRecP->lastLoopCurGraph = saveLastLoopCurGraph;
								bRecP->inSwitch = saveInSwitch;
								bRecP->lastLoopFlags = (short)saveLastLoopFlags;
								CopyBlock(bRecP->breakOffset, GetPtr(saveBreakOff), saveTotBreakOffset);
								bRecP->totBreakOffset = saveTotBreakOffset;
								bRecP->inLoop--;
							}
							else
							{	loopP = tempP;
								loopMaxLen = len;
								err = SkipBlock(api_data, &loopP, &loopMaxLen, flags, nil, nil);
							}
						}
						else
							bRecP->currentCtx.currentLine = conditLine;
					}
				}
			}
		}
		if (saveBreakOff)
			DisposeBlock(&saveBreakOff);
	}

if NOT(err)
{	if (bRecP->inLoop && *bRecP->curLabelName)
		bRecP->_break = true;
	if NOT(skipForced)
	{	tempP = loopP;		// loopP is advanced until end of block
		len = loopMaxLen;
	}
	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_DoIf(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean skipForced)
{
Ptr			saveP, tempP;
long		saveLen, fcID, fcID2, len, flags;
XErr		err = noErr;
Boolean		toProcess, notMode, *toProcessP;
BifernoRecP	bRecP = (BifernoRecP)api_data;
Ptr			blockP;
long		ifOpcodeOffset, elseOpcodeOffset, curGraphs, saveLine, blockLen;
Boolean		foundGoto;
	
	tempP = *oldFilePPtr;
	len = *lenP;
	notMode = false;
	SkipSpaceAndTab(&tempP, &len);
	if (len && (*tempP == '!'))
	{	tempP++;
		len--;
		notMode = true;
	}
	// else if ((len > 2) && (*(short*)tempP == NOT_STR1) && (*(tempP + 2) == 'T'))
	else if (IsNot(tempP, len))
	{	tempP += 3;
		len -= 3;
		notMode = true;
	}
	SkipSpaceAndTab(&tempP, &len);
	if (len && (*tempP == '('))
	{	tempP++;
		len--;
	}
	else
		err = XError(kBAPI_Error, Err_BadSyntax);
	if NOT(err)
	{	if (skipForced)
		{	toProcessP = nil;
			toProcess = false;
		}
		else
			toProcessP = &toProcess;
		if (err = _Condition(api_data, &tempP, &len, notMode, toProcessP, ')', true, &ifOpcodeOffset, INVALID_ABSOLUTE_BR_OFFSET, false, false, skipForced))
			return err;
		if NOT(err = _SkipBeforeBlock(bRecP, &tempP, &len))
		{	if NOT(len)
				err = XError(kBAPI_Error, Err_BadSyntax);
			else if (*tempP != '{')
				flags = kOnlyOneStatement;
			else
				flags = 0;
			if NOT(err)
			{	blockP = tempP;
				blockLen = len;
				saveLine = bRecP->currentCtx.currentLine;
				curGraphs = bRecP->currentCtx.tot_graf_pars;
				if (toProcess)
				{	
				init:
					if NOT(err = ProcessBlock(api_data, &tempP, &len, flags))
					{	// remove last ';' (if any)
						if ((flags & kOnlyOneStatement) && len && (*tempP == ';'))
						{	tempP++;
							len--;
						}
						if NOT(err = _CheckIfGoto(bRecP, &tempP, &len, blockP, blockLen, flags, saveLine, curGraphs, &foundGoto))
						{	if (foundGoto)
								goto init;	// found label in this block
						}
					}
				}
				else
				{	flags |= kStopOnElse;
					err = SkipBlock(api_data, &tempP, &len, flags, nil, nil);
				}
				if (*bRecP->curLabelName)
					bRecP->_break = true;
				if (NOT(err) && NOT(bRecP->_exit) && NOT(bRecP->currentCtx._stop) && NOT(bRecP->_break))	// _break is for the goto
				{	SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
					if (bRecP->currentCtx.inTag)
					{	IsCommentExt(bRecP, &tempP, &len, nil, nil, false);
						SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
					}
					else
					{	IsInitTagExt(bRecP, &tempP, &len);
						SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
					}
					saveP = tempP;
					saveLen = len;
					if (IsFlowControlExt(api_data, &tempP, &len, &fcID, nil))
					{	if (fcID == k_Else)
						{	if COMPILING(api_data)
							{	if NOT(err = BIC_Branch(api_data, false, true, nil, INVALID_ABSOLUTE_BR_OFFSET, &elseOpcodeOffset, false))
									err = BIC_BranchUpdateOffset(api_data, ifOpcodeOffset, INVALID_ABSOLUTE_BR_OFFSET);
							}
							SkipSpaceAndTab(&tempP, &len);
							fcID2 = 0;
							saveP = tempP;
							saveLen = len;
							if (IsFlowControlExt(api_data, &tempP, &len, &fcID2, nil) && (fcID2 != k_If))
							{	if (fcID2 != k_If)
								{	fcID2 = 0;
									tempP = saveP;
									len = saveLen;
								}	
							}
							if NOT(err)
							{	if NOT(err = _SkipBeforeBlock(bRecP, &tempP, &len))
								{	if NOT(fcID2)
									{	if NOT(len)
											err = XError(kBAPI_Error, Err_BadSyntax);
										else if (*tempP != '{')
											flags = kOnlyOneStatement;
										else
											flags = 0;
									}
									if (NOT(COMPILING(api_data)) && (toProcess || skipForced))
									{	if (fcID2)
											err = _DoIf(api_data, &tempP, &len, SKIP_FORCED);
										else
										{	flags |= kStopOnElse;
											err = SkipBlock(api_data, &tempP, &len, flags, nil, nil);
										}
									}
									else
									{	if (fcID2)
											err = _DoIf(api_data, &tempP, &len, false);
										else
										{	blockP = tempP;
											blockLen = len;
											saveLine = bRecP->currentCtx.currentLine;
											curGraphs = bRecP->currentCtx.tot_graf_pars;
										init2:
											if NOT(err = ProcessBlock(api_data, &tempP, &len, flags))
											{	if NOT(err = _CheckIfGoto(bRecP, &tempP, &len, blockP, blockLen, flags, saveLine, curGraphs, &foundGoto))
												{	if (foundGoto)
														goto init2;	// found label in this block
												}
											}
										}
										if COMPILING(api_data)
											err = BIC_BranchUpdateOffset(api_data, elseOpcodeOffset, INVALID_ABSOLUTE_BR_OFFSET);
									}
								}
							}
						}
						else
						{	if COMPILING(api_data)
								err = BIC_BranchUpdateOffset(api_data, ifOpcodeOffset, INVALID_ABSOLUTE_BR_OFFSET);
							tempP = saveP;
							len = saveLen;
						}
					}
					else
					{	if COMPILING(api_data)
							err = BIC_BranchUpdateOffset(api_data, ifOpcodeOffset, INVALID_ABSOLUTE_BR_OFFSET);
					}
				}
			}
		}
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_DoSwitch(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean skipForced)
{
Ptr				tempP;
long			saveLen, len, flags;
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
ParameterRec	param;
ObjRecord			saveSwitchObject;
Byte			lastChar;
Boolean			saveInSwitch, switchMatched, breakRemain;
long			switchFlags;
int				tot_graf_pars;
long			switchDefaultLine;
Ptr				switchDefaultPtr;
long			switchDefaultLen;
long			saveLastSwitchFlags, saveLastSwitchCurGraph, oldVolatileLevel, switchDefaultGraphPars;
Ptr				blockP;
long			defaultCurLine, curGraphs, blockLen, saveLine;

	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTab(&tempP, &len);
	if (len && (*tempP == '('))
	{	tempP++;
		len--;
	}
	else
		err = XError(kBAPI_Error, Err_RoundBracketExpected);
	if NOT(err)
	{	oldVolatileLevel = SetVolatileLevel(bRecP);
		if (skipForced)
			SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, 0L, false, false);
		else
			err = GetOneParameter(api_data, &tempP, &len, &lastChar, &param, nil, true, true, 0L, nil, 0);
		if NOT(err)
		{	SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
			if NOT(len)
				err = XError(kBAPI_Error, Err_BadSyntax);
			else if (*tempP != '{')
				err = XError(kBAPI_Error, Err_BadSyntax);
			else
				flags = 0;
			if NOT(err)
			{	if (skipForced)
					err = SkipEntireBlock(api_data, &tempP, &len, flags, bRecP->currentCtx.tot_graf_pars, true);
				else
				{	
					blockP = tempP;
					blockLen = len;
					saveLine = bRecP->currentCtx.currentLine;
					curGraphs = bRecP->currentCtx.tot_graf_pars;

					tempP++;
					len--;
					
					//saveLastSwitchCurGraph = bRecP->lastSwitchCurGraph;
					//bRecP->lastSwitchCurGraph = bRecP->tot_graf_pars;

					saveLastSwitchCurGraph = bRecP->lastSwitchCurGraph;
					bRecP->lastSwitchCurGraph = bRecP->currentCtx.tot_graf_pars;
					
					saveInSwitch = bRecP->inSwitch;
					bRecP->inSwitch = true;

					tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
					if (tot_graf_pars < MAX_PARCHECKS)
						bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
					bRecP->currentCtx.tot_graf_pars++;

					switchDefaultLine = switchDefaultGraphPars = switchDefaultLen = 0;
					switchDefaultPtr = nil;
					
					saveSwitchObject = bRecP->currentCtx.switchObject;
					bRecP->currentCtx.switchObject = OBJRECORD(param.objRef);
					
					saveLastSwitchFlags = bRecP->lastSwitchFlags;
					bRecP->lastSwitchFlags = (short)flags;
					
					switchMatched = false;	
					breakRemain = false;
					while (len && NOT(switchMatched) && (bRecP->currentCtx.tot_graf_pars > curGraphs) && NOT(err))
					{	if NOT(err = SkipBisBlock(api_data, &tempP, &len, flags, nil, nil, &switchFlags/*, nil, nil*/))
						{
						isCase:
							if (bRecP->currentCtx.tot_graf_pars <= tot_graf_pars)
								break;
							else if (switchFlags == kDefaultFound)
							{	
						isDefault:
								switchDefaultLine = bRecP->currentCtx.currentLine;
								switchDefaultPtr = tempP;
								switchDefaultGraphPars = bRecP->currentCtx.tot_graf_pars;
								saveLen = len;
								defaultCurLine = bRecP->currentCtx.currentLine;
								SkipBlock(api_data, &tempP, &len, flags, nil, &switchFlags);
								switchDefaultLen = saveLen;	// - len;
								if (bRecP->currentCtx.tot_graf_pars == tot_graf_pars)
									break;
							}
							else
								err = _CaseOfSwitch(api_data, &tempP, &len, false, &switchMatched, &switchFlags);
						checkGoto:	
							if NOT(err)
							{	if (bRecP->_break && *bRecP->curLabelName)
								{	if NOT(err = GotoWasFound(api_data, &tempP, &len, blockP, blockLen, curGraphs, flags, saveLine, false))
									{	if (bRecP->_break)
										{	breakRemain = true;
											break;
										}
										else
										{	
										gotoWasFoundInSwitch:
											// switchFlags = 0;
											switchMatched = true;
											err = ProcessBlock(api_data, &tempP, &len, 0);
											goto checkGoto;
										}
									}
								}
								if (len && NOT(err))
								{	if ((bRecP->_exit) || (bRecP->currentCtx._stop) || (bRecP->_break))
										break;
									else if (switchFlags == kDefaultFound)
										goto isDefault;
									else if (switchFlags == kCaseFound)
										goto isCase;
								}
							}
						}
					}
					if NOT(err)
					{	if (NOT(switchMatched) && switchDefaultPtr)
						{	//long	saveCurLine;
						
							// go to default
							//saveTotGraph = bRecP->tot_graf_pars;
							bRecP->currentCtx.tot_graf_pars = (short)switchDefaultGraphPars;
							//saveCurLine = bRecP->currentLine;
							bRecP->currentCtx.currentLine = defaultCurLine;
							if NOT(err = ProcessBlock(api_data, &switchDefaultPtr, &switchDefaultLen, 0))
							{	tempP = switchDefaultPtr;
								len = switchDefaultLen;
								if (bRecP->_break && *bRecP->curLabelName)
								{	if NOT(err = GotoWasFound(api_data, &tempP, &len, blockP, blockLen, curGraphs, flags, saveLine, false))
									{	if (bRecP->_break)
											breakRemain = true;
										else
											goto gotoWasFoundInSwitch;
											// err = ProcessBlock(api_data, &tempP, &len, flags);
									}
								}
							}
							/*if NOT()
							{	bRecP->currentCtx.currentLine = saveCurLine;
								bRecP->tot_graf_pars = saveTotGraph;
							}*/
							//if (bRecP->_break)
							//	bRecP->_break = false;
							
						}
					}
					if (bRecP->_break && NOT(breakRemain))
						bRecP->_break = false;
					bRecP->lastSwitchCurGraph = saveLastSwitchCurGraph;
					bRecP->inSwitch = saveInSwitch;
					//bRecP->lastLoopCurGraph = saveLastLoopCurGraph;
					bRecP->lastSwitchFlags = (short)saveLastSwitchFlags;
					bRecP->currentCtx.switchObject = saveSwitchObject;
				}
			}
		}
		ResumeVolatileLevel(bRecP, oldVolatileLevel);
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_DoWhile(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean skipForced)
{
Ptr			saveConditStrP, conditStrP, saveP, loopP, tempP;
long		whileBodyOffset = 0, opcodeOffset, saveLastLoopFlags, saveLastLoopCurGraph, conditLen, saveConditLen, conditLine, flags, curGraphs, saveLine, loopMaxLen = 0, len;
XErr		err = noErr;
Boolean		toContinue, *toContinueP;
Boolean		notMode, saveInTag, *exitP, *stopP, *breakP, *returnP;
Byte		lastChar;
BifernoRecP	bRecP = (BifernoRecP)api_data;
int			cicle;
Boolean		saveInSwitch;
long		continueOffset, breakOffset, saveTotBreakOffset;
BlockRef	saveBreakOff = 0;

	tempP = *oldFilePPtr;
	len = *lenP;
	notMode = false;
	SkipSpaceAndTab(&tempP, &len);
	if (len && (*tempP == '!'))
	{	tempP++;
		len--;
		notMode = true;
	}
	else if (IsNot(tempP, len))
	// ex else if ((len > 2) && (*(short*)tempP == NOT_STR1) && (*(tempP + 2) == 'T'))
	{	tempP += 3;
		len -= 3;
		notMode = true;
	}
	SkipSpaceAndTabCRLF(&tempP, &len, &((BifernoRecP)api_data)->currentCtx.currentLine);
	if (len && (*tempP == '('))
	{	tempP++;
		len--;
	}
	else
		return XError(kBAPI_Error, Err_BadSyntax);
	saveP = tempP;
	conditLine = bRecP->currentCtx.currentLine;
	cicle = 0;
	if (COMPILING(api_data))
	{	SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, 0L, false, false);
		if (lastChar != ')')
			return XError(kBAPI_Error, Err_BadSyntax);
		if (err = BIC_Branch(api_data, notMode, true, nil, INVALID_ABSOLUTE_BR_OFFSET, &opcodeOffset, false))
			return err;
		if (err = BIC_GetOffset(api_data, &whileBodyOffset))
			return err;
		toContinue = true;
	}
	else
	{	if (err = _Condition(api_data, &tempP, &len, notMode, &toContinue, ')', true, nil, INVALID_ABSOLUTE_BR_OFFSET, false, false, skipForced))
			return err;
	}
	if NOT(saveBreakOff = NewBlock(MAX_BREAKS_IN_LOOP * sizeof(long), &err, nil))
		return err;
	conditStrP = saveConditStrP = saveP;
	conditLen = saveConditLen = tempP-saveP;
	if NOT(err = _SkipBeforeBlock(bRecP, &tempP, &len))
	{	if NOT(len)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else if (*tempP != '{')
			flags = kOnlyOneStatement;
		else
			flags = 0;
		if NOT(err)
		{	curGraphs = bRecP->currentCtx.tot_graf_pars;
			exitP = &((BifernoRecP)api_data)->_exit;
			stopP = &((BifernoRecP)api_data)->currentCtx._stop;
			breakP = &((BifernoRecP)api_data)->_break;
			returnP = &((BifernoRecP)api_data)->_return;
			saveLine = bRecP->currentCtx.currentLine;
			saveInSwitch = bRecP->inSwitch;
			bRecP->inSwitch = false;
			bRecP->inLoop++;
			loopP = tempP;
			loopMaxLen = len;
			saveInTag = bRecP->currentCtx.inTag;
			saveLastLoopCurGraph = bRecP->lastLoopCurGraph;
			saveLastLoopFlags = bRecP->lastLoopFlags;
			CopyBlock(GetPtr(saveBreakOff), bRecP->breakOffset, bRecP->totBreakOffset);
			saveTotBreakOffset = bRecP->totBreakOffset;
			bRecP->lastLoopFlags = (short)flags;
			if (toContinue)
			{	while (NOT(err) && toContinue)
				{	if (cicle)		// first was yet made belowe
					{	conditStrP = saveConditStrP;
						conditLen = saveConditLen;
						if (skipForced)
						{	toContinueP = nil;
							toContinue = false;
						}
						else
							toContinueP = &toContinue;
						if COMPILING(api_data)
							BIC_GetOffset(api_data, &continueOffset);
						err = _Condition(api_data, &conditStrP, &conditLen, notMode, toContinueP, ')', true, nil, whileBodyOffset, true, false, skipForced);
						if COMPILING(api_data)
						{	BIC_GetOffset(api_data, &breakOffset);
							_UpdateBreaksBra(bRecP, continueOffset, breakOffset);
							toContinue = false;
						}
					}
					cicle++;
					if (err)
						bRecP->currentCtx.currentLine = conditLine;
					else if (toContinue)
					{	tempP = loopP;
						len = loopMaxLen;
						bRecP->currentCtx.currentLine = saveLine;
						bRecP->_continue = false;
						bRecP->currentCtx.inTag = saveInTag;
						bRecP->lastLoopCurGraph = curGraphs;
					init:	
						if (skipForced)
							err = SkipBlock(api_data, &tempP, &len, flags, nil, nil);
						else
							err = ProcessBlock(api_data, &tempP, &len, flags);
						if NOT(err)
						{	if (*exitP || *stopP)
								break;
							else if (*returnP)
							{	*returnP = false;
								break;
							}
							else if (*breakP)
							{	if (*bRecP->curLabelName)
								{	if NOT(err = GotoWasFound(api_data, &tempP, &len, loopP, loopMaxLen, curGraphs, flags, saveLine, false))
									{	if (*breakP)
										{	//*breakP = false;
											break;
										}
										else
											goto init;	// found label in this loop
									}
								}
								else
								{	*breakP = false;
									break;
								}
							}
							if COMPILING(api_data)
								err = BIC_BranchUpdateOffset(api_data, opcodeOffset, INVALID_ABSOLUTE_BR_OFFSET);
						}
					}
					if (NOT(err) && (curGraphs != bRecP->currentCtx.tot_graf_pars))
						err = XError(kBAPI_Error, Err_CurlyBracketNotBalanced);
				};
				bRecP->_continue = false;
			}
			else
				err = SkipBlock(api_data, &tempP, &len, flags, nil, nil);
			CopyBlock(bRecP->breakOffset, GetPtr(saveBreakOff), saveTotBreakOffset);
			bRecP->totBreakOffset = saveTotBreakOffset;
			bRecP->inSwitch = saveInSwitch;
			bRecP->lastLoopCurGraph = saveLastLoopCurGraph;
			bRecP->lastLoopFlags = (short)saveLastLoopFlags;
			bRecP->inLoop--;
		}
	}
	if (saveBreakOff)
		DisposeBlock(&saveBreakOff);

	
if NOT(err)
{	if (bRecP->inLoop && *bRecP->curLabelName)
		bRecP->_break = true;
	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
static XErr 	_DoDo(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean skipForced)
{
Ptr			saveP, loopP, tempP;
long		doBodyOffset = 0, saveLastLoopFlags, saveLastLoopCurGraph, fcID, saveLen, flags, curGraphs, saveLine, loopMaxLen = 0, len;
XErr		err = noErr;
Boolean		saveInSwitch, saveInTag, toContinue;
Boolean		toBreak, *exitP, *stopP, *breakP, *returnP;
BifernoRecP	bRecP = (BifernoRecP)api_data;
long		continueOffset, breakOffset, saveTotBreakOffset;
BlockRef	saveBreakOff = 0;

	tempP = *oldFilePPtr;
	len = *lenP;
	if NOT(saveBreakOff = NewBlock(MAX_BREAKS_IN_LOOP * sizeof(long), &err, nil))
		return err;
	if NOT(err = _SkipBeforeBlock(bRecP, &tempP, &len))
	{	if NOT(len)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else if (*tempP != '{')
			flags = kOnlyOneStatement;
		else
			flags = 0;
		if NOT(err)
		{	curGraphs = bRecP->currentCtx.tot_graf_pars;
			exitP = &((BifernoRecP)api_data)->_exit;
			stopP = &((BifernoRecP)api_data)->currentCtx._stop;
			breakP = &((BifernoRecP)api_data)->_break;
			returnP = &((BifernoRecP)api_data)->_return;
			saveLine = bRecP->currentCtx.currentLine;
			bRecP->inLoop++;
			loopP = tempP;
			loopMaxLen = len;
			toBreak = false;
			saveInTag = bRecP->currentCtx.inTag;
			saveLastLoopCurGraph = bRecP->lastLoopCurGraph;
			saveLastLoopFlags = bRecP->lastLoopFlags;
			saveInSwitch = bRecP->inSwitch;
			CopyBlock(GetPtr(saveBreakOff), bRecP->breakOffset, bRecP->totBreakOffset);
			saveTotBreakOffset = bRecP->totBreakOffset;
			bRecP->totBreakOffset = 0;
			bRecP->inSwitch = false;
			bRecP->lastLoopFlags = (short)flags;
			do
			{	tempP = loopP;
				len = loopMaxLen;
				bRecP->currentCtx.currentLine = saveLine;
				bRecP->_continue = false;
				bRecP->currentCtx.inTag = saveInTag;
				bRecP->lastLoopCurGraph = curGraphs;
				if COMPILING(api_data)
					err = BIC_GetOffset(api_data, &doBodyOffset);
				if (skipForced)
					err = SkipBlock(api_data, &tempP, &len, flags, nil, nil);
				else
				{
				init:
					err = ProcessBlock(api_data, &tempP, &len, flags);
				}
				if NOT(err)
				{	if (*exitP || *stopP)
						break;
					else if (*returnP)
					{	*returnP = false;
						break;
					}
					else if (*breakP)
					{	if (*bRecP->curLabelName)
						{	if NOT(err = GotoWasFound(api_data, &tempP, &len, loopP, loopMaxLen, curGraphs, flags, saveLine, false))
							{	if (*breakP)
								{	//*breakP = false;
									toBreak = true;
								}
								else
									goto init;	// found label in this loop
							}
						}
						else
						{	*breakP = false;
							toBreak = true;
						}
					}
					if NOT(err)
					{	SkipSpaceAndTabCRLF(&tempP, &len, &((BifernoRecP)api_data)->currentCtx.currentLine);
						if NOT(bRecP->currentCtx.inTag)
						{	IsInitTagExt(bRecP, &tempP, &len);
							SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
						}
						saveP = tempP;
						saveLen = len;
						if (IsFlowControlExt(api_data, &tempP, &len, &fcID, nil))
						{	if (fcID == k_While)
							{	Boolean notMode = false;
								SkipSpaceAndTab(&tempP, &len);
								if (len && (*tempP == '!'))
								{	tempP++;
									len--;
									notMode = true;
								}
								else if (IsNot(tempP, len))
								// else if ((len > 2) && (*(short*)tempP == NOT_STR1) && (*(tempP + 2) == 'T'))
								{	tempP += 3;
									len -= 3;
									notMode = true;
								}
								SkipSpaceAndTab(&tempP, &len);
								if (len && (*tempP == '('))
								{	tempP++;
									len--;
									if (toBreak || skipForced || COMPILING(api_data))
									{	if COMPILING(api_data)
											BIC_GetOffset(api_data, &continueOffset);
										err = _Condition(api_data, &tempP, &len, notMode, nil, ')', true, nil, doBodyOffset, true, true, skipForced);
										if COMPILING(api_data)
										{	BIC_GetOffset(api_data, &breakOffset);
											_UpdateBreaksBra(bRecP, continueOffset, breakOffset);
										}
										toContinue = false;
									}
									else
										err = _Condition(api_data, &tempP, &len, notMode, &toContinue, ')', true, nil, 0, false, true, skipForced);
								}
								else
									err = XError(kBAPI_Error, Err_BadSyntax);
							}
							else
							{	tempP = saveP;
								len = saveLen;
								toContinue = false;
							}	
						}
						else
							toContinue = false;
					}
				}
				if (NOT(err) && (curGraphs != bRecP->currentCtx.tot_graf_pars))
					err = XError(kBAPI_Error, Err_CurlyBracketNotBalanced);
			} while (NOT(err) && toContinue);
			CopyBlock(bRecP->breakOffset, GetPtr(saveBreakOff), saveTotBreakOffset);
			bRecP->totBreakOffset = saveTotBreakOffset;
			bRecP->inSwitch = saveInSwitch;
			bRecP->_continue = false;
			bRecP->lastLoopFlags = (short)saveLastLoopFlags;
			bRecP->lastLoopCurGraph = saveLastLoopCurGraph;
			bRecP->inLoop--;
		}
	}
	if (saveBreakOff)
		DisposeBlock(&saveBreakOff);
	
if NOT(err)
{	if (bRecP->inLoop && *bRecP->curLabelName)
		bRecP->_break = true;
	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr 	DoFlowControl(long api_data, long fcID, Ptr *oldFilePPtr, long *lenP, long flags, Boolean skipForced)
{
XErr			err = noErr;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
Boolean			saveInFlow;

#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
#endif

	//if (fcID && /*bRecP->loadingClass /*&& (fcID != k_Static)*/)
	//	return XError(kBAPI_Error, Err_BadSyntax);
	//else if (bRecP->inCase)
	//	return XError(kBAPI_Error, Err_IllegalConstantExpression);
	switch(fcID)
	{
		case k_Exit:
			if COMPILING(api_data)
				err = BIC_FlowControl(api_data, k_Exit, nil);
			else
				bRecP->_exit = true;
			break;
		case k_Stop:
			if COMPILING(api_data)
				err = BIC_FlowControl(api_data, k_Stop, nil);
			else
				bRecP->currentCtx._stop = true;
			break;
		case k_For:
			saveInFlow = bRecP->inFlow;
			bRecP->inFlow = true;
			err = _DoFor(api_data, oldFilePPtr, lenP, skipForced);
			bRecP->inFlow = saveInFlow;
			break;
		case k_Do:
			saveInFlow = bRecP->inFlow;
			bRecP->inFlow = true;
			err = _DoDo(api_data, oldFilePPtr, lenP, skipForced);
			bRecP->inFlow = saveInFlow;
			break;
		case k_While:
			saveInFlow = bRecP->inFlow;
			bRecP->inFlow = true;
			err = _DoWhile(api_data, oldFilePPtr, lenP, skipForced);
			bRecP->inFlow = saveInFlow;
			break;
		case k_If:
			saveInFlow = bRecP->inFlow;
			bRecP->inFlow = true;
			err = _DoIf(api_data, oldFilePPtr, lenP, skipForced);
			bRecP->inFlow = saveInFlow;
			break;
		case k_Else:
			err = XError(kBAPI_Error, Err_IllegalFlowControl);
			break;
		case k_Break:
			if (bRecP->inSwitch)
			{	if (bRecP->currentCtx.switchObject.id)
				{	bRecP->_break = true;
					bRecP->currentCtx.switchObject.id = 0;	// not to stop if break follows
					// err = SkipBlock(api_data, oldFilePPtr, lenP, bRecP->lastLoopFlags, nil, nil);
					err = SkipEntireBlock(api_data, oldFilePPtr, lenP, bRecP->lastSwitchFlags, bRecP->lastSwitchCurGraph, false);
				}
				else
					err = XError(kBAPI_Error, Err_IllegalFlowControl);
			}
			else if (bRecP->inLoop)
			{	if COMPILING(api_data)
				{	if (bRecP->totBreakOffset < MAX_BREAKS_IN_LOOP)
						err = BIC_Branch(api_data, false, true, nil, INVALID_ABSOLUTE_BR_OFFSET, &bRecP->breakOffset[bRecP->totBreakOffset++], false);
					else
						err = XError(kBAPI_Error, Err_IllegalFlowControl);
				}
				else
				{	bRecP->_break = true;
					err = SkipEntireBlock(api_data, oldFilePPtr, lenP, bRecP->lastLoopFlags, bRecP->lastLoopCurGraph, false);
				}
			}
			else
				err = XError(kBAPI_Error, Err_IllegalFlowControl);
			break;
		case k_Continue:
			if (bRecP->inLoop)
			{	if COMPILING(api_data)
				{	if (bRecP->totBreakOffset < MAX_BREAKS_IN_LOOP)
					{	long	*contP = &bRecP->breakOffset[bRecP->totBreakOffset];
						err = BIC_Branch(api_data, false, true, nil, INVALID_ABSOLUTE_BR_OFFSET, contP, false);
						// make continue negative
						*contP = -(*contP);
						bRecP->totBreakOffset++;
					}
					else
						err = XError(kBAPI_Error, Err_IllegalFlowControl);
				}
				else
				{	bRecP->_continue = true;
					err = SkipEntireBlock(api_data, oldFilePPtr, lenP, bRecP->lastLoopFlags, bRecP->lastLoopCurGraph, false);
				}
			}
			else
				err = XError(kBAPI_Error, Err_IllegalFlowControl);
			break;
		case k_Switch:
			saveInFlow = bRecP->inFlow;
			bRecP->inFlow = true;
			err = _DoSwitch(api_data, oldFilePPtr, lenP, skipForced);
			bRecP->inFlow = saveInFlow;
			break;
		case k_Case:
			if NOT(skipForced)
			{	if (bRecP->currentCtx.switchObject.id)
				{	if NOT(_SkipUntilCharExt(bRecP, oldFilePPtr, lenP, ':', nil, true))
						err = XError(kBAPI_Error, Err_BadSyntax);
					else 
					{	if (*lenP)
						{	(*oldFilePPtr)++;
							(*lenP)--;
						}
					}
				}
				else
					err = XError(kBAPI_Error, Err_IllegalFlowControl);
			}
			break;
		case k_Default:
			if NOT(skipForced)
			{	if NOT(bRecP->currentCtx.switchObject.id)
					err = XError(kBAPI_Error, Err_IllegalFlowControl);
			}
			break;
		case k_Include:
			saveInFlow = bRecP->inFlow;
			bRecP->inFlow = false;
			err = _DoInclude(api_data, oldFilePPtr, lenP);
			bRecP->inFlow = saveInFlow;
			break;
		case k_Lock:
			if COMPILING(api_data)
				err = BIC_FlowControl(api_data, k_Lock, nil);
			else
			{	XThreadsEnterCriticalSection();
				bRecP->locked++;
			}
			break;
		case k_Unlock:
			if COMPILING(api_data)
				err = BIC_FlowControl(api_data, k_Unlock, nil);
			else
			{	if (bRecP->locked)
				{	bRecP->locked--;
					XThreadsLeaveCriticalSectionExt();
				}
				else
					err = XError(kBAPI_Error, Err_IllegalFlowControl);
			}
			break;
		case k_Debug:
			if COMPILING(api_data)
				err = BIC_FlowControl(api_data, k_Debug, nil);
			else
				err = XError(kBAPI_Error, UserBreak);
			break;
		case k_Goto:
			err = _DoGoto(api_data, oldFilePPtr, lenP);
			break;
		case k_Function:
			if (bRecP->inFlow)
				err = XError(kBAPI_Error, Err_IllegalDeclaration);
			else
				err = LoadBifernoFunction(api_data, oldFilePPtr, lenP, nil);
			break;
		/*case k_Static:
			if (bRecP->loadingClass)
			{	bRecP->loadingStatic = true;
				bRecP->lastClassID = 0;
				SkipSpaceAndTab(oldFilePPtr, lenP);
			}
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
			break;*/
		/*case k_Method:
			if (bRecP->loadingClass)
				err = LoadBifernoFunction(api_data, oldFilePPtr, lenP);
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
			bRecP->loadingStatic = false;
			break;
		case k_Property:
			if (bRecP->loadingClass)
				err = LoadBifernoProperty(api_data, oldFilePPtr, lenP);
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
			bRecP->loadingStatic = false;
			break;
			*/
		case k_Class:
			if (bRecP->inFlow)
				err = XError(kBAPI_Error, Err_IllegalDeclaration);
			else
				err = LoadBifernoClass(api_data, oldFilePPtr, lenP);
			break;
		case k_Return:
			if NOT(err = DoFunctionReturn(api_data, oldFilePPtr, lenP))
			{	bRecP->_return = true;
				while(bRecP->currentCtx.tot_graf_pars && (*lenP > 0))
				{	// if (err = SkipBisBlock(api_data, oldFilePPtr, lenP, 0/*flags*/, nil, nil, nil/*, nil, nil*/))
					if (err = SkipBlock(api_data, oldFilePPtr, lenP, 0, nil, nil))
						break;
				}
			}
			break;
		default:
			err = -1;
	}

return err;
}

//===========================================================================================
Boolean IsFlowControl(long api_data, char *fcName, Ptr *oldFilePPtr, long *lenP, long *fcIDP, long *entityLengthP, XErr *errP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
Ptr			tempP;
long		objID, len;
XErr		err = noErr;
Boolean		res = false;

	tempP = *oldFilePPtr;
	len = *lenP;
	if (entityLengthP)
		*entityLengthP = 0;
	if NOT(*fcName)
		err = GetEntityName(api_data, &tempP, &len, fcName, false);
	if NOT(err)
	{	objID = DLM_GetObjID(gsDispatcherData.flowControls, fcName, nil, fcIDP);
		if (objID)
			res = true;
		if (entityLengthP)
			*entityLengthP = CLen(fcName);
	}
if (err)
{	if (errP)
		*errP = err;
	res = false;
}
else if (res)
{	*oldFilePPtr = tempP;
	*lenP = len;
}

return res;
}

