/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: biferno_server_mac.c,v 1.1.1.1 2003-03-25 13:07:40 valfer Exp $
	|______________________________________________________________________________
*/
// ======== CGI Controller Valerio Ferrucci 28/11/1997 ============
#include	"HTTPMgr.h"
#include	"XFilesMacPrivate.h"

#include <LowMem.h>
#include <NumberFormatting.h>
#include <Devices.h>
#include <Dialogs.h>
#include <Sound.h>
#include <Gestalt.h>
#include <Threads.h>
#include <Navigation.h>

#include <stdio.h>
#include <stdlib.h>

#include 	"Helpers.h"
#include 	"XErrors.h"
#include 	"MacLog.h"
#include 	"FLog.h"

#include 	"HTTPMrgNet.h"

//MaxMem
#define		MinFreeBlock	16000L

XFileRef	gLogRefNum = 0;

HTTPControllerP		gHttpControllerP;

static Boolean			done, gsSilent = false;
static EventRecord		gEvent;
static long				gWinRef;
static unsigned long 	theTicksToSleep = 0, last = 0;
static BlockRef			gHttpControllerBlock;
static char				errorMessage[] = "Error executing ACGI: (Err = ";
static char				appName[255];

extern CStr255			globalErrStr;
extern XYieldProc		gYieldProc;

#if TARGET_API_MAC_CARBON
// Navigator
typedef Boolean (*NavigatorUpdateProc)(WindowPtr);

typedef struct {
				FSSpec		sfFile;
				Boolean		sfGood;
				Boolean		sfReplacing;
				} NavigatorFileReply, *NavigatorFileReplyP;

static	Boolean		gNavServicesExists;
static	OSType					gAppSignature;
static	Str255					gAppName;
static	NavigatorUpdateProc		UpdateProc;

#define kNavigationFlags		(kNavDontAutoTranslate+kNavDontAddTranslateItems+kNavAllowPreviews+kNavSelectDefaultLocation+kNavNoTypePopup)

//============================
static pascal Boolean myFilterProc(AEDesc* theItem, void* info, NavCallBackUserData callBackUD, NavFilterModes filterMode)
{
NavTypeListPtr		navListP;
int					i, numTypes;
XErr				err = noErr;
OSType				type;
NavFileOrFolderInfo	*theInfo = (NavFileOrFolderInfo*)info;

	//return true;
	if (theItem->descriptorType == typeFSS)
	{	if (theInfo->isFolder)
			return true;
		else
		{
			if (callBackUD)
			{	type = theInfo->fileAndFolder.fileInfo.finderInfo.fdType;
				navListP = *((NavTypeListHandle)callBackUD);
				numTypes = navListP->osTypeCount;
				if (numTypes == -1)
					return true;
				else
				{	for (i = 0; i < numTypes; i++)
					{	if (navListP->osType[i] == type)
							return true;
					}
				}
			}
			else
				return true;
		}	
	}
	else
		return true;
	
return false;
}

//============================
static pascal void myEventProc(const NavEventCallbackMessage callBackSelector, 
						NavCBRecPtr callBackParms, 
						NavCallBackUserData callBackUD)
{
XErr		theErr = noErr;

	switch (callBackSelector)
	{
		case kNavCBEvent:
			switch (callBackParms->eventData.eventDataParms.event->what)
			{
				case mouseDown:
					break;
					
				case updateEvt:
						if (UpdateProc)
							UpdateProc((WindowPtr)callBackParms->eventData.eventDataParms.event->message);
						break;

				default:
					break;
			}
			break;

		case kNavCBCustomize:
			break;
			
		case kNavCBStart:
			break;
			
		case kNavCBTerminate:
			break;
	}
}

//============================
static XErr NAV_Get(short numTypes, SFTypeList typeList, Boolean *good, FSSpec *fileSpecP, void *filterProc, StringPtr actionLabel)
{	
NavReplyRecord		theReply;
NavDialogOptions	dialogOptions;
XErr				err = noErr;
NavTypeListHandle	openListH = NULL;
long				i, index, count = 0;
NavObjectFilterUPP	filterUPP = nil;
NavEventUPP			eventUPP = nil;
FSSpec				finalFSSpec;	
AEDesc 				defaultAEDescFSS, resultDesc, *defaultSpecP;
	
	defaultAEDescFSS.dataHandle = 0;

	filterUPP = NewNavObjectFilterUPP(myFilterProc);
	eventUPP = NewNavEventUPP(myEventProc);
	//dialogOptions.location = gLoc_Point;
	
	// default behavior for browser and dialog:
	if (err = NavGetDefaultDialogOptions(&dialogOptions))
		goto out;

	PEquStr(dialogOptions.clientName, gAppName);
	PEquStr(dialogOptions.actionButtonLabel, actionLabel);
	//dialogOptions.dialogOptionFlags = kNavNativeOptionFlags;//kNavGenericOptionFlags;
	
	if (numTypes >= 0)
	{	if NOT(openListH = (NavTypeListHandle)NewHandle(sizeof(NavTypeList) + ((numTypes-1) * sizeof(OSType))))
		{	err = MemError();
			goto out;
		}
		for (i = 0; i < numTypes; i++)
			(*openListH)->osType[i] = typeList[i];
		(*openListH)->osTypeCount = numTypes;
		(*openListH)->componentSignature = gAppSignature;
	}		
	else
		openListH = NULL;
	
	/*else
	{	if NOT(openListH = (NavTypeListHandle)NewHandleGlobE(sizeof(NavTypeList), &err))
			goto out;
	}*/
	
	
	dialogOptions.preferenceKey = 0;
	dialogOptions.dialogOptionFlags = kNavigationFlags;

	if (fileSpecP->name[0])
	{	if (err = AECreateDesc(typeFSS, fileSpecP, sizeof(FSSpec), &defaultAEDescFSS))
			goto out;
		defaultSpecP = &defaultAEDescFSS;
	}
	else
		defaultSpecP = nil;
	
	err = NavGetFile(defaultSpecP,
						&theReply,
						&dialogOptions,
						eventUPP,
						NULL,	// no custom previews
						filterUPP,
						openListH,
						nil);
						
out:
	if (defaultAEDescFSS.dataHandle)
		err = AEDisposeDesc(&defaultAEDescFSS);
	if (filterUPP)
		DisposeNavObjectFilterUPP(filterUPP);
	if (eventUPP)
		DisposeNavEventUPP(eventUPP);
	if (openListH)
		DisposeHandle((Handle)openListH);

	if (theReply.validRecord && NOT(err))
	{	err = AECountItems(&(theReply.selection), &count);
		for (index=1;index<=count; index++)
		{	resultDesc.dataHandle = 0L;
			if ((err = AEGetNthDesc(&(theReply.selection),index,typeFSS,NULL,&resultDesc)) == noErr)
			{	if NOT(err = AEGetDescData(&resultDesc,&finalFSSpec,sizeof(FSSpec)))
				{	// BlockMoveData(*resultDesc.dataHandle,&finalFSSpec,sizeof(FSSpec));
					err = AEDisposeDesc(&resultDesc);
				}
				break;	// prendo solo il primo file
			}
		}
	}
	*good = theReply.validRecord;
	*fileSpecP = finalFSSpec;
		
	err = NavDisposeReply(&theReply);	// clean up after ourselves	

return err;
}

//===========================================================================================
static XErr	Navigator_GetFile(short numTypes, SFTypeList typeList, NavigatorFileReplyP replyPtr)
{
XErr	err = noErr;

	if (gNavServicesExists)
		err = NAV_Get(numTypes, typeList, &replyPtr->sfGood, &replyPtr->sfFile, nil, "\pOpen");
	/*else	// old way
	{	StandardFileReply	reply;
		UniversalProcPtr 		fileFilterProcRecPtr = nil;
	
		//if (fileFilter)		
		//	fileFilterProcRecPtr = NewFileFilterYDProc(fileFilter);

		reply.sfFile = replyPtr->sfFile;
		StandardGetFile(nil, numTypes, typeList, &reply);

		if (fileFilterProcRecPtr)	
			DisposeRoutineDescriptor(fileFilterProcRecPtr);		
		replyPtr->sfFile = reply.sfFile;
		replyPtr->sfGood = reply.sfGood;
	}*/
		
return err;
}

//===========================================================================================
static XErr	Navigator_Init(OSType appSignature, StringPtr appName, NavigatorUpdateProc updateProc)
{
XErr	err = noErr;
	
	if (gNavServicesExists = NavServicesAvailable())
		err = NavLoad();
	gAppSignature = appSignature;
	PEquStr(gAppName, appName);
	UpdateProc = updateProc;
	
return err;
}

//===========================================================================================
static XErr	Navigator_End(void)
{
	if (gNavServicesExists)
		return 	NavUnload();
	else
		return noErr;
}
#endif	// TARGET_API_MAC_CARBON
#pragma mark-
//===========================================================================================
XErr	HTTPControllerLog(long taskID, char *outPutStr)
{
#pragma unused(taskID)

	//if (gLogRefNum)
	//	CStringToLog(gLogRefNum, outPutStr);
	if (gWinRef)
		CStringToLogWindow(gWinRef, outPutStr, true);

return noErr;
}

#pragma mark-
//===========================================================================================
static XErr _GetTheFileInfo(FSSpecPtr fileFspecPtr, HFileInfo *hFileInfoPtr)
{
	hFileInfoPtr->ioCompletion = nil;
	hFileInfoPtr->ioNamePtr = fileFspecPtr->name;
	hFileInfoPtr->ioVRefNum = fileFspecPtr->vRefNum;
	hFileInfoPtr->ioDirID = fileFspecPtr->parID;
	hFileInfoPtr->ioFDirIndex = 0;
	hFileInfoPtr->ioFRefNum = 0;

return PBGetCatInfoSync((CInfoPBPtr)hFileInfoPtr);
}

//===========================================================================================
static XErr _GetFolderFromFile(FSSpecPtr fileSpecPtr, FSSpecPtr dirSpecPtr)
{
DirInfo				dirInfo;
register DirInfo	*dirIPtr = &dirInfo;
Str255				dirName;
XErr				err = 0;

	dirIPtr->ioNamePtr = dirName;								// Nome di ritorno
	dirIPtr->ioVRefNum = fileSpecPtr->vRefNum;					// Volume su cui operare
	dirIPtr->ioDrDirID = fileSpecPtr->parID;					// Directory di partenza
	dirIPtr->ioFDirIndex = -1;									// Info solo su Directories
	if NOT(err = PBGetCatInfoSync((CInfoPBPtr)dirIPtr))
		err = FSMakeFSSpec(dirIPtr->ioVRefNum, dirIPtr->ioDrParID, dirIPtr->ioNamePtr, dirSpecPtr);

return err;
}

//===========================================================================================
static XErr _GetFullPath(FSSpecPtr fileSpecPtr, StringPtr fullPath)
{
DirInfo				dirInfo;
register DirInfo	*dirIPtr = &dirInfo;
Str255				dirName, swapStr;
XErr				err = 0;

if (fileSpecPtr->parID == fsRtParID)
	{
	PEquStr(fullPath, fileSpecPtr->name);
	PAddChar(fullPath, ':');	
	return noErr;
	}

*fullPath = 0;
dirIPtr->ioDrParID = fileSpecPtr->parID;					// Directory di partenza
dirIPtr->ioNamePtr = dirName;								// Nome di ritorno
dirIPtr->ioVRefNum = fileSpecPtr->vRefNum;					// Volume su cui operare
dirIPtr->ioDrDirID = 0;

while (dirIPtr->ioDrDirID != fsRtDirID)						// esce al raggiungimento della Root
	{
	dirIPtr->ioFDirIndex = -1;								// Info solo su Directories
	dirIPtr->ioDrDirID = dirIPtr->ioDrParID;				// non cadere nel PMSP
	if (err = PBGetCatInfoSync((CInfoPBPtr)dirIPtr))
		break;
	PAddChar(dirName, ':');
	PEquStr(swapStr, dirName);
	if ((swapStr[0] + dirName[0]) > 255)
		{
		fullPath[0] = 0;
		err = bdNamErr;
		}
	PAddStr(swapStr, fullPath);								// swap prima dir ultima nel path
	PEquStr(fullPath, swapStr);
	}							

if NOT (err)
	{
	HFileInfo		hFileInfo;
	
	_GetTheFileInfo(fileSpecPtr, &hFileInfo);
	if (hFileInfo.ioFlAttrib & 0x010)
		{
		PAddStr(fullPath, fileSpecPtr->name);
		PAddChar(fullPath, ':');
		}
	}

return err;
}

//===========================================================================================
static short _ProcessEvent(EventRecord *theEventP)
{
short					part, err;
WindowPtr				whichWindow;
Point					theClick;
Boolean					someEvent;
unsigned long			nextWNE;

if (theTicksToSleep && gHttpControllerP->Idle)
{	if ((TickCount() - last) >= theTicksToSleep)
	{	if (err = gHttpControllerP->Idle(0))
			return err;
		theTicksToSleep = 0;
		last = TickCount();
	}
}

// Yield
nextWNE = TickCount() + 8;
do {
	YieldToAnyThread();
	} while (TickCount() <= nextWNE);

if (theEventP)
	{
	gEvent = *theEventP;
	someEvent = gEvent.what != 0;
	}
else
	someEvent = WaitNextEvent(everyEvent, &gEvent, 10, nil);

	
theClick = gEvent.where;
GlobalToLocal(&theClick);			

if (gWinRef)
{	if (IsLogWindowEvent(gWinRef, &gEvent, &done))
		return gEvent.what;
}

if (someEvent)
	{
	switch (gEvent.what)
		{
		case mouseDown:
		part = FindWindow(gEvent.where, &whichWindow);
		switch (part)
			{
			case inDesk: 
				SysBeep(10);
				break;
			case inSysWindow:
				;//SystemClick( &gEvent, whichWindow );
				break;
			default:
				break;	
			}
			break;
		
		case kHighLevelEvent:
			if (gEvent.message == kCoreEventClass)
				err = AEProcessAppleEvent(&gEvent);
			break;
		}
	}
return gEvent.what;
}

//===========================================================================================
static pascal short _yieldProc(void)
{
	_ProcessEvent(nil);

return 0;
}

//===========================================================================================
static XErr _LogRun(long taskID, XErr err)
{
#pragma unused(taskID)
CStr255		errStr, eNameStr, eMsg;
char		cStr[255];
XErr		theErr = 0;

	if (err)
	{	CNumToString(err, errStr);
		CEquStr(cStr, errorMessage);
		CAddStr(cStr, errStr);
		ErrorGetDescr(err, eNameStr, eMsg);
		CAddStr(cStr, " - ");
		CAddStr(cStr, eNameStr);
		if (CLen(eMsg))
		{	CAddStr(cStr, " ");
			CAddStr(cStr, eMsg);
		}
		CAddStr(cStr, ")");
		HTTPControllerLog(0, cStr);
		
		/*
		CEquStr(httpStr, httpHeaderInit);	
		CAddStr(httpStr, cStr);
		errLen = CLen(httpStr);	
		if (h = _HTTPPtrToHandle(httpStr, errLen))
			theErr = HTTPControllerSendReply(taskID, h, errLen);
		*/
		return theErr;
	}
	else
	{	CopyBlock(cStr, "OK (Err = 0)", 12);
		cStr[12] = 0;
		HTTPControllerLog(0, cStr);
		return 0;
	}
}

//===========================================================================================
static short _MyGotReqParams(const AppleEvent *AEvent)
{
Size		ActSize;
DescType	ReturnType;
short			Err;

Err = AEGetAttributePtr(AEvent,keyMissedKeywordAttr,typeWildCard,&ReturnType,0L,0,&ActSize);
if(Err == errAEDescNotFound)
	return(noErr);
else
	{
	if(Err == noErr)
		return(errAEEventNotHandled);
	}

return(Err);
}

//===========================================================================================
static void	_HandleErr(XErr err, char *optStr)
{					
CStr31		errStr;
CStr255		eNameStr, eMsg;
XErr		tErr = noErr;
char		*cStr;
BlockRef	block;
Str255		pStr, p2Str;

	/*if (err)
	{	NumToString(err, aStr);
		DebugStr(aStr);
	}*/
	
	ErrorGetDescr(err, eNameStr, eMsg);
	CNumToString(err, errStr);

	if (block = NewPtrBlock(6 + errStr[0] + 1 + eMsg[0] + 1 + eNameStr[0] + 1 + optStr[0] + 1, &tErr))
	{	cStr = GetPtr(block);
		CEquStr(cStr, "Err = ");
		CAddStr(cStr, errStr);
		CAddStr(cStr, " ");
		CAddStr(cStr, eMsg);
		CAddStr(cStr, " ");
		CAddStr(cStr, eNameStr);
		CAddStr(cStr, " ");
		CAddStr(cStr, optStr);
		HTTPControllerLog(0, cStr);
		CToPascal(cStr, pStr);
		CToPascal(globalErrStr, p2Str);
		ParamText(pStr, p2Str, nil, nil);
		StopAlert(301, nil);
	}
}

//===========================================================================================
static void	_FlushFunc(long menuID, long itemID)
{
	gHttpControllerP->ServerStateChanged(0L, kFlush);
}

//===========================================================================================
static void	_FlushAllFunc(long menuID, long itemID)
{
	gHttpControllerP->ServerStateChanged(0L, kReload);
}

//===========================================================================================
static void	_ProcessFileFunc(long menuID, long itemID)
{
CStr255				filePath;
SFTypeList			typeList;
XErr				err = noErr;

#if TARGET_API_MAC_CARBON
NavigatorFileReply	reply;

	err = Navigator_GetFile(-1, typeList, &reply);
#else
StandardFileReply	reply;

	StandardGetFile(nil, -1, typeList, &reply);
#endif
	if NOT(err)
	{	if (reply.sfGood)
		{	if NOT(err = _GetCFullPath(&reply.sfFile, filePath))
			{	AddPascalToCStr(filePath, reply.sfFile.name);
				CSubstitute(filePath, ':', '/');
				err = gHttpControllerP->Process(0L, filePath);
			}
		}
		if (err)
			_LogRun(0, err);
	}
}

#pragma mark-
//===========================================================================================
static pascal short _OpenDocsProc(const AppleEvent *AEvent, AppleEvent *AReply, unsigned long ARef)
{
#pragma unused(AReply, ARef)
FSSpec				FileDesc;
AEDescList			DocList;
short				err2, i,err;
long				NumOfItems;
Size				ActSize;
AEKeyword			KeyWd;
DescType			ReturnType;
StandardFileReply	reply;
FInfo				FinderInfo;
CStr255				filePath;

	if (err = AEGetParamDesc(AEvent,keyDirectObject,typeAEList,&DocList))
		return err;
	
	if (err = _MyGotReqParams(AEvent))
		return err;

	err = AECountItems(&DocList,&NumOfItems);
	for(i = 1;i <= (short)NumOfItems;i++)
	{	err = AEGetNthPtr(&DocList,(long)i,typeFSS,&KeyWd,&ReturnType, (Ptr)&FileDesc,sizeof(FileDesc),&ActSize);
		if (err == errAECoercionFail)	// from apple script
		{	if NOT(err = AEGetNthPtr(&DocList,(long)i,typeChar,&KeyWd,&ReturnType, filePath,255,&ActSize))
			{	CopyBlock(filePath+1,filePath,ActSize);
				*filePath = '/';
				filePath[ActSize+1] = 0;
			}
		}
		else
		{	if NOT(err = FSpGetFInfo(&FileDesc,&FinderInfo))
			{	if NOT(err = FSMakeFSSpec(FileDesc.vRefNum, FileDesc.parID, FileDesc.name, &reply.sfFile))
				{	if NOT(err = _GetCFullPath(&reply.sfFile, filePath))
						AddPascalToCStr(filePath, FileDesc.name);
				}
			}
		}
		if NOT(err)
		{	CSubstitute(filePath, ':', '/');
			err = gHttpControllerP->Process(0L, filePath);
		}
	}

out:
if (err)
	_LogRun(0, err);
err2 = AEDisposeDesc(&DocList);
return(noErr);
}

//===========================================================================================
static pascal short _QuitProc(const AppleEvent *AEvent, AppleEvent *AReply, unsigned long ARef)
{
#pragma unused(AEvent, AReply, ARef)

	done = 1;
	
return(noErr);
}

//===========================================================================================
static XErr _TerminateApp(void) 
{
XErr	err = noErr;

	AERemoveEventHandler(kCoreEventClass, kAEQuitApplication, (void*)_QuitProc, false);
	AERemoveEventHandler(kCoreEventClass, kAEOpenDocuments, (void*)_OpenDocsProc, false);
	if (gHttpControllerP->ShutDown)
		err = gHttpControllerP->ShutDown(0);
	DisposeBlock(&gHttpControllerBlock);

return err;
}

//===========================================================================================
/*static void	ProcessClientRequest(long socketRef, BlockRef block, long totLen, long userData)
{
HTTPRecord	httpRecord;
XErr		err = noErr;

	if NOT(err = GetClientRequest(socketRef, block, totLen, userData, &httpRecord))
	{	if (gHttpControllerP->Run)
			err = gHttpControllerP->Run((long)&httpRecord);
	}

	if (err)
	{	CStr255	errStr;

		XErrorGetDescr(err, errStr, nil);
		HTTPControllerLog((long)&httpRecord, errStr);
	}
}*/

//===========================================================================================
static void	ProcessClientRequest(long socketRef, BlockRef block, long totLen, long userData)
{
HTTPRecord	httpRecord;
XErr		err = noErr;
CStr255		aCStr;
Boolean		wasSilent, toQuit;
long		buffID = 0;

	//XServerSendToClient(socketRef, block, totLen);
	//return;
	toQuit = false;
	if NOT(err = GetClientRequest(0, socketRef, block, totLen, userData, &httpRecord))
	{	if (httpRecord.command)
		{	
		BlockRef	tblock;
		long		tLen;
		CStr255		remoteAddr, localAddr;

			*aCStr = 0;
			if NOT(err = XRemoteAddress(socketRef, remoteAddr))
			{	if NOT(err = XLocalAddress(socketRef, localAddr))
				{	if (CCompareStrings_cs(remoteAddr, localAddr))
						CEquStr(aCStr, "Forbidden\n");
					else
					{	if (wasSilent = gsSilent)
							gsSilent = false;
						switch(httpRecord.command)
						{	case kFlush:
								buffID = BufferCreate(255, &err);
								gHttpControllerP->ServerStateChanged(buffID, httpRecord.command);
								break;
							case kReload:
								buffID = BufferCreate(255, &err);
								gHttpControllerP->ServerStateChanged(buffID, httpRecord.command);
								break;
							case kQuit:
								toQuit = true;
								CEquStr(aCStr, "Ok, biferno stopped\n");
								break;
							case kGetVersion:
								buffID = BufferCreate(255, &err);
								gHttpControllerP->ServerStateChanged(buffID, httpRecord.command);
								break;
							default:
								CEquStr(aCStr, "Err, unknown command sent to biferno\n");
								break;
						}
						if (wasSilent)
							gsSilent = true;
					}
					if (NOT(*aCStr) && NOT(buffID))
						CEquStr(aCStr, "Err, can't display output\n");
					if (*aCStr)
					{	tLen = CLen(aCStr);
						if (tblock = NewBlock(tLen, &err))
						{	LockBlock(tblock);
							CopyBlock(GetPtr(tblock), aCStr, tLen);
							HTTPControllerSendReply((long)&httpRecord, tblock, tLen);
						}
					}
					else if (buffID)
					{	tblock = BufferGetBlockRef(buffID, &tLen);
						HTTPControllerSendReply((long)&httpRecord, tblock, tLen);
						BufferClose(buffID);
					}
				}
			}
		}
		else if (gHttpControllerP->Run)
			err = gHttpControllerP->Run((long)&httpRecord);
	}

	if (err)
	{	CStr255	errStr;

		XErrorGetDescr(err, errStr, nil);
		HTTPControllerLog((long)&httpRecord, errStr);
	}
	
	if (toQuit)
		exit(0);
}

#pragma mark-
#define	TOT_ITEMS	3
//===========================================================================================
void main(void)
{
Byte					theFld = 1;
long					aLong, lastCheck = 0;
short					err = 0;
CStr255					optStr;
ProcessInfoRec			pInfoRec;
FSSpec					appFoldSpec, applSpec;
ProcessSerialNumber		PSN;
Str255					serverPath;
Boolean					xInited;
CStr63					processItemString[TOT_ITEMS];
MacLogProcessFunc 		processFunc[TOT_ITEMS];

	if (Prof_START(3000,100))
		return;
	Prof_OFF;

#ifndef	ANSI_CONSOLE
	#if !TARGET_API_MAC_CARBON
		MaxApplZone();
	#endif
		for (aLong = 0; aLong < 30; aLong++)
			MoreMasters();
	#if !TARGET_API_MAC_CARBON
		InitGraf(&qd.thePort);
		InitFonts();
		InitWindows();
		InitMenus();
		TEInit();
		InitDialogs(0L);
	#endif
		InitCursor();
#endif
	
	//TEST PER VEDERE COME SI COMPORTA L'IF
	/*{
	int	a = 1, b = 1;
	
		if (a == 1 && b == 1)
		{	SysBeep(2);
			SysBeep(2);
			SysBeep(2);
		}
	}*/
	
	if (GetCurrentProcess(&PSN))
		return;
	pInfoRec.processName = nil;
	pInfoRec.processAppSpec = &applSpec;
	pInfoRec.processInfoLength = sizeof(ProcessInfoRec);
	if (GetProcessInformation(&PSN, &pInfoRec))
		return;
	PascalToC(applSpec.name, appName);
	if (err = _GetFolderFromFile(&applSpec, &appFoldSpec))
		goto out;
	if (err = _GetFullPath(&appFoldSpec, serverPath))
		goto out;
	//PascalToC(serverPath, serverPathCStr);

#if TARGET_API_MAC_CARBON
	if (err = Navigator_Init('BFRN', applSpec.name, UpdateLogWindow))
	{	_HandleErr(err, "Navigator_Init");
		return;
	}
#endif
	xInited = false;
	if (err = XInit(nil))
		goto out;
	gYieldProc = _yieldProc;
	xInited = true;
	
	/*helpersInited = false;
	if (err = InitHelpers())
		goto out;
	helpersInited = true;*/

	optStr[0] = 0;
	gHttpControllerBlock = 0;
	if NOT(gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err))
		goto out;
	gHttpControllerP = (HTTPControllerP)GetPtr(gHttpControllerBlock);
	
	ClearBlock(gHttpControllerP, sizeof(HTTPController));
	if (err = HTTPControllerRegister(gHttpControllerP))
		goto out;

	if (err = Gestalt(gestaltAppleEventsAttr, &aLong))
		goto out;

	// Quit AE
	if (err	= AEInstallEventHandler(kCoreEventClass, kAEQuitApplication, NewAEEventHandlerProc(_QuitProc), 0, false))
		goto out;

	// Open Doc Proc AE
	if (err	= AEInstallEventHandler(kCoreEventClass,kAEOpenDocuments,NewAEEventHandlerProc(_OpenDocsProc),0,false))
		goto out;

	if (MaxBlock() < MinFreeBlock)
	{	err = memFullErr;
		goto out;
	}

	InitCursor();
	FlushEvents(everyEvent, 0);
	
	gWinRef = 0;
#ifndef	ANSI_CONSOLE
	if (err = InitLogWindow(appName, &gWinRef, "\pTabasoft - Biferno Server"))
		return;
	CEquStr(processItemString[0], "Process File.../P");
	CEquStr(processItemString[1], "Flush/F");
	CEquStr(processItemString[2], "Reload/R");
	processFunc[0] = _ProcessFileFunc;
	processFunc[1] = _FlushFunc;
	processFunc[2] = _FlushAllFunc;
	WindowLogAddMenuItem("Biferno", processItemString, processFunc, TOT_ITEMS);
#endif
	gLogRefNum = 0;
	err = InitLog("BifernoServer.log", &gLogRefNum);
	if (err == XERR(kXLibError, ErrXFiles_FileNotFound))
	{	gLogRefNum = 0;
		err = noErr;
	}
	else if (err)
		goto out;

	
	SetCursor(*GetCursor(watchCursor));
	if (gHttpControllerP->Init)
	{	if (err = gHttpControllerP->Init(0, 32))
			goto out;
	}

	HTTPControllerLog(0, "=================");
	HTTPControllerLog(0, "Server Start");
	HTTPControllerLog(0, "=================");
	
	InitCursor();
	done = false;

	if (err = XServerLoop(8084, 64, ProcessClientRequest, 0L, true, true))
		goto out;

#ifdef ANSI_CONSOLE
	while(1)
	{	
		gets(optStr);
	}
#else
	while NOT(done)
		_ProcessEvent(nil);
#endif
	
	XServerNotifyQuit();
	
	err = _TerminateApp();

#if TARGET_API_MAC_CARBON
	Navigator_End();
#endif
out:
if (err)
	_HandleErr(err, optStr);

if (gHttpControllerBlock)
	DisposeBlock(&gHttpControllerBlock);
if (gWinRef)
	EndLogWindow(gWinRef);
if (gLogRefNum)
	EndLog(&gLogRefNum);
//if (helpersInited)
//	EndHelpers();
if (xInited)
	XEnd();

Prof_END;
}

