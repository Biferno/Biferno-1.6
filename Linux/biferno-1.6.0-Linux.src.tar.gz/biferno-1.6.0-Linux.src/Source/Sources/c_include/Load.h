/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Load.h,v 1.3 2008-11-27 15:29:07 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "Variable.h"

#define	CUR_LOADING_CLASS_MAGIC_NUMBER	0x7FFFFFFF

typedef struct {
				CStr63				curLoadingClassName;
				DLMRef				curLoadClassMethodList;
				DLMRef				curLoadClassPropertyList;
				DLMRef				curLoadClassPropertyTemporaneousStaticList;
				DLMRef				curLoadClassStaticList;
				//DLMRef				curLoadClassPrototypeList;
				DLMRef				curLoadClassErrorsList;
				long				lastClassID;
				BlockRef			constructorDoc;
				Byte				lastVisibility;
				Boolean				lastIsConstant;
				Boolean				lastIsStatic;
				Boolean				curLoadClassScope;
				} LoadClassRecord;


//XErr	CheckIfDuplicatedParamName(ProtoParam *firstProtoParamP, long totParams, char *newParamName);
//XErr	TokenizePrototype(long api_data, Ptr *tempPPtr, long *lenP, BlockRef memberDocBlock, char *curLoadingClassName, Boolean noLocal);
XErr	PrototypeToBAPI_Doc(long api_data, Ptr *prototypeP, long *lenP, BlockRef memberDocBlock, LoadClassRecord *loadClassRecordP, Boolean isLocal, long type);
//XErr	CheckProtoInfoBlock(BlockRef *protoBlock, ProtoParam **protoParamPPtr, ProtoParam **firstProtoParamPPtr, long totParams);



XErr	GetFunctionInfo(long api_data, Ptr *oldFilePPtr, long *lenP, char *funcName, BlockRef *membIdentBlockP, Boolean *existP);
XErr	DoFunction(long api_data, MemberAction *membIdentP, char *funcName, Ptr *oldFilePPtr, long *lenP, ObjRecordP result);


XErr	BisFunctionsDestructor(DLMRef dlRef, long objID, long varType, long api_data);
XErr	DoFunctionReturn(long api_data, Ptr *oldFilePPtr, long *lenP);

//XErr	LoadBifernoMember(long api_data, char *varName, Ptr *oldFilePPtr, long *lenP);
XErr	LoadBifernoFunction(long api_data, Ptr *oldFilePPtr, long *lenP, Ptr loadClassDataP);

XErr	LoadBifernoClass(long api_data, Ptr *oldFilePPtr, long *lenP);
//XErr	_ArrayLevel(Ptr *oldFilePPtr, long *lenP, long *arraylevelP);
void	FillMemberPrototype(long api_data, BAPI_Doc *memberDocP, char *curLoadClass);
