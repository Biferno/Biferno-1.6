/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Entity.h,v 1.2 2003-07-16 13:19:21 valfer Exp $
	|______________________________________________________________________________
*/
/*#define	kMethodName				1
#define	kPropertName			2
#define	kVariableName			3
#define	kCostantName			4
#define	kFunctionName			5
#define	kClassName				6
#define	kFlowControlName		7
#define	kGenericMemberName		8
*/
XErr	GetEntityName(long api_data, Ptr *oldFilePPtr, long *lenP, char *varName, Boolean noCheck);
Boolean	IsEntityCharValid(int ch, Boolean isFirstChar, Boolean *getReferenceP);
XErr	IsEntityNameValid(char *varName);

