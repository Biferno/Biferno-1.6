/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BfrParser.h,v 1.5 2006-05-19 11:50:03 valfer Exp $
	|______________________________________________________________________________
*/

// Fast parser table
enum {
		kBSlash = 1,	// '\\'		5C
		kAnd,			// '&'		26
		kDQuote,		// '\"'		22
		kQuote,			// '\''		27
		kSlash,			// '/'		2F
		kSmcmm,			// ';'		3B
		kCCurly,		// '}'		7D
		kOCurly,		// '{'		7B
		kComm,			// ','		2C
		kCBrk,			// ')'		29
		kOBrk,			// '('		28
		kDllr,			// '$'		24
		kCR,			// '\r'		0D
		kLF,			// '\n'		0A
		kQMrk,			// '?'		3F
		kSmcln,			// ':'		3A
		kSpace,			// ' '		20
		kTab,			// '\t'		09
		kStar,			// '*'		2A
		kLess,			// '<'		3C
		kOp,			// possible init operators: N,n,|,=,!,>,<,+,-,% e anche &*/
		kNum,			// numbers
		kDecSep,		// '.'
		kAcCh,			// a-z A-Z _ (acceptable name chs)
		stdCh
		};

XErr	AddXLineOfFile(Ptr textP, long fileSize, long the_line, long buffer_id, int encodeMode, int startLine);
long	BfrGetOffset(BifernoRecP bRecP, long currentLen);

Boolean IsComment(Ptr theP, long len);
Boolean IsCommentExt(BifernoRecP bRecP, Ptr *thePPtr, long *lenP, Boolean *newLineP, Boolean *bilateralP, Boolean noNewLine);
Boolean IsCommentExt2(BifernoRecP bRecP, Ptr *thePPtr, long *lenP, Boolean *newLineP, Boolean *bilateralP, Boolean preserveTheNewLine);
Boolean	IsInitTagExt(BifernoRecP bRecP, Ptr *thePPtr, long *lenP);
Boolean	IsEndTag(Ptr theP, long len);
Boolean	IsEndTagExt(BifernoRecP bRecP, Ptr *thePPtr, long *lenP, XErr *errP);

Boolean StopEvaluating(Ptr theP, long len, long *advanceP);

Boolean IsNot(Ptr textP, long len);

int 	RemoveEndChar(Ptr *oldFilePPtr, long *lenP, long flags, long *curLineP, Boolean advance);

void	SkipSmart(BifernoRecP bRecP, Ptr *oldFilePPtr, long *lenP);

#ifdef __LITTLE_ENDIAN__
	#define	INIT_TAG		'?<'
	#define	END_TAG			'>?'
	#define	INIT_COMMENT	0x2A2F
	#define	END_COMMENT		0x2F2A

	#define	EVAL_NEQUA_STR	'=!'
	#define	EVAL_GEQ_STR	'=>'
	#define	EVAL_LEQ_STR	'=<'

	#define	NOT_STR1		'ON'
	#define	not_STR1		'on'
	
	#define	BREAK_LABEL		'aerb'
	#define	CASE_LABEL		'esac'
	#define	ELSE_STR		'esle'
#else
	#define	INIT_TAG		'<?'
	#define	END_TAG			'?>'
	#define	INIT_COMMENT	0x2F2A
	#define	END_COMMENT		0x2A2F

	#define	EVAL_NEQUA_STR	'!='
	#define	EVAL_GEQ_STR	'>='
	#define	EVAL_LEQ_STR	'<='

	#define	NOT_STR1		'NO'
	#define	not_STR1		'no'

	#define	BREAK_LABEL		'brea'
	#define	CASE_LABEL		'case'

	#define	ELSE_STR		'else'
#endif

#define		_NOT				-41
typedef struct {
				ObjRecord	objRef;
				long		operation;
				} EvalObjRef, *EvalObjRefP;

Boolean	IsConstructor(long api_data, Ptr *oldFilePPtr, long *lenP, char *constrName, Boolean lookForTypeCast, long *constrP, Boolean fromInput, Boolean *isSuperP, XErr *errP);
long	IsEvalOperator(Ptr *oldPtrPPtr, long *lenP, Boolean toAdvance, long nextExpected, long *advancePtr);
Boolean IsFlowControlExt(long api_data, Ptr *oldFilePPtr, long *lenP, long *fcIDP, long *entityLengthP);
Boolean	IsInitTagExt2(BifernoRecP bRecP, Ptr *thePPtr, long *lenP);

XErr	ProcessBlock(long api_data, Ptr *textPPtr, long *lenP, long flags);
XErr	SkipBlock(long api_data, Ptr *textPPtr, long *lenP, long flags, char *labelName, long *switchFlagP);
XErr	SkipEntireBlock(long api_data, Ptr *oldFilePPtr, long *lenP, long flags, long curGraphPar, Boolean searchPar);

XErr 	ProcessBisBlock(long api_data, Ptr *textPPtr, long *lenP, long flags, Boolean *blockDoneP);
XErr	SkipBisBlock(long api_data, Ptr *textPPtr, long *lenP, long flags, Boolean *blockDoneP, char *labelName, long *switchFlagP/*, int charToFind, Boolean stopOnBreak*/);

XErr	ProcessBisLine(long api_data, EvalObjRefP operP, long *totElemsP, Ptr *expressPPtr, long *expressLenP, char *varNameP, long flags, long *numParP/*, Boolean *setErrMsgP*/);
XErr	ResolveBisLine(long api_data, EvalObjRefP operP, long totItems, ObjRecordP resultVarRecP, long requestedType, long typeCastType);
XErr 	SkipBisLine(long api_data, Ptr *textPPtr, long *lenP, long flags, Boolean stopOnTernaryQMark, Boolean stopOnLogicAnd);;


