/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: StaticClasses.h,v 1.6 2008-06-13 14:30:08 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef	__STATIC_CLASSES__
	#define __STATIC_CLASSES__

#define	MAX_STATIC_CLASSES	128

void	StaticClasses(void);

XErr	error_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	string_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	char_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	int_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	bool_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	unsigned_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	double_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	array_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	time_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	db_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#ifdef ODBC_BUILT_IN
	XErr	odbc_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif
XErr	reference_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	file_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	folder_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	cacheItem_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	header_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	httpPage_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	request_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	client_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	serverInfo_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	multiPart_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	search_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

XErr	biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	memberInfo_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	classInfo_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	curApp_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	bifernoUnix_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	curScript_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	curFile_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	objSpec_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	BifernoUtils_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

//XErr	BifernoFunctions_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	BifernoAnsi_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

XErr	Math_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	long_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

#ifdef WITH_SENDMAIL
	XErr	sendMail_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif	

// These class are clones for Java
/*#ifdef JAVA_ENABLED
	XErr	jclass_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif*/

/*XErr	float_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	byte_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	short_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
*/

#ifdef CONVERTIMAGE_BUILT_IN
	XErr	ConvertImage_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif	

#if MYSQL_BUILT_IN
	XErr	mysql_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif	
#if POSTGRES_BUILT_IN
	XErr	postgres_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif	

/*#if WITH_POSTGRES
	XErr	postgres_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif*/

#if WITH_OCI
	XErr	boci_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif	

#if __MAC_XLIB__ && WITH_QUICKBASE
	XErr	quickbase_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
#endif

XErr	stackItem_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	collection_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

#endif
