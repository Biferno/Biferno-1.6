/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoEngineAPI.h,v 1.19 2006-07-19 10:23:10 valfer Exp $
	|______________________________________________________________________________
*/

#ifndef __BIFERNO_ENGINE_API__
	#define __BIFERNO_ENGINE_API__

#include "XLib.h"
#include "HTTPMrgNet.h"

#define	SCRIPT_APPLICATION	CACHE_USER_SIGNIFICANT

// Flags for Run
#define	kIsLocalFile			1
#define	kIsAdmin				2
#define	kIsPost					4
#define	kPrefixLengthInResult	8
#define	kOnlyHead				16

typedef struct {
				long		api_data;
				long		scope;
				} BfrDestructRec;

// ObjRef: Object Reference Structure (deve essere lunga LONGS_IN_OBJREF longs)
typedef struct {
				CStr63		resultObjName;
				long		scope;
				long		type;
				} ConstructorAPIdataRec;


/*
When Immediate, value is written in last 3 long (last 12 bytes, pointing from type)
*/
typedef struct {
				long			id;				// the id in the list (or IMMEDIATE_ID)
				long			classID;		// the type (class) of obj
				long			type;			// the type of the object (var or constant)
				long			scope;			// the scope of the object
				long			list;			// the list it belongs to
				} ObjRecord, *ObjRecordP;

// Immediate
#define		MAX_SPACE_FOR_IMMEDIATE		12			// da type in poi
#define		IMMEDIATE_ID				-1

// Write Immediate here
#define		IMM(obj)				((Ptr)&OBJ_TYPE(obj))
#define		IMM_P(objP)				((Ptr)&OBJ_TYPE_P(objP))
#define		IMMLEN_STRLEN(obj)		(*(Byte*)IMM(obj))
#define		IMMLEN_STRLEN_P(objP)	(*(Byte*)IMM_P(objP))

// Macro
#define		IS_IMMEDIATE(obj)			(((ObjRecordP)&obj)->id < 0)
#define		IS_IMMEDIATE_P(objP)		(((ObjRecordP)objP)->id < 0)

#define		OBJ_ID(obj)				(((ObjRecordP)&obj)->id)
#define		OBJ_LIST(obj)			(((ObjRecordP)&obj)->list)
#define		OBJ_CLASSID(obj)		(((ObjRecordP)&obj)->classID)
#define		OBJ_TYPE(obj)			(((ObjRecordP)&obj)->type)
#define		OBJ_SCOPE(obj)			(((ObjRecordP)&obj)->scope)

#define		OBJ_ID_P(objP)			(((ObjRecordP)objP)->id)
#define		OBJ_LIST_P(objP)		(((ObjRecordP)objP)->list)
#define		OBJ_CLASSID_P(objP)		(((ObjRecordP)objP)->classID)
#define		OBJ_TYPE_P(objP)		(((ObjRecordP)objP)->type)
#define		OBJ_SCOPE_P(objP)		(((ObjRecordP)objP)->scope)

#define		OBJREF(objrecord)		(*(ObjRefP)&objrecord)
#define		OBJRECORD(objref)		(*(ObjRecordP)&objref)

#define		OBJREF_P(objrecordP)	((ObjRefP)objrecordP)
#define		OBJRECORD_P(objrefP)	((ObjRecordP)objrefP)

// Valid
#define		VALID_P(objRefP)			(OBJ_ID_P(objRefP) != 0)
#define		INVAL_P(objRefP)			OBJ_ID_P(objRefP) = 0

#define		VALID(objRef)			(OBJ_ID(objRef) != 0)
#define		INVAL(objRef)			OBJ_ID(objRef) = 0

#define		CHECK_RES(objRefP)		((void)0);	//if VALID_P(objRefP)	Debugger();

// Define
#define	kBifernoWaitTimeout		(unsigned long)(1000L * 120L)	// milliseconds (= 120 secs)

#define	BIFERNO_CONFIG		"Biferno.config.bfr"
#define	BIFERNO_MAIN_NAME	"Biferno Main"

#define	BIFERNO_MEMORY_ERROR_FILE	"NO_MEM_BIFERNO_WENT_MONOTHREAD!"

typedef	XErr	(*BAPI_OutputFunc)(void *taskID, Ptr textP, long len);

//void	VersionToString(long version, char *versionStr);

// Init & End
XErr	BEngineAPI_Init(long *maxUsersP, LogCallBack logCallBack, void *userData, Boolean locally, char *messageErr);
XErr	BEngineAPI_End(LogCallBack logCallBack, void *userData, LONGLONG uniqueid);

// Suspend/Resume
void	BEngineAPI_Suspend(void);
void	BEngineAPI_Resume(void);

// Run Event
void	BEngineAPI_Run(void *userData, char *serverName, char *filePath, char *serverBaseDir, BlockRef headInBlock, long headInBlockLen, BlockRef *bodyBlockP, long bodyBlockLen, char *contentType, BlockRef *resultTextP, long *resultSizeP, BAPI_OutputFunc outputFunc, short flags, LONGLONG uniqueID, char *sid, char *appName, XErr *theErrorP);

XErr	BEngineAPI_Flush(LogCallBack logCallBack, void *userData, LONGLONG uniqueid);
XErr	BEngineAPI_Reload(LogCallBack logCallBack, void *userData, LONGLONG uniqueid);
void	BEngineAPI_Emergency(void *userData);
XErr	BEngineAPI_Idle(LogCallBack logCallBack, void *userData);
XErr	BEngineAPI_GetVersions(char *versionStr, char *versionAPIStr, char *xlibVersStr);

XErr	RegisterApplication(char *applicationName, XFilePathPtr applicationPath, BlockRef *resultTextP, long *resultSizeP, Boolean zeroErr, void *userData);

XErr	BifernoStop(LogCallBack	logCallBack, void *userData, long usersToRemain, CmdType cmdType, LONGLONG uniqueid);
XErr	BifernoResume(void);
XErr	BifernoYield(unsigned long *lastTicksP);
XErr	BifernoEnter(void);

long	GetScope(int i);
long 	GetTotScopes(void);

#endif
