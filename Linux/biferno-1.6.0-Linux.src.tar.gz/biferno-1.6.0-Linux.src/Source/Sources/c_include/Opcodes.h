/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Opcodes.h,v 1.4 2008-11-27 15:29:07 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __BIFERNO_OPCODES__
	#define __BIFERNO_OPCODES__

#define	MAX_PARAM2_SIZE	10

#define	SMALL	sizeof(B_Opcode)
#define	LARGE	sizeof(B_OpcodeExt)

//#define	kLastAdded	-1

typedef struct {
		Byte	pos1	:4;
		Byte	pos2	:4;
		} VariantRec;

typedef struct {
		Byte		opCode;
		VariantRec	opVariant;
		short		dest;		//  0 = SP, > 0 -> VL
		} OpcodeHead;
		
typedef struct {
		OpcodeHead	head;
		Byte		params[sizeof(short) + sizeof(short)];
		} B_Opcode;

typedef struct {
		OpcodeHead	head;
		Byte		params[MAX_PARAM2_SIZE + sizeof(short)];
		} B_OpcodeExt;

//#define	BIC_TYPE(objRecP)	(*(short*)&objRecP->type)

#define	PARAM_1_P(p)				((Byte*)((B_Opcode*)p)->params)
#define	PARAM_2_P(p)				((Byte*)((B_Opcode*)((Ptr)p + 2))->params)
#define	PARAM_2_AFTER_LARGE_P(p)	((Byte*)((B_Opcode*)((Ptr)p + 2))->params)

#define	PARAM_1_SHORT(p)		(*(short*)((B_Opcode*)p)->params)
#define	PARAM_2_SHORT(p)		(*(short*)((B_Opcode*)((Ptr)p + 2))->params)
#define	PARAM_2_AFTER_LARGE(p)	(*(short*)((B_Opcode*)((Ptr)p + MAX_PARAM2_SIZE))->params)

#define	IS_BRANCH(p)		((((B_Opcode*)p)->head.opCode == kBra_o) || (((B_Opcode*)p)->head.opCode == kBet_o) || (((B_Opcode*)p)->head.opCode == kBef_o) || (((B_Opcode*)p)->head.opCode == kBnse_o))
// #define	BRANCH_OFFSET(p)	(*(long*)&(((B_Opcode*)p)->head.dest))
#define	BRANCH_OFFSET(p)	((B_Opcode*)p)->head.dest
#define	BRANCH_TESTVAR(p)	*(short*)(((Ptr)&((B_Opcode*)p)->head.dest) + sizeof(long))

#define	IS_SP(objP)			((BIC_OBJREF_SPEC(objP) == kVL_LIST) && (OBJ_ID_P(objP) == SP))

//#define	T_SHORT(p)			(*(short*)p)

// type of opcodes
typedef enum {
		kNop_o = 0,		// nop
		kStore_o,		// Store
		kStoreElem_o,
		kStoreElemN_o,
		//kDecrStack_o,
		//kCopy_o,
		kLoad_o,		// load
		kLoadDefault_o,
		
		kMul_o,			// Operations
		kDiv_o,
		kMod_o,
		kAdd_o,
		kSub_o,
		kShiftL_o,
		kShiftR_o,
		kGreat_o,
		kLess_o,
		kGreatE_o,
		kLessE_o,
		kEqua_o,
		kNotEqua_o,
		kArAnd_o,
		kArOr_o,
		kLogicAnd_o,
		kLogicOr_o,
		kInvert_o,
		
		kExit_o,		// Flow Controls
		kStop_o,
		kDebug_o,
		k_Lock_o,
		k_Unlock_o,
		k_Include_o,
			
		kPrint_o,		// print
		
		kBra_o,			// branch
		kBet_o,
		kBef_o,
		kBnse_o,
		
		kIncr_o,		// incr
		kIncrIndex_o,
		kIncrIndexN_o,
		kIncrProperty_o,
		//kIncrStatPropertyN_o,
		kDecr_o,
		kDecrIndex_o,
		kDecrIndexN_o,
		kDecrProperty_o,
		//kDecrStatPropertyN_o,
		
		kTypeCast_o,
		
		kCall_o,		// invoke, call etc...
		kCallini_o,
		kCallend_o,
		//kInvoke_o,
		kGet_o,
		kGetLeaveOnStack_o,
		kSet_o,
		kSetPutOnStack_o,
		
		kTern_o,
		
		kIndex_o,
		kIndexN_o,
		kIndexLeaveOnStack_o,
		kIndexLeaveOnStackN_o
		} BICOpcode;

/*enum {
		kVLSlot = 1,
		kCLSlot,
		kBooleanImm,
		kStringImm,
		kDoubleImm,
		kLongImm,
		kUnsignedImm,
		kIntImm
	};
*/
/*			// Variant for three params opcodes
		
		kkVLSlotkVLSlot,
		kCLSlot1,			// first is... second is slot (or Stack)
		kBooleanImm1,
		kStringImm1,
		kDoubleImm1,
		kLongImm1,
		kUnsignedImm1,
		kIntImm1,
		kCLSlot2,			// second is... first is slot (or Stack)
		kBooleanImm2,
		kStringImm2,
		kDoubleImm2,
		kLongImm2,
		kUnsignedImm2,
		kIntImm2
		};
*/

XErr	DumpAssembler(BICRecordP bicRecP, long outputID);

XErr	Opcode_typeCast(BICRecordP bicRecP, ObjRecordP source, long requestedClassID, ObjRecordP resultP, long api_data);
XErr	Opcode_store(BICRecordP bicRecP, ObjRecordP objLeftP, ObjRecordP objRightP, ArrayIndexRec *mCoords, long mCoordDim);
//XErr	Opcode_copy(BICRecordP bicRecP, long destID);
XErr	Opcode_load(BICRecordP bicRecP, ObjRecordP objRefP);
//XErr	Opcode_decrstack(BICRecordP bicRecP, long lessStack);
XErr	Opcode_operation(BICRecordP bicRecP, ObjRecordP obj1, ObjRecordP obj2, long opcode, long operation, ObjRecordP resultP, long api_data);
XErr	Opcode_NoParams(BICRecordP bicRecP, long which);
XErr	Opcode_OneParam(BICRecordP bicRecP, ObjRecordP objRefP, long which);
XErr	Opcode_branch(BICRecordP bicRecP, ObjRecordP objRefP, long offset, long which, long api_data);
XErr	Opcode_opposite(BICRecordP bicRecP, ObjRecordP objP, ObjRecordP resultP);
XErr	Opcode_tern(BICRecordP bicRecP, ObjRecordP obj1, ObjRecordP obj2, ObjRecordP obj3, ObjRecordP resultP, long api_data);
XErr	Opcode_get(BICRecordP bicRecP, long sl_index, int totLessStack, Byte *param2, Boolean isExt, Byte variant2, long opCode, long dest);
XErr	Opcode_set(BICRecordP bicRecP, long sl_index, ArrayIndexRec *propertyIndex, int propertyDim, int totLessStack, ObjRecordP value, Boolean putResultOnStack);
XErr	Opcode_invoke(BICRecordP bicRecP, long sl_index, Byte opCode, int totLessStack, long moreStacks, long returnClassID);
//XErr	Opcode_void(BICRecordP bicRecP, long classID, ObjRecordP resultP);
XErr	Opcode_index(BICRecordP bicRecP, ObjRecordP arrayObjrecP, ArrayIndexRec *mCoords, long dim, long opcode, long dest);

long	GetOpcodeSize(B_Opcode *bOpcodeP);

void	MoreStack(BICRecordP bicRecP, int opcodeIndex);
void	LessStack(BICRecordP bicRecP, int opcodeIndex, Boolean decr_incr);
void	NopUnusedOpcode(BICRecordP bicRecP, Ptr opcodesPtr, long opcodeIndex);
Byte	ObjRefIsExt(ObjRecordP objRecP);

void DumpVL(char *opcodeStr, int id);
void DumpCL(char *opcodeStr, int id);
void DumpSL(char *opcodeStr, int id);
void DumpBool(char *opcodeStr, Boolean aBool);
XErr DumpStr(char *opcodeStr, Byte *str);
void DumpDouble(char *opcodeStr, double *r);
void DumpLong(char *opcodeStr, LONGLONG l);
void DumpInt(char *opcodeStr, long val);
void DumpUnsigned(char *opcodeStr, unsigned long val);
#endif
