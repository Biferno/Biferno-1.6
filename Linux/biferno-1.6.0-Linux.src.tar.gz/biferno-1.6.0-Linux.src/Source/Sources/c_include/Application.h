/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Application.h,v 1.6 2008-04-21 12:37:01 tabasoft Exp $
	|______________________________________________________________________________
*/
#define		MAX_APPLICATION_NAME_LEN		255

#define		DEFAULT_MAX_ERRFILES			2048

XErr	ApplNameFromFile(XFilePathPtr filePath, char *applName);
XErr	GetApplication(BifernoRecP bRecP, char *applicationName, long *applicationObjIDP, XFilePathPtr appBasePath, BlockRef configFilePathBl, /*long configFilePathLen, */Boolean *applicationFirstTimeP, Boolean *dontIncludeServerP, XFilePathPtr filePathErr);
XErr	CloseApplication(Application *applP, Boolean deleteAlsoObj, LogCallBack logCallBack, void *userData, BlockRef *curSessionCSP);
XErr	ScanTreeForConfig(XFilePathPtr filePath, BlockRef *configPathsP, long *configPathsLenP, char *applicationName, XFilePathPtr applicationBasePath, Boolean mustFind);
XErr	UpdateApplicationRec(BifernoRecP bRecP);
XErr	CloseAllApplications(LogCallBack logCallBack, void *userData);
//XErr	DumpServersLists(LogCallBack logCallBack, long userData);
Boolean	DontServeErrorsFile(BifernoRecP bRecP, XFilePathPtr filePath);
void	GetApplicationPerstPath(char *appName, char *xName, char *sName);

XErr	FlushAppWithChildren(char *curAppBasePath, Boolean doReload, BlockRef *curSessionCSP);

XErr	GetApplicationBlock(char *applicationName, BlockRef *appBlockP);
