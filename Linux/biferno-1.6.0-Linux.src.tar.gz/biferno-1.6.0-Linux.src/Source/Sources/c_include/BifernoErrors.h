/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoErrors.h,v 1.4 2008-06-13 14:29:46 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "Flower.h"

XErr	UpdateErrObject(long api_data, XErr theError, ObjRecord *resultErrObjRefP, Boolean *canResumeP);

XErr	NewMsgRecord(long api_data, char *title, char *msg, long msgLen, long flags);
XErr	PrintMsgRecords(long api_data, long bufferID, long encodeMode);
/*XErr	ResetMsgRecords(long api_data);
XErr	GetTheLastMsgRecord(long api_data, char *title, char *msg);
long	GetTotMsgRecords(long api_data);
void	SetTotMsgRecords(long api_data, long msgRecLevel);
void	SetTotMsgInRecords(long api_data, long msgRecLevel);
XErr	GetMsgRecords(long api_data, ErrorMsgRecord *errMessageRecP);
XErr	SetMsgRecords(long api_data, ErrorMsgRecord *errMessageRecP);
*/

XErr	PrintStack(BifernoRecP bRecP, BufferID output);

XErr	BfrLessStack(BifernoRecP bRecP, BAPI_Doc *bisFunctionP);
XErr	BfrMoreStack(BifernoRecP bRecP, BAPI_Doc *bisFunctionP);

XErr	BfrMoreIncludeStack(BifernoRecP bRecP, char *includeFile, int curLine);
XErr	BfrLessIncludeStack(BifernoRecP bRecP);

StackRecord*	BfrGetIndStack(BifernoRecP bRecP, int index);
DLMRef		BfrGetIndStackList(BifernoRecP bRecP, int index);
XErr	BfrStackDisposeLocals(BifernoRecP bRecP);
//XErr	FillStack(BifernoRecP bRecP, BAPI_Doc *bisFunctionP, char *filePath, long line, char *altName);
//long	GetSP(BifernoRecP bRecP);
//XErr	RemoveLastStackItem(BifernoRecP bRecP);

void	Err2BAPIErr(long api_data, XErr *theErrorP, char *subErrStr);
void	FillErrorStrings(long api_data, long lastClassErrCalled, XErr theError, char *errNumStr, char *eNameStr, char *errType, char *subErrStr, char *errLineStr, char *descr, Boolean *resumableP);
