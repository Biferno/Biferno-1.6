/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Dispatcher.h,v 1.22 2008-11-27 15:27:48 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __QWSCLASSLAYER__
	#define __QWSCLASSLAYER__

#include "XLib.h"

#define	MAX_ARRAY_LEVEL			AE_LEVEL_LIMIT
#define	MAX_PROTO_ARRAY_LEVEL	MAX_ARRAY_LEVEL-1

#include "Variable.h"
//#define	GET_PLUGINREC(varRecP)			&gClassRecordBlockP[(varRecP)->classID-1]
#define		GET_PLUGINREC(type)	&gClassRecordBlockP[type-1]

//#define BUILTIN_PROPERTY_MAGIC_NUMBER	0x7FFFFFFF

typedef	Biferno_Dispatch 	ClassesEntryPoint;

// Session Garbage Collection
#define	SESSION_GARBAGE_COLLECTION_INTERVAL		(60L * 2L)	// 2 min

#ifdef __LITTLE_ENDIAN__
	#define	ONE_ARRY_LEVEL	']['
#else
	#define	ONE_ARRY_LEVEL	'[]'
#endif

//#define	FOR_ADDRESS_INVALID_LENGTH		-1

typedef struct {
				LogCallBack 	logCallBack;
				void 			*userData;
				Boolean			macosxBundle;
				Byte			unused;
				short			unused2;
				} LogRec;

typedef struct {
				Boolean						macosxBundle;
				Boolean						moreDispatcher;
				short						pad2;
				
				CStr255						constructorString;
				long						dllRef;
				long						pluginBAPIVersion;
				long						pluginXLibVersion;
				//long						code_type;		// Java, C etc...
				short						pluginMacOSResourceFork;
				short						totErrors;
				long						pluginID;		// index
				long						extendedPluginID;
				CStr63						extendedClass;
				ClassesEntryPoint			the_entryPoint;
				long						pluginType;
				CStr63						pluginName;
				uint32_t					plugin_global_data;
				DLMRef						membersList;
				DLMRef						symbolList;
				long						baseError;
				long						objBaseError;
				Boolean						wantDestructor;
				Boolean						successfull;
				Byte						compare_priority;
				Boolean						dynamic;
				BlockRef					constructor;		// BlockRef to BAPI_Doc
				BAPI_ModifyHook				modifyHook;
				BAPI_ScopeAllowedHook		scopeAllowedHook;
				BAPI_IncrementHook			incrementHook;
				
				// Java
				//CStr63					java_className;

				Boolean						fixedSize;
				Boolean						errorRegistered;
				short						oper_priority;
				} PluginRecord, *PluginRecordP;
				
typedef struct {
				BlockRef		classRecordBlock;	// blocco di memoria contenente le descr dei plug-in (i PluginRecord)
				long			totClass;
				
				long			javaHelperRef;
				/*long			boolConstructor;
				long			intConstructor;
				long			unsignedConstructor;
				long			longConstructor;
				long			doubleConstructor;
				long			charConstructor;
				long			stringConstructor;*/
				long			arrayConstructor;
				DLMRef 			classListRef;
				DLMRef			reservedKeyword;
				DLMRef			flowControls;
				DLMRef			functionsList;
				DLMRef			globApplicationListArray;
				DLMRef			errorList;
				//DLMRef		prototypes;
				
				
				BlockRef		printDocBlock;	// MemberAction
				
				//long			printPlugID;
				//long			printFuncID;
				//long			printObjID;
				
				//Byte			theDecSep;
				//Byte			theThousSep;
				short			pad2;
				Boolean			cacheItemIsFixed;
				Boolean			stackItemIsFixed;
				//long			cacheItemConstructor;
				long			errConstructor;
				long			multipartConstructor;
				long			httpPageConstructor;
				long			refConstructor;
				
				long			maxUsers;
				//long			totMemoryPerUserSize;
				
				// Pool
				PoolRef			evalPool;
				PoolRef			bifernoRecPool;
				PoolRef			paramBlockPool;
				PoolRef			processObjectPool;
				PoolRef			memberLoopPool;
				PoolRef			notifySuperIsChangedPool;
				PoolRef			bifernoClassPool;
				PoolRef			cacheResPool;
				PoolRef			threadDataPool;
				PoolRef			propertyActionPool;
				} DispatcherData, *DispatcherDataP;

typedef struct {
			char	name[64];
			long	value;
			} NameValueRec;

typedef struct {
				CStr63		name;
				CStr255		value;
				CStr255		comment;
			} ApplVarDefaultRec;

XErr	CopyObjectExt(long api_data, ObjRefP sourceObj, char *resultObjName, long scope, long type, ObjRefP destObj);
XErr	BufferToObjExt(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, char *resultObjName, long scope, long type, ObjRefP objRefP);
XErr	ArrayToObjExt(long api_data, Boolean fixedSize, char *resultObjName, long scope, long type, ParameterRec *varRecsP, long totVars, long *errElemIDXP, ObjRefP objRefP);

XErr	GetContructorDoc(long api_data, long classID, BAPI_Doc **docP);
Boolean WantCloneEvent(PluginRecord* plugRecP, Boolean *extendsP);

XErr	CL_Init(LogCallBack	logCallBack, void *userData, long maxUsers);
XErr	CL_ShutDown(LogCallBack	logCallBack, void *userData);
XErr	CL_Run(PluginRecord	*plugRecP, Biferno_ParamBlock *pbPtr);
XErr	CL_Exit(PluginRecord *plugRecP, Biferno_ParamBlock *pbPtr);

XErr	CL_Constructor(long api_data, long scope, long type, char *resultObjName, long classID, ParameterRec *varRecsP, long totVars, BAPI_Doc *docP, ObjRecord *resultObjRefP);
XErr	CL_Clone(long api_data, long scope, long type, char *resultObjName, long classID, ParameterRec *varRecsP, long totVars, long requestedElementClass, Boolean cloneTarget, ObjRecord *resultObjRefP);
XErr	CL_Destructor(long api_data, ObjRecord *varRecP);
XErr	CL_TypeCast(long api_data, ObjRecordP source, long requestedClassID, ObjRecordP dest, long typeCastType);

XErr	CL_GetInt(long api_data, ObjRecordP varRecP, long *longP, long typeCastType);
XErr	CL_GetLong(long api_data, ObjRecordP varRecP, LONGLONG *llongP, long typeCastType);
XErr	CL_GetUnsigned(long api_data, ObjRecordP varRecP, unsigned long *ulongP, long typeCastType);
XErr	CL_GetDouble(long api_data, ObjRecordP varRecP, double *doubleP, long typeCastType);
XErr	CL_GetBoolean(long api_data, ObjRecordP varRecP, Boolean *boolP, long typeCastType);
XErr	CL_GetString(long api_data, ObjRecordP varRecP, char *stringP, long *stringLenP, long maxStorage, long typeCastType, short variant);
XErr	CL_GetChar(long api_data, ObjRecordP varRecP, char *theChar, long typeCastType);

XErr	CL_IntToObj(long api_data, long aLong, ObjRecordP varRecP);
XErr	CL_LongToObj(long api_data, LONGLONG l, ObjRecordP varRecP);
XErr	CL_UnsignedToObj(long api_data, unsigned long uLong, ObjRecordP varRecP);
XErr	CL_DoubleToObj(long api_data, double r, ObjRecordP varRecP);
XErr	CL_BooleanToObj(long api_data, Boolean boolVal, ObjRecordP varRecP);
XErr	CL_StringToObj(long api_data, char *stringP, long stringLen, long type, ObjRecordP varRecP);
XErr	CL_CharToObj(long api_data, char theChar, ObjRecordP varRecP);
//XErr	CL_BufferToObj(long api_data, char *buffP, long buffLen, long requestedClassID, ObjRecordP varRecP);

XErr	CL_ExecuteOperation(long api_data, ObjRecordP item1, ObjRecordP item2, long operation, ObjRecordP resultVarRecP);
XErr	CL_Increment(long api_data, ObjRecord *objRef, Boolean toDecr);
XErr	CL_Opposite(long api_data, ObjRecord *objRefP, ObjRecord *resultP);
XErr	CL_ExecuteMethod(long api_data, MemberAction *membActionP, ParameterRec *paramVarsP, long totParams, ObjRecordP resultVarRecP, Boolean *sideEffectP);
XErr	CL_ExecuteFunction(long api_data, MemberAction *membActionP, char *funcName, ParameterRec *paramVarsP, long totParams, ObjRecordP resultVarRecP);
XErr	CL_GetProperty(long api_data, MemberAction *membActionP, long propertyDim, ArrayIndexRec *propertyIndex, ObjRecordP resultVarRecP);
XErr	CL_SetProperty(long api_data, MemberAction *membIdentP, long propertyDim, ArrayIndexRec *propertyIDX, ObjRecordP value);

XErr	CL_Accessor(long api_data, long classID, long message, Biferno_ParamBlockPtr paramBlockPtr);
XErr	CL_GetErrMessage(long api_data, long classID, long theError, char *errName, char *errMessage, char *errType);
//XErr	CL_GetSuperObj(long api_data, ObjRecord *objRef, ObjRecord *superObjRef);
XErr	CL_SuperIsChanged(long api_data, ObjRecord *objRef, char *propertyName);

XErr	_FillList(DLMRef list, NameValueRec *keywords, long tot);

XErr	CreateEmptyObject(long api_data, char *nameP, DLMRef list, long theScope, long classID, long arrayLevel, long arrayElementClassID, long finalFlags, Boolean canBeImmediate, ObjRecord *resultObjRefP);

Boolean	ContainsReference(ObjRecord *objRefP);
Boolean	WantDestructorFromObj(ObjRecord *varRecP);
Boolean	WantDestructorFromClass(long classID);

PluginRecord* GetPluginRecFromClassID(Biferno_ParamBlock *pbPtr, long classID);

// Utils
//void	VersionToString(long version, char *versionStr, Boolean alsoDev);
//XErr	CheckIfDuplicatedParamName(ProtoParam *firstProtoParamP, long totParams, char *newParamName);
//XErr	TokenizePrototype(long api_data, Ptr *tempPPtr, long *lenP, Boolean *dontCheckNumParamsP, BlockRef *protoParamBlockP, long *totParamsP, char *curLoadingClassName, Boolean noLocal);
//XErr	ParamNamesFromPrototype(char *prototype, MemberRecord *membRecP);
//XErr	SetMyType(Biferno_ParamBlockPtr pbPtr, ObjRecord *objRefP, long destClassID);
//XErr	CheckProtoInfoBlock(BlockRef *protoBlock, ProtoParam **protoParamPPtr, ProtoParam **firstProtoParamPPtr, long totParams);

//XErr	BeforeModify(long api_data, long list, long id);
//XErr	AfterModify(long api_data, long list, long id);

XErr	ModifyObjCheckDestructors(long api_data, DLMRef destList, long destObjID, long destclassid, long destScope, DLMRef valueList, long valueID, long valueClassID);
XErr	ModifyObjBufferCheckDestructors(long api_data, DLMRef destList, long destObjID, long destclassid, long destScope, void* dataP, long dataLen, long classID);

XErr	SetDefault(long api_data, ParameterRec *newParamP, char *paramDefaults, BAPI_ParameterDoc *protoParamP);

//XErr	CheckSetProperty(MemberIdentification *membIdentP);
XErr	CheckSetProperty(MemberAction *membActionP);

XErr	CreateEmptyArray(char *nameP, DLMRef list, long arrayLevel, long arrayElementClassID, long finalFlags, long *destIDP);

// Hooks
BAPI_ModifyHook			GetModifyHook(long classID);
BAPI_IncrementHook		GetIncrementHook(long classID);
#endif
