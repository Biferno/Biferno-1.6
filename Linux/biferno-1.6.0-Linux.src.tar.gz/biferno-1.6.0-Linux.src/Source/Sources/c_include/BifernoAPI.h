/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoAPI.h,v 1.75 2008-11-27 15:27:48 tabasoft Exp $
	|______________________________________________________________________________
*/
/** @file
* 	BAPI Definitions
*
*	This file contains definitions for BAPI (Biferno Application Programming Interface).
*
*	Copyright (c) 2001, Tabasoft Sas
*
*	$RCSfile: BifernoAPI.h,v $
*	$Date: 2008-11-27 15:27:48 $ 
*	$Revision: 1.75 $
*
*	Valerio Ferrucci
*/


#ifndef __BAPIBIFERNO__
	#define __BAPIBIFERNO__

//#if GENERATINGPOWERPC
//#pragma options align=powerpc
//#endif

// XLib
#include "XLib.h"

//===========================================================================================
// CONSTANTS
//===========================================================================================

// The current versions of Biferno API (BAPI)
#define CUR_BIFERNO_API_VERSION			(unsigned long) 0x00010005	// Do NOT modify this value (Biferno 1.3)

// BifernoAdmin Names
#define	BADMIN_FOLDER		"bifernoadmin"
#define	BADMIN_FOLDER_LEN	12
#define	BFDOC_PATH			"bifernoadmin/bfdoc/index.bfr?page=reference.bfr&className="

// Limits
#define		MAX_CLASS_ELEM_LENGTH		63	// max length of member name class
#define		MAX_VARIABLE_NAME_LENGTH	63	// max length of a variable name
#define		MAX_ARRAYINDEX				8	// max number of multiple array (i.e myArray[][][][][][]...)
#define		MAX_EXPRESSINPARENT			32	// max number of element in an expression evaluation (a + b + c / g ...)

// Prefix for absolute paths
#define		FILE_HD_PREFIX				"file:/"
#define		FILE_HD_PREFIX_LEN			6

// Errors type (XLib has number 1 and 2)
#define		kBAPI_Error					3
#define		kBAPI_ClassError			4

// Ae level for generic array ptototypes
#define		AE_LEVEL_LIMIT				16

// First erro number of Biferno
#define 	BIFERNO_BASE_ERROR			1

// Priority in operations are between 0 and MAX_OPER_PRIORITY
#define		MAX_OPER_PRIORITY			9

// Redir page for session/cookie variables
#define		BIFERNO_REDIR		"/bifernoadmin/bifernoredir.bfr"
#define		BIFERNO_DENY		"/bifernoadmin/bifernodeny.bfr"

// ClassID for "obj"
#define	CLASSID_UNSPECIFIED				0x7FFFFFFE

// Flags for BAPI_NewMsgRecord
#define	kInputIsClassName	1L
#define	kInputIsClassID		2L
#define	kInputIsObj			4L
//#define	kOnlyIfEmpty			4L

// Titles for BAPI_NewMsgRecord
#define	kDOING			"while processing:"
#define	kEXECUTING_OP	"while executing operation:"
#define	kDOINGURL		"while processing url:"
#define	kMEMBER			"while processing member:"
#define	kSETPROPERTY	"while setting property:"
#define	kPARAMETER		"while processing parameter with name:"
#define	kCLASS			"while calling class:"
//#define	kMETHOD			"while operating on method:"
//#define	kFUNCTION		"while executing function of prototype:"
//#define	kCONSTRUCTOR	"while operating on constructor:"
#define	kHINT			"maybe you intend:"
#define	kPROTOTYPE		"correct prototype is:"
#define	kCLASS_BAD		"while searching for class:"
#define	kFUNCTION_BAD	"while searching for function:"
#define	kTYPECAST		"while typecasting:"
#define	kVARIABLE		"while processing variable:"
#define	kLABEL_BAD		"while searching for label:"
#define	kFILE_BAD		"while looking for file:"
#define	kBIFERNOCONFIG	"while processing Biferno.config.bfr:"
#define	kADVICE			"hint:"
#define	kNote			"note:"


#define	LONGS_IN_OBJREF	5

// Error messages
#define		MAX_ERR_MSG				1
#define		MAX_ERROR_MSG_LENGTH	127

typedef struct {
				CStr63		title;
				char		msg[MAX_ERROR_MSG_LENGTH + 1];
				} ErrorMsgItem;

typedef struct {
				long				totMsg;
				/*Boolean				varNameSet;		// internal (don't use!)
				Byte				pad1;
				short				pad2;*/
				ErrorMsgItem		msg[MAX_ERR_MSG];
				} ErrorMsgRecord;

//===========================================================================================
// STRUCT/UNIONS
//===========================================================================================

// ObjRef: Object Reference Structure
typedef struct {
				long		opaque[LONGS_IN_OBJREF];
				} ObjRef, *ObjRefP;

// Parameter
typedef struct {
				CStr63			name;
				ObjRef			objRef;
				long			privateData;	// don't use this
				} ParameterRec, *ParameterRecP;

// Array index definition
typedef struct {
				long			ind;
				CStr63			ind_name;
				} ArrayIndexRec;

// Member/Function definition
typedef struct {
				CStr63			name;
				long			value;
				CStr255			prototype;
				} BAPI_MemberRecord;

// Info about a class
typedef struct {
				CStr63			name;
				CStr255			sourceFilePath;
				long			id;
				Boolean			wantDestructor;
				Boolean			pad;
				Boolean			canHavePersistent;
				Boolean			cloneObjects;
				long			implem;
				long			extendedClassID;
				} BAPI_ClassInfo;

// Description of names
typedef struct {
				CStr63		name;
				} BAPI_Name;

// Documentation of Biferno methods, functions, property etc...
typedef struct	{
				CStr63			name;
				CStr63			defaultStr;
				long			classID;
				long			targetClassID;	// if classID is ref
				long			aeClassID;
				short			aeLevel;
				short			pad;
				} BAPI_ParameterDoc;

typedef struct	{
				long				classID;		// class owning the method
				Boolean				varArgs;
				Boolean				noNames;
				Byte				pad;
				Byte				visibility;
				} BAPI_MethodDoc;

typedef struct	{
				long				classID;		// class owning the property
				CStr255				defaultStr;
				Boolean				isConst;
				Byte				visibility;
				short				pad1;
				} BAPI_PropertyDoc;

typedef union	{
				BAPI_MethodDoc		method;
				BAPI_PropertyDoc	property;
				} BAPI_MemberDoc;

typedef struct	{
				// C Classes
				long				pluginID;		// plugin declaring the member (can be different from class id owning the member)
				long				val;			// val assigned by the C class to this member
				} BAPI_CIdent;

typedef struct	{
				// Biferno Classes
				CacheResult			sourceFile;		// file in which the member is declared
				long				fileLine;		// line of sourceFile (only for user funcs)
				long				fileOffset;		// offset in file where this func begins
				long				funcLength;
				long				list;			// DLM list containing this member
				} BAPI_Bifernoident;

typedef union	{
				BAPI_CIdent			c;
				BAPI_Bifernoident	b;
				} BAPI_Ident;

typedef struct	{
				long				len;			// len of this block
				long				type;			// kMethod, kProperty, kFunction, kError, kConstant
				CStr63				name;
				CStr255				prototype;
				long				returnClassID;
				long				returnAeLevel;
				long				returnAeClass;
				Boolean				isStatic;		// meaningless if kFunction
				Boolean				isBuiltIn;		// reserved
				Boolean				isDynamic;
				Boolean				pad;
				long				implem;			// kCdll or kBifernoClass
				BAPI_Ident			ident;			// union depending from implem
				BAPI_MemberDoc		info;
				BlockRef			xmlStuff;		// a BAPI_Descr block (see BAPI_Descr below)
				long				totParams;		// 0 for properties
				BAPI_ParameterDoc	params[1];		// variable length (0 for property, constant and error)
				} BAPI_Doc;

typedef struct	{
				long				off;
				long				len;
				} BAPI_Pos;
				
typedef struct	{
				long			totlen;
				BAPI_Pos		purpose;
				BAPI_Pos		descr;
				BAPI_Pos		returns;
				BAPI_Pos		errors;
				BAPI_Pos		seeAlso;
				BAPI_Pos		note;
				BAPI_Pos		params[1];
				// ... follows the text (if any)
				} BAPI_Descr;
				
// Hooks
// check if a scope (other than LOCAL GLOBAL TEMP) is allowed
typedef XErr	(*BAPI_ScopeAllowedHook)(long api_data, ObjRefP objP, long scope, Boolean *allowedP);
// trap Biferno modify
typedef XErr	(*BAPI_ModifyHook)(long api_data, ObjRefP varToSet, ObjRefP value);
// trap Biferno unary operation
typedef XErr	(*BAPI_IncrementHook)(long api_data, ObjRefP varToIncrement, Boolean isDecr);

// Register Event Record
typedef struct {
				unsigned long		api_version;			// in
				long				pluginID;				// in
				long				maxUsers;				// in
				short				macOSResRefNum;			// in
				Boolean				bifernoInLocalMode;		// in
				Boolean				pad1;
				
				long				pluginType;				// out
				CStr63				pluginName;				// out
				CStr255				pluginDescr;			// out
				CStr255				pluginVersionStr;		// out
				CStr255				constructor;			// out
				CStr63				extendedClass;			// out
				Boolean				wantDestructor;			// out
				Boolean				fixedSize;				// out
				Boolean				dynamic;				// out
				Boolean				pad2;
				long				nextBAPI_Dispatch;		// out (really is a Biferno_Dispatch)
				// Hooks
				BAPI_ScopeAllowedHook	scopeAllowedHook;	// out
				BAPI_ModifyHook			modifyHook;			// out
				BAPI_IncrementHook		incrementHook;		// out
				} RegisterRec;

// Run Event Record
typedef struct {
				CStr255			serverName;				// in
				BlockRef		headInBlock;			// in
				long			headInBlockLen;			// in
				BlockRef		postBlock;				// in
				long			postBlockLen;			// in
				Boolean			shuttingDown;			// in
				Boolean			pad1;	//ex localScript;			// in
				short			pad2;
				} RunRec;

// Constructor/TypeCast/Clone Event Record
typedef struct {
				long			privateData;
				ParameterRec	*varRecsP;				// in
				long			totVars;				// in
				Byte			typeCastType;			// in (for TypeCast only)
				Boolean			cloneTarget;
				short			pad2;
				ObjRef			resultObjRef;			// out
				} ConstructorRec;

// Destructor Event Record
typedef struct {
				ObjRef 			objRef;					// in
				} DestructorRec;

// ExecuteOperation Event Record
typedef struct {
				ObjRef			objRef1;				// in
				ObjRef			objRef2;				// in
				ObjRef			resultObjRef;					// out
				long			operation;				// in
				} ExecuteOperationRec;

// Opposite Event Record
typedef struct {
				ObjRef			objRef;					// in
				ObjRef			resultObjRef;			// out
				} OppositeRec;

// ExecuteMethod Event Record
typedef struct {
				ObjRef			objRef;					// in
				long			methodID;				// in
				CStr63			methodName;				// in
				ParameterRec 	*paramVarsP;			// in
				long			totParams;				// in
				BAPI_Doc		*bapiDocP;				// in
				ObjRef			resultObjRef;			// out
				Boolean			sideEffect;				// out
				Boolean			pad1;
				short			pad2;
			} ExecuteMethodRec;

// GetProperty Event Record
typedef struct {
				ObjRef			objRef;					// in
				long			propertyID;				// in
				CStr63			propertyName;			// in
				long			propertyDim;			// in
				ArrayIndexRec	*propertyIndex;			// in
				Boolean			isConstant;
				Byte			pad;
				short			padShort;
				BAPI_Doc		*bapiDocP;				// in
				ObjRef			resultObjRef;			// out
			} GetPropertyRec;

// SetProperty Event Record
typedef struct {
				ObjRef			objRef;					// in
				long			propertyID;				// in
				CStr63			propertyName;			// in
				long			propertyDim;			// in
				ArrayIndexRec	*propertyIndex;			// in
				BAPI_Doc		*bapiDocP;				// in
				ObjRef			value;					// in
			} SetPropertyRec;

// Primitive_String struct of PrimitiveRec
typedef struct {
				char			*stringP;
				long			stringLen;
				long			stringMaxStorage;
				short			variant;
				short			pad2;
				} Primitive_String;

// PrimitiveUnion struct of PrimitiveRec
typedef union {
				long				intValue;
				LONGLONG			longValue;
				unsigned long		uIntValue;
				double				doubleValue;
				Boolean				boolValue;
				Primitive_String	text;
				char				theChar[2];
				} PrimitiveUnion;

// Primitive Event Record
typedef struct {
				long				typeCastType;			// in (implicit or explicit)
				ObjRef				objRef;					// in
				long				resultWanted;			// in
				PrimitiveUnion		result;					// out
				} PrimitiveRec;

// GetErrMessage Event Record
typedef struct {
				long				err;					// in
				CStr255				errMessage;				// out
				} GetErrMessageRec;

// SuperIsChanged Event Record
typedef struct {
				ObjRef				objRef;					// in
				CStr63				propertyName;			// in
				} SuperIsChangedRec;

// Biferno_PB_Union of param block
typedef union {
				RegisterRec			registerRec;
				RunRec				runRec;
				ConstructorRec		constructorRec;
				DestructorRec		destructorRec;
				ExecuteOperationRec executeOperationRec;
				OppositeRec			oppositeRec;
				ExecuteMethodRec	executeMethodRec;	
				GetPropertyRec		getPropertyRec;
				SetPropertyRec		setPropertyRec;
				PrimitiveRec		primitiveRec;
				GetErrMessageRec	getErrMessageRec;
				SuperIsChangedRec	superIsChangedRec;
				} Biferno_PB_Union;

// Biferno Param Block
typedef struct {
				uint32_t			api_data;			// private
				uint32_t			*plugin_global_dataP;
				uint32_t			*plugin_run_dataP;
				CStr255				error;
				Biferno_PB_Union	param;
				} Biferno_ParamBlock, *Biferno_ParamBlockPtr;


//===========================================================================================
// ENUMS
//===========================================================================================

// Primitive classes
enum {
		kBooleanClassID = 1,
		kStringClassID,
		kDoubleClassID,
		kLongClassID,
		kUnsignedClassID,
		kIntClassID,
		kCharClassID
		};

// visibility
enum {
		kPublic = 0,
		kPrivate,
		kProtected
};

// Object type
enum {
		VARIABLE = 10,
		CONSTANT
		};

// Messages sent to plugins
/*
Note:	the kExit event is the last event (for a single script) sent to a BAPI class,
		except for kDestructor and kPrimitive. kDestructor and kPrimitive can be sent at unspecified time.
		This is important to know if a class allocates pointer
		in kRun (and put in plugin_run_dataP) and dispose of it in kExit. 
		Such a class must know that its "plugin_run_dataP" pointer can be invalid in
		the kDestructor and kPrimitive event.
*/
typedef enum {
		kRegister,
		kInit,
		kShutDown,
		kRun,
		kExit,
		kConstructor,
		kTypeCast,
		kClone,
		kDestructor,
		kExecuteOperation,
		kOpposite,
		kExecuteMethod,
		kExecuteFunction,
		kGetProperty,
		kSetProperty,
		kPrimitive,
		kGetErrMessage,
		kSuperIsChanged
		} Biferno_Message;

// Object's list type
enum{
		kNamedList = 1,
		kNamedCSList,
		kNoNamedList
		};

// Object scope
enum {
		TEMP = 16,
		LOCAL,
		GLOBAL,
		APPLICATION,
		SESSION,
		PERSISTENT
		};

// plugins type
enum {
		kCImplementation = 1,
		kBifernoImplementation
	};

// process status
enum {
		kRUNNING = 0,
		kSTOPPED,
		kEXITED
	};

typedef struct {
		CStr63		name;
		CStr255		descr;
		Boolean		resumable;
		Byte		pad1;
		short		pad2;
		} BAPIErrorRecord;

typedef struct	{
	XFilePath	filePath;
	long		line;
	CStr255		prototype;
	long		classOwner;
	long		localList;
	long		includeStackPointer;
	long		totInputs;
	long		bisFunctionInitLine;
	ObjRef		thisObjRef;
} StackRecord;

typedef struct	{
	XFilePath	filePath;
	long		line;
} IncludeStackRecord;

enum{
		// OS
		Err_OSError = BIFERNO_BASE_ERROR,			// Operating System error (see err.subErr and err.subErrStr for details)

		// Generic
		Err_FileNotFound,							// The requested file was not found
		Err_FolderNotFound,							// The requested path doesn't exist
		Err_BadSyntax,								// Invalid syntax
		Err_UndefinedIdentifier,					// An identifier with this name doesn't exists
		Err_InvalidIndex,							// A variable with this name doesn't exist
		Err_NoSuchClassOrFunction,					// A class or function with this name doesn't exist
		Err_StringTooLong,							// The string is too long
		Err_InvalidScope,							// This scope is invalid (possible scopes are: local, global, application, session, persistent)
		Err_IllegalScopeForObject,
		Err_ScopeConflict,
		Err_Timeout,								// The script duration exceeded the timeout period
		Err_IllegalFlowControl,						// This flow control is inappropriate here
		Err_IllegalConstantExpression,
		UserBreak,									// Programmer stopped execution to debug script
		Err_AbsolutePathRequired,					// An absolute (not relative) path is required
		Err_InvalidEscapeSequence,
		
		// Error on requests
		Err_BadSyntaxInURL,							// Invalid syntax in url
		Err_HTTPBodyTooLong,						// The size of POST data is greater then MAX specified in form action
		Err_MultipartObjectDuplicated,				// A multipart objects with this name already exists from POST data
				
		// Expressions parsing
		Err_CommaOrRoundSquareExpected,				// Character "," or ")" was expected
		Err_OperatorExpected,						// An operator (and not an identifier) was expected
		Err_EndOfLineOrSemicolonExpected,			// End of line or ";" was expected
		Err_QuotesExpected,							// Quotas (' or " ) expected
		Err_UnknownOperator,						// Biferno doesn't recognize this operator 
		Err_TooManyVariablesInExpression,			// An experession can't contain more than 32 items
		Err_EmptyExpression,						// The expression can't be empty
		
		// Expressions
		Err_IllegalOperation,						// Operation not permitted
		Err_IllegalOperationOnConstant,				// Constant variables cannot be modified
		Err_IllegalOperationOnMethod,				// Can't operate on a method
		Err_IllegalAssignment,						// Assignment of a void object

		// Arrays
		Err_BadArrayIndex,							// The index of the array is invalid (<= 0 or string where required numeric)
		Err_ArrayRequired,							// Invalid reference with index ([]) of a non-array variable
		Err_ArrayElementNotFound,					// An array element with this name doesn't exist
		Err_OutOfBoundary,							// The index exceeded the limits of the array
		Err_DuplicatedArrayElemName,				// An array element with this name already exists
		Err_ArrayElementsTypeCastFailed,			// The typecast of the object to the array elem class failed
		Err_IllegalArrayInURL,						// never used
		
		// Published Vars
		Err_VariableNotPublished,					// The variable with this name was not published
		Err_VariableNotDefined,						// A variable with this name was not found
		Err_VariableNotInitialized,
		
		// Application
		Err_BifernoConfigNotFound,					// A "Biferno.config.bfr" file was not found
		Err_ApplicationNameNotFoundInConfig,		// The "Biferno.config.bfr" file didn't declare the APPLICATION_NAME variable
		Err_ApplicationNameTooLong,					// The name of the application is too long (> 255)
		Err_ApplicationNameDuplicated,				// An application with this name already exist
		Err_BadSyntaxInApplicationName,				// The "Biferno.config.bfr" declaration of "APPLICATION_NAME" was not correct			
		Err_NoSuchApplication,						// An application with this name doesn't exist
		
		// Session
		Err_BadBifernoSID,							// The BifernoSID string contains invalid character
		Err_SessionIsDisabled,						// Seesion are disabled (set application SESSION to true)
		Err_InvalidSessionCookie,					// The cookie sent from the user agent (BIFERNO_SID) is invalid
		Err_CookieDisabled,							// The user agent has cookie disabled (throwed only by bifernoadmin redir or deny)
		
		// Persistent
		Err_ObjectCantBePersistent,					// The variable belong to a class incompatible with persistent scope
		
		// Run error (should never happen)
		Err_PageOutNotDefined,						// Variable global pageOut is not correctly initialized
		Err_PageInNotDefined,						// Variable global pageIn is not correctly initialized
		
		// Goto
		Err_LabelNotFound,							// The requested label to go was not found
		Err_DuplicatedLabel,						// The label must be unique
		
		// Include
		Err_TooManyIncludes,
		
		// Functions
		Err_ReturnValueRequired,					// The function requires a return value
		Err_ArrayMismatch,
		Err_FunctionIsVoid,							// Invalid return value in void function
		Err_DuplicatedParameter,					// Function's parameters name must be unique
		Err_InvalidParameter,
		Err_InvalidRefParameter,
		Err_RefParameterRequired,
		Err_NoSuchFunction,							// A function with this name doesn't exist
		Err_PrototypeMismatch,						// The calling prototype doesn't match with function/method declaration
		Err_InvalidParameterName,					// A parameter with this name doesn't exist
		Err_IllegalConstantParameter,
		
		// Function prototypes declaration
		Err_TooLongDefault,							// The default string for a parameter is too long (max is 63 for parameters, 255 for properties)
		Err_BadPrototype,							// There was a sintax error in function/method prototype declaration
		Err_IllegalRef,								// There was a sintax error in function/method prototype declaration
		Err_FunctionRedeclared,						// The name of the function conflicts with a predefined function
	
		// Undef
		Err_IllegalUndef,							// Can't undef a literal or operation resulting variable
		
		// Variable names
		Err_InvalidCharacter,
		Err_InvalidName,							// A generic identifier is not valid
		Err_TooLongName,					// An identifier of a variable is too long (> 63)
		Err_EmptyName,						// An identifier of a variable is empty (0 chars)
		Err_ReservedKeyword,						// Can't use that name for the variable because it is a reserved keyword 
				
		// Class Execution
		Err_SuperConstructorRequired,				// A call to "super" is required inside the constructor
		Err_NotAllowedInDestructor,					// This expression is not allowed in Destructor method
		Err_NoSuchClass,							// A class with this name doesn't exist
		Err_MemberIsStatic,							// Trying to call a static member using an instance
		Err_MemberIsNotStatic,						// Trying to call a non static member without an instance
		Err_ThisIsUndefined,						// Using the keyword "this" is inappropriate here
		Err_SuperIsUndefined,						// Using the keyword "super" is inappropriate here
		Err_NotAnExtendingClass,					// The class doesn't extend another class, so it has no super object
		Err_ClassIsStatic,							// The class is completely static and refuses to instance objects
		Err_IllegalSetProperty,

		// Class Declaration
		Err_InvalidErrorValue,						// The value of an error in a class declaration is invalid (=0)
		Err_MethodNameConflict,						// A method with this name already exist in the class
		Err_ClassRedeclared,
		Err_DuplicatedPropertyName,
		Err_IllegalDeclaration,
		Err_DuplicatedConstructor,
		
		// Class calling
		Err_MemberOnUndefinedIdentifier,			// Can't apply a member to an undefined identifier
		Err_NoSuchProperty,							// The object has not a property with this name
		Err_NoSuchConstant,							// The object has not a constant property with this name
		Err_NoSuchMethod,							// The object has not a method with this name
		Err_NoSuchMember,							// The object has not a member with this name
		Err_CantAccessThisMember,					// The member is private or protected from external access
		Err_PropertyIsOnlyRead,						// The property can only be accessed for read, not write, operation
				
		// TypeCast
		Err_IllegalTypeCast,						// TypeCast between classes failed
		Err_ExplicitTypeCastRequired,				// An explicit typeCast is required
		
		// OnErrorResume
		Err_OnErrorNotBalanced,						// Calls to OnErrorSuspend didn't match calls to OnErrorResume
				
		// Parenthesis
		Err_RoundBracketExpected,
		Err_RoundBracketNotBalanced,
		Err_SquareBracketExpected,
		Err_CurlyBracketExpected,
		Err_CurlyBracketNotBalanced,
		
		// Overflow
		Err_Overflow,								// This variable cannot contain this value (see limits for numeric classes)
		Err_TooLongHexLiteral,
				
		// Error returned only to BAPI C classes (never return this to users)
		Err_BAPI_ExtensionTooOld,					// The extension is too old to run in this Biferno context
		Err_BAPI_ExtensionTooNew,					// The extension is too new to run in this Biferno context
		Err_BAPI_BifernoTooOld,						// Biferno context is too old to correctly load this extension
		Err_BAPI_BifernoTooNew,						// Biferno context is too new to correctly load this extension
		Err_BAPI_MessageNotHandled,					// The extension didn't handle the message (Divert to super?)
		Err_BAPI_BufferTooSmall,					// The storage for the request object is too small to contain it 
		Err_BAPI_ObjNotPrintable,					// The object can't be printable (method tostring not found)
		Err_BAPI_InvalidAPIData,					// An invalid api_data was passed to a BAPI call
		Err_BAPI_InvalidParameter,					// Invalid parameters were passed to a BAPI call
		Err_BAPI_ExtensionNameRequired,				// The name of the extension was not filled
		Err_BAPI_ObjNotToDestruct,					// BAPI_AvoidDestructor was called twice on an object
		Err_BAPI_ObjAlreadyToDestruct,				// BAPI_ForceDestructor was called twice on an object
		Err_BAPI_ErrorsAlreadyRegistered,			// BAPI_RegisterErrors was called twice
		Err_BAPI_EndOfObject,						// BAPI_ReadObj reached the end of the object data
		Err_BAPI_LoopAbort,							// Error sed to stop the BAPI_ArrayLoop
		Err_BAPI_SymbolNotFound,					// BAPI_GetSymbol couldn't find the requested symbol
		Err_BAPI_UnknowExtensionType,				// The extension is not a C or Biferno extension (should never happen)
		
		// XLib Errors
		Err_PathTooLong,							// The path is too long (> 255)
		Err_LockNotSupported,						// The lock of files is not supported
		Err_FolderIsNotEmpty,						// The operation failed because he directory is not empty
		Err_EndOfFile,								// The end of file was reached
		Err_WalkFolderAbort,						// WalkFolder interrupted by user
		Err_DuplicatedFile,							// A file with the same name exist in this location
		Err_UnknownUser,							// User unknown
		Err_UnknownGroup,							// Group is unknown
		Err_BadFileRef,								// The file ref passed to XLib function is invalid
		Err_BadMemoryRef,							// The memory ref passed to XLib function is invalid
		Err_NullSizeBlock,							// Can't allocate a null size block of memory
		Err_BadBlockSize,							// The size of the block is invalid (<= 0)
		Err_MemoryFull,								// There is not enough memory to perform operation
		Err_FreeBlock,								// Attempt to dispose a memory block twice
		Err_ThreadTimeout,							// The threads timed out waiting for a semaphore
		Err_ThreadsInternalErr,						// The TLS (Thread Local Storage) manager failed
		Err_ThreadNotFound,							// The TLS (Thread Local Storage) couldn't find the thread id
		Err_DateTimeFormatError,					// The format string for date/time record is invalid
		Err_CantLoadShObject,						// The DLL can't be loaded
		Err_CantFindShLibSymbol,					// The DLL symbol can't be found
		Err_CantCloseShLib,							// Close of DLL failed
		Err_ConvertingStringToLong,					// Conversion from string to long long failed
		Err_NotImplemented,							// The function is not implemented in this version of XLib
		Err_ConnectionBroken,						// The connection was reset by the server
		Err_XLibTooOld,								// The XLib version is too old to run in this context
		Err_XLibTooNew,								// The XLib version is too new to run in this context
		Err_XLibCallerTooOld,						// The context is too old to correctly load this XLib version
		Err_XLibCallerTooNew,						// The context is too new to correctly load this XLib version
		Err_ProcessShutDown,						// The operation failed because the application is shutting down
	
		// XLib Helpers Errors
		Err_BuffersNotInitialized,					// The Buffer manager is not initialized
		Err_BuffersBadID,							// The buffer id is invalid
		Err_CacheNotInitialized,					// The Cache manager is not initialized
		Err_CachePathTooLong,						// The path passed to the cache is too long (> 255)
		Err_InvalidListRef,							// The DLM list ref is invalid
		Err_ListDontAcceptNames,					// The list doesn't accept object names
		Err_DuplicatedObject,						// A DLM object with this name already exists
		Err_ListOutOfBoundary,						// The id of the object is out of list boundary
		Err_ListBufferTooSmall,						// The storage passed to DLM is too small to contain the requested object
		Err_ObjectNotFound,							// An object with this name was not found
		Err_CantModifyLength,						// Attempt to change a size of a fixed size object failed
		//Err_ObjectIsConstant,						// Attempt to change a constant object failed
		Err_ObjectIsLocked,							// Attempt to change a locked object failed
		Err_ListIsLocked,
		//Err_BadArrayDimension,						// The dimension of the array is invalid (< 0)
		Err_InvalidArrayIndex,						// The index of the array is invalid
		Err_InvalidPosition,						// The position of the new object is invalid
		Err_InvalidLength,							// The length of the object to add is invalid
		Err_NoResolveOnDupList,						// DLM_ResolveArrayElem can't be called on a list with duplicated names
		Err_NameTooLong,							// the name of the object is too long (> 255)
		Err_InvalidListType,						// The list type is invalid (possible values are: ID_LIST, NAME_LIST, NAMECS_LIST)
		Err_TextUtilsNotInitialized,				// The XLib Text Manager manager is not initialized
		Err_UnknownError,							// Unknown error
		Err_UnknownXLibError,						// Unknown XLib error
		Err_UnknownXLibHelpersError,				// Unknown XLib Helpers error
					
		// BAPI >= 0x00010001
		Err_JVMLoadFailed,
		Err_AttachCurrentThreadException,
		Err_JavaNotAvailable,
		
		Err_ParameterNameTooLong,
		
		Err_MemorySlotsFull,
		Err_SlotMgrUnavailable,

		Err_ClassError,
		
		// BAPI >= 0x00010004
		Err_VariableDuplicatedInURL,
		Err_StackOverflow,							// The script used too much stack

		// BAPI >= 0x00010005
		Err_InvalidVariableType,
		Err_IllegalDestructor,
		
	
		Err_LastErr									// The last err (never used)
		};

// Types of TypeCast
enum {
		kNoTypeCast,
		kExplicitTypeCast,
		kImplicitTypeCast
		};

// Types of extensions (plugins)
enum {
		kNewClassPlugin,
		kNewFunctionsPlugin
		};

// Variant of Primitive event (on Primitive_String)
enum {
		kNormal,
		kForConstructor,
		kForDebug
		};

// Mode of BAPI_AvoidDestructor/BAPI_ForceDestructor
enum {
		kMain,
		kElements,
		kWhole
		};

// Operators	
enum{	// name						symbol						priority
		EVAL_MULT = 1,				// *						0
		EVAL_DIV,					// /						0
		EVAL_MOD,					// %						0
		EVAL_ADD,					// +						1
		EVAL_MINUS,					// -						1
		EVAL_SHIFTR,				// >>						2
		EVAL_SHIFTL,				// <<						2
		EVAL_GTH ,					// >						3
		EVAL_LTH,					// <						3
		EVAL_GEQ,					// >=						3
		EVAL_LEQ,					// <=						3
		EVAL_EQUA,					// ==						4
		EVAL_NEQUA,					// !=						4
		EVAL_ARAND,					// &						5
		EVAL_AROR,					// |						6
		EVAL_LOGIC_AND,				// &&						7		// Never sent to classes
		EVAL_LOGIC_OR				// ||						8		// Never sent to classes
		};

// Define the last operator number
#define		LAST_OP						EVAL_LOGIC_OR	//EVAL_TERNARY_SEMICOLON

// Class elements
enum {
		kMethod = 1,
		kFunction,
		kProperty,
		kError,
		kConstant
		};

// OnError function modes
enum {
		kResume = 1,
		kSuspend,
		kGetState,
		kGetFunction
		};

// mode of BAPI_ApplyPropertyList
enum {
		GET = 1,
		SET
		};


// BAPI_HTTPParam parameters
typedef enum {
		BAPI_Method = 1,
		BAPI_URL,
		BAPI_SearchArg,
		BAPI_IPAddress,
		BAPI_Address,
		BAPI_Username,
		BAPI_Password,
		BAPI_Domain,
		BAPI_Protocol,
		BAPI_Scheme,
		BAPI_Port
		} BAPI_HTTPParam;


// Type of requests for Primitive event
enum {
		kInt,
		kLong,
		kUnsigned,
		kDouble,
		kBool,
		kCString,
		kChar
		};

// Array Sort Modes
enum {
		kArraySortAsc,
		kArraySortDesc
		};

enum{
		kSortChoose = 0,
		kSortBubble,
		kSortShell
		};

//===========================================================================================
// GLOBALS
//===========================================================================================

// Types of scope
//long		scope[NUM_LIST] = {LOCAL, GLOBAL, APPLICATION, SESSION, PERSISTENT, TEMP};

//===========================================================================================
// CALLBACK TYPEDEFs
//===========================================================================================

// Biferno Dispatch entry point
typedef	XErr	(*Biferno_Dispatch)(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

// Callback to loop on array's elements
typedef XErr	(*BAPI_ArrayLoopCallBack)(long api_data, char *elemName, ObjRefP element, long param);

// Callback to sort an array (must return true if are to swap)
typedef Boolean	(*BAPI_ArraySortCallBack)(long api_data, ObjRefP elem1, ObjRefP elem2, long param, XErr *errP);

//===========================================================================================
// FUNCTION PROTOTYPES
//===========================================================================================

//===========================================================================================
// FUNCTION PROTOTYPES
//===========================================================================================

// Extension Entry Point Dispatch
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

// Declare New Members
XErr	BAPI_NewProperties(long api_data, long pluginID, BAPI_MemberRecord *memberRecordsP, long totProperties, char *owner);
XErr	BAPI_NewMethods(long api_data, long pluginID, BAPI_MemberRecord *memberRecordsP, long totMethods, char *owner);
XErr	BAPI_NewConstants(long api_data, long pluginID, BAPI_MemberRecord *memberRecordsP, long totConstants, char *owner);
XErr	BAPI_RegisterErrors(long api_data, long pluginID, long baseError, CStr63 *namesP, long totErrors);
XErr	BAPI_NewFunctions(long api_data, long pluginID, BAPI_MemberRecord *memberRecordsP, long totFunctions);
XErr	BAPI_NewApplicationDefault(long api_data, char *name, char *value, char *comment);

// Create objects from C primitives
XErr 	BAPI_IntToObj(long api_data, long value, ObjRefP objRefP);
XErr 	BAPI_LongToObj(long api_data, LONGLONG value, ObjRefP objRefP);
XErr 	BAPI_UnsignedToObj(long api_data, unsigned long value, ObjRefP objRefP);
XErr 	BAPI_DoubleToObj(long api_data, double doubleVal, ObjRefP objRefP);
XErr 	BAPI_BooleanToObj(long api_data, Boolean isTrue, ObjRefP objRefP);
XErr	BAPI_StringToObj(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP);
XErr	BAPI_CharToObj(long api_data, char theChar, ObjRefP objRefP);

// Create objects from other types or from obj
XErr	BAPI_BufferToObj(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, long constructorPrivateData, ObjRefP objRefP);
XErr	BAPI_BufferToObjWithSuper(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, ObjRefP superObj, long constructorPrivateData, ObjRefP objRefP);
XErr	BAPI_ArrayToObj(long api_data, Boolean fixedSize, ParameterRec *varRecsP, long totVars, long *errElemIDXP, long constructorPrivateData, ObjRefP objRefP);
XErr	BAPI_CopyObj(long api_data, ObjRefP sourceObj, long constructorPrivateData, ObjRefP destObj);

// Getting the objects content
XErr	BAPI_ReadObj(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP);
XErr	BAPI_GetObj(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP);
XErr	BAPI_GetStringBlock(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType);
XErr	BAPI_GetStringBlockExt(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType, short variant);
XErr	BAPI_GetObjBlock(long api_data, ObjRefP objRef, Ptr buffer, Ptr *stringP, long *stringLen, BlockRef *refP);
void	BAPI_ReleaseBlock(BlockRef *refP);

// Modify objects
XErr	BAPI_ModifyObj(long api_data, ObjRefP objref, void* dataP, long dataLen);
XErr	BAPI_WriteObj(long api_data, ObjRefP objref, void* dataP, long dataLen, long atOffset);
XErr	BAPI_ReplaceObj(long api_data, ObjRefP objref, ObjRefP value, Boolean extended);
XErr	BAPI_ModifyObjClassID(long api_data, ObjRefP objref, long newObjClassID);
XErr	BAPI_ConcatObjs(long api_data, ObjRefP objref1, ObjRefP objref2);

// Operation on ObjRefs
XErr	BAPI_InvalObjRef(long api_data, ObjRefP objRef);
XErr	BAPI_IsObjRefToDestruct(long api_data, ObjRefP objRef, Boolean *isToDestructP);
Boolean	BAPI_IsObjRefValid(long api_data, ObjRefP objRef);
XErr	BAPI_LocateObj(long api_data, ObjRefP objRef, char *scope, long *stackIndex);
XErr	BAPI_GetObjInfo(long api_data, ObjRefP objRef, long *classIDP, char *name);
long	BAPI_GetObjClassID(long api_data, ObjRefP objRef);
long	BAPI_GetObjClassIDExt(long api_data, ObjRefP objRef, long *classIDP);
void	BAPI_SetObjClassID(long api_data, ObjRefP objRef, long newClassID);
long	BAPI_GetObjScope(long api_data, ObjRefP objRef);
void	BAPI_SetObjScope(long api_data, ObjRefP objRef, long newScope);
long	BAPI_GetObjType(long api_data, ObjRefP objRef);
void	BAPI_SetObjType(long api_data, ObjRefP objRef, long newType);
XErr	BAPI_NeedSerialize(long api_data, ObjRefP objRef, Boolean *needP);
XErr	BAPI_ScopeAllowed(long api_data, ObjRefP objP, long scope, Boolean *allowedP);

// Set/Get the super object of a class
XErr	BAPI_SetSuperObj(long api_data, ObjRefP obj, ObjRefP superObj, ObjRefP newSuperObjP);
XErr	BAPI_GetSuperObj(long api_data, ObjRef *objRef, ObjRef *superObjRef);

// Convert object to C primitives
XErr	BAPI_ObjToInt(long api_data, ObjRefP objRef, long *valueP, long typeCastType);
XErr	BAPI_ObjToLong(long api_data, ObjRefP objRef, LONGLONG *lvalueP, long typeCastType);
XErr	BAPI_ObjToUnsigned(long api_data, ObjRefP objRef, unsigned long *valueP, long typeCastType);
XErr	BAPI_ObjToBoolean(long api_data, ObjRefP objRef, Boolean *valueP, long typeCastType);
XErr	BAPI_ObjToDouble(long api_data, ObjRefP objRef, double *valueP, long typeCastType);
XErr	BAPI_ObjToString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType);
XErr	BAPI_ObjToChar(long api_data, ObjRefP objRef, char *theChar, long typeCastType);
XErr	BAPI_ObjToConstrString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType);
XErr	BAPI_ObjToDebugString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType);

// Working on Arrays
XErr	BAPI_ElementOfArray(long api_data, ObjRefP objRef, long index, ObjRefP resultObjRef);
XErr	BAPI_ElementOfArrayExt(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, ObjRefP resultObjRef);
XErr	BAPI_GetArrayInfo(long api_data, ObjRefP objRef, long *arrayDimP, long *arrayClassIDP, long *dlmRefP);
XErr	BAPI_SetArrayElemClass(long api_data, ObjRefP objRef, long classID);
XErr	BAPI_SetArrayDim(long api_data, ObjRefP theObjRefP, long newDim);
XErr	BAPI_SetArrayElemName(long api_data, ObjRefP arrayObjRef, ArrayIndexRec *mCoords, short dim, char *name);
XErr	BAPI_ArrayGetElementIndex(long api_data, ObjRef *arrayObjRef, ObjRefP objRef);
XErr	BAPI_ArrayLoop(long api_data, ObjRefP objRef, BAPI_ArrayLoopCallBack callBack, long param);
XErr	BAPI_ArrayAddElement(long api_data, ObjRefP arrayObjRefP, char *name, ObjRef *objToAdd);
XErr	BAPI_ArrayDelete(long api_data, ObjRefP objRef, long firstElem, long lastElem);
XErr	BAPI_ArraySwap(long api_data, ObjRefP objRef, long elem1, long elem2);
XErr	BAPI_ArrayReverse(long api_data, ObjRefP arrayObjRefP);
XErr	BAPI_ArraySort(long api_data, ObjRefP arrayObjRefP, long mode, long alg, BAPI_ArraySortCallBack callBack, long param);
XErr	BAPI_ArrayInsert(long api_data, ObjRefP arrayObjRefP, int pos, ParameterRec *paramVarsP, long totParams);
XErr	BAPI_ArrayReset(long api_data, ObjRefP objRefP);
XErr	BAPI_ArrayConcat(long api_data, ObjRefP objRef1, ObjRefP objRef2, ObjRefP result);

// Communication between classes (Accessors)
XErr	BAPI_Accessor(long api_data, long classID, long message, Biferno_ParamBlockPtr paramBlockPtr);
XErr	BAPI_Constructor(long api_data, long classID, ParameterRec *varRecsP, long totVars, ObjRef *resultObjRefP);
XErr	BAPI_Clone(long api_data, ObjRef *sourceP, ObjRef *destP, Boolean cloneTarget);
XErr	BAPI_Destructor(long api_data, ObjRefP varRecP);
XErr	BAPI_ExecuteOperation(long api_data, ObjRefP item1, ObjRefP item2, long operation, ObjRefP resultVarRecP);
XErr	BAPI_Increment(long api_data, ObjRefP objRefP, Boolean toDecr);
XErr	BAPI_ExecuteMethod(long api_data, ObjRefP objRef, ParameterRec *paramVarsP, long totParams, char *methodName, ObjRefP resultVarRecP, Boolean *sideEffectP);
XErr	BAPI_GetProperty(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP resultVarRecP);
XErr	BAPI_SetProperty(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP value);
XErr	BAPI_TypeCast(long api_data, ObjRefP objRef, long requestedClassID, ObjRefP resultVarRecP, long typeCastType);
XErr	BAPI_ExecuteFunction(long api_data, ParameterRec *paramVarsP, long totParams, char *functionName, ObjRefP resultVarRecP);
XErr	BAPI_GetErrMessage(long api_data, long classID, short theError, char *errName, char *errMessage, char *errType);
XErr	BAPI_SuperIsChanged(long api_data, ObjRef *objRef, char *propertyName);

// Encode/Decode Strings
XErr	BAPI_EncodeIsolatin(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR, Boolean encodeGthLth, Boolean useNames, Boolean extTags, long userTagList);
XErr	BAPI_DecodeIsolatin(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR);
XErr	BAPI_EncodeURL(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean spaceToPlus, char *preStr);
XErr	BAPI_DecodeURL(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean plusToSpace, char *preStr);
XErr	BAPI_EncodeBase64(long api_data, char *stringP, long stringLen, char *resultString, long *resultStringLengthP);
XErr	BAPI_DecodeBase64(long api_data, char *stringP, long stringLen, char *resultStringP, long *resultStringLengthP, long maxStorage);

// User Variables
XErr	BAPI_GetTotVariables(long api_data, long *totVarsP, long scope);											// deprecated
XErr	BAPI_GetListTotVariables(long api_data, long scope, int stackIndex, long *totVarsP);
XErr	BAPI_GetListTotVariablesExt(long api_data, long scope, int stackIndex, Boolean onlyArguments, long *totVarsP);

XErr	BAPI_GetIndVariable(long api_data, long index, long scope, Boolean sorted, char *name, ObjRef *objIDP);		// deprecated
XErr	BAPI_GetListIndVariable(long api_data, long index, long scope, Boolean sorted, char *name, int stackIndex, ObjRef *objIDP);
XErr	BAPI_IsVariableInitialized(long api_data, ObjRefP objrefP, Boolean *isInitP);
XErr	BAPI_IsVariableHidden(long api_data, ObjRefP objRef, Boolean *isHidden);
XErr	BAPI_IsVariableDefined(long api_data, char *name, long theScope, Boolean *isDefP, ObjRef *varObjRefP);

// Publishe objs
XErr	BAPI_Publish(long api_data, Boolean toPublish, ObjRef *objrefP);
XErr	BAPI_GetPublishedVar(long api_data, char *applicationName, long theScope, char *objName, ObjRef *resultObjRefP);

// Undef/Hide/Show
XErr	BAPI_Undef(long api_data, ObjRef *varObjRefP);
XErr	BAPI_Hide(long api_data, Boolean toHide, ObjRef *objRef);

// Lock objects
XErr	BAPI_LockObj(long api_data, ObjRefP objref);
XErr	BAPI_UnlockObj(long api_data, ObjRefP objref);

// Modify destructor behaviour
XErr	BAPI_AvoidDestructor(long api_data, ObjRefP objRef, long mode);
XErr	BAPI_ForceDestructor(long api_data, ObjRefP objRef, long mode);

// Output Functions
XErr	BAPI_StandardOutput(long api_data, char *textP, long len, Boolean useCustom);
XErr	BAPI_SetCustomOutput(long api_data, char *functionName);
XErr	BAPI_SetStandardOutput(long api_data);
XErr	BAPI_GetOutputFunction(long api_data, char *funcName);
XErr	BAPI_Log(long api_data, char *strLog);

// Error Handling
XErr	BAPI_Exception(long api_data, long errType, long errNum, char *className, Boolean setClassException);
XErr	BAPI_GetErrDescription(long api_data, XErr theError, char *eNameStr, char *classErrNotesP, char *errType, char *descr, Boolean *resumableP, long lastClassErrCalled, char *subErrStr);
XErr	BAPI_NewMsgRecord(long api_data, char *title, char *msg, long msgLen, long flags);			// deprecated
XErr	BAPI_GetMessageRecords(long api_data, CStr63 *title, CStr255 *msg, long *totP, long max);	// deprecated
XErr	BAPI_GetErrorMsgRecord(long api_data, ErrorMsgRecord *msgRecordP, long *lastMultiStrLineP);
XErr	BAPI_GetIncludeStack(long api_data, BlockRef *stackBlockP, long *totItemsP);
XErr	BAPI_GetStack(long api_data, BlockRef *stackBlockP, long *totItemsP, Boolean *stackFixedSize);
XErr	BAPI_GetHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, long lastClassErrCalled);
XErr	BAPI_GetStatus(long api_data, BlockRef *fileLineBlockP, long *fileLineLengthP, BlockRef *statusBlockP, long *statusBlockLengthP, BlockRef *stackBlockP, long *stackBlockLengthP);
XErr	BAPI_GetErrorStrings(long api_data, long *startErrP, BAPIErrorRecord **errorStringsP, long *totErrorsP);
XErr	BAPI_Exit(long api_data);
XErr	BAPI_OnError(long api_data, long mode, char *onErrorFunc, Boolean *stateP);

// Infos on system/environment
XErr	BAPI_GetCache(long api_data, BlockRef *infoBlockP, long *totItemsP, unsigned long *totalBytesInCacheP, Boolean *cacheFixedSizeP);
XErr	BAPI_GetMaxUsers(long api_data, long *maxUsersP);
XErr	BAPI_GetPoolFactor(long api_data, long *poolFactorP);
XErr	BAPI_GetVersions(long api_data, char *versionStr, char *versionBAPIStr, char *xlibVersStr);
XErr	BAPI_GetNumVersions(long api_data, unsigned long *version, unsigned long *versionBAPI, unsigned long *xlibVers);
XErr	BAPI_Platform(long api_data, char *cStr, char *compilationFlags, long strSize);
XErr	BAPI_GetBifernoHome(long api_data, XFilePathPtr homeStr);
XErr	BAPI_GetServerUpSince(long api_data, ObjRef *timeObjP);

// Flush/Reload
XErr	BAPI_Flush(long api_data);
XErr	BAPI_FlushAppFiles(long api_data);
XErr	BAPI_FlushFile(long api_data, XFilePathPtr filePath);
XErr	BAPI_ReloadApp(long api_data);

// Applications
XErr	BAPI_RegisterApplication(long api_data, char *applicationName, XFilePathPtr applicationPath);
XErr	BAPI_GetCurrentAppInfo(long api_data, char *name, char *home);
XErr	BAPI_GetGenericAppInfo(long api_data, char *appName, char *appHome);
XErr	BAPI_GetApplications(long api_data, BlockRef *appsArrayBlockP, long *totAppsP, long index);
XErr	BAPI_GetConfig(long api_data, char *configName, char *result, long *resultLenP, Boolean *isDefP);
XErr	BAPI_GetBooleanConfig(long api_data, char *configName, Boolean *resultP, Boolean *isDefP);
XErr	BAPI_GetIntConfig(long api_data, char *configName, long *resultP, Boolean *isDefP);
XErr	BAPI_GetUnsignedConfig(long api_data, char *configName, unsigned long *resultP, Boolean *isDefP);

// Reflection (Info on other class/funcs)
XErr	BAPI_GetAppChildren(long api_data, char *applicationName, BlockRef *childrenArrayBlockP, long *totChildrenP, long index);
XErr	BAPI_GetClasses(long api_data, char *applicationName, BlockRef *classesArrayBlockP, long *totClassesP, long index);
XErr	BAPI_GetMembers(long api_data, char *applicationName, char *className, long which, BlockRef *membersArrayBlockP, long *totMembersP, long index);
XErr	BAPI_GetMemberDoc(long api_data, char *className, char *memberName, BlockRef *docBlockRefP, Boolean extended);
XErr	BAPI_GetClassDoc(long api_data, char *className, BlockRef *xmlBlockRefP);
XErr	BAPI_DuplicateMemberDoc(long api_data, BlockRef docBlockRef, BlockRef *newDocBlockRefP);
XErr	BAPI_ReleaseMemberDoc(long api_data, BlockRef *docBlockRefP);
XErr	BAPI_IsMemberDef(long api_data, char *className, char *memberName, Boolean *isDefP);
XErr	BAPI_IsFuncDef(long api_data, char *name, Boolean *isDefP);
XErr	BAPI_GetClassInfo(long api_data, long classID, BAPI_ClassInfo *classInfoP);
long	BAPI_ClassIDFromName(long api_data, char *className, Boolean allExtensionsType);
XErr	BAPI_NameFromClassID(long api_data, long pluginID, char *pluginName);
XErr	BAPI_FixedSize(long api_data, long classID, Boolean *fixedSize);

// Infos on script/files
XErr	BAPI_GetCurrentScriptInfo(long api_data, unsigned long *timeoutP, long *currentThreadsP, long *maxThreadsP, XFilePathPtr basePath);
XErr	BAPI_GetCurrentScriptStatus(long api_data, long *statusP);
XErr	BAPI_SetTimeout(long api_data, unsigned long newTimeOut);
XErr	BAPI_Yield(long api_data, unsigned long *lastTicksP);
XErr	BAPI_GetFilePath(long api_data, XFilePathPtr filePath);
XErr	BAPI_GetCurrentFilePath(long api_data, XFilePathPtr currentFilePath, long *actLineP, Boolean *wasInCacheP, Boolean *willBeCachedP);
XErr	BAPI_GetCurrentFileOffset(long api_data, long *offP);
Boolean	BAPI_IsCacheActive(long api_data);
XErr	BAPI_GetCurrentBasePath(long api_data, XFilePathPtr currentBasePath, Boolean fromRoot);
XErr	BAPI_SetFileCacheState(long api_data, Boolean toCache);
XErr	BAPI_RealPath(long api_data, XFilePathPtr path, Boolean resolveAlias);
XErr	BAPI_NativePath(long api_data, XFilePathPtr path);
XErr	BAPI_BifernoPath(long api_data, XFilePathPtr path);

// Infos on HTTP
void*	BAPI_HTTPTaskID(long api_data);
XErr	BAPI_GetHTTPParam(long api_data, BAPI_HTTPParam what, ObjRef *result);

// Java
XErr	BAPI_JavaGetCurrentJNIEnv(long api_data, void **envPPtr);
XErr	BAPI_JavaLoadJVM(long api_data);

// Symbols
XErr	BAPI_RegisterSymbol(long api_data, long classID, char *symbolName, long address);
XErr	BAPI_GetSymbol(long api_data, long classID, char *symbolName, long *addressP);

// Class Run data
XErr	BAPI_GetPluginRunData(long api_data, long classID, long *class_thread_dataP);
XErr	BAPI_SetPluginRunData(long api_data, long classID, long class_thread_data);

// Biferno SID (Session ID)
XErr	BAPI_GetSID(long api_data, char *SIDStr, char *XIDStr);
XErr	BAPI_SetSID(long api_data, char *SIDStr, char *XIDStr, Boolean isNew);
XErr	BAPI_CheckSID(long api_data, char *SIDStr, char *XIDStr, Boolean *validP);
XErr	BAPI_GetIndSID(long api_data, long index, char *SIDStr);
XErr	BAPI_SessionVariableToString(long api_data, char *SIDStr, char *varName, char *strP, long *strLenP, long maxLen);

// Number/Date format
XErr	BAPI_SetNumberFormat(long api_data, Byte thousSep, Byte decSep);
XErr	BAPI_GetNumberFormat(long api_data, Byte *thousSepP, Byte *decSepP);
XErr	BAPI_GetDateFormat(long api_data, char *formatStr);

// Eval
XErr	BAPI_Eval(long api_data, char *strToEval, long strToEvalLen, ObjRefP resultObjRefP, Boolean onlyOneStatement, Boolean resume);
XErr	BAPI_ResetError(long api_data);

// Utils
XErr	BAPI_ScopeID(long api_data, char *scopeName, long *scopeP);
XErr	BAPI_ScopeName(long api_data, long the_scope, char *scopeName);
long	BAPI_ConstructorScope(long api_data, long constructorPrivateData);
void	BAPI_ClearParameterRec(long api_data, ParameterRec *paramP);

// References
XErr	BAPI_GetReference(long api_data, char *targetStr, ObjRef *targetObjRefP, BlockRef *targetPropListP);
XErr	BAPI_DisposePropertyList(long api_data, BlockRef *targetPropListP);
XErr	BAPI_ClonePropertyList(long api_data, BlockRef source, BlockRef *destP);
XErr	BAPI_ApplyPropertyList(long api_data, ObjRef *targetP, BlockRef targetPropList, long mode, Boolean skipLast, ObjRef *obj2P);
XErr	BAPI_GetPropertyListNames(long api_data, BlockRef targetPropList, BlockRef *resultP, long *resultLenP);
XErr	BAPI_GetPropertyListClassID(long api_data, BlockRef targetPropList, long *classIDP);
XErr	BAPI_MakeRef(long api_data, ObjRef *objRefP, ObjRef *targetP);
Boolean	BAPI_IsReference(long api_data, ObjRef *objRefP);
XErr	BAPI_GetReferenceTarget(long api_data, ObjRefP objRef, ObjRefP targetP);

// this can be called only by Biferno, not by plugins
XErr	BAPI_SetPageOut(long api_data, ObjRefP pageObjRef);

//********************************************************************************************************
/*
* private
*/
EXP XErr	_X_RegisterCallBacks(long callsBackPtr);
EXP long	_X_BAPI_PluginBAPIVersion(XErr *errP);

#endif
