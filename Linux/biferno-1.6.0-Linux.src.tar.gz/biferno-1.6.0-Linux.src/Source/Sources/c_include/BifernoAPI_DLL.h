/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoAPI_DLL.h,v 1.21 2008-06-13 14:29:09 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __BIFERNOAPI_DLL__
	#define __BIFERNOAPI_DLL__
		
typedef struct {
	// Eval
	long	BAPI_Eval;
	// ObjRef
	long	BAPI_InvalObjRef;
	long	BAPI_GetObjInfo;
	long	BAPI_IsObjRefValid;
	long	BAPI_GetObjClassID;
	long	BAPI_GetObjScope;
	long	BAPI_GetObjType;
	long	BAPI_NeedSerialize;
	
	// New Members
	long	BAPI_NewProperties;
	long	BAPI_NewMethods;
	long	BAPI_RegisterErrors;
	long	BAPI_NewFunctions;
	long	BAPI_NewConstants;
	long	BAPI_NewApplicationDefault;
	
	// New Obj
	long	BAPI_BufferToObj;
	long	BAPI_ScopeID;
	long	BAPI_ConstructorScope;
	
	// Super Obj
	long	BAPI_BufferToObjWithSuper;
	long	BAPI_SetSuperObj;
	long	BAPI_GetSuperObj;
	
	// Temporaneous objects
	long	BAPI_IntToObj;
	long	BAPI_LongToObj;
	long	BAPI_UnsignedToObj;
	long	BAPI_DoubleToObj;
	long	BAPI_BooleanToObj;
	long	BAPI_StringToObj;
	//long	BAPI_StringToConstObj;
	long	BAPI_CharToObj;
	
	long	BAPI_ArrayToObj;
	
	// Modify Objs
	long	BAPI_ModifyObj;
	long	BAPI_WriteObj;
	long	BAPI_ReplaceObj;
	long	BAPI_ModifyObjClassID;
	long	BAPI_LockObj;
	long	BAPI_UnlockObj;
	
	// Convert Objs to C types
	long	BAPI_ObjToInt;
	long	BAPI_ObjToLong;
	long	BAPI_ObjToUnsigned;
	long	BAPI_ObjToBoolean;
	long	BAPI_ObjToDouble;
	long	BAPI_ObjToString;
	long	BAPI_ObjToChar;
	long	BAPI_ObjToConstrString;
	long	BAPI_ObjToDebugString;
	long	BAPI_ReadObj;
	long	BAPI_GetObj;
	long	BAPI_GetStringBlock;
	long	BAPI_GetStringBlockExt;
	long	BAPI_ReleaseBlock;
	
	// Operations on object
	long	BAPI_ConcatObjs;
	long	BAPI_CopyObj;
	long	BAPI_GetPublishedVar;
	long	BAPI_AvoidDestructor;
	long	BAPI_ForceDestructor;
	long	BAPI_SetArrayElemName;
	
	// Arrays
	long	BAPI_GetArrayInfo;
	long	BAPI_SetArrayElemClass;
	long	BAPI_SetArrayDim;
	long	BAPI_ElementOfArray;
	long	BAPI_ElementOfArrayExt;
	long	BAPI_ArrayLoop;
	long	BAPI_ArrayAddElement;
	long	BAPI_ArrayDelete;
	long	BAPI_ArraySwap;
	long	BAPI_ArrayReverse;
	long	BAPI_ArraySort;
	long	BAPI_ArrayInsert;
	long	BAPI_ArrayReset;
	long	BAPI_ArrayConcat;
	
	// Access to other classes
	long	BAPI_Accessor;
	long	BAPI_Constructor;
	long	BAPI_Clone;
	long	BAPI_Destructor;
	long	BAPI_ExecuteOperation;
	long	BAPI_ExecuteMethod;
	long	BAPI_GetProperty;
	long	BAPI_SetProperty;
	long	BAPI_TypeCast;
	long	BAPI_ExecuteFunction;
	long	BAPI_GetErrMessage;
	long	BAPI_SuperIsChanged;
	
	// Encode/Decode Strings
	long	BAPI_EncodeIsolatin;
	long	BAPI_DecodeIsolatin;
	long	BAPI_EncodeURL;
	long	BAPI_DecodeURL;
	long	BAPI_EncodeBase64;
	long	BAPI_DecodeBase64;
	
	// User Variables
	long	BAPI_GetTotVariables;
	long	BAPI_GetIndVariable;
	long	BAPI_Publish;
	long	BAPI_Hide;
	long	BAPI_Undef;
	//long	BAPI_IsClassDef;
	long	BAPI_IsFuncDef;
	long	BAPI_IsVariableDefined;
	long	BAPI_IsVariableInitialized;
	long	BAPI_GetClassInfo;
	long	BAPI_FixedSize;
	long	BAPI_ClearParameterRec;
	
	// Standard Output
	long	BAPI_StandardOutput;
	long	BAPI_SetCustomOutput;
	long	BAPI_SetStandardOutput;
	long	BAPI_GetOutputFunction;
	
	// Error Handling
	long	BAPI_Exception;
	long	BAPI_GetErrDescription;
	long	BAPI_NewMsgRecord;
	long	BAPI_GetMessageRecords;
	long	BAPI_GetHtmlError;
	long	BAPI_GetStatus;
	long	BAPI_ScopeName;
	long	BAPI_GetErrorStrings;
	
	// Infos on system and functions/class
	long	BAPI_GetCache;
	long	BAPI_GetMaxUsers;
	long	BAPI_GetPoolFactor;
	long	BAPI_GetVersions;
	long	BAPI_GetNumVersions;
	long	BAPI_Platform;
	long	BAPI_GetBifernoHome;
	long	BAPI_GetServerUpSince;
	long	BAPI_FlushAppFiles;
	long	BAPI_FlushFile;
	long	BAPI_ReloadApp;
	long	BAPI_GetCurrentAppInfo;
	long	BAPI_RegisterApplication;
	long	BAPI_GetApplications;
	
	long	BAPI_GetClasses;
	long	BAPI_GetMembers;
	long	BAPI_GetMemberDoc;
	long	BAPI_GetClassDoc;
	long	BAPI_ReleaseMemberDoc;
	long	BAPI_DuplicateMemberDoc;
	long	BAPI_IsMemberDef;
	long	BAPI_NameFromClassID;
	long	BAPI_ClassIDFromName;
	long	BAPI_ScopeAllowed;
	
	// Infos on files
	long	BAPI_GetFilePath;
	long	BAPI_GetCurrentFilePath;
	long	BAPI_IsCacheActive;
	long	BAPI_GetCurrentBasePath;
	long	BAPI_GetCurrentScriptInfo;
	long	BAPI_SetFileCacheState;
	long	BAPI_RealPath;
	long	BAPI_NativePath;
	long	BAPI_BifernoPath;
	
	// Infos on HTTP
	long	BAPI_HTTPTaskID;
	long	BAPI_GetHTTPParam;
	
	// Flowing settings
	long	BAPI_OnError;
	long	BAPI_Exit;
	
	// Java
	long	BAPI_JavaGetCurrentJNIEnv;
	
	// Symbols
	long	BAPI_RegisterSymbol;
	long	BAPI_GetSymbol;
	
	// Class Thread data
	long	BAPI_GetPluginRunData;
	long	BAPI_SetPluginRunData;
	
	long	BAPI_GetConfig;
	long	BAPI_GetBooleanConfig;
	long	BAPI_GetIntConfig;
	long	BAPI_GetUnsignedConfig;
	
	// SID
	long	BAPI_SetSID;
	long	BAPI_CheckSID;
	long	BAPI_GetIndSID;
	long	BAPI_SessionVariableToString;
	
	// timeouts
	long	BAPI_GetTimeout;
	long	BAPI_SetTimeout;
	long	BAPI_Yield;
	
	// Number/Date format
	long	BAPI_SetNumberFormat;
	long	BAPI_GetNumberFormat;
	long	BAPI_GetDateFormat;
	
	// New Flush/Reload funcs
	long	BAPI_Flush;
	long	available;	//BAPI_Reload;	aliminated
	
	// Log on output
	long	BAPI_Log;
	
	long	BAPI_GetAppChildren;
	
	long	BAPI_SetObjClassID;
	long	BAPI_SetObjScope;
	long	BAPI_SetObjType;
	// GetInfo
	long	BAPI_GetObjBlock;
	
	long	BAPI_GetReference;
	long	BAPI_DisposePropertyList;
	long	BAPI_ApplyPropertyList;
	long	BAPI_GetPropertyListNames;
	long	BAPI_GetPropertyListClassID;
	long	BAPI_MakeRef;
	long	BAPI_IsReference;
	
	long	BAPI_Increment;
	long	BAPI_ResetError;
	
	// BAPI >= 0x00010002
	long	BAPI_JavaLoadJVM;			// Java Load JVM call back
	
	// BAPI >= 0x00010003				// Biferno 1.1
	long	BAPI_IsObjRefToDestruct;
	long	BAPI_ClonePropertyList;
	long	BAPI_GetCurrentScriptStatus;
	
	// BAPI >= 0x00010004				// Biferno 1.2
	long	BAPI_GetReferenceTarget;
	
	// BAPI >= 0x00010005				// Biferno 1.3
	long	BAPI_GetStack;
	long	BAPI_GetErrorMsgRecord;
	long	BAPI_GetListTotVariables;
	long	BAPI_GetListIndVariable;
	long	BAPI_GetCurrentFileOffset;
	long	BAPI_LocateObj;
	long	BAPI_IsVariableHidden;
	long	BAPI_GetSID;
	long	BAPI_GetGenericAppInfo;
	
	long	BAPI_GetIncludeStack;
	long	BAPI_GetListTotVariablesExt;
	
} CallBacksRec;
#if TARGET_API_MAC_CARBON
    //XErr	BAPI_InitJavaAPI(long callsBackPtr);
    long	BAPI_PluginBAPIVersion(XErr *errP);
#else
	//EXP XErr	BAPI_InitJavaAPI(long callsBackPtr);
	EXP long	BAPI_PluginBAPIVersion(XErr *errP);
#endif
#endif
