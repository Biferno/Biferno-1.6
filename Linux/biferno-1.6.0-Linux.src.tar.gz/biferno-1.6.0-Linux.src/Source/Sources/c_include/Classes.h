/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Classes.h,v 1.9 2008-11-27 15:27:48 tabasoft Exp $
	|______________________________________________________________________________
*/
// reserved keywords
enum {
		_kTHIS = 1,
		_kSTATIC,
		_kPUBLIC,
		_kPRIVATE,
		_kPROTECTED,
		_kSUPER,
		_kOBJ,
		_kNoNames
};

// Methods												Prototypes:
														// Constructor: void class_name(parameters)
#define	kCloneMethodName			"Clone"				// void	Clone(void)
#define	kDestructorMethodName		"Destructor"		// void	Destructor(void)
#define	kSetPropertyMethodName		"SetProperty"		// void SetProperty(string propertyName)
#define	kOperationMethodName		"Operation"			// void Operation(obj theObj, string operation)
#define	kCompareMethodName			"Compare"			// boolean Compare(obj theObj, string operation)
#define	kGetErrMessageMethodName	"GetErrMessage"		// static string GetErrDescr(int err)
#define	kSuperIsChangedMethodName	"SuperIsChanged"	// void	SuperIsChanged(void)

#define	kToStringMethodName				"tostring"
#define	kToConstrStringMethodName		"toconstrstring"
#define	kToDebugStringMethodName		"todebugstring"

#define	kToCharMethodName		"tochar"
#define	kToIntMethodName		"toint"
#define	kToLongMethodName		"tolong"
#define	kToUnsignedMethodName	"tounsigned"
#define	kToDoubleMethodName		"todouble"
#define	kToBooleanMethodName	"toboolean"

//#define	kWhileSetReturnValuesHint		"while setting parameters by reference"
//#define	kWhileDestructingHint			"while destructing local variables"

/*
#define	kHasCloneMethodBit			1
#define	kHasConstructorMethodBit	2
#define	kHasDestructorMethodBit		4
#define	kHasToStringMethodBit		5
#define	kHasToIntMethodBit			16
#define	kHasToLongMethodBit			32
#define	kHasToUnsignedMethodBit		64
#define	kHasToDoubleMethodBit		128
#define	kHasToBooleanMethodBit		256
#define	kHasGetErrDescrMethodBit	512
#define	kHasSetPropertyMethodBit	1024
#define	kHasOperationMethodBit		2048
*/
#define	kDontExecuteDestructor			1

// ************** da levare ************ 
/*typedef struct {
				CStr255			prototype;			// this must be first field
				CacheResult		sourceFile;
				long			returnClassID;
				long			fileLine;
				long			methodObjList;
				long			methodObjID;
				Boolean			isStatic;
				Byte			visibility;			// used only for class methods, not for funcs
				Boolean			dontCheckNumParams;
				Boolean			dontCheckNames;
				long			returnArraylevel;
				long			returnArrayClassID;
				long			totParams;
				DLMRef			protoParamList;
				long			protoParamObjID;	// func:	in list gsDispatcherData.prototypes
				} BifernoFunc;						// method:	in list	bifernoclass.prototypes

// Property
// ************** da levare ************ 
typedef struct {
				long			arrayLevel;			// max 255
				long			arrayElementClassID;
				Boolean			isStatic;
				Boolean			isConstant;
				Byte			visibility;
				Boolean			isError;
				} PropertyHeader;

// ************** da levare ************ 
typedef struct {
				PropertyHeader	header;
				CStr255			prototype;
				long			classID;
				CStr255			theDefault;
				} BifernoProperty;
*/
// Class
#define		kConstrID	-1

// properties list is ordered with non-static before static properties
typedef struct {
				CStr63			className;
				CStr255			sourceFilePath;
				long			sourceLine;
				long			flags;
				long			extendedClassID;
				DLMRef			properties;			// NAME_LIST with statis and non-static BifernoProperty records
				long			totNonStatic;
				DLMRef			staticProperties;	// ID_LIST with only static objects
				DLMRef			methods;
				//DLMRef		prototypes;			// list of prototypes
				DLMRef			errors;
				
				//long			constructorObjID;
				BlockRef		constructorDoc;
				long			cloneObjID;
				long			destructorObjID;
				long			setPropertyObjID;
				long			operationObjID;
				long			compareObjID;
				long			getErrMessageObjID;
				long			getErrNumberObjID;
				long			superIsChangedObjID;
				long			tostringObjID;
				long			to_debug_stringObjID;
				long			to_construct_stringObjID;
				long			tocharObjID;
				long			tointObjID;
				long			tolongObjID;
				long			tounsignedObjID;
				long			todoubleObjID;
				long			tobooleanObjID;
				} BifernoClass;
		
// Instance
typedef struct {
	// --- IMPORTANT
	// BifernoInstance must be a simple DLRef; MUST NOT contain other fields
	// otherwise you must modify handling of flag kIsDlm in DLM.c, or not use kDLM flag for biferno instance
	// (but then serialize multithread access from inside Classes.c, as normal C extensions containing external reference do (NeedSerialize() etc...)
	// ---
	DLMRef			list;		// ID_LIST with non-static objects
} BifernoInstance;

// Local functions and class ids are subtracted by this  
#define	LOCAL_ID_OFFSET		60000
#define	IS_LOCAL(classID)	(classID < (-LOCAL_ID_OFFSET))

XErr	DestructVariableWithAllSupers(long api_data, ObjRecordP objRefP);

long	GetUserClassID(BifernoRecP bRecP, char *className);
XErr	GetUserClassRecord(BifernoRecP bRecP, long classID, Ptr dataP, long *dataLenP, long offset, long *userDataP);
XErr	ModifyUserClassRecord(BifernoRecP bRecP, long classID, Ptr dataP, long dataLen, long userData, DLMLoopCallBack callBack, long param, DLMLoopCallBack notifyProc);
DLMRef	GetUserClassDLMList(BifernoRecP bRecP, long classID);

//long	GetUserFunctionObjID(BifernoRecP bRecP, char *funcName, BlockRef *membIdentBlockP);
XErr	GetUserFunctionInfo(BifernoRecP bRecP, char *funcName, BlockRef *membIdentBlockP, Boolean *existsP, Boolean *isApplicationP);
//XErr	GetUserFunctionRecord(BifernoRecP bRecP, long classID, Ptr dataP, long *dataLenP, long offset, long *userDataP);
//DLMRef	GetUserFunctionDLMList(BifernoRecP bRecP, long *funcObjIDP);

XErr	BifernoDestructorCallBack(DLMRef dlRef, long objID, long flags, long classID, long scope, long api_data);
XErr	BifernoDestructorCallBack_CheckFlags(DLMRef dlRef, long objID, unsigned short flags, long classID, long userData);

XErr	BifernoCode_Call(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
XErr	GetBifernoFunctionRec(DLMRef list, long funcObjID, Ptr *recP, BlockRef *bRefP, long *totalLenP);
XErr	DefaultProperty(BifernoRecP bRecP, BAPI_Doc *propertyRecP, char *propName, DLMRef instanceList, long theScope, Boolean isStatic, ObjRecord *resultObjRefP);
XErr	DisposeBifernoClass(DLMRef dlRef, long objID, unsigned short flags, long classID, long api_data);

XErr	GetBifernoClassRecAlloc(BifernoRecP bRecP, long classObjID, BifernoClass **bifernoClassPPtr, uint32_t *slotP);
XErr	GetBifernoClassRec(BifernoRecP bRecP, long classObjID, BifernoClass	*bifernoClassP);

XErr	BifernoGetErrorName(long api_data, long classID, long errValue, char *errName);
//XErr	BifernoClassHasMember(long api_data, long classID, MemberIdentification *membIdentP, Boolean *memberExistsP, Boolean fromTryCurrent, SuperIsChangedNotify **notifyP, Boolean getInfo);
XErr	BifernoClassHasMember(long api_data, char *memberName, long classID, ObjRecord *objRefP, BlockRef *membIdentBlockP, MemberAction **membActionP, int followChar, Boolean *memberExistsP, Boolean fromTryCurrent, SuperIsChangedNotify **notifyP, Boolean getInfo, Boolean gettingReference);
//XErr	CloneInstanceObject(DLMRef dlRef, long objID, long flags, long userData, long param);

XErr	BifernoDisposeInstanceList(long api_data, DLMRef dlRef, long objID, long scope);

XErr	BifernoTypeCastToObject(long api_data, ObjRecord *sourceObjP, long requestedClassID, long typeCastType, ObjRecord *resultObjRefP);
XErr	BifernoSetSuper(long api_data, ObjRecord *thisObjRef, ObjRecord *superObjRef, ObjRecord *instSupObjRefPtr);

XErr	CheckIfStatic(MemberAction *membIdentP, ObjRecordP objRefP, Boolean fromTryCurrent, Boolean getInfo, Boolean gettingReference);

char*	_GetOperationStringP(long operation);

#define	DumpStack(x)	((void)0)
//void	DumpStack(char *funcName);
