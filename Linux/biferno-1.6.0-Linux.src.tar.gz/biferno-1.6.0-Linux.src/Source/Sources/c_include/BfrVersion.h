#ifndef __BIFERNO_VERSION__
#define __BIFERNO_VERSION__

	// The current versions of Biferno: 	Unused|Release|Revision|Fix
	#define CUR_BIFERNO_VERSION				(unsigned long)0x00010600

	// Internal stage (Development, Beta, Alpha)
	#define DEVELOPMENT_VERS_STR			""

	// Status
	#define STATUS_VERS_STR					"stable"
#endif
