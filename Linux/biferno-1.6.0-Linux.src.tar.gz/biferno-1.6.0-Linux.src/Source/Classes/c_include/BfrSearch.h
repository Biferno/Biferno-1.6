/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BfrSearch.h,v 1.1 2003-06-25 15:53:42 valfer Exp $
	|______________________________________________________________________________
*/
#ifndef __BIFERNO_SEARCH__
	#define __BIFERNO_SEARCH__
	
//#define		MAX_SEARCHREC_ITEMS		32

// group
#define		kNO_PAR			0
#define		kOPEN_PAR		1
#define		kCLOSE_PAR		2

// operat
#define 	kALL			1
#define 	kALLNOT			2
#define 	kAND			3
#define 	kOR				4
#define 	kANDNOT			5
#define 	kORNOT			6

// wild char (find type)
#define		kCONTAIN		1
#define		kBEGIN			2
#define		kEND			3

#define		MAX_ANDOR_STR	8

#define		SEARCH_MAX_ELEMENT_LENGTH	255
typedef struct {
				char		key[SEARCH_MAX_ELEMENT_LENGTH+1];
				Byte		group;
				Byte		operat;
				Byte		wildChar;		
				Byte		padByte;
				} SearchItem, *SearchItemP;

typedef struct {
				//ObjRef		stringSuperObjRef;	// in an only one object list
				short		totItems;
				short		booleanMode;
				SearchItem	sItem[1];
				} SearchHeader, *SearchHeaderP;

#endif
