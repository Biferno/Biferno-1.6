XErr	GetRescaledDims(long xsize, long ysize, double scale, int *widthP, int *heightP, char *errMessage);
XErr	BifernoConvertImage(char *srcfile, char *dstfile, int jpegQuality, double scale, int width, int height, char *errMessage);
