/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: classInfo.c,v 1.9 2005-03-18 15:25:58 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

// defines
#define	gsPlugName	"classInfo"

// Methods
enum{
		kIsDef = 1,
		kGetErrorDescription
	};
#define TOT_METHODES	2

// Properties
#define TOT_PROPRIETIES	14
enum{
		k_persistenAllowed,
		k_cloneIsNeeded,
		k_wantDestructor,
		k_extendedClass,
		k_implem,
		k_sourcePath,
		k_methods,
		k_properties,
		k_constants,
		k_errors,
		k_descr,
		k_purpose,
		k_seeAlso,
		k_note
	};

#define	TOT_COSTANTS	2

static 	long	classInfoClassID;

typedef struct {
				BAPI_ClassInfo		info;
				BlockRef			xmldoc;
				} ClassInfoRec;

//===========================================================================================
static XErr	_ClassInfoRegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	classInfoProperty[TOT_PROPRIETIES] = 
					{	"persistentAllowed",	k_persistenAllowed,		"boolean",
						"cloneIsNeeded",		k_cloneIsNeeded,		"boolean",
						"wantDestructor",		k_wantDestructor,		"boolean",
						"extendedClass",		k_extendedClass,		"string",
						"implem",				k_implem,				"int",
						"sourcePath",			k_sourcePath,			"string",
						"methods[]",			k_methods,				"string",
						"properties[]",			k_properties,			"string",
						"constants[]",			k_constants,			"string",
						"errors[]",				k_errors,				"string",
						"descr",				k_descr,				"string",
						"purpose",				k_purpose,				"string",
						"seeAlso",				k_seeAlso,				"string",
						"note",					k_note,					"string"
					};
					
BAPI_MemberRecord	classInfoMethods[TOT_METHODES] = 
					{	"IsDef",				kIsDef, 				"static boolean IsDef(string className, boolean allTypes)",
						"GetErrorDescription",	kGetErrorDescription,	"string GetErrorDescription(int error)"
					};

BAPI_MemberRecord	classInfoCostants[TOT_COSTANTS] = 
					{	"c", 			kCImplementation,		"int",
						"biferno", 		kBifernoImplementation,	"int"
					};

	if (err = BAPI_NewProperties(api_data, classInfoClassID, classInfoProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewMethods(api_data, classInfoClassID, classInfoMethods, TOT_METHODES, nil))
		return err;
	if (err = BAPI_NewConstants(api_data, classInfoClassID, classInfoCostants, TOT_COSTANTS, nil))
		return err;

//out:
return err;
}

//===========================================================================================
static XErr	_GetMembArray(long api_data, GetPropertyRec *getPropertyRecP, long which, BAPI_ClassInfo *infoP)
{
XErr			err = noErr;
ArrayIndexRec	mCoord;
ObjRef			tObjRef, *resultP = &getPropertyRecP->resultObjRef;
long			i, tots;
BlockRef		blockRef;
BAPI_Name		*nameRecP;

	if (getPropertyRecP->propertyIndex)
		mCoord = getPropertyRecP->propertyIndex[0];
	else
		ClearBlock(&mCoord, sizeof(ArrayIndexRec));
	if (*mCoord.ind_name)
		err = XError(kBAPI_Error, Err_ArrayElementNotFound);
	else
	{	switch(which)
		{
			case k_methods:
				err = BAPI_GetMembers(api_data, nil, infoP->name, kMethod, &blockRef, &tots, mCoord.ind);
				break;
			case k_properties:
				err = BAPI_GetMembers(api_data, nil, infoP->name, kProperty, &blockRef, &tots, mCoord.ind);
				break;
			case k_constants:
				err = BAPI_GetMembers(api_data, nil, infoP->name, kConstant, &blockRef, &tots, mCoord.ind);
				break;
			case k_errors:
				err = BAPI_GetMembers(api_data, nil, infoP->name, kError, &blockRef, &tots, mCoord.ind);
				break;
		}
		if NOT(err)
		{	if (blockRef)
				nameRecP = (BAPI_Name*)GetPtr(blockRef);
			if (mCoord.ind)
				err = BAPI_StringToObj(api_data, nameRecP->name, CLen(nameRecP->name), resultP);
			else
			{	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, resultP))
				{	if (blockRef)
					{	LockBlock(blockRef);
						for (i = 0; (i < tots) && NOT(err); i++, nameRecP++)
						{	BAPI_InvalObjRef(api_data, &tObjRef);
							if NOT(err = BAPI_StringToObj(api_data, nameRecP->name, CLen(nameRecP->name), &tObjRef))
								err = BAPI_ArrayAddElement(api_data, resultP, nil, &tObjRef);
						}
					}
				}
			}
			if (blockRef)
				DisposeBlock(&blockRef);
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	ClassInfo_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	classInfoClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.fixedSize = true;
	pbPtr->param.registerRec.wantDestructor = true;
	CEquStr(pbPtr->param.registerRec.constructor, "void classInfo(string className, boolean extended)");
		
//out:
return err;
}

//===========================================================================================
static XErr	ClassInfo_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _ClassInfoRegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	ClassInfo_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
CStr63			className;
long			tLen, api_data = pbPtr->api_data;
ParameterRec	*paramVarsP = constructorRecP->varRecsP;
long			classID;
ClassInfoRec	classRec, newClassRec;
Boolean			extended;
Ptr				p;

	if (clone)
	{	tLen = sizeof(ClassInfoRec);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &paramVarsP[0].objRef, (Ptr)&classRec, &tLen, 0, nil))
		{	newClassRec = classRec;
			if (classRec.xmldoc)
			{	tLen = GetBlockSize(classRec.xmldoc, nil);
				if (newClassRec.xmldoc = NewBlockLocked(tLen, &err, &p))
					CopyBlock(p, GetPtr(classRec.xmldoc), tLen);
			}
			if NOT(err)
				err = BAPI_BufferToObj(api_data, (Ptr)&newClassRec, sizeof(ClassInfoRec), classInfoClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
	else if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, className, nil, 64, kImplicitTypeCast))
	{	if (classID = BAPI_ClassIDFromName(api_data, className, false))
		{	if NOT(err = BAPI_GetClassInfo(api_data, classID, &classRec.info))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &paramVarsP[1].objRef, &extended, kImplicitTypeCast))
				{	if (extended)
						err = BAPI_GetClassDoc(api_data, className, &classRec.xmldoc);
					else
						classRec.xmldoc = 0;
					if NOT(err)
						err = BAPI_BufferToObj(api_data, (Ptr)&classRec, sizeof(ClassInfoRec), classInfoClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
				}
			}
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchClass);
	}

return err;
}

//===========================================================================================
static XErr	ClassInfo_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
ClassInfoRec	classInfo;
long			objLen;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(ClassInfoRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&classInfo, &objLen, 0, nil))
		{	if (objLen && classInfo.xmldoc)
				DisposeBlock(&classInfo.xmldoc);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	ClassInfo_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
XErr				err = noErr;
long				tLen;
Primitive_String	*textP;
PrimitiveUnion		*param_d;
ClassInfoRec		classInfo;
long				size;
Boolean				needSer;
CStr255				resStr;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		param_d = &typeCast->result;
		tLen = sizeof(ClassInfoRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&classInfo, &tLen, 0, nil))
		{	if (typeCast->resultWanted == kBool)
			{	if (tLen)
					typeCast->result.boolValue = (*classInfo.info.name != 0);
				else
					typeCast->result.boolValue = false;
			}
			else if (typeCast->resultWanted == kCString)
			{	textP = &param_d->text;
				*resStr = 0;
				if (param_d->text.variant == kForConstructor)
					CAddChar(resStr, '\"');
				if (tLen)
					CAddStr(resStr, classInfo.info.name);
				if (param_d->text.variant == kForConstructor)
					CAddChar(resStr, '\"');
				size = CLen(resStr);
				if (textP->stringP)
				{	if (textP->stringMaxStorage >= (size + 1))
					{	CopyBlock(textP->stringP, resStr, size);
						textP->stringP[size] = 0;
						textP->stringLen = size;
					}
					else
					{	CopyBlock(textP->stringP, resStr, textP->stringMaxStorage - 1);
						textP->stringP[textP->stringMaxStorage - 1] = 0;
						textP->stringLen = size;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					textP->stringLen = size;
			}
			else
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static XErr	ClassInfo_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr				err = noErr;
long				tLen, api_data = pbPtr->api_data;
ObjRef				*resultObjRefP = &getPropertyRec->resultObjRef;
ClassInfoRec		classInfo;
CStr255				aCStr;
Boolean				needSer;
BAPI_Descr			*descrP;

	if (getPropertyRec->isConstant)
		return BAPI_IntToObj(api_data, getPropertyRec->propertyID, &getPropertyRec->resultObjRef);

	if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
		err = BAPI_NeedSerialize(api_data, &getPropertyRec->objRef, &needSer);
	else
		needSer = false;
	if (needSer)
		XThreadsEnterCriticalSection();
	if NOT(err)
	{	tLen = sizeof(ClassInfoRec);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&classInfo, &tLen, 0, nil))
		{	switch(getPropertyRec->propertyID)
			{
				case k_persistenAllowed:
					err = BAPI_BooleanToObj(api_data, classInfo.info.canHavePersistent, &getPropertyRec->resultObjRef);
					break;
				case k_cloneIsNeeded:
					err = BAPI_BooleanToObj(api_data, classInfo.info.cloneObjects, &getPropertyRec->resultObjRef);
					break;
				case k_wantDestructor:
					err = BAPI_BooleanToObj(api_data, classInfo.info.wantDestructor, &getPropertyRec->resultObjRef);
					break;
				case k_extendedClass:
					if (classInfo.info.extendedClassID)
						err = BAPI_NameFromClassID(api_data, classInfo.info.extendedClassID, aCStr);
					else
						*aCStr = 0;
					if NOT(err)
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRec->resultObjRef);
					break;
				case k_implem:
					err = BAPI_IntToObj(api_data, classInfo.info.implem, &getPropertyRec->resultObjRef);
					break;
				case k_sourcePath:
					if (*classInfo.info.sourceFilePath)
					{	CEquStr(aCStr, FILE_HD_PREFIX);
						CAddStr(aCStr, classInfo.info.sourceFilePath);
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), resultObjRefP);
					}	
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_methods:
					err = _GetMembArray(api_data, getPropertyRec, k_methods, &classInfo.info);
					break;
				case k_properties:
					err = _GetMembArray(api_data, getPropertyRec, k_properties, &classInfo.info);
					break;
				case k_constants:
					err = _GetMembArray(api_data, getPropertyRec, k_constants, &classInfo.info);
					break;
				case k_errors:
					err = _GetMembArray(api_data, getPropertyRec, k_errors, &classInfo.info);
					break;
				case k_descr:
					if (classInfo.xmldoc)
					{	descrP = (BAPI_Descr*)GetPtr(classInfo.xmldoc);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->descr.off, descrP->descr.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_purpose:
					if (classInfo.xmldoc)
					{	descrP = (BAPI_Descr*)GetPtr(classInfo.xmldoc);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->purpose.off, descrP->purpose.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_seeAlso:
					if (classInfo.xmldoc)
					{	descrP = (BAPI_Descr*)GetPtr(classInfo.xmldoc);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->seeAlso.off, descrP->seeAlso.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_note:
					if (classInfo.xmldoc)
					{	descrP = (BAPI_Descr*)GetPtr(classInfo.xmldoc);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->note.off, descrP->note.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static XErr	ClassInfo_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	switch(setPropertyRec->propertyID)
	{
		case k_persistenAllowed:
		case k_cloneIsNeeded:
		case k_wantDestructor:
		case k_extendedClass:
		case k_methods:
		case k_properties:
		case k_constants:
		case k_errors:
		case k_descr:
		case k_purpose:
		case k_seeAlso:
		case k_note:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
static XErr	ClassInfo_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
ParameterRec 		*paramVarsP = exeMethodRecP->paramVarsP;
CStr63				className;
CStr255				errMessage;
Boolean				allTypes, isDef;
long				theError;
long				tLen;
BAPI_ClassInfo		classInfo;

	switch(exeMethodRecP->methodID)
	{
		case kIsDef:
			if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, className, nil, 64, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &paramVarsP[1].objRef, &allTypes, kImplicitTypeCast))
				{	if (BAPI_ClassIDFromName(api_data, className, allTypes))
						isDef = true;
					else
						isDef = false;
					err = BAPI_BooleanToObj(api_data, isDef, &exeMethodRecP->resultObjRef);
				}
			}
			break;
		
		case kGetErrorDescription:
			tLen = sizeof(BAPI_ClassInfo);
			if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&classInfo, &tLen, 0, nil))
			{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[0].objRef, &theError, kImplicitTypeCast))
				{	if NOT(err = BAPI_GetErrMessage(api_data, classInfo.id, (short)theError, nil, errMessage, nil))
						err = BAPI_StringToObj(api_data, errMessage, CLen(errMessage), &exeMethodRecP->resultObjRef);
				}
			}
			break;

		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	classInfo_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = ClassInfo_Register(pbPtr);
			break;
		case kInit:
			err = ClassInfo_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = ClassInfo_Constructor(pbPtr, false);
			break;
		case kClone:
			err = ClassInfo_Constructor(pbPtr, true);
			break;
		case kDestructor:
			err = ClassInfo_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = ClassInfo_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = ClassInfo_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = ClassInfo_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = ClassInfo_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


