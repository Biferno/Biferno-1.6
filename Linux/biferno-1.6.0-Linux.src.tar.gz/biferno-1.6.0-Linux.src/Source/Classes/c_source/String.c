/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: String.c,v 1.15 2004-05-04 13:21:55 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BifernoEngineAPI.h"
#include 	"StaticClasses.h"

#include 	"SendMail.h"
#include 	"BfrSearch.h"

#include <stdio.h>
#include <string.h>

// Methods
enum{
		kEncode = 1,
		kDecode,
		kEscape,
		kURLEncode,
		kURLDecode,
		//kEncodeJavaScript,
		//kDecodeJavaScript,
		kFind,
		kBegins,
		kEnds,
		kContains,
		kContainsWordBegin,
		kContainsWordEnd,
		kContainsWordExact,
		kIn,
		kCompare,
		kUpToLower,
		kLowToUpper,
		kSubString,
		kToArray,
		kIsEMail,
		kIsDate,
		kIsNumeric,
		k_Hilite,
		kSubstitute,
		kZap,
		kPad,
		kHTUUEncode,
		kHTUUDecode,
		kCapitalize,
		kRemoveSubString,
		kInsertSubString,
		kIsANSIStandard,
		kLog,
		kHex2Bin,
		kBin2Hex,
		kMD5
		//kDec
	};
#define TOT_METHODES	35

// Properties
#define TOT_PROPRIETIES	2
enum{
		kLength = 1,
		kCharProperty
	};

#define TOT_COSTANTS	2
enum{
		kHtmlTags = 0,
		kAllTags
	};


// defines
#define	gsPlugName	"string"

static 	long		unsignedClassID, stringClassID, searchClassID, arrayClassID, intClassID,boolClassID, charClassID;
static 	long		gsApiVersion;
static	CStr63		hi_preStr = "<font color=\"red\"><b>";
static	CStr63		hi_postStr = "</b></font>";

// Errors
#define	STRING_START_ERR	100
enum {
		ErrBadIndex = STRING_START_ERR,
		ErrBadLength,
		ErrTooLongSeparator
};

CStr63	gStringErrorsStr[] = 
	{	
		"ErrBadIndex",
		"ErrBadLength",
		"ErrTooLongSeparator"
		};

#define	TOT_ERRORS	3

#define	MAX_HILITE	64

typedef struct {
				long			*offsets;
				long			*end_offsets;
				Ptr				textP;
				long			textLen;
				long			*curOffP;
				short			pad;
				Boolean			cs;
				Boolean			skipHTML;
			} ArrHiliteRec;

//--- MD5 code
#include	"global.h"
#include	"md5.h"

#define HASHLEN 16
typedef char HASH[HASHLEN];
#define HASHHEXLEN 32
typedef char HASHHEX[HASHHEXLEN+1];
#define IN
#define OUT
//---

//===========================================================================================
static XErr	_ArrHiliteCallBack(long api_data, char *elemName, ObjRefP element, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(elemName)
#endif
XErr			err = noErr;
ArrHiliteRec	*arrHRecP = (ArrHiliteRec*)param;
long			totOffsets, *tempOffP, *tempEnd_OffP;
CStr255			aCStr;
long			curOff = *arrHRecP->curOffP;
					
	tempOffP = arrHRecP->offsets + curOff;
	tempEnd_OffP = arrHRecP->end_offsets + curOff;
	if NOT(err = BAPI_ObjToString(api_data, element, aCStr, nil, 255, kImplicitTypeCast))
	{	if NOT(err = OffsetsInText(arrHRecP->textP, arrHRecP->textLen, aCStr, arrHRecP->cs, tempOffP, tempEnd_OffP, &totOffsets, MAX_HILITE - curOff, arrHRecP->skipHTML))
			*arrHRecP->curOffP += totOffsets;
	}
		
return err;
}

//===========================================================================================
static void	_ReleaseBlock(BlockRef *refP)
{
	if (*refP)
		DisposeBlock((BlockRef*)refP);
}

//===========================================================================================
static XErr	_GetBlock(long api_data, ObjRefP objRef, SearchHeaderP *stringP, long *stringLen, BlockRef *refP)
{		
XErr		err = noErr;
long		dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock;
long 		tLen;

	*refP = 0;
	dataLen = 0;
	if NOT(err = BAPI_GetObj(api_data, objRef, nil, &dataLen, 0, nil))
	{	++dataLen;	// 0-final
		if (dataBlock = NewBlockLocked(dataLen, &err, &dataP))
		{	//LockBlock(dataBlock);
			//dataP = GetPtr(dataBlock);
			*stringP = (SearchHeaderP)dataP;
			*refP = dataBlock;
			tLen = dataLen - 1;
			if NOT(err = BAPI_GetObj(api_data, objRef, dataP, &tLen, 0, nil))
			{	*stringLen = tLen;
				dataP[tLen] = 0;
			}
		}	
	}
	
if (err && *refP)
	DisposeBlock(&dataBlock);
return err;
}

//===========================================================================================
static XErr	_CheckBuff(BlockRef block, ParameterRec **varRecsPPtr, long id, long i)
{
Boolean	moved;
XErr	err = noErr;

	if NOT(err = BufferCheck(id, (i + 1) * sizeof(ParameterRec), &moved))
	{	if (moved)
		{	//block = BufferGetBlockRef(id, nil);
			//LockBlock(block);
			*varRecsPPtr = (ParameterRec*)GetPtr(block);
		}
	}

return err;
}

//===========================================================================================
static XErr	_CheckThousSep(Byte *lastThusSepPos, long totPoints, long strLen)
{
int		t, i;
XErr	err = noErr;

	if (totPoints)
	{	t = ((strLen - totPoints) / 3);
		t -= ((t * 3) == 0);
		if (totPoints != t)
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
		else
		{	strLen -= 3;
			for (i = totPoints-1; (i >= 0) && NOT(err); i--, strLen -= 4)
			{	if (lastThusSepPos[i] != strLen)
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_StringToNumeric(char **strP, long *strLenP, int which, Byte thousSep, Byte decSep, Boolean removeSign)
{
int			pos, ch;
char 		*chP = *strP, *writeP;
XErr		err = noErr;
Boolean		decim = false, thCheck = false;
long		k = 0, strLen = *strLenP;
Byte		lastThusSepPos[85];		// 255/3

	if (strLen > 255)
		return XError(kBAPI_Error, Err_IllegalTypeCast);
	if (*chP)
	{	writeP = chP;
		if (*chP == '+')
		{	chP++;
			writeP++;
		}
	 	else if (*chP == '-')
		{	chP++;
			writeP++;
			if (removeSign)	// (which == kUnsigned)
			{	(*strP)++;
				strLen--;
			}
		}
		pos = 1;
		do	{
			ch = *chP;
			if ((ch < '0') || (ch > '9'))
			{	if (ch == thousSep)
				{	if (decim)
						return XError(kBAPI_Error, Err_IllegalTypeCast);
					else
					{	lastThusSepPos[k++] = pos;
						strLen--;
						ch = *++chP;
						pos++;
					}
				}
				else
				{	if (which == kDouble)		
					{	/*if (ch == '.')
						{	if (decim)
								return XError(kBAPI_Error, Err_IllegalTypeCast);
							if (err = _CheckThousSep(lastThusSepPos, k, pos-1))
								return err;
							else
								thCheck = true;
							decim = true;
						}
						else 
						*/
						if (ch == decSep)
						{	if (decim)
								return XError(kBAPI_Error, Err_IllegalTypeCast);
							if (err = _CheckThousSep(lastThusSepPos, k, pos-1))
								return err;
							else
								thCheck = true;
							decim = true;
							ch = '.';
						}
						else	
							return XError(kBAPI_Error, Err_IllegalTypeCast);
					}
					else
					{	if (/*(ch == '.') || */(ch == decSep))
						{	*chP++ = 0;
							strLen = CLen(*strP);
							// thous sep must not follow
							while (*chP)
							{	if (*chP++ == thousSep)
									return XError(kBAPI_Error, Err_IllegalTypeCast);
							}
							break;
						}
						else	
							return XError(kBAPI_Error, Err_IllegalTypeCast);
					}
				}
			}
			*writeP++ = ch;
			chP++;
			pos++;
		} while(*chP);
		if (NOT(thCheck) && (err = _CheckThousSep(lastThusSepPos, k, pos-1)))
			return err;
		(*strP)[strLen] = 0;
		if NOT(err)
			*strLenP = strLen;
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);

return err;
}

//===========================================================================================
static void	_ReleaseStringBlock(BlockRef *refP)
{
	if (*refP)
		DisposeBlock((BlockRef*)refP);
}

//===========================================================================================
static XErr	_GetStringBlock(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType)
{		
XErr		err = noErr;

	if (OBJ_CLASSID_P(objRef) == stringClassID)
		err = BAPI_GetObjBlock(api_data, objRef, aCStr, stringP, stringLen, refP);
	else
		err = BAPI_GetStringBlock(api_data, objRef, aCStr, stringP, stringLen, refP, typeCastType);

return err;
}

//===========================================================================================
static XErr	_GetStringBlockMore(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, long moreStorage, BlockRef *refP, long typeCastType)
{		
XErr		err = noErr;
long		totalLen, dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock;

	*refP = 0;
	if (OBJ_CLASSID_P(objRef) == stringClassID)
	{	dataLen = 0;
		if NOT(err = BAPI_GetObj(api_data, objRef, nil, &dataLen, 0, nil))
		{	++dataLen;	// 0-final
			totalLen = dataLen + moreStorage;
			if ((totalLen < 255) && aCStr)
			{	dataP = aCStr;
				*refP = 0;
				*stringP = dataP;
			}
			else
			{	if (dataBlock = NewBlockLocked(totalLen, &err, &dataP))
				{	*stringP = dataP;
					*refP = dataBlock;
				}
			}
			if NOT(err)
			{	long tLen = dataLen - 1;
				if NOT(err = BAPI_GetObj(api_data, objRef, dataP, &tLen, 0, nil))
				{	*stringLen = tLen;
					dataP[tLen] = 0;
				}
			}	
		}
	}
	else
	{	if NOT(err = BAPI_ObjToString(api_data, objRef, nil, &dataLen, 0, typeCastType))
		{	++dataLen;	// 0-final
			totalLen = dataLen + moreStorage;
			if ((totalLen < 255) && aCStr)
			{	dataP = aCStr;
				*refP = 0;
				*stringP = dataP;
			}
			else
			{	if (dataBlock = NewBlockLocked(totalLen, &err, &dataP))
				{	*stringP = dataP;
					*refP = dataBlock;
				}
			}
			if NOT(err)
			{	if NOT(err = BAPI_ObjToString(api_data, objRef, dataP, &dataLen, dataLen-1, typeCastType))
					*stringLen = dataLen;
			}	
		}
	}
	
if (err && *refP)
	DisposeBlock(&dataBlock);
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_Encode(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
Boolean		extTags, entities, tagsVisible, alsoCR;
CStr255		aStr;
Ptr			stringP;
long		stringLen;
BlockRef	ref;
BlockRef	resultStringBlock;
long		resultLen;
ObjRefP		param4P;
long		param4PClassID, userTagList;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[0].objRef, &alsoCR, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &tagsVisible, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &entities, kImplicitTypeCast))
				{	param4P = &exeMethodRecP->paramVarsP[3].objRef;
					param4PClassID = BAPI_GetObjClassID(api_data, param4P);
					if (param4PClassID == arrayClassID)
					{	if NOT(err = BAPI_GetArrayInfo(api_data, param4P, nil, nil, &userTagList))
							extTags = false;
					}
					else
					{	if (param4PClassID == intClassID)
							err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[3].objRef, &userTagList, kImplicitTypeCast);
						else
							userTagList = kHtmlTags;
						if NOT(err)
						{	if (userTagList == kHtmlTags)
								extTags = false;
							else
								extTags = true;
							userTagList = 0;
						}
					}
					if NOT(err)
					{	err = BAPI_EncodeIsolatin(api_data, (Byte*)stringP, stringLen, &resultStringBlock, &resultLen, alsoCR, tagsVisible, entities, extTags, userTagList);
						_ReleaseStringBlock(&ref);
						if NOT(err)
						{	err = BAPI_StringToObj(api_data, GetPtr(resultStringBlock), resultLen, &exeMethodRecP->resultObjRef);
							DisposeBlock(&resultStringBlock);
						}
					}
				}
			}
		}
		if (ref)
			_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_Escape(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			stringP;
long		stringLen;
BlockRef	ref, escapedBlock;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = StringEscaped(&stringP, &stringLen, &escapedBlock))
		{	LockBlock(escapedBlock);
			err = BAPI_StringToObj(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef);
			DisposeBlock(&escapedBlock);
		}
		if (ref)
			_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_Decode(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
Boolean		alsoCR;
CStr255		aStr;
Ptr			stringP;
long		resultLen, stringLen;
BlockRef	ref;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[0].objRef, &alsoCR, kImplicitTypeCast))
		{	if NOT(err = DecodeIsolatinFast(stringP, alsoCR, &resultLen))
				err = BAPI_StringToObj(api_data, stringP, resultLen, &exeMethodRecP->resultObjRef);
			_ReleaseStringBlock(&ref);
		}
		if (ref)
			_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_URL(ExecuteMethodRec *exeMethodRecP, long which, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
CStr63		preStr;
Ptr			stringP;
long		stringLen;
BlockRef	ref;
BlockRef	encodedStringBlock = 0;
long		resultLen;
Boolean		spaceToPlus;
Ptr			resP;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[0].objRef, &spaceToPlus, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, preStr, nil, 63, kImplicitTypeCast))
			{	if (which == kURLEncode)
				{	if NOT(err = BAPI_EncodeURL(api_data, (Byte*)stringP, stringLen, &encodedStringBlock, &resultLen, spaceToPlus, preStr))
					{	LockBlock(encodedStringBlock);
						resP = GetPtr(encodedStringBlock);
					}
				}
				else
				{	if NOT(err = DecodeURLFast(stringP, spaceToPlus, preStr, &resultLen))
						resP = stringP;
				}
				if NOT(err)
				{	err = BAPI_StringToObj(api_data, resP, resultLen, &exeMethodRecP->resultObjRef);
					if (encodedStringBlock)
						DisposeBlock(&encodedStringBlock);
				}
			}
		}
		_ReleaseStringBlock(&ref);
	}
	
return err;
}

//===========================================================================================
/*static XErr	_EncDecodeJavaScript(ExecuteMethodRec *exeMethodRecP, long api_data, Boolean toEncode)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			stringP;
long		stringLen;
BlockRef	ref;
BlockRef	resultStringBlock;
long		resultLen;
			
	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if (toEncode)
			err = BAPI_EncodeJavaScript(api_data, (Byte*)stringP, stringLen, &resultStringBlock, &resultLen);
		else
			err = BAPI_DecodeJavaScript(api_data, (Byte*)stringP, stringLen, &resultStringBlock, &resultLen);
		_ReleaseStringBlock(&ref);
		if NOT(err)
		{	err = BAPI_StringToObj(api_data, GetPtr(resultStringBlock), resultLen, &exeMethodRecP->resultObjRef);
			DisposeBlock(&resultStringBlock);
		}
	}

return err;
}*/

//===========================================================================================
static XErr	_Compare(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr				err = noErr;
long				stringLen, string2Len;
CStr255				aStr, aStr2;
Ptr					stringP, string2P;
BlockRef			ref, ref2;
Boolean				cs;
long				result;

	if ((totParams == 1) || (totParams == 2))
	{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
		{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	if (totParams == 2)
					err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &cs, kImplicitTypeCast);
				else
					cs = false;
				if NOT(err)
				{	stringP[stringLen] = 0;
					string2P[string2Len] = 0;
					if (cs)
						result = CCompareStrings_cs(stringP, string2P);
					else
						result = CCompareStrings(stringP, string2P);
					err = BAPI_IntToObj(api_data, result, &exeMethodRecP->resultObjRef);
				}
				_ReleaseStringBlock(&ref2);
			}
			_ReleaseStringBlock(&ref);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_In(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		str;
long		sepLen, strLen, textLen;
CStr255		aStr;
Ptr			textP;
BlockRef	ref;
Byte		sep[256];
Boolean		result;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aStr, &textP, &textLen, &ref, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->objRef, str, &strLen, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, (Ptr)sep, &sepLen, 255, kImplicitTypeCast))
			{	if (sepLen > 1)
					err = XError(kBAPI_ClassError, ErrTooLongSeparator);
				else
				{	result = StringInText(str, strLen, textP, textLen, *sep);
					err = BAPI_BooleanToObj(api_data, result, &exeMethodRecP->resultObjRef);
				}	
			}
		}
		_ReleaseStringBlock(&ref);
	}
	
return err;
}

//===========================================================================================
static XErr	_Find(ExecuteMethodRec *exeMethodRecP, long totParams, long which, long api_data)
{
XErr				err = noErr;
long				stringLen, string2Len;
CStr255				aStr, aStr2;
Ptr					stringP, string2P;
BlockRef			ref, ref2;
Boolean				cs, res;
long				tLen, index;
int					bpos, pos;
			
				
	if ((totParams == 1) || (totParams == 2) || (totParams == 3))
	{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
		{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	if ((totParams == 2) && OBJ_ID(exeMethodRecP->paramVarsP[1].objRef))
					err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &cs, kImplicitTypeCast);
				else
					cs = false;
				if NOT(err)
				{	if (which == kEnds)
					{	tLen = stringLen - string2Len;
						if (cs)
							res = (tLen >= 0) && NOT(CCompareStrings_cs(stringP + tLen, string2P));
						else
							res = (tLen >= 0) && NOT(CCompareStrings(stringP + tLen, string2P));
						err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);
					}
					else
					{	long	from;
					
						if (which == kFind)
						{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &from, kImplicitTypeCast))
							{	if NOT(from)
									from = 1;
								else if ((from < 0) || (from > stringLen))
									err = XError(kBAPI_ClassError, ErrBadIndex);
								from--;	
							}
						}
						else
							from = 0;
						if NOT(err)
						{	switch(which)
							{
								case kFind:
									res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false);
									// index == 0 means no found
									if (index == -1)
										index = 0;
									else
										index += from;
									err = BAPI_IntToObj(api_data, index, &exeMethodRecP->resultObjRef);
									break;
								case kBegins:
									res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false);
									err = BAPI_BooleanToObj(api_data, (Boolean)(index == 1), &exeMethodRecP->resultObjRef);
									break;
								case kEnds:
									res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false);
									break;
								case kContains:
									res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false);
									err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);
									break;
								case kContainsWordBegin:
									res = false;
									while NOT(res)
									{	if (res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false))
										{	pos = index - 2;
											// Check the "before char"
											if (pos >= 0)
												res = IsSeparChar(stringP + pos, stringLen - pos, nil);
											else
												res = true;
											if NOT(res)
											{	bpos = index + string2Len - 1;
												stringP += bpos;
												stringLen -= bpos;
												if ((stringLen - from) <= 0)
													break;
											}
										}
										else
											break;
									}
									/*res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false);
									while (res && (index > 1))
									{	ch = stringP[index - 2];
										res = ((ch == ' ') || (ch == '\r') || (ch == '\t') || (ch == '(')	|| (ch == '\"') || (ch == '\'') || (ch == '\n'));
										if NOT(res)
											res = FindStringInText(string2P, string2Len, stringP + from + index - 1, stringLen - from - index, &index, cs, false);
										else
											break;
									}*/
									err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);	
									break;
								case kContainsWordEnd:
									res = false;
									while NOT(res)
									{	if (res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false))
										{	// Check the "after char"
											bpos = index + string2Len - 1;
											if (bpos < stringLen)
												res = IsSeparChar(stringP + bpos, stringLen - bpos, nil);
											else
												res = true;
											if NOT(res)
											{	stringP += bpos;
												stringLen -= bpos;
												if ((stringLen - from) <= 0)
													break;
											}
										}
										else
											break;
									}
									/*
									res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false);
									pos = index + string2Len - 1;
									if (res && (pos < stringLen))
									do
									{	ch = stringP[pos];
										res = ((ch == ' ') || (ch == '\r') || (ch == '\t') || (ch == ')') || (ch == '.') || (ch == ',') || (ch == ';') || (ch == ':')	|| (ch == '!') || (ch == '?') || (ch == '\"') || (ch == '\'') || (ch == '\n'));
										if NOT(res)
											res = FindStringInText(string2P, string2Len, stringP + from + index - 1, stringLen - from - index, &index, cs, false);
									} while (NOT(res) && (index > 1));*/
									err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);	
									break;
								case kContainsWordExact:
									res = false;
									while NOT(res)
									{	if (res = FindStringInText(string2P, string2Len, stringP + from, stringLen - from, &index, cs, false))
										{	// Check the "after char"
											bpos = index + string2Len - 1;
											if (bpos < stringLen)
												res = IsSeparChar(stringP + bpos, stringLen - bpos, nil);
											else
												res = true;
											if (res)
											{	pos = index - 2;
												// Check the "before char"
												if (pos >= 0)
													res = IsSeparChar(stringP + pos, stringLen - pos, nil);
												else
													res = true;
											}
											if NOT(res)
											{	stringP += bpos;
												stringLen -= bpos;
												if ((stringLen - from) <= 0)
													break;
											}
										}
										else
											break;
									}
									err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);	
									break;
							}
						}
					}
				}
				_ReleaseStringBlock(&ref2);
			}
			_ReleaseStringBlock(&ref);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}
//===========================================================================================
static XErr	_UpLow(ExecuteMethodRec *exeMethodRecP, long which, long api_data)
{
XErr				err = noErr;
long				from, len, stringLen;
CStr255				aStr;
Ptr					stringP;
BlockRef			ref;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if (stringLen)
		{	stringP[stringLen] = 0;
			if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &from, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &len, kImplicitTypeCast))
				{	if NOT(from)
						from = 1;
					if NOT(len)
						len = stringLen;
					if ((from <= 0) || (from > stringLen))
						err = XError(kBAPI_ClassError, ErrBadIndex);
					else if (len < 0)
						err = XError(kBAPI_ClassError, ErrBadLength);
					else if (len > (stringLen - from + 1))
						len = stringLen - from + 1;
					if NOT(err)
					{	if (which == kUpToLower)
							CUp2LowerStr(stringP + from - 1, len);
						else
							CLow2UpperStr(stringP + from - 1, len);
						_ReleaseStringBlock(&ref);
						if NOT(err)
							err = BAPI_StringToObj(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef);
					}
				}
			}
		}
		else
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
	}								

return err;
}

//===========================================================================================
static XErr	_SubString(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr				err = noErr;
long				stringLen;
CStr255				aStr;
Ptr					stringP;
BlockRef			ref;
long				from, len;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if (stringLen)
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &from, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &len, kImplicitTypeCast))
				{	if NOT(from)
						from = 1;
					if NOT(len)
						len = stringLen;
					if ((from <= 0) || (from > stringLen))
						err = XError(kBAPI_ClassError, ErrBadIndex);
					else if (len < 0)
						err = XError(kBAPI_ClassError, ErrBadLength);
					else if (len > (stringLen - from + 1))
						len = stringLen - from + 1;
					if NOT(err)
						stringP += from - 1;	// from is 1 - based
				}
			}
			if NOT(err)
				err = BAPI_StringToObj(api_data, stringP, len, &exeMethodRecP->resultObjRef);
		}
		else
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
		_ReleaseStringBlock(&ref);
	}								

return err;
}

//===========================================================================================
static XErr	_CharsVector(long api_data, char *stringP, long stringLen, ObjRefP resultObjRef)
{
long			i;
ObjRef			tObjRef;
ParameterRec	param;
XErr			err = noErr;
	
	if NOT(err = BAPI_ArrayToObj(api_data, true, nil, 0, nil, nil, resultObjRef))
	{	BAPI_ClearParameterRec(api_data, &param);
		for (i = 0; (i < stringLen) && NOT(err); i++, stringP++)
		{	BAPI_InvalObjRef(api_data, &param.objRef);
			if NOT(err = BAPI_StringToObj(api_data, stringP, 1, &param.objRef))
			{	BAPI_InvalObjRef(api_data, &tObjRef);
				if NOT(err = BAPI_Constructor(api_data, charClassID, &param, 1, &tObjRef))
					err = BAPI_ArrayAddElement(api_data, resultObjRef, nil, &tObjRef);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_ToArray(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr			err = noErr;
CStr63			delims;
CStr255			aStr;
Ptr				itemP, stringP;
BlockRef		bl, ref;
long			itemLen, delimsLen, id, stringLen;
int				i;
ParameterRec	*varRecsP;
ObjRefP			tObjP;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, delims, &delimsLen, 63, kImplicitTypeCast))
		{	delims[delimsLen] = 0;
			if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
			{	stringP[stringLen] = 0;
				if (stringLen)
				{	i = 0;
					if (delimsLen)
					{	if (id = BufferCreate(512, &err))
						{	bl = BufferGetBlockRef(id, nil);
							LockBlock(bl);
							varRecsP = (ParameterRec*)GetPtr(bl);
							itemP = stringP;
							itemLen = 0;
							if (stringLen)
							{	do {
										if ((stringLen >= delimsLen) && NOT(CompareBlock(stringP, delims, delimsLen)))
										{	if NOT(err = _CheckBuff(bl, &varRecsP, id, i))
											{	*varRecsP[i].name = 0;
												tObjP = &varRecsP[i++].objRef;
												BAPI_InvalObjRef(api_data, tObjP);
												err = BAPI_StringToObj(api_data, itemP, itemLen, tObjP);
											}
											stringP += delimsLen;
											stringLen -= delimsLen;
											itemLen = 0;
											itemP = stringP;
										}
										else
										{	stringP++;
											stringLen--;
											itemLen++;
										}
									} while ((stringLen > 0) && NOT(err));
							}
							if NOT(err = _CheckBuff(bl, &varRecsP, id, i))
							{	*varRecsP[i].name = 0;
								tObjP = &varRecsP[i++].objRef;
								BAPI_InvalObjRef(api_data, tObjP);
								err = BAPI_StringToObj(api_data, itemP, itemLen, tObjP);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, false, varRecsP, i, nil, nil, &exeMethodRecP->resultObjRef);
							BufferFree(id);
						}
					}
					else
						err = _CharsVector(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef);
				}
				else
				{	ObjRef	tObjRef;
				
					BAPI_InvalObjRef(api_data, &tObjRef);
					if NOT(err = BAPI_StringToObj(api_data, "", 0, &tObjRef))
					{	ParameterRec	param;
					
						BAPI_ClearParameterRec(api_data, &param);
						param.objRef = tObjRef;
						err = BAPI_ArrayToObj(api_data, false, &param, 1, nil, nil, &exeMethodRecP->resultObjRef);
					
					}
				}
				_ReleaseStringBlock(&ref);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_IsDate(ExecuteMethodRec *exeMethodRecP, long api_data)
{
CStr255			formatStr, timeStr;
XErr			err = noErr, tErr = noErr;
XDateTimeRec	timeRec;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->objRef, timeStr, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, formatStr, nil, 255, kImplicitTypeCast))
		{	if NOT(*formatStr)
				err = BAPI_GetDateFormat(api_data, formatStr);
			if NOT(err)
			{	tErr = XStringToDateTime(timeStr, &timeRec, formatStr);
				err = BAPI_BooleanToObj(api_data, (Boolean)(tErr == 0), &exeMethodRecP->resultObjRef);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_IsNumeric(ExecuteMethodRec *exeMethodRecP, long api_data)
{
CStr255			numStr;
long			numStrLen;
XErr			err = noErr, tErr = noErr;
Byte			thousSep, decSep;
char			*strP;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->objRef, numStr, &numStrLen, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_GetNumberFormat(api_data, &thousSep, &decSep))
		{	strP = numStr;
			tErr = _StringToNumeric(&strP, &numStrLen, kDouble, thousSep, decSep, false);
			err = BAPI_BooleanToObj(api_data, (Boolean)(tErr == 0), &exeMethodRecP->resultObjRef);
		}
	}

return err;
}

//===========================================================================================
static XErr	_IsValidEMail(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
Boolean		result = false;
CStr255		errMessage, address;	//, user, host;
//char		*strP = address;
Boolean		checkIfExists;
//BlockRef	mxBlock;
//int			i;
//long		mxTot;
//MXRecord	*mxRecordP;

	*errMessage = 0;
	err = BAPI_ObjToString(api_data, &exeMethodRecP->objRef, address, nil, 255, kImplicitTypeCast);
	if NOT(err)
	{	result = _IsEMail(address);
		if (result && NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[0].objRef, &checkIfExists, kImplicitTypeCast)))
		{	if (checkIfExists)
			{	
				err = VerifyMailAddress(address, errMessage, &result);
				/*CEquStr(user, address);
				strP = user;
				do {
					if (*strP == '@')
					{	*strP = 0;
						break;
					}
				} while (*strP++);
				result = false;
				if (*++strP)
				{	CEquStr(host, strP);
					mxTot = 32;
					if (mxBlock = NewBlockLocked(sizeof(MXRecord) * mxTot, &err, (Ptr*)&mxRecordP))
					{	if NOT(err = GetMXRecords(host, mxRecordP, &mxTot))
						{	if (mxTot)
							{	for (i = 0; (i < mxTot) && NOT(err); i++, mxRecordP++)
								{	if (result = IsAddressValid(mxRecordP->name, address, errMessage))
										break;
								}
							}
						}
						else
							err = noErr;
						DisposeBlock(&mxBlock);
					}
				}*/
			}
		}
	}
	else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
	{	result = false;
		err = noErr;
	}
	if NOT(err)
	{
	Boolean	isInit;
	
		if NOT(err = BAPI_BooleanToObj(api_data, result, &exeMethodRecP->resultObjRef))
		{	if NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[1].objRef, &isInit))
			{	if (isInit)
					err = BAPI_StringToObj(api_data, errMessage, CLen(errMessage), &exeMethodRecP->paramVarsP[1].objRef);
			}
		}
	}
		
return err;
}

//===========================================================================================
static XErr	_Hilite(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr			err = noErr;
Boolean			skipHTML, cs;
CStr255			textStr, preStr, postStr;
char			aStr2[SEARCH_MAX_ELEMENT_LENGTH+1];
BlockRef		textRef, ref2;
char			*textP, *stringP2;
long			len, textLen, stringLen2;
BlockRef 		textResultBlock;
long 			textResultLen;
int				tot, j, i;
long			classID, searchHeadLen, curOff, totOffsets, offsets[MAX_HILITE], end_offsets[MAX_HILITE], *tempOffP, *tempEnd_OffP;
SearchHeaderP	searchHeadP;
BlockRef		ref;

	if (totParams < 4)
		return XError(kBAPI_Error, Err_PrototypeMismatch);
	
	if ((OBJ_CLASSID(exeMethodRecP->paramVarsP[0].objRef) != boolClassID) || (OBJ_CLASSID(exeMethodRecP->paramVarsP[1].objRef) != boolClassID))
		return XError(kBAPI_Error, Err_PrototypeMismatch);

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, textStr, &textP, &textLen, &textRef, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cs, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &skipHTML, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, preStr, &len, 255, kImplicitTypeCast))
				{	if NOT(len)
						CEquStr(preStr, hi_preStr);
					else
						preStr[len] = 0;
					if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[3].objRef, postStr, &len, 255, kImplicitTypeCast))
					{	if NOT(len)
							CEquStr(postStr, hi_postStr);
						else
							postStr[len] = 0;
						curOff = 0;
						ClearBlock(offsets, MAX_HILITE * sizeof(long));
						ClearBlock(end_offsets, MAX_HILITE * sizeof(long));
						for (i = 4; (i < totParams) && NOT(err); i++)
						{	classID = OBJ_CLASSID(exeMethodRecP->paramVarsP[i].objRef);
							if (classID == searchClassID)
							{	if NOT(err = _GetBlock(api_data, &exeMethodRecP->paramVarsP[i].objRef, &searchHeadP, &searchHeadLen, &ref))
								{	SearchItemP		sItemP;
								
									if (searchHeadLen)
									{	tot = searchHeadP->totItems;
										for (j = 0; j < tot; j++)
										{	sItemP = &searchHeadP->sItem[j];
											stringP2 = aStr2;
											stringLen2 = CLen(sItemP->key);
											CopyBlock(stringP2, sItemP->key, stringLen2);	// aStr2 is allocated SEARCH_MAX_ELEMENT_LENGTH
											stringP2[stringLen2] = 0;
											tempOffP = offsets + curOff;
											tempEnd_OffP = end_offsets + curOff;
											if NOT(err = OffsetsInText(textP, textLen, stringP2, cs, tempOffP, tempEnd_OffP, &totOffsets, MAX_HILITE - curOff, skipHTML))
												curOff += totOffsets;
										}
									}
									_ReleaseBlock(&ref);
								}
							}
							else if (classID == arrayClassID)
							{	ArrHiliteRec	arrHRec;

								arrHRec.offsets = offsets;
								arrHRec.end_offsets = end_offsets;
								arrHRec.textP = textP;
								arrHRec.textLen = textLen;
								arrHRec.cs = cs;
								arrHRec.skipHTML = skipHTML;
								arrHRec.curOffP = &curOff;
								err = BAPI_ArrayLoop(api_data, &exeMethodRecP->paramVarsP[i].objRef, _ArrHiliteCallBack, (long)&arrHRec);
							}
							else
							{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->paramVarsP[i].objRef, aStr2, &stringP2, &stringLen2, &ref2, kImplicitTypeCast))
								{	stringP2[stringLen2] = 0;
									tempOffP = offsets + curOff;
									tempEnd_OffP = end_offsets + curOff;
									if NOT(err = OffsetsInText(textP, textLen, stringP2, cs, tempOffP, tempEnd_OffP, &totOffsets, MAX_HILITE - curOff, skipHTML))
										curOff += totOffsets;
								}
							}
						}
						if NOT(err)
						{	if NOT(err = HiliteInText(textP, textLen, &textResultBlock, &textResultLen, offsets, end_offsets, curOff, preStr, postStr))
							{	LockBlock(textResultBlock);
								err = BAPI_StringToObj(api_data, GetPtr(textResultBlock), textResultLen, &exeMethodRecP->resultObjRef);
								DisposeBlock(&textResultBlock);
							}
						}
					}
				}
			}
		}
		_ReleaseStringBlock(&textRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_Substitute(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
//Boolean		result = false;
//CStr255		address;
//char		*strP = address;
CStr255		textStr, oldString, newString;
Ptr			oldStringP, newStringP, textP;
long		resultLen, textLen, newStringLen, oldStringLen;
BlockRef	resultStringBlock, textRef;
Boolean		skipHTML, cs;
BlockRef	newStringRef, oldStringRef;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, textStr, &textP, &textLen, &textRef, kImplicitTypeCast))
	{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, oldString, &oldStringP, &oldStringLen, &oldStringRef, kImplicitTypeCast))
		{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, newString, &newStringP, &newStringLen, &newStringRef, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &cs, kImplicitTypeCast))
				{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[3].objRef, &skipHTML, kImplicitTypeCast))
					{	if NOT(err = SubstituteExt(textP, textLen, &resultStringBlock, &resultLen, oldStringP, oldStringLen, newStringP, newStringLen, cs, skipHTML))
						{	LockBlock(resultStringBlock);
							err = BAPI_StringToObj(api_data, GetPtr(resultStringBlock), resultLen, &exeMethodRecP->resultObjRef);
							DisposeBlock(&resultStringBlock);
						}
					}
				}
				_ReleaseStringBlock(&newStringRef);
			}
			_ReleaseStringBlock(&oldStringRef);
		}
		_ReleaseStringBlock(&textRef);
	}

return err;
}

//===========================================================================================
static XErr	_Zap(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			stringP;
BlockRef	ref;
long		zapped, stringLen;

	if (totParams)
		return XError(kBAPI_Error, Err_PrototypeMismatch);
	
	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if (zapped = ZapText((Byte*)stringP, stringLen))
			stringLen -= zapped;
		err = BAPI_StringToObj(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef);
		_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_Pad(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aStr, aCStr2;
Ptr			stringP, resultP;
BlockRef	ref, ref2;
long		totChars, stringLen;
Byte		padChar[2];
Boolean		before;

	if ((totParams == 2) || (totParams == 3))
	{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &totChars, kImplicitTypeCast))
			{	if (totChars > stringLen)
				{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, (Ptr)&padChar, nil, 2, kImplicitTypeCast))
					{	if (totParams == 3)
							err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &before, kImplicitTypeCast);
						else
							before = false;
						if NOT(err)
						{	if (resultP = AllocString(totChars, aCStr2, &ref2, &err))
							{	CEquStr(resultP, stringP);
								PadString((Byte*)resultP, (short)stringLen, totChars, *padChar, before);
								err = BAPI_StringToObj(api_data, resultP, totChars, &exeMethodRecP->resultObjRef);
							}
						}
					}
					else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
					{	err = XError(kBAPI_Error, Err_IllegalOperation);
						CEquStr(pbPtr->error, "Second parameter of Pad must be a char (or single character string)");
					}
				}
				else
					err = BAPI_StringToObj(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef);
			}
			_ReleaseStringBlock(&ref);
		}
	}
	else
		return XError(kBAPI_Error, Err_PrototypeMismatch);
	

return err;
}

//===========================================================================================
static XErr	_HTUUEncode(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			resultP, stringP;
BlockRef	ref, resultBlock;
long		rest, resultLen, stringLen;

	if (totParams)
		return XError(kBAPI_Error, Err_PrototypeMismatch);
	
	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	resultBlock = 0;
		rest = 3 - (stringLen % 3);
		if ((stringLen + rest) > 48)
		{	if NOT(err = HTUU_encodeExt(stringP, stringLen, &resultBlock, &resultLen, 48))
			{	LockBlock(resultBlock);
				resultP = GetPtr(resultBlock);
			}
		}
		else
		{	if (resultBlock = NewBlockLocked(5 + (4 * stringLen)/3, &err, &resultP))
				resultLen = HTUU_encode((Byte*)stringP, stringLen, resultP);
		}
		if NOT(err)
		{	if NOT(err = BAPI_StringToObj(api_data, resultP, resultLen, &exeMethodRecP->resultObjRef))
				DisposeBlock(&resultBlock);
		}
		_ReleaseStringBlock(&ref);
		if (resultBlock)
			DisposeBlock(&resultBlock);
	}

return err;
}

//===========================================================================================
static XErr	_HTUUDecode(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			resultP, stringP;
BlockRef	ref, resultBlock;
long		resultLen, stringLen;

	if (totParams)
		return XError(kBAPI_Error, Err_PrototypeMismatch);
	
	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if (stringLen)
		{	if (resultBlock = NewBlockClear(stringLen + 2, &err, &resultP))
			{	LockBlock(resultBlock);
				//resultP = GetPtr(resultBlock);
				resultLen = HTUU_decode(stringP, (Byte*)resultP, stringLen + 2);
				err = BAPI_StringToObj(api_data, resultP, resultLen, &exeMethodRecP->resultObjRef);
				DisposeBlock(&resultBlock);
			}
		}
		else
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
		_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_Capitalize(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			stringP;
BlockRef	ref;
long		stringLen;

	if (totParams)
		return XError(kBAPI_Error, Err_PrototypeMismatch);
	
	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	Capitalize((Byte*)stringP, stringLen);
		err = BAPI_StringToObj(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef);
		_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_RemoveSubString(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			stringP;
BlockRef	ref;
long		finalLength, stringLen, from, len;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if (stringLen)
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &from, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &len, kImplicitTypeCast))
				{	if NOT(from)
						from = 1;
					else if ((from < 0) || (from > stringLen))
						err = XError(kBAPI_ClassError, ErrBadIndex);
					if (len < 0)
						err = XError(kBAPI_ClassError, ErrBadLength);
					else if (len > (stringLen - from + 1))
						len = stringLen - from + 1;
					if NOT(err)
					{	finalLength = stringLen - len;
						CopyBlock(stringP + from - 1, stringP + from + len - 1, stringLen - from - len + 1);
						stringP[finalLength] = 0;
						err = BAPI_StringToObj(api_data, stringP, finalLength, &exeMethodRecP->resultObjRef);
					}
				}
			}
		}
		else
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
		_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_InsertSubString(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aStr, aStr2;
Ptr			newTextP, stringP, stringP2;
BlockRef	newBlock, ref, ref2;
long		totLen, firstPartLen, stringLen, stringLen2, pos;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	//if (stringLen)
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &pos, kImplicitTypeCast))
			{	if (pos <= 0)
					err = XError(kBAPI_ClassError, ErrBadIndex);
				else if (pos > stringLen)
					pos = stringLen + 1;
				if NOT(err)
				{	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aStr2, &stringP2, &stringLen2, &ref2, kImplicitTypeCast))
					{	totLen = stringLen + stringLen2;
						if (newBlock = NewBlockLocked(totLen + 1, &err, &newTextP))
						{	//LockBlock(newBlock);
							//newTextP = GetPtr(newBlock);
							firstPartLen = pos - 1;
							CopyBlock(newTextP, stringP, firstPartLen);
							CopyBlock(newTextP + firstPartLen, stringP2, stringLen2);
							CopyBlock(newTextP + firstPartLen + stringLen2, stringP + pos - 1, stringLen - firstPartLen);
							newTextP[totLen] = 0;
							err = BAPI_StringToObj(api_data, newTextP, totLen, &exeMethodRecP->resultObjRef);
							DisposeBlock(&newBlock);
						}
						_ReleaseStringBlock(&ref2);
					}
				}
			}
		}
		//else
		//	err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
		_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_IsANSIStandard(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aStr;
Ptr			stringP;
BlockRef	ref;
long		res, i, stringLen;
Byte		ch;

	if NOT(err = _GetStringBlock(api_data, &exeMethodRecP->objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	res = 0;
		for (i = 0; i < stringLen; i++)
		{	ch = *stringP++;
			if (ch > 127)
			{	res = i+1;
				break;
			}
		}
		err = BAPI_IntToObj(api_data, res, &exeMethodRecP->resultObjRef);
		_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_LogString(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
CStr255			logStr;

	if NOT(err = BAPI_ObjToString(api_data, &execMethodRecP->objRef, logStr, nil, 256, kImplicitTypeCast))
		err = BAPI_Log(api_data, logStr);
	else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
		CEquStr(pbPtr->error, "Can't log more than 255 characters");
		
return err;
}

//===========================================================================================
static XErr	_Hex2Bin(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		text;
short		*textPtr;
char		*outPtr, *savedPtr;
long		textLen, halfLen;
BlockRef	blockRef;


	// Get the string for the param objRef
	if (not(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->objRef, text, (Ptr*)&textPtr, &textLen, &blockRef, kImplicitTypeCast)))
		{
		savedPtr = outPtr = (char*)textPtr;
		halfLen = (textLen >> 1) + 1;
		while (--halfLen)
			*outPtr++ = Hex2Num((char*)textPtr++);

		// Create the result object
		err = BAPI_StringToObj(api_data, savedPtr, textLen >> 1, &exeMethodRecP->resultObjRef);
		}
	
	BAPI_ReleaseBlock(&blockRef); 
	
return err;
}

//===========================================================================================
static XErr	_Bin2Hex(ExecuteMethodRec *exeMethodRecP, long api_data)
{
Byte hexTableChar[16] =
{
//	0	1	2	3	4	5	6	7	8	9	A	B	C	D	E	F
  	48,	49,	50,	51,	52,	53,	54,	55,	56,	57,	65,	66,	67,	68,	69,	70
};

XErr		err = noErr;
char		*outPtr, *inPtr, *sPtr;
Byte		binValue, *hexTablePtr;
long		inLen, outLen;
BlockRef	blockRef;


	if (not(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->objRef, nil, &inPtr, &inLen, &blockRef, kImplicitTypeCast)))
		{
		outLen = inLen << 1;
		if (not(err = SetBlockSize(blockRef, outLen)))
			{
			inPtr = GetPtr(blockRef);
			
			sPtr = inPtr;
			outPtr = inPtr + outLen - 2;
			inPtr += inLen - 1;
			inLen++;
			hexTablePtr = hexTableChar;
			
			while(--inLen)
				{
				binValue = *inPtr--;
				*outPtr = hexTablePtr[binValue >> 4];
				outPtr[1] = hexTablePtr[binValue & 0x0F];
				outPtr -= 2;
				}
			err = BAPI_StringToObj(api_data, sPtr, outLen, &exeMethodRecP->resultObjRef);
			}
		}

	BAPI_ReleaseBlock(&blockRef); 
	
return err;
}

//===========================================================================================
static void CvtHex(IN HASH Bin, OUT HASHHEX Hex)
{
    unsigned short i;
    unsigned char j;

    for (i = 0; i < HASHLEN; i++) {
        j = (Bin[i] >> 4) & 0xf;
        if (j <= 9)
            Hex[i*2] = (j + '0');
         else
            Hex[i*2] = (j + 'a' - 10);
        j = Bin[i] & 0xf;
        if (j <= 9)
            Hex[i*2+1] = (j + '0');
         else
            Hex[i*2+1] = (j + 'a' - 10);
    };
    Hex[HASHHEXLEN] = '\0';
}

//===========================================================================================
static XErr	_MD5(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr				err = noErr;
CStr255				aCStr;
BlockRef			ref;
Ptr					stringP;
long				stringLen;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->objRef, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{
	MD5_CTX 		Md5Ctx;
	HASH 			HA1;
	HASHHEX 		result;
	
		MD5Init(&Md5Ctx);
		MD5Update(&Md5Ctx, stringP, stringLen);
		MD5Final(HA1, &Md5Ctx);
		CvtHex(HA1, result);
		err = BAPI_StringToObj(api_data, result, HASHHEXLEN, &exeMethodRecP->resultObjRef);
		BAPI_ReleaseBlock(&ref);
	}

return err;
}

//===========================================================================================
/*static XErr	_Dec(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
CStr255			aCStr, className;
long			aLong;
Boolean			wantSign;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->objRef, aCStr, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[0].objRef, &wantSign, kImplicitTypeCast))
		{	aLong = HexStringToNum(aCStr);
			if (wantSign)
				err = BAPI_IntToObj(api_data, aLong, &exeMethodRecP->resultObjRef);
			else
				err = BAPI_UnsignedToObj(api_data, *(unsigned long*)&aLong, &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	stringProperty[TOT_PROPRIETIES] = 
					{	"length", 	kLength,		"int",
						"char[]", 	kCharProperty,	"char"
					};
BAPI_MemberRecord		stringMethods[TOT_METHODES] = 
					{	"Encode",				kEncode, 				"string Encode(boolean alsoCR, boolean tagsVisible, boolean entities, obj tagList)",
						"Decode", 				kDecode, 				"string Decode(boolean alsoCR)",
						"Escape",				kEscape, 				"string Escape(void)",
						"UrlEncode", 			kURLEncode, 			"string UrlEncode(boolean spaceToPlus, string pre)",
						"UrlDecode", 			kURLDecode, 			"string UrlDecode(boolean plusToSpace, string pre)",
						"Find", 				kFind, 					"int Find(string str, boolean caseSense, int from)",
						"Begins", 				kBegins, 				"boolean Begins(string str, boolean caseSense)",
						"Ends", 				kEnds, 					"boolean Ends(string str, boolean caseSense)",
						"Contains", 			kContains, 				"boolean Contains(string str, boolean caseSense)",
						"ContainsWordBegin", 	kContainsWordBegin, 	"boolean ContainsWordBegin(string str, boolean caseSense)",
						"ContainsWordEnd", 		kContainsWordEnd, 		"boolean ContainsWordEnd(string str, boolean caseSense)",
						"ContainsWordExact", 	kContainsWordExact, 	"boolean ContainsWordExact(string str, boolean caseSense)",
						"In", 					kIn, 					"boolean In(string str, char sep=\",\")",
						"Compare", 				kCompare,				"int Compare(string str, boolean caseSense)",
						"UpToLower", 			kUpToLower, 			"string UpToLower(int from, int len)",
						"LowToUpper", 			kLowToUpper, 			"string LowToUpper(int from, int len)",
						"SubString", 			kSubString, 			"string SubString(int from, int len)",						
						"ToArray",				kToArray,				"array ToArray(string separator=\", \")",
						"IsEMail",				kIsEMail,				"boolean IsEMail(boolean exists, string *msg)",
						"IsDate",				kIsDate,				"boolean IsDate(string format)",
						"IsNumeric",			kIsNumeric,				"boolean IsNumeric(void)",
						"Hilite",				k_Hilite,				"string Hilite(boolean cs, boolean skipHTML, string pre, string post, obj strN...)",
						"Substitute",			kSubstitute,			"string Substitute(string oldString, string newString, boolean cs, boolean skipHTML)",
						"Zap",					kZap,					"string Zap(void)",
						"Pad",					kPad,					"string Pad(int totChars, char padChar, boolean before)",
						"HTUUEncode",			kHTUUEncode,			"string HTUUEncode(void)",
						"HTUUDecode",			kHTUUDecode,			"string HTUUDecode(void)",
						"Capitalize",			kCapitalize,			"string Capitalize(void)",
						"RemoveSubString",		kRemoveSubString,		"string RemoveSubString(int from, int len)",
						"InsertSubString",		kInsertSubString,		"string InsertSubString(int pos, string subString)",
						"IsANSIStandard",		kIsANSIStandard,		"int IsANSIStandard(void)",
						"Log",					kLog,					"void Log(void)",
						"Hex2Bin",				kHex2Bin,				"void Hex2Bin(void)",
						"Bin2Hex",				kBin2Hex,				"void Bin2Hex(void)",
						"MD5",					kMD5,					"string MD5(void)"
						//"Dec", 				kDec,					"obj Dec(boolean signed)"
					};

BAPI_MemberRecord	stringCostants[TOT_COSTANTS] = 
					{	"htmlTags", 	kHtmlTags,		"int",
						"allTags", 		kAllTags,		"int"
					};


	if (err = BAPI_NewProperties(api_data, stringClassID, stringProperty, TOT_PROPRIETIES, nil))
		return err;		

	if (err = BAPI_NewMethods(api_data, stringClassID, stringMethods, TOT_METHODES, nil))
		return err;

	if (err = BAPI_NewConstants(api_data, stringClassID, stringCostants, TOT_COSTANTS, nil))
		return err;

	err = BAPI_RegisterErrors(api_data, stringClassID, STRING_START_ERR, gStringErrorsStr, TOT_ERRORS);

//out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// Ci si deve registrare dando il nome della classe (costruttore), dicendo di 
// che tipo � il plugin e ricevendo la propria classID
static XErr	String_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec		*initRecP = &pbPtr->param.initRec.newClassRec;
XErr			err = noErr;

	err = _RegisterListMembers(pbPtr->api_data);
	searchClassID = BAPI_ClassIDFromName(pbPtr->api_data, "search", false);
	arrayClassID = BAPI_ClassIDFromName(pbPtr->api_data, "array", false);
	boolClassID = BAPI_ClassIDFromName(pbPtr->api_data, "boolean", false);
	charClassID = BAPI_ClassIDFromName(pbPtr->api_data, "char", false);
	unsignedClassID = BAPI_ClassIDFromName(pbPtr->api_data, "unsigned", false);
	intClassID = BAPI_ClassIDFromName(pbPtr->api_data, "int", false);
	
	//CEquStr(initRecP->priorityPluginName, "char");	// I command on "boolean" (in operations)
	
return err;
}

//===========================================================================================
// Finalizzazioni
static XErr	String_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	stringClassID = 0;
	
return noErr;
}

//===========================================================================================
// Data una sequenza di caratteri (constructorRecP->data), o una sequenza di obj (varRecsP) 
// si deve creare un oggetto di tipo stringa usando la callback "BAPI_BufferToObj"
static XErr	String_Constructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			dataLen;
long			api_data = pbPtr->api_data;
CStr255			aCStr;
Ptr				dataP;
BlockRef		dataBlock = 0;
long			typeCastType;

	if (constructorRecP->typeCastType)
		typeCastType = constructorRecP->typeCastType;
	else
		typeCastType = kExplicitTypeCast;
	if (constructorRecP->totVars == 1)
	{	if (OBJ_CLASSID(constructorRecP->varRecsP[0].objRef) == stringClassID)
			err = BAPI_CopyObj(api_data, &constructorRecP->varRecsP[0].objRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
		else if NOT(err = BAPI_GetStringBlock(api_data, &constructorRecP->varRecsP->objRef, aCStr, &dataP, &dataLen, &dataBlock, typeCastType))
		{	
			err = BAPI_BufferToObj(api_data, dataP, dataLen, stringClassID, false, constructorRecP->privateData, &constructorRecP->resultObjRef);
			BAPI_ReleaseBlock(&dataBlock);
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "string(obj param)");
	}
		
return err;
}

//===========================================================================================
// Il risultato va messo in objRef1
static XErr	String_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err= noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				operation = exeOperationRecP->operation;
Boolean				aBool;
long				api_data = pbPtr->api_data;
//long				strLen = -1;
long				string1Len;
long				totLength, string2Len;
CStr255				aStr1, aStr2;
Ptr					string1P, string2P;
int					res;
BlockRef			ref1, ref2;

#ifdef MEM_DEBUG
	if (err = BAPI_NeedSerialize(pbPtr->api_data, &exeOperationRecP->objRef1, nil))
		return err;
	if (err = BAPI_NeedSerialize(pbPtr->api_data, &exeOperationRecP->objRef2, nil))
		return err;
#endif
	//if (exeOperationRecP->increment)
	//	return XError(kBAPI_Error, Err_IllegalOperation);
	
	switch(operation)
	{
		case EVAL_MULT:
		case EVAL_DIV:
		case EVAL_MOD:
			return XError(kBAPI_Error, Err_IllegalOperation);
			
		case EVAL_ADD:
			if NOT(err = _GetStringBlock(pbPtr->api_data, &exeOperationRecP->objRef2, aStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	if NOT(err = _GetStringBlockMore(pbPtr->api_data, &exeOperationRecP->objRef1, aStr1, &string1P, &string1Len, string2Len, &ref1, kImplicitTypeCast))
				{	CopyBlock(string1P + string1Len, string2P, string2Len);
					totLength = string1Len + string2Len;
					string1P[totLength] = 0;
					err = BAPI_StringToObj(api_data, string1P, totLength, &exeOperationRecP->resultObjRef);
					if (ref1)
						DisposeBlock(&ref1);
				}
				_ReleaseStringBlock(&ref2);
			}
			/*
			{
			ObjRef		temp_objRef;
			
				if (OBJ_CLASSID(exeOperationRecP->objRef2) != stringClassID)
				{	CDebugStr("String.c, non doveva mai succedere");
					if NOT(err = _GetStringBlock(pbPtr->api_data, &exeOperationRecP->objRef2, aStr2, &string2P, &string2Len, 0, &ref2, kImplicitTypeCast))
					{	err = BAPI_StringToObj(api_data, string2P, string2Len, &temp_objRef);
						_ReleaseStringBlock(&ref2);
					}
				}
				else
					temp_objRef = exeOperationRecP->objRef2;
					
				if NOT(err)
				{	if NOT(err = BAPI_CopyObj(api_data, &exeOperationRecP->objRef1, nil, TEMP, VARIABLE, &exeOperationRecP->resultObjRef))
					{	
						err = BAPI_ConcatObjs(api_data, &exeOperationRecP->resultObjRef, &temp_objRef);
					}
				}
			}*/
			break;
		
		case EVAL_MINUS:
		case EVAL_SHIFTR:
		case EVAL_SHIFTL:
			return XError(kBAPI_Error, Err_IllegalOperation);

		case EVAL_GTH:
		case EVAL_LTH:
		case EVAL_GEQ:
		case EVAL_LEQ:
		case EVAL_EQUA:
		case EVAL_NEQUA:
			if NOT(err = _GetStringBlock(pbPtr->api_data, &exeOperationRecP->objRef1, aStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
			{	if NOT(err = _GetStringBlock(pbPtr->api_data, &exeOperationRecP->objRef2, aStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
				{	string1P[string1Len] = 0;
					string2P[string2Len] = 0;
					res = CCompareStrings_cs(string1P, string2P);
					switch(operation)
					{	case EVAL_GTH:
							aBool = (res == -1);
							break;
						case EVAL_LTH:
							aBool = (res == +1);
							break;
						case EVAL_GEQ:
							aBool = NOT(res) || (res == -1);
							break;
						case EVAL_LEQ:
							aBool = NOT(res) || (res == +1);
							break;
						case EVAL_EQUA:
							aBool = (res == 0);
							break;
						case EVAL_NEQUA:
							aBool = (res != 0);
							break;
					}
					err = BAPI_BooleanToObj(pbPtr->api_data, aBool, &exeOperationRecP->resultObjRef);
					_ReleaseStringBlock(&ref2);
				}
				_ReleaseStringBlock(&ref1);
			}
			break;
		
		case EVAL_ARAND:
		case EVAL_AROR:
			return XError(kBAPI_Error, Err_IllegalOperation);
							
		default:
			CDebugStr("Unknown operator!");
	}

return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	String_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;

#ifdef MEM_DEBUG
	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
	{	if (err = BAPI_NeedSerialize(pbPtr->api_data, &exeMethodRecP->objRef, nil))
			return err;
	}
#endif
	//BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);	// for void
	/*if (exeMethodRecP->isStatic && exeMethodRecP->totParams)
	{	exeMethodRecP->objRef = exeMethodRecP->paramVarsP->objRef;
		exeMethodRecP->paramVarsP++;
		exeMethodRecP->totParams--;
	}
	*/	
	switch(exeMethodRecP->methodID)
	{
		case kEncode:
			err = _Encode(exeMethodRecP, api_data);
			break;
		case kDecode:
			err = _Decode(exeMethodRecP, api_data);
			break;
		
		case kEscape:
			err = _Escape(exeMethodRecP, api_data);
			break;
		
		case kURLEncode:
		case kURLDecode:
			err = _URL(exeMethodRecP, exeMethodRecP->methodID, api_data);
			break;
		/*case kEncodeJavaScript:
			err = _EncDecodeJavaScript(exeMethodRecP, api_data, true);
			break;
		case kDecodeJavaScript:
			err = _EncDecodeJavaScript(exeMethodRecP, api_data, false);
			break;*/
		case kFind:
		case kBegins:
		case kEnds:
		case kContains:
		case kContainsWordBegin:
		case kContainsWordEnd:
		case kContainsWordExact:
			err = _Find(exeMethodRecP, exeMethodRecP->totParams, exeMethodRecP->methodID, api_data);
			break;
		case kIn:
			err = _In(exeMethodRecP, api_data);
			break;
		case kCompare:
			err = _Compare(exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kUpToLower:
		case kLowToUpper:
			err = _UpLow(exeMethodRecP, exeMethodRecP->methodID, api_data);
			break;
		case kSubString:
			err = _SubString(exeMethodRecP, api_data);
			break;
		case kToArray:
			err = _ToArray(exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kIsEMail:
			err = _IsValidEMail(exeMethodRecP, api_data);
			break;
		case kIsDate:
			err = _IsDate(exeMethodRecP, api_data);
			break;
		case kIsNumeric:
			err = _IsNumeric(exeMethodRecP, api_data);
			break;
		case k_Hilite:
			err = _Hilite(exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kSubstitute:
			err = _Substitute(exeMethodRecP, api_data);
			break;
		case kZap:
			err = _Zap(exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kPad:
			err = _Pad(pbPtr, exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kHTUUEncode:
			err = _HTUUEncode(exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kHTUUDecode:
			err = _HTUUDecode(exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kCapitalize:
			err = _Capitalize(exeMethodRecP, exeMethodRecP->totParams, api_data);
			break;
		case kRemoveSubString:
			err = _RemoveSubString(exeMethodRecP, api_data);
			break;
		case kInsertSubString:
			err = _InsertSubString(exeMethodRecP, api_data);
			break;
		case kIsANSIStandard:
			err = _IsANSIStandard(exeMethodRecP, api_data);
			break;
		case kLog:
			err = _LogString(pbPtr, exeMethodRecP);
			break;
		case kHex2Bin:
			err = _Hex2Bin(exeMethodRecP, api_data);
			break;
		case kBin2Hex:
			err = _Bin2Hex(exeMethodRecP, api_data);
			break;
		case kMD5:
			err = _MD5(exeMethodRecP, api_data);
			break;
		
		/*case kDec:
			err = _Dec(exeMethodRecP, api_data);
			break;*/
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}

return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	String_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			dataLen, api_data = pbPtr->api_data;
Byte			theChar;
int				idx;

	if (getPropertyRec->isConstant)
		return BAPI_IntToObj(api_data, getPropertyRec->propertyID, &getPropertyRec->resultObjRef);

#ifdef MEM_DEBUG
	if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
	{	if (err = BAPI_NeedSerialize(pbPtr->api_data, &getPropertyRec->objRef, nil))
			return err;
	}
#endif
	switch(getPropertyRec->propertyID)
	{
		case kLength:
			if NOT(err = BAPI_GetObj(api_data, &getPropertyRec->objRef, nil, &dataLen, 0, nil))
				err = BAPI_IntToObj(api_data, dataLen, &getPropertyRec->resultObjRef);
			break;
		case kCharProperty:
			if (idx = getPropertyRec->propertyIndex[0].ind)
			{	dataLen = 1;
				if NOT(err = BAPI_GetObj(api_data, &getPropertyRec->objRef, (Ptr)&theChar, &dataLen, idx, nil))
				{	err = BAPI_CharToObj(api_data, theChar, &getPropertyRec->resultObjRef);
					/*
					BAPI_ClearParameterRec(api_data, &param);
					if NOT(err = BAPI_StringToObj(api_data, (Ptr)&theChar, 1, &param.objRef))
						err = BAPI_Constructor(api_data, TEMP, VARIABLE, nil, charClassID, &param, 1, &getPropertyRec->resultObjRef);
					*/
				}
			}
			else if (*getPropertyRec->propertyIndex[0].ind_name)
			{	err = XError(kBAPI_Error, Err_BadArrayIndex);
				CEquStr(pbPtr->error, "The char Index must be integer (not string)");
			}
			else
			{	BlockRef		ref;
				CStr255			aCStr;
				long			arrayDim;//, i;
				char			*stringP;
				//ObjRef			tObjRef, *arrayObjRefP = &getPropertyRec->resultObjRef;
				//ParameterRec	param;
				
				if NOT(err = _GetStringBlock(api_data, &getPropertyRec->objRef, aCStr, &stringP, &arrayDim, &ref, kExplicitTypeCast))
				{	err = _CharsVector(api_data, stringP, arrayDim, &getPropertyRec->resultObjRef);
					/*if NOT(err = BAPI_NewArray(api_data, true, 0, nil, TEMP, VARIABLE, nil, 0, nil, arrayObjRefP))
					{	BAPI_ClearParameterRec(api_data, &param);
						for (i = 0; (i < arrayDim) && NOT(err); i++, stringP++)
						{	if NOT(err = BAPI_StringToObj(api_data, stringP, 1, &param.objRef))
							{	if NOT(err = BAPI_Constructor(api_data, TEMP, VARIABLE, nil, charClassID, &param, 1, &tObjRef))
									err = BAPI_ArrayAddElement(api_data, arrayObjRefP, nil, &tObjRef);
							}
						}
					}*/
					_ReleaseStringBlock(&ref);
				}
			}
			/*{	err = 1;
				CEquStr(pbPtr->error, "The char Index was not specified");
			}*/
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	String_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
long				idx, api_data = pbPtr->api_data;
long				newDataLen;
Byte				ch[2];

#ifdef MEM_DEBUG
	if (BAPI_IsObjRefValid(api_data, &setPropertyRecP->objRef))
	{	if (err = BAPI_NeedSerialize(pbPtr->api_data, &setPropertyRecP->objRef, nil))
			return err;
	}
#endif
	switch(setPropertyRecP->propertyID)
	{
		case kLength:
			if NOT(err = BAPI_ObjToInt(api_data, &setPropertyRecP->value, &newDataLen, kImplicitTypeCast))
			{	if (newDataLen >= 0)
					err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, nil, newDataLen);
				else
					err = XError(kBAPI_ClassError, ErrBadLength);
			}
			break;

		case kCharProperty:
			if (idx = setPropertyRecP->propertyIndex[0].ind)
			{	if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, (Ptr)ch, nil, 2, kImplicitTypeCast))
					err = BAPI_WriteObj(api_data, &setPropertyRecP->objRef, &ch[0], 1, idx);
				if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
				{	err = XError(kBAPI_Error, Err_IllegalOperation);
					CEquStr(pbPtr->error, "illegal char length");
				}
			}
			else if (*setPropertyRecP->propertyIndex[0].ind_name)
			{	err = XError(kBAPI_Error, Err_BadArrayIndex);
				CEquStr(pbPtr->error, "The char Index must be integer (not string)");
			}
			else
				err = XError(kBAPI_Error, Err_IllegalOperation);
			break;

		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}
	
return err;
}

//===========================================================================================
/*static XErr	String_Modify(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ModifyRec	*modifyRecP = &pbPtr->param.modifyRec;
long		dataLen;
long		api_data = pbPtr->api_data;
Ptr			dataP;
Str255		aStr;
BlockRef	dataBlock = 0;

	if NOT(err = BAPI_ObjToString(api_data, &modifyRecP->value, nil, &dataLen, 0, kImplicitTypeCast))
	{	if (dataLen < 255)
			dataP = (Ptr)&aStr[1];
		else
		{	if (dataBlock = NewBlock(dataLen, &err))
			{	LockBlock(dataBlock);
				dataP = GetPtr(dataBlock);
			}
		}
		if NOT(err)
		{	if NOT(err = BAPI_ObjToString(api_data, &modifyRecP->value, dataP, &dataLen, dataLen, kImplicitTypeCast))
			{	// per la stringa l'obj risultato non � altro che la stringa stessa di ritorno da QWSAPI_ObjToString
				err = BAPI_ModifyObj(api_data, &modifyRecP->varToModify, dataP, dataLen, stringClassID);
			}
			if (dataBlock)
				DisposeBlock(&dataBlock);
		}
	}
	
return err;
}
*/

//===========================================================================================
/*static XErr	String_GetErrDescr(Biferno_ParamBlockPtr pbPtr)
{
GetErrDescrRec		*getErrDescrRecP = &pbPtr->param.getErrDescrRec;
short				tErr;

	CEquStr(getErrDescrRecP->errType, "String Error");
	if (((tErr = getErrDescrRecP->err) >= STRING_START_ERR) && (tErr < lastErr))
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, gStringErrorsStr[tErr - STRING_START_ERR]);
	}
	else
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, "Unknown Error");
	}

return noErr;
}
*/
//===========================================================================================
static XErr	String_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
CStr255			aCStr;
long			strLen;
Ptr				strP;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
long			api_data = pbPtr->api_data;
BlockRef		ref = 0, ref2;
Byte			thousSep, decSep;
PrimitiveUnion	*param_d;
//ParameterRec	parameter;

#ifdef MEM_DEBUG
	if (err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, nil))
		return err;
#endif
	if NOT(err = BAPI_GetNumberFormat(api_data, &thousSep, &decSep))
	{	if NOT(err = _GetStringBlock(api_data, &typeCast->objRef, aCStr, &strP, &strLen, &ref, typeCast->typeCastType))
		{	strP[strLen] = 0;
			param_d = &typeCast->result;
			switch(typeCast->resultWanted)
			{	case kInt:
				#ifdef NUM_STRING_TYPECAST_EXPLICIT	
					if (typeCast->type != kExplicitTypeCast)
						return XError(kBAPI_Error, Err_IllegalTypeCast);
				#endif
					if NOT(err = _StringToNumeric(&strP, &strLen, kInt, thousSep, decSep, false))
						err = CStringToNumExt(strP, &param_d->intValue, nil);
					break;
				case kLong:
				#ifdef NUM_STRING_TYPECAST_EXPLICIT	
					if (typeCast->type != kExplicitTypeCast)
						return XError(kBAPI_Error, Err_IllegalTypeCast);
				#endif
					if NOT(err = _StringToNumeric(&strP, &strLen, kInt, thousSep, decSep, false))
						err = CStringToLongNum(strP, strLen, &param_d->longValue);
					break;
				case kUnsigned:
				#ifdef NUM_STRING_TYPECAST_EXPLICIT	
					if (typeCast->type != kExplicitTypeCast)
						return XError(kBAPI_Error, Err_IllegalTypeCast);
				#endif
					if NOT(err = _StringToNumeric(&strP, &strLen, kInt, thousSep, decSep, true))
						err = CStringToNumExt(strP, nil, &param_d->uIntValue);
					break;
				case kDouble:
				#ifdef NUM_STRING_TYPECAST_EXPLICIT	
					if (typeCast->type != kExplicitTypeCast)
						return XError(kBAPI_Error, Err_IllegalTypeCast);
				#endif
					if NOT(err = _StringToNumeric(&strP, &strLen, kDouble, thousSep, decSep, false))
						param_d->doubleValue = CStrToReal(strP);
					break;
				case kBool:
				#ifdef NUM_STRING_TYPECAST_EXPLICIT	
					if (typeCast->type != kExplicitTypeCast)
						return XError(kBAPI_Error, Err_IllegalTypeCast);
				#endif
					param_d->boolValue = (strLen != 0);
					break;
				case kCString:
					if (param_d->text.variant == kForConstructor)
						err = StringEscaped(&strP, &strLen, &ref2);
					else
						ref2 = 0;
					if NOT(err)
					{	if (param_d->text.stringP)
						{	if (param_d->text.stringMaxStorage >= (strLen + 1))	// 0 terminated
							{	CopyBlock(param_d->text.stringP, strP, strLen);
								param_d->text.stringP[strLen] = 0;
								param_d->text.stringLen = strLen;
							}
							else
							{	CopyBlock(param_d->text.stringP, strP, param_d->text.stringMaxStorage - 1);
								param_d->text.stringP[param_d->text.stringMaxStorage - 1] = 0;
								param_d->text.stringLen = strLen;
								err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
							}
						}
						else
							param_d->text.stringLen = strLen;
						if (ref2)
							DisposeBlock(&ref2);
					}
					break;
					
				case kChar:
					if (param_d->text.variant == kForConstructor)
						err = StringEscaped(&strP, &strLen, &ref2);
					else
						ref2 = 0;
					if NOT(err)
					{	*param_d->theChar = *strP;
						if (ref2)
							DisposeBlock(&ref2);
					}
					break;

				/*case kObj:
					BAPI_ClearParameterRec(api_data, &parameter);
					if NOT(err = BAPI_BufferToObj(api_data, strP, strLen, stringClassID, false, nil, TEMP, VARIABLE, &parameter.objRef))
						err = BAPI_Clone(api_data, TEMP, VARIABLE, nil, param_d->objRef.classID, &parameter, 1, &param_d->objRef);
					break;*/
				default:
					CDebugStr("Unknown TypeCast Parameter");
					break;
			}
			_ReleaseStringBlock(&ref);
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	string_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			stringClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = false;
			CEquStr(pbPtr->param.registerRec.constructor, "void string(obj str)");
			break;
		case kInit:
			err = String_Init(pbPtr);
			break;
		case kShutDown:
			err = String_ShutDown(pbPtr);
			break;
		case kRun:
			/*{
			ObjRef	objRef;
			
			
				if NOT(err = BAPI_StringToObj(pbPtr->api_data, "ab", 2, &objRef))
				{
					err = BAPI_ModifyObj(pbPtr->api_data, &objRef, "nm", 2);
				}
				if NOT(err = BAPI_StringToObj(pbPtr->api_data, "valeriovaleriovaleriovalerio", 28, &objRef))
				{
					err = BAPI_ModifyObj(pbPtr->api_data, &objRef, "nm", 2);
				}
			}*/
			
			/*{
			long	tLen;
			Byte	tStr[2];
			Boolean	isDef;

				tLen = 2;
				if NOT(err = BAPI_GetConfig(pbPtr->api_data, "DECIMAL_SEP", (char*)tStr, &tLen, &isDef))
				{	*(Byte*)&pbPtr->plugin_run_data = *tStr;
					tLen = 2;
					if NOT(err = BAPI_GetConfig(pbPtr->api_data, "THOUSAND_SEP", (char*)tStr, &tLen, &isDef))
						*(Byte*)((Ptr)&pbPtr->plugin_run_data + 1) = *tStr;
				}
			}*/
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = String_Constructor(pbPtr);
			break;
		case kDestructor:
			// do nothing
			break;
		case kExecuteOperation:
			err = String_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = String_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = String_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = String_SetProperty(pbPtr);
			break;
		/*case kModify:
			err = String_Modify(pbPtr);
			break;*/
		case kPrimitive:
			err = String_TypeCast(pbPtr);
			break;
		/*case kGetErrDescr:
			err = String_GetErrDescr(pbPtr);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


