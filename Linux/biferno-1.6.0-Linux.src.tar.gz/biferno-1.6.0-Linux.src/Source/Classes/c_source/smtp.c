/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: smtp.c,v 1.5 2005-03-23 13:01:37 valfer Exp $
	|______________________________________________________________________________

	Thanks to:

		John Norstad
		Academic Technologies
		Northwestern University
		
	for the original version of this file "smtp.c"

*/
#include 	"XLib.h"

/*----------------------------------------------------------------------------

	smtp.c

	This reusable and reentrant module implements SMTP mail.
	
	The following functions are exported:
	
		SmtpOpen - Open an SMTP stream.
		SmtpClose - Close an SMTP stream.
		SmtpSendMessage - Send a mail message.
		SmtpGetServerErrInfo - Get server error information.
	
	You must call memutil.c/InitMemUtil and net.c/NetInit before calling any of
	the functions in this module. You also must call the NetIdle function in your
	idle loop, and the NetTerm function at program termination.
		
	A "stream" is an abstraction representing a bidirectional network connection
	to an SMTP server. A stream is represented as a variable of type "SmtpStreamRef". 
	These stream references are opaque. You may copy them and pass them as parameters 
	to functions in smtp.c, but you are prohibited from accessing the contents of
	the memory blocks pointed to by the references. Only the functions in 
	smtp.c are permitted to manipulate the contents of these blocks.
	
	The functions return a value of type OSErr as the function result:
	
		noErr				no error occurred
		smtpServerErr		server error
		other				any other OS or Toolbox error code
		
	If the function result is smtpServerErr, the SmtpGetServerErrInfo function can
	be called to get information about the server error. On server errors, the 
	stream is still allocated and open on return to the caller.
		
	If an OS or Toolbox error occurs, the stream is aborted and deallocated before
	returning to the caller. "Aborted" means that the server connection is closed 
	abruptly, without going through the usual TCP stream teardown process. You must 
	perform careful error checking. The stream is deallocated, and must not be reused.
	
	Copyright � 1994-1997, Northwestern University.

----------------------------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "def.h"
#include "net.h"
#include "smtp.h"
//#include "memutil.h"



/* Types. */

typedef struct SmtpTStream {
	NetStreamRef netStream;				/* net stream reference */
	Boolean needReset;					/* true if must send RSET command before next message */
} SmtpTStream, *SmtpTStreamPtr/*, **TStreamHandle*/;



/*----------------------------------------------------------------------------
	SmtpOpen 
	
	Open an SMTP stream.
	
	Entry:	host = server host address (domain name or dotted 
				decimal IP address).
	
	Exit:	function result = result code.
			stream = reference to opened stream, 
				or nil if function result != noErr.
----------------------------------------------------------------------------*/

XErr SmtpOpen (char *host, SmtpStreamRef *stream, long userData, char *errmsg)
{
BlockRef 		s = nil;
NetAddress	 	addr;
unsigned short 	port;
NetStreamRef 	netStream;
CStr255 		myName;
CStr255 		command, response;
long 			responseCode;
XErr 			err = noErr;
SmtpTStreamPtr	sPtr;
	
	if NOT(s = NewBlock(sizeof(SmtpTStream), &err, nil))
		return err;
	//err = MyNewHandle(sizeof(TStream), &s);
	//if (err != noErr) return err;
	
	if (errmsg)
		CEquStr(errmsg, "NetNameToAddr...");
	err = NetNameToAddr(host, kSMTPPort, &addr, &port);
	if (err != noErr) goto exit;
	
	if (errmsg)
		CEquStr(errmsg, "NetOpen...");
	err = NetOpen(&addr, port, true, &netStream, &responseCode, response, userData, errmsg);
	if (err != noErr) goto exit;

	sPtr = (SmtpTStreamPtr)GetPtr(s);
	sPtr->netStream = netStream;
	sPtr->needReset = false;
	*stream = (SmtpStreamRef)s;
	
	if (responseCode != 220)
		return smtpServerErr;
	
	if (errmsg)
		CEquStr(errmsg, "NetGetMyName...");
	err = NetGetMyName(myName);
	if (err != noErr)
	{
		if (errmsg)
			CEquStr(errmsg, "NetGetMyAddrStr...");
		err = NetGetMyAddrStr(myName);
		if (err != noErr) {
			NetClose(netStream, userData);
			goto exit;
		}
	}
	sprintf(command, "HELO %.250s", myName);
	if (errmsg)
		CEquStr(errmsg, "NetCommand HELO...");
	err = NetCommand(netStream, command, &responseCode, response, userData);
	if (err != noErr) goto exit;
	if (responseCode != 250)
		return smtpServerErr;

	if (errmsg)
		*errmsg = 0;
	return noErr;
	
exit:

	DisposeBlock(&s);
	return err;
}



/*----------------------------------------------------------------------------
	SmtpClose 
	
	Close an SMTP stream.
	
	Entry:	stream = stream reference.
	
	Exit:	function result = result code.
----------------------------------------------------------------------------*/

XErr SmtpClose (SmtpStreamRef stream, long userData)
{
BlockRef 	s;
XErr 		err = noErr;
SmtpTStreamPtr	sPtr;
	
	s = (BlockRef)stream;
	LockBlock(s);
	sPtr = (SmtpTStreamPtr)GetPtr(s);
	err = NetClose(sPtr->netStream, userData);
	DisposeBlock(&s);
	return err;
}


//================================================================================================
XErr SmtpIsAddressValid(SmtpStreamRef stream, char* host, char *user, long userData, Boolean *addressIsValidP)
{
BlockRef 		s;
NetStreamRef 	netStream;
CStr255 		command, response;
long 			responseCode;
XErr 			err = noErr;
SmtpTStreamPtr	sPtr;

	*addressIsValidP = false;	
	s = (BlockRef)stream;
	LockBlock(s);
	sPtr = (SmtpTStreamPtr)GetPtr(s);
	netStream = sPtr->netStream;
	
	if (sPtr->needReset)
	{	strcpy(command, "RSET");
		err = NetCommand(netStream, command, &responseCode, response, userData);
		if (err != noErr) goto exit1;
		if (responseCode != 250) goto exit2;
		sPtr->needReset = false;
	}
	
	if ((CLen(user) + 1 + CLen(host)) < 255)
	{	sprintf(command, "MAIL FROM:<%.243s>", user);
		err = NetCommand(netStream, command, &responseCode, response, userData);
		if (err != noErr) goto exit1;
		if (responseCode != 250) goto exit2;

		sprintf(command, "RCPT TO:<%.*s>", CLen(user), user);
		err = NetCommand(netStream, command, &responseCode, response, userData);
		if (err != noErr) goto exit1;
		if (responseCode != 250 && responseCode != 251) goto exit2;
	}
	else
		goto exit2;

	*addressIsValidP = true;	
	UnlockBlock(s);
	return noErr;
	
exit1:

	DisposeBlock(&s);
	return err;
	
exit2:

	sPtr->needReset = true;
	UnlockBlock(s);
	return smtpServerErr;
}

/*----------------------------------------------------------------------------
	SmtpSendMessage 
	
	Send a mail message.
	
	Entry:	stream = stream reference.
			from = C-format email address of sender.
			to = C-format email address of recipients.
			text = handle to message text, including SMTP header, with CR line 
				terminators. Warning: the memory block is modified by the function.
				The memory block must be unlocked and nonpurgeable.
	
	Exit:	function result = result code.
	
	Multiple recipients may be listed in the "to" string, separated by commas.
----------------------------------------------------------------------------*/

XErr SmtpSendMessage (SmtpStreamRef stream, char *from, char *auth, char *to, BlockRef *textP, long userData, Boolean *mailSentP)
{
BlockRef 		s;
NetStreamRef 	netStream;
char 			*p, *q;
short 			len;
char	 		command[512], response[512];
long 			tLen, newLen, responseCode;
XErr 			err = noErr;
SmtpTStreamPtr	sPtr;
Byte			tempStr[256];
Ptr				toAddressP;

	s = (BlockRef)stream;
	LockBlock(s);
	sPtr = (SmtpTStreamPtr)GetPtr(s);
	netStream = sPtr->netStream;
	
	if (sPtr->needReset) {
		strcpy(command, "RSET");
		err = NetCommand(netStream, command, &responseCode, response, userData);
		if (err != noErr) goto exit1;
		if (responseCode != 250) goto exit2;
		sPtr->needReset = false;
	}
	
	if (auth && *auth && (CLen(auth) < 500))
	{	sprintf(command, "AUTH PLAIN %s", auth);
		err = NetCommand(netStream, command, &responseCode, response, userData);
		if (err != noErr) goto exit1;
		if (responseCode != 235) goto exit2;
	}
	sprintf(command, "MAIL FROM:<%.243s>", from);
	err = NetCommand(netStream, command, &responseCode, response, userData);
	if (err != noErr) goto exit1;
	if (responseCode != 250) goto exit2;
	
	p = to;
	while (*p != 0) {
		q = p;
		while (*q != 0 && *q != ',') q++;
		len = q-p;
		if (len > 0 && len <= 245)
		{	CopyBlock(tempStr, p, len);
			newLen = len;
			if (tLen = ZapText(tempStr, len))
				newLen -= tLen;
			toAddressP = (Ptr)tempStr;
			SkipSpaceAndTabCRLF(&toAddressP, &newLen, nil);
			toAddressP[newLen] = 0;
			sprintf(command, "RCPT TO:<%.*s>", (int)newLen, toAddressP);
			// sprintf(command, "RCPT TO:<%.*s>", len, p);
			err = NetCommand(netStream, command, &responseCode, response, userData);
			if (err != noErr) goto exit1;
			if (responseCode != 250 && responseCode != 251) goto exit2;
		}
		p = q;
		if (*p == ',') p++;
	}
	
	strcpy(command, "DATA");
	err = NetCommand(netStream, command, &responseCode, response, userData);
	if (err != noErr) goto exit1;
	if (responseCode != 354) goto exit2;
	
	err = NetPutText(netStream, textP, true, userData);
	if (err != noErr) goto exit1;
	
	err = NetGetExtraResponse(netStream, &responseCode, response, userData);
	if (err != noErr) goto exit1;
	if (responseCode != 250 && responseCode != 251) goto exit2;
	
	if (mailSentP)
		*mailSentP = true;
	
	UnlockBlock(s);
	return noErr;
	
exit1:

	DisposeBlock(&s);
	return err;
	
exit2:

	sPtr->needReset = true;
	UnlockBlock(s);
	return smtpServerErr;
}



/*----------------------------------------------------------------------------
	SmtpGetServerErrInfo 
	
	Get server error information.
	
	Entry:	stream = stream reference.
	
	Exit:	*serverErrInfo = server error information.
----------------------------------------------------------------------------*/

void SmtpGetServerErrInfo (SmtpStreamRef stream, NetServerErrInfo *serverErrInfo)
{
BlockRef		s;
SmtpTStreamPtr		sPtr;
	
	s = (BlockRef)stream;
	LockBlock(s);
	sPtr = (SmtpTStreamPtr)GetPtr(s);
	NetGetServerErrInfo(sPtr->netStream, serverErrInfo);
	UnlockBlock(s);
}

//----------------------------------------------------------------------------
void SmtpIdle (long userData)
{
	NetIdle (userData);
}
