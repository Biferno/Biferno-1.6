/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: bifernoUnix.c,v 1.15 2004-05-04 13:21:46 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"BfrHeader.h"
#include 	"File.h"

// defines
#define	gsPlugName	"unix"

// Methods
enum{
		k_getenv = 1,
		k_putenv,
		k_setenv,
		k_unsetenv,
		k_getuser,
		k_getgroup
		//k_system
	};
#define TOT_METHODES	6

static 	long	gsApiVersion, bifernoUnixClassID;

#include <stdlib.h>

#if __UNIX_XLIB__ || __MACOSX__
	#if __MACOSX__
		#include <sys/types.h>
		#include <unistd.h>
		#include <stdlib.h>
	#endif
	#include <pwd.h>
	#include <grp.h>
	#include <errno.h>
	#include <sys/wait.h>
#endif

//===========================================================================================
static XErr	_BifernoUnixRegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	bifernoUnixMethods[TOT_METHODES] = 
					{	
					"getenv",		k_getenv,		"static string getenv(string varName)",
					"putenv",		k_putenv,		"static void putenv(string str)",
					"setenv",		k_setenv,		"static void setenv(string name, string value, boolean rewrite)",
					"unsetenv",		k_unsetenv,		"static void unsetenv(string name)",
					"getuser",		k_getuser,		"static string getuser(void)",
					"getgroup",		k_getgroup,		"static string getgroup(void)"
					//"system",		k_system,		"static int system(string command, int timeout_secs=10, string *stdOut, string *stdErr)"
					};

	if (err = BAPI_NewMethods(api_data, bifernoUnixClassID, bifernoUnixMethods, TOT_METHODES, nil))
		return err;

return err;
}

//===========================================================================================
static XErr	_getUser(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
#if __UNIX_XLIB__ || __MACOSX__
struct passwd	*pwp;

	if (pwp = getpwuid(getuid()))
		err = BAPI_StringToObj(api_data, pwp->pw_name, CLen(pwp->pw_name), &exeMethodRecP->resultObjRef);
		
#else
	err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
#endif

return err;
}

//===========================================================================================
static XErr	_getGroup(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
#if __UNIX_XLIB__ || __MACOSX__
struct group	*grp;

	if (grp = getgrgid(getgid()))
		err = BAPI_StringToObj(api_data, grp->gr_name, CLen(grp->gr_name), &exeMethodRecP->resultObjRef);
		
#else
	err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
#endif

return err;
}

//===========================================================================================
/*static XErr	_setUser(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;

#if __UNIX_XLIB__ || __MACOSX__
struct 	passwd	*ent;
CStr63	newUser;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, newUser, nil, 63, kImplicitTypeCast))
		{	errno = 0;
			if (ent = getpwnam(newUser))
			{	errno = 0;
				if (setgid(ent->pw_gid) == -1)
					err = errno;
				else
				{	errno = noErr;
					if (setuid(ent->pw_uid) == -1)
						err = errno;	
				}
			}
			else
				err = errno;
		}
		err = BAPI_IntToObj(api_data, err, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
#else
	#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(exeMethodRecP, totParams, api_data)
	#endif
#endif

return err;
}*/

//===========================================================================================
static XErr	_getEnv(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
char		*strP;
CStr255		varName;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, varName, nil, 255, kImplicitTypeCast))
	{	if (strP = getenv(varName))
			err = BAPI_StringToObj(api_data, strP, CLen(strP), &exeMethodRecP->resultObjRef);
		else
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_PutEnv(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
#if __UNIX_XLIB__
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
long			api_data = pbPtr->api_data;
CStr255			aCStr;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, aCStr, nil, 255, kImplicitTypeCast))
	{	errno = 0;
		if (putenv(aCStr))
			err = errno;
	}
#else
	#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr, execMethodRecP)
	#endif
#endif
return err;
}

//===========================================================================================
static XErr	_SetEnv(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
#if __UNIX_XLIB__
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			name, value;
Boolean			rewrite;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, name, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &paramsP[1].objRef, value, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &paramsP[2].objRef, &rewrite, kImplicitTypeCast))
			{	errno = 0;
				if (setenv(name, value, rewrite))
					err = errno;
			}
		}
	}
#else
	#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr, execMethodRecP)
	#endif
#endif
return err;
}

//===========================================================================================
static XErr	_UnsetEnv(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
#if __UNIX_XLIB__
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			name;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, name, nil, 255, kImplicitTypeCast))
		unsetenv(name);
#else
	#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr, execMethodRecP)
	#endif
#endif	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	bifernoUnix_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	bifernoUnixClassID = pbPtr->param.registerRec.pluginID;
	
return err;
}

//===========================================================================================
static XErr	bifernoUnix_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _BifernoUnixRegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	bifernoUnix_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
//long				totParams = exeMethodRecP->totParams;

	switch(exeMethodRecP->methodID)
	{
		case k_getenv:
			err = _getEnv(exeMethodRecP, api_data);
			break;
		case k_putenv:
			err = _PutEnv(pbPtr, exeMethodRecP);
			break;
		case k_setenv:
			err = _SetEnv(pbPtr, exeMethodRecP);
			break;
		case k_unsetenv:
			err = _UnsetEnv(pbPtr, exeMethodRecP);
			break;
		case k_getuser:
			err = _getUser(exeMethodRecP, api_data);
			break;
		case k_getgroup:
			err = _getGroup(exeMethodRecP, api_data);
			break;
		/*case k_system:
			err = _biferno_system(exeMethodRecP, api_data);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif
//===========================================================================================
XErr	bifernoUnix_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = bifernoUnix_Register(pbPtr);
			break;
		case kInit:
			err = bifernoUnix_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = bifernoUnix_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kGetErrMessage:
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


//===========================================================================================
// note that must be: args[totArgs] = nil;
/*static XErr	_exec_unix_command(char *fileName, char *args, int totArgs, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP, long *resultP)
{
XErr			err = noErr;
Ptr				textP;
int				fd[2], fdErr[2];
pid_t			pid;
int 			n;
CStr63			msgStr;

	errno = noErr;
	if (pipe(fd) < 0)
		err = errno;
	else
	{	if (pipe(fdErr) < 0)
			err = errno;
		else
		{	errno = noErr;
			if ((pid = fork()) < 0)
				err = errno;
			else if (pid == 0)		// child
			{	dup2(fd[1], 1);		// duplicate (and close) stdOut to fd[1]
				close(fd[0]);
				dup2(fdErr[1], 2);	// duplicate (and close) stdErr to fdErr[1]
				close(fdErr[0]);
				errno = noErr;
				execvp(fileName, (Ptr*)args);	// if success, will never return
				sprintf(msgStr, "biferno exec: %s", strerror(errno));
				write(fdErr[1], msgStr, CLen(msgStr));
				exit(0);
			}
			if NOT(err)				// parent
			{	errno = noErr;
				if (waitpid(pid, resultP, WNOHANG) < 0)
					err = errno;
				close(fd[1]);
				close(fdErr[1]);
				if NOT(err)
				{	if (stdOutP)
						err = _read_fd(fd[0], stdOutP, stdOutLenP);
					if (stdErrP)
						err = _read_fd(fdErr[0], stdErrP, stdErrLenP);
				}
			}
		}
	}

return err;
}*/

//===========================================================================================
/*static XErr	_exec_command(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;

#if __UNIX_XLIB__ || __MACOSX__
CStr255		aCStr;
long		max, commandLen, index;
Ptr			commandP, strP;
BlockRef	ref;
char		*argv[MAX_EXEC_ARGUMENTS];
BlockRef 	stdOutBlock, stdErrBlock;
long 		result, stdOutLen, stdErrLen;
Boolean		isInit;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &commandP, &commandLen, &ref, kImplicitTypeCast))
	{	SkipSpaceAndTab(&commandP, &commandLen);
		index = 0;
		if (commandLen)
		{	argv[index++] = commandP;
			max = MAX_EXEC_ARGUMENTS-1;
			do
			{	if (SkipSpaceAndTab(&commandP, &commandLen))
				{	*(commandP-1) = 0;
					if (*commandP)
					{	if (index < max)
							argv[index++] = commandP;
						else
						{	err = XError(kBAPI_ClassError, ErrTooMuchArguments);
							break;
						}
					}
				}
			} while (*commandP++);
			if NOT(err)
			{	argv[index] = nil;
				if NOT(err = _exec_unix_command(argv[0], (char*)argv, index, &stdOutBlock, &stdOutLen, &stdErrBlock, &stdErrLen, &result))
				{	if (NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[1].objRef, &isInit)) && isInit)
						err = BAPI_StringToObj(api_data, GetPtr(stdOutBlock), stdOutLen, &exeMethodRecP->paramVarsP[1].objRef);
					if NOT(err)
					{	if (NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[2].objRef, &isInit)) && isInit)
							err = BAPI_StringToObj(api_data, GetPtr(stdErrBlock), stdErrLen, &exeMethodRecP->paramVarsP[2].objRef);
						if NOT(err)
							err = BAPI_IntToObj(api_data, result, &exeMethodRecP->resultObjRef);
					}
					DisposeBlock(&stdOutBlock);
					DisposeBlock(&stdErrBlock);
				}
			}
		}
		else
			err = XError(kBAPI_ClassError, ErrCommandIsEmpty);
		BAPI_ReleaseBlock(&ref);
	}
		
#else
	err = XError(kBAPI_Error, Err_NotImplemented);
#endif

return err;
}
*/
