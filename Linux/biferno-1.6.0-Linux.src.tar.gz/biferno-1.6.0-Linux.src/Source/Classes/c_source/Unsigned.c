/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Unsigned.c,v 1.9 2006-07-10 11:02:26 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BifernoEngineAPI.h"
#include 	"StaticClasses.h"

#include 	<limits.h>

static long	unsignClassID;
static long		gsApiVersion;

#define	gsPlugName		"unsigned"


// Methods
enum{
		kToTime = 1
	};
#define TOT_METHODES	1
static BAPI_MemberRecord	gsUnsignedMethods[TOT_METHODES] = 
					{	"ToTime", kToTime, 	"time ToTime(void)"
					};

//===========================================================================================
static Boolean	Do_UnsignedOperation(long operation, LONGLONG item1, LONGLONG item2, Boolean *isBoolP, Boolean *boolResP, LONGLONG *resultP)
{
LONGLONG		res = 0;
Boolean			boolres = false;
unsigned long	aLong;

	*isBoolP = false;
	switch(operation)
	{	case EVAL_MULT:
			if (LongLongMul(&item1, item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_DIV:
			if (item2/*&& __llmul(&item1, 1/item2)*/)
				res = item1 / item2;
			else
				return true;
			break;
		case EVAL_MOD:
			aLong = (unsigned long)item2;
			res = item1 % aLong;
			break;
		case EVAL_ADD:
			if (LongLongAdd(&item1, item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_MINUS:
			if (LongLongAdd(&item1, -item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_SHIFTR:
			aLong = (unsigned long)item2;
			res = item1 >> aLong;
			break;
		case EVAL_SHIFTL:
			aLong = (unsigned long)item2;
			res = item1 << aLong;
			break;
		case EVAL_GTH:
			boolres = item1 > item2;
			*isBoolP = true;
			break;
		case EVAL_LTH:
			boolres = item1 < item2;
			*isBoolP = true;
			break;
		case EVAL_GEQ:
			boolres = item1 >= item2;
			*isBoolP = true;
			break;
		case EVAL_LEQ:
			boolres = item1 <= item2;
			*isBoolP = true;
			break;
		case EVAL_EQUA:
			boolres = item1 == item2;
			*isBoolP = true;
			break;
		case EVAL_NEQUA:
			boolres = item1 != item2;
			*isBoolP = true;
			break;
		case EVAL_ARAND:
			aLong = (unsigned long)item2;
			res = item1 & aLong;
			break;
		case EVAL_AROR:
			aLong = (unsigned long)item2;
			res = item1 | aLong;
			break;
		default:
			CDebugStr("Unknown operator!");
	}

*boolResP = boolres;
*resultP = res;
return false;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// Ci si deve registrare dando il nome della classe (costruttore), dicendo di 
// che tipo � il plugin e ricevendo la propria classID
static XErr	Unsign_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;

	if (err = BAPI_NewMethods(pbPtr->api_data, unsignClassID, gsUnsignedMethods, TOT_METHODES, nil))
		return err;

return err;
}

//===========================================================================================
// Finalizzazioni
static XErr	Unsign_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	unsignClassID = 0;
	
return noErr;
}

//===========================================================================================
// Data una sequenza di caratteri (constructorRecP->data), o una sequenza di obj (varRecsP) 
// si deve creare un oggetto di tipo inta usando la callback "BAPI_BufferToObj"
static XErr	Unsign_Constructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data;
//BlockRef		dataBlock = 0;
unsigned long	uLong;

	/*if (constructorRecP->dataP)
	{	if (constructorRecP->isString == INTERNAL)
		{	uLong = *(unsigned long*)constructorRecP->dataP;
			err = BAPI_BufferToObj(api_data, &uLong, sizeof(unsigned long), unsignClassID, true, nil, constructorRecP->scope, constructorRecP->type, &constructorRecP->resultObjRef);
		}
		else
		{	if (constructorRecP->dataLen < 255)
			{	CopyBlock(&aStr[1], constructorRecP->dataP, constructorRecP->dataLen);
				aStr[0] = constructorRecP->dataLen;
				if (PStringToNumExt(aStr, nil, &uLong) == -1)
					err = XError(kBAPI_Error, Err_Overflow);
				else
					err = BAPI_BufferToObj(api_data, &uLong, sizeof(unsigned long), unsignClassID, true, nil, constructorRecP->scope, constructorRecP->type, &constructorRecP->resultObjRef);
			}
			else
				err = Err_BadConstructorArgument;
		}
	}
	else */
	
	if (constructorRecP->totVars == 1)
	{	
		if (OBJ_CLASSID(constructorRecP->varRecsP[0].objRef) == unsignClassID)
			err = BAPI_CopyObj(api_data, &constructorRecP->varRecsP[0].objRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
		else
		{	if NOT(err = BAPI_ObjToUnsigned(api_data, &constructorRecP->varRecsP->objRef, &uLong, kImplicitTypeCast))
				err = BAPI_BufferToObj(api_data, &uLong, sizeof(unsigned long), unsignClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "unsigned(obj param)");
	}

	if NOT(err)
		OBJ_CLASSID(constructorRecP->resultObjRef) = unsignClassID;
		
return err;
}


//===========================================================================================
// Il risultato va messo in objRef1
static XErr	Unsign_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err= noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				operation = exeOperationRecP->operation;
Boolean				boolres, isBool;
long				api_data = pbPtr->api_data;
LONGLONG 			item1_l, item2_l, res_l;

	if NOT(err = BAPI_ObjToLong(api_data, &exeOperationRecP->objRef1, &item1_l, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToLong(api_data, &exeOperationRecP->objRef2, &item2_l, kImplicitTypeCast))
		{	if (Do_UnsignedOperation(operation, item1_l, item2_l, &isBool, &boolres, &res_l))
				err = XError(kBAPI_Error, Err_Overflow);
			else
			{	if (isBool)
					err = BAPI_BooleanToObj(api_data, boolres, &exeOperationRecP->resultObjRef);
				else
				{	if ((res_l >= 0) && (res_l <= ULONG_MAX))
						err = BAPI_UnsignedToObj(api_data, (unsigned long)res_l, &exeOperationRecP->resultObjRef);
					else
						err = BAPI_LongToObj(api_data, res_l, &exeOperationRecP->resultObjRef);
				}
			}
		}
	}
		
return err;
}

//===========================================================================================
/*static XErr	Unsign_Increment(Biferno_ParamBlockPtr pbPtr)
{
IncrementRec	*incrP = &pbPtr->param.incrementRec;
XErr			err = noErr;

	err = DLM_IncrementUnsigned(OBJ_LIST(incrP->objRef), OBJ_ID(incrP->objRef), incrP->decrement);
	
return noErr;
}*/

//===========================================================================================
static XErr	Unsign_Opposite(Biferno_ParamBlockPtr pbPtr)
{
OppositeRec		*oppP = &pbPtr->param.oppositeRec;
XErr			err = noErr;
long			tLen;
unsigned long	uLong;

	tLen = sizeof(unsigned long);
	//if NOT(err = DLM_GetObj(OBJ_LIST(oppP->objRef), OBJ_ID(oppP->objRef), (Ptr)&uLong, &tLen, 0, nil))
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &oppP->objRef, (Ptr)&uLong, &tLen, 0, nil))
		err = BAPI_UnsignedToObj(pbPtr->api_data, /*-*/uLong, &oppP->resultObjRef);	

return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	Unsign_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;
unsigned long 		uLong;
XDateTimeRec		xdtRec;
CStr255				cStr, formatStr;
ObjRef				tObjRef;

	BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);	// for void
	if NOT(err = BAPI_ObjToUnsigned(pbPtr->api_data, &exeMethodRecP->objRef, &uLong, kExplicitTypeCast))
	{	switch(exeMethodRecP->methodID)
		{
			case kToTime:
				if (totParams == 0)
				{	SecondsToXDateTime(uLong, &xdtRec);
					if NOT(err = BAPI_GetDateFormat(api_data, formatStr))
					{	XDateTimeToString(&xdtRec, cStr, kComplete, formatStr);
						BAPI_InvalObjRef(api_data, &tObjRef);
						if NOT(err = BAPI_StringToObj(api_data, cStr, CLen(cStr), &tObjRef))
							err = BAPI_TypeCast(api_data, &tObjRef, BAPI_ClassIDFromName(api_data, "time", false), &exeMethodRecP->resultObjRef, kExplicitTypeCast);
					}
				}
				else
					err = XError(kBAPI_Error, Err_PrototypeMismatch);
				break;
											
			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
	}
	
return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	Unsign_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	Unsign_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr				err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchProperty);
	
return err;
}

//===========================================================================================
/*static XErr	Unsign_Modify(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ModifyRec		*modifyRecP = &pbPtr->param.modifyRec;
long			api_data = pbPtr->api_data;
unsigned long	uLong;

	if NOT(err = BAPI_ObjToUnsigned(api_data, &modifyRecP->value, &uLong, kImplicitTypeCast))
		err = BAPI_ModifyObj(api_data, &modifyRecP->varToModify, &uLong, sizeof(unsigned long), unsignClassID);
	
return err;
}*/

//===========================================================================================
static XErr	Unsign_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
unsigned long	uLong;
CStr255			aCStr;
long			cLen;
Ptr				p;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
//TypeCastParam	*param_s = &typeCast->param1, *param_d = &typeCast->param2;
long			api_data = pbPtr->api_data;
PrimitiveUnion	*param_d;
//ParameterRec	parameter;
long			tLen;

	tLen = sizeof(unsigned long);
	if NOT(err = BAPI_GetObj(api_data, &typeCast->objRef, (Ptr)&uLong, &tLen, 0, nil))
	{	if NOT(tLen)
			uLong = 0;
		param_d = &typeCast->result;
		switch(typeCast->resultWanted)
		{	case kInt:
				param_d->intValue = uLong;
				break;
			case kLong:
				param_d->longValue = uLong;
				break;
			case kUnsigned:
				param_d->uIntValue = uLong;
				break;
			case kDouble:
				param_d->doubleValue = uLong;
				break;
			case kBool:
				param_d->boolValue = (uLong != 0);
				break;
			case kCString:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				CUnsignedToString(uLong, aCStr);
				cLen = CLen(aCStr);
				if (p = param_d->text.stringP)
				{	if (param_d->text.stringMaxStorage >= (cLen + 1))
					{	CopyBlock(p, aCStr, cLen);
						p[cLen] = 0;
						param_d->text.stringLen = cLen;
					}
					else
					{	CopyBlock(p, aCStr, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = cLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = cLen;
				break;
			case kChar:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				CUnsignedToString(uLong, aCStr);
				*param_d->theChar = *aCStr;
				break;
			/*case kObj:
				BAPI_ClearParameterRec(api_data, &parameter);
				if NOT(err = BAPI_BufferToObj(api_data, &uLong, sizeof(unsigned long), unsignClassID, true, nil, TEMP, VARIABLE, &parameter.objRef))
					err = BAPI_Clone(api_data, TEMP, VARIABLE, nil, param_d->objRef.classID, &parameter, 1, &param_d->objRef);
				break;*/
			default:
				CDebugStr("Unknown TypeCast Parameter");
				break;
		}
	}


return err;
}
//===========================================================================================
// trasformazione dell'obj in long (kInt), u long (kUnsigned), double (kDouble) o boolean (kBool)
/*static XErr	Unsign_StandardType(Biferno_ParamBlockPtr pbPtr)
{
StandardType	*standardTypeRecP = &pbPtr->param.standardType;
XErr			err = noErr;
CStr255			aCStr;
BlockRef		dataBlock = 0;
long			which = standardTypeRecP->which;
long			cLen, api_data = pbPtr->api_data;
unsigned long	uLong;

	if NOT(err = BAPI_GetObj(api_data, &standardTypeRecP->objRef, (Ptr)&uLong, nil, nil, 0, 0, sizeof(unsigned long)))
	{	if (which == kInt)
			standardTypeRecP->intValue = uLong;
		else if (which == kUnsigned)
			standardTypeRecP->uIntValue = uLong;
		else if (which == kDouble)
			standardTypeRecP->doubleValue = uLong;
		else if (which == kBool)
			standardTypeRecP->boolValue = (uLong != 0);
		else if (which == kCString)
		{	CNumToString(uLong, aCStr);
			cLen = CLen(aCStr);
			if (standardTypeRecP->stringP)
			{	if (standardTypeRecP->stringMaxStorage >= cLen)
				{	CopyBlock(standardTypeRecP->stringP, aCStr, cLen);
					standardTypeRecP->stringLen = cLen;
				}
				else
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
			}
			else
				standardTypeRecP->stringLen = cLen;
		}
	}
	
return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	unsigned_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			unsignClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void unsigned(obj num)");
	
			break;
		case kInit:
			err = Unsign_Init(pbPtr);
			break;
		case kShutDown:
			err = Unsign_ShutDown(pbPtr);
			break;
		case kRun:
			// do nothing
			break;
		case kExit:
			// do nothing
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Unsign_Constructor(pbPtr);
			break;
		case kDestructor:
			// do nothing
			break;
		case kExecuteOperation:
			err = Unsign_ExecuteOperation(pbPtr);
			break;
		/*case kIncrement:
			err = Unsign_Increment(pbPtr);
			break;*/
		case kOpposite:
			err = Unsign_Opposite(pbPtr);
			break;
		case kExecuteMethod:
			err = Unsign_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Unsign_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Unsign_SetProperty(pbPtr);
			break;
		/*case kModify:
			err = Unsign_Modify(pbPtr);
			break;*/
		case kPrimitive:
			err = Unsign_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


