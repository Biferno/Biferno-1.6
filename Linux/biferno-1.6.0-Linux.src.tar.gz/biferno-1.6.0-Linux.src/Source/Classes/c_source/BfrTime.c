/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BfrTime.c,v 1.11 2005-08-30 15:27:23 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include 	"BfrTime.h"
#include 	<time.h>

static long	timeClassID;
static long		gsApiVersion;

#define	gsPlugName		"time"


typedef struct {
				XDateTimeRec	timeRec;
				CStr63			formatStr;
				} Time_Record, *Time_RecordP;

// Properties
enum{
		kHour = 1,
		kMinute,
		kSecond,
		kYear,
		kMonth,
		kDay,
		kDayOfWeek,
		k_Format,
		
		kSUNDAY,
		kMONDAY,
		kTUESDAY,
		kWEDNESDAY,
		kTHURSDAY,
		kFRIDAY,
		kSATURDAY
	};
#define TOT_PROPRIETIES	8
#define TOT_CONSTANT	7
// Methods
enum{
		k_Hour = 1,
		kDate,
		kToSecs,
		kStrftime,
		kGMT,
		kUString,
		kIn,
		kMillisecs
	};
#define TOT_METHODES	8

// Errors
#define	START_ERR	100
enum {
		ErrInvalidTimeString = START_ERR		
};

CStr63	gTimeErrorsStr[] = 
	{	
		"ErrInvalidTimeString"
		};
#define	TOT_ERRORS	1
		
//===========================================================================================
/*static XErr	_TimeRecToExt(XDateTimeRec *timeRecP, XDateTimeRecExt *timeRecExtP)
{
	timeRecExtP->year = timeRecP->year;
	timeRecExtP->month = timeRecP->month;
	timeRecExtP->day = timeRecP->day;
	timeRecExtP->hour = timeRecP->hour;
	timeRecExtP->minute = timeRecP->minute;
	timeRecExtP->second = timeRecP->second;
	timeRecExtP->dayOfWeek = timeRecP->dayOfWeek;
}

//===========================================================================================
static XErr	_TimeRecFromExt(XDateTimeRecExt *timeRecExtP, XDateTimeRec *timeRecP)
{
	timeRecP->year = timeRecExtP->year;
	timeRecP->month = timeRecExtP->month;
	timeRecP->day = timeRecExtP->day;
	timeRecP->hour = timeRecExtP->hour;
	timeRecP->minute = timeRecExtP->minute;
	timeRecP->second = timeRecExtP->second;
	timeRecP->dayOfWeek = timeRecExtP->dayOfWeek;
}
*/
//===========================================================================================
static XErr	_AddToProp(XDateTimeRec *timeRecP, long propID, long aLong)
{
XErr	err = noErr;

	switch(propID)
	{	case kHour:
			timeRecP->hour = aLong;
			break;
		case kMinute:
			timeRecP->minute = aLong;
			break;
		case kSecond:
			timeRecP->second = aLong;
			break;
		case kYear:
			timeRecP->year = aLong;
			break;
		case kMonth:
			timeRecP->month = aLong;
			break;
		case kDay:
			timeRecP->day = aLong;
			break;
		case kDayOfWeek:
			timeRecP->dayOfWeek = aLong;
			break;
		case k_Format:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
/*static XErr	_AddToProp_Long(XDateTimeRecExt *timeRecP, long propID, LONGLONG ll)
{
XErr	err = noErr;

	switch(propID)
	{	case kHour:
			timeRecP->hour = ll;
			break;
		case kMinute:
			timeRecP->minute = ll;
			break;
		case kSecond:
			timeRecP->second = ll;
			break;
		case kYear:
			timeRecP->year = ll;
			break;
		case kMonth:
			timeRecP->month = ll;
			break;
		case kDay:
			timeRecP->day = ll;
			break;
		case kDayOfWeek:
			timeRecP->dayOfWeek = ll;
			break;
		case k_Format:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}
*/
//===========================================================================================
static XErr	_Millisecs(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
unsigned long	m_secs;

	XGetMilliseconds(&m_secs);
	err = BAPI_UnsignedToObj(api_data, m_secs, &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_Strftime(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, XDateTimeRec *timeRecP)
{
XErr		err = noErr;
long		api_data = pbPtr->api_data;
char		strftimeString[1024];
CStr63		formatStr;
struct tm	tmRec;
int			numchars;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, formatStr, nil, 63, kImplicitTypeCast))
	{	if ((timeRecP->year < BASE_YEAR) || (timeRecP->year > MAX_YEAR))
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
		else
		{	XDateTime2ANSI(timeRecP , (Ptr)&tmRec);
			numchars = strftime(strftimeString, 255, formatStr, &tmRec);
			err = BAPI_StringToObj(api_data, strftimeString, numchars, &exeMethodRecP->resultObjRef);
		}
	}
	else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
	{	err = XError(kBAPI_Error, Err_StringTooLong);
		CEquStr(pbPtr->error, "The format string must be shorter than 64");
	}

return err;
}

//===========================================================================================
static XErr	_In(long api_data, ExecuteMethodRec	*exeMethodRecP, XDateTimeRec *thisTimeP)
{
ObjRef			from, to;
XErr			err = noErr;
XDateTimeRec	*fromXDT_P, *toXDT_P;
Time_Record		fromTR, toTR;
long			tLen;
short			res1, res2;

	BAPI_InvalObjRef(api_data, &from);
	BAPI_InvalObjRef(api_data, &to);
	if NOT(err = BAPI_TypeCast(api_data, &exeMethodRecP->paramVarsP[0].objRef, timeClassID, &from, kImplicitTypeCast))
	{	if NOT(err = BAPI_TypeCast(api_data, &exeMethodRecP->paramVarsP[1].objRef, timeClassID, &to, kImplicitTypeCast))
		{	tLen = sizeof(Time_Record);
			if NOT(err = BAPI_ReadObj(api_data, &from, (Ptr)&fromTR, &tLen, 0, nil))
			{	fromXDT_P = &fromTR.timeRec;
				tLen = sizeof(Time_Record);
				if NOT(err = BAPI_ReadObj(api_data, &to, (Ptr)&toTR, &tLen, 0, nil))
				{	toXDT_P = &toTR.timeRec;
					res1 = XCompareDateTime(thisTimeP, fromXDT_P);	// -1 or 0 this >= from
					res2 = XCompareDateTime(thisTimeP, toXDT_P);	// +1 or 0 this <= to
					err = BAPI_BooleanToObj(api_data, (Boolean)(((res1 == -1) || (res1 == 0)) && ((res2 == +1) || (res2 == 0))), &exeMethodRecP->resultObjRef);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	_Sub(long api_data, ExecuteMethodRec	*exeMethodRecP, XDateTimeRec *thisTimeP)
{
XErr			err = noErr;
ObjRef			subTime;
Time_Record		subTimeTR;
time_t			thisSec, subSecs;
long			tLen;

	BAPI_InvalObjRef(api_data, &subTime);
	if NOT(err = BAPI_TypeCast(api_data, &exeMethodRecP->paramVarsP[0].objRef, timeClassID, &subTime, kImplicitTypeCast))
	{	tLen = sizeof(Time_Record);
		if NOT(err = BAPI_ReadObj(api_data, &subTime, (Ptr)&subTimeTR, &tLen, 0, nil))
		{	XDateTimeToSeconds(&subTimeTR.timeRec, &subSecs);
			XDateTimeToSeconds(thisTimeP, &thisSec);
			err = BAPI_LongToObj(api_data, thisSec - subSecs, &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}
*/

//===========================================================================================
static void	_RecalcDayOfWeek(XDateTimeRec *timeRecP)
{	
time_t	secs;

	if ((timeRecP->year < BASE_YEAR) || (timeRecP->year > MAX_YEAR))
		timeRecP->dayOfWeek = 0;
	else
	{	// for dayOfWeek
		XDateTimeToSeconds(timeRecP, &secs);
		SecondsToXDateTime(secs, timeRecP);
	}
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Time_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
BAPI_MemberRecord	timeProperty[TOT_PROPRIETIES] = 
					{	"format", 		k_Format,	"string",
						"year", 		kYear,		"int",
						"month", 		kMonth,		"int",
						"day",			kDay,		"int",
						"hour", 		kHour,		"int",
						"minute", 		kMinute,	"int",
						"second",		kSecond,	"int",
						"dayOfWeek",	kDayOfWeek,	"int"
					};

BAPI_MemberRecord	timeMethods[TOT_METHODES] = 
					{	"Hour",		k_Hour, 		"string Hour(void)",
						"Date",		kDate, 			"string Date(void)",
						"ToSecs",	kToSecs, 		"long ToSecs(void)",
						"Strftime", kStrftime, 		"string Strftime(string format)",
						"GMT", 		kGMT, 			"time GMT(void)",
						"UString",	kUString,		"string UString(void)",
						"In",		kIn,			"boolean In(time from, time to)",
						"Millisecs",kMillisecs, 	"static unsigned Millisecs(void)"
					};

BAPI_MemberRecord	timeConstants[TOT_CONSTANT] = 
					{	"sunday",		kSUNDAY, 		"int",
						"monday",		kMONDAY, 		"int",
						"tuesday",		kTUESDAY, 		"int",
						"wednesday",	kWEDNESDAY, 	"int",
						"thursday", 	kTHURSDAY, 		"int",
						"friday",		kFRIDAY,		"int",
						"saturday",		kSATURDAY,		"int"
					};

	if (err = BAPI_NewProperties(pbPtr->api_data, timeClassID, timeProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewMethods(pbPtr->api_data, timeClassID, timeMethods, TOT_METHODES, nil))
		return err;
	if (err = BAPI_NewConstants(pbPtr->api_data, timeClassID, timeConstants, TOT_CONSTANT, nil))
		return err;
	err = BAPI_RegisterErrors(pbPtr->api_data, timeClassID, START_ERR, gTimeErrorsStr, TOT_ERRORS);

return err;
}

//===========================================================================================
static XErr	Time_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	timeClassID = 0;
	
return noErr;
}

//===========================================================================================
static XErr	Time_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data, totVars;
CStr255			timeStr;
Time_Record		timeRec;
time_t		 	secs;
unsigned long	now;

	ClearBlock(&timeRec, sizeof(Time_Record));
	totVars = constructorRecP->totVars;
	if ((totVars == 1) || (totVars == 2))
	{	if ((BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP[0].objRef) == timeClassID) && clone)
			err = BAPI_CopyObj(api_data, &constructorRecP->varRecsP[0].objRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
		else
		{	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP->objRef, timeStr, nil, 254, kImplicitTypeCast))
			{	if (totVars == 2)
					err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[1].objRef, timeRec.formatStr, nil, 63, kImplicitTypeCast);
				else
					*timeRec.formatStr = 0;
				if NOT(err)
				{	if NOT(*timeRec.formatStr)
						err = BAPI_GetDateFormat(api_data, timeRec.formatStr);
					if NOT(err)
					{	if NOT(*timeStr)
							goto nowTime;
						else
						{	if NOT(err = XStringToDateTime(timeStr, &timeRec.timeRec, timeRec.formatStr))
							{	if ((timeRec.timeRec.year < BASE_YEAR) || (timeRec.timeRec.year > MAX_YEAR))
									timeRec.timeRec.dayOfWeek = 0;
								else
								{	// for dayOfWeek
									XDateTimeToSeconds(&timeRec.timeRec, &secs);
									SecondsToXDateTime(secs, &timeRec.timeRec);
								}
								err = BAPI_BufferToObj(api_data, (Ptr)&timeRec, sizeof(Time_Record), timeClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
							}
							if (err == XError(kXLibError, ErrXDateTimeFormatError))
							{	err = XError(kBAPI_ClassError, ErrInvalidTimeString);
								CEquStr(pbPtr->error, "Can't obtain a correct time from this string");
							}
						}
					}
				}
			}
		}
	}
	else if NOT(totVars)	// current time
	{	
	nowTime:
		XGetSeconds(&now);
		SecondsToXDateTime(now, &timeRec.timeRec);
		err = BAPI_BufferToObj(api_data, (Ptr)&timeRec, sizeof(Time_Record), timeClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "time(string timeString = current, string formatString)");
	}

	//if NOT(err)
	//	BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, timeClassID);
		//constructorRecP->resultObjRef.classID = timeClassID;
		
return err;
}

//===========================================================================================
static XErr	Time_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err= noErr;
XDateTimeRec		*timeRec1P, *timeRec2P;
Time_Record			theRecord1, theRecord2;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				api_data = pbPtr->api_data, operation = exeOperationRecP->operation;
Boolean				boolres, isBool;
short				result;

	if (BAPI_GetObjClassID(api_data, &exeOperationRecP->objRef2) == timeClassID)
	{	long tLen = sizeof(Time_Record);
	
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeOperationRecP->objRef1, (Ptr)&theRecord1, &tLen, 0, nil))
		{	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeOperationRecP->objRef2, (Ptr)&theRecord2, &tLen, 0, nil))
			{	timeRec1P = &theRecord1.timeRec;
				timeRec2P = &theRecord2.timeRec;
				isBool = false;
				switch(operation)
				{	case EVAL_MULT:
					case EVAL_DIV:
					case EVAL_MOD:
						err = XError(kBAPI_Error, Err_IllegalOperation);
						break;
					case EVAL_ADD:
						err = XError(kBAPI_Error, Err_IllegalOperation);
						/*timeRec1P->hour += timeRec2P->hour;
						timeRec1P->minute += timeRec2P->minute;
						timeRec1P->second += timeRec2P->second;
						timeRec1P->year += timeRec2P->year;
						timeRec1P->month += timeRec2P->month;
						timeRec1P->day += timeRec2P->day;
						XValidDateTime(timeRec1P);
						_RecalcDayOfWeek(timeRec1P);
						*/
						break;
					case EVAL_MINUS:
						err = XError(kBAPI_Error, Err_IllegalOperation);
						/*timeRec1P->hour -= timeRec2P->hour;
						timeRec1P->minute -= timeRec2P->minute;
						timeRec1P->second -= timeRec2P->second;
						timeRec1P->year -= timeRec2P->year;
						timeRec1P->month -= timeRec2P->month;
						timeRec1P->day -= timeRec2P->day;
						XValidDateTime(timeRec1P);
						_RecalcDayOfWeek(timeRec1P);
						*/
						break;
					case EVAL_SHIFTR:
					case EVAL_SHIFTL:
						err = XError(kBAPI_Error, Err_IllegalOperation);
						break;
					case EVAL_GTH:
						result = XCompareDateTime(timeRec1P, timeRec2P);
						boolres = (result == -1);
						isBool = true;
						break;
					case EVAL_LTH:
						result = XCompareDateTime(timeRec1P, timeRec2P);
						boolres = (result == +1);
						isBool = true;
						break;
					case EVAL_GEQ:
						result = XCompareDateTime(timeRec1P, timeRec2P);
						boolres = (result == -1) || NOT(result);
						isBool = true;
						break;
					case EVAL_LEQ:
						result = XCompareDateTime(timeRec1P, timeRec2P);
						boolres = (result == +1) || NOT(result);
						isBool = true;
						break;
					case EVAL_EQUA:
						result = XCompareDateTime(timeRec1P, timeRec2P);
						boolres = (result == 0);
						isBool = true;
						break;
					case EVAL_NEQUA:
						result = XCompareDateTime(timeRec1P, timeRec2P);
						boolres = (result != 0);
						isBool = true;
						break;
					case EVAL_ARAND:
					case EVAL_AROR:
						err = XError(kBAPI_Error, Err_IllegalOperation);
						break;
					default:
						CDebugStr("Unknown operator!");
				}
				if NOT(err)
				{	if (isBool)
						err = BAPI_BooleanToObj(api_data, boolres, &exeOperationRecP->resultObjRef);
					else
						err = BAPI_BufferToObj(api_data, (Ptr)timeRec1P, sizeof(Time_Record), timeClassID, true, nil, &exeOperationRecP->resultObjRef);
				}
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);
		
return err;
}

//===========================================================================================
static XErr	Time_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				tLen, totParams = exeMethodRecP->totParams;
Time_Record			timeRecord;
XDateTimeRec		*timeRecP;
time_t		 		secs;
CStr255				timeStr;

	if (exeMethodRecP->bapiDocP->isStatic)
		timeRecP = nil;
	else
	{	tLen = sizeof(Time_Record);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&timeRecord, &tLen, 0, nil))
			timeRecP = &timeRecord.timeRec;
	}
	if NOT(err)
	{	switch(exeMethodRecP->methodID)
		{
			case k_Hour:
				if (totParams == 0)
				{	XDateTimeToString(timeRecP, timeStr, kWantHour + kLeadingZeros + kWantSecs, timeRecord.formatStr);
					err = BAPI_StringToObj(api_data, timeStr, CLen(timeStr), &exeMethodRecP->resultObjRef);
				}
				else
					err = XError(kBAPI_Error, Err_PrototypeMismatch);
				break;

			case kDate:
				if (totParams == 0)
				{	XDateTimeToString(timeRecP, timeStr, kWantDate + kLeadingZeros, timeRecord.formatStr);
					err = BAPI_StringToObj(api_data, timeStr, CLen(timeStr), &exeMethodRecP->resultObjRef);
				}
				else
					err = XError(kBAPI_Error, Err_PrototypeMismatch);
				break;
			
			case kToSecs:
				if (totParams == 0)
				{	XDateTimeToSeconds(timeRecP, &secs);
					err = BAPI_LongToObj(api_data, secs, &exeMethodRecP->resultObjRef);
				}
				else
					err = XError(kBAPI_Error, Err_PrototypeMismatch);
				break;
			
			case kStrftime:
				err = _Strftime(pbPtr, exeMethodRecP, timeRecP);
				/*if (totParams == 1)
				{	err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, formatStr, nil, 63, kImplicitTypeCast);
					if NOT(err)
					{	
					char	strftimeString[1024];
						
						if ((timeRecP->year < BASE_YEAR) || (timeRecP->year > MAX_YEAR))
							err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
						else
						{	XDateTime2ANSI(timeRecP , (Ptr)&tmRec);
							numchars = strftime(strftimeString, 255, formatStr, &tmRec);
							err = BAPI_StringToObj(api_data, strftimeString, numchars, &exeMethodRecP->resultObjRef);
						}
					}
					else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
					{	err = XError(kBAPI_Error, Err_StringTooLong);
						CEquStr(pbPtr->error, "The format string must be shorter than 64");
					}
				}
				else
					err = XError(kBAPI_Error, Err_PrototypeMismatch);
				*/
				break;
				
			case kGMT:
				XDateTimeToGMT(timeRecP);
				err = BAPI_BufferToObj(api_data, (Ptr)&timeRecord, sizeof(Time_Record), timeClassID, true, nil, &exeMethodRecP->resultObjRef);
				break;
			
			case kUString:
				//XDateTimeToGMT(timeRecP);
				GetUString(timeRecP, timeStr);
				err = BAPI_StringToObj(api_data, timeStr, CLen(timeStr), &exeMethodRecP->resultObjRef);
				break;
				
			case kIn:
				err = _In(api_data, exeMethodRecP, timeRecP);
				break;
			
			case kMillisecs:
				err = _Millisecs(exeMethodRecP, api_data);
				break;
				
			/*case kSub:
				err = _Sub(api_data, exeMethodRecP, timeRecP);
				break;*/

			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Time_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
Time_Record		timeRecord;
XDateTimeRec	*timeRecP;
long			tLen;

	if (getPropertyRec->isConstant)
	{	switch(getPropertyRec->propertyID)
		{	case kSUNDAY:
				err = BAPI_IntToObj(pbPtr->api_data, 1, &getPropertyRec->resultObjRef);
				break;
			case kMONDAY:
				err = BAPI_IntToObj(pbPtr->api_data, 2, &getPropertyRec->resultObjRef);
				break;
			case kTUESDAY:
				err = BAPI_IntToObj(pbPtr->api_data, 3, &getPropertyRec->resultObjRef);
				break;
			case kWEDNESDAY:
				err = BAPI_IntToObj(pbPtr->api_data, 4, &getPropertyRec->resultObjRef);
				break;
			case kTHURSDAY:
				err = BAPI_IntToObj(pbPtr->api_data, 5, &getPropertyRec->resultObjRef);
				break;
			case kFRIDAY:
				err = BAPI_IntToObj(pbPtr->api_data, 6, &getPropertyRec->resultObjRef);
				break;
			case kSATURDAY:
				err = BAPI_IntToObj(pbPtr->api_data, 7, &getPropertyRec->resultObjRef);
				break;
	
			default:
				err = XError(kBAPI_Error, Err_NoSuchConstant);
				break;
		}
	}
	else
	{	tLen = sizeof(Time_Record);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&timeRecord, &tLen, 0, nil))
		{	timeRecP = &timeRecord.timeRec;
			switch(getPropertyRec->propertyID)
			{
				case kHour:
					err = BAPI_IntToObj(pbPtr->api_data, timeRecP->hour, &getPropertyRec->resultObjRef);
					break;
				case kMinute:
					err = BAPI_IntToObj(pbPtr->api_data, timeRecP->minute, &getPropertyRec->resultObjRef);
					break;
				case kSecond:
					err = BAPI_IntToObj(pbPtr->api_data, timeRecP->second, &getPropertyRec->resultObjRef);
					break;
				case kYear:
					err = BAPI_IntToObj(pbPtr->api_data, timeRecP->year, &getPropertyRec->resultObjRef);
					break;
				case kMonth:
					err = BAPI_IntToObj(pbPtr->api_data, timeRecP->month, &getPropertyRec->resultObjRef);
					break;
				case kDay:
					err = BAPI_IntToObj(pbPtr->api_data, timeRecP->day, &getPropertyRec->resultObjRef);
					break;
				case kDayOfWeek:
					err = BAPI_IntToObj(pbPtr->api_data, timeRecP->dayOfWeek, &getPropertyRec->resultObjRef);
					break;
				case k_Format:
					err = BAPI_StringToObj(pbPtr->api_data, timeRecord.formatStr, CLen(timeRecord.formatStr), &getPropertyRec->resultObjRef);
					break;
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	Time_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
long				api_data = pbPtr->api_data;
long				tLen, propID, aLong;
Time_Record			timeRecord;
XDateTimeRec		*timeRecP;
CStr63				formStr;

	tLen = sizeof(Time_Record);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &setPropertyRecP->objRef, (Ptr)&timeRecord, &tLen, 0, nil))
	{	propID = setPropertyRecP->propertyID;
		timeRecP = &timeRecord.timeRec;
		if (propID == k_Format)
			err = BAPI_ObjToString(api_data, &setPropertyRecP->value, formStr, nil, 63, kImplicitTypeCast);
		else
			err = BAPI_ObjToInt(api_data, &setPropertyRecP->value, &aLong, kImplicitTypeCast);
		if NOT(err)
		{	_AddToProp(timeRecP, propID, aLong);
			XValidDateTime(timeRecP);
			_RecalcDayOfWeek(timeRecP);
		}
		/*else if (err == XError(kBAPI_Error, Err_Overflow))
		{
		LONGLONG			ll;
		XDateTimeRecExt		timeRecExt;
		
	DoLong:
			if NOT(err = BAPI_ObjToLong(api_data, &setPropertyRecP->value, &ll, kImplicitTypeCast))
			{	_TimeRecToExt(timeRecP, &timeRecExt);
				_AddToProp_Long(&timeRecExt, propID, ll);
				XValidDateTimeExt(&timeRecExt);
				_TimeRecFromExt(&timeRecExt, timeRecP);
			}
		}*/
		if NOT(err)
			err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&timeRecord, sizeof(Time_Record));
	}
	
return err;
}

//===========================================================================================
static XErr	Time_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				size;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
long				tLen;	//, api_data = pbPtr->api_data;
Time_Record			timeRecord;
XDateTimeRec		*timeRecP;
CStr63				timeStr;
CStr255				aCStr;
Primitive_String	*textP;
int					variant;
PrimitiveUnion		*param_d;
char				*formP;

	tLen = sizeof(Time_Record);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&timeRecord, &tLen, 0, nil))
	{	
	char		*timeStrP;
	
		param_d = &typeCast->result;
		if (typeCast->resultWanted == kCString)
			variant = param_d->text.variant;
		else
			variant = kNormal;

		if (tLen)
			timeRecP = &timeRecord.timeRec;
		else
			timeRecP = nil;
		/*if (variant == kForDebug)
		{	if NOT(err = BAPI_GetDateFormat(api_data, aCStr))
				formP = aCStr;
		}
		else*/
			formP = timeRecord.formatStr;
		if NOT(err)
		{	if (timeRecP)
				XDateTimeToString(timeRecP, timeStr, kComplete, formP);
			else
				*timeStr = 0;
			timeStrP = timeStr;
			size = CLen(timeStr);
			if (variant == kForConstructor)
			{	CEquStr(aCStr, "\"");
				CAddStr(aCStr, timeStr);
				CAddStr(aCStr, "\"");
				timeStrP = aCStr;
				size = CLen(timeStrP);
			}
			if (typeCast->resultWanted == kCString)
			{	textP = &param_d->text;
				if (textP->stringP)
				{	if (textP->stringMaxStorage >= (size + 1))
					{	CopyBlock(textP->stringP, timeStrP, size);
						textP->stringP[size] = 0;
						textP->stringLen = size;
					}
					else
					{	CopyBlock(textP->stringP, timeStrP, textP->stringMaxStorage - 1);
						textP->stringP[textP->stringMaxStorage - 1] = 0;
						textP->stringLen = size;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					textP->stringLen = size;
			}
			else
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	Time_GetErrDescr(Biferno_ParamBlockPtr pbPtr)
{
GetErrDescrRec		*getErrDescrRecP = &pbPtr->param.getErrDescrRec;
short				tErr;

	CEquStr(getErrDescrRecP->errType, "Class time Error");
	if (((tErr = getErrDescrRecP->err) >= START_ERR) && (tErr < lastErr))
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, gTimeErrorsStr[tErr - START_ERR]);
	}
	else
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, "Unknown Error");
	}

return noErr;
}

//===========================================================================================
static XErr	Time_GetErrNumber(Biferno_ParamBlockPtr pbPtr)
{
GetErrNumber	*getErrNumberP = &pbPtr->param.getErrNumber;
char			*strP = getErrNumberP->errName;

	if NOT(CCompareStrings_cs(strP, "ErrInvalidTimeString"))
		getErrNumberP->errNumber = ErrInvalidTimeString;

return noErr;
}
*/
#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif


//===========================================================================================
XErr	time_TimeRecToObjRef(long api_data, XDateTimeRec *timeRecP, ObjRef *objRefP)
{
XErr			err = noErr;
Time_Record		timeRecord;

	timeRecord.timeRec = *timeRecP;
	*timeRecord.formatStr = 0;
	err = BAPI_BufferToObj(api_data, (Ptr)&timeRecord, sizeof(Time_Record), timeClassID, true, nil, objRefP);

return err;
}

//===========================================================================================
XErr	time_ObjRefToTimeRec(long api_data, ObjRef *objRefP, XDateTimeRec *timeRecP)
{
XErr			err = noErr;
Time_Record		timeRecord;
long			tLen;

	tLen = sizeof(Time_Record);
	if NOT(err = BAPI_ReadObj(api_data, objRefP, (Ptr)&timeRecord, &tLen, 0, nil))
		*timeRecP = timeRecord.timeRec;

return err;
}

//===========================================================================================
XErr	time_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			timeClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void time(string timeString, string formatString)");
	
			if NOT(err = BAPI_RegisterSymbol(pbPtr->api_data, timeClassID, "time_TimeRecToObjRef", (long)time_TimeRecToObjRef))
				err = BAPI_RegisterSymbol(pbPtr->api_data, timeClassID, "time_ObjRefToTimeRec", (long)time_ObjRefToTimeRec);
			break;
		case kInit:
			err = Time_Init(pbPtr);
			break;
		case kShutDown:
			err = Time_ShutDown(pbPtr);
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = Time_Constructor(pbPtr, false);
			break;
		case kClone:
			err = Time_Constructor(pbPtr, true);
			break;
		case kDestructor:
			// do nothing
			break;
		case kExecuteOperation:
			err = Time_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = Time_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Time_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Time_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = Time_TypeCast(pbPtr);
			break;
		/*case kGetErrDescr:
			err = Time_GetErrDescr(pbPtr);
			break;
		case kGetErrNumber:
			err = Time_GetErrNumber(pbPtr);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


