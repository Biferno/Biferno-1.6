/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: net.c,v 1.6 2003-06-26 17:02:38 valfer Exp $
	|______________________________________________________________________________

	Thanks to:

		John Norstad
		Academic Technologies
		Northwestern University
		
	for the original version of this file "net.c"

*/
#include 	"XLib.h"
/*----------------------------------------------------------------------------

	net.c

	This reusable and reentrant module handles low-level communications with 
	TCP/IP network servers, using a simple "net ASCII" command/response 
	stream model. It also exports several functions for using FTP data streams,
	and several functions for doing domain name resolver tasks. 
	
	The module hides the complexity and peculiarities of Open Transport and the 
	MacTCP device driver. If Open Transport is available, it is used. Otherwise, 
	MacTCP is used. 
	
	The module also manages many of the common protocol details of communicating
	with net ASCII servers: 
	
	Handling initial server "hello" messages.
	Handling final server "QUIT" commands and all the details of graceful
		asynchronous stream close operations.
	Mapping between CR line terminators and CRLF line terminators.
	Decoding numeric server response codes.
	Skipping server comments (response lines with "-" following the response code).
	Supplying terminating "." lines when sending blocks of text.
	Recognizing and discarding terminating "." lines when reading blocks of text.
	Mapping between leading "." characters and leading ".." characters on text lines. 
	
	The module emphasizes simplicity at the expense of power. There are many things 
	you can do by calling Open Transport or MacTCP directly which you cannot do with 
	this module. The module is *not* a general purpose interface to Open Transport or
	MacTCP designed to meet the needs of all possible Mac TCP/IP networking programs. 
	It is only a convenient interface for writing clients for typical simple net ASCII 
	servers.
	
	The following mandatory functions handle initialization, idle time, and
	termination tasks.
	
		NetInit - Initialize the module.
		NetIdle - Handle idle time tasks.
		NetTerm - Terminate the module.
	
	The following functions work with Net ASCII command/response streams.

		NetOpen - Open a stream.
		NetClose - Close a stream.
		NetCommand - Send a command and get the response.
		NetGetExtraResponse - Get an extra command response.
		NetBatchedCommands - Send several commands in a batch and
			get and process the responses.
		NetPutText - Send command text.
		NetGetText - Get response text.
		
	The following functions work with FTP data streams. They are used by 
	the ftp.c module.
	.
		NetFTPDataPassiveOpen - Open an FTP passive data stream.
		NetFTPDataClose - Close an FTP data stream.
		NetFTPDataWaitForConnection - Wait for the FTP server to open
			its end of an FTP passive data stream.
		NetGetFTPData - Get FTP data.
		NetSendFTPData - Send FTP data.
		
	The following functions handle simple domain name resolver and related tasks.
	
		NetGetMyAddr - Get my IP address.
		NetGetMyAddrStr - Get my IP address as a dotted-decimal string.
		NetGetMyName - Get my domain name.
		NetNameToAddr - Convert a domain name to an IP address.
		NetAddrToName - Convert an IP address to a domain name.
		
	Finally, the module exports the following utility functions:
	
		NetMacTCPDNROperationInProgress - Determine if a MacTCP DNR operation 
			is in progress.
		NetGetServerErrInfo - Get server error information.
		NetGetStreamStats - Get stream stats (bytes in/out).
		NetHaveOT - Determine whether we are using Open Transport or MacTCP.
		NetGetNumOpenStreams - Get the number of open streams.
	
	A "stream" is an abstraction representing a bidirectional network connection
	to a net ASCII TCP/IP server. 
	
	With Open Transport, the notion of a "stream" in this module is basically
	equivalent to a "TCP endpoint". The "NetOpen" function opens an endpoint, 
	binds it to a TCP port,  and creates a connection. The "NetClose" function
	does an orderly disconnect and closes the endpoint.
	
	With MacTCP, the notion of a "stream" in this module combines the 
	separate MacTCP notions of "stream" and "connection". When calling MacTCP 
	directly, you "create" and "release" streams and "open" and "close" connections. 
	These operations are combined in the net.c module. The "NetOpen" function both
	creates a stream and opens a connection. The "NetClose" function both
	closes the connection and releases the stream.
	
	A stream is represented as a variable of type "NetStreamRef". These stream
	references are opaque. You may copy them and pass them as parameters to 
	functions in net.c, but you are prohibited from accessing the contents of
	the memory blocks pointed to by the references. Only the functions in 
	net.c are permitted to manipulate the contents of these blocks.
	
	The functions return a value of type OSErr as the function result:
	
		noErr					no error occurred
		netOpenDriverErr		NetInit could not initialize the network driver
		netOpenStreamErr		stream open failed
		netLostConnectionErr	stream was unexpectedly closed or aborted by server
		netDNRErr				DNR failed to resolve name or address
		netTruncatedErr			incoming text was truncated
		other					any other OS or toolbox error
	
	If any error occurs, the stream is aborted before returning to the caller. 
	"Aborted" means that the server connection is closed abruptly, without going 
	through the usual orderly TCP stream teardown process. The stream is also 
	deallocated. In this case, you must not attempt to reuse the stream reference, 
	since the stream no longer exists. You must perform careful error checking.
	
	The "expected" Open Transport and MacTCP error codes are translated into either
	regular MacOS error codes (e.g., kENOMEMErr -> memFullErr) or into the
	special "net" error codes (e.g., authNameErr -> netDNRErr). This
	gives the clients of this module a uniform set of error codes which are the
	same for both Open Transport and MacTCP. Open Transport and MacTCP error
	codes which are not translated are "unexpected" errors which should not
	occur, and if they do, indicate an error in the code in this module.
	
	Copyright � 1994-1997, Northwestern University.

----------------------------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

//#include "MyMacTCP.h"


#include "def.h"
#include "net.h"
//#include "memutil.h"
//#include "strutil.h"




/*	Global variables. */

Boolean gHaveOT;					/* true if we have Open Transport */
NetGiveTimeFunction gGiveTime;	/* pointer to GiveTime function */
NetLogFunction gLog;				/* pointer to logging function, or nil if none */

BlockRef gAll = nil;				/* pointer to list of open streams */
BlockRef gClose = nil;			/* pointer to list of closing streams */
BlockRef gFree = nil;			/* pointer to list of available preallocated stream buffers */

static long gStreamBufSize;				/* stream buffer size */

//static short gRefNum;					/* MacTCP driver reference number */
//static long gTCPBufSize;				/* TCP buffer size for MacTCP */
//static Boolean gMacTCPDNROperationInProgress = false;
										/* True when MacTCP DNR operation in progress */
										
//static ResultUPP gMacTCPDNRResultProcUPP = nil;
//static TCPIOCompletionUPP gMacTCPCloseStreamCompletionRoutineUPP = nil;
//static UniversalProcPtr gOldExitToShellUPP = nil;
//static UniversalProcPtr gMyExitToShellUPP;


/*----------------------------------------------------------------------------
	TranslateErrorCode 
	
	Translate error codes.
	
	Entry:	err = Open Transport, MacTCP, or OS error code.
	
	Exit:	function result = translated error code.
----------------------------------------------------------------------------*/

XErr TranslateErrorCode (XErr err)
{
	switch (err) {
	#ifdef __MAC_XLIB__
		case kENOMEMErr:
			return memFullErr;
	#endif
		/*case noNameServer:
		case authNameErr:
		case noAnsErr:
		case dnrErr:
		case nameSyntaxErr:
			return netDNRErr;
		case openFailed:
			return netOpenStreamErr;*/
		default:
			return err;
	}
}



/*----------------------------------------------------------------------------
	LogMessage
	
	Log a message.
	
	Entry:	s = pointer to stream.
			logEntryType = 
				'C' if command.
				'R' if response.
				' ' if open/close operation.
			str = command or response string or open/close message string.
----------------------------------------------------------------------------*/

void LogMessage (TStreamPtr s, char logEntryType, char *str, long userData)
{
	if (gLog != nil)
		(*gLog)(logEntryType, &s->serverAddr, s->serverPort, s->localPort, str, userData);
}



/*----------------------------------------------------------------------------
	NewStreamBuffer 
	
	Allocate a stream buffer.
	
	Exit:	function result = error code.
			*s = pointer to new stream buffer.
----------------------------------------------------------------------------*/

static XErr NewStreamBuffer (BlockRef *s)
{
XErr			err = noErr;
TStreamPtr		sPtr;
Ptr				tempP;

	XThreadsEnterCriticalSection();
	if (gFree == nil)
	{	if NOT(*s = NewPtrBlock(gStreamBufSize, &err, &tempP))
			return err;
		ClearBlock(tempP, gStreamBufSize);
		//err = MyNewPtr(gStreamBufSize, s);
		//if (err != noErr) return err;
	}
	else
	{	*s = gFree;
		sPtr = (TStreamPtr)GetPtr(gFree);
		gFree = sPtr->nextFree;
		memset(sPtr, 0, sizeof(TStream));
		sPtr->fromFreeList = true;
	}
	XThreadsLeaveCriticalSection();
	//if (!gHaveOT)
	//	(*s)->myA5 = SetCurrentA5();

return noErr;
}



/*----------------------------------------------------------------------------
	DisposeStreamBuffer 
	
	Dispose a stream buffer.
	
	Entry:	s = pointer to stream buffer.
----------------------------------------------------------------------------*/

static void DisposeStreamBuffer (BlockRef s)
{
TStreamPtr		sPtr;

	if (s == nil) return;
	
	sPtr = (TStreamPtr)GetPtr(s);
#ifdef __MAC_XLIB__
	if (gHaveOT)
	{
		if (sPtr->call != nil) OTFree(sPtr->call, T_CALL);
		if (sPtr->bindReq != nil) OTFree(sPtr->bindReq, T_BIND);
		if (sPtr->bindRet != nil) OTFree(sPtr->bindRet, T_BIND);
	}
#endif	
	if (sPtr->fromFreeList)
	{	XThreadsEnterCriticalSection();
		sPtr->nextFree = gFree;
		gFree = s;
		XThreadsLeaveCriticalSection();
	}
	else
	{
		DisposeBlock(&s);
	}
}



#if __MWERKS__
#pragma mark-
#endif


/*----------------------------------------------------------------------------
	MyExitToShell 
	
	ExitToShell trap patch (for MacTCP only).
	
	This patch makes sure that all open streams are closed when ExitToShell
	is called (e.g., if the program crashes and you type "es" in MacsBug, or
	if you use Command-Option-Escape to force quit the program). This keeps 
	MacTCP happy. It doesn't always work, but it helps sometimes.
	
	Open Transport has its own mechanisms for doing this, so this patch
	is only installed if we are using MacTCP.
----------------------------------------------------------------------------*/

/*static void MyExitToShell (void)
{
	TStreamPtr s;

	SetCurrentA5();
	SetToolTrapAddress(gOldExitToShellUPP, _ExitToShell);
	gLog = nil;
	for (s = gAll; s != nil; s = s->next) DoTCPRelease(s);
	ExitToShell();
}
*/


/*----------------------------------------------------------------------------
	PatchExitToShell 
	
	Install a patch on the ExitToShell trap (for MacTCP only).
----------------------------------------------------------------------------*/

/*static void PatchExitToShell (void)
{
	if (gOldExitToShellUPP != nil) return;
	gOldExitToShellUPP = GetToolTrapAddress(_ExitToShell);
	gMyExitToShellUPP = 
		NewRoutineDescriptor((ProcPtr)MyExitToShell, kPascalStackBased, GetCurrentISA());
	SetToolTrapAddress(gMyExitToShellUPP, _ExitToShell);
}
*/


/*----------------------------------------------------------------------------
	SendCommand 
	
	Send a command on a stream.
	
	Entry:	s = pointer to stream.
			command = C-format command string.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

static XErr SendCommand (TStreamPtr s, char *command, long userData)
{
	XErr err = noErr;
	unsigned short len;

	strcpy(s->command, command);
	len = strlen(command);
	// ex BlockMoveData(command, s->buf, len);
	CopyBlock(s->buf, command, len);
	*(s->buf + len) = CR;
	*(s->buf + len + 1) = LF;
	err = DoTCPSend(s, s->buf, (unsigned short)(len+2));
	if (err != noErr) return err;
	if (gLog != nil) LogMessage(s, 'C', command, userData);
	return noErr;
}



/*----------------------------------------------------------------------------
	CrackNum 
	
	Crack a decimal number from a string after skipping white space.
	
	Entry:	*x = pointer to string.
			
	Exit:	function result = cracked number.
			*x = pointer to first character following number in string.
----------------------------------------------------------------------------*/

static long CrackNum (char **x)
{	
	long result = 0;
	char *y;
	
	y = *x;
	while (isLWSP(*y)) y++;
	while (isdigit(*y)) {
		result = 10*result + (*y - '0');
		y++;
	}
	*x = y;
	return result;
}

/*----------------------------------------------------------------------------
	ReadResponse 
	
	Read a command response from a stream.
	
	Entry:	s = pointer to stream.
	
	Exit:	function result = error code.
			*responseCode = server response code.
			response = C-format server response string, including the 
				response code.
				
	Response comment lines are discarded (response lines with a
	'-' immediately following the response code). Lines which do not
	start with a numeric response code are also discarded.
----------------------------------------------------------------------------*/


// No more than five seconds without receiving data
#define	kReadResponseTicksTimeout	(60L * 60L)	// 60 seconds

//#include	"HTTPMgr.h"
static XErr ReadResponse (TStreamPtr s, long *responseCode, CStr255 response, long userData)
{
char 			*in, *out, *p, *q, *r;
unsigned short 	len, numUnread;
long 			num;
XErr 			err = noErr;
unsigned long	start;
	
	in = s->in;
	out = s->out;
	start = XGetTicks();
	while (true)
	{	while (out < in)
		{
			for (p = out; p < in; p++)
			{
				if (*p == LF) 
				{
					*p = 0;
					q = out;
					out = p+1;
					break;
				} 
				else if (*p == CR && p < in-1 && *(p+1) == LF)
				{
					*p = 0;
					q = out;
					out = p+2;
					break;
				}
			}
			if (p >= in) break;
			r = q;
			if (isdigit(*r))
			{
				num = CrackNum(&r);
			} 
			else if (*r == '-' && isdigit(*(r+1)))
			{
				r++;
				num = -CrackNum(&r);
			} 
			else 
			{
				num = 0;
			}
			if (*r != '-' && num != 0) 
			{
				if (p - q > 255) *(q+255) = 0;
				strcpy(response, q);
				strcpy(s->response, q);
				*responseCode = s->responseCode = num;
				s->in = in;
				s->out = out;
				if (gLog != nil) LogMessage(s, 'R', response, userData);
	/*{
	CStr255	aCStr;
	
	if NOT(err)
		sprintf(aCStr, "response after: %d", (XGetTicks() - start) / 60);
	else
		sprintf(aCStr, "timeout");
	HTTPControllerLog(0, aCStr);
	}*/
				return noErr;
			}
		}
		if (out == in)
		{
			out = in = s->buf;
		} 
		else if (in > s->buf + kBufSizeDiv2)
		{
			numUnread = in - out;
			if (numUnread > kBufSizeDiv2)
			{
				numUnread = kBufSizeDiv2;
				out = in - numUnread;
			}
			// BlockMoveData(out, s->buf, numUnread);
			CopyBlock(s->buf, out, numUnread);
			out = s->buf;
			in = out + numUnread;
		}
		len = s->buf + kBufSize - in;
		err = DoTCPRcv(s, in, &len);
		if (err)		// != noErr) 
			return err;
		
		// No more than five seconds without receiving data
		if (len)
			start = XGetTicks();
		else
		{	if ((XGetTicks() - start) > kReadResponseTicksTimeout)
				break;
		}
		
	/*#if __UNIX_XLIB__ || __WIN_XLIB__
		if NOT(len)	// Added 3/3/2003	(avoid endless loop)
			break;
	#endif*/
		
		in += len;
	}
		
return err;
}

//===========================================================================================
/*static XErr ExMungeOut (BlockRef text, Boolean mungePeriods)
{
	XErr err = noErr;
	char *p, *pEnd, *pStart, *q;
	long textLen, oldTextLen;

	textLen = GetBlockSize(text, &err);
	if (err)
		return err;
	p = GetPtr(text);
	pEnd = p + textLen;
	if (textLen == 0 || *(pEnd-1) != CR)
	{	textLen++;
		err = SetBlockSize(text, textLen);
		if (err != noErr) return err;
		p = GetPtr(text);
		pEnd = p + textLen;
		*(pEnd-1) = CR;
	}
	oldTextLen = textLen;
	if (mungePeriods)
	{	while (p < pEnd)
		{	if (*p == '.') textLen++;
			while (*p != CR) p++;
			p++;
			textLen++;
		}
		textLen += 3;
	}
	else
	{
		for (; p < pEnd; p++) if (*p == CR) textLen++;
	}
	err = SetBlockSize(text, textLen);
	if (err != noErr) return err;
	pStart = GetPtr(text);
	p = pStart + oldTextLen - 1;
	q = pStart + textLen - 1;
	if (mungePeriods)
	{
		*q-- = LF;
		*q-- = CR;
		*q-- = '.';
		while (p >= pStart)
		{
			*q-- = LF;
			*q-- = CR;
			p--;
			while (*p != CR && p >= pStart) *q-- = *p--;
			if (*(p+1) == '.') *q-- = '.';
		}
	}
	else
	{
		while (p >= pStart)
		{
			if (*p == CR) *q-- = LF;
			*q-- = *p--;
		}
	}

p = GetPtr(text);
return noErr;
}
*/
/*----------------------------------------------------------------------------
	MungeOut 
	
	Munge a block of text before sending it out to a server.
	
	Entry:	text = handle to CR-terminated ASCII text lines.
				Warning: the memory block is modified by the function.
				The memory block must be unlocked and nonpurgeable.
			mungePeriods = true to munge periods.
	
	Exit:	function result = error code.
	
	CR line terminators are translated to CRLF. If the text block does
	not have a terminating CR at the end of the last line, one is added.
	
	If mungePeriods=true, leading "." characters on lines are mapped to 
	"..", and a terminating "." on a line by itself is added to the end
	of the text block.
----------------------------------------------------------------------------*/
XErr MungeOut (BlockRef *textBlockP, Boolean mungePeriods)
{
XErr		err = noErr;
long		size, buffID, textLen, lenToAdd;
Ptr			newTextP, textP, pToAdd;
int			ch;
Boolean		beginLines;
BlockRef	newTextBlock, text = *textBlockP;

	if (buffID = BufferCreate(255, &err))
	{	LockBlock(text);
		textP = GetPtr(text);
		textLen = GetBlockSize(text, &err);
		lenToAdd = 0;
		pToAdd = textP;
		beginLines = false;
		do
		{	ch = *textP++;
			textLen--;
			switch (ch)
			{
				case '\r':
					lenToAdd++;
					if (*textP == '\n')		// follows a LF?
					{	textP++;
						textLen--;
						lenToAdd++;
					}
					else
					{	if NOT(err = BufferAddBuffer(buffID, pToAdd, lenToAdd))
						{	if NOT(err = BufferAddChar(buffID, '\n'))
							{	lenToAdd = 0;
								pToAdd = textP;
							}
						}
					}
					if NOT(err)
						beginLines = true;
					break;
			
				case '\n':					// single LF (Unix)
					if NOT(err = BufferAddBuffer(buffID, pToAdd, lenToAdd))
					{	if NOT(err = BufferAddCString(buffID, "\r\n", NO_ENC, 0))
						{	lenToAdd = 0;
							pToAdd = textP;
							beginLines = true;
						}
					}
					break;
				
				case '.':
					if (mungePeriods && beginLines)
					{	lenToAdd++;
						if NOT(err = BufferAddBuffer(buffID, pToAdd, lenToAdd))
						{	if NOT(err = BufferAddChar(buffID, '.'))
							{	lenToAdd = 0;
								pToAdd = textP;
							}
						}
					}
					else
						lenToAdd++;
					beginLines = false;
					break;

				default:		
					lenToAdd++;
					beginLines = false;
					break;
		
			}
		} while (textLen > 0);
		if NOT(err = BufferAddBuffer(buffID, pToAdd, lenToAdd))	// last part
		{	if NOT(beginLines)
				err = BufferAddCString(buffID, "\r\n", NO_ENC, 0);
			if NOT(err)
			{	if (mungePeriods)
					err = BufferAddCString(buffID, ".\r\n", NO_ENC, 0);
				if NOT(err)
				{	newTextBlock = BufferGetBlockRefExtSize(buffID, &size, &newTextP);
					err = BufferSetLength(buffID, size);
				}
			}
		}
	}
	if (err)
	{	if (buffID)
			BufferFree(buffID);
		
	}
	else
	{	*textBlockP = newTextBlock;
		BufferClose(buffID);
		/*{
		// Debug to compare with ExMungeOut
		Ptr		newText2P;
		
		LockBlock(newTextBlock);
		newTextP = GetPtr(newTextBlock);
		
		err = ExMungeOut(text, true);
		newText2P = GetPtr(text);
		}*/

		DisposeBlock(&text);
	}

return err;
}

/*----------------------------------------------------------------------------
	MungeIn 
	
	Munge a block of text after receiving it from a server.
	
	Entry:	text = handle to ASCII text lines as received from server.
				Warning: the memory block is modified by the function.
				The memory block must be unlocked and nonpurgeable.
			textLen = number of characters in text block.
			mungePeriods = true to munge periods.
	
	Exit:	function result = error code.
	
	CRLF line terminators are translated to CR. A final CR is added at the
	end of the last line if necessary.
	
	If mungePeriods=true, leading ".." characters on lines are mapped to 
	".", and the terminating "." on a line by itself is removed from the end
	of the text block.
----------------------------------------------------------------------------*/

static XErr MungeIn(BlockRef *textBlockP, long textLen, Boolean mungePeriods)
{
XErr		err = noErr;
long		size, buffID, lenToAdd;
Ptr			newTextP, textP, pToAdd;
int			ch;
Boolean		beginLines;
BlockRef	newTextBlock, text = *textBlockP;

	if (buffID = BufferCreate(255, &err))
	{	LockBlock(text);
		textP = GetPtr(text);
		lenToAdd = 0;
		pToAdd = textP;
		beginLines = false;
		do
		{	ch = *textP++;
			textLen--;
			switch (ch)
			{
				case '\r':
					lenToAdd++;
					beginLines = true;
					if (*textP == '\n')		// follows a LF?
					{	textP++;
						textLen--;
						lenToAdd++;
					}
					break;
			
				case '\n':					// single LF (Unix)
					lenToAdd++;
					beginLines = true;
					break;
				
				case '.':
					if (mungePeriods && beginLines)
					{	lenToAdd++;
						if (*textP == '.')	// 2 points becomes 1
						{	textP++;
							textLen--;
							// dont add the second '.'
						}
						if NOT(err = BufferAddBuffer(buffID, pToAdd, lenToAdd))
						{	lenToAdd = 0;
							pToAdd = textP;
						}
					}
					else
						lenToAdd++;
					beginLines = false;
					break;

				default:		
					lenToAdd++;
					beginLines = false;
					break;
		
			}
		} while (textLen > 0);
		if NOT(err = BufferAddBuffer(buffID, pToAdd, lenToAdd))	// last part
		{	newTextBlock = BufferGetBlockRefExtSize(buffID, &size, &newTextP);
			err = BufferSetLength(buffID, size);
		}
	}
	if (err)
	{	if (buffID)
			BufferFree(buffID);
		
	}
	else
	{	*textBlockP = newTextBlock;
		BufferClose(buffID);
		DisposeBlock(&text);
	}

return err;
}

//===========================================================================================
/*static XErr ExMungeIn (BlockRef text, long textLen, Boolean mungePeriods)
{
	XErr 		err = noErr;
	char 		*pEnd, *p, *q;
	Boolean 	needTerminatingCR = false;
	Ptr			textStartP = GetPtr(text);

	if (mungePeriods && textLen >= 3) {
		p = textStartP + textLen - 3;
		if (*p == '.' && *(p+1) == CR && *(p+2) == LF) textLen -= 3;
	}
	p = q = textStartP;
	pEnd = p + textLen;
	if (mungePeriods) {
		while (p < pEnd) {
			if (*p == '.' && *(p+1) == '.') {
				*q++ = '.';
				p += 2;
			}
			while (p < pEnd && (*p != CR || *(p+1) != LF)) *q++ = *p++;
			*q++ = CR;
			p += 2;
		}
	} else {
		while (p < pEnd) {
			if (*p == CR && *(p+1) == LF) {
				*q++ = CR;
				p += 2;
			} else {
				*q++ = *p++;
			}
		}
	}
	textLen = q - textStartP;
	if (textLen > 0 && *(q-1) != CR) {
		textLen++;
		needTerminatingCR = true;
	}
	err = SetBlockSize(text, textLen);
	// err = MySetHandleSize(text, textLen);
	if (err != noErr) return err;
	if (needTerminatingCR) *(GetPtr(text) + textLen - 1) = CR;
	return noErr;
}
*/


// ----------------------------------------------------------------------------
/*static OSErr MyNewPtr (unsigned long len, void *ptr)
{
XErr	err = noErr;

#if __MAC_XLIB__
	if NOT(*(Ptr*)ptr = NewPtrClear(len))
		err = MemError();
#elif __UNIX_XLIB__
	errno = 0;
	if NOT(*(Ptr*)ptr = calloc(1, len))
		err = errno;
#else
	if NOT(*(Ptr*)ptr = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, len))
		err = XWinGetLastError();
#endif
}*/

/*----------------------------------------------------------------------------
	NetInit 
	
	Initialize the net.c module. This function must be called before calling
	any other functions in the module.
	
	Entry:	giveTime = pointer to give time function.
			log = pointer to logging function, or nil if none.
			numBuffs = number of stream buffers to preallocate.
	
	Exit:	function result = error code.
	
	The give time function is called repeatedly during all network
	operations. It must be declared as follows:
	
		OSErr GiveTime (void)
	
	This function gives time to other processes/threads by calling WaitNextEvent/
	YieldTo[Any]Thread, and may check for user cancel operations (e.g., clicking
	a Cancel button or pressing Command-period or Escape). The function returns
	noErr to continue the operation, or any other error code to cancel (abort)
	the operation. Any error code returned by GiveTime is in turn returned as the 
	function result of the functions exported by net.c.
	
	The net.c module is reentrant with respect to the GiveTime function. That is,
	multiple threads of execution may make calls to the net.c module and use
	the YieldTo[Any]Thread call in the GiveTime function.
	
	The logging function is called once for each server command and response
	and stream open/close operation. It must be declared as follows:
	
		void Log (char logEntryType, unsigned long serverAddr, 
			unsigned short serverPort, unsigned short localPort, char *str)
		
	You can use this function to log all sever commands and responses. On
	entry to the Log function, the parameters are:
	
		logEntryType = 
			'C' if command.
			'R' if response.
			' ' if open/close operation.
		serverAddr = IP address of server.
		serverPort = port number on server.
		localPort = local port number.
		str = command or response string or open/close message string.
		
	The logging function is responsible for filtering out any passwords
	in the strings.
	
	You must call the InitMemUtil function in memutil.c to initialize the
	memory management utilities *before* calling NetInit.
----------------------------------------------------------------------------*/

XErr NetInit (NetGiveTimeFunction giveTime, NetLogFunction log, short numBuffs, Boolean initOpenTransport)
{
short 		i;
BlockRef 	s;
//long mtu;
TStreamPtr	sPtr;
XErr		err = noErr;

#ifdef __MAC_XLIB__
	gHaveOT = NetHaveOT();
#else
	gHaveOT = true;
#endif
	gGiveTime = giveTime;
	gLog = log;
	
	XThreadsEnterCriticalSection();
	if (gHaveOT)
	{
		if (initOpenTransport)
		{	
		#ifdef __MAC_XLIB__
			//err = InitOpenTransport();
		#endif
			if (err != noErr)
			{	err = netOpenDriverErr;
				goto out;
			}
		}
		gStreamBufSize = sizeof(TStream);
		
	} else {
	
		err = -1;
		goto out;
		/*gMacTCPDNRResultProcUPP = NewResultProc(MacTCPDNRResultProc);
		gMacTCPCloseStreamCompletionRoutineUPP = 
			NewTCPIOCompletionProc(MacTCPCloseStreamCompletionRoutine);
		err = OpenDriver("\p.IPP", &gRefNum);
		if (err != noErr) return netOpenDriverErr;
		mtu = GetMaxTCPMTU();
		gTCPBufSize = 8 * mtu;
		if (gTCPBufSize < kMinTCPBufSize) gTCPBufSize = kMinTCPBufSize;
		gStreamBufSize = sizeof(TStream) - 1 + gTCPBufSize;
		PatchExitToShell();*/
		
	}
	
	for (i = 0; i < numBuffs; i++) 
	{
		s = NewPtrBlock(gStreamBufSize, &err, (Ptr*)&sPtr);
		// err = MyNewPtr(gStreamBufSize, &s);
		if (err != noErr)
			goto out;
		//sPtr = (TStreamPtr)GetPtr(s);
		sPtr->nextFree = gFree;
		gFree = s;
	}
	
out:
XThreadsLeaveCriticalSection();
return err;
}



/*----------------------------------------------------------------------------
	NetIdle 
	
	Handle idle time tasks. You must call this function in your main 
	event loop.
	
	Exit:	function result = error code.
	
	This function takes care of releasing and deallocating streams which
	have finished closing asynchronously in the background.
----------------------------------------------------------------------------*/

XErr NetIdle (long userData)
{
BlockRef 	s, nextClose, prev = nil;
//XErr 		err = noErr;
TStreamPtr	sPtr;

	XThreadsEnterCriticalSection();
	for (s = gClose; s != nil; s = nextClose)
	{	sPtr = (TStreamPtr)GetPtr(s);
		nextClose = sPtr->nextClose;
		if (sPtr->release)
		{
			DoTCPRelease(s, userData);
			if (prev == nil)
			{
				gClose = nextClose;
			}
			else
			{
				((TStreamPtr)GetPtr(prev))->nextClose = nextClose;
			}
			DisposeStreamBuffer(s);
		}
		else
		{
			prev = s;
		}
	}
	XThreadsLeaveCriticalSection();
	return noErr;
}



/*----------------------------------------------------------------------------
	NetTerm 
	
	Terminate the module. You must call this function when you quit.
	
	Exit:	function result = error code.
	
	This functions waits until all asynchronous stream close operations have
	completed, or for 5 seconds, whichever happens first. If any close
	operations are still pending after 5 seconds, they are aborted.
	
	In addition, any other open streams are aborted.
----------------------------------------------------------------------------*/

XErr NetTerm (Boolean closeOpenTransport, long userData)
{
BlockRef	s;
long 		waitTil;

	XThreadsEnterCriticalSection();
	waitTil = XGetTicks() + 300;
	while (gClose != nil && XGetTicks() < (unsigned long)waitTil) {
		(*gGiveTime)();
		NetIdle(userData);
	}
	for (s = gAll; s != nil; s = ((TStreamPtr)GetPtr(s))->next)
		DoTCPRelease(s, userData);
	while (gFree != nil) {
		s = ((TStreamPtr)GetPtr(gFree))->nextFree;
		DisposeBlock(&gFree);
		gFree = s;
	}
	gFree = gClose = gAll = nil;
	if (gHaveOT && closeOpenTransport)
	{	
		#ifdef __MAC_XLIB__
			//CloseOpenTransport();
		#endif
	}
	XThreadsLeaveCriticalSection();
 	return noErr;
}



/*----------------------------------------------------------------------------
	NetOpen 
	
	Open a stream.
	
	Entry:	addr = IP address of server. Valerio: era uLong, ora string perch� su Unix vuole il nome del server
			port = port number of service.
			getHello = true to wait for, receive, and return an initial
				"hello" message.
	
	Exit:	function result = error code.
			*stream = opened stream reference.
			*responseCode = server hello message response code.
			response = C-format hello message string, including the
				response code.
				
	Hello message comment lines are discarded (response lines with a
	'-' immediately following the response code).
----------------------------------------------------------------------------*/

XErr NetOpen (NetAddress *addr, unsigned short port, Boolean getHello, NetStreamRef *stream, long *responseCode, CStr255 response, long userData, char *errmsg)
{
BlockRef		s;
TStreamPtr		sPtr;
XErr			err = noErr;
	
	*responseCode = 0;
	*response = 0;
	if (errmsg)
		CEquStr(errmsg, "NewStreamBuffer...");
	err = NewStreamBuffer(&s);
	if (err != noErr) return err;
	sPtr = (TStreamPtr)GetPtr(s);
	sPtr->in = sPtr->out = sPtr->buf;
	sPtr->serverAddr = *addr;
	sPtr->serverPort = port;
	*sPtr->command = *sPtr->response = (char)0;
	sPtr->responseCode = (char)0;
	if (gLog != nil)
		LogMessage(sPtr, 'N', "DoTCPCreate ...", userData);
	if (errmsg)
		CEquStr(errmsg, "DoTCPCreate...");
	err = DoTCPCreate(s);
	if (err != noErr) goto exit2;
	if (gLog != nil)
		LogMessage(sPtr, 'N', "DoTCPActiveOpen ...", userData);
	if (errmsg)
		CEquStr(errmsg, "DoTCPActiveOpen...");
	err = DoTCPActiveOpen(sPtr, addr, port, userData);
	if (err != noErr) goto exit1;
	if (getHello) 
	{
		if (gLog != nil)
			LogMessage(sPtr, 'N', "ReadResponse ...", userData);
		if (errmsg)
			CEquStr(errmsg, "ReadResponse...");
		err = ReadResponse(sPtr, responseCode, response, userData);
		if (err != noErr) goto exit1;

		if (gLog != nil)
			LogMessage(sPtr, 'R', response, userData);
	}
	*stream = (NetStreamRef)s;
	return noErr;
	
exit1:
	if (gHaveOT)
	{
		if (sPtr->otherSideHasClosed)
			err = netOpenStreamErr;
	}
	else
	{	/*if (err == connectionClosing || err == connectionDoesntExist || err == connectionTerminated)
			err = netOpenStreamErr;
		*/
	}
	DoTCPRelease(s, userData);

exit2:
	DisposeStreamBuffer(s);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetClose 
	
	Close a stream.
	
	Entry:	stream = stream reference.
	
	Exit:	function result = error code.
	
	A QUIT command is sent to the server before closing the stream. 
	Thus you do not need to and should not send this command yourself.
	
	To improve performance, all streams are closed asynchronously. 
	This function returns immediately without any delay.
	
	This asynchronous stream closing feature also permits you to close 
	connections in the background without interfering with or delaying user 
	actions in the foreground.
----------------------------------------------------------------------------*/

XErr NetClose (NetStreamRef stream, long userData)
{
TStreamPtr 	sPtr;
BlockRef 	s;
XErr		err = noErr;

	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	sPtr->closing = true;
	
	/* Link the stream into the queue of closing streams. */
	sPtr->nextClose = gClose;
	gClose = s;
	
	/* Send the QUIT command. */
	if (sPtr->weHaveClosed && sPtr->otherSideHasClosed)
	{	sPtr->release = true;
		return noErr;
	}
	else
	{	
	#ifdef __MAC_XLIB__
		err = OTSetBlocking(sPtr->ref);
		if (err != noErr) goto exit;
	#endif
		err = DoTCPSend(sPtr, "quit\r\n", 6);
		if (err != noErr) goto exit;
	#ifdef __MAC_XLIB__
		err = OTSetNonBlocking(sPtr->ref);
		if (err != noErr) goto exit;
	#endif
	}
	
	if (gLog != nil) {
		LogMessage(sPtr, 'C', "QUIT", userData);
		LogMessage(sPtr, ' ', "Asynch stream close initiated.", userData);
	}
	/*
	sPtr->release = true;:
	
	Added Valerio 22/5/2003
	if don't set sPtr->release the socket
	will not be closed and some mailserver
	can complain
	*/
	sPtr->release = true;
	
	return noErr;

exit:

	sPtr->release = true;
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetCommand 
	
	Send a command to a server and get the response.
	
	Entry:	stream = stream reference.
			command = C-format command string.
	
	Exit:	function result = error code.
			*responseCode = server response code.
			response = C-format server response string, including the 
				response code.
				
	Response comment lines are discarded (response lines with a
	'-' immediately following the response code).
----------------------------------------------------------------------------*/

XErr NetCommand (NetStreamRef stream, char *command, 
	long *responseCode, CStr255 response, long userData)
{
BlockRef 	s;
TStreamPtr	sPtr;
XErr 		err = noErr;

	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);

	if (gLog != nil)
		LogMessage(sPtr, 'N', command, userData);
	
	err = SendCommand(sPtr, command, userData);
	if (err != noErr) goto exit;
	err = ReadResponse(sPtr, responseCode, response, userData);
	if (err != noErr) goto exit;
	return noErr;
	
exit:

	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetGetExtraResponse 
	
	Get an extra command response from a server.
	
	Entry:	stream = stream reference.
	
	Exit:	function result = error code.
			*responseCode = server response code.
			response = C-format server response string, including the 
				response code.
				
	Response comment lines are discarded (response lines with a
	'-' immediately following the response code).
	
	Some servers have commands which return more than one response. The
	NetCommand function above reads the first response. This function is
	used to read the additional response(s). The FTP RETR and STOR commands
	are examples.
----------------------------------------------------------------------------*/

XErr NetGetExtraResponse (NetStreamRef stream, long *responseCode, 
	CStr255 response, long userData)
{
BlockRef 	s;
TStreamPtr	sPtr;
XErr 		err = noErr;

	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	err = ReadResponse(sPtr, responseCode, response, userData);
	if (err != noErr) goto exit;
	return noErr;
	
exit:

	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetBatchedCommands 
	
	Send multiple batched commands to a server and get and process
	the responses.
	
	Entry:	stream = stream reference.
			commands = handle to CR-terminated commands.
				Warning: the memory block is modified by the function.
				The memory block must be unlocked and nonpurgeable.
			doOneResponse = pointer to response processing function.
			userDataPtr = pointer to user data to be passed through
				to the doOneResponse function.
	
	Exit:	function result = error code.
	
	The response processing function must be declared as follows:

		void DoOneResponse (long responseCode, CStr255 response, Ptr userDataPtr)
	
	The function is called once for each command response. It is passed the 
	following parameters:
	
		responseCode = server response code.
		response = C-format server response string, including the
			response code.
		userDataPtr = user data pointer.
				
	Response comment lines are discarded (leading response lines with a
	'-' immediately following the response code).
	
	CR line terminators are mapped to CRLF line terminators before sending
	the batched commands.
	
	When you know in advance that you need to send a number of commands to a
	server all in a row, it is usually much more efficient to send them in
	a batch rather than sending them one at a time using the NetCommand function
	above. You should take care, however, since not all servers support batched 
	commands. 
	
	All of the batched commands must return only a single response (after
	skipping any possible comment lines).
----------------------------------------------------------------------------*/

XErr NetBatchedCommands (NetStreamRef stream, BlockRef *commandsP, NetDoOneResponse doOneResponse, Ptr userDataPtr, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;
char 			*p, *q, *r;
long 			cmdLen;
unsigned short	len;
long 			responseCode;
CStr255 		response;
short 			numCmds, i;
BlockRef		commands;

	//char state;
	
	//state = MyHGetState(commands);

	err = MungeOut(commandsP, false);
	if (err != noErr) goto exit;

	commands = *commandsP;
	cmdLen = GetBlockSize(commands, &err);
	if (err)
		return err;
	
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	LockBlock(commands);
	p = GetPtr(commands);
	while (cmdLen > 0)
	{
		len = (unsigned short)(cmdLen > 4000 ? 4000 : cmdLen);
		q = p + len - 1;
		while (q > p && (*q != LF || *(q-1) != CR)) q--;
		if (q == p) {
			p += len;
			cmdLen -= len;
			continue;
		} else {
			numCmds = 0;
			len = q - p + 1;
			while (q > p) {
				if (*q == LF && *(q-1) == CR) {
					numCmds++;
					q -= 2;
				} else {
					q--;
				}
			}
		}
		err = DoTCPSend(sPtr, p, len);
		if (err != noErr) goto exit;
		if (gLog != nil) {
			q = p;
			for (i = 0; i < numCmds; i++) {
				r = q;
				while (*r != CR || *(r+1) != LF) r++;
				*r = 0;
				LogMessage(sPtr, 'C', q, userData);
				q = r + 2;
			}
		}
		p += len;
		cmdLen -= len;
		while (numCmds--) {
			err = ReadResponse(sPtr, &responseCode, response, userData);
			if (err != noErr) goto exit;
			(*doOneResponse)(responseCode, response, userDataPtr);
		}
	}
	UnlockBlock(commands);
	// MyHSetState(commands, state);
	return noErr;
	
exit:

	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	UnlockBlock(commands);
	// MyHSetState(commands, state);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetPutText 
	
	Send command text to a server.
	
	Entry:	stream = stream reference.
			text = handle to CR-terminated ASCII text lines.
				Warning: the memory block is modified by the function.
				The memory block must be unlocked and nonpurgeable.
			munge = true to "munge" the text (see below).
	
	Exit:	function result = error code.
	
	If munge = true, the text is "munged" before being sent to the server:
	
		CR line terminators are translated to CRLF. A terminating "." on a line
		by itself is sent. The caller should not include this terminating line
		in the "text" block. Leading "." characters on lines are mapped to "..".
	
		If the text block does not have a terminating CR at the end of the last
		line, one is added.
		
	You should pass munge = false if you have previously called NetPutText once
	already with the same block of text. By specifying munge = false, you avoid
	munging the block twice.
----------------------------------------------------------------------------*/

XErr NetPutText (NetStreamRef stream, BlockRef *textP, Boolean munge, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;
char 			*p;
long			textLen;
unsigned short len;
//char state;
CStr255 		msg;
BlockRef		text;
	
	//state = MyHGetState(text);

	if (munge) {
		err = MungeOut(textP, true);
		if (err != noErr) goto exit;
	}
 	text = *textP;
 	textLen = GetBlockSize(text, &err);
	if (err)
		return err;
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);

	if (gLog != nil) {
		sprintf(msg, "Begin text block transmission of %ld bytes", textLen);
		LogMessage(sPtr, 'C', msg, userData);
	}
	LockBlock(text);
	p = GetPtr(text);
	while (textLen > 0)
	{
		len = (unsigned short)(textLen > 4000 ? 4000 : textLen);
		err = DoTCPSend(sPtr, p, len);
		if (err != noErr) goto exit;
		p += len;
		textLen -= len;
	}
	UnlockBlock(text);
	if (gLog != nil) LogMessage(sPtr, 'C', "End text block transmission", userData);
	return noErr;
	
exit:

	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	UnlockBlock(text);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetGetText
	
	Get response text from a server.
	
	Entry:	stream = stream reference.
			text = pointer to handle in which to return text,
				or nil if none.
			chunkFunction = pointer to chunk processing function, 
				or nil if none.
			userDataPtr = pointer to user data to be passed through
				to the chunk processing function, or nil if none.
	
	Exit:	function result = error code.
			*text = handle to received ASCII text lines, if text != nil.
			
	In the text returned via the "text" handle (if requested),
	CRLF line terminators are translated to CR. The server must send a 
	terminating "." on a line by itself. This terminating line is not 
	included in the "text" handle returned to the caller. Leading
	".." characters on lines are mapped to ".".
	
	The chunk processing function, if any, is called every time a new 
	block of text is received from the server. This function must be 
	declared as follows:
	
	OSErr ProcessTextChunk (Ptr t, long tLen, Ptr userDataPtr,
		long *truncPos)
	
	Entry:	t = pointer to raw text received from server.
			tLen = length of text received from server.
			userDataPtr = pointer to user data.
			
	Exit:	function result = error code.
			*truncPos = position at which to truncate text if
				error code is netTruncatedErr.
	
	If text == nil, the text is processed by the chunk processing function
	in pieces (e.g., saved to a file as it comes in over the network). In 
	this case, the text is not accumulated and returned as a whole to the
	NetGetText caller, and the "t" and "tLen" parameters passed to the
	chunk processing function are for just the chunk received.
	
	If text != nil, the text is accumulated as it is received and returned
	as a whole to the NetGetText caller, and the "t" and "tLen" parameters
	passed to the chunk processing function (if any) are for the entire text
	as accumulated so far.
				
	If the chunk processing function returns with an error code, NetGetText 
	aborts the stream and returns to the caller immediately with the text handle
	set to just the text received so far. The error code returned by the
	chunk processing function is returned to the NetGetText caller as NetGetText's
	function result.
	
	If the chunk processing function returns netTruncatedErr, and if text != nil,
	the returned text is truncated to "truncPos" bytes, as specified by the
	chunk processing function, and NetGetText returns the error code netTruncatedErr
	to its caller.
	
	The text passed to the chunk processing function is raw. It contains CRLF 
	line terminators and doubled leading ".." characters. The terminating "."
	on a line by itself, however, is not passed to the chunk processing function.
----------------------------------------------------------------------------*/

XErr NetGetText (NetStreamRef stream, BlockRef *text, NetChunkFunction chunkFunction, Ptr userDataPtr, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;
XErr 			chunkErr = noErr;
BlockRef 		t = nil;
long 			tLen = 0;
long 			tAllocated = 0;
unsigned short	len;
char 			*tEnd;
long 			truncPos;
Ptr				tPtr, tempP;

	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	tLen = sPtr->in - sPtr->out;
	tAllocated = tLen + 4005;
	t = NewBlock(tAllocated, &err, &tPtr);
	if (err != noErr) goto exit;
	if (tLen > 0)
	{	CopyBlock(tPtr, sPtr->out, tLen);
		// BlockMoveData(sPtr->out, GetPtr(t), tLen);
	}
	sPtr->in = sPtr->out = sPtr->buf;
	
	while (true)
	{
		if (tLen >= 3) {
			tEnd = GetPtr(t) + tLen;
			if (*(tEnd-3) == '.' && *(tEnd-2) == CR && *(tEnd-1) == LF) {
				if (tLen == 3) break;
				if (tLen >= 5 && *(tEnd-5) == CR && *(tEnd-4) == LF) break;
			}
		}
		len = 4000;
		LockBlock(t);
		err = DoTCPRcv(sPtr, GetPtr(t) + tLen, &len);
		if (err != noErr) goto exit;
		UnlockBlock(t);
		tLen += len;
		if (chunkFunction != nil && tLen > 5) {
			LockBlock(t);
			chunkErr = (*chunkFunction)(GetPtr(t), tLen - 5, userDataPtr, &truncPos);
			UnlockBlock(t);
			if (chunkErr != noErr) goto exit2;
			if (text == nil)
			{	tempP = GetPtr(t);
				// ex BlockMoveData(tempP + tLen - 5, tempP, 5);
				CopyBlock(tempP, tempP + tLen - 5, 5);
				tLen = 5;
			}
		}
		if (text != nil && tAllocated - tLen <= 4000) {
			tAllocated += 4000;
			err = SetBlockSize(t, tAllocated);
			if (err != noErr) goto exit;
		}
	}
	
	if (chunkFunction != nil && tLen > 3) {
		LockBlock(t);
		chunkErr = (*chunkFunction)(GetPtr(t), tLen-3, userDataPtr, &truncPos);
		UnlockBlock(t);
		if (chunkErr != noErr) goto exit2;
	}
	
	if (text == nil) {
		DisposeBlock(&t);
	} else {
		err = MungeIn(&t, tLen, true);
		if (err != noErr) goto exit;
		*text = t;
	}

	return noErr;
	
exit:

	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	DisposeBlock(&t);
	return TranslateErrorCode(err);
	
exit2:

	if (text == nil) {
		DisposeBlock(&t);
	} else {
		if (chunkErr == netTruncatedErr) tLen = truncPos;
		err = MungeIn(&t, tLen, true);
		if (err != noErr) goto exit;
		*text = t;
	}
	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	return chunkErr;
}



#ifdef __MAC_XLIB__
#if __MWERKS__
#pragma mark-
#endif

// Da fare ancora il porting su Win e Linux dell'ftp
/*----------------------------------------------------------------------------
	NetFTPDataPassiveOpen 
	
	Open an FTP passive data stream.
	
	Exit:	function result = error code.
			*port = assigned unused local port number.
			*stream = reference to opened FTP data stream.
	
	This function returns immediately. It should be followed by a call to
	NetFTPDataWaitForConnection to wait for the FTP server to open its end of 
	the data stream connection.
	
	It's confusing, but this "passive" stream open function is used for
	*active* FTP mode data transfers (the client opens a passive stream
	and waits for the server to connect). For *passive* FTP mode data
	transfers (the server opens a passive stream and waits for the client
	to connect), the regular "active" stream open function NetOpen must
	be used instead.
----------------------------------------------------------------------------*/

XErr NetFTPDataPassiveOpen (unsigned short *port, NetStreamRef *stream, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;

	err = NewStreamBuffer(&s);
	if (err != noErr) goto exit2;
	sPtr = (TStreamPtr)GetPtr(s);
	sPtr->in = sPtr->out = sPtr->buf;
	err = DoTCPCreate(s);
	if (err != noErr) goto exit2;
	err = DoTCPPassiveOpen(sPtr, port);
	if (err != noErr) goto exit1;
	*stream = (NetStreamRef)s;
	return noErr;
	
exit1:

	DoTCPRelease(s, userData);
	
exit2:
	
	DisposeStreamBuffer(s);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetFTPDataClose
	
	Close an FTP data stream.
	
	Entry:	stream = FTP data stream reference.
	
	Exit:	function result = error code.
	
	This function is used to close all FTP data streams, including "passive
	mode" data streams and "active mode" data streams.
----------------------------------------------------------------------------*/

XErr NetFTPDataClose (NetStreamRef stream, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;
	
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	
	/* Special case a passive data stream which is still waiting for
	   a connection. In this case, we abort the stream. */
	   
	if (sPtr->passiveOpenInProgress) {
		DoTCPRelease(s, userData);
		DisposeStreamBuffer(s);
		return noErr;
	}
	
	sPtr->closing = true;
 	
	/* Link the stream into the queue of closing streams. */
	XThreadsEnterCriticalSection();
	sPtr->nextClose = gClose;
	gClose = s;
	XThreadsLeaveCriticalSection();
	
	/* Close our end of the stream. */
	
	if (gHaveOT) {
	
		if (!sPtr->weHaveClosed) {
			err = OTSndOrderlyDisconnect(sPtr->ref);
			if (err != noErr) goto exit;
			sPtr->weHaveClosed = true;
		} else if (sPtr->weHaveClosed && sPtr->otherSideHasClosed) {
			sPtr->release = true;
		}
		return noErr;
	
	} else {
		
		/* Start an asynchronous close operation, chained to our 
		   completion routine. */
	/*
		InitMacTCPParamBlock(&s->pBlock, TCPClose);
		s->pBlock.ioCompletion = gMacTCPCloseStreamCompletionRoutineUPP;
		s->pBlock.tcpStream = s->tcpStream;
		err = PBControlAsync((ParmBlkPtr)&s->pBlock);
		if (err != noErr) goto exit;
		if (gLog != nil) LogMessage(s, ' ', "Asynch stream close initiated.");
		return noErr;
	*/
	}
	
exit:
	
	sPtr->release = true;
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetFTPDataWaitForConnection 
	
	Wait for an FTP server to open its end of a passive data stream.
	
	Entry:	stream = FTP data stream reference.
	
	Exit:	function result = error code.
	
	It's confusing, but this "passive" stream wait function is used for
	*active* FTP mode data transfers (the client opens a passive stream
	and waits for the server to connect). For *passive* FTP mode data
	transfers (the server opens a passive stream and waits for the client
	to connect), the regular "active" stream open function NetOpen must
	be used instead, and this function is not used.
----------------------------------------------------------------------------*/

XErr NetFTPDataWaitForConnection (NetStreamRef stream, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;
InetAddress 	*inetAddr;
	
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);	
	if (gHaveOT) {
	
		while (true) {
			err = (*gGiveTime)();
			if (err != noErr) goto exit;
			err = OTListen(sPtr->ref, sPtr->call);
			if (err == noErr) break;
			if (err != kOTNoDataErr) goto exit;
		}
		inetAddr = (InetAddress*)sPtr->call->addr.buf;
		sPtr->serverAddr = inetAddr->fHost;
		sPtr->serverPort = inetAddr->fPort;
		sPtr->complete = false;
		err = OTAccept(sPtr->ref, sPtr->ref, sPtr->call);
		if (err != noErr) goto exit;
		err = MyOTStreamWait(sPtr, true);
		if (err != noErr) goto exit;
	
	} else {
	
		/*while (s->pBlock.ioResult > 0) {
			err = (*gGiveTime)();
			if (err != noErr) goto exit;
		}
		err = s->pBlock.ioResult;
		if (err != noErr) goto exit;
		s->serverAddr = s->pBlock.csParam.open.remoteHost;
		s->serverPort = s->pBlock.csParam.open.remotePort;
		*/
	}
	
	sPtr->passiveOpenInProgress = false;
	if (gLog != nil) LogMessage(sPtr, ' ', "Stream opened.", userData);
	return noErr;
		
exit:

	if (gHaveOT) {
		if (sPtr->otherSideHasClosed)
			err = netOpenStreamErr;
	}
	else
	{
		/*if (err == connectionClosing || err == connectionDoesntExist ||
			err == connectionTerminated) err = netOpenStreamErr;
		*/
	}
	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetGetFTPData 
	
	Get data from an FTP server.
	
	Entry:	stream = FTP data stream reference.
			mapCR = true to map CRLF line terminators to CR.
	
	Exit:	function result = error code.
			*data = handle to received data.
			
----------------------------------------------------------------------------*/

XErr NetGetFTPData (NetStreamRef stream, Boolean mapCR, BlockRef *data, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;
BlockRef		d = nil;
long 			dLen = 0;
long 			dAllocated = 4000;
long 			numFree;
unsigned short 	len;
	
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	d = NewBlock(dAllocated, &err, nil);
	if (err != noErr) goto exit;
	
	while (true) {
		numFree = dAllocated - dLen;
		if (numFree <= 4000) {
			dAllocated += 4000;
			err = SetBlockSize(d, dAllocated);
			if (err != noErr) goto exit;
		}
		len = 4000;
		LockBlock(d);
		err = DoTCPRcv(sPtr, GetPtr(d) + dLen, &len);
		UnlockBlock(d);
		if (err == netLostConnectionErr) break;
		if (err != noErr) goto exit;
		dLen += len; 
	}
	
	if (mapCR) {
		err = MungeIn(&d, dLen, false);
		if (err != noErr) goto exit;
	} else {
		SetBlockSize(d, dLen);
	}
	
	*data = d;
	return noErr;
	
exit:

	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	DisposeBlock(&d);
	return TranslateErrorCode(err);
}



/*----------------------------------------------------------------------------
	NetPutFTPData 
	
	Send data to an FTP server.
	
	Entry:	stream = FTP data stream reference.
			mapCR = true to map CR line terminators to CRLF.
			data = handle to data.
	
	Exit:	function result = error code.

	Warning: If mapCR = true, the data block is modified by the function,
	and it must be unlocked and nonpurgeable.
----------------------------------------------------------------------------*/

XErr NetPutFTPData (NetStreamRef stream, Boolean mapCR, BlockRef *dataP, long userData)
{
BlockRef 		s;
TStreamPtr		sPtr;
XErr 			err = noErr;
char 			*p;
long 			dataLen;
unsigned short 	len;
//char 			state;
BlockRef		data;
	
	// state = MyHGetState(data);

	if (mapCR) {
		err = MungeOut(dataP, false);
		if (err != noErr) goto exit;
	}
	data = *dataP;
	dataLen = GetBlockSize(data, &err);
	if (err)
		return err;
	
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);

	LockBlock(data);
	p = GetPtr(data);
	while (dataLen > 0) {
		len = dataLen > 4000 ? 4000 : dataLen;
		err = DoTCPSend(sPtr, p, len);
		if (err != noErr) goto exit;
		p += len;
		dataLen -= len;
	}
	UnlockBlock(data);
	return noErr;
	
exit:

	DoTCPRelease(s, userData);
	DisposeStreamBuffer(s);
	UnlockBlock(data);
	return TranslateErrorCode(err);
}
#if __MWERKS__
#pragma mark-
#endif

#endif


#if __UNIX_XLIB__
	#include <sys/types.h>
	#include <netinet/in.h>
	#include <arpa/nameser.h>
	#include <resolv.h>

	#include <signal.h>
	#include <unistd.h>
	#include <stdio.h>
	//#include <resolv.h>
	#include <sys/socket.h>
	#include <sys/socketvar.h>
	//#include <sys/types.h>
	#include <sys/file.h>
	#include <sys/un.h>
	#include <netdb.h>
	#include <pthread.h>
	//#include <netinet/in.h>
#elif __WIN_XLIB__
	#include <signal.h>
	//#include <unistd.h>
	#include <stdio.h>
#endif

//----------------------------------------------------------------------------
void NetAddressToString (NetAddress *address, CStr255 name)
{
Ptr				addrP;
Byte			b1, b2, b3, b4;
CStr15			tStr;

	#ifdef __MAC_XLIB__
		addrP = (Ptr)&address;
	#else
		struct sockaddr_in 	saddr;

		memcpy(&saddr.sin_addr, address->h_addr_list0, address->h_length);
		addrP = (Ptr)&saddr.sin_addr;
	#endif
	
	b1 = *(Byte*)addrP++;
	b2 = *(Byte*)addrP++;
	b3 = *(Byte*)addrP++;
	b4 = *(Byte*)addrP;
	
	CNumToString(b1, name);
	
	CAddChar(name, '.');
	CNumToString(b2, tStr);
	CAddStr(name, tStr);

	CAddChar(name, '.');
	CNumToString(b3, tStr);
	CAddStr(name, tStr);

	CAddChar(name, '.');
	CNumToString(b4, tStr);
	CAddStr(name, tStr);
}

/*----------------------------------------------------------------------------
	NetGetServerErrInfo 
	
	Get server error information for a stream.
	
	Entry:	stream = stream reference.
	
	Exit:	*serverErrInfo = server error informaton.
----------------------------------------------------------------------------*/

void NetGetServerErrInfo (NetStreamRef stream, NetServerErrInfo *serverErrInfo)
{
TStreamPtr 	sPtr;
BlockRef 	s;
	
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	strcpy(serverErrInfo->command, sPtr->command);
	strcpy(serverErrInfo->response, sPtr->response);
	serverErrInfo->responseCode = sPtr->responseCode;
}



/*----------------------------------------------------------------------------
	NetGetStreamStats 
	
	Get stream stats (bytes in/out).
	
	Entry:	stream = stream reference.
	
	Exit:	*bytesIn = number of bytes received on stream.
			*bytesOut = number of bytes sent on stream.
----------------------------------------------------------------------------*/

void NetGetStreamStats (NetStreamRef stream, long *bytesIn, long *bytesOut)
{
TStreamPtr 	sPtr;
BlockRef 	s;
	
	s = (BlockRef)stream;
	sPtr = (TStreamPtr)GetPtr(s);
	*bytesIn = sPtr->bytesIn;
	*bytesOut = sPtr->bytesOut;
}



/*----------------------------------------------------------------------------
	NetGetNumOpenStreams 
	
	Get the number of open streams.
	
	Exit:	function result = number of open streams.
----------------------------------------------------------------------------*/

short NetGetNumOpenStreams (void)
{
short 		n;
BlockRef 	s;
	
	XThreadsEnterCriticalSection();
	for (s = gAll, n = 0; s != nil; s = ((TStreamPtr)GetPtr(s))->next) n++;
	XThreadsLeaveCriticalSection();
	return n;
}
