/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: bifernoMainClass.c,v 1.7 2003-06-26 17:02:38 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"BfrHeader.h"

// defines
#define	gsPlugName	"biferno"

// Methods
/*
enum{
		kFlush = 1,
		kReload
	};
#define TOT_METHODES	2
*/

// Properties
#define TOT_PROPRIETIES	11
enum{
		kOS,
		kVersion,
		kVersionNum,
		kHome,
		kCompFlags,
		kMaxUsers,
		kpoolFactor,
		kUpSince,
		kApplications,
		kClasses,
		kFunctions
	};

static 	long	gsApiVersion, 	bifernoClassID;

//===========================================================================================
static XErr	_BifernoRegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	bifernoProperty[TOT_PROPRIETIES] = 
					{	"os",				kOS,				"static string",
						"version",			kVersion,			"static string",
						"versionNum",		kVersionNum,		"static unsigned",
						"home",				kHome,				"static string",
						"compilationFlags",	kCompFlags,			"static string",
						"maxUsers",			kMaxUsers,			"static int",
						"poolFactor",		kpoolFactor,		"static int",
						"upSince",			kUpSince,			"static time",
						"applications[]",	kApplications,		"static string",
						"classes[]",		kClasses,			"static string",
						"functions[]",		kFunctions,			"static string"
					};
					
/*
BAPI_MemberRecord	bifernoMethods[TOT_METHODES] = 
					{	"Flush",			kFlush, 		"static void Flush(void)",
						"Reload",			kReload, 		"static void Reload(void)"
					};
*/

	if (err = BAPI_NewProperties(api_data, bifernoClassID, bifernoProperty, TOT_PROPRIETIES, nil))
		return err;		

	//if (err = BAPI_NewMethods(api_data, bifernoClassID, bifernoMethods, TOT_METHODES, nil))
	//	return err;

//out:
return err;
}

//===========================================================================================
static XErr	_GetCompilFlags(long api_data, ObjRefP result)
{
char		compileFlagsStr[1024];
CStr255		aCStr;
XErr		err = noErr;

	if NOT(err = BAPI_Platform(api_data, aCStr, compileFlagsStr, 1024))
		err = BAPI_StringToObj(api_data, compileFlagsStr, CLen(compileFlagsStr), result);

return err;
}

//===========================================================================================
static XErr	_GetArray(long api_data, GetPropertyRec *getPropertyRecP, long which)
{
XErr			err = noErr;
ArrayIndexRec	mCoord;
ObjRef			tObjRef, *resultP = &getPropertyRecP->resultObjRef;
long			i, tots;
BlockRef		blockRef;
BAPI_Name		*nameRecP;

	if (getPropertyRecP->propertyIndex)
		mCoord = getPropertyRecP->propertyIndex[0];
	else
		ClearBlock(&mCoord, sizeof(ArrayIndexRec));
	if (*mCoord.ind_name)
		err = XError(kBAPI_Error, Err_ArrayElementNotFound);
	else
	{	switch(which)
		{	case kApplications:
				err = BAPI_GetApplications(api_data, &blockRef, &tots, mCoord.ind);
				break;
			case kClasses:
				err = BAPI_GetClasses(api_data, nil, &blockRef, &tots, mCoord.ind);
				break;
			case kFunctions:
				err = BAPI_GetMembers(api_data, nil, "function", kFunction, &blockRef, &tots, mCoord.ind);
				break;
		}
		if NOT(err)
		{	if (blockRef)
				nameRecP = (BAPI_Name*)GetPtr(blockRef);
			if (mCoord.ind)
				err = BAPI_StringToObj(api_data, nameRecP->name, CLen(nameRecP->name), resultP);
			else
			{	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, resultP))
				{	if (blockRef)
					{	LockBlock(blockRef);
						for (i = 0; (i < tots) && NOT(err); i++, nameRecP++)
						{	BAPI_InvalObjRef(api_data, &tObjRef);
							if NOT(err = BAPI_StringToObj(api_data, nameRecP->name, CLen(nameRecP->name), &tObjRef))
								err = BAPI_ArrayAddElement(api_data, resultP, nil, &tObjRef);
						}
					}
				}
			}
			if (blockRef)
				DisposeBlock(&blockRef);
		}
	}
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	biferno_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	bifernoClassID = pbPtr->param.registerRec.pluginID;
	
return err;
}

//===========================================================================================
static XErr	biferno_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _BifernoRegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	biferno_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;

	switch(exeMethodRecP->methodID)
	{
		/*case kFlush:
			err = BAPI_Flush(api_data);
			break;
		
		case kReload:
			err = BAPI_Reload(api_data);
			break;*/

		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
	
return err;
}

//===========================================================================================
static XErr	biferno_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			api_data = pbPtr->api_data, aLong;
CStr255			aCStr;
unsigned long	uLong;

	switch(getPropertyRec->propertyID)
	{
		case kOS:
			if NOT(err = BAPI_Platform(api_data, aCStr, nil, 0))
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRec->resultObjRef);
			break;
		case kVersion:
			if NOT(err = BAPI_GetVersions(api_data, aCStr, nil, nil))
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRec->resultObjRef);
			break;
		case kVersionNum:
			if NOT(err = BAPI_GetNumVersions(api_data, &uLong, nil, nil))
				err = BAPI_UnsignedToObj(api_data, uLong, &getPropertyRec->resultObjRef);
			break;
		case kHome:
			if NOT(err = BAPI_GetBifernoHome(api_data, aCStr))
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRec->resultObjRef);
			break;
		case kCompFlags:
			err = _GetCompilFlags(api_data, &getPropertyRec->resultObjRef);
			break;
		case kMaxUsers:
			if NOT(err = BAPI_GetMaxUsers(api_data, &aLong))
				err = BAPI_IntToObj(api_data, aLong, &getPropertyRec->resultObjRef);
			break;
		case kpoolFactor:
			if NOT(err = BAPI_GetPoolFactor(api_data, &aLong))
				err = BAPI_IntToObj(api_data, aLong, &getPropertyRec->resultObjRef);
			break;
		case kUpSince:
			err = BAPI_GetServerUpSince(api_data, &getPropertyRec->resultObjRef);
			break;
		case kApplications:
			err = _GetArray(api_data, getPropertyRec, kApplications);
			break;
		case kClasses:
			err = _GetArray(api_data, getPropertyRec, kClasses);
			break;
		case kFunctions:
			err = _GetArray(api_data, getPropertyRec, kFunctions);
			break;
		default:
			break;
	}

return err;
}

//===========================================================================================
static XErr	biferno_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	switch(setPropertyRec->propertyID)
	{
		case kOS:
		case kVersion:
		case kVersionNum:
		case kHome:
		case kCompFlags:
		case kMaxUsers:
		case kpoolFactor:
		case kUpSince:
		case kApplications:
		case kClasses:
		case kFunctions:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif
//===========================================================================================
XErr	biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = biferno_Register(pbPtr);
			break;
		case kInit:
			err = biferno_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = biferno_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = biferno_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = biferno_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


