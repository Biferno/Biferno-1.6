/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Multipart.c,v 1.12 2005-08-30 13:45:59 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"Multipart.h"

#include <stdio.h>
#include <string.h>

typedef struct MultipartRec
{
	CStr255		path;
	CStr255		name;
	CStr255		contentType;
	BlockRef	data;
	long		dataLen;
} MultipartRec;

// Methods
enum{
		kToFile = 1
	};
#define TOT_METHODES	1

// Properties
#define TOT_PROPRIETIES	4
enum{
		kData = 1,
		kName,
		kPath,
		kContentType
	};

// defines
#define	gsPlugName	"multipart"

static 	long		multipartClassID;
static 	long		gsApiVersion;

//===========================================================================================
static void	_NewNameForPath(char *path, char *fileName)
{
char	*strP, *strP2;

	if (strP = strrchr(path, '\\'))
	{	if (strP2 = strrchr(strP, '/'))
			strP = strP2;
	}
	else
		strP = strrchr(path, '/');
	if (strP)
		CEquStr(strP+1, fileName);
}

//===========================================================================================
static void	_PathToName(char *fileName)
{
char	*strP, *strP2;

	if (strP = strrchr(fileName, '\\'))
	{	if (strP2 = strrchr(strP, '/'))
			strP = strP2;
	}
	else
		strP = strrchr(fileName, '/');
	if (strP)
		CEquStr(fileName, strP+1);
}

//===========================================================================================
static XErr	_ToFile(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, MultipartRec *mPartRecP)
{
XErr		err = noErr, err2 = noErr;
long		filePathLen, toWrite, api_data = pbPtr->api_data;
CStr255		filePath, fileName;
XFileRef	fileRef;
Boolean		isFolder, overwrite;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, filePath, &filePathLen, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &overwrite, kImplicitTypeCast))
		{	err = BAPI_RealPath(api_data, filePath, false);
			if (err == XError(kXLibError, ErrXFiles_FileNotFound))
			{	err = noErr;
				isFolder = false;
			}
			else
				err = XIsFolder(filePath, &isFolder);
			if NOT(err)
			{	if (isFolder)
				{	CEquStr(fileName, mPartRecP->path);
					_PathToName(fileName);
					if (filePath[CLen(filePath)-1] != '/')
						CAddChar(filePath, '/');
					CAddStr(filePath, fileName);
				}
				if NOT(err)	
				{	
				long	openMode;
				
					if (overwrite)
						openMode = CREATE_FILE_ALWAYS;
					else
						openMode = CREATE_FILE_NEW;
					if NOT(err = OpenXFile(filePath, (short)openMode, READ_WRITE_PERM, false, &fileRef))
					{	toWrite = mPartRecP->dataLen;
						err = WriteXFile(fileRef, GetPtr(mPartRecP->data), &toWrite);
						err2 = CloseXFile(&fileRef);
						if (err2 && NOT(err))
							err = err2;
					}
				}
			}
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	multiPart_NewObject(long api_data, char *textP, long textLen, char *filePath, char *contentType, ObjRef *result)
{
XErr			err = noErr;
MultipartRec	mPartRec;
long			plugin_run_data;
Ptr				dataP;

	ClearBlock(&mPartRec, sizeof(MultipartRec));
	if (textLen)
	{	if (mPartRec.data = NewBlock(textLen, &err, &dataP))
		{	CopyBlock(dataP, textP, textLen);
			mPartRec.dataLen = textLen;
		}
	}
	else
	{	if (mPartRec.data = NewBlock(1, &err, nil))
			mPartRec.dataLen = 0;
	}
	if NOT(err)
	{	CEquStr(mPartRec.path, filePath);
		CEquStr(mPartRec.contentType, contentType);
		if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&mPartRec, sizeof(MultipartRec), multipartClassID, true, nil, result))
		{	if NOT(err = BAPI_GetPluginRunData(api_data, multipartClassID, &plugin_run_data))
			{	plugin_run_data++;
				err = BAPI_SetPluginRunData(api_data, multipartClassID, plugin_run_data);
			}
		}
		if (err)
			DisposeBlock(&mPartRec.data);
	}
		
return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	stringProperty[TOT_PROPRIETIES] = 
					{	"data", 		kData,			"string",
						"name", 		kName,			"string",
						"path", 		kPath,			"string",
						"contentType", 	kContentType,	"string"
					};
BAPI_MemberRecord		stringMethods[TOT_METHODES] = 
					{	"ToFile",		kToFile, 		"void ToFile(string path, boolean overwrite)"
					};


	if (err = BAPI_NewProperties(api_data, multipartClassID, stringProperty, TOT_PROPRIETIES, nil))
		return err;		

	if (err = BAPI_NewMethods(api_data, multipartClassID, stringMethods, TOT_METHODES, nil))
		return err;

//out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	MultiPart_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec		*initRecP = &pbPtr->param.initRec.newClassRec;
XErr			err = noErr;

	err = _RegisterListMembers(pbPtr->api_data);
	
return err;
}

//===========================================================================================
static XErr	MultiPart_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	multipartClassID = 0;
	
return noErr;
}

//===========================================================================================
static XErr	MultiPart_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
MultipartRec	mPartRec;
long			objLen;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(MultipartRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&mPartRec, &objLen, 0, nil))
		{	if (objLen)
			{	DisposeBlock(&mPartRec.data);
				(*pbPtr->plugin_run_dataP)--;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr	MultiPart_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			stringLen;
long			tLen, oldDataLen, api_data = pbPtr->api_data;
CStr255			aCStr;
Ptr				stringP, newMPartRecDataPtr;
MultipartRec	mPartRec;
BlockRef		ref;

	if (clone/* && (constructorRecP->varRecsP->objRef.classID == multipartClassID)*/)
	{	//err = XError(kBAPI_Error, Err_IllegalOperation);
		//CEquStr(pbPtr->error, "Can't clone multipart object");
		MultipartRec newMPartRec;
	
		tLen = sizeof(MultipartRec);
		if NOT(err = BAPI_GetObj(api_data, &constructorRecP->varRecsP->objRef, (Ptr)&mPartRec, &tLen, 0, nil))
		{	oldDataLen = mPartRec.dataLen;
			newMPartRec = mPartRec;
			if (oldDataLen)
			{	if (newMPartRec.data = NewBlock(oldDataLen, &err, &newMPartRecDataPtr))
					CopyBlock(newMPartRecDataPtr, GetPtr(mPartRec.data), oldDataLen);
			}
			else
				newMPartRec.data = NewBlock(1, &err, nil);
			if NOT(err)
			{	if (err = BAPI_BufferToObj(api_data, (Ptr)&newMPartRec, sizeof(MultipartRec), multipartClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
					DisposeBlock(&newMPartRec.data);
			}
			if NOT(err)	
				(*pbPtr->plugin_run_dataP)++;
		}
	}
	else
	{	if ((constructorRecP->totVars >= 1) && (constructorRecP->totVars <= 3))
		{	ClearBlock(&mPartRec, sizeof(MultipartRec));
			if NOT(err = BAPI_GetStringBlock(api_data, &constructorRecP->varRecsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
			{	Ptr		dataP;
			
				if (stringLen)
				{	if (mPartRec.data = NewBlock(stringLen, &err, &dataP))
					{	CopyBlock(dataP, stringP, stringLen);
						mPartRec.dataLen = stringLen;
					}
				}
				else
				{	if (mPartRec.data = NewBlock(1, &err, nil))
						mPartRec.dataLen = 0;
				}
				// ex if (mPartRec.data = NewBlock(stringLen, &err, &dataP))
				if NOT(err)
				{	//CopyBlock(dataP, stringP, stringLen);
					if (constructorRecP->totVars >= 2)
					{	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[1].objRef, mPartRec.path, nil, 255, kImplicitTypeCast))
						{	if (constructorRecP->totVars >= 3)
								err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[2].objRef, mPartRec.contentType, nil, 255, kImplicitTypeCast);
						}
					}
					if NOT(err)
						err = BAPI_BufferToObj(api_data, (Ptr)&mPartRec, sizeof(MultipartRec), multipartClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
					if NOT(err)
						(*pbPtr->plugin_run_dataP)++;
					else
						DisposeBlock(&mPartRec.data);
				}
				BAPI_ReleaseBlock(&ref);
			}
		}
		else
		{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
			CEquStr(pbPtr->error, "multipart(string data, [string path], [string, contentType])");
		}
	}
	
	//if NOT(err)
		//BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, multipartClassID);
		//constructorRecP->resultObjRef.classID = multipartClassID;
		
return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	MultiPart_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
//long				totParams = exeMethodRecP->totParams;
long				tLen;
MultipartRec		mPartRec;
Boolean				needSer;

	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
		err = BAPI_NeedSerialize(api_data, &exeMethodRecP->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(MultipartRec);
		if NOT(err = BAPI_ReadObj(api_data, &exeMethodRecP->objRef, (Ptr)&mPartRec, &tLen, 0, nil))
		{	switch(exeMethodRecP->methodID)
			{
				case kToFile:
					err = _ToFile(pbPtr, exeMethodRecP, &mPartRec);
					break;
				
				default:
					err = XError(kBAPI_Error, Err_NoSuchMethod);
					break;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	MultiPart_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
MultipartRec	mPartRec;
long			tLen, api_data = pbPtr->api_data;
CStr255			name;
BlockRef		data;
Boolean			needSer;

	if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
		err = BAPI_NeedSerialize(api_data, &getPropertyRec->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(MultipartRec);
		if NOT(err = BAPI_ReadObj(api_data, &getPropertyRec->objRef, (Ptr)&mPartRec, &tLen, 0, nil))
		{	switch(getPropertyRec->propertyID)
			{
				case kData:
					data = mPartRec.data;
					LockBlock(data);
					err = BAPI_StringToObj(api_data, GetPtr(data), mPartRec.dataLen, &getPropertyRec->resultObjRef);
					UnlockBlock(data);
					break;
				case kName:
					CEquStr(name, mPartRec.path);
					_PathToName(name);
					err = BAPI_StringToObj(api_data, name, CLen(name), &getPropertyRec->resultObjRef);
					break;
				case kPath:
					err = BAPI_StringToObj(api_data, mPartRec.path, CLen(mPartRec.path), &getPropertyRec->resultObjRef);
					break;
				case kContentType:
					err = BAPI_StringToObj(api_data, mPartRec.contentType, CLen(mPartRec.contentType), &getPropertyRec->resultObjRef);
					break;
				
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	MultiPart_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
MultipartRec		mPartRec;
long				stringLen, tLen, api_data = pbPtr->api_data;
CStr255				aCStr;
char				*stringP;
BlockRef			ref;
Boolean				needSer;

	if (BAPI_IsObjRefValid(api_data, &setPropertyRecP->objRef))
		err = BAPI_NeedSerialize(api_data, &setPropertyRecP->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(MultipartRec);
		if NOT(err = BAPI_ReadObj(api_data, &setPropertyRecP->objRef, (Ptr)&mPartRec, &tLen, 0, nil))
		{	switch(setPropertyRecP->propertyID)
			{
				case kData:
					if NOT(err = BAPI_GetStringBlock(api_data, &setPropertyRecP->value, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
					{	if (ref)
						{	DisposeBlock(&mPartRec.data);
							mPartRec.data = ref;
							err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&mPartRec, sizeof(MultipartRec));
						}
						else
						{	if NOT(err = SetBlockSize(mPartRec.data, stringLen))
							{	CopyBlock(GetPtr(mPartRec.data), stringP, stringLen);
								mPartRec.dataLen = stringLen;
								err = BAPI_WriteObj(api_data, &setPropertyRecP->objRef, (Ptr)&mPartRec, sizeof(MultipartRec), 1);
							}
						}
					}
					break;
				case kName:
					if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aCStr, nil, 255, kImplicitTypeCast))
					{	_NewNameForPath(mPartRec.path, aCStr);
						err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&mPartRec, sizeof(MultipartRec));
					}
					break;
				case kPath:
					if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aCStr, nil, 255, kImplicitTypeCast))
					{	CEquStr(mPartRec.path, aCStr);
						err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&mPartRec, sizeof(MultipartRec));
					}
					break;
				case kContentType:
					if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aCStr, nil, 255, kImplicitTypeCast))
					{	CEquStr(mPartRec.contentType, aCStr);
						err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&mPartRec, sizeof(MultipartRec));
					}
					break;
				
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr	_AddEscaped(long id, Ptr strP, long strLen)
{
BlockRef	escapedBlock;
XErr		err = noErr;

	if NOT(err = StringEscaped(&strP, &strLen, &escapedBlock))
	{	LockBlock(escapedBlock);
		err = BufferAddBuffer(id, GetPtr(escapedBlock), strLen);
		DisposeBlock(&escapedBlock);
	}

return err;
}

//===========================================================================================
static XErr	MultiPart_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
long			tLen, strLen;
char			*strP, *p;
MultipartRec	mPartRec;
PrimitiveUnion	*param_d;
Boolean			needSer;
long			id = 0;
BlockRef		block;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(MultipartRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&mPartRec, &tLen, 0, nil))
		{	param_d = &typeCast->result;
			if (typeCast->resultWanted == kCString)
			{	if NOT(tLen)
				{	//*mPartRec.path;
					strP = mPartRec.path;
					strLen = CLen(strP);
				}
				else
				{	if (param_d->text.variant == kForConstructor)
					{	if (id = BufferCreate(512, &err))
						{	LockBlock(mPartRec.data);
							err = _AddEscaped(id, GetPtr(mPartRec.data), mPartRec.dataLen);
							UnlockBlock(mPartRec.data);
							if NOT(err)
							{	if NOT(err = BufferAddCString(id, ",", NO_ENC, 0))
								{	if NOT(err = _AddEscaped(id, mPartRec.path, CLen(mPartRec.path)))
									{	if (*mPartRec.contentType)
										{	if NOT(err = BufferAddCString(id, ",", NO_ENC, 0))
												err = _AddEscaped(id, mPartRec.contentType, CLen(mPartRec.contentType));
										}
									}
								}
							}
							if NOT(err)
							{	block = BufferGetBlockRefExtSize(id, &strLen, &strP);
								LockBlock(block);
							}
						}
					}
					else
					{	strP = mPartRec.path;
						strLen = CLen(strP);
					}
				}
				if NOT(err)
				{	p = param_d->text.stringP;
					if (p)
					{	if (param_d->text.stringMaxStorage >= (strLen+1))
						{	CopyBlock(p, strP, strLen);
							p[strLen] = 0;
							param_d->text.stringLen = strLen;
						}
						else
						{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
							p[param_d->text.stringMaxStorage - 1] = 0;
							param_d->text.stringLen = strLen;
							err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
						}
					}
					else
						param_d->text.stringLen = strLen;
				}
				if (id)
					BufferFree(id);
			}
			else
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	multiPart_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			multipartClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void multipart(string data, string path, string contentType)");
			err = BAPI_RegisterSymbol(pbPtr->api_data, multipartClassID, "multiPart_NewObject", (long)multiPart_NewObject);
			break;
		case kInit:
			err = MultiPart_Init(pbPtr);
			break;
		case kShutDown:
			err = MultiPart_ShutDown(pbPtr);
			break;
		case kRun:
			//pbPtr->plugin_run_data = 0;
			break;
		case kExit:
		/*#ifdef MEM_DEBUG
			if ((*pbPtr->plugin_run_dataP))
				BAPI_Log(pbPtr->api_data, "multipart: leaking");
		#endif*/
			break;
		case kConstructor:
		case kTypeCast:
			err = MultiPart_Constructor(pbPtr, false);
			break;
		case kClone:
			err = MultiPart_Constructor(pbPtr, true);
			break;
		case kDestructor:
			err = MultiPart_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = MultiPart_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = MultiPart_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = MultiPart_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = MultiPart_TypeCast(pbPtr);
			break;
		/*case kGetErrDescr:
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


