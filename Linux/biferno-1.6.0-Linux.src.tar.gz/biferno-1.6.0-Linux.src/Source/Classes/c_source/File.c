/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: File.c,v 1.18 2008-06-16 13:47:31 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifdef __UNIX_XLIB__
	#include <sys/types.h>
	#include <sys/stat.h>
#endif

#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include 	"BfrTime.h"
#include 	"File.h"

#include <string.h>

typedef struct
{
	CStr255		path;
	XFileRef	ref;
	long		openMode;
	long		permission;
	Boolean		isAlias;
	Boolean		eofErr;		// for GetNextLine
	short		pad;
	long		totRefs;
	
	BlockRef	linesBlock;
	long		actLine;	
	long		bytesRead;
	long		bytesServed;
} FileRec;

#define	DECR(x)		{if (x){(*x)--;}}
#define	INCR(x)		{if (x){(*x)++;}}

// Errors
#define	START_ERR	100
enum {
		ErrFileIsNotOpen = START_ERR,
		ErrBadOffset,
		ErrBadLen,
		ErrBadOSTypeOrCreator,
		ErrBadPermission,
		ErrBadOpenMode,
		ErrCantOpenAlias,
		ErrBadName,
		ErrItemIsFolder,
		ErrNoMoreLinesInFile
};

CStr63	gFileErrorsStr[] = 
	{	
		"ErrFileIsNotOpen",
		"ErrBadOffset",
		"ErrBadLen",
		"ErrBadOSTypeOrCreator",
		"ErrBadPermission",
		"ErrBadOpenMode",
		"ErrCantOpenAlias",
		"ErrBadName",
		"ErrItemIsFolder",
		"ErrNoMoreLinesInFile"
		};
#define	TOT_ERRORS	10


// defines
#define	gsPlugName	"file"

#define	FILE_CHUNK_SIZE		1024L * 10L	// 10 K

static 	long						fileClassID;
static 	long						gsApiVersion, gsTimeClassID, gsStringClassID;


static 	time_TimeRecToObjRef_Prot	gsTimeRecToObjRef;
static 	time_ObjRefToTimeRec_Prot	gsObjRefToTimeRec;

#define TOT_COSTANTS		20

#define kFileEOFValue	-2
// Properties
enum{
		kPath = 1,
		kName,
		kPerm,
		kOpenMode,
		kLength,
		kResForkLength,
		kCreatTime,
		kModifTime,
		kIsOpen,
		kisAlias,
		kMacOSType,
		kMacOSCreator,
		kCurLine,
		kUser,
		kGroup,
		kCurPos,

		kCREATE_FILE_NEW,
		kCREATE_FILE_ALWAYS,
		kOPEN_FILE_EXISTING,
		kOPEN_FILE_ALWAYS,
		kDONT_OPEN,
		kREAD_WRITE_PERM,
		kREAD_PERM,
		kALL,

		cS_IRUSR,
		cS_IWUSR,
		cS_IXUSR,
		cS_IRGRP,
		cS_IWGRP,
		cS_IXGRP,
		cS_IROTH,
		cS_IWOTH,
		cS_IXOTH,
		
		kIsFolderBit,
		kIsAliasBit,
		kFileIsEOF
	} File_Property;

#define TOT_PROPRIETIES	16
// Methods
enum{
		kOpen = 1,
		kClose,
		kDelete,
		kGet,
		kPut,
		kAppend,
		kMove,
		kCopy,
		kRename,
		kExists,
		kFlush,
		kCheckPath,
		k_IsOpen,
		kMakeAlias,
		kFileIsAlias,
		kIsFolder,
		kResolvePath,
		kResolveAlias,
		k_fchmod,
		k_fgetmod,
		k_symlink,
		kNativePath,
		kBifernoPath,
		kGetNextLine,
		kLock,
		kUnlock
	} File_Method;
#define TOT_METHODES	26

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	fileMethods[TOT_METHODES] = 
					{	"Open", 		kOpen, 				"void Open(void)",
						"Close", 		kClose, 			"void Close(void)",
						"Delete", 		kDelete, 			"void Delete(void)",
						"Get", 			kGet, 				"string Get(int offset, int len=all)",
						"Put", 			kPut, 				"void Put(int offset, string text)",
						"Append", 		kAppend, 			"void Append(string text)",
						"Move",			kMove,				"void Move(string filePath, boolean replace=false)",
						"Copy",			kCopy,				"file Copy(string filePath, boolean replace=false)",
						"Rename",		kRename,			"file Rename(string newName)",
						"Exists",		kExists,			"static boolean Exists(string path)",
						"Flush",		kFlush,				"void Flush(void)",
						"CheckPath",	kCheckPath,			"static string CheckPath(string path)",
						"IsOpen",		k_IsOpen,			"static boolean IsOpen(string filePath)",
						"MakeAlias",	kMakeAlias,			"void MakeAlias(string aliasPath)",
						"IsAlias",		kFileIsAlias,		"static boolean IsAlias(string path)",
						"IsFolder",		kIsFolder,			"static boolean IsFolder(string path)",
						"ResolvePath",	kResolvePath,		"static string ResolvePath(string aliasPath)",
						"ResolveAlias",	kResolveAlias,		"string ResolveAlias(void)",
						"fchmod",		k_fchmod,			"static void fchmod(string path, int flags)",
						"fgetmod",		k_fgetmod,			"static int fgetmod(string path)",
						"symlink",		k_symlink,			"static void symlink(string targetPath, string symPath)",
						"NativePath",	kNativePath,		"static string NativePath(string path)",
						"BifernoPath",	kBifernoPath,		"static string BifernoPath(string path)",
						"GetNextLine",	kGetNextLine,		"string GetNextLine(void)",
						"Lock",			kLock,				"void Lock(boolean wait)",
						"Unlock",		kUnlock,			"void Unlock(void)"
					};

BAPI_MemberRecord	fileProperty[TOT_PROPRIETIES] = 
					{	"path", 			kPath,			"string",
						"name", 			kName,			"string",
						"permission", 		kPerm,			"int",
						"openMode",			kOpenMode,		"int",
						"length",			kLength,		"int",
						"resForkLength",	kResForkLength,	"int",
						"creatTime",		kCreatTime,		"time",
						"modifTime",		kModifTime,		"time",
						"isOpen",			kIsOpen,		"boolean",
						"isAlias",			kisAlias,		"boolean",
						"osType",			kMacOSType,		"string",
						"osCreator",		kMacOSCreator,	"string",
						"curLine",			kCurLine,		"int",
						"user",				kUser,			"string",
						"group",			kGroup,			"string",
						"curPos",			kCurPos,		"int"
					};

BAPI_MemberRecord	fileCostants[TOT_COSTANTS] = 
					{	"createFileNew", 		kCREATE_FILE_NEW,		"int",
						"createFileAlways", 	kCREATE_FILE_ALWAYS,	"int",
						"openFileExisting", 	kOPEN_FILE_EXISTING,	"int",
						"openFileAlways", 		kOPEN_FILE_ALWAYS,		"int",
						"dontOpen",		 		kDONT_OPEN,				"int",
						"rw", 					kREAD_WRITE_PERM,		"int",
						"r", 					kREAD_PERM,				"int",
						"all",					kALL,					"int",

						"S_IRUSR",				cS_IRUSR,				"int",
						"S_IWUSR",				cS_IWUSR,				"int",
						"S_IXUSR",				cS_IXUSR,				"int",

						"S_IRGRP",				cS_IRGRP,				"int",
						"S_IWGRP",				cS_IWGRP,				"int",
						"S_IXGRP",				cS_IXGRP,				"int",

						"S_IROTH",				cS_IROTH,				"int",
						"S_IWOTH",				cS_IWOTH,				"int",
						"S_IXOTH",				cS_IXOTH,				"int",
						
						"isFolderBit",			kIsFolderBit,			"int",
						"isAliasBit",			kIsAliasBit,			"int",

						"EOF",					kFileIsEOF,				"int"
					};

	if (err = BAPI_NewProperties(api_data, fileClassID, fileProperty, TOT_PROPRIETIES, nil))
		return err;		

	if (err = BAPI_NewMethods(api_data, fileClassID, fileMethods, TOT_METHODES, nil))
		return err;
	
	if (err = BAPI_NewConstants(api_data, fileClassID, fileCostants, TOT_COSTANTS, nil))
		return err;

	err = BAPI_RegisterErrors(api_data, fileClassID, START_ERR, gFileErrorsStr, TOT_ERRORS);
	
//out:
return err;
}

//===========================================================================================
static XErr	_GetFileRecPtr(long api_data, ObjRef *objRefP, FileRec **fileRecPPtr, BlockRef *fileRecBlock, long *objLenP)
{
	long		tLen;
	XErr		err = noErr;
	
	tLen = sizeof(BlockRef);
	if NOT(err = BAPI_GetObj(api_data, objRefP, (Ptr)fileRecBlock, &tLen, 0, nil))
	{
		*fileRecPPtr = (FileRec*)GetPtr(*fileRecBlock);
		if (objLenP)
			*objLenP = tLen;
	}
	return err;
}

//===========================================================================================
static XErr	_ReadNextChunk(long api_data, ExecuteMethodRec *execMethodRecP, FileRec *fileRecP, Ptr *textPPtr, long *textLenP, long *bytesServedP, long *bytesReadP, long *curLineLenP, Boolean *toConcatP, Ptr *savePPtr, Boolean *toBreakP)
{
XErr		err = noErr;
ObjRef		temp_objRef;
long		curLineLen, tLen, textLen;
Ptr			textP, saveP;
int			ch;

	textP = *textPPtr;
	textLen = *textLenP;
	saveP = *savePPtr;
	curLineLen = *curLineLenP;
	if (curLineLen)
	{	if (*toConcatP)
		{	BAPI_InvalObjRef(api_data, &temp_objRef);
			if NOT(err = BAPI_StringToObj(api_data, saveP, curLineLen, &temp_objRef))
				err = BAPI_ConcatObjs(api_data, &execMethodRecP->resultObjRef, &temp_objRef);
		}
		else
		{	err = BAPI_StringToObj(api_data, saveP, curLineLen, &execMethodRecP->resultObjRef);
			*toConcatP = true;
		}
	}
	if NOT(err)
	{	if (fileRecP->eofErr)
		{	if (fileRecP->actLine == kFileEOFValue)
				err = XError(kBAPI_ClassError, ErrNoMoreLinesInFile);
			else
			{	fileRecP->actLine = kFileEOFValue;
				*toBreakP = true;
				curLineLen = 0;
			}
		}
		else
		{	textLen = FILE_CHUNK_SIZE;
			textP = saveP = GetPtr(fileRecP->linesBlock);
			err = ReadXFile(fileRecP->ref, textP, &textLen);
			if (err == XError(kXLibError, ErrXFiles_EndOfFile))
			{	fileRecP->eofErr = true;
				err = noErr;
			}
			if NOT(err)
			{	if (textLen)
				{	ch = *(textP + textLen - 1);
					if ((ch == '\r') && NOT(fileRecP->eofErr))
					{	if NOT(err = SetBlockSize(fileRecP->linesBlock, textLen+1))
						{	textP = saveP = GetPtr(fileRecP->linesBlock);
							tLen = 1;
							if NOT(err = ReadXFile(fileRecP->ref, textP + textLen, &tLen))
								textLen++;
						}
					}
				}
				if NOT(err)
				{	*bytesServedP = 0;
					*bytesReadP = textLen;
					curLineLen = 0;
				}
			}
		}
	}
	*textPPtr = textP;
	*textLenP = textLen;
	*savePPtr = saveP;
	*curLineLenP = curLineLen;

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static void	_OpenModeStr(long openMode, char *tStr)
{
	switch(openMode)
	{
		case CREATE_FILE_NEW:
			CEquStr(tStr, "createFileNew");
			break;
		case CREATE_FILE_ALWAYS:
			CEquStr(tStr, "createFileAlways");
			break;
		case OPEN_FILE_EXISTING:
			CEquStr(tStr, "openFileExisting");
			break;
		case OPEN_FILE_ALWAYS:
			CEquStr(tStr, "openFileAlways");
			break;
		case DONT_OPEN:
			CEquStr(tStr, "dontOpen");
			break;
		default:
			*tStr = 0;
	}
}

//===========================================================================================
static void	_PermissionStr(long permission, char *tStr)
{
	switch(permission)
	{
		case READ_WRITE_PERM:
			CEquStr(tStr, "rw");
			break;
		case READ_PERM:
			CEquStr(tStr, "r");
			break;
		default:
			*tStr = 0;
	}
}

//===========================================================================================
static XErr	_GetNextLine(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP, FileRec *fileRecP, ObjRef *fileRecObjRefP)
{
XErr		err = noErr;
long		curLineLen, bytesServed, bytesRead, actLine, textLen, api_data = pbPtr->api_data, returnSize;
Ptr			textP, saveP;
ObjRef		temp_objRef;
Boolean		toBreak = false, toConcat = false, allocated = false;

	if NOT(fileRecP->ref)
		err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
	else
	{	if NOT(fileRecP->linesBlock)
		{	if (fileRecP->linesBlock = NewBlock(FILE_CHUNK_SIZE, &err, nil))
				allocated = true;
		}
		if NOT(err)
		{	actLine = fileRecP->actLine;	// 0-based
			LockBlock(fileRecP->linesBlock);
			bytesRead = fileRecP->bytesRead;
			bytesServed = fileRecP->bytesServed;
			textP = saveP = GetPtr(fileRecP->linesBlock) + bytesServed;
			textLen = bytesRead - bytesServed;
			curLineLen = 0;
			while NOT(err)
			{	if (bytesServed >= bytesRead)
				{	if (err = _ReadNextChunk(api_data, execMethodRecP, fileRecP, &textP, &textLen, &bytesServed, &bytesRead, &curLineLen, &toConcat, &saveP, &toBreak))
						break;
					if (toBreak)
						break;
				}
				if (IsNewLine(textP, textLen, &returnSize))
				{	bytesServed += returnSize;
					break;
				}
				else
				{	if (textLen)
					{	textP++;
						textLen--;
						bytesServed++;
						curLineLen++;
					}
				}
			}
			if NOT(err)
			{	if (toConcat)
				{	BAPI_InvalObjRef(api_data, &temp_objRef);
					if NOT(err = BAPI_StringToObj(api_data, saveP, curLineLen, &temp_objRef))
						err = BAPI_ConcatObjs(api_data, &execMethodRecP->resultObjRef, &temp_objRef);
				}
				else
					err = BAPI_StringToObj(api_data, saveP, curLineLen, &execMethodRecP->resultObjRef);
				if NOT(err)
				{	if (fileRecP->actLine != kFileEOFValue)
						fileRecP->actLine++;
					fileRecP->bytesServed = bytesServed;
					fileRecP->bytesRead = bytesRead;
					// err = BAPI_ModifyObj(pbPtr->api_data, fileRecObjRefP, (Ptr)fileRecP, sizeof(FileRec));
				}
			}
			UnlockBlock(fileRecP->linesBlock);
		}
		if (err && allocated)
			DisposeBlock(&fileRecP->linesBlock);
	}

return err;
}

//===========================================================================================
static XErr	_NativePath(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = BAPI_NativePath(api_data, filePath))
				err = BAPI_StringToObj(api_data, filePath, CLen(filePath), &execMethodRecP->resultObjRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_BifernoPath(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_BifernoPath(api_data, filePath))
			err = BAPI_StringToObj(api_data, filePath, CLen(filePath), &execMethodRecP->resultObjRef);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_fchmod(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
long 			modeFlags;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = BAPI_ObjToInt(api_data, &paramsP[1].objRef, &modeFlags, kImplicitTypeCast))
				err = ChangeFileMode(0, filePath, modeFlags);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_fgetmod(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			mode, api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = GetFileMode(0, filePath, &mode))
				err = BAPI_IntToObj(api_data, mode, &execMethodRecP->resultObjRef);
			/*errno = 0;
			if (lstat(filePath, &theStat) < 0)
				err = errno;
			
			if NOT(err = GetXFileInfo(filePath, &xFileInfo))
				err = BAPI_IntToObj(api_data, GetMode(filePath), &execMethodRecP->resultObjRef);
			*/
		}
	}

return err;	
}

//===========================================================================================
static XErr	_symlink(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			targetPath, symPath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, targetPath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &paramsP[1].objRef, symPath, nil, 255, kImplicitTypeCast))
		{	err = BAPI_RealPath(api_data, symPath, true);
			if (err == XError(kXLibError, ErrXFiles_FileNotFound))
				err = noErr;
			err = XMakeAlias(targetPath, symPath);
		}
	}

return err;
}

//===========================================================================================
/*static XErr	_fgetuser(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
#ifdef __UNIX_XLIB__
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
XFileInfo 		xFileInfo;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = GetXFileInfo(filePath, &xFileInfo))
				err = BAPI_StringToObj(api_data, xFileInfo.user, CLen(xFileInfo.user), &execMethodRecP->resultObjRef);
		}
	}

#else
	err = BAPI_StringToObj(api_data, "", 0, &execMethodRecP->resultObjRef);
#endif
	
return err;
}

//===========================================================================================
static XErr	_fgetgroup(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
#ifdef __UNIX_XLIB__
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
XFileInfo 		xFileInfo;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = GetXFileInfo(filePath, &xFileInfo))
				err = BAPI_StringToObj(api_data, xFileInfo.group, CLen(xFileInfo.group), &execMethodRecP->resultObjRef);
		}
	}

#else
	err = BAPI_StringToObj(api_data, "", 0, &execMethodRecP->resultObjRef);
#endif
	
return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_OpenFile(Biferno_ParamBlockPtr pbPtr, FileRec *fileRecP, ObjRef *fileRecObjRefP)
{
XErr		err = noErr;

	if (fileRecP->ref)
	{	if NOT(err = CloseXFile(&fileRecP->ref))
			DECR(pbPtr->plugin_run_dataP)
	}
	if NOT(err)
	{	if (fileRecP->isAlias)
			err = XError(kBAPI_ClassError, ErrCantOpenAlias);
		else
		{	if (fileRecP->openMode == DONT_OPEN)
				fileRecP->openMode = OPEN_FILE_EXISTING;
			err = OpenXFile(fileRecP->path, (short)fileRecP->openMode, fileRecP->permission, false, &fileRecP->ref);
			if (err && (fileRecP->permission == READ_WRITE_PERM))
			{	fileRecP->permission = READ_PERM;
				err = OpenXFile(fileRecP->path, (short)fileRecP->openMode, fileRecP->permission, false, &fileRecP->ref);
			}
			if NOT(err)
			{	INCR(pbPtr->plugin_run_dataP)
				if (fileRecObjRefP)
				{	if (fileRecP->openMode == DONT_OPEN)
						fileRecP->openMode = OPEN_FILE_EXISTING;
					// err = BAPI_ModifyObj(pbPtr->api_data, fileRecObjRefP, (Ptr)fileRecP, sizeof(FileRec));
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_CloseFile(Biferno_ParamBlockPtr pbPtr, FileRec *fileRecP, ObjRef *fileRecObjRefP)
{
XErr	err = noErr;

	if (fileRecP->ref)
	{	if NOT(err = CloseXFile(&fileRecP->ref))
		{	DECR(pbPtr->plugin_run_dataP)
			fileRecP->ref = 0;
			
			if (fileRecP->linesBlock)
			{	DisposeBlock(&fileRecP->linesBlock);
				fileRecP->linesBlock = 0;
				fileRecP->actLine = 0;
				fileRecP->bytesRead = 0;
				fileRecP->bytesServed = 0;
				fileRecP->eofErr = 0;
			}
			// err = BAPI_ModifyObj(pbPtr->api_data, fileRecObjRefP, (Ptr)fileRecP, sizeof(FileRec));
		}
	}
	else
	{	err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
		CEquStr(pbPtr->error, "file: can't close file (the file is not open)");
	}	
	
return err;
}

//===========================================================================================
static XErr	_DeleteFile(Biferno_ParamBlockPtr pbPtr, FileRec *fileRecP, ObjRef *fileRecObjRefP)
{
	XErr	err = noErr;	//, err2 = noErr;
//Boolean	toModify = false;

	if (fileRecP->ref)
	{	if NOT(err = CloseXFile(&fileRecP->ref))
		{	DECR(pbPtr->plugin_run_dataP)
			fileRecP->ref = 0;
			// toModify = true;
		}
	}
	
	if NOT(err)
	{	if NOT(err = DeleteXFile(fileRecP->path))
		{	fileRecP->ref = 0;
			fileRecP->openMode = 0;
			fileRecP->permission = 0;
			fileRecP->isAlias = false;
		}
	}
	
	/*if (toModify)
	{	err2 = BAPI_ModifyObj(pbPtr->api_data, fileRecObjRefP, (Ptr)fileRecP, sizeof(FileRec));
		if (err2 && NOT(err))
			err = err2;
	}*/
	
return err;
}

//===========================================================================================
static XErr	_Get(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FileRec *fileRecP)
{
XErr			err = noErr;
long			offset, len;
BlockRef		block;
Ptr				textP;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
long 			totParams = exeMethodRecP->totParams;

	if NOT(fileRecP->ref)
		err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
	else if (totParams == 2)
	{	if NOT(err = BAPI_ObjToInt(api_data, &paramsP[0].objRef, &offset, kImplicitTypeCast))
		{	if (offset < 0)
				err = XError(kBAPI_ClassError, ErrBadOffset);
			else
			{	if NOT(err = BAPI_ObjToInt(api_data, &paramsP[1].objRef, &len, kImplicitTypeCast))
				{	if (len == 0)
						err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
					else if ((len < 0) && (len != -1))
						err = XError(kBAPI_ClassError, ErrBadLen);
					else
					{	if (len == -1)
							err = GetXEOF(fileRecP->ref, &len);
						if NOT(err)
						{	if (len)
							{	if (block = NewBlockLocked(len, &err, &textP))
								{	//LockBlock(block);
									//textP = GetPtr(block);
									if NOT(err = SetXFPos(fileRecP->ref, FROM_START, offset))
									{	if NOT(err = ReadXFile(fileRecP->ref, textP, &len))
											err = BAPI_StringToObj(api_data, textP, len, &exeMethodRecP->resultObjRef);
									}
									DisposeBlock(&block);
								}
							}
							else
								err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
						}
					}
				}
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
	
return err;
}

//===========================================================================================
static XErr	_Put(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FileRec *fileRecP, Boolean append)
{
XErr			err = noErr;
long			offset;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
long 			totParams = exeMethodRecP->totParams;
CStr255			aCStr;
BlockRef		ref = 0;
char			*stringP;
long			stringLen;

	if NOT(fileRecP->ref)
		return XError(kBAPI_ClassError, ErrFileIsNotOpen);
	if (append)	
	{	if (totParams == 1)
		{	if NOT(err = GetXEOF(fileRecP->ref, &offset))
				err = BAPI_GetStringBlock(api_data, &paramsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast);
		}
		else
			err = XError(kBAPI_Error, Err_PrototypeMismatch);
	}
	else
	{	if (totParams == 2)
		{	if NOT(err = BAPI_ObjToInt(api_data, &paramsP[0].objRef, &offset, kImplicitTypeCast))
			{	if (offset < 0)
					err = XError(kBAPI_ClassError, ErrBadOffset);
				else
					err = BAPI_GetStringBlock(api_data, &paramsP[1].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast);
			}
		}
		else
			err = XError(kBAPI_Error, Err_PrototypeMismatch);
	}
	if (err && ref)
		BAPI_ReleaseBlock(&ref);
		
	if NOT(err)
	{	if (offset >= 0)
			err = SetXFPos(fileRecP->ref, FROM_START, offset);
		if NOT(err)
			err = WriteXFile(fileRecP->ref, stringP, &stringLen);
		BAPI_ReleaseBlock(&ref);
	}
	
return err;
}

//===========================================================================================
static XErr	_Flush(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
//long			api_data = pbPtr->api_data;
//long 			tLen;//, theError;
FileRec			*fileRecP;
BlockRef		fileRecBlock;

	//tLen = sizeof(FileRec);
	//if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&fileRec, &tLen, 0, nil))
	if not(err = _GetFileRecPtr(pbPtr->api_data, &exeMethodRecP->objRef, &fileRecP, &fileRecBlock, nil))
	{	
		if (fileRecP->ref)
			err = FlushXFile(fileRecP->ref);
		else
			err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
	}
	
return err;
}

//===========================================================================================
static XErr	_Exists(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, Boolean returnError)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
long 			filePathLen, theError;
CStr255			filePath;
CStr255			subErr, eNameStr, errType, descr;
char			retStr[512];
//long			eNum, eType;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, &filePathLen, 255, kImplicitTypeCast))
	{	if (filePathLen)
		{	if NOT(theError = BAPI_RealPath(api_data, filePath, false))
				theError = CheckPath(filePath, false);
		}
		else
			theError = XError(kXLibError, ErrXFiles_FileNotFound);
		if (returnError)
		{	if (theError)
			{	BAPI_GetErrDescription(api_data, theError, eNameStr, nil, errType, descr, nil, 0, subErr);
				sprintf(retStr, "%s/%s/%s", eNameStr, descr, subErr);
			}
			else
				*retStr = 0;
			err = BAPI_StringToObj(api_data, retStr, CLen(retStr), &exeMethodRecP->resultObjRef);
		}
		else
			err = BAPI_BooleanToObj(api_data, (Boolean)(theError == 0), &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_RenameFile(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FileRec *fileRecP)
{
XErr			err = noErr;	//, err2 = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
//long 			totParams = exeMethodRecP->totParams;
CStr255			newName, newPath;
char			*strP;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, newName, nil, 255, kImplicitTypeCast))
	{	if (*newName)
		{	CEquStr(newPath, fileRecP->path);
			if (strP = strrchr(newPath, '/'))
			{	CEquStr(++strP, newName);
				if NOT(err = RenameXFile(fileRecP->path, newPath))
				{	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
					{	
						CEquStr(fileRecP->path, newPath);
						// err = BAPI_ModifyObj(api_data, &exeMethodRecP->objRef, (Ptr)fileRecP, sizeof(FileRec));
					}
				}
			}
		}
		else
			err = XError(kBAPI_ClassError, ErrBadName);
	}
	
return err;
}

//===========================================================================================
static XErr	_MoveFile(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FileRec *fileRecP, BlockRef fileBlockRef, Boolean toCopy)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
long 			totParams = exeMethodRecP->totParams;
CStr255			newPath;
Boolean			replaceExisting, closed = false;
	
	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, newPath, nil, 255, kImplicitTypeCast))
	{	
		if (totParams > 1)
			err = BAPI_ObjToBoolean(api_data, &paramsP[1].objRef, &replaceExisting, kImplicitTypeCast);
		else
			replaceExisting = false;
		if NOT(err)
		{	
			err = BAPI_RealPath(api_data, newPath, false);
			if (err == XError(kXLibError, ErrXFiles_FileNotFound))
				err = noErr; 
			if (NOT(err) && CCompareStrings_cs(fileRecP->path, newPath))
			{	
				if (toCopy)
				{	
					if NOT(err = CopyXFile(fileRecP->path, newPath, replaceExisting))
					{	
						BlockRef	newFileRecBlock;
						FileRec		*newFileRecP;
						
						if (newFileRecBlock = NewBlockClear(sizeof(FileRec), &err, (Ptr*)&newFileRecP))
						{
							// return object
							*newFileRecP = *fileRecP;
							CEquStr(newFileRecP->path, newPath);
							newFileRecP->ref = 0;
							newFileRecP->linesBlock = 0;
							newFileRecP->openMode = DONT_OPEN;
							newFileRecP->totRefs = 1;
							if (err = BAPI_BufferToObj(api_data, (Ptr)&newFileRecBlock, sizeof(BlockRef), fileClassID, true, nil, &exeMethodRecP->resultObjRef))
								DisposeBlock(&newFileRecBlock);
						}
					}
				}
				else
				{	
					if (fileRecP->ref)
					{	if NOT(err = CloseXFile(&fileRecP->ref))
						{	
							DECR(pbPtr->plugin_run_dataP)
							closed = true;
						}
					}
					if NOT(err)
					{	
						if NOT(err = MoveXFile(fileRecP->path, newPath, replaceExisting))
							CEquStr(fileRecP->path, newPath);
						if (closed)
						{	
							XErr err2 = OpenXFile(fileRecP->path, (short)fileRecP->openMode, fileRecP->permission, false, &fileRecP->ref);
							if NOT(err2)
								INCR(pbPtr->plugin_run_dataP)
							if (err2 && NOT(err))
								err = err2;
						}
						/*if (NOT(err) || closed)
						{	
							XErr err2;
							if NOT(err2 = BAPI_ModifyObj(api_data, &exeMethodRecP->objRef, (Ptr)fileRecP, sizeof(FileRec)))
								exeMethodRecP->sideEffect = true;
							if (err2 && NOT(err))
								err = err2;
						}*/
					}
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_IsOpen(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
//long 			totParams = exeMethodRecP->totParams;
CStr255			filePath;
Boolean			isOpen;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = IsXFileOpen(filePath, &isOpen))
				err = BAPI_BooleanToObj(api_data, isOpen, &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_IsAlias(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
CStr255			filePath;
Boolean			isAlias;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = XIsAlias(filePath, &isAlias))
				err = BAPI_BooleanToObj(api_data, isAlias, &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_IsFolder(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
CStr255			filePath;
Boolean			isDir;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = XIsFolder(filePath, &isDir))
				err = BAPI_BooleanToObj(api_data, isDir, &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_ResolvePath(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
//long 			totParams = exeMethodRecP->totParams;
CStr255			filePath, tempStr;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, true))
		{	CEquStr(tempStr, FILE_HD_PREFIX);
			CAddStr(tempStr, filePath);
			err = BAPI_StringToObj(api_data, tempStr, CLen(tempStr), &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_ResolveAlias(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FileRec *fileRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
//ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
//long 			totParams = exeMethodRecP->totParams;
CStr255			filePath, tempStr;

	CEquStr(filePath, FILE_HD_PREFIX);
	CAddStr(filePath, fileRecP->path);
	if NOT(err = BAPI_RealPath(api_data, filePath, true))
	{	CEquStr(tempStr, FILE_HD_PREFIX);
		CAddStr(tempStr, filePath);
		err = BAPI_StringToObj(api_data, tempStr, CLen(tempStr), &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_MakeAlias(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FileRec *fileRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
//long 			totParams = exeMethodRecP->totParams;
CStr255			aliasPath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, aliasPath, nil, 255, kImplicitTypeCast))
	{	err = BAPI_RealPath(api_data, aliasPath, false);
		if (err == XError(kXLibError, ErrXFiles_FileNotFound))
			err = noErr;
		err = XMakeAlias(fileRecP->path, aliasPath);
	}

return err;
}

//===========================================================================================
static XErr	_Lock(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FileRec *fileRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
Boolean			toWait;

	if NOT(err = BAPI_ObjToBoolean(api_data, &paramsP[0].objRef, &toWait, kImplicitTypeCast))
	{	if (fileRecP->ref)
			err = LockXFile(fileRecP->ref, 0, -1, toWait);
		else
		{	err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
			CEquStr(pbPtr->error, "file: can't lock file (the file is not open)");
		}	
	}

return err;
}

//===========================================================================================
static XErr	_Unlock(Biferno_ParamBlockPtr pbPtr, FileRec *fileRecP)
{
XErr			err = noErr;
//long			api_data = pbPtr->api_data;

	if (fileRecP->ref)
		err = UnlockXFile(fileRecP->ref, 0, -1);
	else
	{	err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
		CEquStr(pbPtr->error, "file: can't unlock file (the file is not open)");
	}	

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	File_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	gsTimeClassID = BAPI_ClassIDFromName(api_data, "time", false);
	gsStringClassID = BAPI_ClassIDFromName(api_data, "string", false);
	if NOT(err = BAPI_GetSymbol(api_data, gsTimeClassID, "time_ObjRefToTimeRec", (long*)&gsObjRefToTimeRec))
	{	if NOT(err = BAPI_GetSymbol(api_data, gsTimeClassID, "time_TimeRecToObjRef", (long*)&gsTimeRecToObjRef))
			err = _RegisterListMembers(api_data);
	}
		
return err;
}

//===========================================================================================
static XErr	File_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	fileClassID = 0;
	
return noErr;
}

//#define	RANDOM_ERRORS_DEBUG

#ifdef RANDOM_ERRORS_DEBUG
	extern long gRunID;
	static long	gFileTest;
#endif
//===========================================================================================
static XErr	File_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
	XErr			err = noErr, pathError = noErr;
	ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
	long			api_data = pbPtr->api_data;
	BlockRef		fileRecBlock;
	FileRec			*fileRecP;
	Boolean			isFolder = false;
	ParameterRec	*paramVarsP = constructorRecP->varRecsP;
	ObjRefP			firstParamP = &paramVarsP[0].objRef;
	XErr			err2 = noErr;
	
	if ((message == kClone) || (message == kTypeCast))
	{	
		if (BAPI_GetObjClassID(api_data, firstParamP) == fileClassID)
		{	
			if not(err = _GetFileRecPtr(api_data, firstParamP, &fileRecP, &fileRecBlock, nil))
			{	
				fileRecP->totRefs++;
				err = BAPI_BufferToObj(api_data, (Ptr)&fileRecBlock, sizeof(BlockRef), fileClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
			}
		}
		else
		{	
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
		}
	}
	else
	{	
		if (fileRecBlock = NewBlockClear(sizeof(FileRec), &err, (Ptr*)&fileRecP))
		{	
			err = BAPI_ObjToString(api_data, firstParamP, fileRecP->path, nil, 255, kImplicitTypeCast);
			if (err && (err == (XError(kBAPI_Error, Err_BAPI_BufferTooSmall))))
				err = (XError(kBAPI_Error, Err_PathTooLong));
			if NOT(err)
			{	
				if NOT(pathError = BAPI_RealPath(api_data, fileRecP->path, false))
					err = XIsAlias(fileRecP->path, &fileRecP->isAlias);
				else if (pathError != XError(kXLibError, ErrXFiles_FileNotFound))
					err = pathError;
				if NOT(err)
				{	
					if (NOT(fileRecP->isAlias) && NOT(pathError))
						err = XIsFolder(fileRecP->path, &isFolder);
					if NOT(err)
					{	
						if (isFolder)
							err = XError(kBAPI_ClassError, ErrItemIsFolder);
						else
						{	
							if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &fileRecP->openMode, kImplicitTypeCast))
							{	
								if NOT(fileRecP->openMode)
								{	if (fileRecP->isAlias)
									fileRecP->openMode = DONT_OPEN;
								else
									fileRecP->openMode = OPEN_FILE_EXISTING;
								}
							}
							if (NOT(err) && ((fileRecP->openMode < CREATE_FILE_NEW) || (fileRecP->openMode > DONT_OPEN)))
								err = XError(kBAPI_ClassError, ErrBadOpenMode);
							if NOT(err)
							{	
								err = BAPI_ObjToInt(api_data, &paramVarsP[2].objRef, &fileRecP->permission, kImplicitTypeCast);
								if NOT(fileRecP->permission)
									fileRecP->permission = READ_WRITE_PERM;
								if (NOT(err) && (fileRecP->permission != READ_WRITE_PERM) && (fileRecP->permission != READ_PERM))
									err = XError(kBAPI_ClassError, ErrBadPermission);
								if NOT(err)
								{	
									if (fileRecP->openMode == DONT_OPEN)
										err = pathError;
									else if (fileRecP->isAlias)
										err = XError(kBAPI_ClassError, ErrCantOpenAlias);
									else
									{	
										if NOT(err = OpenXFile(fileRecP->path, (short)fileRecP->openMode, fileRecP->permission, false, &fileRecP->ref))
											INCR(pbPtr->plugin_run_dataP)
											}
									if NOT(err)
									{	
										fileRecP->totRefs = 1;
										if (err = BAPI_BufferToObj(api_data, (Ptr)&fileRecBlock, sizeof(BlockRef), fileClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
										{	
											if NOT(err2 = CloseXFile(&fileRecP->ref))
												DECR(pbPtr->plugin_run_dataP)
										}
									}
								}
							}
						}
					}
				}
			}
			if (err)
			{
				if NOT(*pbPtr->error)
				{	
					if (*fileRecP->path)
					{	CEquStr(pbPtr->error, "Error on path: ");
						CAddStr(pbPtr->error, fileRecP->path);
					}
				}
				DisposeBlock(&fileRecBlock);
			}
		}
	}
	
	return err;
}

//===========================================================================================
static XErr	File_Destructor(Biferno_ParamBlockPtr pbPtr)
{
	XErr			err = noErr;
	DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
	FileRec			*fileRecP;
	BlockRef		fileRecBlock;
	Boolean			isDir;
	long			objLen;
	
	if not(err = _GetFileRecPtr(pbPtr->api_data, &destructorRecP->objRef, &fileRecP, &fileRecBlock, &objLen))
	{	
		if (objLen)
		{	
			if not(--fileRecP->totRefs)
			{
				if (fileRecP->ref)		// already closed?
				{	
					err = CloseXFile(&fileRecP->ref);
					if (err)
					{	
						XIsFolder(fileRecP->path, &isDir);	// I think this is only for unix
						if (isDir)
						{	
							DECR(pbPtr->plugin_run_dataP)
							err = noErr;
						}
					}
					else
						DECR(pbPtr->plugin_run_dataP)	
				}
				if (fileRecP->linesBlock)
					DisposeBlock(&fileRecP->linesBlock);
				DisposeBlock(&fileRecBlock);
			}				
		}
	}
	
	return err;
}

//===========================================================================================
static XErr	File_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
	XErr				err = noErr;
	ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
	long				tLen;
	FileRec				*fileRec1P, *fileRec2P;
	Boolean				res;
	BlockRef			fileRecBlock1, fileRecBlock2;
	
	if (exeOperationRecP->operation == EVAL_EQUA)
	{	
		tLen = sizeof(BlockRef);
		if (err = BAPI_ReadObj(pbPtr->api_data, &exeOperationRecP->objRef1, (Ptr)&fileRecBlock1, &tLen, 0, nil))
			goto out;
		if (err = BAPI_ReadObj(pbPtr->api_data, &exeOperationRecP->objRef2, (Ptr)&fileRecBlock2, &tLen, 0, nil))
			goto out;
		fileRec1P = (FileRec*)GetPtr(fileRecBlock1);
		fileRec2P = (FileRec*)GetPtr(fileRecBlock2);
		res = NOT(CCompareStrings_cs(fileRec1P->path, fileRec2P->path));
		err = BAPI_BooleanToObj(pbPtr->api_data, res, &exeOperationRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);
	
out:
	return err;
}

//===========================================================================================
static XErr	File_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
	XErr				err = noErr;
	ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
	long 				tLen, api_data = pbPtr->api_data;
	FileRec				*fileRecP;
	BlockRef			fileRecBlock;
	
	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
	{	
		tLen = sizeof(BlockRef);
		if not(err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&fileRecBlock, &tLen, 0, nil))
			fileRecP = (FileRec*)GetPtr(fileRecBlock);
	}
	//else
	//	ClearBlock(&fileRec, sizeof(FileRec));
	if NOT(err)
	{	
		switch(exeMethodRecP->methodID)
		{	case kOpen:
				err = _OpenFile(pbPtr, fileRecP, &exeMethodRecP->objRef);
				break;
			case kClose:
				err = _CloseFile(pbPtr, fileRecP, &exeMethodRecP->objRef);
				break;
			case kDelete:
				err = _DeleteFile(pbPtr, fileRecP, &exeMethodRecP->objRef);
				break;
			case kGet:
				err = _Get(pbPtr, exeMethodRecP, fileRecP);
				break;
			case kPut:
				err = _Put(pbPtr, exeMethodRecP, fileRecP, false);
				break;
			case kAppend:
				err = _Put(pbPtr, exeMethodRecP, fileRecP, true);
				break;
			case kMove:
				err = _MoveFile(pbPtr, exeMethodRecP, fileRecP, fileRecBlock, false);
				break;
			case kCopy:
				err = _MoveFile(pbPtr, exeMethodRecP, fileRecP, fileRecBlock, true);
				break;
			case kRename:
				err = _RenameFile(pbPtr, exeMethodRecP, fileRecP);
				break;
			case kExists:
				err = _Exists(pbPtr, exeMethodRecP, false);		// static
				break;
			case kFlush:
				err = _Flush(pbPtr, exeMethodRecP);
				break;
			case kCheckPath:
				err = _Exists(pbPtr, exeMethodRecP, true);		// static
				break;
			case k_IsOpen:
				err = _IsOpen(pbPtr, exeMethodRecP);				// static
				break;
			case kMakeAlias:
				err = _MakeAlias(pbPtr, exeMethodRecP, fileRecP);
				break;
			case kFileIsAlias:
				err = _IsAlias(pbPtr, exeMethodRecP);				// static
				break;
			case kIsFolder:
				err = _IsFolder(pbPtr, exeMethodRecP);				// static
				break;
			case kResolvePath:
				err = _ResolvePath(pbPtr, exeMethodRecP);			// static
				break;
			case kResolveAlias:
				err = _ResolveAlias(pbPtr, exeMethodRecP, fileRecP);
				break;
			case k_fchmod:
				err = _fchmod(pbPtr, exeMethodRecP);
				break;
			case k_fgetmod:
				err = _fgetmod(pbPtr, exeMethodRecP);
				break;
			case k_symlink:
				err = _symlink(pbPtr, exeMethodRecP);
				break;
			
			/*case k_fgetuser:
				err = _fgetuser(pbPtr, exeMethodRecP);
				break;
			case k_fgetgroup:
				err = _fgetgroup(pbPtr, exeMethodRecP);
				break;*/
			
			case kNativePath:
				err = _NativePath(pbPtr, exeMethodRecP);
				break;
			case kBifernoPath:
				err = _BifernoPath(pbPtr, exeMethodRecP);
				break;
			case kGetNextLine:
				err = _GetNextLine(pbPtr, exeMethodRecP, fileRecP, &exeMethodRecP->objRef);
				break;

			case kLock:
				err = _Lock(pbPtr, exeMethodRecP, fileRecP);
				break;
			case kUnlock:
				err = _Unlock(pbPtr, fileRecP);
				break;
			
			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
	}

return err;
}

//===========================================================================================
static XErr	File_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
	GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
	XErr			err = noErr;
	FileRec			*fileRecP;
	BlockRef		fileRecBlock;
	long			strpLen, tLen, eof, api_data = pbPtr->api_data;
	CStr255			tempStr;
	char			*strP;

	if (getPropertyRec->isConstant)
	{	
		switch(getPropertyRec->propertyID)
		{	
			case kCREATE_FILE_NEW:
				err = BAPI_IntToObj(api_data, CREATE_FILE_NEW, &getPropertyRec->resultObjRef);
				break;
			case kCREATE_FILE_ALWAYS:
				err = BAPI_IntToObj(api_data, CREATE_FILE_ALWAYS, &getPropertyRec->resultObjRef);			
				break;
			case kOPEN_FILE_EXISTING:
				err = BAPI_IntToObj(api_data, OPEN_FILE_EXISTING, &getPropertyRec->resultObjRef);			
				break;
			case kOPEN_FILE_ALWAYS:
				err = BAPI_IntToObj(api_data, OPEN_FILE_ALWAYS, &getPropertyRec->resultObjRef);			
				break;
			case kDONT_OPEN:
				err = BAPI_IntToObj(api_data, DONT_OPEN, &getPropertyRec->resultObjRef);			
				break;
			case kREAD_WRITE_PERM:
				err = BAPI_IntToObj(api_data, READ_WRITE_PERM, &getPropertyRec->resultObjRef);			
				break;
			case kREAD_PERM:
				err = BAPI_IntToObj(api_data, READ_PERM, &getPropertyRec->resultObjRef);			
				break;
			case kALL:
				err = BAPI_IntToObj(api_data, -1, &getPropertyRec->resultObjRef);			
				break;
			case cS_IRUSR:
				err = BAPI_IntToObj(api_data, kS_IRUSR, &getPropertyRec->resultObjRef);			
				break;
			case cS_IWUSR:
				err = BAPI_IntToObj(api_data, kS_IWUSR, &getPropertyRec->resultObjRef);			
				break;
			case cS_IXUSR:
				err = BAPI_IntToObj(api_data, kS_IXUSR, &getPropertyRec->resultObjRef);			
				break;
			case cS_IRGRP:
				err = BAPI_IntToObj(api_data, kS_IRGRP, &getPropertyRec->resultObjRef);			
				break;
			case cS_IWGRP:
				err = BAPI_IntToObj(api_data, kS_IWGRP, &getPropertyRec->resultObjRef);			
				break;
			case cS_IXGRP:
				err = BAPI_IntToObj(api_data, kS_IXGRP, &getPropertyRec->resultObjRef);			
				break;
			case cS_IROTH:
				err = BAPI_IntToObj(api_data, kS_IROTH, &getPropertyRec->resultObjRef);			
				break;
			case cS_IWOTH:
				err = BAPI_IntToObj(api_data, kS_IWOTH, &getPropertyRec->resultObjRef);			
				break;
			case cS_IXOTH:
				err = BAPI_IntToObj(api_data, kS_IXOTH, &getPropertyRec->resultObjRef);			
				break;
			case kIsFolderBit:
				err = BAPI_IntToObj(api_data, kPathIsFolder, &getPropertyRec->resultObjRef);			
				break;
			case kIsAliasBit:
				err = BAPI_IntToObj(api_data, kPathIsAlias, &getPropertyRec->resultObjRef);			
				break;
			
			case kFileIsEOF:
				err = BAPI_IntToObj(api_data, kFileEOFValue, &getPropertyRec->resultObjRef);			
				break;
			
			default:
				err = XError(kBAPI_Error, Err_NoSuchConstant);
				break;
		}
	}
	else if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
	{	
		tLen = sizeof(BlockRef);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&fileRecBlock, &tLen, 0, nil))
		{	
			fileRecP = (FileRec*)GetPtr(fileRecBlock);
			switch(getPropertyRec->propertyID)
			{
				case kPath:
					CEquStr(tempStr, FILE_HD_PREFIX);
					CAddStr(tempStr, fileRecP->path);
					err = BAPI_StringToObj(api_data, tempStr, CLen(tempStr), &getPropertyRec->resultObjRef);
					break;
				case kName:
					if (strP = strrchr(fileRecP->path, '/'))
					{	if (strpLen = CLen(strP))
						{	strP++;
							strpLen--;
						}
						else
							CDebugStr("Illegal file path (1)");
						err = BAPI_StringToObj(api_data, strP, strpLen, &getPropertyRec->resultObjRef);
					}
					else
						CDebugStr("Illegal file path (2)");
					break;
				case kPerm:
					err = BAPI_IntToObj(api_data, fileRecP->permission, &getPropertyRec->resultObjRef);
					break;
				case kOpenMode:
					err = BAPI_IntToObj(api_data, fileRecP->openMode, &getPropertyRec->resultObjRef);
					break;
				case kLength:
					if (fileRecP->ref)
					{	if NOT(err = GetXEOF(fileRecP->ref, &eof))
							err = BAPI_IntToObj(api_data, eof, &getPropertyRec->resultObjRef);
					}
					else
					{	if NOT(err = GetXEOFFromPath(fileRecP->path, &eof))
							err = BAPI_IntToObj(api_data, eof, &getPropertyRec->resultObjRef);
					}
					break;
				case kResForkLength:
					if NOT(err = GetXResForkSize(fileRecP->path, &eof))
						err = BAPI_IntToObj(api_data, eof, &getPropertyRec->resultObjRef);
					break;
				case kCreatTime:
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
							err = gsTimeRecToObjRef(api_data, &xFileInfo.creatDate, &getPropertyRec->resultObjRef);
					}
					break;
					
				case kModifTime:
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
							err = gsTimeRecToObjRef(api_data, &xFileInfo.modifDate, &getPropertyRec->resultObjRef);
					}
					break;
				case kIsOpen:
					{
					Boolean	isOpen;
					
					if NOT(err = IsXFileOpen(fileRecP->path, &isOpen))
						err = BAPI_BooleanToObj(api_data, isOpen, &getPropertyRec->resultObjRef);
					}
					break;
				case kisAlias:
					err = BAPI_BooleanToObj(api_data, fileRecP->isAlias, &getPropertyRec->resultObjRef);
					break;
				case kMacOSType:
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
							err = BAPI_StringToObj(api_data, (Ptr)&xFileInfo.macosType, sizeof(long), &getPropertyRec->resultObjRef);
					}
					break;
				case kMacOSCreator:
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
							err = BAPI_StringToObj(api_data, (Ptr)&xFileInfo.macosCreator, sizeof(long), &getPropertyRec->resultObjRef);
					}
					break;
				
				case kCurLine:
					if (fileRecP->actLine != kFileEOFValue)
						eof = fileRecP->actLine + 1;
					else
						eof = kFileEOFValue;
					err = BAPI_IntToObj(api_data, eof, &getPropertyRec->resultObjRef);
					break;
				
				case kUser:
				#ifdef __UNIX_XLIB__
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
							err = BAPI_StringToObj(api_data, (Ptr)&xFileInfo.user, CLen(xFileInfo.user), &getPropertyRec->resultObjRef);
					}
				#else
					err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
				#endif
					break;
				
				case kGroup:
				#ifdef __UNIX_XLIB__
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
							err = BAPI_StringToObj(api_data, (Ptr)&xFileInfo.group, CLen(xFileInfo.group), &getPropertyRec->resultObjRef);
					}
				#else
					err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
				#endif
					break;
				
				case kCurPos:
					if NOT(fileRecP->ref)
						err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
					else
					{	if NOT(err = GetXFPos(fileRecP->ref, &eof))
							err = BAPI_IntToObj(api_data, eof, &getPropertyRec->resultObjRef);
					}
					break;
				
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

//===========================================================================================
static XErr	File_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
	SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
	XErr				err = noErr;
	long				aLong, tLen, api_data = pbPtr->api_data, newEOF;
	CStr255				aStr;
	FileRec				*fileRecP;
	BlockRef			fileRecBlock;
	
	tLen = sizeof(BlockRef);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &setPropertyRecP->objRef, (Ptr)&fileRecBlock, &tLen, 0, nil))
	{	
		fileRecP = (FileRec*)GetPtr(fileRecBlock);
		switch(setPropertyRecP->propertyID)
		{
			case kPath:
			case kName:
				err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
				break;
			case kPerm:
				if NOT(err = BAPI_ObjToInt(api_data, &setPropertyRecP->value, &aLong, kImplicitTypeCast))
				{	if ((aLong == READ_WRITE_PERM) || (aLong == READ_PERM))
					{	
						fileRecP->permission = aLong;
						// err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&fileRec, sizeof(FileRec));
					}
					else
						err = XError(kBAPI_ClassError, ErrBadPermission);
				}
				break;
			case kOpenMode:
				if NOT(err = BAPI_ObjToInt(api_data, &setPropertyRecP->value, &aLong, kImplicitTypeCast))
				{	if ((aLong >= CREATE_FILE_NEW) && (aLong <= DONT_OPEN))
					{	
						fileRecP->openMode = aLong;
						// err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&fileRec, sizeof(FileRec));
					}
					else
						err = XError(kBAPI_ClassError, ErrBadOpenMode);
				}
				break;
			case kLength:
				if (fileRecP->ref)
				{	if NOT(err = BAPI_ObjToInt(api_data, &setPropertyRecP->value, &newEOF, kImplicitTypeCast))
					{	if (newEOF >= 0)
							err = SetXEOF(fileRecP->ref, newEOF);
						else
							err = XError(kBAPI_ClassError, ErrBadLen);
					}
				}
				else
					err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
				break;
			case kResForkLength:
				err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
				break;
			case kCreatTime:
				{	XFileInfo	xFileInfo;

					if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
					{	if NOT(err = gsObjRefToTimeRec(api_data, &setPropertyRecP->value, &xFileInfo.creatDate))
							err = SetXFileInfo(fileRecP->path, &xFileInfo);
					}
				}
				break;
			case kModifTime:
				{	XFileInfo	xFileInfo;

					if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
					{	if NOT(err = gsObjRefToTimeRec(api_data, &setPropertyRecP->value, &xFileInfo.modifDate))
							err = SetXFileInfo(fileRecP->path, &xFileInfo);
					}
				}
				break;
			case kIsOpen:
			case kisAlias:
				err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
				break;
			case kMacOSType:
				if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aStr, nil, 255, kImplicitTypeCast))
				{	if (CLen(aStr) == sizeof(long))
					{	XFileInfo	xFileInfo;
					
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
						{	xFileInfo.macosType = *(long*)aStr;
							err = SetXFileInfo(fileRecP->path, &xFileInfo);
						}
					}
					else
						err = XError(kBAPI_ClassError, ErrBadOSTypeOrCreator);
				}
				break;
			case kMacOSCreator:
				if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aStr, nil, 255, kImplicitTypeCast))
				{	if (CLen(aStr) == sizeof(long))
					{	XFileInfo	xFileInfo;
					
						if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
						{	xFileInfo.macosCreator = *(long*)aStr;
							err = SetXFileInfo(fileRecP->path, &xFileInfo);
						}
					}
					else
						err = XError(kBAPI_ClassError, ErrBadOSTypeOrCreator);
				}
				break;
				
			case kCurLine:
				err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
				break;
			
			case kUser:
			#ifdef __UNIX_XLIB__
				if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aStr, nil, 63, kImplicitTypeCast))
				{	XFileInfo	xFileInfo;
					
					if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
					{	CEquStr(xFileInfo.user, aStr);
						err = SetXFileInfo(fileRecP->path, &xFileInfo);
					}
				}
			#endif
				break;
				
			case kGroup:
			#ifdef __UNIX_XLIB__
				if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aStr, nil, 63, kImplicitTypeCast))
				{	XFileInfo	xFileInfo;
					
					if NOT(err = GetXFileInfo(fileRecP->path, &xFileInfo))	
					{	CEquStr(xFileInfo.group, aStr);
						err = SetXFileInfo(fileRecP->path, &xFileInfo);
					}
				}
			#endif
				break;
				
			case kCurPos:
				if NOT(fileRecP->ref)
					err = XError(kBAPI_ClassError, ErrFileIsNotOpen);
				else
				{	if NOT(err = BAPI_ObjToInt(api_data, &setPropertyRecP->value, &aLong, kImplicitTypeCast))
						err = SetXFPos(fileRecP->ref, FROM_START,aLong);
				}
				break;

			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	File_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
	XErr			err = noErr;
	PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
	long			tLen, strLen;
	char			*strP, *p;
	FileRec			*fileRecP;
	BlockRef		fileRecBlock;
	char			aCStr[512];
	CStr63			tStr;
	PrimitiveUnion	*param_d;
	BlockRef		ref;
	Ptr				pathP;
	long			pathLen;
	
	if (typeCast->resultWanted == kCString)
	{	
		tLen = sizeof(BlockRef);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&fileRecBlock, &tLen, 0, nil))
		{	
			fileRecP = (FileRec*)GetPtr(fileRecBlock);
			param_d = &typeCast->result;
			if (param_d->text.variant == kForConstructor)
			{	*aCStr = 0;
				strLen = 0;
				if (tLen)
				{	pathP = fileRecP->path;
					pathLen = CLen(fileRecP->path);
					if NOT(err = StringEscaped(&pathP, &pathLen, &ref))
					{	if (pathLen < 512)
							strLen = CAddStr(aCStr, pathP);
						if (ref)
							DisposeBlock(&ref);
					}
				}
				if NOT(err)
				{	if ((strLen + 1) < 512)
						strLen = CAddStr(aCStr, ",");
					_OpenModeStr(fileRecP->openMode, tStr);
					if ((strLen + CLen(tStr)) < 512)
						strLen = CAddStr(aCStr, tStr);
					if ((strLen + 1) < 512)
						strLen = CAddStr(aCStr, ",");
					_PermissionStr(fileRecP->permission, tStr);
					if ((strLen + CLen(tStr)) < 512)
						strLen = CAddStr(aCStr, tStr);
				}
			}
			else
			{	if (tLen)
				{	strLen = CEquStr(aCStr, "file:/");
					if ((6 + strLen) < 512)
						strLen = CAddStr(aCStr, fileRecP->path);
				}
				else
				{	strLen = 0;
					*aCStr = 0;
				}
			}
			if NOT(err)
			{	strP = aCStr;
				//strLen = CLen(strP);
				p = param_d->text.stringP;
				if (p)
				{	if (param_d->text.stringMaxStorage >= (strLen+1))
					{	CopyBlock(p, strP, strLen);
						p[strLen] = 0;
						param_d->text.stringLen = strLen;
					}
					else
					{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = strLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = strLen;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);

return err;
}

//===========================================================================================
/*static XErr	File_GetErrDescr(Biferno_ParamBlockPtr pbPtr)
{
GetErrDescrRec		*getErrDescrRecP = &pbPtr->param.getErrDescrRec;
short				tErr;

	CEquStr(getErrDescrRecP->errType, "Class file Error");
	if (((tErr = getErrDescrRecP->err) >= START_ERR) && (tErr < lastErr))
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, gFileErrorsStr[tErr - START_ERR]);
	}
	else
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, "Unknown Error");
	}

return noErr;
}

//===========================================================================================
static XErr	File_GetErrNumber(Biferno_ParamBlockPtr pbPtr)
{
GetErrNumber	*getErrNumberP = &pbPtr->param.getErrNumber;
char			*strP = getErrNumberP->errName;

	if NOT(CCompareStrings_cs(strP, "ErrFileIsNotOpen"))
		getErrNumberP->errNumber = ErrFileIsNotOpen;
	else if NOT(CCompareStrings_cs(strP, "ErrBadOffset"))
		getErrNumberP->errNumber = ErrBadOffset;
	else if NOT(CCompareStrings_cs(strP, "ErrBadLen"))
		getErrNumberP->errNumber = ErrBadLen;
	else if NOT(CCompareStrings_cs(strP, "ErrBadOSTypeOrCreator"))
		getErrNumberP->errNumber = ErrBadOSTypeOrCreator;
	else if NOT(CCompareStrings_cs(strP, "ErrPermissionIsNotOpen"))
		getErrNumberP->errNumber = ErrPermissionIsNotOpen;
	else if NOT(CCompareStrings_cs(strP, "ErrBadPermission"))
		getErrNumberP->errNumber = ErrBadPermission;
	else if NOT(CCompareStrings_cs(strP, "ErrBadOpenMode"))
		getErrNumberP->errNumber = ErrBadOpenMode;
	else if NOT(CCompareStrings_cs(strP, "ErrCantOpenAlias"))
		getErrNumberP->errNumber = ErrCantOpenAlias;

return noErr;
}
*/
#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	file_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			fileClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void file(string path, int openMode, int permission=rw)");
			break;
		case kInit:
			err = File_Init(pbPtr);
			break;
		case kShutDown:
			err = File_ShutDown(pbPtr);
			break;
		case kRun:
		#ifdef RANDOM_ERRORS_DEBUG
			gFileTest = 1;
		#endif
			break;
		case kExit:
		/*#ifdef MEM_DEBUG
			if (*pbPtr->plugin_run_dataP)
			{	CStr63	debugStr;
			
				sprintf(debugStr, "file: leaking, %d", (*pbPtr->plugin_run_dataP));
				BAPI_Log(pbPtr->api_data, debugStr);
			}
		#endif*/
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = File_Constructor(pbPtr, message);
			break;
		case kDestructor:
			err = File_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = File_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = File_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = File_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = File_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = File_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


