/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: curScript.c,v 1.16 2008-09-08 14:03:54 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"BfrHeader.h"
#include 	"File.h"
#include 	"Reference.h"

// defines
#define	gsCurScriptPlugName	"curScript"

// Methods
enum{
		kDelay = 1,
		kGetCustomOutput,
		kSetCustomOutput,
		kSetStandardOutput,
		kGetIndVariable,
		kGetIndVariableRef,
		kGetTotVariables,
		//kSetTimeout,
		kIsDef,
		kUndef,
		kGetNumFormat,
		kSetNumFormat,
		kLaunchProcess,
		kValueOf,
		kGetStack,
		kGetIncludeStack
	};
#define TOT_METHODES	15

// Properties
#define TOT_PROPRIETIES	4
enum{
		kbasePath,
		ktimeout,
		kcurrentThreads,
		kmaxThreads
	};

static 	long							gsApiVersion, curScriptClassID, gsStackItemClassID;
static	Ref_NewReferenceCallBack		ref_NewReference;

//===========================================================================================
static XErr	_CurScriptRegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	curScriptProperty[TOT_PROPRIETIES] = 
					{	"basePath",			kbasePath,			"static string",
						"timeout",			ktimeout,			"static unsigned",
						"currentThreads",	kcurrentThreads,	"static int",
						"maxThreads",		kmaxThreads,		"static int"
					};
BAPI_MemberRecord	curScriptMethods[TOT_METHODES] = 
					{	
						"Delay",			kDelay,				"static void Delay(int seconds)",
						"GetCustomOutput",	kGetCustomOutput,	"static string GetCustomOutput(void)",
						"SetCustomOutput",	kSetCustomOutput,	"static void SetCustomOutput(string outputFunction)",
						"SetStandardOutput",kSetStandardOutput,	"static void SetStandardOutput(void)",
						"GetIndVariable",	kGetIndVariable,	"static obj GetIndVariable(int index=1, string *name, boolean sorted=false, string scope=\"local\", int stackIndex)",
						"GetIndVariableRef",kGetIndVariableRef,	"static obj GetIndVariableRef(int index=1, string *name, boolean sorted=false, string scope=\"local\", int stackIndex)",
						"GetTotVariables",	kGetTotVariables,	"static int GetTotVariables(string scope=\"local\", int stackIndex, boolean onlyArguments)",
						//"SetTimeout",		kSetTimeout,		"static void SetTimeout(unsigned minutes)",
						"IsDef",			kIsDef,				"static boolean IsDef(string name)",
						"Undef",			kUndef,				"static void Undef(obj variable)",
						"GetNumFormat",		kGetNumFormat,		"static void GetNumFormat(char *thousSep, char *decimSep)",
						"SetNumFormat",		kSetNumFormat,		"static void SetNumFormat(char thousSep, char decimSep)",
						"LaunchProcess",	kLaunchProcess,		"static boolean LaunchProcess(string executablePath, string commandLineString, boolean waitEnd, unsigned timeout_ms)",
						"ValueOf",			kValueOf,			"static obj ValueOf(string line)",
						"GetStack",			kGetStack,			"static array GetStack()",
						"GetIncludeStack",	kGetIncludeStack,	"static array GetIncludeStack()"
					};

	if (err = BAPI_NewProperties(api_data, curScriptClassID, curScriptProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewMethods(api_data, curScriptClassID, curScriptMethods, TOT_METHODES, nil))
		return err;

//out:
return err;
}

//===========================================================================================
static XErr	__Delay(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr			err = noErr;
unsigned long	secs;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->paramVarsP[0].objRef, &secs, kImplicitTypeCast))
			XDelay(secs * 60);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetCustomOutput(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		funcName;

	if NOT(err = BAPI_GetOutputFunction(api_data, funcName))
		err = BAPI_StringToObj(api_data, funcName, CLen(funcName), &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_SetCustomOutput(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		funcName;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, funcName, nil, 63, kImplicitTypeCast))
		err = BAPI_SetCustomOutput(api_data, funcName);

return err;
}

//===========================================================================================
static XErr	_SetStandardOutput(long api_data)
{
	return BAPI_SetStandardOutput(api_data);
}

//===========================================================================================
/*static XErr	_GetCurrentOutput(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		funcName;

	if NOT(err = BAPI_GetOutputFunction(api_data, funcName))
		err = BAPI_StringToObj(api_data, funcName, CLen(funcName), &exeMethodRecP->resultObjRef);

return err;
}*/

//===========================================================================================
/*static XErr	_SetTimeout(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
unsigned long	minutes;

	if NOT(err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->paramVarsP[0].objRef, &minutes, kImplicitTypeCast))
		err = BAPI_SetTimeout(api_data, minutes * 3600);	// Minutes to ticks

return err;
}
*/
//===========================================================================================
static XErr	_GetTotVariables(ExecuteMethodRec *exeMethodRecP, long api_data)
{
	XErr		err = noErr;
	long		totVars, stackIndex, scope;
	CStr63		cStr;
	Boolean		onlyArguments;
	
	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, cStr, nil, 63, kImplicitTypeCast))
	{	if (*cStr)
			err = BAPI_ScopeID(api_data, cStr, &scope);
		else
			scope = LOCAL;
		if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &stackIndex, kImplicitTypeCast))
		{	
			if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &onlyArguments, kImplicitTypeCast))
			{	
				if NOT(err = BAPI_GetListTotVariablesExt(api_data, scope, stackIndex, onlyArguments, &totVars))
					err = BAPI_IntToObj(api_data, totVars, &exeMethodRecP->resultObjRef);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_GetIndVariable(ExecuteMethodRec *exeMethodRecP, long api_data, Boolean getRef)
{
XErr		err = noErr;
long		stackIndex, index, scope;
CStr63		cStr;
Boolean		isInit, sorted;
ObjRef		tempObjRef, *tObjP;
//BlockRef	targetPropBlockRef;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &sorted, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[3].objRef, cStr, nil, 63, kImplicitTypeCast))
			{	if (*cStr)
					err = BAPI_ScopeID(api_data, cStr, &scope);
				else
					scope = LOCAL;
				if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[4].objRef, &stackIndex, kImplicitTypeCast))
				{	if NOT(err = BAPI_GetListIndVariable(api_data, index, scope, sorted, cStr, stackIndex, &tempObjRef))
					{	if (getRef)
							err = ref_NewReference(api_data, &tempObjRef, 0, &exeMethodRecP->resultObjRef);
						else
							err = BAPI_Clone(api_data, &tempObjRef, &exeMethodRecP->resultObjRef, false);
						if NOT(err)
						{	tObjP = &exeMethodRecP->paramVarsP[1].objRef;
							if NOT(err = BAPI_IsVariableInitialized(api_data, tObjP, &isInit))
							{	if (isInit)
									err = BAPI_StringToObj(api_data, cStr, CLen(cStr), tObjP);
							}
						}
					}
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_LaunchProcess(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
CStr255			executablePath;
char			commandLineString[512];
Boolean 		waitEnd;
unsigned long	timeout_ms;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, executablePath, nil, 255, kImplicitTypeCast))
	{	
	#ifndef __UNIX_XLIB__
		if NOT(err = BAPI_RealPath(api_data, executablePath, true))	
	#endif	
		{	commandLineString[0] = ' ';
			if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, &commandLineString[1], nil, 511, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &waitEnd, kImplicitTypeCast))
				{	if NOT(err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->paramVarsP[3].objRef, &timeout_ms, kImplicitTypeCast))
					{	err = XLaunchProcess(executablePath, commandLineString, waitEnd, timeout_ms);
						if (err == XError(kXLibError, ErrXThreads_Timeout))
							err = BAPI_BooleanToObj(api_data, true, &exeMethodRecP->resultObjRef);
						else if NOT(err)
							err = BAPI_BooleanToObj(api_data, false, &exeMethodRecP->resultObjRef);
					}
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetTimeout(GetPropertyRec *getPropertyRec, long api_data)
{
XErr			err = noErr;
unsigned long	timeout;

	if NOT(err = BAPI_GetCurrentScriptInfo(api_data, &timeout, nil, nil, nil))
	{	timeout /= (60 * 60);	// ticks -> minutes
		err = BAPI_UnsignedToObj(api_data, timeout, &getPropertyRec->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_IsDef(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr	err = noErr;
CStr63	name;
long	len;
Boolean	exists;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, &len, 63, kImplicitTypeCast))
		{	if (len)
			{	name[len] = 0;
				if NOT(err = BAPI_IsVariableDefined(api_data, name, 0, &exists, nil))
					err = BAPI_BooleanToObj(api_data, exists, &exeMethodRecP->resultObjRef);
			}
			else
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Undef(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;

	err = BAPI_Undef(api_data, &exeMethodRecP->paramVarsP[0].objRef);

return err;
}

//===========================================================================================
static XErr	_ValueOf(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
char		*valuOfStr;
CStr255		aCStr;
long		valuOfLen;
BlockRef	ref;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &valuOfStr, &valuOfLen, &ref, kImplicitTypeCast))
	{	if (valuOfLen)
		{	err = BAPI_Eval(api_data, valuOfStr, valuOfLen, &exeMethodRecP->resultObjRef, true, true);
			if (err)	// == XError(kBAPI_Error, Err_UndefinedIdentifier))
			{	BAPI_ResetError(api_data);
				err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
			}
		}
		else
			err = XError(kBAPI_Error, Err_BadSyntax);
		BAPI_ReleaseBlock(&ref);
	}	

return err;
}

//===========================================================================================
static XErr	_GetCurrentStack(long api_data, ExecuteMethodRec *exeMethodRecP)
{
	long			totItems;
	BlockRef		stackBlock;
	XErr			err = noErr;
	Boolean			stackFixedSize;
	ObjRefP			resultP;
	int				i;
	ObjRef			stackItemObjRef;
	StackRecord		*stackP;
	
	resultP = &exeMethodRecP->resultObjRef;
	if NOT(err = BAPI_GetStack(api_data, &stackBlock, &totItems, &stackFixedSize))
	{	
		if NOT(err = BAPI_ArrayToObj(api_data, stackFixedSize, nil, 0, nil, nil, resultP))
		{	
			if (stackBlock)
			{	
				LockBlock(stackBlock);
				stackP = (StackRecord*)GetPtr(stackBlock);
				for (i = 0; (i < totItems) && NOT(err); i++, stackP++)
				{	
					BAPI_InvalObjRef(api_data, &stackItemObjRef);
					if NOT(err = BAPI_BufferToObj(api_data, (Ptr)stackP, sizeof(StackRecord), gsStackItemClassID, true, nil, &stackItemObjRef))
						err = BAPI_ArrayAddElement(api_data, resultP, "", &stackItemObjRef);
				}
				DisposeBlock(&stackBlock);
			}
		}
	}
	
	return err;
}

//===========================================================================================
static XErr	_GetIncludeStack(long api_data, ExecuteMethodRec *exeMethodRecP)
{
	long				totItems;
	BlockRef			stackBlock;
	XErr				err = noErr;
	ObjRefP				resultP;
	int					i;
	ObjRef				stackItemObjRef;
	IncludeStackRecord	*stackP;
	CStr15				lineStr;
	CStr255				includeStack;
	
	resultP = &exeMethodRecP->resultObjRef;
	if NOT(err = BAPI_GetIncludeStack(api_data, &stackBlock, &totItems))
	{	
		if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, resultP))
		{	
			if (stackBlock)
			{	
				LockBlock(stackBlock);
				stackP = (IncludeStackRecord*)GetPtr(stackBlock);
				for (i = 0; (i < totItems) && NOT(err); i++, stackP++)
				{	
					CEquStr(includeStack, "file:/");
					CAddStr(includeStack, stackP->filePath);
					CAddStr(includeStack, ":");
					CNumToString(stackP->line, lineStr);
					CAddStr(includeStack, lineStr);
					BAPI_InvalObjRef(api_data, &stackItemObjRef);
					if NOT(err = BAPI_StringToObj(api_data, (Ptr)includeStack, CLen(includeStack), &stackItemObjRef))
						err = BAPI_ArrayAddElement(api_data, resultP, "", &stackItemObjRef);
				}
				DisposeBlock(&stackBlock);
			}
		}
	}
	
	return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	curScript_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsCurScriptPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	curScriptClassID = pbPtr->param.registerRec.pluginID;
	
return err;
}

//===========================================================================================
static XErr	curScript_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	if NOT(err = BAPI_GetSymbol(0,  BAPI_ClassIDFromName(api_data, "ref", false), "Ref_NewReference", (long*)&ref_NewReference))
	{	gsStackItemClassID = BAPI_ClassIDFromName(api_data, "stackItem", false);
		err = _CurScriptRegisterListMembers(api_data);
	}
		
return err;
}

//===========================================================================================
static XErr	curScript_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
	XErr				err = noErr;
	ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
	long 				api_data = pbPtr->api_data;
	long				totParams = exeMethodRecP->totParams;
	Byte				thousSep, decSep;
	Boolean				isInit;
	
	switch(exeMethodRecP->methodID)
	{
		case kDelay:
			err = __Delay(exeMethodRecP, totParams, api_data);
			break;
		case kGetCustomOutput:
			err = _GetCustomOutput(exeMethodRecP, api_data);
			break;
		case kSetCustomOutput:
			err = _SetCustomOutput(exeMethodRecP, api_data);
			break;
		case kSetStandardOutput:
			err = _SetStandardOutput(api_data);
			break;
		case kGetIndVariable:
			err = _GetIndVariable(exeMethodRecP, api_data, false);
			break;
		case kGetIndVariableRef:
			err = _GetIndVariable(exeMethodRecP, api_data, true);
			break;
		case kGetTotVariables:
			err = _GetTotVariables(exeMethodRecP, api_data);
			break;
			/*case kSetTimeout:
			 err = _SetTimeout(exeMethodRecP, api_data);
			 break;*/
		case kIsDef:
			err = _IsDef(exeMethodRecP, totParams, api_data);
			break;
		case kUndef:
			err = _Undef(exeMethodRecP, api_data);
			break;
		case kGetNumFormat:
			if NOT(err = BAPI_GetNumberFormat(api_data, &thousSep, &decSep))
			{	
				if (NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[0].objRef, &isInit)) && isInit)
					err = BAPI_CharToObj(api_data, thousSep, &exeMethodRecP->paramVarsP[0].objRef);
				if NOT(err)
				{	
					if (NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[1].objRef, &isInit)) && isInit)
						err = BAPI_CharToObj(api_data, decSep, &exeMethodRecP->paramVarsP[1].objRef);
				}
			}
			break;
		case kSetNumFormat:
			if (exeMethodRecP->totParams == 2)
			{	
				Byte	decSep[2], thousSep[2];
				
				if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, (Ptr)thousSep, nil, 2, kImplicitTypeCast))
				{	
					if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, (Ptr)decSep, nil, 2, kImplicitTypeCast))
						err = BAPI_SetNumberFormat(api_data, *thousSep, *decSep);
					else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
					{	
						err = XError(kBAPI_Error, Err_IllegalTypeCast);
						CEquStr(pbPtr->error, "thousandSep must be a char");
					}
				}
				else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
				{	
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
					CEquStr(pbPtr->error, "decimSep must be a char");
				}
			}
			else
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
			break;
		case kLaunchProcess:
			err = _LaunchProcess(exeMethodRecP, api_data);
			break;
		case kValueOf:
			err = _ValueOf(exeMethodRecP, api_data);
			break;
		case kGetStack:
			err = _GetCurrentStack(api_data, exeMethodRecP);
			break;
		case kGetIncludeStack:
			err = _GetIncludeStack(api_data, exeMethodRecP);
			break;
	}
	
	return err;
}

//===========================================================================================
static XErr	curScript_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			api_data = pbPtr->api_data, aLong;
CStr255			aCStr, basePath;

	switch(getPropertyRec->propertyID)
	{
		case kbasePath:
			if NOT(err = BAPI_GetCurrentScriptInfo(api_data, nil, nil, nil, basePath))
			{	CEquStr(aCStr, FILE_HD_PREFIX);
				CAddStr(aCStr, basePath);
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRec->resultObjRef);
			}
			break;
		case ktimeout:
			err = _GetTimeout(getPropertyRec, api_data);
			break;
		case kcurrentThreads:
			if NOT(err = BAPI_GetCurrentScriptInfo(api_data, nil, &aLong, nil, nil))
				err = BAPI_IntToObj(api_data, aLong, &getPropertyRec->resultObjRef);
			break;
		case kmaxThreads:
			if NOT(err = BAPI_GetCurrentScriptInfo(api_data, nil, nil, &aLong, nil))
				err = BAPI_IntToObj(api_data, aLong, &getPropertyRec->resultObjRef);
			break;
		default:
			break;
	}

return err;
}

//===========================================================================================
static XErr	curScript_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;
unsigned long	minutes;
long			api_data = pbPtr->api_data;

	switch(setPropertyRec->propertyID)
	{
		case kbasePath:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		case ktimeout:
			if NOT(err = BAPI_ObjToUnsigned(api_data, &setPropertyRec->value, &minutes, kImplicitTypeCast))
				err = BAPI_SetTimeout(api_data, minutes * 3600);	// Minutes to ticks
			break;
		case kcurrentThreads:
		case kmaxThreads:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	curScript_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = curScript_Register(pbPtr);
			break;
		case kInit:
			err = curScript_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = curScript_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = curScript_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = curScript_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


