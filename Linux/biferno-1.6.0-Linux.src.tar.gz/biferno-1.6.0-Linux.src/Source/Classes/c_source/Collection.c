/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Collection.c,v 1.1 2008-06-13 14:25:57 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BifernoEngineAPI.h"
#include 	"StaticClasses.h"

// defines
#define	gsPlugName	"collection"

// Methods
enum{
	kGet = 1,
	kGetByName,
	kName,
	kAdd,
	kDelete,
};
#define TOT_METHODES	5

// Properties
enum{
	kDim
	//kObject
};
#define TOT_PROPRIETIES	1

typedef struct CollectionRec
{
	DLMRef		list;
} CollectionRec;

static 	long	collectionClassID, gsStringClassId;
static 	long	gsApiVersion;

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
	XErr				err = noErr;
	BAPI_MemberRecord	collectionProperty[TOT_PROPRIETIES] = 
	{	
		"dim",		kDim,		"int"
		//"object[]", kObject,	"obj"
	};
	
	BAPI_MemberRecord	collectionMethods[TOT_METHODES] = 
	{	
		"Get",		kGet,		"obj Get(int index)",
		"GetByName",kGetByName,	"obj GetByName(string name)",
		"Name",		kName,		"string Name(int index)",
		"Add",		kAdd,		"void Add(nonames obj element...)",
		"Delete",	kDelete, 	"void Delete(int index)"
	};
	
	if (err = BAPI_NewProperties(api_data, collectionClassID, collectionProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewMethods(api_data, collectionClassID, collectionMethods, TOT_METHODES, nil))
		return err;
	
	gsStringClassId = BAPI_ClassIDFromName(api_data, "string", true);
	
	return noErr;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_Add(Biferno_ParamBlockPtr pbPtr, CollectionRec *collectionRecP, ExecuteMethodRec *exeMethodRecP)
{
	XErr			err = noErr;
	ObjRecord		clonedObj;
	long			i, destId;
	long			api_data = pbPtr->api_data;
	int				totElems = exeMethodRecP->totParams;
	ParameterRec	*paramP;
	
	for (i = 0; i < totElems; i++)
	{	
		paramP = &exeMethodRecP->paramVarsP[i];
		BAPI_InvalObjRef(api_data, (ObjRefP)&clonedObj);
		if not(err = BAPI_Clone(api_data, &paramP->objRef, (ObjRefP)&clonedObj, false))
		{
			err = DLM_CopyObj(clonedObj.list, clonedObj.id, collectionRecP->list, paramP->name, -1, &destId);
		}
	}
	return err;
}

//===========================================================================================
static XErr	_Delete(Biferno_ParamBlockPtr pbPtr, CollectionRec *collectionRecP, ExecuteMethodRec *exeMethodRecP)
{
	XErr		err = noErr;
	long		api_data = pbPtr->api_data, index;
	ObjRecord	objToDelete;
	
	if not(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
	{
		objToDelete.list = collectionRecP->list;
		objToDelete.id = index;
		if not(err = DLM_GetInfo(collectionRecP->list, objToDelete.id, nil, &objToDelete.classID, nil))
		{
			objToDelete.type = OBJ_TYPE(exeMethodRecP->objRef);	
			objToDelete.scope = OBJ_SCOPE(exeMethodRecP->objRef);
			if not(err = BAPI_Destructor(api_data, (ObjRefP)&objToDelete))
				err = DLM_DeleteObj(collectionRecP->list, index, nil, 0);
		}
	}
	return err;
}

//===========================================================================================
static XErr	_Get(Biferno_ParamBlockPtr pbPtr, CollectionRec *collectionRecP, ObjRef *thisObjRefP, int index, Boolean wantName,  ObjRef *resultObjRefP)
{
	XErr		err = noErr;
	ObjRecord	resultObj;
	long		api_data = pbPtr->api_data;
	CStr63		name;
	
	resultObj.list = collectionRecP->list;
	resultObj.id = index;
	if not(err = DLM_GetInfo(collectionRecP->list, resultObj.id, nil, &resultObj.classID, name))
	{
		resultObj.type = OBJ_TYPE_P(thisObjRefP);	
		resultObj.scope = OBJ_SCOPE_P(thisObjRefP);
		if (wantName)
			err = BAPI_StringToObj(api_data, name, CLen(name), resultObjRefP);
		else
			err = BAPI_Clone(api_data, (ObjRefP)&resultObj, resultObjRefP, false);
	}
	
	return err;
}

//===========================================================================================
static XErr	_GetByName(Biferno_ParamBlockPtr pbPtr, CollectionRec *collectionRecP, ObjRef *thisObjRefP, char *objName,  ObjRef *resultObjRefP)
{
	XErr		err = noErr;
	ObjRecord	resultObj;
	long		objId, api_data = pbPtr->api_data;
	
	if (objId = DLM_GetObjID(collectionRecP->list, objName, nil, &resultObj.classID))
	{
		resultObj.list = collectionRecP->list;
		resultObj.id = objId;
		resultObj.type = OBJ_TYPE_P(thisObjRefP);	
		resultObj.scope = OBJ_SCOPE_P(thisObjRefP);
		err = BAPI_Clone(api_data, (ObjRefP)&resultObj, resultObjRefP, false);
	}
	else
		err = XError(kBAPI_Error, Err_ObjectNotFound);
	
	return err;
}

//===========================================================================================
static XErr	_GetAll(Biferno_ParamBlockPtr pbPtr, CollectionRec *collectionRecP, ObjRef *thisObjRefP, ObjRef *resultObjRefP)
{
	XErr		err = noErr;
	ObjRecord	resultObj;
	long		i, totObjs, api_data = pbPtr->api_data;
	CStr63		name;
	ObjRef		resultVar, theArray;
	
	BAPI_InvalObjRef(api_data, &theArray);
	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &theArray))
	{
		if not(err = DLM_GetTotObjs(collectionRecP->list, &totObjs, false))
		{
			for (i = 1; (i <= totObjs) && not(err); i++)
			{
				resultObj.list = collectionRecP->list;
				resultObj.id = i;
				if not(err = DLM_GetInfo(collectionRecP->list, resultObj.id, nil, &resultObj.classID, name))
				{
					resultObj.type = OBJ_TYPE_P(thisObjRefP);	
					resultObj.scope = OBJ_SCOPE_P(thisObjRefP);
					
					if not(err = BAPI_TypeCast(api_data, (ObjRefP)&resultObj, gsStringClassId, &resultVar, kExplicitTypeCast))
					{
						err = BAPI_ArrayAddElement(api_data, &theArray, name, &resultVar);
					}
				}
			}
		}
	}
	if not(err)
		*resultObjRefP = theArray;
	
	return err;
}

//===========================================================================================
static XErr	_Dim(Biferno_ParamBlockPtr pbPtr, CollectionRec *collectionRecP, GetPropertyRec *getPropertyRecP)
{
	XErr		err = noErr;
	long		api_data = pbPtr->api_data, totObjs;
	
	if not(err = DLM_GetTotObjs(collectionRecP->list, &totObjs, false))
	{
		err = BAPI_IntToObj(api_data, totObjs, &getPropertyRecP->resultObjRef);
		
	}
	
	return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Collection_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	collectionClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.wantDestructor = true;
	pbPtr->param.registerRec.fixedSize = true;
	CEquStr(pbPtr->param.registerRec.constructor, "void collection(void)");
		
return err;
}

//===========================================================================================
static XErr	Collection_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _RegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	Collection_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
	XErr			err = noErr;
	ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
	long			tLen, api_data = pbPtr->api_data;
	CollectionRec	collectionRec;
	long			listGlobal, tscope;
	
	if (clone && (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP->objRef) == collectionClassID))
	{	
		CollectionRec newCollectionRec;
		
		tLen = sizeof(CollectionRec);
		if NOT(err = BAPI_ReadObj(api_data, &constructorRecP->varRecsP->objRef, (Ptr)&collectionRec, &tLen, 0, nil))
		{	
			if NOT(err = DLM_CloneList(collectionRec.list, &newCollectionRec.list))
			{	
				if (err = BAPI_BufferToObj(api_data, (Ptr)&newCollectionRec, sizeof(CollectionRec), collectionClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
					DLM_Dispose(&newCollectionRec.list, nil, 0);
			}
		}
	}
	else
	{	
		tscope = BAPI_ConstructorScope(api_data, constructorRecP->privateData);
		if ((tscope == APPLICATION) || (tscope == PERSISTENT))
			listGlobal = GLOBAL_LIST;
		else
			listGlobal = LOCAL_LIST;
		if NOT(err = DLM_CreateAcceptDupl(&collectionRec.list, NAME_LIST, listGlobal))
		{	
			if (err = BAPI_BufferToObj(api_data, (Ptr)&collectionRec, sizeof(CollectionRec), collectionClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
				DLM_Dispose(&collectionRec.list, nil, 0);
		}
	}
	
	return err;
}

//===========================================================================================
static XErr	Collection_Destructor(Biferno_ParamBlockPtr pbPtr)
{
	XErr			err = noErr;
	DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
	CollectionRec	collectionRec;
	long			objLen;
	Boolean			needSer;
	
	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	
		if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(CollectionRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&collectionRec, &objLen, 0, nil))
		{	
			if (objLen)
			{	
				DLM_Dispose(&collectionRec.list, nil, 0);
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
	return err;
}

//===========================================================================================
static XErr	Collection_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
	XErr				err = noErr;
	ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
	long 				index, tLen, api_data = pbPtr->api_data;
	CollectionRec		collectionRec;
	Boolean				needSer;
	CStr63				name;
	
	tLen = sizeof(CollectionRec);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&collectionRec, &tLen, 0, nil))
	{	
		if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
			err = BAPI_NeedSerialize(api_data, &exeMethodRecP->objRef, &needSer);
		else
			needSer = false;
		if NOT(err)
		{	
			if (needSer)
				XThreadsEnterCriticalSection();
			switch(exeMethodRecP->methodID)
			{
				case kGet:
					if not(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
						err = _Get(pbPtr, &collectionRec, &exeMethodRecP->objRef, index, false, &exeMethodRecP->resultObjRef);
					break;
				case kGetByName:
					if not(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, nil, 64, kImplicitTypeCast))
						err = _GetByName(pbPtr, &collectionRec, &exeMethodRecP->objRef, name, &exeMethodRecP->resultObjRef);
					break;
				case kName:
					if not(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
						err = _Get(pbPtr, &collectionRec, &exeMethodRecP->objRef, index, true, &exeMethodRecP->resultObjRef);
					break;
				case kAdd:
					err = _Add(pbPtr, &collectionRec, exeMethodRecP);
					break;
				case kDelete:
					err = _Delete(pbPtr, &collectionRec, exeMethodRecP);
					break;
				default:
					err = XError(kBAPI_Error, Err_NoSuchMethod);
					break;
			}
			if (needSer)
				XThreadsLeaveCriticalSection();
		}
	}
	
	return err;
}

//===========================================================================================
static XErr	Collection_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
	GetPropertyRec	*getPropertyRecP = &pbPtr->param.getPropertyRec;
	XErr			err = noErr;
	CollectionRec	collectionRec;
	long			tLen, api_data = pbPtr->api_data;
	Boolean			needSer;
	// char			*propIndNameP = getPropertyRecP->propertyIndex[0].ind_name;
	
	if (BAPI_IsObjRefValid(api_data, &getPropertyRecP->objRef))
		err = BAPI_NeedSerialize(api_data, &getPropertyRecP->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	
		if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(CollectionRec);
		if NOT(err = BAPI_ReadObj(api_data, &getPropertyRecP->objRef, (Ptr)&collectionRec, &tLen, 0, nil))
		{	
			switch(getPropertyRecP->propertyID)
			{
				case kDim:
					err = _Dim(pbPtr, &collectionRec, getPropertyRecP);
					break;
				/*case kObject:
					if (index = getPropertyRecP->propertyIndex[0].ind)
					{	
						err = _Get(pbPtr, &collectionRec, &getPropertyRecP->objRef, index, false, &getPropertyRecP->resultObjRef);
					}
					else if (*propIndNameP)
					{	
						err = _GetByName(pbPtr, &collectionRec, &getPropertyRecP->objRef, propIndNameP, &getPropertyRecP->resultObjRef);					}
					else
					{	
						err = _GetAll(pbPtr, &collectionRec, &getPropertyRecP->objRef, &getPropertyRecP->resultObjRef);
					}
					break;*/
					
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
	return err;
}
//===========================================================================================
static XErr	Collection_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
	SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
	XErr			err = noErr;
	
	switch(setPropertyRec->propertyID)
	{
		case kDim:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
			
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}
	
	return err;
}

//===========================================================================================
static XErr	Collection_Primitive(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(pbPtr)
#endif
	XErr			err = noErr;
	PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
	long			tLen;
	CollectionRec	collectionRec;
	PrimitiveUnion	*param_d;
	Boolean			needSer;
	
	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, &needSer))
	{	
		if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(CollectionRec);
		param_d = &typeCast->result;
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&collectionRec, &tLen, 0, nil))
		{	
			switch (typeCast->resultWanted)
			{	
				case kCString:
					break;
					
				case kChar:
					break;
					
				case kBool:
					break;
					
				default:
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
					break;
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
	return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	collection_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = Collection_Register(pbPtr);
			break;
		case kInit:
			err = Collection_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
			err = Collection_Constructor(pbPtr, false);
			break;
		case kTypeCast:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kClone:
			err = Collection_Constructor(pbPtr, true);
			break;
		case kDestructor:
			err = Collection_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Collection_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Collection_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Collection_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = Collection_Primitive(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


