/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Boolean.c,v 1.7 2004-05-04 13:21:46 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

static long	boolClassID;
static long		gsApiVersion;

// Proprieties
// no proprieties

// Methodes
// no methodes

#define	gsBoolPlugName		"boolean"


//===========================================================================================
// Ci si deve registrare dando il nome della classe (costruttore), dicendo di 
// che tipo � il plugin e ricevendo la propria classID
/*static XErr	Bool_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;

	
return err;
}*/

//===========================================================================================
// Finalizzazioni
static XErr	Bool_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	boolClassID = 0;
	
return noErr;
}

//===========================================================================================
// Data una sequenza di caratteri (constructorRecP->data), o una sequenza di obj (varRecsP) 
// si deve creare un oggetto di tipo inta usando la callback "BAPI_BufferToObj"
static XErr	Bool_Constructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data;
Boolean			aBool;
//BlockRef		dataBlock = 0;

	/*if (constructorRecP->dataP)
	{	if (constructorRecP->isString == INTERNAL)
		{	aBool = *(Boolean*)constructorRecP->dataP;
			err = BAPI_BufferToObj(api_data, &aBool, sizeof(Boolean), boolClassID, true, nil, constructorRecP->scope, constructorRecP->type, &constructorRecP->resultObjRef);
		}
		else
		{	aBool = (constructorRecP->dataLen != 0);
			err = BAPI_BufferToObj(api_data, &aBool, sizeof(Boolean), boolClassID, true, nil, constructorRecP->scope, constructorRecP->type, &constructorRecP->resultObjRef);
		}
	}
	else 
	*/
	
	if (constructorRecP->totVars == 1)
	{	if (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP[0].objRef) == boolClassID)
			err = BAPI_CopyObj(api_data, &constructorRecP->varRecsP[0].objRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
		else
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &constructorRecP->varRecsP->objRef, &aBool, kImplicitTypeCast))
				err = BAPI_BufferToObj(api_data, &aBool, sizeof(aBool), boolClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "boolean(obj param)");
	}
	
	//if NOT(err)
	//	BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, boolClassID);
		//constructorRecP->resultObjRef.classID = boolClassID;
		
return err;
}

//===========================================================================================
// Il risultato va messo in objRef1
static XErr	Bool_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err= noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				operation = exeOperationRecP->operation;
long				api_data = pbPtr->api_data;
Boolean				item1, item2, boolres;

	if NOT(err = BAPI_ObjToBoolean(api_data, &exeOperationRecP->objRef1, &item1, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeOperationRecP->objRef2, &item2, kImplicitTypeCast))
		{	switch(operation)
			{	case EVAL_MULT:
					boolres = item1 * item2;
					break;
				case EVAL_DIV:
					boolres = item1 / item2;
					break;
				case EVAL_MOD:
					boolres = item1 % item2;
					break;
				case EVAL_ADD:
					boolres = item1 + item2;
					break;
				case EVAL_MINUS:
					boolres = item1 - item2;
					break;
				case EVAL_SHIFTR:
					boolres = item1 >> item2;
					break;
				case EVAL_SHIFTL:
					boolres = item1 << item2;
					break;
				case EVAL_GTH:
					boolres = item1 > item2;
					break;
				case EVAL_LTH:
					boolres = item1 < item2;
					break;
				case EVAL_GEQ:
					boolres = item1 >= item2;
					break;
				case EVAL_LEQ:
					boolres = item1 <= item2;
					break;
				case EVAL_EQUA:
					boolres = item1 == item2;
					break;
				case EVAL_NEQUA:
					boolres = item1 != item2;
					break;
				case EVAL_ARAND:
					boolres = item1 & item2;
					break;
				case EVAL_AROR:
					boolres = item1 | item2;
					break;
				/*case EVAL_AND:
					boolres = item1 && item2;
					break;
				case EVAL_OR:	
					boolres = item1 || item2;
					break;*/
				default:
					CDebugStr("Unknown operator!");
			}
			err = BAPI_BooleanToObj(api_data, boolres, &exeOperationRecP->resultObjRef);
		}
	}
		
return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	Bool_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr				err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchMethod);

return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	Bool_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	Bool_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr				err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchProperty);
	
return err;
}

//===========================================================================================
static XErr	Bool_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
Boolean			aBool;
CStr255			aCStr;
long			cLen;
Ptr				p;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
PrimitiveUnion	*param_d;
long			tLen, api_data = pbPtr->api_data;
	
	tLen = sizeof(Boolean);
	if NOT(err = BAPI_GetObj(api_data, &typeCast->objRef, (Ptr)&aBool, &tLen, 0, nil))
	{	if NOT(tLen)
			aBool = false;
		param_d = &typeCast->result;
		switch(typeCast->resultWanted)
		{	case kInt:
				param_d->intValue = aBool;
				break;
			case kLong:
				param_d->longValue = aBool;
				break;
			case kUnsigned:
				param_d->uIntValue = aBool;
				break;
			case kDouble:
				param_d->doubleValue = aBool;
				break;
			case kBool:
				param_d->boolValue = aBool;
				break;
			case kCString:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				if (aBool)
					CEquStr(aCStr, "true");
				else
				{	if (param_d->text.variant == kNormal)
						CEquStr(aCStr, "");
					else
						CEquStr(aCStr, "false");
				}
				cLen = CLen(aCStr);
				if (p = param_d->text.stringP)
				{	if (param_d->text.stringMaxStorage >= (cLen + 1))
					{	CopyBlock(p, aCStr, cLen);
						p[cLen] = 0;
						param_d->text.stringLen = cLen;
					}
					else
					{	CopyBlock(p, aCStr, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = cLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = cLen;
				break;
			case kChar:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				if (aBool)
					*param_d->theChar = '1';
				else
					*param_d->theChar = '0';
				break;
			default:
				CDebugStr("Unknown TypeCast Parameter");
				break;
		}
	}


return err;
}


/*//===========================================================================================
// trasformazione dell'obj in long (kInt), u long (kUnsigned), double (kDouble) o boolean (kBool)
static XErr	Bool_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
TypeCast	*TypeCastRecP = &pbPtr->param.standardType;
XErr			err = noErr;
CStr255			aCStr;
BlockRef		dataBlock = 0;
long			which = standardTypeRecP->which;
long			cLen, api_data = pbPtr->api_data;
Boolean			aBool;

	if NOT(err = BAPI_GetObj(api_data, &standardTypeRecP->objRef, (Ptr)&aBool, nil, nil, 0, 0, sizeof(Boolean)))
	{	if (which == kInt)
			standardTypeRecP->intValue = aBool;
		else if (which == kUnsigned)
			standardTypeRecP->uIntValue = aBool;
		else if (which == kDouble)
			standardTypeRecP->doubleValue = aBool;
		else if (which == kBool)
			standardTypeRecP->boolValue = aBool;
		else if (which == kCString)
		{	if (aBool)
				CEquStr(aCStr, "true");
			else
				CEquStr(aCStr, "false");
			cLen = CLen(aCStr);
			if (standardTypeRecP->stringP)
			{	if (standardTypeRecP->stringMaxStorage >= cLen)
				{	CopyBlock(standardTypeRecP->stringP, aCStr, cLen);
					standardTypeRecP->stringLen = cLen;
				}
				else
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
			}
			else
				standardTypeRecP->stringLen = cLen;
		}
	}
	
return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	bool_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsBoolPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			boolClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void boolean(obj var)");
			break;
		case kInit:
			//err = Bool_Init(pbPtr);
			break;
		case kShutDown:
			err = Bool_ShutDown(pbPtr);
			break;
		case kRun:
			// do nothing
			break;
		case kExit:
			// do nothing
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Bool_Constructor(pbPtr);
			break;
		case kDestructor:
			// do nothing
			break;
		case kExecuteOperation:
			err = Bool_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = Bool_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Bool_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Bool_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = Bool_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


