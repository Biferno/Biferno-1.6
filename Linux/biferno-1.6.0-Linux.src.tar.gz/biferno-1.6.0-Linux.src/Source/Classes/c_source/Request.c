/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Request.c,v 1.15 2006-06-26 09:58:12 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"BfrHeader.h"

// defines
//#define	gsPlugName	"request"

// Methods
enum{
		kGetField = 1,
		kRedirect
	};
#define TOT_METHODES	2
// Properties
#define TOT_PROPRIETIES	12
enum{
		kContentType = 1,
		k_Method,
		kUrl,
		kHost,
		kFilePath,
		kPhysicalPath,
		kFileName,
		kSearchArg,
		kReferer,
		kProtocol,
		kScheme,
		kPort
	};

static 	long	gsApiVersion, requestClassID;
//static	CStr255	gServName;

#include <string.h>

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	requestProperty[TOT_PROPRIETIES] = 
					{	"contentType",		kContentType,		"static string",
						"method",			k_Method,			"static string",
						"url",				kUrl,				"static string",
						"host",				kHost,				"static string",
						"filePath",			kFilePath,			"static string",
						"physicalPath",		kPhysicalPath,		"static string",
						"fileName",			kFileName,			"static string",
						//"pathArg",			kPathArg,			"static string",
						"searchArg",		kSearchArg,			"static string",
						"referer",			kReferer,			"static string",
						"protocol",			kProtocol,			"static string",
						"scheme",			kScheme,			"static string",
						"port",				kPort,				"static int"
					};
BAPI_MemberRecord		requestMethods[TOT_METHODES] = 
					{	"GetField",			kGetField, 		"static string GetField(string fieldName)",
						"Redirect",			kRedirect, 		"static void Redirect(string url)"
					};


	if (err = BAPI_NewProperties(api_data, requestClassID, requestProperty, TOT_PROPRIETIES, nil))
		return err;		

	if (err = BAPI_NewMethods(api_data, requestClassID, requestMethods, TOT_METHODES, nil))
		return err;

//out:
return err;
}

//===========================================================================================
static XErr	_GetUrl(long api_data, ObjRef *objRefP)
{
ObjRef			urlObjRef;
XErr			err = noErr;
char			*url;
CStr255			aCStr;
char			*strP, *initStrP, *endStrP;
long			urlLen;
BlockRef		ref;

	if NOT(err = GetHeaderField(api_data, "0", &urlObjRef))
	{	
		if NOT(err = BAPI_GetStringBlock(api_data, &urlObjRef, aCStr, &url, &urlLen, &ref, kExplicitTypeCast))
		{	if (strP = strchr(url, '/'))
			{	initStrP = strP;
				if (endStrP = strchr(strP, ' '))
					err = BAPI_StringToObj(api_data, initStrP, endStrP-initStrP, objRefP);
				else
					err = BAPI_StringToObj(api_data, "", 0, objRefP);
			}
			else
				err = BAPI_StringToObj(api_data, "", 0, objRefP);
			BAPI_ReleaseBlock(&ref);
		}
	}

return err;
}

XErr	_Redirect(long api_data, char *url, long urlLen, Boolean use307, Boolean useMetaEquiv);

#define	_307_LINE	"global pageOut.head.SetField(\"\", \"HTTP/1.1 307 Temporary redirect\")"
#define	_302_LINE	"global pageOut.head.SetField(\"\", \"HTTP/1.1 302 Found\")"
#define	_303_LINE	"global pageOut.head.SetField(\"\", \"HTTP/1.1 303 See other\")"

#define	PRE_STR		"global pageOut.head.AddField(\"Location\", \""
#define	POST_STR	"\")"

#define       HTML_REDIR_PRE  "<html><head><meta http-equiv=\"refresh\" content=\"0;URL="
#define       HTML_REDIR_POST "\"</head></html>"

//===========================================================================================
XErr	_Redirect(long api_data, char *url, long urlLen, Boolean use307, Boolean useMetaEquiv)
{
XErr			err = noErr;
CStr255			protocol;
ObjRef			pageOut, nullString;
Boolean			isDef;
ObjRef			protObjRef;	//, schemeObjRef;
CStr255			aCStr;	//, scheme;
long			totSize;
Ptr				textP;
BlockRef		block;

	if (err = BAPI_IsVariableDefined(api_data, "pageOut", GLOBAL, &isDef, &pageOut))
		goto out;
	if (isDef)
	{	BAPI_InvalObjRef(api_data, &nullString);
		if (err = BAPI_StringToObj(api_data, "", 0, &nullString))
			goto out;
		if (err = BAPI_SetProperty(api_data, &pageOut, "body", 1, nil, &nullString))
			goto out;			
		// get scheme (works only in apache >= 2.2)
		/*BAPI_InvalObjRef(api_data, &schemeObjRef);
		if NOT(err = BAPI_GetHTTPParam(api_data, BAPI_Scheme, &schemeObjRef))
		{	if NOT(err = BAPI_ObjToString(api_data, &schemeObjRef, scheme, nil, 255, kImplicitTypeCast))
			{
				if NOT(CCompareStrings(scheme, "https"))
				*/
				if (useMetaEquiv)
				{
					if NOT(err = BAPI_StandardOutput(api_data, HTML_REDIR_PRE, CLen(HTML_REDIR_PRE), true))
					{	
						if NOT(err = BAPI_StandardOutput(api_data, url, urlLen, true))
						{
							if NOT(err = BAPI_StandardOutput(api_data, HTML_REDIR_POST, CLen(HTML_REDIR_POST), true))
								err = BAPI_Exit(api_data);
						}
					}
				}
				else
				{	
					// Get Protocol
					if (use307)		// make a POST redirect
						CEquStr(aCStr, _307_LINE);
					else
					{	BAPI_InvalObjRef(api_data, &protObjRef);
						if NOT(err = BAPI_GetHTTPParam(api_data, BAPI_Protocol, &protObjRef))
						{	if NOT(err = BAPI_ObjToString(api_data, &protObjRef, protocol, nil, 255, kImplicitTypeCast))
							{	if NOT(CCompareStrings(protocol, "HTTP/1.0"))
									CEquStr(aCStr, _302_LINE);
								else
									CEquStr(aCStr, _303_LINE);
							}
						}
					}
					if NOT(err)
					{	
						if NOT(err = BAPI_Eval(api_data, aCStr, CLen(aCStr), nil, true, false))
						{
							totSize = CLen(PRE_STR) + urlLen + CLen(POST_STR);
							if (block = NewBlockLocked(totSize + 1, &err, &textP))
							{	CEquStr(textP, PRE_STR);
								CAddStr(textP, url);
								CAddStr(textP, POST_STR);
								if NOT(err = BAPI_Eval(api_data, textP, totSize, nil, true, false))
									err = BAPI_Exit(api_data);
								DisposeBlock(&block);
							}
						}
					}
				}
			//}
		//}
	}
		
out:
return err;
}

//===========================================================================================
static XErr	_RedirectUrl(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
//long			totParams = exeMethodRecP->totParams;
CStr255			aCStr;
Ptr				stringP;
long			stringLen;
BlockRef		ref;

	/* err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, url, nil, 200, kImplicitTypeCast);
	if (err)	
	{	if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
		{	err = XError(kBAPI_Error, Err_StringTooLong);
			CEquStr(errorMsg, "Redirect url can't contain more than 200 characters");
		}
	}
	else*/
	
	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP->objRef, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	stringP[stringLen] = 0;
		err = _Redirect(api_data, stringP, stringLen, false, false);
		BAPI_ReleaseBlock(&ref);
	}
		
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Request_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, "request");
	gsApiVersion = pbPtr->param.registerRec.api_version;
	requestClassID = pbPtr->param.registerRec.pluginID;
	err = BAPI_RegisterSymbol(pbPtr->api_data, requestClassID, "Redirect", (long)_Redirect);
	
return err;
}

//===========================================================================================
static XErr	Request_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	//initRecP->plugin_global_data = nil;
	//*gServName = 0;
	//CEquStr(initRecP->constructor, "static void request(void)");
	err = _RegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	Request_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
CStr255				fieldName;

	switch(exeMethodRecP->methodID)
	{
		case kGetField:
			if (exeMethodRecP->totParams == 1)
			{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, fieldName, nil, 255, kImplicitTypeCast))
					err = GetHeaderField(pbPtr->api_data, fieldName, &exeMethodRecP->resultObjRef);
			}
			else
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
			break;
		
		case kRedirect:
			err = _RedirectUrl(pbPtr->api_data, exeMethodRecP);
			break;

		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
	
return err;
}

//===========================================================================================
static XErr	Request_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			api_data = pbPtr->api_data;
CStr255			filePath;

	switch(getPropertyRec->propertyID)
	{
		case kContentType:
			err = GetHeaderField(api_data, "Content-type", &getPropertyRec->resultObjRef);
			break;
		case k_Method:
			err = BAPI_GetHTTPParam(api_data, BAPI_Method, &getPropertyRec->resultObjRef);
			break;
		case kUrl:
			err = _GetUrl(api_data, &getPropertyRec->resultObjRef);
			break;
		case kHost:
			err = BAPI_GetHTTPParam(api_data, BAPI_Domain, &getPropertyRec->resultObjRef);
			break;
		case kFilePath:
			err = BAPI_GetHTTPParam(api_data, BAPI_URL, &getPropertyRec->resultObjRef);
			break;
		case kPhysicalPath:
			if NOT(err = BAPI_GetFilePath(api_data, filePath))
				err = BAPI_StringToObj(api_data, filePath, CLen(filePath), &getPropertyRec->resultObjRef);
			break;
		case kFileName:
			if NOT(err = BAPI_GetFilePath(api_data, filePath))
			{	char	*strP;
				
				if (strP = strrchr(filePath, '/'))
				{	strP++;
					err = BAPI_StringToObj(api_data, strP, CLen(strP), &getPropertyRec->resultObjRef);
				}
			}
			break;
		/*case kPathArg:
			err = BAPI_GetHTTPParam(api_data, BAPI_PathArg, &getPropertyRec->resultObjRef);
			break;*/
		case kSearchArg:
			err = BAPI_GetHTTPParam(api_data, BAPI_SearchArg, &getPropertyRec->resultObjRef);
			break;
		case kReferer:
			err = GetHeaderField(api_data, "Referer", &getPropertyRec->resultObjRef);
			break;
		case kProtocol:
			err = BAPI_GetHTTPParam(api_data, BAPI_Protocol, &getPropertyRec->resultObjRef);
			break;
		case kScheme:
			err = BAPI_GetHTTPParam(api_data, BAPI_Scheme, &getPropertyRec->resultObjRef);
			break;
		case kPort:
			err = BAPI_GetHTTPParam(api_data, BAPI_Port, &getPropertyRec->resultObjRef);
			break;
			
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
static XErr	Request_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	switch(setPropertyRec->propertyID)
	{
		case kContentType:
		case k_Method:
		case kUrl:
		case kHost:
		case kFilePath:
		case kPhysicalPath:
		case kFileName:
		//case kPathArg:
		case kSearchArg:
		case kReferer:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	request_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = Request_Register(pbPtr);
			break;
		case kInit:
			err = Request_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			//if NOT(*gServName)
			//	CEquStr(gServName, pbPtr->param.runRec.serverName);
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Request_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Request_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Request_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		/*case kGetErrDescr:
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


