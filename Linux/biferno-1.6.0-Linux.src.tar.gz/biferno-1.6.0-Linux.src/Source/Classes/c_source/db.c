/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: db.c,v 1.35 2007-12-18 15:55:35 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BDBAPI.h"

#include 	<stdio.h>

#define		MAX_TOTAL_CURSORS	32
#define		MAX_PREPARED		16

// Prepare Record
typedef struct
{		
	PrepareParams		params;
	CStr255				sqlString;
	BlockRef			sqlStringBlock;
	BlockRef			busyBlock;				// array of busy (Boolean)
	BlockRef			block;				// array of cursors
	Boolean				busy;
	Byte				pad1;
	short				pad2;
} DBPreparedRec;

typedef struct
{
	short			cursID;
	short			prepareID;
	unsigned long	counter;				// no more than 4G cursor allocation per db instance
} IndexRec;

typedef struct
{
	long		cursProgressive;			// cursor counter increments when a new cursor is requested (never decremented per db)
	long		sp;							// id of the last item of LIFO stack (Stack Pointer)
	long		totPrepared;				// only for class supporting the Prepare command
	BlockRef	preparedBlock;				// block of array of MAX_PREPARED DBPreparedRec
	IndexRec	stack[MAX_TOTAL_CURSORS];	// stack
	Boolean		busy[MAX_TOTAL_CURSORS];	// stack
	// ... follow MAX_TOTAL_CURSORS cursors (each one has a long + sizeOfCursor)
} CursorsRec;
#define	CURSORS_OFF	(offsetof(CursorsRec, busy) + (MAX_TOTAL_CURSORS * sizeof(Boolean)))

typedef struct
{
	long		totRefs;
	long		dbdescrPos;
	BlockRef	connBlockRef;
	Ptr			connPointer;
	long		connBuffLen;
	BlockRef	cursorsBlockRef;		// CursorsRec
	CursorsRec	*cursorsP;				// pointer to CursorsRec
} DBRec;

typedef struct
{		
	CStr63				name;
	Boolean				multiThreadLimited;
	Byte				pad1;
	short				sizeOfCursor;
	short				offsetOfBusy;
	short				pad2;
	BDBAPI_Dispatch		entryPoint;
} DBDescription;

enum {
	kEscape = BDBAPI_LAST_MESSAGE+1,
};

// defines
static long				dbClassID;
static long				gsApiVersion;
static BlockRef			gsDescrBlock;
static DBDescription*	gsDescrBlockP;
static long				gsTotDescrs;

#define gsDBClassName	"db"

XErr	db_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

#define	 	TOT_METHODES	27
#define 	TOT_COSTANTS	7

typedef struct
{		
	long	totDBs;
} DBThreadData;

//===========================================================================================
static void	_SetError(XErr *errP, char *optString, char *strError)
{
CStr15		tStr;
XErr		err = *errP;
CStr255		resultStr;

	*resultStr = 0;
	if NOT(err)
		err = ErrDBMSError;
	CNumToString(err, tStr);
	CEquStr(strError, tStr);
	CAddStr(strError, ":mysql:");
	if (optString)
		CAddStr(strError, optString);
	err = XError(kBAPI_ClassError, ErrDBMSError);
	*errP = err;
}

//===========================================================================================
static XErr	_CallPlugin(DBDescription *dbdescrP, BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;

	err = dbdescrP->entryPoint(message, pbPtr);

return err;
}

//===========================================================================================
static DBDescription* _GetDBDescr(char *name, long *dbdescrIDP)
{
	if (dbdescrIDP && *dbdescrIDP)
	{	int 	id = (*dbdescrIDP) - 1;
		
		if (name)
			CEquStr(name, gsDescrBlockP[id].name);
		return &gsDescrBlockP[id];
	}
	else if (name && *name)
	{	int				i, tot;
		DBDescription	*tDescrP;
	
		tot = gsTotDescrs;
		tDescrP = &gsDescrBlockP[0];
		for (i = 0; i < tot; i++, tDescrP++)
		{	if NOT(CCompareStrings_cs(name, tDescrP->name))
			{	if (dbdescrIDP)
					*dbdescrIDP = i + 1;
				return tDescrP;
			}
		}
	}
	else
		return nil;

return nil;
}

//===========================================================================================
static Ptr	_GetConnBuffer(DBRec *dbRecP)
{
	if (dbRecP->connPointer)
		return dbRecP->connPointer;
	else
		return GetPtr(dbRecP->connBlockRef);
}

//===========================================================================================
static XErr	_ScopeAllowed(long api_data, ObjRefP objP, long scope, Boolean *allowedP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(scope)
#endif
XErr			err = noErr;
long			tLen;
DBRec			dbRec;
DBDescription* 	descrDBP;

	if (scope > GLOBAL)
	{	if (BAPI_IsObjRefValid(api_data, objP))
		{	tLen = sizeof(DBRec);
			if NOT(err = BAPI_ReadObj(api_data, objP, (Ptr)&dbRec, &tLen, 0, nil))
				descrDBP = _GetDBDescr(nil, &dbRec.dbdescrPos);
		}
		else
			descrDBP = nil;
		if NOT(err)
		{	if (descrDBP)
				*allowedP = NOT(descrDBP->multiThreadLimited);
			else
				err = XError(kBAPI_ClassError, ErrUnknownDBType);
		}
	}
		
return err;
}

//===========================================================================================
static XErr	_GetCursorPointer(DBRec *dbRecP, long sizeOfCursor, long prepareID, long cursID, Ptr *cursorPPtr)
{
//Ptr				cursorP = nil;
XErr			/*saveErr = noErr, */err = noErr;
DBPreparedRec	*preparedItemP;
DBDescription	*dbDescrRecP;
Boolean			*busyP;

	if (prepareID)
	{	if ((prepareID > 0) && (prepareID <= MAX_PREPARED))
		{	preparedItemP = &((DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock))[prepareID-1];
			if (preparedItemP->busy)
			{	dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
				busyP = (Boolean*)GetPtr(preparedItemP->busyBlock);
				if (busyP[--cursID])
					*cursorPPtr = GetPtr(preparedItemP->block) + (cursID * dbDescrRecP->sizeOfCursor);
				else
					err = XError(kBAPI_ClassError, ErrBadCursorID);
			}
			else
				err = XError(kBAPI_ClassError, ErrBadPrepareID);
		}
		else
			err = XError(kBAPI_ClassError, ErrBadPrepareID);
	}
	else
	{	if (dbRecP->cursorsP->busy[--cursID])
			*cursorPPtr = (Ptr)dbRecP->cursorsP + CURSORS_OFF + (cursID * sizeOfCursor);
		else
			err = XError(kBAPI_ClassError, ErrBadCursorID);
	}
	
return err;
}

//===========================================================================================
static XErr	_FindOneFreeCursorSlot(DBRec *dbRecP, long *cursIDP, Ptr *cursorPPtr)
{
Ptr				cursorP;
int				i, sizeOfCursor;
DBDescription	*dbDescrRecP;
XErr			err = noErr;
Boolean			*busyP;

	XThreadsEnterCriticalSection();
	if (cursorPPtr)
		*cursorPPtr = nil;
	if (dbRecP->cursorsP->sp >= MAX_TOTAL_CURSORS)
		err = XError(kBAPI_ClassError, ErrTooManyCursors);
	else
	{	*cursIDP = 0;
		dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
		sizeOfCursor = dbDescrRecP->sizeOfCursor;
		cursorP = (Ptr)dbRecP->cursorsP + CURSORS_OFF;
		busyP = &dbRecP->cursorsP->busy[0];
		for (i = 0; i < MAX_TOTAL_CURSORS; i++, cursorP += sizeOfCursor, busyP++)
		{	if NOT(*busyP)
			{	*cursIDP = i+1;
				ClearBlock(cursorP, sizeOfCursor);
				*busyP = true;
				if (cursorPPtr)
					*cursorPPtr = cursorP;
				break;
			}
		}
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
static void	_DisposePrepareCursorSlot(DBRec	*dbRecP, long prepareID)
{
int			count, totItems;
IndexRec	*readP, *writeP;

	if (totItems = dbRecP->cursorsP->sp)
	{	readP = writeP = dbRecP->cursorsP->stack;
		count = 0;
		do
		{	if (readP->prepareID != prepareID)
			{	*writeP++ = *readP;
				count++;
			}
			readP++;
		} while (--totItems);
		dbRecP->cursorsP->sp = count;
	}
}

//===========================================================================================
static XErr	_NewCursorSlot(long api_data, long db_api_data, long prepareID, long internalCursID, long *cursorIDP, Ptr *cursorPPtr)
{	
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
DBRec		*dbRecP = (DBRec*)db_api_data;
IndexRec	*stackP;
XErr		err = noErr;

	if (internalCursID)
	{	if (dbRecP->cursorsP->sp >= MAX_TOTAL_CURSORS)
			err = XError(kBAPI_ClassError, ErrTooManyCursors);
	}
	else
		err = _FindOneFreeCursorSlot(dbRecP, &internalCursID, cursorPPtr);
	if NOT(err)
	{	stackP = &dbRecP->cursorsP->stack[dbRecP->cursorsP->sp++];
		stackP->cursID = (short)internalCursID;
		stackP->prepareID = (short)prepareID;
		stackP->counter = ++dbRecP->cursorsP->cursProgressive;
		*cursorIDP = stackP->counter;
	}
	
return err;
}

//===========================================================================================
static void	_DisposePrepare(long api_data, long db_api_data, DBPreparedRec *preparedItemP, long prepareID, long sizeOfCursor, BDBAPI_CallBack _freePreparedCallBack, long userData, char *error)
{	
int				j;
Ptr				cursorP;
long			totCursors;
BlockRef		bl;
Boolean			*busyP;

	cursorP = GetPtr(preparedItemP->block);
	totCursors = preparedItemP->params.totCursors;
	busyP = (Boolean*)GetPtr(preparedItemP->busyBlock);
	for (j = 0; j < totCursors; j++, cursorP += sizeOfCursor, busyP++)
	{	_freePreparedCallBack(api_data, db_api_data, cursorP, userData, error);
		*busyP = false;
	}
	_DisposePrepareCursorSlot((DBRec*)db_api_data, prepareID);
	if (bl = preparedItemP->sqlStringBlock)
		DisposeBlock(&bl);
	DisposeBlock(&preparedItemP->busyBlock);
	DisposeBlock(&preparedItemP->block);
	preparedItemP->busy = false;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_Connect(long api_data, DBDescription *dbdescrP, char *connString, long connStringLen, BlockRef *connBuffBlockRefP, long *connBuffLenP, Ptr *connPointerP, char *error, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
ConnectRec			*connectRecP = &pb.param.connectRec;

	pb.api_data = api_data;
	pb.db_api_data = (long)dbRecP;
	*pb.error = 0;
	pb.connBufferPtr = nil;
	pb.connBufferLength = 0;
	CEquStr(connectRecP->connString, connString);
	connectRecP->connStringLen = connStringLen;
	if NOT(err = _CallPlugin(dbdescrP, kConnect, &pb))
	{	*connBuffBlockRefP = connectRecP->connBuffer;
		*connBuffLenP = connectRecP->connBufferLength;
		*connPointerP = connectRecP->connPointer;
	}
	CEquStr(error, pb.error);

return err;
}

//===========================================================================================
static XErr	_Disconnect(long api_data, DBDescription *dbdescrP, BlockRef connBuffBlockRef, long connBuffLen, char *error, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
DisconnectRec		*disconnectRecP = &pb.param.disconnectRec;

	pb.api_data = api_data;
	pb.db_api_data = (long)dbRecP;
	*pb.error = 0;
	LockBlock(connBuffBlockRef);
	pb.connBufferPtr = _GetConnBuffer(dbRecP);
	pb.connBufferLength = connBuffLen;
	disconnectRecP->connBuffer = connBuffBlockRef;
	disconnectRecP->connBufferLength = connBuffLen;
	err = _CallPlugin(dbdescrP, kDisconnect, &pb);
	CEquStr(error, pb.error);

return err;
}

//===========================================================================================
static XErr	_FreeResult(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
long				cursID, totParams = exeMethodRecP->totParams;
BDBAPI_ParamBlock	pb;
FreeResultRec		*freeResultRecP = &pb.param.freeResultRec;
long				api_data = pbPtr->api_data;

	if ((totParams == 0) || (totParams == 1))
	{	if (totParams == 1)
			err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cursID, kImplicitTypeCast);
		if NOT(err)
		{	if NOT(cursID)
				cursID = -1;
			LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			freeResultRecP->cursorID = cursID;
			err = _CallPlugin(dbDescrRecP, kFreeResult, &pb);
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_RowSetSize(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
long				size, cursID;
BDBAPI_ParamBlock	pb;
RowSetSizeRec		*rowSetSizeRecP = &pb.param.rowSetSizeRec;
long				api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &size, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &cursID, kImplicitTypeCast))
		{	if NOT(cursID)
				cursID = -1;
			LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			rowSetSizeRecP->cursorID = cursID;
			rowSetSizeRecP->size = size;
			err = _CallPlugin(dbDescrRecP, kRowSetSize, &pb);
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_ExecPrepared(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
long				cursID, totParams = exeMethodRecP->totParams;
BDBAPI_ParamBlock	pb;
ExecPreparedRec		*execPreparedRecP = &pb.param.execPreparedRec;
long				api_data = pbPtr->api_data;

	if ((totParams == 0) || (totParams == 1))
	{	if (totParams == 1)
			err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cursID, kImplicitTypeCast);
		if NOT(err)
		{	if NOT(cursID)
				cursID = -1;
			LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			execPreparedRecP->cursorID = cursID;
			err = _CallPlugin(dbDescrRecP, kExecPrepared, &pb);
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Exec(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP, BDBAPI_Message which)
{
XErr				err = noErr;
CStr255				aStr;
BlockRef			ref = 0;
char				*stringP;
long				rowSetSize, cursorMode, stringLen;
long				cursorID = 0;
BDBAPI_ParamBlock	pb;
ExecRec				*execRecP = &pb.param.execRec;
long				api_data = pbPtr->api_data;
Boolean				freeCurs;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &cursorMode, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &rowSetSize, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[3].objRef, &freeCurs, kImplicitTypeCast))
				{	if NOT(cursorMode)
						cursorMode = kDefault;
					else if ((cursorMode < kDefault) || (cursorMode > kDynamic))
						err = XError(kBAPI_ClassError, ErrBadCursorMode);
					if NOT(err)
					{	LockBlock(dbRecP->connBlockRef);
						pb.api_data = api_data;
						pb.db_api_data = (long)dbRecP;
						*pb.error = 0;
						pb.connBufferPtr = _GetConnBuffer(dbRecP);
						pb.connBufferLength = dbRecP->connBuffLen;
						execRecP->sqlStringP = stringP;
						execRecP->sqlStringLen = stringLen;
						execRecP->onlyPrepare = (which == kPrepare);
						execRecP->cursorMode = (short)cursorMode;
						execRecP->rowSetSize = rowSetSize;
						execRecP->dontReturnCursor = freeCurs;
						if NOT(err = _CallPlugin(dbDescrRecP, which, &pb))
							cursorID = execRecP->cursorID;
						CEquStr(pbPtr->error, pb.error);
						UnlockBlock(dbRecP->connBlockRef);
						if NOT(err)
						{	if (freeCurs)
							{	/*LockBlock(dbRecP->connBlockRef);
								pb.api_data = api_data;
								*pb.error = 0;
								pb.connBufferPtr = _GetConnBuffer(dbRecP);
								pb.connBufferLength = dbRecP->connBuffLen;
								pb.param.freeResultRec.cursorID = cursorID;
								err = _CallPlugin(dbDescrRecP, kFreeResult, &pb);
								CEquStr(pbPtr->error, pb.error);
								UnlockBlock(dbRecP->connBlockRef);
								if NOT(err)*/
								err = BAPI_IntToObj(api_data, 0, &exeMethodRecP->resultObjRef);
							}
							else
								err = BAPI_IntToObj(api_data, cursorID, &exeMethodRecP->resultObjRef);
						}
					}
				}
			}
		}
		BAPI_ReleaseBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_GetPrepared(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
long				cursorID = 0;
BDBAPI_ParamBlock	pb;
GetPreparedRec		*getPreparedRecP = &pb.param.getPreparedRec;
long				prepareID, api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &prepareID, kImplicitTypeCast))
	{	LockBlock(dbRecP->connBlockRef);
		pb.api_data = api_data;
		pb.db_api_data = (long)dbRecP;
		*pb.error = 0;
		pb.connBufferPtr = _GetConnBuffer(dbRecP);
		pb.connBufferLength = dbRecP->connBuffLen;
		getPreparedRecP->prepareID = prepareID;
		if NOT(err = _CallPlugin(dbDescrRecP, kGetPrepared, &pb))
			cursorID = getPreparedRecP->cursorID;
		CEquStr(pbPtr->error, pb.error);
		UnlockBlock(dbRecP->connBlockRef);
		if NOT(err)
			err = BAPI_IntToObj(api_data, cursorID, &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_FreePrepare(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
FreePrepareRec		*freePrepareRecP = &pb.param.freePrepareRec;
long				api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &freePrepareRecP->prepareID, kImplicitTypeCast))
	{	LockBlock(dbRecP->connBlockRef);
		pb.api_data = api_data;
		pb.db_api_data = (long)dbRecP;
		*pb.error = 0;
		pb.connBufferPtr = _GetConnBuffer(dbRecP);
		pb.connBufferLength = dbRecP->connBuffLen;
		err = _CallPlugin(dbDescrRecP, kFreePrepare, &pb);
		CEquStr(pbPtr->error, pb.error);
		UnlockBlock(dbRecP->connBlockRef);
	}

return err;
}

//===========================================================================================
static XErr	_Prepare(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP, BDBAPI_Message which)
{
XErr				err = noErr;
CStr255				aStr;
BlockRef			ref = 0;
char				*stringP;
long				rowSetSize, cursorMode, prepareID, totCursors, stringLen;	//, totParams = exeMethodRecP->totParams;
BDBAPI_ParamBlock	pb;
PrepareRec			*prepareRecP = &pb.param.prepareRec;
long				api_data = pbPtr->api_data;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &totCursors, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &cursorMode, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[3].objRef, &rowSetSize, kImplicitTypeCast))
				{	if NOT(totCursors)
						totCursors = 1;
					if NOT(cursorMode)
						cursorMode = kDefault;
					else if ((cursorMode < kDefault) || (cursorMode > kDynamic))
						err = XError(kBAPI_ClassError, ErrBadCursorMode);
					if NOT(err)
					{	LockBlock(dbRecP->connBlockRef);
						pb.api_data = api_data;
						pb.db_api_data = (long)dbRecP;
						*pb.error = 0;
						pb.connBufferPtr = _GetConnBuffer(dbRecP);
						pb.connBufferLength = dbRecP->connBuffLen;
						prepareRecP->sqlStringP = stringP;
						prepareRecP->sqlStringLen = stringLen;
						prepareRecP->totCursors = totCursors;
						prepareRecP->cursorMode = cursorMode;
						prepareRecP->rowSetSize = rowSetSize;
						prepareRecP->prepareID = 0;
						if NOT(err = _CallPlugin(dbDescrRecP, which, &pb))
							prepareID = prepareRecP->prepareID;
						CEquStr(pbPtr->error, pb.error);
						UnlockBlock(dbRecP->connBlockRef);
						if NOT(err)
							err = BAPI_IntToObj(api_data, prepareID, &exeMethodRecP->resultObjRef);
					}
				}
			}
		}
		BAPI_ReleaseBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_Bind(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP, long which)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
BindRec				*bindRecP = &pb.param.bindRec;
long				theID, api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &bindRecP->paramNum, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, bindRecP->paramObjName, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &bindRecP->paramStorage, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[3].objRef, &bindRecP->paramMode, kImplicitTypeCast))
				{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[4].objRef, &theID, kImplicitTypeCast))
					{	if NOT(bindRecP->paramMode)
							bindRecP->paramMode = kInputBindMode;
						if NOT(bindRecP->paramNum)
							bindRecP->paramNum = 1;
						if (which == kBindAll)
							bindRecP->prepareID = theID;
						else
						{	if NOT(theID)
								theID = -1;
							bindRecP->cursorID = theID;
						}
						LockBlock(dbRecP->connBlockRef);
						pb.api_data = api_data;
						pb.db_api_data = (long)dbRecP;
						*pb.error = 0;
						pb.connBufferPtr = _GetConnBuffer(dbRecP);
						pb.connBufferLength = dbRecP->connBuffLen;
						err = _CallPlugin(dbDescrRecP, which, &pb);
						CEquStr(pbPtr->error, pb.error);
						UnlockBlock(dbRecP->connBlockRef);
					}
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_Call(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP, long which)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
CallRec				*callRecP = &pb.param.callRec;
long				api_data = pbPtr->api_data;
Boolean				isInit, isExt = (which == kCallExt);

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, callRecP->procName, nil, 256, kImplicitTypeCast))
	{	if (isExt)
		{	if (exeMethodRecP->totParams >= 2)
			{	callRecP->totParams = exeMethodRecP->totParams - 2;
				callRecP->params = &exeMethodRecP->paramVarsP[2];
			}
			else
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
		}
		else
		{	if (exeMethodRecP->totParams >= 1)
			{	callRecP->totParams = exeMethodRecP->totParams - 1;
				callRecP->params = &exeMethodRecP->paramVarsP[1];
			}
			else
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
		}
		if NOT(err)
		{	if NOT(callRecP->totParams)
				callRecP->params = nil;
			callRecP->returnValue = &exeMethodRecP->resultObjRef;
			LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			if NOT(err = _CallPlugin(dbDescrRecP, which, &pb))
			{	if (isExt)
				{	if (NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[1].objRef, &isInit)) && isInit)
						err = BAPI_IntToObj(api_data, callRecP->cursorID, &exeMethodRecP->paramVarsP[1].objRef);
				}
			}
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
		}
	}

return err;
}

//===========================================================================================
static XErr	_Seek(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
long				cursID, index, totParams = exeMethodRecP->totParams;
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
SeekRec				*seekRecP = &pb.param.seekRec;
long				api_data = pbPtr->api_data;

	if ((totParams == 1) || (totParams == 2))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
		{	if (index > 0)
			{	if (totParams == 2)
					err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &cursID, kImplicitTypeCast);
				if NOT(cursID)
					cursID = -1;
				if NOT(err)
				{	LockBlock(dbRecP->connBlockRef);
					pb.api_data = api_data;
					pb.db_api_data = (long)dbRecP;
					*pb.error = 0;
					pb.connBufferPtr = _GetConnBuffer(dbRecP);
					pb.connBufferLength = dbRecP->connBuffLen;
					seekRecP->cursorID = cursID;
					seekRecP->pos = index;
					err = _CallPlugin(dbDescrRecP, kSeek, &pb);
					CEquStr(pbPtr->error, pb.error);
					// err = dbDescrRecP->_seek(pbPtr->api_data, GetPtr(dbRecP->connBlockRef), dbRecP->connBuffLen, cursID, index, pbPtr->error);
					UnlockBlock(dbRecP->connBlockRef);
				}
			}
			else
				err = XError(kBAPI_ClassError, ErrBadSeekIndex);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Transaction(Biferno_ParamBlockPtr pbPtr, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
long				api_data = pbPtr->api_data;

	LockBlock(dbRecP->connBlockRef);
	pb.api_data = api_data;
	pb.db_api_data = (long)dbRecP;
	*pb.error = 0;
	pb.connBufferPtr = _GetConnBuffer(dbRecP);
	pb.connBufferLength = dbRecP->connBuffLen;
	err = _CallPlugin(dbDescrRecP, kTransaction, &pb);
	CEquStr(pbPtr->error, pb.error);
	UnlockBlock(dbRecP->connBlockRef);

return err;
}

//===========================================================================================
static XErr	_CommitRollBack(Biferno_ParamBlockPtr pbPtr, DBDescription *dbDescrRecP, DBRec *dbRecP, long which)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
long				api_data = pbPtr->api_data;

	LockBlock(dbRecP->connBlockRef);
	pb.api_data = api_data;
	pb.db_api_data = (long)dbRecP;
	*pb.error = 0;
	pb.connBufferPtr = _GetConnBuffer(dbRecP);
	pb.connBufferLength = dbRecP->connBuffLen;
	err = _CallPlugin(dbDescrRecP, which, &pb);
	CEquStr(pbPtr->error, pb.error);
	UnlockBlock(dbRecP->connBlockRef);

return err;
}

//===========================================================================================
static XErr	_SetSpecific(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
long				api_data = pbPtr->api_data;
SetSpecificRec		*setSpecificRecP = &pb.param.setSpecificRec;
long				cursID;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &cursID, kImplicitTypeCast))
	{	if NOT(cursID)
			cursID = -1;
		if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, setSpecificRecP->name, nil, 256, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, setSpecificRecP->value, nil, 256, kImplicitTypeCast))
			{	LockBlock(dbRecP->connBlockRef);
				pb.api_data = api_data;
				pb.db_api_data = (long)dbRecP;
				*pb.error = 0;
				setSpecificRecP->cursorID = cursID;
				pb.connBufferPtr = _GetConnBuffer(dbRecP);
				pb.connBufferLength = dbRecP->connBuffLen;
				err = _CallPlugin(dbDescrRecP, kSetSpecific, &pb);
				CEquStr(pbPtr->error, pb.error);
				UnlockBlock(dbRecP->connBlockRef);
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetSpecific(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
long				api_data = pbPtr->api_data;
GetSpecificRec		*getSpecificRecP = &pb.param.getSpecificRec;
long				cursID;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &cursID, kImplicitTypeCast))
	{	if NOT(cursID)
			cursID = -1;
		if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, getSpecificRecP->name, nil, 256, kImplicitTypeCast))
		{	LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			getSpecificRecP->cursorID = cursID;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			if NOT(err = _CallPlugin(dbDescrRecP, kGetSpecific, &pb))
				err = BAPI_StringToObj(api_data, getSpecificRecP->value, CLen(getSpecificRecP->value), &exeMethodRecP->resultObjRef);
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_Tell(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
long				cursID, totParams = exeMethodRecP->totParams;
long				offset;
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
TellRec				*tellRecP = &pb.param.tellRec;
long				api_data = pbPtr->api_data;

	if ((totParams == 0) || (totParams == 1))
	{	if (totParams == 1)
			err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cursID, kImplicitTypeCast);
		if NOT(err)
		{	if NOT(cursID)
				cursID = -1;
			LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			tellRecP->cursorID = cursID;
			if NOT(err = _CallPlugin(dbDescrRecP, kTell, &pb))
				offset = tellRecP->pos;
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
			err = BAPI_IntToObj(api_data, offset, &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Warning(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
long				cursID, totParams = exeMethodRecP->totParams;
//long				offset;
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
WarningRec			*warningRecP = &pb.param.warningRec;
long				api_data = pbPtr->api_data;
char				*strP = nil;

	if ((totParams == 0) || (totParams == 1))
	{	if (totParams == 1)
			err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cursID, kImplicitTypeCast);
		if NOT(err)
		{	if NOT(cursID)
				cursID = -1;
			LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			warningRecP->cursorID = cursID;
			if NOT(err = _CallPlugin(dbDescrRecP, kWarning, &pb))
				strP = warningRecP->warning;
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
			if NOT(err)
			{	if (strP)
					err = BAPI_StringToObj(api_data, strP, CLen(strP), &exeMethodRecP->resultObjRef);
				else
					err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_LobWrite(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
LobRec				*lobRecP = &pb.param.lobRec;
long				api_data = pbPtr->api_data;
BlockRef			ref;
ParameterRec		*paramVarsP = exeMethodRecP->paramVarsP;

	LockBlock(dbRecP->connBlockRef);
	pb.api_data = api_data;
	pb.db_api_data = (long)dbRecP;
	*pb.error = 0;
	pb.connBufferPtr = _GetConnBuffer(dbRecP);
	pb.connBufferLength = dbRecP->connBuffLen;
	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[0].objRef, (long*)&lobRecP->locator, kImplicitTypeCast))
	{	if NOT(err = BAPI_GetObjBlock(api_data, &paramVarsP[1].objRef, nil, &lobRecP->buffer, &lobRecP->len, &ref))
		{	// offset 0-based
			if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[2].objRef, (long*)&lobRecP->offset, kImplicitTypeCast))
			{	err = _CallPlugin(dbDescrRecP, kLobWrite, &pb);
				CEquStr(pbPtr->error, pb.error);
			}
			BAPI_ReleaseBlock(&ref);
		}
	}
	UnlockBlock(dbRecP->connBlockRef);

return err;
}

//===========================================================================================
static XErr	_LobRead(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
LobRec				*lobRecP = &pb.param.lobRec;
long				api_data = pbPtr->api_data;
ParameterRec		*paramVarsP = exeMethodRecP->paramVarsP;

	LockBlock(dbRecP->connBlockRef);
	pb.api_data = api_data;
	pb.db_api_data = (long)dbRecP;
	*pb.error = 0;
	pb.connBufferPtr = _GetConnBuffer(dbRecP);
	pb.connBufferLength = dbRecP->connBuffLen;
	BAPI_InvalObjRef(api_data, &lobRecP->outObj);
	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[0].objRef, (long*)&lobRecP->locator, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, (long*)&lobRecP->offset, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[2].objRef, (long*)&lobRecP->len, kImplicitTypeCast))
			{	if NOT(err = _CallPlugin(dbDescrRecP, kLobRead, &pb))
					exeMethodRecP->resultObjRef = lobRecP->outObj;
				CEquStr(pbPtr->error, pb.error);
			}
		}
	}
	UnlockBlock(dbRecP->connBlockRef);

return err;
}

//===========================================================================================
static XErr	_FetchRec(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
long				cursID;
BDBAPI_ParamBlock	pb;
FetchRec			*fetchRecP = &pb.param.fetchRec;
long				api_data = pbPtr->api_data;
Boolean				undefNULL;
Boolean				fetchLocator;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cursID, kImplicitTypeCast))
	{	if NOT(cursID)
			cursID = -1;
		if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &undefNULL, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &fetchLocator, kImplicitTypeCast))
			{	LockBlock(dbRecP->connBlockRef);
				pb.api_data = api_data;
				pb.db_api_data = (long)dbRecP;
				*pb.error = 0;
				pb.connBufferPtr = _GetConnBuffer(dbRecP);
				pb.connBufferLength = dbRecP->connBuffLen;
				fetchRecP->cursorID = cursID;
				fetchRecP->undefNull = undefNULL;
				fetchRecP->fetchLocator = fetchLocator;
				fetchRecP->object = exeMethodRecP->resultObjRef;
				if NOT(err = _CallPlugin(dbDescrRecP, kFetchRec, &pb))
					exeMethodRecP->resultObjRef = fetchRecP->object;
				CEquStr(pbPtr->error, pb.error);
				UnlockBlock(dbRecP->connBlockRef);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
	
return err;
}

//===========================================================================================
static XErr	_GetCurRecs(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
long				totRecs;
long				cursID;
BDBAPI_ParamBlock	pb;
GetCurRecsRec		*getCurRecsRecP = &pb.param.getCurRecsRec;
long				api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cursID, kImplicitTypeCast))
	{	if NOT(cursID)
			cursID = -1;
		LockBlock(dbRecP->connBlockRef);
		pb.api_data = api_data;
		pb.db_api_data = (long)dbRecP;
		*pb.error = 0;
		pb.connBufferPtr = _GetConnBuffer(dbRecP);
		pb.connBufferLength = dbRecP->connBuffLen;
		getCurRecsRecP->cursorID = cursID;
		if NOT(err = _CallPlugin(dbDescrRecP, kGetCurRecs, &pb))
			totRecs = getCurRecsRecP->curRecs;
		CEquStr(pbPtr->error, pb.error);
		UnlockBlock(dbRecP->connBlockRef);
		if NOT(err)
		{	if (totRecs < 0)
				err = XError(kBAPI_ClassError, ErrGettingCurRecs);
			else
				err = BAPI_IntToObj(api_data, totRecs, &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetAffectedRecs(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP)
{
XErr				err = noErr;
long				affectedRecs;
long				cursID;
BDBAPI_ParamBlock	pb;
GetAffectedRecsRec	*getAffectedRecsRecP = &pb.param.getAffectedRecsRec;
long				api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &cursID, kImplicitTypeCast))
	{	if NOT(cursID)
			cursID = -1;
		LockBlock(dbRecP->connBlockRef);
		pb.api_data = api_data;
		pb.db_api_data = (long)dbRecP;
		*pb.error = 0;
		pb.connBufferPtr = _GetConnBuffer(dbRecP);
		pb.connBufferLength = dbRecP->connBuffLen;
		getAffectedRecsRecP->cursorID = cursID;
		if NOT(err = _CallPlugin(dbDescrRecP, kGetAffectedRecs, &pb))
			affectedRecs = getAffectedRecsRecP->affectedRecs;
		CEquStr(pbPtr->error, pb.error);
		UnlockBlock(dbRecP->connBlockRef);
		if NOT(err)
		{	if (affectedRecs < 0)
				err = XError(kBAPI_ClassError, ErrGettingAffectedRecs);
			else
				err = BAPI_IntToObj(api_data, affectedRecs, &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Escape(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP)
{
XErr				err = noErr;
CStr255				aStr;
BlockRef			ref = 0;
char				*stringP;
long				stringLen, api_data = pbPtr->api_data;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	BlockRef	resultBlock;
		long		resultLen;
	
		if NOT(err = BDBAPI_Escape(api_data, 0, stringP, stringLen, &resultBlock, &resultLen))	
		{	LockBlock(resultBlock);
			err = BAPI_StringToObj(pbPtr->api_data, GetPtr(resultBlock), resultLen, &exeMethodRecP->resultObjRef);
			DisposeBlock(&resultBlock);
		}
		BAPI_ReleaseBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_RealEscape(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, DBDescription *dbDescrRecP, DBRec *dbRecP, Boolean unescape)
{
XErr				err = noErr;
BDBAPI_ParamBlock	pb;
RealEscapeRec		*realEscapeRecP = &pb.param.realEscapeRec;
long				stringLen, api_data = pbPtr->api_data;
CStr255				aStr;
BlockRef			ref = 0;
char				*stringP;
Boolean				byteEsc;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &byteEsc, kImplicitTypeCast))
		{	//BlockRef	resultBlock;
			//long		resultLen;
		
			LockBlock(dbRecP->connBlockRef);
			pb.api_data = api_data;
			pb.db_api_data = (long)dbRecP;
			*pb.error = 0;
			pb.connBufferPtr = _GetConnBuffer(dbRecP);
			pb.connBufferLength = dbRecP->connBuffLen;
			realEscapeRecP->resultObj = exeMethodRecP->resultObjRef;
			realEscapeRecP->stringP = stringP;
			realEscapeRecP->stringLen = stringLen;
			realEscapeRecP->byteEsc = byteEsc;
			realEscapeRecP->unescape = unescape;
			realEscapeRecP->pad2 = 0;
			err = _CallPlugin(dbDescrRecP, kRealEscape, &pb);
			if NOT(err)
				exeMethodRecP->resultObjRef = realEscapeRecP->resultObj;
			/*else if (err == XError(kBAPI_Error, Err_BAPI_MessageNotHandled))
			{	if NOT(err = BDBAPI_Escape(api_data, 0, stringP, stringLen, &resultBlock, &resultLen))	
				{	LockBlock(resultBlock);
					err = BAPI_StringToObj(pbPtr->api_data, GetPtr(resultBlock), resultLen, &exeMethodRecP->resultObjRef);
					DisposeBlock(&resultBlock);
				}
			}*/
			CEquStr(pbPtr->error, pb.error);
			UnlockBlock(dbRecP->connBlockRef);
			BAPI_ReleaseBlock(&ref);
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	db_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				api_data = pbPtr->api_data;
BAPI_MemberRecord	dbMethods[TOT_METHODES] = 
					{	"Exec", 			kExec, 				"int Exec(string sql_statement, int mode=defaultMode, int rowSetSize=1, boolean freeCursor)",
						"Call", 			kCall, 				"string Call(string procName, ...)",
						"CallExt", 			kCallExt, 			"string CallExt(string procName, int *cursID, ...)",
						"Prepare", 			kPrepare, 			"int Prepare(string sql_statement, int totPrepared, int mode=defaultMode, int rowSetSize=1)",
						"FreePrepare", 		kFreePrepare, 		"void FreePrepare(int prepareID)",
						"RowSetSize",		kRowSetSize,		"void RowSetSize(int size, int cursorID)",
						"GetPrepared", 		kGetPrepared, 		"int GetPrepared(int prepareID)",
						"Bind", 			kBind, 				"void Bind(int pos, string variableName, int bytes, int mode, int cursorID)",
						"BindAll", 			kBindAll, 			"void BindAll(int pos, string variableName, int bytes, int mode, int prepareID)",
						"ExecPrepared", 	kExecPrepared, 		"void ExecPrepared(int cursorID)",
						"GetCurRecs", 		kGetCurRecs, 		"int GetCurRecs(int cursorID)",
						"GetAffectedRecs",	kGetAffectedRecs,	"int GetAffectedRecs(int cursorID)",
						"FetchRec", 		kFetchRec, 			"array FetchRec(int cursorID, boolean undefNULL, boolean fetchLocator)",
						"Seek",				kSeek,				"void Seek(int index, int cursorID)",
						"Tell",				kTell,				"int Tell(int cursorID)",
						"Warning",			kWarning,			"string Warning(int cursorID)",
						"Free",				kFreeResult,		"void Free(int cursorID)",
						"Escape", 			kEscape, 			"static string Escape(string str)",
						"RealEscape", 		kRealEscape, 		"string RealEscape(string str, boolean byteEsc)",
						"RealUnescape", 	kRealUnescape, 		"string RealUnescape(string str, boolean byteEsc)",
						"Transaction", 		kTransaction, 		"void Transaction(void)",
						"Commit", 			kCommit, 			"void Commit(void)",
						"RollBack", 		kRollBack, 			"void RollBack(void)",
						"GetSpecific", 		kGetSpecific, 		"string GetSpecific(string name, int cursorID)",
						"SetSpecific", 		kSetSpecific, 		"void SetSpecific(string name, string value, int cursorID)",
						"LobWrite", 		kLobWrite, 			"void LobWrite(int locator, string content, int offset)",
						"LobRead", 			kLobRead, 			"string LobRead(int locator, int offset, int len)"
					};

BAPI_MemberRecord	dbCostants[TOT_COSTANTS] = 
					{	"defaultMode", 				kDefault,				"int",
						"staticMode", 				kStatic,				"int",
						"dynamicMode", 				kDynamic,				"int",
						"inputBindMode", 			kInputBindMode,			"int",
						"outputBindMode", 			kOutputBindMode,		"int",
						"inputOutputBindMode", 		kInputOutputBindMode,	"int",
						"null", 					kNull,					"string"
					};

CStr63				dbErrors[BDBAPI_TOT_ERRORS] = 
					{	"ErrDBMSError",
						"ErrGettingCurRecs",
						"ErrGettingAffectedRecs",
						"ErrBadSeekIndex",
						"ErrNotEnoughStorageForRecord",
						"ErrUnknownDBType",
						"ErrBadCursorMode",
						"ErrTooManyCursors",
						"ErrTooManyPrepares",
						"ErrBadPrepareID",
						"ErrBadCursorID",
						"ErrInvalidFree",
						"ErrNoCursorAvailable",
						"ErrUndefinedBindVariable",
						"ErrUnknownSpecific"
					};

	if NOT(err = BAPI_NewMethods(api_data, dbClassID, dbMethods, TOT_METHODES, nil))
	{	if NOT(err = BAPI_RegisterErrors(api_data, dbClassID, BDBAPI_FIRST_ERR, dbErrors, BDBAPI_TOT_ERRORS))
			err = BAPI_NewConstants(api_data, dbClassID, dbCostants, TOT_COSTANTS, nil);
	}
	
return err;
}

//===========================================================================================
static XErr	db_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr	err = noErr;

	dbClassID = 0;
	
return err;
}

//===========================================================================================
static XErr	db_Constructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data;
DBRec			*dbRecP;
BlockRef		dbRecBlock;
long			sizeOfCursorRec, dbdescrPos = 0, init_stringLen;	//, totParams = constructorRecP->totVars;
DBDescription	*dbDescrRecP;
CStr255			dbName, aStr;
Ptr				init_stringP;
BlockRef		ref = 0;
DBThreadData	*dbTDataP;

	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[1].objRef, dbName, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_GetStringBlock(api_data, &constructorRecP->varRecsP[0].objRef, aStr, &init_stringP, &init_stringLen, &ref, kImplicitTypeCast))
		{	if (dbDescrRecP = _GetDBDescr(dbName, &dbdescrPos))
			{	
				if (dbRecBlock = NewBlock(sizeof(DBRec), &err, (Ptr*)&dbRecP))
				{
					ClearBlock(dbRecP, sizeof(DBRec));
					sizeOfCursorRec = sizeof(CursorsRec) + (dbDescrRecP->sizeOfCursor * MAX_TOTAL_CURSORS);
					if (dbRecP->cursorsBlockRef = NewBlockLocked(sizeOfCursorRec, &err, (Ptr*)&dbRecP->cursorsP))
					{	ClearBlock(dbRecP->cursorsP, sizeOfCursorRec);
						dbRecP->dbdescrPos = dbdescrPos;
						if NOT(err = _Connect(api_data, dbDescrRecP, init_stringP, init_stringLen, &dbRecP->connBlockRef, &dbRecP->connBuffLen, &dbRecP->connPointer, pbPtr->error, dbRecP))
						{	dbRecP->totRefs = 1;
							if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&dbRecBlock, sizeof(BlockRef), dbClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
							{	if (pbPtr->plugin_run_dataP && *pbPtr->plugin_run_dataP)
								{	dbTDataP = (DBThreadData*)GetPtr(*pbPtr->plugin_run_dataP);
									dbTDataP->totDBs++;
								}
							}
							else
							{	LockBlock(dbRecP->connBlockRef);
								_Disconnect(api_data, dbDescrRecP, dbRecP->connBlockRef, dbRecP->connBuffLen, pbPtr->error, dbRecP);
								dbRecP->connBlockRef = 0;
							}
						}
						if (err)
							DisposeBlock(&dbRecP->cursorsBlockRef);
					}
					if (err)
						DisposeBlock(&dbRecBlock);
				}
			}
			else
			{	err = XError(kBAPI_ClassError, ErrUnknownDBType);
				CEquStr(pbPtr->error, "db: unknown db type (");
				if (*dbName)
					CAddStr(pbPtr->error, dbName);
				else
					CAddStr(pbPtr->error, "?");
				CAddStr(pbPtr->error, ")");
			}
			if (ref)
				BAPI_ReleaseBlock(&ref);
		}
	}

return err;
}

//===========================================================================================
static XErr	db_Clone(Biferno_ParamBlockPtr pbPtr)
{
DBRec			*dbRecP;
BlockRef		dbRecBlock;
XErr			err = noErr;
Boolean			needSer;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
ObjRefP			objRefP;
long			tLen, api_data = pbPtr->api_data;

	objRefP = &constructorRecP->varRecsP[0].objRef;
	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, objRefP, &needSer))
	{
		if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(BlockRef);
		if NOT(err = BAPI_GetObj(api_data, objRefP, (Ptr)&dbRecBlock, &tLen, 0, nil))
		{
			dbRecP = (DBRec*)GetPtr(dbRecBlock);
			dbRecP->totRefs++;
			err = BAPI_BufferToObj(api_data, (Ptr)&dbRecBlock, sizeof(BlockRef), dbClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}

//===========================================================================================
static XErr	db_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
DBDescription	*dbDescrRecP;
long			tLen, api_data = pbPtr->api_data;
DBThreadData	*dbTDataP;
Boolean			needSer;
BlockRef		bl;
DBRec			*dbRecP;
BlockRef		dbRecBlock;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(BlockRef);
		if NOT(err = BAPI_GetObj(api_data, &destructorRecP->objRef, (Ptr)&dbRecBlock, &tLen, 0, nil))
		{	dbRecP = (DBRec*)GetPtr(dbRecBlock);
			if (tLen && (dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos)))
			{	
				if not(--dbRecP->totRefs)
				{
					LockBlock(dbRecP->connBlockRef);
					// _Disconnect disposes of connBlockRef (disconnectRecP->connBuffer)
					if NOT(err = _Disconnect(api_data, dbDescrRecP, dbRecP->connBlockRef, dbRecP->connBuffLen, pbPtr->error, dbRecP))
					{	dbRecP->connBlockRef = 0;
						if (pbPtr->plugin_run_dataP && *pbPtr->plugin_run_dataP)
						{	dbTDataP = (DBThreadData*)GetPtr(*pbPtr->plugin_run_dataP);
							dbTDataP->totDBs--;
						}
					}
					if (bl = dbRecP->cursorsP->preparedBlock)
						DisposeBlock(&bl);
					DisposeBlock(&dbRecP->cursorsBlockRef);
					DisposeBlock(&dbRecBlock);
				}
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	db_Run(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DBThreadData	*dbTDataP;

	if (*pbPtr->plugin_run_dataP = NewPtrBlock(sizeof(DBThreadData), &err, (Ptr*)&dbTDataP))
		ClearBlock(dbTDataP, sizeof(DBThreadData));

return err;
}

//===========================================================================================
static XErr	db_Exit(Biferno_ParamBlockPtr pbPtr)
{
XErr							err = noErr;
DBThreadData					*dbTDataP;

	if (pbPtr->plugin_run_dataP && *pbPtr->plugin_run_dataP)
	{	dbTDataP = (DBThreadData*)GetPtr(*pbPtr->plugin_run_dataP);
		DisposeBlock(pbPtr->plugin_run_dataP);
	}

return err;
}

//===========================================================================================
static XErr	db_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				tLen, api_data = pbPtr->api_data;
DBDescription* 		descrDBP;
Boolean				needSer;
DBRec				*dbRecP;
BlockRef			dbRecBlock;

	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
	{	tLen = sizeof(dbRecBlock);
		if (err = BAPI_ReadObj(api_data, &exeMethodRecP->objRef, (Ptr)&dbRecBlock, &tLen, 0, nil))
			return err;
		dbRecP = (DBRec*)GetPtr(dbRecBlock);
		if NOT(descrDBP = _GetDBDescr(nil, &dbRecP->dbdescrPos))
			return XError(kBAPI_ClassError, ErrUnknownDBType);
		err = BAPI_NeedSerialize(pbPtr->api_data, &exeMethodRecP->objRef, &needSer);
	}
	else
	{	// ClearBlock(&dbRec, sizeof(DBRec));
		dbRecP = nil;
		descrDBP = nil;
		needSer = false;
	}
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		switch(exeMethodRecP->methodID)
		{
			case kExec:
				if (descrDBP)
					err = _Exec(pbPtr, exeMethodRecP, descrDBP, dbRecP, kExec);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kCall:
				err = _Call(pbPtr, exeMethodRecP, descrDBP, dbRecP, kCall);
				break;
			case kCallExt:
				err = _Call(pbPtr, exeMethodRecP, descrDBP, dbRecP, kCallExt);
				break;
			case kPrepare:
				if (descrDBP)
					err = _Prepare(pbPtr, exeMethodRecP, descrDBP, dbRecP, kPrepare);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kFreePrepare:
				err = _FreePrepare(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				break;
			case kRowSetSize:
				if (descrDBP)
					err = _RowSetSize(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kGetPrepared:
				if (descrDBP)
					err = _GetPrepared(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kBind:
				err = _Bind(pbPtr, exeMethodRecP, descrDBP, dbRecP, kBind);
				break;
			case kBindAll:
				if (descrDBP)
					err = _Bind(pbPtr, exeMethodRecP, descrDBP, dbRecP, kBindAll);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kExecPrepared:
				if (descrDBP)
					err = _ExecPrepared(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kFreeResult:
				if (descrDBP)
					err = _FreeResult(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kGetCurRecs:
				if (descrDBP)
					err = _GetCurRecs(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kGetAffectedRecs:
				if (descrDBP)
					err = _GetAffectedRecs(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kFetchRec:
				if (descrDBP)
					err = _FetchRec(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kSeek:
				if (descrDBP)
					err = _Seek(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kTell:
				if (descrDBP)
					err = _Tell(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kWarning:
				if (descrDBP)
					err = _Warning(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				else
					err = XError(kBAPI_ClassError, ErrUnknownDBType);
				break;
			case kEscape:
				err = _Escape(pbPtr, exeMethodRecP);
				break;
			case kRealEscape:
				err = _RealEscape(pbPtr, exeMethodRecP, descrDBP, dbRecP, false);
				break;		
			case kRealUnescape:
				err = _RealEscape(pbPtr, exeMethodRecP, descrDBP, dbRecP, true);
				break;		
			case kTransaction:
				err = _Transaction(pbPtr, descrDBP, dbRecP);
				break;
			case kCommit:
				err = _CommitRollBack(pbPtr, descrDBP, dbRecP, kCommit);
				break;
			case kRollBack:
				err = _CommitRollBack(pbPtr, descrDBP, dbRecP, kRollBack);
				break;
			case kGetSpecific:
				err = _GetSpecific(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				break;
			case kSetSpecific:
				err = _SetSpecific(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				break;
			case kLobWrite:
				err = _LobWrite(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				break;
			case kLobRead:
				err = _LobRead(pbPtr, exeMethodRecP, descrDBP, dbRecP);
				break;
			
			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
			
return err;
}

//===========================================================================================
static XErr	db_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;

	if (getPropertyRec->isConstant)
	{	if (getPropertyRec->propertyID == kNull)
			err = BAPI_StringToObj(pbPtr->api_data, DB_NULL_VALUE, DB_NULL_VALUE_LEN, &getPropertyRec->resultObjRef);
		else
			err = BAPI_IntToObj(pbPtr->api_data, getPropertyRec->propertyID, &getPropertyRec->resultObjRef);			
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchProperty);
	
return err;
}

//===========================================================================================
static XErr	db_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr	err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

#define	DASH_STRING	"-"
//===========================================================================================
static XErr	db_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
long			tLen, strLen;
char			*strP, *p;
DBDescription	*descrDBP;
PrimitiveUnion	*param_d;
long			api_data = pbPtr->api_data;
Boolean			needSer;
DBRec			*dbRecP;
BlockRef		dbRecBlock;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if (typeCast->resultWanted == kCString)
		{	param_d = &typeCast->result;
			if (typeCast->typeCastType == kExplicitTypeCast)
			{	tLen = sizeof(BlockRef);
				if NOT(err = BAPI_GetObj(api_data, &typeCast->objRef, (Ptr)&dbRecBlock, &tLen, 0, nil))
				{	dbRecP = (DBRec*)GetPtr(dbRecBlock);
					if (tLen)
					{	if (descrDBP = _GetDBDescr(nil, &dbRecP->dbdescrPos))
						{	if (param_d->text.variant == kForConstructor)
								strP = DASH_STRING;
							else
								strP = descrDBP->name;
							if (tLen)
								strLen = CLen(strP);
							else
								strLen = 0;
						}
						else
							err = XError(kBAPI_Error, Err_IllegalTypeCast);
					}
					else
					{	strP = DASH_STRING;
						strLen = 0;
					}
					if NOT(err)
					{	p = param_d->text.stringP;
						if (p)
						{	if (param_d->text.stringMaxStorage >= (strLen+1))
							{	CopyBlock(p, strP, strLen);
								p[strLen] = 0;
								param_d->text.stringLen = strLen;
							}
							else
							{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
								p[param_d->text.stringMaxStorage - 1] = 0;
								param_d->text.stringLen = strLen;
								err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
							}
						}
						else
							param_d->text.stringLen = strLen;
					}
				}
			}
			else
				err = XError(kBAPI_Error, Err_ExplicitTypeCastRequired);
		}
		else
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	db_GetErrMessage(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetErrMessageRec	*getErrMessageRecP = &pbPtr->param.getErrMessageRec;

	switch(getErrMessageRecP->err)
	{
		case ErrDBMSError:
			CEquStr(getErrMessageRecP->errMessage, "An error related to the DBMS occurred");
			break;
		case ErrGettingCurRecs:
			CEquStr(getErrMessageRecP->errMessage, "GetCurRecs unavailable");
			break;
		case ErrGettingAffectedRecs:
			CEquStr(getErrMessageRecP->errMessage, "GetAffectedRecs unavailable");
			break;
		case ErrBadSeekIndex:
			CEquStr(getErrMessageRecP->errMessage, "Invalid index");
			break;
		case ErrNotEnoughStorageForRecord:
			CEquStr(getErrMessageRecP->errMessage, "Not enough storage for the record");
			break;
		case ErrUnknownDBType:
			CEquStr(getErrMessageRecP->errMessage, "A Biferno extension implementing this database connection was not found");
			break;
		case ErrBadCursorMode:
			CEquStr(getErrMessageRecP->errMessage, "Invalid cursor mode");
			break;
		case ErrTooManyCursors:
		case ErrTooManyPrepares:
		case ErrBadPrepareID:
		case ErrBadCursorID:
		case ErrInvalidFree:
		case ErrNoCursorAvailable:
			break;
		case ErrUnknownSpecific:
			CEquStr(getErrMessageRecP->errMessage, "Specification with this name doesn't exist");
			break;
		// da completare
		default:
			*getErrMessageRecP->errMessage = 0;
			break;
	}
	
return err;
}

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	db_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsDBClassName);
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(database support)");
			gsApiVersion = pbPtr->param.registerRec.api_version;
			dbClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.scopeAllowedHook = _ScopeAllowed;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void db(string initString, string db)");
			if (gsDescrBlock = NewBlockLocked(1 * sizeof(DBDescription), &err, (Ptr*)&gsDescrBlockP))
				gsTotDescrs = 0;
			err = BAPI_RegisterSymbol(pbPtr->api_data, dbClassID, "BDBAPI_Init", (long)BDBAPI_Init);
			break;
		case kInit:
			err = db_Init(pbPtr);
			break;
		case kShutDown:
			err = db_ShutDown(pbPtr);
			DisposeBlock(&gsDescrBlock);
			break;
		case kRun:
			err = db_Run(pbPtr);
			break;
		case kExit:
			err = db_Exit(pbPtr);
			break;
		case kConstructor:
		case kTypeCast:
			err = db_Constructor(pbPtr);
			break;
		case kClone:
			err = db_Clone(pbPtr);
			// CEquStr(pbPtr->error, "db objects cannot be copied and can be passed to functions only by reference");
			// err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = db_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = db_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = db_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = db_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = db_TypeCast(pbPtr);
			break;
		case kGetErrMessage:
			err = db_GetErrMessage(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BDBAPI_Init(BDBAPI_Rec *theRecP)
{
	theRecP->BDBAPI_Register = BDBAPI_Register;
	theRecP->BDBAPI_ObjToConnBuffer = BDBAPI_ObjToConnBuffer;
	theRecP->BDBAPI_Escape = BDBAPI_Escape;
	theRecP->BDBAPI_NewCursorSlot = BDBAPI_NewCursorSlot;
	theRecP->BDBAPI_GetCursorSlot = BDBAPI_GetCursorSlot;
	theRecP->BDBAPI_DisposeCursorSlot = BDBAPI_DisposeCursorSlot;
	theRecP->BDBAPI_DisposeAllCursorsSlots = BDBAPI_DisposeAllCursorsSlots;
	theRecP->BDBAPI_NewPrepare = BDBAPI_NewPrepare;
	theRecP->BDBAPI_DisposePrepare = BDBAPI_DisposePrepare;
	theRecP->BDBAPI_DisposeAllPrepares = BDBAPI_DisposeAllPrepares;
	theRecP->BDBAPI_GetPrepareParams = BDBAPI_GetPrepareParams;
	theRecP->BDBAPI_GetPreparedCursor = BDBAPI_GetPreparedCursor;
	theRecP->BDBAPI_PrepareLoop = BDBAPI_PrepareLoop;
	theRecP->BDBAPI_GetCursorPrepareID = BDBAPI_GetCursorPrepareID;
	theRecP->BDBAPI_FlushParamsInputs = BDBAPI_FlushParamsInputs;
	theRecP->BDBAPI_DisposeParams = BDBAPI_DisposeParams;
	theRecP->BDBAPI_LoadParamsOutputs = BDBAPI_LoadParamsOutputs;
	theRecP->BDBAPI_NativeCursor = BDBAPI_NativeCursor;

return noErr;
}

//===========================================================================================
XErr	BDBAPI_Register(char *dbmsName, BDBAPI_Dispatch dispatcher, long sizeOfCursor, Boolean multiThreadLimited)
{
XErr			err = noErr;
DBDescription	*dbDescrP;

	UnlockBlock(gsDescrBlock);
	err = SetBlockSize(gsDescrBlock, (gsTotDescrs + 1) * sizeof(DBDescription));
	LockBlock(gsDescrBlock);
	if NOT(err)
	{	gsDescrBlockP = (DBDescription*)GetPtr(gsDescrBlock);
		dbDescrP = &gsDescrBlockP[gsTotDescrs];
		CEquStr(dbDescrP->name, dbmsName);
		dbDescrP->entryPoint = dispatcher;
		dbDescrP->sizeOfCursor = (short)sizeOfCursor;
		dbDescrP->multiThreadLimited = multiThreadLimited;
		gsTotDescrs++;
	}

return err;
}

//===========================================================================================
XErr	BDBAPI_ObjToConnBuffer(long api_data, long db_api_data, ObjRef *objRefP, Ptr connBuffP, long *lenP, long maxStorage)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(db_api_data)
#endif
XErr				err = noErr;
long 				tLen;
DBRec				*dbRecP;
BlockRef			dbRecBlock;

	tLen = sizeof(BlockRef);
	if (err = BAPI_ReadObj(api_data, objRefP, (Ptr)&dbRecBlock, &tLen, 0, nil))
		return err;
	dbRecP = (DBRec*)GetPtr(dbRecBlock);
	if ((tLen = dbRecP->connBuffLen) <= maxStorage)
	{	if (connBuffP)
			CopyBlock(connBuffP, _GetConnBuffer(dbRecP), tLen);
		if (lenP)
			*lenP = tLen;
	}
	else
		err = XError(kBAPI_ClassError, ErrNotEnoughStorageForRecord);
		
return err;
}

//===========================================================================================
XErr	BDBAPI_NewPrepare(long api_data, long db_api_data, PrepareParams *paramsP, BDBAPI_CallBack callback, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data, error)
#endif
XErr			err = noErr;
int				totCursors, sqlStringLen, i;
Ptr				cursorP;
char			*p;
long			tSize, sizeOfCursor;
DBPreparedRec 	*preparedItemP = nil;
DBRec			*dbRecP = (DBRec*)db_api_data;
DBDescription	*dbDescrRecP;
char			*sqlStringP;
Boolean			*busyP;

	XThreadsEnterCriticalSection();
	if (dbRecP->cursorsP->preparedBlock)
	{	// find first free
		if (dbRecP->cursorsP->totPrepared >= MAX_PREPARED)
			err = XError(kBAPI_ClassError, ErrTooManyPrepares);
		else
		{	preparedItemP = (DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock);
			for (i = 0; i < MAX_PREPARED; i++, preparedItemP++)
			{	if NOT(preparedItemP->busy)
				{	paramsP->prepareID = i+1;
					break;
				}
			}
		}
	}
	else
	{	// alloc the prepares block
		if (dbRecP->cursorsP->preparedBlock = NewBlock(tSize = (sizeof(DBPreparedRec) * MAX_PREPARED), &err, (Ptr*)&preparedItemP))
		{	ClearBlock(preparedItemP, tSize);
			dbRecP->cursorsP->totPrepared = 0;
			paramsP->prepareID = 1;
		}
	}
	if NOT(err)
	{	ClearBlock(preparedItemP, sizeof(DBPreparedRec));
		preparedItemP->busy = true;
		dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
		sizeOfCursor = dbDescrRecP->sizeOfCursor;
		sqlStringLen = paramsP->sqlStringLen;
		sqlStringP = paramsP->sqlStringP;
		totCursors = paramsP->totCursors;
		preparedItemP->params = *paramsP;
		if (preparedItemP->block = NewBlockLocked(tSize = (totCursors * sizeOfCursor), &err, &cursorP))
		{	ClearBlock(cursorP, tSize);
			if (preparedItemP->busyBlock = NewBlockLocked(tSize = (totCursors * sizeof(Boolean)), &err, (Ptr*)&busyP))
			{	ClearBlock(busyP, tSize);
				for (i = 0; (i < totCursors) && NOT(err); i++, cursorP += sizeOfCursor)
				{	if (sqlStringLen < 255)
					{	CEquStr(preparedItemP->sqlString, sqlStringP);
						preparedItemP->sqlStringBlock = 0;
					}
					else if (preparedItemP->sqlStringBlock = NewBlock(sqlStringLen+1, &err, &p))
					{	CopyBlock(p, sqlStringP, sqlStringLen);
						p[sqlStringLen] = 0;
					}
					if (callback)
						err = callback(api_data, db_api_data, cursorP, userData, error);
				}
				// if there is an error in the loop, increment totPrepared anyway, so that later a dispose will clean spurious data
				dbRecP->cursorsP->totPrepared++;
			}
			else
				DisposeBlock(&preparedItemP->block);
		}
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	BDBAPI_DisposePrepare(long api_data, long db_api_data, long prepareID, BDBAPI_CallBack _freePreparedCallBack, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			/*saveErr = noErr, */err = noErr;
DBPreparedRec	*preparedItemP;
DBRec			*dbRecP = (DBRec*)db_api_data;
DBDescription	*dbDescrRecP;

	XThreadsEnterCriticalSection();
	if ((prepareID > 0) && (prepareID <= MAX_PREPARED))
	{	preparedItemP = &((DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock))[prepareID-1];
		dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
		if (preparedItemP->busy)
		{	_DisposePrepare(api_data, db_api_data, preparedItemP, prepareID, dbDescrRecP->sizeOfCursor, _freePreparedCallBack, userData, error);
			dbRecP->cursorsP->totPrepared--;
		}
		else
			err = XError(kBAPI_ClassError, ErrBadPrepareID);
	}
	else
		err = XError(kBAPI_ClassError, ErrBadPrepareID);
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	BDBAPI_DisposeAllPrepares(long api_data, long db_api_data, BDBAPI_CallBack _freePreparedCallBack, long userData, char *error)
{
DBRec			*dbRecP = (DBRec*)db_api_data;
DBPreparedRec	*preparedItemP;
int				sizeOfCursor, i, totPrepares;
DBDescription	*dbDescrRecP;
XErr			err = noErr;

	XThreadsEnterCriticalSection();
	if (totPrepares = dbRecP->cursorsP->totPrepared)
	{	preparedItemP = (DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock);
		dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
		sizeOfCursor = dbDescrRecP->sizeOfCursor;
		for (i = 0; i < totPrepares; i++, preparedItemP++)
			_DisposePrepare(api_data, db_api_data, preparedItemP, i+1, sizeOfCursor, _freePreparedCallBack, userData, error);
		dbRecP->cursorsP->totPrepared = 0;
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	BDBAPI_GetPreparedCursor(long api_data, long db_api_data, long prepareID, long *cursorIDP, Ptr *cursorPPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
int				i;
Ptr				cursorP;
long			totCursors, sizeOfCursor;
DBPreparedRec	*preparedItemP;
DBRec			*dbRecP = (DBRec*)db_api_data;
DBDescription	*dbDescrRecP;
Boolean			*busyP;

	XThreadsEnterCriticalSection();
	if ((prepareID > 0) && (prepareID <= MAX_PREPARED))
	{	preparedItemP = &((DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock))[prepareID-1];
		if (preparedItemP->busy)
		{	cursorP = GetPtr(preparedItemP->block);
			totCursors = preparedItemP->params.totCursors;
			dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
			sizeOfCursor = dbDescrRecP->sizeOfCursor;
			busyP = (Boolean*)GetPtr(preparedItemP->busyBlock);
			for (i = 0; i < totCursors; i++, cursorP += sizeOfCursor, busyP++)
			{	if NOT(*busyP)
					break;
			}
			if (i == totCursors)
				err = XError(kBAPI_ClassError, ErrTooManyCursors);
			else
			{	if NOT(err = _NewCursorSlot(api_data, db_api_data, prepareID, i+1, cursorIDP, nil))
				{	*cursorPPtr = cursorP;
					*busyP = true;
				}
			}
		}
		else
			err = XError(kBAPI_ClassError, ErrBadPrepareID);
	}
	else
		err = XError(kBAPI_ClassError, ErrBadPrepareID);
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	BDBAPI_GetPrepareParams(long api_data, long db_api_data, long prepareID, PrepareParams *paramsP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
DBPreparedRec	*preparedItemP;
DBRec			*dbRecP = (DBRec*)db_api_data;

	if ((prepareID > 0) && (prepareID <= MAX_PREPARED))
	{	preparedItemP = &((DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock))[prepareID-1];
		if (preparedItemP->busy)
			*paramsP = preparedItemP->params;
		else
			err = XError(kBAPI_ClassError, ErrBadPrepareID);
	}
	else
		err = XError(kBAPI_ClassError, ErrBadPrepareID);
	
return err;
}

//===========================================================================================
XErr	BDBAPI_PrepareLoop(long api_data, long db_api_data, long prepareID, BDBAPI_CallBack _callBack, long userData, char *error)
{	
XErr			err = noErr;
Ptr				cursorP;
long			i, sizeOfCursor, totCursors;
DBRec			*dbRecP = (DBRec*)db_api_data;
DBDescription	*dbDescrRecP;
Boolean			*busyP;
DBPreparedRec	*preparedItemP;

	if ((prepareID > 0) && (prepareID <= MAX_PREPARED))
	{	preparedItemP = &((DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock))[prepareID-1];
		if (preparedItemP->busy)
		{	totCursors = preparedItemP->params.totCursors;
			cursorP = GetPtr(preparedItemP->block);
			dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
			sizeOfCursor = dbDescrRecP->sizeOfCursor;
			busyP = (Boolean*)GetPtr(preparedItemP->busyBlock);
			for (i = 0; (i < totCursors) && NOT(err); i++, cursorP += sizeOfCursor, busyP++)
			{	if (*busyP)
					_SetError(&err, "_Bind: Some cursors were busy", error);
				else if (_callBack)
					err = _callBack(api_data, db_api_data, cursorP, userData, error);
			}
		}
		else
			err = XError(kBAPI_ClassError, ErrBadPrepareID);
	}
	else
		err = XError(kBAPI_ClassError, ErrBadPrepareID);

return err;
}

//===========================================================================================
XErr	BDBAPI_Escape(long api_data, long db_api_data, char *stringP, long stringLen, BlockRef *resultBlockP, long *resultLenP)
{	
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data, db_api_data)
#endif
XErr			err = noErr;

	err = SubstituteExt(stringP, stringLen, resultBlockP, resultLenP, "\'", 1, "\'\'", 2, true, false);
	
return err;
}

//===========================================================================================
XErr	BDBAPI_NewCursorSlot(long api_data, long db_api_data, long *cursorIDP, Ptr *cursorPPtr)
{	
	return _NewCursorSlot(api_data, db_api_data, 0, 0, cursorIDP, cursorPPtr);
}

//===========================================================================================
XErr	BDBAPI_GetCursorPrepareID(long api_data, long db_api_data, long cursorID, long *prepareIDP)
{	
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
IndexRec	*stackP;
long		totItems;
DBRec		*dbRecP = (DBRec*)db_api_data;
XErr		err = noErr;
	
	*prepareIDP = 0;
	totItems = dbRecP->cursorsP->sp;
	stackP = &dbRecP->cursorsP->stack[totItems - 1];	// the last item
	if (cursorID == -1)
		*prepareIDP = stackP->prepareID;
	else
	{	while(totItems--)
		{	if (stackP->counter == (unsigned long)cursorID)
			{	*prepareIDP = stackP->prepareID;
				break;
			}
		}
	}
	if NOT(*prepareIDP)
		err = XError(kBAPI_ClassError, ErrBadCursorID);
	
return err;
}

//===========================================================================================
XErr	BDBAPI_GetCursorSlot(long api_data, long db_api_data, long cursorID, Ptr *cursorPPtr)
{	
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
IndexRec	*stackP;
long		totItems;
short		cursID, prepareID;
DBRec		*dbRecP = (DBRec*)db_api_data;
XErr		err = noErr;
	
	*cursorPPtr = nil;
	totItems = dbRecP->cursorsP->sp;
	stackP = &dbRecP->cursorsP->stack[totItems - 1];	// the last item
	if (cursorID == -1)
	{	cursID = stackP->cursID;
		prepareID = stackP->prepareID;
		if NOT(cursID)
			err = XError(kBAPI_ClassError, ErrNoCursorAvailable);
	}
	else
	{	cursID = prepareID = 0;
		while(totItems--)
		{	if (stackP->counter == (unsigned long)cursorID)
			{	cursID = stackP->cursID;
				prepareID = stackP->prepareID;
				break;
			}
			else
				stackP--;
		}
		if NOT(cursID)
			err = XError(kBAPI_ClassError, ErrBadCursorID);
	}
	if NOT(err)
	{	DBDescription *dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
		err = _GetCursorPointer(dbRecP, dbDescrRecP->sizeOfCursor, prepareID, cursID, cursorPPtr);
	}
	
return err;
}

//===========================================================================================
XErr	BDBAPI_DisposeCursorSlot(long api_data, long db_api_data, long cursorID, BDBAPI_CallBack _freeCallBack, long userData, char *error)
{
IndexRec		*stackP;
long			totItems, i, index;
DBRec			*dbRecP = (DBRec*)db_api_data;
XErr			err = noErr;
DBPreparedRec	*preparedItemP;
Boolean			busy, *busyP;

	XThreadsEnterCriticalSection();
	totItems = dbRecP->cursorsP->sp;
	if (cursorID == -1)
	{	index = dbRecP->cursorsP->sp - 1;
		stackP = &dbRecP->cursorsP->stack[index];
	}
	else
	{	stackP = &dbRecP->cursorsP->stack[0];
		index = -1;
		for (i = 0; i <= totItems; i++, stackP++)
		{	if (stackP->counter == (unsigned long)cursorID)
			{	index = i;
				break;
			}
		}
		if (index == -1)
			err = XError(kBAPI_ClassError, ErrBadCursorID);
	}
	if NOT(err)
	{	if (stackP->prepareID)
		{	preparedItemP = &((DBPreparedRec*)GetPtr(dbRecP->cursorsP->preparedBlock))[stackP->prepareID-1];
			busyP = (Boolean*)GetPtr(preparedItemP->busyBlock);
			busy = busyP[stackP->cursID-1];
		}
		else
			busy = dbRecP->cursorsP->busy[stackP->cursID-1];
		if NOT(busy)
			err = XError(kBAPI_ClassError, ErrInvalidFree);
		else
		{	if (_freeCallBack)
			{
			DBDescription	*dbDescrRecP;
			Ptr				cursorP;
				
				dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
				if NOT(err = _GetCursorPointer(dbRecP, dbDescrRecP->sizeOfCursor, stackP->prepareID, stackP->cursID, &cursorP))
					err = _freeCallBack(api_data, db_api_data, cursorP, userData, error);
			}
			dbRecP->cursorsP->busy[stackP->cursID-1] = false;
			CopyBlock(&dbRecP->cursorsP->stack[index], &dbRecP->cursorsP->stack[index+1], (totItems - index - 1) * sizeof(IndexRec));
			dbRecP->cursorsP->sp--;
			// if curs was from prepare, free the slot in prepare
			if (stackP->prepareID)
				busyP[stackP->cursID-1] = false;
		}
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	BDBAPI_DisposeAllCursorsSlots(long api_data, long db_api_data, BDBAPI_CallBack _freeCallBack, long userData, char *error)
{
DBRec			*dbRecP = (DBRec*)db_api_data;
int				tot, sizeOfCursor, i;
Ptr				cursorP;
DBDescription	*dbDescrRecP;
Boolean			*busyP;
XErr			err = noErr;

	cursorP = (Ptr)dbRecP->cursorsP + CURSORS_OFF;
	dbDescrRecP = _GetDBDescr(nil, &dbRecP->dbdescrPos);
	sizeOfCursor = dbDescrRecP->sizeOfCursor;
	busyP = dbRecP->cursorsP->busy;
	tot = dbRecP->cursorsP->sp;
	for (i = 0; (i < MAX_TOTAL_CURSORS) && tot; i++, cursorP += sizeOfCursor, busyP++)
	{	if (*busyP)
		{	err = _freeCallBack(api_data, db_api_data, cursorP, userData, error);
			*busyP = false;
			tot--;
		}
	}
	dbRecP->cursorsP->sp = 0;
	
return err;
}

//===========================================================================================
// params array of BlockRef pointing to BDBAPI_ParameterDescr*
XErr	BDBAPI_FlushParamsInputs(long api_data, long db_api_data, BlockRef *params, long totParams, char *error, Boolean *hasParamsP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(db_api_data)
#endif
XErr					err = noErr;
int						index;
BlockRef				tBl;
BDBAPI_ParameterDescr	*paramP;
Boolean					isDef;
ObjRef					tObjRef;

	if (hasParamsP)
		*hasParamsP = false;
	if (totParams)
	{	index = 0;
		do 
		{	if (tBl = params[index++])
			{	totParams--;
				paramP = (BDBAPI_ParameterDescr*)GetPtr(tBl);
				if ((paramP->mode == kInputBindMode) || (paramP->mode == kInputOutputBindMode))
				{	if NOT(err = BAPI_IsVariableDefined(api_data, (char*)paramP->name, 0, &isDef, &tObjRef))
					{	if (isDef)
							err = BAPI_ObjToString(api_data, &tObjRef, (char*)paramP->valueP, &paramP->length, paramP->valueStorage, kExplicitTypeCast);
						else
						{	CEquStr(error, "Bind Variable not defined (");
							CAddStr(error, paramP->name);
							CAddStr(error, ")");
							err = XError(kBAPI_ClassError, ErrUndefinedBindVariable);
						}
					}
					if (hasParamsP)
						*hasParamsP = true;
				}
			}
		} while (totParams && NOT(err));
	}

return err;
}

//===========================================================================================
// params array of BlockRef pointing to BDBAPI_ParameterDescr*
XErr	BDBAPI_LoadParamsOutputs(long api_data, long db_api_data, BlockRef *params, long totParams, BDBAPI_IsNullCallBack _IsNull, long userData, char *error, Boolean *hasParamsP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(db_api_data, error)
#endif
Ptr						strToEvalP;
BlockRef				tempBlock;
long					strToEvalLen;
BlockRef				tBl;
BDBAPI_ParameterDescr	*paramP;
int						index;
CStr255					aCStr;
XErr					err = noErr;
ObjRef					tObjRef;

	if (totParams)		// retrieve parameters for stored procs
	{	index = 0;
		do 
		{	tBl = params[index];
			index++;
			if (tBl)
			{	totParams--;
				paramP = (BDBAPI_ParameterDescr*)GetPtr(tBl);
				if ((paramP->mode == kOutputBindMode) || (paramP->mode == kInputOutputBindMode))
				{	strToEvalLen = CLen(paramP->name) + 2 + paramP->length + 1 + 1;
					if (strToEvalLen > 255)
					{	strToEvalP = aCStr;
						tempBlock = 0;
					}
					else
						tempBlock = NewPtrBlock(strToEvalLen, &err, &strToEvalP);
					if NOT(err)
					{	strToEvalP = GetPtr(tempBlock);
						CEquStr(strToEvalP, paramP->name);
						CAddStr(strToEvalP, "=\"");
						if NOT(_IsNull(paramP, index, userData))
						{	paramP->valueP[paramP->length] = 0;
							CAddStr(strToEvalP, (char*)paramP->valueP);
						}
						CAddStr(strToEvalP, "\"");
						BAPI_InvalObjRef(api_data, &tObjRef);
						if (err = BAPI_Eval(api_data, strToEvalP, strToEvalLen, &tObjRef, true, false))
							break;
						if (tempBlock)
							DisposeBlock(&tempBlock);
					}
					if (hasParamsP)
						*hasParamsP = true;
				}
			}
		} while (totParams);
	}

return err;
}

//===========================================================================================
XErr	BDBAPI_DisposeParams(long api_data, long db_api_data, BlockRef *params, long totParams)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data, db_api_data)
#endif
int						index;
BDBAPI_ParameterDescr	*paramDescrP;
BlockRef				tBl;

	if (totParams)
	{	index = 0;
		do 
		{	if (tBl = params[index])
			{	totParams--;
				paramDescrP = (BDBAPI_ParameterDescr*)GetPtr(tBl);
				if (paramDescrP->valueBlock)
					DisposeBlock(&paramDescrP->valueBlock);
				DisposeBlock(&tBl);
				params[index] = 0;
			}
			index++;
		} while (totParams);
	}

return noErr;
}

//===========================================================================================
XErr	BDBAPI_NativeCursor(long api_data, ObjRef *dbObjRefP, char *driver, long *cursorAddrP)
{
XErr			err = noErr;
long			tLen;
DBRec			*dbRecP;
DBDescription* 	descrDBP;
BlockRef		dbRecBlock;

	tLen = sizeof(dbRecBlock);
	if NOT(err = BAPI_ReadObj(api_data, dbObjRefP, (Ptr)&dbRecBlock, &tLen, 0, nil))
	{	dbRecP = (DBRec*)GetPtr(dbRecBlock);
		if NOT(err = BDBAPI_GetCursorSlot(0, (long)dbRecP, -1, (Ptr*)cursorAddrP))
		{	if (descrDBP = _GetDBDescr(nil, &dbRecP->dbdescrPos))
				CEquStr(driver, descrDBP->name);
		}
	}
	
return err;
}

#if __MWERKS__
#pragma export off
#endif

