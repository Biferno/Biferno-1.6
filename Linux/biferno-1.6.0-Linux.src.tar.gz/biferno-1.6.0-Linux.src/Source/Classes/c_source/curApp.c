/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: curApp.c,v 1.11 2006-07-21 09:47:01 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"BfrHeader.h"
#include 	"File.h"

// defines
#define	gsPlugName	"curApp"

// Methods
enum{
		kFlush = 1,
		kReload,
		kPublish,
		kUnpublish,
		kGetPubVariable,
		kRegisterNewApp
	};
#define TOT_METHODES	6

// Properties
#define TOT_PROPRIETIES	9
enum{
		kName,
		kHome,
		kChildren,
		kChildrenHomes,
		kClasses,
		kFunctions,
		kCacheTotItems,
		kCacheTotSize,
		kCacheItems
	};

static 	long	gsApiVersion, gsCacheItemClassID, curAppClassID;

//===========================================================================================
static XErr	_CurAppRegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	curAppProperty[TOT_PROPRIETIES] = 
					{	
					"name",				kName,			"static string",
					"home",				kHome,			"static string",
					"children[]",		kChildren,		"static string",
					"childrenHomes[]",	kChildrenHomes,	"static string",
					"classes[]",		kClasses,		"static string",
					"functions[]",		kFunctions,		"static string",
					"cacheTotItems",	kCacheTotItems,	"static int",
					"cacheTotSize",		kCacheTotSize,	"static unsigned",
					"cacheItems[]",		kCacheItems,	"static cacheItem"
					};
					
BAPI_MemberRecord	curAppMethods[TOT_METHODES] = 
					{	
					"Flush",			kFlush,				"static void Flush(void)",
					"Reload",			kReload,			"static void Reload(void)",
					"Publish",			kPublish,			"static void Publish(obj varToPublish)",
					"Unpublish",		kUnpublish,			"static void Unpublish(obj varToUnpublish)",
					"GetPubVariable",	kGetPubVariable,	"static obj GetPubVariable(string application, string scope, string name)",
					"RegisterNewApp",	kRegisterNewApp,	"static void RegisterNewApp(string applName, string fullPath)"
					};

	if (err = BAPI_NewProperties(api_data, curAppClassID, curAppProperty, TOT_PROPRIETIES, nil))
		return err;		

	if (err = BAPI_NewMethods(api_data, curAppClassID, curAppMethods, TOT_METHODES, nil))
		return err;

//out:
return err;
}

//===========================================================================================
static XErr	_GetPubVariable(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
long		scopeID;
CStr255		applName;
CStr63		theName, theScope;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applName, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, theScope, nil, 63, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, theName, nil, 63, kImplicitTypeCast))
			{	if NOT(err = BAPI_ScopeID(api_data, theScope, &scopeID))
					err = BAPI_GetPublishedVar(api_data, applName, scopeID, theName, &exeMethodRecP->resultObjRef);
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_RegisterNewApp(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		applicationName;
CStr255		applicationPath;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applicationName, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, applicationPath, nil, 255, kImplicitTypeCast))
			err = BAPI_RegisterApplication(api_data, applicationName, applicationPath);
	}
	
return err;
}

//===========================================================================================
static XErr	_GetAppInfoArray(long api_data, GetPropertyRec *getPropertyRecP, long which, char *applName)
{
XErr			err = noErr;
ArrayIndexRec	mCoord;
ObjRef			tObjRef, *resultP = &getPropertyRecP->resultObjRef;
long			i, tots;
BlockRef		blockRef;
BAPI_Name		*nameRecP;
char			*nameP;
CStr255			aCStr, appHome;

	if (getPropertyRecP->propertyIndex)
		mCoord = getPropertyRecP->propertyIndex[0];
	else
		ClearBlock(&mCoord, sizeof(ArrayIndexRec));
	if (*mCoord.ind_name)
		err = XError(kBAPI_Error, Err_ArrayElementNotFound);
	else
	{	switch(which)
		{
			case kChildren:
			case kChildrenHomes:
				err = BAPI_GetAppChildren(api_data, applName, &blockRef, &tots, mCoord.ind);
				break;
			case kClasses:
				err = BAPI_GetClasses(api_data, applName, &blockRef, &tots, mCoord.ind);
				break;
			case kFunctions:
				err = BAPI_GetMembers(api_data, applName, "function", kFunction, &blockRef, &tots, mCoord.ind);
				break;
		}
		if NOT(err)
		{	if (blockRef)
				nameRecP = (BAPI_Name*)GetPtr(blockRef);
			if (mCoord.ind)
			{	
				if (which == kChildrenHomes)
				{
					if NOT(err = BAPI_GetGenericAppInfo(api_data, nameRecP->name, aCStr))
					{
						CEquStr(appHome, "file:/");
						CAddStr(appHome, aCStr);
						nameP = appHome;
					}
				}
				else
					nameP = nameRecP->name;
				err = BAPI_StringToObj(api_data, nameP, CLen(nameP), resultP);
			}
			else
			{	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, resultP))
				{	if (blockRef)
					{	LockBlock(blockRef);
						for (i = 0; (i < tots) && NOT(err); i++, nameRecP++)
						{	
							if (which == kChildrenHomes)
							{
								if NOT(err = BAPI_GetGenericAppInfo(api_data, nameRecP->name, aCStr))
								{
									CEquStr(appHome, "file:/");
									CAddStr(appHome, aCStr);
									nameP = appHome;
								}
							}
							else
								nameP = nameRecP->name;
							if NOT(err)
							{	
								BAPI_InvalObjRef(api_data, &tObjRef);
								if NOT(err = BAPI_StringToObj(api_data, nameP, CLen(nameP), &tObjRef))
									err = BAPI_ArrayAddElement(api_data, resultP, nil, &tObjRef);
							}
						}
					}
				}
			}
			if (blockRef)
				DisposeBlock(&blockRef);
		}
	}
return err;
}

//===========================================================================================
static XErr	_GetCacheInfo(long api_data, GetPropertyRec *getPropertyRecP)
{
long			totItems;
unsigned long 	totalBytesInCache;
BlockRef		cacheItemInfoBlock;
XErr			err = noErr;
CStr255			aCStr;
Boolean			cacheFixedSize;
ObjRefP			resultP = &getPropertyRecP->resultObjRef;
ParameterRec	param[2];
CacheItemInfoP	infosP;
int				i;
ObjRef			objRefToAdd;

	if NOT(err = BAPI_GetCache(api_data, &cacheItemInfoBlock, &totItems, &totalBytesInCache, &cacheFixedSize))
	{	if NOT(err = BAPI_ArrayToObj(api_data, cacheFixedSize, nil, 0, nil, nil, resultP))
		{	LockBlock(cacheItemInfoBlock);
			infosP = (CacheItemInfoP)GetPtr(cacheItemInfoBlock);
			*param[0].name = 0;
			//param[0].expP = nil;
			//param[0].expLen = 0;
			*param[1].name = 0;
			//param[1].expP = nil;
			//param[1].expLen = 0;
			for (i = 0; (i < totItems) && NOT(err); i++, infosP++)
			{	CEquStr(aCStr, "file:/");
				CAddStr(aCStr, infosP->path);
				BAPI_InvalObjRef(api_data, &param[0].objRef);
				if NOT(err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &param[0].objRef))
				{	BAPI_InvalObjRef(api_data, &param[1].objRef);
					if NOT(err = BAPI_IntToObj(api_data, DONT_OPEN, &param[1].objRef))
					{	BAPI_InvalObjRef(api_data, &objRefToAdd);
						if NOT(err = BAPI_Constructor(api_data, gsCacheItemClassID, param, 2, &objRefToAdd))
							err = BAPI_ArrayAddElement(api_data, resultP, "", &objRefToAdd);
					}
				}
			}
		}
		DisposeBlock(&cacheItemInfoBlock);
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	curApp_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	curAppClassID = pbPtr->param.registerRec.pluginID;
	
return err;
}

//===========================================================================================
static XErr	curApp_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	gsCacheItemClassID = BAPI_ClassIDFromName(api_data, "cacheItem", false);
	err = _CurAppRegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	curApp_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;

	switch(exeMethodRecP->methodID)
	{
		case kFlush:
			err = BAPI_FlushAppFiles(api_data);
			break;
		case kReload:
			err = BAPI_ReloadApp(api_data);
			break;
		case kPublish:
			err = BAPI_Publish(api_data, true, &exeMethodRecP->paramVarsP[0].objRef);
			break;
		case kUnpublish:
			err = BAPI_Publish(api_data, false, &exeMethodRecP->paramVarsP[0].objRef);
			break;
		case kGetPubVariable:
			err = _GetPubVariable(exeMethodRecP, api_data);
			break;
		case kRegisterNewApp:
			err = _RegisterNewApp(exeMethodRecP, api_data);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
	
return err;
}

//===========================================================================================
static XErr	curApp_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRecP = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			totItems, api_data = pbPtr->api_data;
CStr255			name, home, aCStr;
unsigned long 	totalBytesInCache;
BlockRef		infoBlock;

	if NOT(err = BAPI_GetCurrentAppInfo(api_data, name, aCStr))
	{	switch(getPropertyRecP->propertyID)
		{
			case kName:
				err = BAPI_StringToObj(api_data, name, CLen(name), &getPropertyRecP->resultObjRef);
				break;
			case kHome:
				CEquStr(home, FILE_HD_PREFIX);
				CAddStr(home, aCStr);
				err = BAPI_StringToObj(api_data, home, CLen(home), &getPropertyRecP->resultObjRef);
				break;
			case kChildren:
				err = _GetAppInfoArray(api_data, getPropertyRecP, kChildren, name);
				break;
			case kChildrenHomes:
				err = _GetAppInfoArray(api_data, getPropertyRecP, kChildrenHomes, name);
				break;
			case kClasses:
				err = _GetAppInfoArray(api_data, getPropertyRecP, kClasses, name);
				break;
			case kFunctions:
				err = _GetAppInfoArray(api_data, getPropertyRecP, kFunctions, name);
				break;
			case kCacheTotItems:
				if NOT(err = BAPI_GetCache(api_data, &infoBlock, &totItems, &totalBytesInCache, nil))
				{	err = BAPI_IntToObj(api_data, totItems, &getPropertyRecP->resultObjRef);
					DisposeBlock(&infoBlock);
				}
			case kCacheTotSize:
				if NOT(err = BAPI_GetCache(api_data, &infoBlock, &totItems, &totalBytesInCache, nil))
				{	err = BAPI_UnsignedToObj(api_data, totalBytesInCache, &getPropertyRecP->resultObjRef);
					DisposeBlock(&infoBlock);
				}
				break;
			case kCacheItems:
				err = _GetCacheInfo(api_data, getPropertyRecP);
				break;
			default:
				break;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	curApp_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	switch(setPropertyRec->propertyID)
	{
		case kName:
		case kHome:
		case kClasses:
		case kFunctions:
		case kCacheTotItems:
		case kCacheTotSize:
		case kCacheItems:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	curApp_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = curApp_Register(pbPtr);
			break;
		case kInit:
			err = curApp_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = curApp_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = curApp_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = curApp_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


