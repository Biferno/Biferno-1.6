/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: search.c,v 1.14 2008-04-16 14:31:08 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"


#include 	"BifernoAPI.h"
#include 	"BfrSearch.h"
#include 	"BDBAPI.h"

// Properties
#define TOT_PROPRIETIES	6
enum{
		kTot = 1,
		kMode,
		kString,
		kOper,
		kGroup,
		kFindType
	};

// Errors
#define		SEARCH_START_ERR	100
enum {
		ErrUnsupportedMode = SEARCH_START_ERR,
		ErrIndexRequired,
		ErrSearchElementTooLong
};

CStr63	gSearchErrorsStr[] = 
	{	
		"ErrUnsupportedMode",
		"ErrIndexRequired",
		"ErrSearchElementTooLong"
		};
#define TOT_ERRORS	3

// defines
#define TOT_COSTANTS	12

#define TOT_METHODES	2
enum{
		kSetOption = 1,
		//kReprocess,
		kToSQL
	};


static long					gsStringClassID, searchClassID, gsIntClassID;
static long					gsApiVersion;
static BDBAPI_Rec			bdbRec;

XErr	search_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
				
#define	MAX_STR	8
typedef struct {
				char		andStr[MAX_STR];
				char		orStr[MAX_STR];
				char		notStr[MAX_STR];
				char		wildStr[MAX_STR];
				short		andStrLen;
				short		orStrLen;
				short		notStrLen;
				short		wildStrLen;
				} SearchOption, *SearchOptionP;

static SearchOption	gsDefaultOption = {"&", "|", "!", "*", 1, 1, 1, 1};

//===========================================================================================
static void	_GetSQLOperatString(short boolMode, short operat, char *str, Boolean *isNotP, long index, Boolean lowerCase)
{
	*str = 0;
	if (boolMode)
		operat = boolMode;
	switch(operat)
	{	
		case kALLNOT:
		case kANDNOT:
			*isNotP = true;
			if (index)
			{	if (lowerCase)
					CEquStr(str, "and");
				else
					CEquStr(str, "AND");
			}
			break;
		case kALL:
		case kAND:
			*isNotP = false;
			if (index)
			{	if (lowerCase)
					CEquStr(str, "and");
				else
					CEquStr(str, "AND");
			}
			break;
		case kOR:
			*isNotP = false;
			if (index)
			{	if (lowerCase)
					CEquStr(str, "or");
				else
					CEquStr(str, "OR");
			}
			break;
		case kORNOT:
			*isNotP = true;
			if (index)
			{	if (lowerCase)
					CEquStr(str, "or");
				else
					CEquStr(str, "OR");
			}
			break;
	}
}

//===========================================================================================
/*static void	_GetFindTypeString(short wildChar, char *str)
{
	*str = 0;
	switch(wildChar)
	{	case kCONTAIN:
			CEquStr(str, "contains");
			break;
		case kBEGIN:
			CEquStr(str, "begins");
			break;
		case kEND:
			CEquStr(str, "ends");
			break;
		default:
			CEquStr(str, "equal");
			break;
	}
}
*/
//===========================================================================================
static void	_GetSQLFindTypeString(short wildChar, Boolean isNot, char *str, char *keyStr, Boolean lowerCase)
{
char	tempStr[SEARCH_MAX_ELEMENT_LENGTH+1];

	switch(wildChar)
	{	case kCONTAIN:
			CEquStr(tempStr, "%");
			CAddStr(tempStr, keyStr);
			CAddChar(tempStr, '%');
			CEquStr(keyStr, tempStr);
			if (isNot)
			{	if (lowerCase)
					CEquStr(str, "not like");
				else
					CEquStr(str, "NOT LIKE");
			}
			else
			{	if (lowerCase)
					CEquStr(str, "like");
				else
					CEquStr(str, "LIKE");
			}
			break;
		case kBEGIN:
			CAddChar(keyStr, '%');
			if (isNot)
			{	if (lowerCase)
					CEquStr(str, "not like");
				else
					CEquStr(str, "NOT LIKE");
			}
			else
			{	if (lowerCase)
					CEquStr(str, "like");
				else
					CEquStr(str, "LIKE");
			}
			break;
		case kEND:
			CEquStr(tempStr, "%");
			CAddStr(tempStr, keyStr);
			CEquStr(keyStr, tempStr);
			if (isNot)
			{	if (lowerCase)
					CEquStr(str, "not like");
				else
					CEquStr(str, "NOT LIKE");
			}
			else
			{	if (lowerCase)
					CEquStr(str, "like");
				else
					CEquStr(str, "LIKE");
			}
			break;
		default:
			if (isNot)
				CEquStr(str, "<>");
			else
				CEquStr(str, "=");
			break;
	}
}

//===========================================================================================
static void	_ReleaseBlock(BlockRef *refP)
{
	if (*refP)
		DisposeBlock((BlockRef*)refP);
}

//===========================================================================================
static void	_ReverseOperat(long *operatP)
{
	switch (*operatP)
	{
		case kALL:
			*operatP = kALLNOT;
			break;
		case kALLNOT:
			*operatP = kALL;
			break;
		case kAND:
			*operatP = kANDNOT;
			break;
		case kOR:
			*operatP = kORNOT;
			break;
		case kANDNOT:
			*operatP = kAND;
			break;
		case kORNOT:
			*operatP = kOR;
			break;
	}
}

//===========================================================================================
static XErr	_StoreOne(SearchOptionP	optionP, long buffID, BlockRef searchBlock, SearchHeaderP *searchHeadPPtr, long *strIndexP, char *strP, long operat, long *lastGroupP)
{
XErr			err = noErr;
Boolean			moved;
SearchHeaderP	searchHeadP;
SearchItemP		sItemP;
long			zapped, strLen;
char			*keyStrP;
long			strIndex;
	
	if (strLen = CLen(strP))
	{	strIndex = *strIndexP;
		if NOT(err = BufferCheck(buffID, sizeof(SearchHeader) + (sizeof(SearchItem) * strIndex), &moved))
		{	if (moved)
				*searchHeadPPtr = searchHeadP = (SearchHeaderP)GetPtr(searchBlock);
			else
				searchHeadP = *searchHeadPPtr;
			sItemP = &searchHeadP->sItem[strIndex];
			(*strIndexP)++;
			// firstChar ('!' or '(')
			keyStrP = sItemP->key;
			SkipSpaceAndTab(&strP, &strLen);
			if (/*((*lastGroupP == kCLOSE_PAR) || (*lastGroupP == kNO_PAR)) && */strLen && (*strP == '('))
			{	*lastGroupP = sItemP->group = kOPEN_PAR;
				strP++;
				strLen--;
				SkipSpaceAndTab(&strP, &strLen);
				if (strLen && NOT(CompareBlock(strP, optionP->notStr, optionP->notStrLen)))
				{	_ReverseOperat(&operat);
					strP += optionP->notStrLen;
					strLen -= optionP->notStrLen;
				}
			}
			else if (strLen && NOT(CompareBlock(strP, optionP->notStr, optionP->notStrLen)))
			{	_ReverseOperat(&operat);
				strP += optionP->notStrLen;
				strLen -= optionP->notStrLen;
				SkipSpaceAndTab(&strP, &strLen);
				if ((/*((*lastGroupP == kOPEN_PAR) || (*lastGroupP == kNO_PAR)) && */strLen && (*strP == '(')) && strLen && (*strP == '('))
				{	*lastGroupP = sItemP->group = kOPEN_PAR;
					strP++;
					strLen--;
				}
			}
			if (strLen < SEARCH_MAX_ELEMENT_LENGTH)
				CEquStr(keyStrP, strP);
			else
				err = XError(kBAPI_ClassError, ErrSearchElementTooLong);
			if NOT(err)
			{	SkipSpaceAndTab(&strP, &strLen);
				if ((strLen > optionP->wildStrLen) && NOT(CompareBlock(keyStrP, optionP->wildStr, optionP->wildStrLen)))
				{	sItemP->wildChar = kEND;
					CopyBlock(keyStrP, keyStrP+1, strLen-1);
					keyStrP[--strLen] = 0;
					strP++;
				}
				while (strLen && (*(strP+strLen-1) == ' ') || (*(strP+strLen-1) == '\t'))
					strLen--;			
				if ((*lastGroupP == kOPEN_PAR) && strLen && (*(strP+strLen-1) == ')'))
				{	/*if (sItemP->group == kOPEN_PAR)
						sItemP->group = kNO_PAR;
					else
						*/
					if (sItemP->group == kOPEN_PAR)
						*lastGroupP = sItemP->group = kNO_PAR;
					else
						*lastGroupP = sItemP->group = kCLOSE_PAR;
					strLen--;
				}
				while (strLen && (*(strP+strLen-1) == ' ') || (*(strP+strLen-1) == '\t'))
					strLen--;		
				sItemP->operat = (Byte)operat;
				keyStrP[strLen] = 0;
				if ((strLen > optionP->wildStrLen) && NOT(CompareBlock(keyStrP+strLen-optionP->wildStrLen, optionP->wildStr, optionP->wildStrLen)))
				{	if (sItemP->wildChar == kEND)
						sItemP->wildChar = kCONTAIN;
					else
						sItemP->wildChar = kBEGIN;
					keyStrP[--strLen] = 0;
				}
			}
		}
	}
	if NOT(err)
	{	if (zapped = ZapText((Byte*)keyStrP, strLen))
		{	strLen -= zapped;
			keyStrP[strLen] = 0;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_NewSearchRecord(long plugin_run_data, char *stringP, long len, long booleanMode, BlockRef *resultBlockRef, long *resultLenP)
{
SearchHeaderP	searchHeadP;
XErr			err = noErr;
long			buffID;
BlockRef		searchBlock = 0;
Ptr				tempP = stringP;
long			lastGroup, lastOperat, numStr, tempLen = len;
int				j, ch;
Boolean			inString = false;
char			tempStr[SEARCH_MAX_ELEMENT_LENGTH+1];
SearchOptionP	optionP;
int				back_slashCnt;
long			advance;

	if (buffID = BufferCreateClear(sizeof(SearchHeader), &err))
	{	lastGroup = kNO_PAR;
		if (plugin_run_data)
			optionP = (SearchOptionP)GetPtr(plugin_run_data);
		else
			optionP = &gsDefaultOption;
		searchBlock = BufferGetBlockRefExt(buffID, (Ptr*)&searchHeadP);
		LockBlock(searchBlock);
		lastOperat = kALL;
		if (tempLen)
		{	j = 0;
			numStr = 0;
			back_slashCnt = 0;
			do {
				ch = *tempP;
				if NOT(ch)
					break;
				if (ch == '\\')
					back_slashCnt++;
				else if (ch != '\"')
					back_slashCnt = 0;
				if (ch == '\"')
				{	if NOT(back_slashCnt & 1)
					{	if (inString)
							inString = false;
						else
							inString = true;
						ch = 0;
					}
					back_slashCnt = 0;
				}
				if NOT(inString)
				{	if NOT(CompareBlock(optionP->andStr, tempP, optionP->andStrLen))
					{	tempStr[j] = 0;
						err = _StoreOne(optionP, buffID, searchBlock, &searchHeadP, &numStr, tempStr, lastOperat, &lastGroup);
						lastOperat = kAND;
					 	tempP += optionP->andStrLen;
					 	tempLen -= optionP->andStrLen;
					 	SkipSpaceAndTab(&tempP, &tempLen);
					 	j = 0;
					}
					else if NOT(CompareBlock(optionP->orStr, tempP, optionP->orStrLen))
					{	tempStr[j] = 0;
						err = _StoreOne(optionP, buffID, searchBlock, &searchHeadP, &numStr, tempStr, lastOperat, &lastGroup);
						lastOperat = kOR;
					 	tempP += optionP->orStrLen;
					 	tempLen -= optionP->orStrLen;
					 	j = 0;
					 	SkipSpaceAndTab(&tempP, &tempLen);
					}
					else if (booleanMode && (*tempP != '(') && (*tempP != ')') && IsSeparChar(tempP, len, &advance))
			 		{	tempStr[j] = 0;
			 			err = _StoreOne(optionP, buffID, searchBlock, &searchHeadP, &numStr, tempStr, booleanMode, &lastGroup);
			 			tempP += advance;
			 			tempLen -= advance;
			 			j = 0;
			 			SkipSpaceAndTab(&tempP, &tempLen);
					}
					else
					{	if (j < SEARCH_MAX_ELEMENT_LENGTH)
						{	tempStr[j++] = ch;
							tempP++;
							tempLen--;
						}
						else
							err = XError(kBAPI_ClassError, ErrSearchElementTooLong);
					}
				}
				else
				{	if (ch)
						tempStr[j++] = ch;
					tempP++;
					tempLen--;
				}
			} while ((tempLen > 0) && NOT(err));
			if NOT(err)
			{	// last
				tempStr[j] = 0;
				err = _StoreOne(optionP, buffID, searchBlock, &searchHeadP, &numStr, tempStr, lastOperat, &lastGroup);
			}
		}
		else
			numStr = 0;
	}
	
	if NOT(err)
	{	if (resultLenP)
			*resultLenP = sizeof(SearchHeader) + (sizeof(SearchItem) * (numStr-1));
		if (resultBlockRef)
			*resultBlockRef = searchBlock;
		searchHeadP->totItems = (short)numStr;
		searchHeadP->booleanMode = (short)booleanMode;
		BufferClose(buffID);
	}
	
	if (searchBlock)
		UnlockBlock(searchBlock);
	if (err)
		BufferFree(buffID);
	
return err;
}

//===========================================================================================
static XErr	_ReallocSearchRecord(long api_data, long plugin_run_data, ObjRef *stringSuperObjRef, short booleanMode, BlockRef *resultBlockRef, long *resultLen)
{
XErr		err = noErr;
CStr255		aCStr;
char		*stringP;
long		stringLen;
BlockRef	ref;

	if NOT(err = BAPI_GetStringBlock(api_data, stringSuperObjRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
	{	err = _NewSearchRecord(plugin_run_data, stringP, stringLen, booleanMode, resultBlockRef, resultLen);
		if (ref)
			DisposeBlock(&ref);
	}
		
return err;
}

//===========================================================================================
static XErr	_GetSearchBlock(long plugin_run_data, long api_data, ObjRefP objRef, char *aCStr, SearchHeaderP *stringP, long *stringLen, BlockRef *refP, ObjRef *superObjRefP)
{		
XErr		err = noErr;
long		dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock = 0;
Boolean		isSearch;

	*refP = 0;
	dataLen = 0;
	if (BAPI_GetObjClassID(api_data, objRef) == searchClassID)
		isSearch = true;
	else
		isSearch = false;
	
	if (superObjRefP)
		err = BAPI_InvalObjRef(api_data, superObjRefP);
		//superObjRefP->id = 0L;
	
	if NOT(err)
	{	if (isSearch)
			err = BAPI_ReadObj(api_data, objRef, nil, &dataLen, 0, nil);
		else
			err = BAPI_ObjToString(api_data, objRef, nil, &dataLen, 0, kImplicitTypeCast);
		if NOT(err)
		{	++dataLen;	// 0-final
			if (dataLen < 255)
			{	dataP = aCStr;
				*refP = 0;
				*stringP = (SearchHeaderP)dataP;
			}
			else
			{	if (dataBlock = NewBlockLocked(dataLen, &err, &dataP))
				{	//LockBlock(dataBlock);
					//dataP = GetPtr(dataBlock);
					*stringP = (SearchHeaderP)dataP;
					*refP = dataBlock;
				}
			}
			if NOT(err)
			{	long tLen = dataLen - 1;
				
				if (isSearch)
				{	if NOT(err = BAPI_ReadObj(api_data, objRef, dataP, &tLen, 0, nil))
					{	*stringLen = tLen;
						dataP[tLen] = 0;
						if (superObjRefP)
							err = BAPI_GetSuperObj(api_data, objRef, superObjRefP);
					}
				}
				else
				{	if NOT(err = BAPI_ObjToString(api_data, objRef, dataP, &dataLen, dataLen-1, kImplicitTypeCast))
					{	BlockRef	resultBlockRef;
					
						if NOT(err = _NewSearchRecord(plugin_run_data, dataP, dataLen, 0, &resultBlockRef, stringLen))
						{	if (dataBlock)
								DisposeBlock(&dataBlock);
							LockBlock(resultBlockRef);
							*refP = resultBlockRef;
						}
					}		
				}
			}	
		}
	}
	
if (err && *refP)
	DisposeBlock(refP);
return err;
}

//===========================================================================================
static XErr	_SetOption(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
//Boolean			result = false;
//CStr255			address;
//char			*strP = address;
SearchOptionP	optionP;
CStr255			tempStr;
long			tempLen;
	
	optionP = (SearchOptionP)GetPtr((*pbPtr->plugin_run_dataP));
	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, tempStr, &tempLen, 255, kImplicitTypeCast))
	{	if (tempLen)
		{	if (tempLen > (MAX_STR-1))
				tempStr[MAX_STR-1] = 0;
			CEquStr(optionP->andStr, tempStr);
			optionP->andStrLen = (short)tempLen;
		}
		if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, tempStr, &tempLen, 255, kImplicitTypeCast))
		{	if (tempLen)
			{	if (tempLen > (MAX_STR-1))
					tempStr[MAX_STR-1] = 0;
				CEquStr(optionP->orStr, tempStr);
				optionP->orStrLen = (short)tempLen;
			}
			if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, tempStr, &tempLen, 255, kImplicitTypeCast))
			{	if (tempLen)
				{	if (tempLen > (MAX_STR-1))
						tempStr[MAX_STR-1] = 0;
					CEquStr(optionP->notStr, tempStr);
					optionP->notStrLen = (short)tempLen;
				}
				if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[3].objRef, tempStr, &tempLen, 255, kImplicitTypeCast))
				{	if (tempLen)
					{	if (tempLen > (MAX_STR-1))
							tempStr[MAX_STR-1] = 0;
						CEquStr(optionP->wildStr, tempStr);
						optionP->wildStrLen = (short)tempLen;
					}
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_ReprocessLow(long plugin_run_data, ObjRefP objRefP, long api_data, Boolean *sideEffectP)
{
XErr			err = noErr;
long 			len;
CStr255			aCStr;
BlockRef		ref, resultBlockRef;
ObjRef			stringSuperObjRef;
SearchHeaderP	searchHeadP;

	if NOT(err = _GetSearchBlock(plugin_run_data, api_data, objRefP, aCStr, &searchHeadP, &len, &ref, &stringSuperObjRef))
	{	if (BAPI_IsObjRefValid(api_data, &stringSuperObjRef))
		{	if NOT(err = _ReallocSearchRecord(api_data, plugin_run_data, &stringSuperObjRef, searchHeadP->booleanMode, &resultBlockRef, &len))
			{	LockBlock(resultBlockRef);
				if NOT(err = BAPI_ModifyObj(api_data, objRefP, GetPtr(resultBlockRef), len))
				{	if (sideEffectP)
						*sideEffectP = true;
				}
				DisposeBlock(&resultBlockRef);
			}
		}
		else
			CDebugStr("search: _Reprocess invalid superObjRef");
		_ReleaseBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_SearchToSQL(long api_data, SearchHeaderP searchHeadP, char *fieldName, BlockRef *textBlockP, long *textLengthP, Ptr *textPPtr, Boolean isNumeric, Boolean lowerCase)
{	
XErr			err = noErr;
SearchItem		*sItemP;
short			booleanMode;
char			keyStr[SEARCH_MAX_ELEMENT_LENGTH+1], tStr[SEARCH_MAX_ELEMENT_LENGTH+1];
Boolean			isNot;
long 			lastLoop, buffID, i, totItems;
BlockRef		keyStrResultStringBlock;
long			keyStrResultLen;

	if (buffID = BufferCreate(255, &err))
	{	totItems = searchHeadP->totItems;
		booleanMode = searchHeadP->booleanMode;
		sItemP = &searchHeadP->sItem[0];
		lastLoop = totItems - 1;
		for (i = 0; (i < totItems) && NOT(err); i++, sItemP++)
		{	_GetSQLOperatString(searchHeadP->booleanMode, sItemP->operat, tStr, &isNot, i, lowerCase);
			if (err = BufferAddCString(buffID, tStr, NO_ENC, 0))
				break;
			if (sItemP->group == kOPEN_PAR)
				err = BufferAddCString(buffID, " (", NO_ENC, 0);
			else if (i != 0)
				err = BufferAddChar(buffID, ' ');
			if (err)
				break;
			if (err = BufferAddCString(buffID, fieldName, NO_ENC, 0))
				break;
			if (err = BufferAddChar(buffID, ' '))
				break;
			if NOT(err = bdbRec.BDBAPI_Escape(api_data, 0, sItemP->key, CLen(sItemP->key), &keyStrResultStringBlock, &keyStrResultLen))
			{	if (keyStrResultLen < SEARCH_MAX_ELEMENT_LENGTH)
				{	LockBlock(keyStrResultStringBlock);
					CopyBlock(keyStr, GetPtr(keyStrResultStringBlock), keyStrResultLen);
					keyStr[keyStrResultLen] = 0;
					_GetSQLFindTypeString(sItemP->wildChar, isNot, tStr, keyStr, lowerCase);			
					if (err = BufferAddCString(buffID, tStr, NO_ENC, 0))
						break;
					if NOT(isNumeric)
					{	if (err = BufferAddCString(buffID, " \'", NO_ENC, 0))
							break;
					}
					else
					{	if (err = BufferAddChar(buffID, ' '))
							break;
					}
					err = BufferAddCString(buffID, keyStr, NO_ENC, 0);		
					if (err)
						break;
					if NOT(isNumeric)
					{	if (err = BufferAddCString(buffID, "\'", NO_ENC, 0))
							break;
					}
					if (sItemP->group == kCLOSE_PAR)
						err = BufferAddChar(buffID, ')');
					if (i < lastLoop)
						err = BufferAddChar(buffID, ' ');
					if (err)
						break;
				}
				else
					err = XError(kBAPI_ClassError, ErrSearchElementTooLong);
				DisposeBlock(&keyStrResultStringBlock);
			}
		}
		if NOT(err)
		{	*textBlockP = BufferGetBlockRefExtSize(buffID, textLengthP, textPPtr);
			LockBlock(*textBlockP);
			BufferClose(buffID);
		}
		else
			BufferFree(buffID);
	}

return err;
}

//===========================================================================================
static XErr	_ToSQL(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
long 			textLength, fieldNameLen, len;
SearchHeaderP 	searchHeadP;
CStr255			aCStr;
BlockRef		ref;
CStr63			fieldName;
BlockRef		textBlock;
Ptr				textP;
Boolean			lowerCase, isNumeric;

	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, fieldName, &fieldNameLen, 63, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &isNumeric, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &lowerCase, kImplicitTypeCast))
		return err;
	if NOT(fieldNameLen)
		CEquStr(fieldName, "[field]");
	if NOT(err = _GetSearchBlock((*pbPtr->plugin_run_dataP), api_data, &exeMethodRecP->objRef, aCStr, &searchHeadP, &len, &ref, nil))
	{	if NOT(err = _SearchToSQL(api_data, searchHeadP, fieldName, &textBlock, &textLength, &textP, isNumeric, lowerCase))
		{	err = BAPI_StringToObj(api_data, textP, textLength, &exeMethodRecP->resultObjRef);
			DisposeBlock(&textBlock);
		}
		_ReleaseBlock(&ref);
	}

return err;
}

typedef XErr	(*SearchAddPropertyArray)(long api_data, SearchItem *sItemP, ObjRef *resultObjP);

//===========================================================================================
static XErr	_AddString(long api_data, SearchItem *sItemP, ObjRef *resultObjP)
{
	BAPI_InvalObjRef(api_data, resultObjP);
	return BAPI_StringToObj(api_data, sItemP->key, CLen(sItemP->key), resultObjP);
}

//===========================================================================================
static XErr	_AddOper(long api_data, SearchItem *sItemP, ObjRef *resultObjP)
{
	BAPI_InvalObjRef(api_data, resultObjP);
	return BAPI_IntToObj(api_data, sItemP->operat, resultObjP);
}

//===========================================================================================
static XErr	_AddGroup(long api_data, SearchItem *sItemP, ObjRef *resultObjP)
{
	BAPI_InvalObjRef(api_data, resultObjP);
	return BAPI_IntToObj(api_data, sItemP->group, resultObjP);
}

//===========================================================================================
static XErr	_AddFindType(long api_data, SearchItem *sItemP, ObjRef *resultObjP)
{
	BAPI_InvalObjRef(api_data, resultObjP);
	return BAPI_IntToObj(api_data, sItemP->wildChar, resultObjP);
}

//===========================================================================================
static XErr	_NewSearchArray(long api_data, long classID, SearchHeaderP searchHeadP, ObjRef *arrayP, SearchAddPropertyArray callBack)
{
long			totItems, i;
ObjRef			tObjRef;
XErr			err = noErr;
SearchItem		*sItemP;
Boolean			fixedSize;

	totItems = searchHeadP->totItems;
	if NOT(err = BAPI_FixedSize(api_data, classID, &fixedSize))
	{	if NOT(err = BAPI_ArrayToObj(api_data, fixedSize, nil, 0, nil, nil, arrayP))
		{	sItemP = &searchHeadP->sItem[0];
			for (i = 0; (i < totItems) && NOT(err); i++, sItemP++)
			{	if NOT(err = callBack(api_data, sItemP, &tObjRef))
					err = BAPI_ArrayAddElement(api_data, arrayP, nil, &tObjRef);
			}
		}
	}

return err;
}

//===========================================================================================
/*static XErr	_MyGetConfig(long api_data, char *configName, char *result, long *resultLenP, Boolean *isDefP, ObjRef *varObjRefP)
{
XErr		err = noErr;
Boolean		isDef;
	
	if (resultLenP)
		*resultLenP = 0;
	if (varObjRefP->id)
		isDef = true;
	else
		err = BAPI_IsVariableDefined(api_data, configName, APPLICATION, &isDef, varObjRefP);
	if NOT(err)
	{	if NOT(varObjRefP->classID)
			isDef = false;
		if (isDef)
			err = BAPI_ObjToString(api_data, varObjRefP, result, resultLenP, 255, kExplicitTypeCast);
		if (isDefP)
			*isDefP = isDef;
	}

return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	search_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec			*initRecP = &pbPtr->param.initRec.newClassRec;
XErr				err = noErr;
long				api_data = pbPtr->api_data;
BAPI_MemberRecord	searchProperty[TOT_PROPRIETIES] = 
					{	"tot", 			kTot,		"int",
						"mode", 		kMode,		"int",
						"string[]",		kString,	"string",
						"oper[]", 		kOper,		"int",
						"group[]", 		kGroup,		"int",
						"findType[]", 	kFindType,	"int"
					};
BAPI_MemberRecord	searchCostants[TOT_COSTANTS] = 
					{	"all", 			kALL,		"int",
						"allNot", 		kALLNOT,	"int",
						"and", 			kAND,		"int",
						"andNot", 		kANDNOT,	"int",
						"or", 			kOR,		"int",
						"orNot",		kORNOT,		"int",

						"contains",		kCONTAIN,	"int",
						"begins",		kBEGIN,		"int",
						"ends",			kEND,		"int",

						"noPar",		kNO_PAR,	"int",
						"openPar",		kOPEN_PAR,	"int",
						"closePar",		kCLOSE_PAR,	"int"
					};
BAPI_MemberRecord	searchMethods[TOT_METHODES] = 
					{	"SetOption",	kSetOption, "static void SetOption(string search_and, string search_or, string search_not, string search_wild)",
						//"Reprocess",	kReprocess, "void Reprocess(void)",
						"ToSQL",		kToSQL, 	"string ToSQL(string fieldName, boolean isNumeric, boolean lowerSQL)"
					};
BDBAPI_Init_CallBack	BDBAPI_Init_EP;

	gsStringClassID = BAPI_ClassIDFromName(api_data, "string", false);
	gsIntClassID = BAPI_ClassIDFromName(api_data, "int", false);
	if (err = BAPI_NewProperties(api_data, searchClassID, searchProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewConstants(api_data, searchClassID, searchCostants, TOT_COSTANTS, nil))
		return err;		
	if (err = BAPI_NewMethods(api_data, searchClassID, searchMethods, TOT_METHODES, nil))
		return err;

	if (err = BAPI_NewApplicationDefault(api_data, "SEARCH_AND", "\"&\"", "Default search AND operator"))
		return err;
	if (err = BAPI_NewApplicationDefault(api_data, "SEARCH_OR", "\"|\"", "Default search OR operator"))
		return err;
	if (err = BAPI_NewApplicationDefault(api_data, "SEARCH_NOT", "\"!\"", "Default search NOT operator"))
		return err;
	if (err = BAPI_NewApplicationDefault(api_data, "SEARCH_WILD", "\"*\"", "Default search WILD char"))
		return err;

	/*ClearBlock(&g_SEARCH_AND_ObjRef, sizeof(ObjRef));
	ClearBlock(&g_SEARCH_OR_ObjRef, sizeof(ObjRef));
	ClearBlock(&g_SEARCH_NOT_ObjRef, sizeof(ObjRef));
	ClearBlock(&g_SEARCH_WILD_ObjRef, sizeof(ObjRef));*/
	
	if NOT(err = BAPI_RegisterErrors(api_data, searchClassID, SEARCH_START_ERR, gSearchErrorsStr, TOT_ERRORS))
	{	if NOT(err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, "db", false), "BDBAPI_Init", (long*)&BDBAPI_Init_EP))
			err = BDBAPI_Init_EP(&bdbRec);
	}
	
return err;
}

//===========================================================================================
static XErr	search_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr	err = noErr;

	searchClassID = 0;
	
return err;
}

//===========================================================================================
static XErr	search_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			dataLen;
long			resultLen, api_data = pbPtr->api_data;
CStr255			aCStr;
Ptr				dataP;
BlockRef		bl, dataBlock = 0;
SearchHeaderP	searchHeadP;
BlockRef		ref;
long			booleanMode;
	
	if (clone)
	{	ObjRef	superObjRef;
	
		if NOT(err = _GetSearchBlock((*pbPtr->plugin_run_dataP), pbPtr->api_data, &constructorRecP->varRecsP[0].objRef, aCStr, &searchHeadP, &resultLen, &ref, &superObjRef))
		{	ObjRef	*objRefP;
		
			if NOT(BAPI_IsObjRefValid(api_data, &superObjRef))
			{	objRefP = &constructorRecP->varRecsP[0].objRef;
				if (BAPI_GetObjClassID(api_data, objRefP) == gsStringClassID)
					superObjRef = *objRefP;
				else
					err = BAPI_TypeCast(api_data, objRefP, gsStringClassID, &superObjRef, kImplicitTypeCast);
			}
			if NOT(err)
				err = BAPI_BufferToObjWithSuper(api_data, (Ptr)searchHeadP, resultLen, searchClassID, false, &superObjRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
			if (ref)
				_ReleaseBlock(&ref);
		}
	}
	else if (constructorRecP->totVars == 1)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &constructorRecP->varRecsP->objRef, aCStr, &dataP, &dataLen, &dataBlock, kImplicitTypeCast))
		{
		/*if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP->objRef, nil, &dataLen, 0, kImplicitTypeCast))
		{	if (dataLen < 255)
				dataP = aCStr;
			else
				dataBlock = NewBlockLocked(dataLen + 1, &err, &dataP);
			if NOT(err)
			{	long		booleanMode;
			
				if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP->objRef, dataP, &dataLen, dataLen, kImplicitTypeCast))
				{	*/
			booleanMode = 0;
			if NOT(err = _NewSearchRecord((*pbPtr->plugin_run_dataP), dataP, dataLen, booleanMode, &bl, &resultLen))
			{	LockBlock(bl);
				err = BAPI_BufferToObjWithSuper(api_data, GetPtr(bl), resultLen, searchClassID, false, &constructorRecP->varRecsP->objRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
				DisposeBlock(&bl);
			}
			BAPI_ReleaseBlock(&dataBlock);
				//if (dataBlock)
				//	DisposeBlock(&dataBlock);
			//}
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "search(string str)");
	}
	
	//if NOT(err)
		//BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, searchClassID);
		//constructorRecP->resultObjRef.classID = searchClassID;
		
return err;
}
//===========================================================================================
/*static XErr	search_Destructor(Biferno_ParamBlockPtr pbPtr)
{
	return _DestructSearchObj(pbPtr, pbPtr->api_data, &pbPtr->param.destructorRec.objRef);
}*/

//===========================================================================================
static XErr	search_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
//long				totParams = exeMethodRecP->totParams;

	switch(exeMethodRecP->methodID)
	{
		case kSetOption:
			if ((*pbPtr->plugin_run_dataP))
				err = _SetOption(pbPtr, exeMethodRecP, api_data);
			break;
		/*case kReprocess:
			err = _Reprocess(pbPtr, exeMethodRecP, api_data);
			break;*/
		case kToSQL:
			err = _ToSQL(pbPtr, exeMethodRecP, api_data);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}

//===========================================================================================
static XErr	search_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
int				idx;
long 			len, api_data = pbPtr->api_data;
SearchHeaderP 	searchHeadP;
CStr255			aCStr;
BlockRef		ref;

	if (getPropertyRec->isConstant)
		err = BAPI_IntToObj(api_data, getPropertyRec->propertyID, &getPropertyRec->resultObjRef);
	else
	{	if NOT(err = _GetSearchBlock((*pbPtr->plugin_run_dataP), api_data, &getPropertyRec->objRef, aCStr, &searchHeadP, &len, &ref, nil))
		{	switch(getPropertyRec->propertyID)
			{
				case kTot:
					err = BAPI_IntToObj(api_data, searchHeadP->totItems, &getPropertyRec->resultObjRef);
					break;
				case kMode:
					err = BAPI_IntToObj(api_data, searchHeadP->booleanMode, &getPropertyRec->resultObjRef);
					break;
				case kString:
					if (getPropertyRec->propertyDim && (idx = getPropertyRec->propertyIndex[0].ind) && (idx-- <= searchHeadP->totItems))
						err = BAPI_StringToObj(api_data, searchHeadP->sItem[idx].key, CLen(searchHeadP->sItem[idx].key), &getPropertyRec->resultObjRef);
					else
						err = _NewSearchArray(api_data, gsStringClassID, searchHeadP, &getPropertyRec->resultObjRef, _AddString);
					break;
				case kOper:
					if (getPropertyRec->propertyDim && (idx = getPropertyRec->propertyIndex[0].ind) && (idx-- <= searchHeadP->totItems))
						err = BAPI_IntToObj(api_data, searchHeadP->sItem[idx].operat, &getPropertyRec->resultObjRef);
					else
						err = _NewSearchArray(api_data, gsIntClassID, searchHeadP, &getPropertyRec->resultObjRef, _AddOper);
					break;
				case kGroup:
					if (getPropertyRec->propertyDim && (idx = getPropertyRec->propertyIndex[0].ind) && (idx-- <= searchHeadP->totItems))
						err = BAPI_IntToObj(api_data, searchHeadP->sItem[idx].group, &getPropertyRec->resultObjRef);
					else
						err = _NewSearchArray(api_data, gsIntClassID, searchHeadP, &getPropertyRec->resultObjRef, _AddGroup);
					break;
				case kFindType:
					if (getPropertyRec->propertyDim && (idx = getPropertyRec->propertyIndex[0].ind) && (idx-- <= searchHeadP->totItems))
						err = BAPI_IntToObj(api_data, searchHeadP->sItem[idx].wildChar, &getPropertyRec->resultObjRef);
					else
						err = _NewSearchArray(api_data, gsIntClassID, searchHeadP, &getPropertyRec->resultObjRef, _AddFindType);
					break;
				default:
					err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					break;
			}
			_ReleaseBlock(&ref);
		}
	}

return err;
}

//===========================================================================================
static XErr	search_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;
long 			idx, aLong, len, api_data = pbPtr->api_data;
SearchHeaderP 	searchHeadP;
CStr255			aCStr;
BlockRef		ref;
ObjRef			stringSuperObjRef;

	if ((setPropertyRec->propertyID == kTot) || (setPropertyRec->propertyID == kString))
		return XError(kBAPI_Error, Err_PropertyIsOnlyRead);

	if NOT(err = _GetSearchBlock((*pbPtr->plugin_run_dataP), api_data, &setPropertyRec->objRef, aCStr, &searchHeadP, &len, &ref, &stringSuperObjRef))
	{	if NOT(err = BAPI_ObjToInt(api_data, &setPropertyRec->value, &aLong, kImplicitTypeCast))
		{	switch(setPropertyRec->propertyID)
			{
				case kTot:
					err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
					break;
				case kMode:
					{
					BlockRef		resultBlockRef = 0L;
					
						if (NOT(aLong) || (aLong == kAND) || (aLong == kOR))
						{	searchHeadP->booleanMode = (short)aLong;
							if NOT(err = _ReallocSearchRecord(api_data, (*pbPtr->plugin_run_dataP), &stringSuperObjRef, searchHeadP->booleanMode, &resultBlockRef, &len))
							{	LockBlock(resultBlockRef);
								err = BAPI_ModifyObj(api_data, &setPropertyRec->objRef, GetPtr(resultBlockRef), len);
								DisposeBlock(&resultBlockRef);	// ex UnlockBlock
							}
						}
						else
							err = XError(kBAPI_ClassError, ErrUnsupportedMode);
					}
					break;
				case kString:
					err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
					break;
				case kOper:
					if NOT(idx = setPropertyRec->propertyIndex[0].ind)
						err = XError(kBAPI_ClassError, ErrIndexRequired);
					else if (idx-- <= searchHeadP->totItems)
					{	searchHeadP->sItem[idx].operat = (Byte)aLong;
						err = BAPI_ModifyObj(api_data, &setPropertyRec->objRef, (Ptr)searchHeadP, len);
					}
					else
						err = XError(kBAPI_Error, Err_OutOfBoundary);
					break;
				case kGroup:
					if NOT(idx = setPropertyRec->propertyIndex[0].ind)
						err = XError(kBAPI_ClassError, ErrIndexRequired);
					else if (idx-- <= searchHeadP->totItems)
					{	searchHeadP->sItem[idx].group = (Byte)aLong;
						err = BAPI_ModifyObj(api_data, &setPropertyRec->objRef, (Ptr)searchHeadP, len);
					}
					else
						err = XError(kBAPI_Error, Err_OutOfBoundary);
					break;
				case kFindType:
					if NOT(idx = setPropertyRec->propertyIndex[0].ind)
						err = XError(kBAPI_ClassError, ErrIndexRequired);
					else if (idx-- <= searchHeadP->totItems)
					{	searchHeadP->sItem[idx].wildChar = (Byte)aLong;
						err = BAPI_ModifyObj(api_data, &setPropertyRec->objRef, (Ptr)searchHeadP, len);
					}
					else
						err = XError(kBAPI_Error, Err_OutOfBoundary);
					break;
				default:
					err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					break;
			}
		}
		_ReleaseBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	search_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
long			superLen, len, strLen;
long			api_data = pbPtr->api_data;
SearchHeaderP 	searchHeadP;
CStr255			superCStr, aCStr;
BlockRef		superRef, textBlock = 0, ref = 0, ref2 = 0;
int				variant;
Ptr				superP, strP;
PrimitiveUnion	*param_d;
ObjRef			stringSuperObjRef;

	if NOT(err = _GetSearchBlock((*pbPtr->plugin_run_dataP), api_data, &typeCast->objRef, aCStr, &searchHeadP, &len, &ref, &stringSuperObjRef))
	{	param_d = &typeCast->result;
		if (typeCast->resultWanted == kCString)
			variant = param_d->text.variant;
		else
			variant = kNormal;
		if NOT(err = BAPI_GetStringBlock(api_data, &stringSuperObjRef, superCStr, &superP, &superLen, &superRef, kExplicitTypeCast))
		{	switch(param_d->text.variant)
			{
				case kNormal:
					strP = superP;
					strLen = superLen;
					break;

				case kForConstructor:
					strP = 	superP;
					strLen = superLen;
					err = StringEscaped(&strP, &strLen, &ref2);
					break;
					
				case kForDebug:
					err = _SearchToSQL(api_data, searchHeadP, "[field]", &textBlock, &strLen, &strP, false, false);
					break;
			}
			switch(typeCast->resultWanted)
			{	case kInt:
				case kLong:
				case kUnsigned:
				case kDouble:
					err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					break;
				case kBool:
					param_d->boolValue = (len != 0);
					break;
				case kCString:
					if NOT(err)
					{	if (param_d->text.stringP)
						{	if (param_d->text.stringMaxStorage >= (strLen + 1))	// 0 terminated
							{	CopyBlock(param_d->text.stringP, strP, strLen);
								param_d->text.stringP[strLen] = 0;
								param_d->text.stringLen = strLen;
							}
							else
							{	CopyBlock(param_d->text.stringP, strP, param_d->text.stringMaxStorage - 1);
								param_d->text.stringP[param_d->text.stringMaxStorage - 1] = 0;
								param_d->text.stringLen = strLen;
								err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
							}
						}
						else
							param_d->text.stringLen = strLen;
					}
					break;

				case kChar:
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
					break;
			}
			if (ref)
				_ReleaseBlock(&ref);
			if (ref2)
				DisposeBlock(&ref2);
			if (superRef)
				DisposeBlock(&superRef);
			if (textBlock)
				DisposeBlock(&textBlock);
		}
	}

return err;
}

//===========================================================================================
/*static XErr	search_GetErrDescr(Biferno_ParamBlockPtr pbPtr)
{
GetErrDescrRec		*getErrDescrRecP = &pbPtr->param.getErrDescrRec;
short				tErr;

	CEquStr(getErrDescrRecP->errType, "Class search Error");
	if (((tErr = getErrDescrRecP->err) >= SEARCH_START_ERR) && (tErr < lastErr))
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, gSearchErrorsStr[tErr - SEARCH_START_ERR]);
	}
	else
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, "Unknown Error");
	}

return noErr;
}

//===========================================================================================
static XErr	search_GetErrNumber(Biferno_ParamBlockPtr pbPtr)
{
GetErrNumber	*getErrNumberP = &pbPtr->param.getErrNumber;
char			*strP = getErrNumberP->errName;

	if NOT(CCompareStrings_cs(strP, "Err_TooManySearchStrings"))
		getErrNumberP->errNumber = Err_TooManySearchStrings;

return noErr;
}*/

//===========================================================================================
/*
static XErr	search_GetSuperObj(Biferno_ParamBlockPtr pbPtr)
{
GetSuperObjRec		*getSuperObjRec = &pbPtr->param.getSuperObjRec;
long				tLen;
XErr				err = noErr;

	tLen = sizeof(ObjRef);
	err = BAPI_ReadObj(pbPtr->api_data, &getSuperObjRec->objRef, (Ptr)&getSuperObjRec->superObjRef, &tLen, offsetof(SearchHeader, stringSuperObjRef)+1, nil);

return err;
}
*/

//===========================================================================================
static XErr	search_Run(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
SearchOptionP	optionP;
BlockRef		bl = 0;
CStr255			tempStr;
long			tempLen, api_data = pbPtr->api_data;
Boolean			isDef;

	if (bl = NewBlockLocked(sizeof(SearchOption), &err, (Ptr*)&optionP))
	{	//LockBlock(bl);	// remain locked
		// SEARCH_AND
		//optionP = (SearchOptionP)GetPtr(bl);
		if (err = BAPI_GetConfig(api_data, "SEARCH_AND", tempStr, &tempLen, &isDef))
			goto out;
		if (isDef)
		{	if (tempLen > (MAX_STR-1))
				tempStr[MAX_STR-1] = 0;
			CEquStr(optionP->andStr, tempStr);
		}
		else
			CEquStr(optionP->andStr, "&");

		// SEARCH_OR
		if (err = BAPI_GetConfig(api_data, "SEARCH_OR", tempStr, &tempLen, &isDef))
			goto out;
		if (isDef)
		{	if (tempLen > (MAX_STR-1))
				tempStr[MAX_STR-1] = 0;
			CEquStr(optionP->orStr, tempStr);
		}
		else
			CEquStr(optionP->orStr, "|");
	
		// SEARCH_NOT
		if (err = BAPI_GetConfig(api_data, "SEARCH_NOT", tempStr, &tempLen, &isDef))
			goto out;
		if (isDef)
		{	if (tempLen > (MAX_STR-1))
				tempStr[MAX_STR-1] = 0;
			CEquStr(optionP->notStr, tempStr);
		}
		else
			CEquStr(optionP->notStr, "!");
	
		// SEARCH_WILD
		if (err = BAPI_GetConfig(api_data, "SEARCH_WILD", tempStr, &tempLen, &isDef))
			goto out;
		if (isDef)
		{	if (tempLen > (MAX_STR-1))
				tempStr[MAX_STR-1] = 0;
			CEquStr(optionP->wildStr, tempStr);
		}
		else
			CEquStr(optionP->wildStr, "*");

		optionP->andStrLen = CLen(optionP->andStr);
		optionP->orStrLen = CLen(optionP->orStr);
		optionP->notStrLen = CLen(optionP->notStr);
		optionP->wildStrLen = CLen(optionP->wildStr);

		(*pbPtr->plugin_run_dataP) = bl;
	}

out:
if (err && bl)
	DisposeBlock(&bl);
return err;
}

//===========================================================================================
static XErr	search_Exit(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
BlockRef	bl;

	bl = (*pbPtr->plugin_run_dataP);
	DisposeBlock(&bl);
	
return err;
}

//===========================================================================================
static XErr	search_SuperIsChanged(Biferno_ParamBlockPtr pbPtr)
{
	return _ReprocessLow((*pbPtr->plugin_run_dataP), &pbPtr->param.superIsChangedRec.objRef, pbPtr->api_data, nil);
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	search_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "search");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "");
			gsApiVersion = pbPtr->param.registerRec.api_version;
			searchClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = false;
			CEquStr(pbPtr->param.registerRec.extendedClass, "string");
			CEquStr(pbPtr->param.registerRec.constructor, "void search(string query)");
			break;
		case kInit:
			err = search_Init(pbPtr);
			break;
		case kShutDown:
			err = search_ShutDown(pbPtr);
			break;
		case kRun:
			err = search_Run(pbPtr);
			break;
		case kExit:
			err = search_Exit(pbPtr);
			break;
		case kConstructor:
		case kTypeCast:
			err = search_Constructor(pbPtr, false);
			break;
		case kClone:
			err = search_Constructor(pbPtr, true);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
		case kExecuteMethod:
			err = search_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = search_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = search_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = search_TypeCast(pbPtr);
			break;
		case kSuperIsChanged:
			err = search_SuperIsChanged(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
		
return err;
}
#if __MWERKS__
#pragma export off
#endif

