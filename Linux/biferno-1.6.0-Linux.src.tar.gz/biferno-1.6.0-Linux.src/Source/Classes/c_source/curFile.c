/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: curFile.c,v 1.6 2003-06-26 17:02:38 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"BfrHeader.h"
#include 	"File.h"

// defines
#define	gsPlugName	"curFile"

// Methods
/*enum{
		kForceCache = 1,
		kNoCache
	};
#define TOT_METHODES	2
*/

// Properties
#define TOT_PROPRIETIES	5
enum{
		kBasePath,
		kPath,
		kCurLine,
		kFromCache,
		kCache
	};

static 	long	gsApiVersion, curFileClassID;

//===========================================================================================
static XErr	_CurFileRegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	curFileProperty[TOT_PROPRIETIES] = 
					{	"basePath",		kBasePath,		"static string",
						"path",			kPath,			"static string",
						"curLine",		kCurLine,		"static int",
						"fromCache",	kFromCache,		"static boolean",
						"cache",		kCache,			"static boolean"
					};
/*BAPI_MemberRecord	curFileMethods[TOT_METHODES] = 
					{	
						"ForceCache",	kForceCache,		"static void ForceCache(void)",
						"NoCache",		kNoCache,			"static void NoCache(void)"
					};
*/

	if (err = BAPI_NewProperties(api_data, curFileClassID, curFileProperty, TOT_PROPRIETIES, nil))
		return err;		
	
	//if (err = BAPI_NewMethods(api_data, curFileClassID, curFileMethods, TOT_METHODES, nil))
	//	return err;

//out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	curFile_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	curFileClassID = pbPtr->param.registerRec.pluginID;
	
return err;
}

//===========================================================================================
static XErr	curFile_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _CurFileRegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
/*static XErr	curFile_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;

	switch(exeMethodRecP->methodID)
	{
		case kForceCache:
			err = BAPI_SetFileCacheState(api_data, true);
			break;
		case kNoCache:
			err = BAPI_SetFileCacheState(api_data, false);
			break;
	}

return err;
}
*/
//===========================================================================================
static XErr	curFile_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRecP = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			curLine, api_data = pbPtr->api_data;
CStr255			aCStr, basePath;
Boolean			willBeCached, fromCache;

	switch(getPropertyRecP->propertyID)
	{
		case kBasePath:
			if NOT(err = BAPI_GetCurrentBasePath(api_data, basePath, false))
			{	CEquStr(aCStr, FILE_HD_PREFIX);
				CAddStr(aCStr, basePath);
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRecP->resultObjRef);
			}
			break;
		case kPath:
			if NOT(err = BAPI_GetCurrentFilePath(api_data, aCStr, nil, nil, nil))
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRecP->resultObjRef);
			break;
		case kCurLine:
			if NOT(err = BAPI_GetCurrentFilePath(api_data, nil, &curLine, nil, nil))
				err = BAPI_IntToObj(api_data, curLine, &getPropertyRecP->resultObjRef);
			break;
		case kFromCache:
			if NOT(err = BAPI_GetCurrentFilePath(api_data, nil, nil, &fromCache, nil))
				err = BAPI_BooleanToObj(api_data, fromCache, &getPropertyRecP->resultObjRef);
			break;
		case kCache:
			if NOT(err = BAPI_GetCurrentFilePath(api_data, nil, nil, nil, &willBeCached))
				err = BAPI_BooleanToObj(api_data, willBeCached, &getPropertyRecP->resultObjRef);
			break;
		default:
			break;
	}

return err;
}

//===========================================================================================
static XErr	curFile_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;
long			api_data = pbPtr->api_data;
Boolean			cacheState;

	switch(setPropertyRec->propertyID)
	{
		case kBasePath:
		case kPath:
		case kCurLine:
		case kFromCache:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;

		case kCache:
			if NOT(err = BAPI_ObjToBoolean(api_data, &setPropertyRec->value, &cacheState, kImplicitTypeCast))
				err = BAPI_SetFileCacheState(api_data, cacheState);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	curFile_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = curFile_Register(pbPtr);
			break;
		case kInit:
			err = curFile_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			//err = curFile_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = curFile_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = curFile_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


