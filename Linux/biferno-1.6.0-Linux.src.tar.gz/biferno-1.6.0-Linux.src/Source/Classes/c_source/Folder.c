/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Folder.c,v 1.22 2004-05-05 14:25:29 valfer Exp $
	|______________________________________________________________________________
*/
#ifdef __UNIX_XLIB__
	#include <sys/types.h>
	#include <sys/stat.h>
#endif

#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include 	"BfrTime.h"

#include <string.h>

typedef struct FolderRec
{
	CStr255		path;
	long		openMode;
} FolderRec;

typedef struct {
				char	*error;
				long	api_data;
				char	*funcNameP;
				ObjRef	userDataObjRef;
				//Ptr		userData_expP;
				//long	userData_expLen;
				XErr	returnedError;
				ObjRef	thisObj;		// if callBack is a method
				Boolean	isMethod;
				Byte	pad;
				short	pad2;
				} WalkFolderUserData;


// Errors
#define	START_ERR	200
enum {
		ErrItemIsAlias = START_ERR,
		ErrItemIsNotFolder,
		ErrBadOpenMode,
		ErrFolderExists,
		ErrFolderNotFound,
		ErrBadName
		//ErrBadUserData
};

CStr63	gFolderErrorsStr[] = 
	{	
		"ErrItemIsAlias",
		"ErrItemIsNotFolder",
		"ErrBadOpenMode",
		"ErrFolderExists",
		"ErrFolderNotFound",
		"ErrBadName"
		//"ErrBadUserData"
		};
#define	TOT_ERRORS	6

// defines
#define	gsPlugName	"folder"

static 	long		folderClassID;
static 	long		gsApiVersion, gsTimeClassID, gsStringClassID;


static 	time_TimeRecToObjRef_Prot	gsTimeRecToObjRef;
static 	time_ObjRefToTimeRec_Prot	gsObjRefToTimeRec;

// Costants
#define TOT_COSTANTS	12

// Properties
enum{
		kPath = 1,
		kName,
		kOpenMode,
		kCreatTime,
		kModifTime,
		kUser,
		kGroup,

		kCREATE_FOLDER_NEW,
		//kCREATE_FOLDER_ALWAYS,
		kFOLDER_EXISTING,
		kFOLDER_IF_NEEDED,

		cS_IRUSR,
		cS_IWUSR,
		cS_IXUSR,
		cS_IRGRP,
		cS_IWGRP,
		cS_IXGRP,
		cS_IROTH,
		cS_IWOTH,
		cS_IXOTH
	} Folder_Property;

#define TOT_PROPRIETIES	7

// Methods
enum{
		kCreate = 1,
		kDelete,
		kMakeAlias,
		kRename,
		kWalk,
		k_fchmod,
		k_fgetmod,
		//k_fgetuser,
		//k_fgetgroup
	} Folder_Method;
#define TOT_METHODES	7

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	folderMethods[TOT_METHODES] = 
					{	
						"Create",		kCreate,		"static void Create(string path)",
						"Delete",		kDelete,		"void Delete(void)",
						"MakeAlias",	kMakeAlias,		"void MakeAlias(string aliasPath)",
						"Rename",		kRename,		"void Rename(string newName)",
						"Walk",			kWalk,			"int Walk(string suffix, boolean recursive, string callBack, obj *userdata)",
						"fchmod",		k_fchmod,		"static void fchmod(string filePath, int flags)",
						"fgetmod",		k_fgetmod,		"static string fgetmod(string filePath)"
					};

BAPI_MemberRecord	folderProperty[TOT_PROPRIETIES] = 
					{	"path", 			kPath,			"string",
						"name", 			kName,			"string",
						"openMode",			kOpenMode,		"int",
						"creatTime",		kCreatTime,		"time",
						"modifTime",		kModifTime,		"time",
						"user",				kUser,			"string",
						"group",			kGroup,			"string"
					};

BAPI_MemberRecord	folderCostants[TOT_COSTANTS] = 
					{	"createFolderNew", 		kCREATE_FOLDER_NEW,		"int",
						"folderExisting", 		kFOLDER_EXISTING,		"int",
						"createFolderIfNeeded", kFOLDER_IF_NEEDED,		"int",
						"S_IRUSR",				cS_IRUSR,				"int",
						"S_IWUSR",				cS_IWUSR,				"int",
						"S_IXUSR",				cS_IXUSR,				"int",

						"S_IRGRP",				cS_IRGRP,				"int",
						"S_IWGRP",				cS_IWGRP,				"int",
						"S_IXGRP",				cS_IXGRP,				"int",

						"S_IROTH",				cS_IROTH,				"int",
						"S_IWOTH",				cS_IWOTH,				"int",
						"S_IXOTH",				cS_IXOTH,				"int"
					};


	if (err = BAPI_NewProperties(api_data, folderClassID, folderProperty, TOT_PROPRIETIES, nil))
		return err;		

	if (err = BAPI_NewMethods(api_data, folderClassID, folderMethods, TOT_METHODES, nil))
		return err;
	
	if (err = BAPI_NewConstants(api_data, folderClassID, folderCostants, TOT_COSTANTS, nil))
		return err;
	
	err = BAPI_RegisterErrors(api_data, folderClassID, START_ERR, gFolderErrorsStr, TOT_ERRORS);

//out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static void	_OpenModeStr(long openMode, char *tStr)
{
	switch(openMode)
	{
		case kCREATE_FOLDER_NEW:
			CEquStr(tStr, "createFolderNew");
			break;
		case kFOLDER_EXISTING:
			CEquStr(tStr, "folderExisting");
			break;
		case kFOLDER_IF_NEEDED:
			CEquStr(tStr, "createFolderIfNeeded");
			break;
		default:
			*tStr = 0;
	}
}

//===========================================================================================
static XErr	_fchmod(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
long 			modeFlags;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = BAPI_ObjToInt(api_data, &paramsP[1].objRef, &modeFlags, kImplicitTypeCast))
					err = ChangeFileMode(0, filePath, modeFlags);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_fgetmod(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{

XErr			err = noErr;
long			mode, api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = GetFileMode(0, filePath, &mode))
				err = BAPI_IntToObj(api_data, mode, &execMethodRecP->resultObjRef);
			/*errno = 0;
			if (lstat(filePath, &theStat) < 0)
				err = errno;
			
			if NOT(err = GetXFileInfo(filePath, &xFileInfo))
				err = BAPI_IntToObj(api_data, GetMode(filePath), &execMethodRecP->resultObjRef);
			*/
		}
	}

return err;	
/*
ex
XErr			err = noErr;
long			api_data = pbPtr->api_data;
#ifdef __UNIX_XLIB__
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
XFileInfo 		xFileInfo;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = GetXFileInfo(filePath, &xFileInfo))
				err = BAPI_IntToObj(api_data, xFileInfo.st_mode, &execMethodRecP->resultObjRef);
		}
	}

#else
	err = BAPI_IntToObj(api_data, 0xFFFFFFFF, &execMethodRecP->resultObjRef);
#endif
*/
return err;
}

//===========================================================================================
/*static XErr	_fgetuser(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
#ifdef __UNIX_XLIB__
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
XFileInfo 		xFileInfo;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = GetXFileInfo(filePath, &xFileInfo))
				err = BAPI_StringToObj(api_data, xFileInfo.user, CLen(xFileInfo.user), &execMethodRecP->resultObjRef);
		}
	}

#else
	err = BAPI_StringToObj(api_data, "", 0, &execMethodRecP->resultObjRef);
#endif
	
return err;
}

//===========================================================================================
static XErr	_fgetgroup(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
#ifdef __UNIX_XLIB__
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
XFileInfo 		xFileInfo;
CStr255			filePath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
		{	if NOT(err = GetXFileInfo(filePath, &xFileInfo))
				err = BAPI_StringToObj(api_data, xFileInfo.group, CLen(xFileInfo.group), &execMethodRecP->resultObjRef);
		}
	}

#else
	err = BAPI_StringToObj(api_data, "", 0, &execMethodRecP->resultObjRef);
#endif
	
return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_NewFolder(Biferno_ParamBlockPtr pbPtr, char *folderPath)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
//long			api_data = pbPtr->api_data;

	err = CreateXFolder(folderPath);
	
return err;
}

//===========================================================================================
static XErr	_CreateFolder(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
long			foldPathLen, api_data = pbPtr->api_data;
ParameterRec 	*paramsP = pbPtr->param.executeMethodRec.paramVarsP;
XFilePath		foldPath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, foldPath, &foldPathLen, 255, kImplicitTypeCast))
	{	// Add last '/' if doesn't exists
		if (foldPath[foldPathLen-1] != '/')
			CAddChar(foldPath, '/');
		err = BAPI_RealPath(api_data, foldPath, true);
		if ((err == XError(kXLibError, ErrXFiles_FolderNotFound)) || (err == XError(kXLibError, ErrXFiles_FileNotFound)))
			err = CreateXFolder(foldPath);
	}
	
return err;
}

//===========================================================================================
static XErr	_DeleteFolder(Biferno_ParamBlockPtr pbPtr, char *folderPath)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
//long			api_data = pbPtr->api_data;

	err = DeleteXFolder(folderPath);
	
return err;
}

//===========================================================================================
static XErr	_RenameFolder(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FolderRec *folderRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
//long 			totParams = exeMethodRecP->totParams;
CStr255			newName;
char			*strP;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, newName, nil, 255, kImplicitTypeCast))
	{	if (*newName)
		{	if NOT(err = RenameXFolder(folderRecP->path, newName))
			{	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
				{	if (strP = strrchr(folderRecP->path, '/'))
					{	*strP = 0;
						if (strP = strrchr(folderRecP->path, '/'))
						{	CEquStr(strP+1, newName);
							CAddChar(folderRecP->path, '/');
							err = BAPI_ModifyObj(api_data, &exeMethodRecP->objRef, (Ptr)folderRecP, sizeof(FolderRec));
						}
					}
				}
			}
		}
		else
			err = XError(kBAPI_ClassError, ErrBadName);
	}
	
return err;
}

//===========================================================================================
static XErr	_MakeAlias(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, FolderRec *folderRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = exeMethodRecP->paramVarsP;
//long 			totParams = exeMethodRecP->totParams;
CStr255			aliasPath;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, aliasPath, nil, 255, kImplicitTypeCast))
	{	err = BAPI_RealPath(api_data, aliasPath, false);
		if (err == XError(kXLibError, ErrXFiles_FileNotFound))
			err = noErr;
		err = XMakeAlias(folderRecP->path, aliasPath);
	}

return err;
}

//===========================================================================================
static XErr	_WalkFolderCallBack(char *folderPath, long variant, long userData)
{
ParameterRec		param[3];
WalkFolderUserData	*wfUserDataRecP = (WalkFolderUserData*)userData;
ObjRef				result;
long				status, theError, totParams;
XErr				err = noErr;
CStr255				tempStr;

	ClearBlock(param, sizeof(ParameterRec) * 3);
	if (BAPI_IsObjRefValid(wfUserDataRecP->api_data, &wfUserDataRecP->userDataObjRef))
	{	totParams = 3;
		param[2].objRef = wfUserDataRecP->userDataObjRef;
		//param[2].expP = wfUserDataRecP->userData_expP;
		//param[2].expLen = wfUserDataRecP->userData_expLen;
	}
	else
		totParams = 2;
	if NOT(err)
	{	
	#ifdef __MAC_XLIB__
		CSubstitute(folderPath, ':', '/');
	#endif
		CEquStr(tempStr, FILE_HD_PREFIX);
		CAddStr(tempStr, folderPath);
		if NOT(err = BAPI_StringToObj(wfUserDataRecP->api_data, tempStr, CLen(tempStr), &param[0].objRef))
		{	if NOT(err = BAPI_IntToObj(wfUserDataRecP->api_data, variant, &param[1].objRef))
			{	if (wfUserDataRecP->isMethod)
					err = BAPI_ExecuteMethod(wfUserDataRecP->api_data, &wfUserDataRecP->thisObj, param, totParams, wfUserDataRecP->funcNameP, &result, nil);
				else
					err = BAPI_ExecuteFunction(wfUserDataRecP->api_data, param, totParams, wfUserDataRecP->funcNameP, &result);
				if NOT(err)
				{	/*if (wfUserDataRecP->userDataIsTemp)
					{	
						//If userdata is temp (i.e. &a.length) the last callBack modified the property value
						//while wfUserDataRecP->userDataObjRef retain yet the old value, so update it with an Eval.
						err = BAPI_Eval(wfUserDataRecP->api_data, wfUserDataRecP->userData_expP, wfUserDataRecP->userData_expLen, &wfUserDataRecP->userDataObjRef, true);
					}
					
					if NOT(err)
					{	
					*/
					err = BAPI_ObjToInt(wfUserDataRecP->api_data, &result, &theError, kImplicitTypeCast);
					if (NOT(err) && theError)
						err = theError;
					BAPI_GetCurrentScriptStatus(wfUserDataRecP->api_data, &status);
					if (theError || (status == kSTOPPED) || (status == kEXITED))
					{	wfUserDataRecP->returnedError = theError;
						err = XError(kXLibError, ErrXFiles_WalkFolderAbort);
					}
					//}
				}
				else if (err == XError(kBAPI_Error, Err_PrototypeMismatch))
				{	if (wfUserDataRecP->isMethod)
						CEquStr(wfUserDataRecP->error, "Walk callback prototype is: static int MyMethod(string path, int variant, obj *userData)");
					else
						CEquStr(wfUserDataRecP->error, "Walk callback prototype is: int MyFunction(string path, int variant, obj *userData)");
				}
			}
		}
	}

return err;
}

//===========================================================================================
static void	_GetCallBackType(long api_data, char *callBackName, char *className, char *memberName, ObjRef *thisObjP, Boolean *isMethodP)
{
char		*strP;
int			tLen;
long		classID;
XErr		err = noErr;

	*className = *memberName = 0;
	if (strP = strchr(callBackName, '.'))
	{	tLen = CLen(callBackName);
		if (strP < callBackName + tLen - 1)
		{	*strP = 0;
			CEquStr(className, callBackName);
			CEquStr(memberName, strP+1);
			if (classID = BAPI_ClassIDFromName(api_data, className, false))
			{	ClearBlock(thisObjP, sizeof(ObjRef));
				BAPI_SetObjClassID(api_data, thisObjP, classID);
				*isMethodP = true;
			}
			else
				err = XError(kBAPI_Error, Err_NoSuchClass);
		}
	}
	else
	{	*isMethodP = false;
		CEquStr(className, "function");
		CEquStr(memberName, callBackName);
	}
}

//===========================================================================================
static XErr	_WalkFolder(Biferno_ParamBlockPtr pbPtr, long api_data, ExecuteMethodRec *exeMethodRecP, FolderRec *folderRecP)
{
XErr				err = noErr;
CStr255				callBackName;
CStr63				className, memberName;
CStr15				suffix;
long				userData, len;
Boolean				recursive;
WalkFolderUserData	wfUserDataRec;
char				*tSuffP;
//long				totParams = exeMethodRecP->totParams;
long				thirdClassID;
ParameterRec		*paramP = exeMethodRecP->paramVarsP;
char				*strP;
Boolean				wasToDestruct;
	
	if NOT(err = BAPI_ObjToString(api_data, &paramP[0].objRef, suffix, &len, 15, kImplicitTypeCast))
	{	suffix[len] = 0;
		if NOT(CCompareStrings_cs(suffix, ".*"))
			tSuffP = nil;
		else
			tSuffP = suffix;
		if NOT(err = BAPI_ObjToBoolean(api_data, &paramP[1].objRef, &recursive, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &paramP[2].objRef, callBackName, &len, 63, kImplicitTypeCast))
			{	
			BlockRef	docBlockRef;
			
				_GetCallBackType(api_data, callBackName, className, memberName, &wfUserDataRec.thisObj, &wfUserDataRec.isMethod);
				if NOT(err = BAPI_GetMemberDoc(api_data, className, memberName, &docBlockRef, false))
				{	
				BAPI_Doc	*docP = (BAPI_Doc*)GetPtr(docBlockRef);
					
					if (docP->totParams >= 3)
						thirdClassID = docP->params[2].classID;
					else
						thirdClassID = 0;
					BAPI_ReleaseMemberDoc(api_data, &docBlockRef);
					wfUserDataRec.api_data = api_data;
					wfUserDataRec.funcNameP = memberName;	//callBackName;
					wfUserDataRec.returnedError = noErr;
					wfUserDataRec.error = pbPtr->error;
					if (thirdClassID)
					{	wfUserDataRec.userDataObjRef = paramP[3].objRef;						
						//wfUserDataRec.userData_expP = paramP[3].expP;
						//wfUserDataRec.userData_expLen = paramP[3].expLen;
						if NOT(err = BAPI_IsObjRefToDestruct(api_data, &wfUserDataRec.userDataObjRef, &wasToDestruct))
							err = BAPI_AvoidDestructor(api_data, &wfUserDataRec.userDataObjRef, kDLMWhole);
					}
					else
						err = BAPI_InvalObjRef(api_data, &wfUserDataRec.userDataObjRef);
					if NOT(err)
					{	userData = (long)&wfUserDataRec;
						if NOT(err = WalkXFolder(folderRecP->path, tSuffP, recursive, _WalkFolderCallBack, userData))
							err = BAPI_IntToObj(api_data, wfUserDataRec.returnedError, &exeMethodRecP->resultObjRef);
						if (thirdClassID && wasToDestruct)
							BAPI_ForceDestructor(api_data, &wfUserDataRec.userDataObjRef, kDLMWhole);
					}
				}
				else
				{	if ((err == XError(kBAPI_Error, Err_NoSuchFunction)) || (err == XError(kBAPI_Error, Err_NoSuchMember)))
						strP = memberName;
					else
						strP = className;
					CEquStr(pbPtr->error, "Cannot find ");
					CAddStr(pbPtr->error, strP);
				}
			}
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Folder_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	gsTimeClassID = BAPI_ClassIDFromName(api_data, "time", false);
	gsStringClassID = BAPI_ClassIDFromName(api_data, "string", false);
	if NOT(err = BAPI_GetSymbol(api_data, gsTimeClassID, "time_ObjRefToTimeRec", (long*)&gsObjRefToTimeRec))
	{	if NOT(err = BAPI_GetSymbol(api_data, gsTimeClassID, "time_TimeRecToObjRef", (long*)&gsTimeRecToObjRef))
			err = _RegisterListMembers(api_data);
	}
		
return err;
}

//===========================================================================================
static XErr	Folder_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	folderClassID = 0;
	
return noErr;
}

//===========================================================================================
static XErr	Folder_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr			err = noErr, pathError = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data;
long			tLen;
FolderRec		folderRec;
ParameterRec	*paramVarsP;
Boolean			isAlias = false, isFolder;

	ClearBlock(&folderRec, sizeof(FolderRec));
	if (clone)
	{	if (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP[0].objRef) == folderClassID)
		{	tLen = sizeof(FolderRec);
			if NOT(err = BAPI_GetObj(pbPtr->api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&folderRec, &tLen, 0, nil))
				err = BAPI_BufferToObj(api_data, (Ptr)&folderRec, sizeof(FolderRec), folderClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
		else
			err = XError(kBAPI_Error, Err_IllegalOperation);
	}
	else
	{	paramVarsP = constructorRecP->varRecsP;
		err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, folderRec.path, nil, 255, kImplicitTypeCast);
		if (err && (err == (XError(kBAPI_Error, Err_BAPI_BufferTooSmall))))
			err = (XError(kBAPI_Error, Err_PathTooLong));
		if NOT(err)
		{	int	foldPathLen = CLen(folderRec.path);
		
			if (foldPathLen && (folderRec.path[foldPathLen-1] != '/'))
				CAddChar(folderRec.path, '/');
			if NOT(pathError = BAPI_RealPath(api_data, folderRec.path, true))
				err = XIsAlias(folderRec.path, &isAlias);
			else if ((pathError != XError(kXLibError, ErrXFiles_FileNotFound)) && (pathError != XError(kXLibError, ErrXFiles_FolderNotFound)))
				err = pathError;
			if NOT(err)
			{	if (*folderRec.path != '/')
				{	//pathError = BAPI_RealPath(api_data, folderRec.path, false);
					CDebugStr("Illegal folder path (in constr)");
				}
			}
			if NOT(err)
			{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &folderRec.openMode, kImplicitTypeCast))
				{	if NOT(folderRec.openMode)
						folderRec.openMode = kFOLDER_EXISTING;
				}
				if (NOT(err) && ((folderRec.openMode < kCREATE_FOLDER_NEW) || (folderRec.openMode > kFOLDER_IF_NEEDED)))
					err = XError(kBAPI_ClassError, ErrBadOpenMode);
				if (isAlias)
					err = XError(kBAPI_ClassError, ErrItemIsAlias);
				else
				{	if NOT(pathError)
						err = XIsFolder(folderRec.path, &isFolder);
					else
					{	if (folderRec.openMode == kFOLDER_EXISTING)
							err = pathError;
						else
							isFolder = true;
					}
					if NOT(err)
					{	if NOT(isFolder)
							err = XError(kBAPI_ClassError, ErrItemIsNotFolder);
						else
						{	/*if ((folderRec.openMode == kCREATE_FOLDER_NEW) && NOT(pathError))
								err = _DeleteFolder(pbPtr, folderRec.path);
							if NOT(err)
							{	*/
							if ((folderRec.openMode == kCREATE_FOLDER_NEW) && NOT(pathError))
								err = XError(kBAPI_ClassError, ErrFolderExists);
							if NOT(err)
							{	if ((pathError == XError(kXLibError, ErrXFiles_FolderNotFound)) || (pathError == XError(kXLibError, ErrXFiles_FileNotFound)))
									err = _NewFolder(pbPtr, folderRec.path);
								if NOT(err)
									err = BAPI_BufferToObj(api_data, (Ptr)&folderRec, sizeof(FolderRec), folderClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
							}
							//}
						}
					}
				}
			}
		}
	}

	if NOT(err)
		;//BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, folderClassID);
		// constructorRecP->resultObjRef.classID = folderClassID;
	else if NOT(*pbPtr->error)
	{	if (err == XError(kXLibError, ErrXFiles_FileNotFound))
			err = XError(kBAPI_ClassError, ErrFolderNotFound);
		CEquStr(pbPtr->error, folderRec.path);
	}
		
return err;
}

//===========================================================================================
static XErr	Folder_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				tLen;
FolderRec			folderRec1, folderRec2;
Boolean				res;

	if (exeOperationRecP->operation == EVAL_EQUA)
	{	tLen = sizeof(FolderRec);
		if (err = BAPI_ReadObj(pbPtr->api_data, &exeOperationRecP->objRef1, (Ptr)&folderRec1, &tLen, 0, nil))
			goto out;	
		if (err = BAPI_ReadObj(pbPtr->api_data, &exeOperationRecP->objRef2, (Ptr)&folderRec2, &tLen, 0, nil))
			goto out;	
		res = NOT(CCompareStrings_cs(folderRec1.path, folderRec2.path));
		err = BAPI_BooleanToObj(pbPtr->api_data, res, &exeOperationRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);

out:
return err;
}

//===========================================================================================
static XErr	Folder_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				tLen, api_data = pbPtr->api_data;
FolderRec			folderRec;

	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
	{	tLen = sizeof(FolderRec);
		err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&folderRec, &tLen, 0, nil);
	}
	else
		ClearBlock(&folderRec, sizeof(FolderRec));
	if NOT(err)
	{	switch(exeMethodRecP->methodID)
		{	case kCreate:
				err = _CreateFolder(pbPtr);
				break;
			case kDelete:
				err = _DeleteFolder(pbPtr, folderRec.path);
				break;
			case kMakeAlias:
				err = _MakeAlias(pbPtr, exeMethodRecP, &folderRec);
				break;
			case kRename:
				err = _RenameFolder(pbPtr, exeMethodRecP, &folderRec);
				break;
			case kWalk:
				err = _WalkFolder(pbPtr, api_data, exeMethodRecP, &folderRec);
				break;
			case k_fchmod:
				err = _fchmod(pbPtr, exeMethodRecP);
				break;
			case k_fgetmod:
				err = _fgetmod(pbPtr, exeMethodRecP);
				break;
			/*case k_fgetuser:
				err = _fgetuser(pbPtr, exeMethodRecP);
				break;
			case k_fgetgroup:
				err = _fgetgroup(pbPtr, exeMethodRecP);
				break;*/
			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
	}

return err;
}

//===========================================================================================
static XErr	Folder_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
FolderRec		folderRec;
long			strpLen, tLen, api_data = pbPtr->api_data;
CStr255			tempStr;
char			*strP;

	if (getPropertyRec->isConstant)
	{	switch(getPropertyRec->propertyID)
		{	case kCREATE_FOLDER_NEW:
				err = BAPI_IntToObj(api_data, kCREATE_FOLDER_NEW, &getPropertyRec->resultObjRef);			
				break;
			/*case kCREATE_FOLDER_ALWAYS:
				err = BAPI_IntToObj(api_data, kCREATE_FOLDER_ALWAYS, &getPropertyRec->resultObjRef);			
				break;*/
			case kFOLDER_EXISTING:
				err = BAPI_IntToObj(api_data, kFOLDER_EXISTING, &getPropertyRec->resultObjRef);			
				break;
			case kFOLDER_IF_NEEDED:
				err = BAPI_IntToObj(api_data, kFOLDER_IF_NEEDED, &getPropertyRec->resultObjRef);			
				break;
			case cS_IRUSR:
				err = BAPI_IntToObj(api_data, kS_IRUSR, &getPropertyRec->resultObjRef);			
				break;
			case cS_IWUSR:
				err = BAPI_IntToObj(api_data, kS_IWUSR, &getPropertyRec->resultObjRef);			
				break;
			case cS_IXUSR:
				err = BAPI_IntToObj(api_data, kS_IXUSR, &getPropertyRec->resultObjRef);			
				break;
			case cS_IRGRP:
				err = BAPI_IntToObj(api_data, kS_IRGRP, &getPropertyRec->resultObjRef);			
				break;
			case cS_IWGRP:
				err = BAPI_IntToObj(api_data, kS_IWGRP, &getPropertyRec->resultObjRef);			
				break;
			case cS_IXGRP:
				err = BAPI_IntToObj(api_data, kS_IXGRP, &getPropertyRec->resultObjRef);			
				break;
			case cS_IROTH:
				err = BAPI_IntToObj(api_data, kS_IROTH, &getPropertyRec->resultObjRef);			
				break;
			case cS_IWOTH:
				err = BAPI_IntToObj(api_data, kS_IWOTH, &getPropertyRec->resultObjRef);			
				break;
			case cS_IXOTH:
				err = BAPI_IntToObj(api_data, kS_IXOTH, &getPropertyRec->resultObjRef);			
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchConstant);
				break;
		}
	}
	else if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
	{	tLen = sizeof(FolderRec);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&folderRec, &tLen, 0, nil))
		{	switch(getPropertyRec->propertyID)
			{
				case kPath:
					CEquStr(tempStr, FILE_HD_PREFIX);
					CAddStr(tempStr, folderRec.path);
					// CAddChar(tempStr, '/');
					err = BAPI_StringToObj(api_data, tempStr, CLen(tempStr), &getPropertyRec->resultObjRef);
					break;
				case kName:
					tLen = CEquStr(tempStr, folderRec.path);
					tempStr[tLen-1] = 0;
					if (strP = strrchr(tempStr, '/'))
					{	if (strpLen = CLen(strP))
						{	strP++;
							strpLen--;
						}
						else
							CDebugStr("Illegal folder path (1)");
						err = BAPI_StringToObj(api_data, strP, strpLen, &getPropertyRec->resultObjRef);
					}
					else
						CDebugStr("Illegal folder path (1)");
					break;
				case kOpenMode:
					err = BAPI_IntToObj(api_data, folderRec.openMode, &getPropertyRec->resultObjRef);
					break;
				case kCreatTime:
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
							err = gsTimeRecToObjRef(api_data, &xFileInfo.creatDate, &getPropertyRec->resultObjRef);
					}
					break;
					
				case kModifTime:
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
							err = gsTimeRecToObjRef(api_data, &xFileInfo.modifDate, &getPropertyRec->resultObjRef);
					}
					break;
				case kUser:
				#ifdef __UNIX_XLIB__
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
							err = BAPI_StringToObj(api_data, (Ptr)&xFileInfo.user, CLen(xFileInfo.user), &getPropertyRec->resultObjRef);
					}
				#else
					err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
				#endif
					break;
				
				case kGroup:
				#ifdef __UNIX_XLIB__
					{	XFileInfo	xFileInfo;
						
						if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
							err = BAPI_StringToObj(api_data, (Ptr)&xFileInfo.group, CLen(xFileInfo.group), &getPropertyRec->resultObjRef);
					}
				#else
					err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
				#endif
					break;
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

//===========================================================================================
static XErr	Folder_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
XErr				err = noErr;
long				tLen, api_data = pbPtr->api_data;
FolderRec			folderRec;
#ifdef __UNIX_XLIB__
CStr255				aStr;
#endif

	tLen = sizeof(FolderRec);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &setPropertyRecP->objRef, (Ptr)&folderRec, &tLen, 0, nil))
	{	switch(setPropertyRecP->propertyID)
		{
			case kPath:
			case kName:
			case kOpenMode:
				err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
				break;
			case kCreatTime:
				{	XFileInfo	xFileInfo;

					if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
					{	if NOT(err = gsObjRefToTimeRec(api_data, &setPropertyRecP->value, &xFileInfo.creatDate))
							err = SetXFileInfo(folderRec.path, &xFileInfo);
					}
				}
				break;
			case kModifTime:
				{	XFileInfo	xFileInfo;

					if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
					{	if NOT(err = gsObjRefToTimeRec(api_data, &setPropertyRecP->value, &xFileInfo.modifDate))
							err = SetXFileInfo(folderRec.path, &xFileInfo);
					}
				}
				break;
			case kUser:
			#ifdef __UNIX_XLIB__
				if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aStr, nil, 63, kImplicitTypeCast))
				{	XFileInfo	xFileInfo;
					
					if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
					{	CEquStr(xFileInfo.user, aStr);
						err = SetXFileInfo(folderRec.path, &xFileInfo);
					}
				}
			#endif
				break;
			case kGroup:
			#ifdef __UNIX_XLIB__
				if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, aStr, nil, 63, kImplicitTypeCast))
				{	XFileInfo	xFileInfo;
					
					if NOT(err = GetXFileInfo(folderRec.path, &xFileInfo))	
					{	CEquStr(xFileInfo.group, aStr);
						err = SetXFileInfo(folderRec.path, &xFileInfo);
					}
				}
			#endif
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Folder_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
long			tLen, strLen;
char			*strP, *p;
FolderRec		folderRec;
char			aCStr[512];
PrimitiveUnion	*param_d;
CStr63			tStr;
Ptr				pathP;
long			pathLen;
BlockRef		ref;

	if (typeCast->resultWanted == kCString)
	{	tLen = sizeof(FolderRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&folderRec, &tLen, 0, nil))
		{	param_d = &typeCast->result;
			if (param_d->text.variant == kForConstructor)
			{	*aCStr = 0;
				strLen = 0;
				if (tLen)
				{	pathP = folderRec.path;
					pathLen = CLen(folderRec.path);
					if NOT(err = StringEscaped(&pathP, &pathLen, &ref))
					{	if (pathLen < 512)
							strLen = CAddStr(aCStr, pathP);
						if (ref)
							DisposeBlock(&ref);
					}
				}
				if NOT(err)
				{	if ((strLen + 1) < 512)
						strLen = CAddStr(aCStr, ",");
					_OpenModeStr(folderRec.openMode, tStr);
					if ((strLen + CLen(tStr)) < 512)
						strLen = CAddStr(aCStr, tStr);
				}
			}
			else
			{	if (tLen)
				{	strLen = CEquStr(aCStr, "file:/");
					if ((6 + strLen) < 512)
						strLen = CAddStr(aCStr, folderRec.path);
				}
				else
				{	strLen = 0;
					*aCStr = 0;
				}
			}
			if NOT(err)
			{	strP = aCStr;
				//strLen = CLen(strP);
				p = param_d->text.stringP;
				if (p)
				{	if (param_d->text.stringMaxStorage >= (strLen+1))
					{	CopyBlock(p, strP, strLen);
						p[strLen] = 0;
						param_d->text.stringLen = strLen;
					}
					else
					{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = strLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = strLen;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);

return err;
}

//===========================================================================================
/*static XErr	Folder_GetErrDescr(Biferno_ParamBlockPtr pbPtr)
{
GetErrDescrRec		*getErrDescrRecP = &pbPtr->param.getErrDescrRec;
short				tErr;

	CEquStr(getErrDescrRecP->errType, "Class folder Error");
	if (((tErr = getErrDescrRecP->err) >= START_ERR) && (tErr < lastErr))
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, gFolderErrorsStr[tErr - START_ERR]);
	}
	else
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, "Unknown Error");
	}

return noErr;
}

//===========================================================================================
static XErr	Folder_GetErrNumber(Biferno_ParamBlockPtr pbPtr)
{
GetErrNumber	*getErrNumberP = &pbPtr->param.getErrNumber;
char			*strP = getErrNumberP->errName;

	if NOT(CCompareStrings_cs(strP, "Err_ItemIsAlias"))
		getErrNumberP->errNumber = Err_ItemIsAlias;
	else if NOT(CCompareStrings_cs(strP, "Err_ItemIsNotFolder"))
		getErrNumberP->errNumber = Err_ItemIsNotFolder;
	else if NOT(CCompareStrings_cs(strP, "ErrBadOpenMode"))
		getErrNumberP->errNumber = ErrBadOpenMode;
	else if NOT(CCompareStrings_cs(strP, "Err_FolderExists"))
		getErrNumberP->errNumber = Err_FolderExists;
	else if NOT(CCompareStrings_cs(strP, "ErrFolderNotFound"))
		getErrNumberP->errNumber = ErrFolderNotFound;

return noErr;
}*/

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	folder_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			folderClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void folder(string path, int openMode)");
			break;
		case kInit:
			err = Folder_Init(pbPtr);
			break;
		case kShutDown:
			err = Folder_ShutDown(pbPtr);
			break;
		case kRun:
			//pbPtr->plugin_run_data = 0;
			break;
		case kExit:
			break;
		case kConstructor:
			err = Folder_Constructor(pbPtr, false);
			break;
		case kTypeCast:
		case kClone:
			err = Folder_Constructor(pbPtr, true);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = Folder_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = Folder_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Folder_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Folder_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = Folder_TypeCast(pbPtr);
			break;
		/*case kGetErrDescr:
			err = Folder_GetErrDescr(pbPtr);
			break;
		case kGetErrNumber:
			err = Folder_GetErrNumber(pbPtr);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


