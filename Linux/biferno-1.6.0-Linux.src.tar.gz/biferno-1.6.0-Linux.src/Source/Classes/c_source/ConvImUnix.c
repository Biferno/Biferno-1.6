#ifdef WITH_CONVERT_IMAGE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>

#define	HAVE_BOOLEAN	1

#include "XLib.h"

#include "ConvIm.h"
#include "GraphicsGems.h"

#include "tiffio.h"
#include "jpeglib.h"

/* M_PI was not in gems header ?? */
#ifndef M_PI
	#define M_PI	 3.14159265359
#endif

typedef	unsigned char	Pixel;
/* Note: if you define Pixel to something bigger than char, 
		you may need to add more support in bitmap file I/O functions.
*/

typedef struct
{
	int	xsize;		/* horizontal size of the image in Pixels */
	int	ysize;		/* vertical size of the image in Pixels */
	Pixel *	data;		/* pointer to first scanline of image */
	int	span;		/* byte offset between two scanlines */
} Image;

#define	WHITE_PIXEL	(255)
#define	BLACK_PIXEL	(0)

/*
 *	generic image access and i/o support routines
 */

static char *
next_token(f)
FILE *f;
{
	static char delim[] = " \t\r\n";
	static char *t = NULL;
	static char lnbuf[256];
	char *p;

	while(t == NULL) {			/* nothing in the buffer */
		if(fgets(lnbuf, sizeof(lnbuf), f)) {	/* read a line */
			if(p = strchr(lnbuf, '#')) {	/* clip any comment */
				*p = '\0';
			}
			t = strtok(lnbuf, delim);	/* get first token */
		} else {
			return(NULL);
		}
	}
	p = t;
	t = strtok((char *)NULL, delim);		/* get next token */
	return(p);
}



Pixel
get_pixel(image, x, y)
Image *image;
int x, y;
{
	static Image *im = NULL;
	static int yy = -1;
	static Pixel *p = NULL;

	if((x < 0) || (x >= image->xsize) || (y < 0) || (y >= image->ysize)) {
		return(0);
	}
	if((im != image) || (yy != y)) {
		im = image;
		yy = y;
		p = image->data + (y * image->span);
	}
	return(p[x]);
}

void
get_row(row, image, y)
Pixel *row;
Image *image;
int y;
{
	if((y < 0) || (y >= image->ysize)) {
		return;
	}
	memcpy(row,
		image->data + (y * image->span),
		(sizeof(Pixel) * image->xsize));
}

void
get_column(column, image, x)
Pixel *column;
Image *image;
int x;
{
	int i, d;
	Pixel *p;

	if((x < 0) || (x >= image->xsize)) {
		return;
	}
	d = image->span;
	for(i = image->ysize, p = image->data + x; i-- > 0; p += d) {
		*column++ = *p;
	}
}

Pixel
put_pixel(image, x, y, data)
Image *image;
int x, y;
Pixel data;
{
	static Image *im = NULL;
	static int yy = -1;
	static Pixel *p = NULL;

	if((x < 0) || (x >= image->xsize) || (y < 0) || (y >= image->ysize)) {
		return(0);
	}
	if((im != image) || (yy != y)) {
		im = image;
		yy = y;
		p = image->data + (y * image->span);
	}
	return(p[x] = data);
}

Image *
new_image(xsize, ysize)	/* create a blank image */
int xsize, ysize;
{
	Image *image;
	ASSERT(xsize > 0 && ysize > 0);

	if(image = (Image *)malloc(sizeof(Image)))
	{
		if(image->data = (Pixel *)calloc(ysize, xsize))
		{
			image->xsize = xsize;
			image->ysize = ysize;
			image->span = xsize;
		}
		else
		{
			free(image);
			image = NULL;
		}
	}
	return image;
}

void
free_image(image)
Image *image;
{
	ASSERT(image && image->data);
	free(image->data);
	free(image);
}


/*
	fileextension()

	Returns type of file based on its name.
	Returns the empty string if filename has no extension 
*/
char*
fileextension(f)
char* f;
{
	/* Get a filename's extension string. */
	int i;
	for(i = strlen(f) - 1; i > 0; i--)
	{
		if(f[i] == '.')
			return f + i + 1;
	}
	/* No extension. Return the end of the string, 
	   which effectively returns a null string. */
	return f + strlen(f);
}




/* add your filetype loaders and savers here */

/* -- tif/jpeg bitmap support------------------------------------------------ */

void	_RGBA2ImageData(int w, int h, uint32 *raster, Pixel *destP)
{
register char	*writeP;
register long	v, step, *readP;
int				i, j;
int				pixelsToSkip, newWidth, newHeight, oldWidth, oldHeight;
int				nPixels = w * h;
//long			r, g, b, a;

	readP = (long*)raster;
	writeP = (char*)destP;
	step = nPixels / 4;
	for (i = 0; i < step; i++)
		{
		v = *readP++;
		*writeP++ = v & 0x000000FF;
		v = *readP++;
		*writeP++ = v & 0x000000FF;
		v = *readP++;
		*writeP++ = v & 0x000000FF;
		v = *readP++;
		*writeP++ = v & 0x000000FF;
		}
	nPixels = nPixels - (step * 4);
	for (i = 0; i < nPixels; i++)
	{			
		v = *readP++;
		/*
		r = *readP++;
		g = *readP++;
		b = *readP++;
		*/
		*writeP++ = v & 0x000000FF;
	}
}

static void	write_JPEG_file(FILE *outfile, int quality, long image_width, long image_height, JSAMPLE *image_buffer, long components, long colorSpace)
{
struct		jpeg_compress_struct	cinfo;
struct		jpeg_error_mgr			jerr;
JSAMPROW 	row_pointer[1];      /* pointer to JSAMPLE row[s] */
int			row_stride;               /* physical row width in image buffer */

	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_compress(&cinfo);
	jpeg_stdio_dest(&cinfo, outfile);
	cinfo.image_width = image_width;      /* image width and height, in pixels */
	cinfo.image_height = image_height;
	cinfo.input_components = components;           /* # of color components per pixel */
	cinfo.in_color_space = colorSpace;       /* colorspace of input image */

	jpeg_set_defaults(&cinfo);
	jpeg_set_quality(&cinfo, quality, TRUE /* limit to baseline-JPEG values */);
	jpeg_start_compress(&cinfo, TRUE);
	row_stride = image_width * components;

	while (cinfo.next_scanline < cinfo.image_height)
	{
		row_pointer[0] = &image_buffer[cinfo.next_scanline * row_stride];
		(void) jpeg_write_scanlines(&cinfo, row_pointer, 1);
	}
	jpeg_finish_compress(&cinfo);	
	jpeg_destroy_compress(&cinfo);
}

//===========================================================================================
// legge sempre "test.tif"
Image *load_image_tif(char *path, FILE *f)		/* read image from bm file */
{
TIFF		*tif, *out;
uint32		w, h;
size_t		npixels;
uint32		*raster;
Image 		*image = NULL;
Pixel		*destP;

  	if (tif = TIFFOpen(path, "r"))
    {	TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &w);
		TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &h);
		npixels = w * h;
		raster = (uint32*)_TIFFmalloc(npixels * sizeof (uint32));
		if (raster != NULL)
		{	TIFFSetField(tif, TIFFTAG_ORIENTATION, ORIENTATION_BOTLEFT);   
			if (TIFFReadRGBAImage(tif, w, h, raster, 0))
			{	if (image = new_image(w, h))
				{	destP = image->data;
					_RGBA2ImageData(w, h, raster, destP);
				}
			}
			_TIFFfree(raster);
		}
		TIFFClose(tif);
	}
	
return(image);	
}

int
save_image_jpeg(f, image, jpegQuality)	/* write image to bm file */
FILE *f;
Image *image;
int	jpegQuality;
{

	//printf("Saving Image in jpeg format ..\n");
	write_JPEG_file(f, jpegQuality, image->xsize, image->ysize, image->data, 1, JCS_GRAYSCALE);
	//printf("Image saved\n");
	
return(0);		/* save successful */
	/*
	fprintf(f, "Bm # PXM 8-bit greyscale image\x0A");
	fprintf(f, "%d %d 8 # width height depth\x0A",
		image->xsize, image->ysize);
	if(fwrite(image->data, (size_t)image->xsize, (size_t)image->ysize, f) == (size_t)image->ysize) {
		return(0);
	} else {
		return(-1);
	}
	*/
}

/* -- PXM bitmap support------------------------------------------------ */

Image *
load_image_bm(path, f)		/* read image from bm file */
char *path;
FILE *f;
{
	char *p;
	int width, height;
	Image *image;

	if(((p = next_token(f)) && (strcmp(p, "Bm") == 0))
	&& ((p = next_token(f)) && ((width = atoi(p)) > 0))
	&& ((p = next_token(f)) && ((height = atoi(p)) > 0))
	&& ((p = next_token(f)) && (strcmp(p, "8") == 0))
	&& (image = new_image(width, height))
	&& (fread(image->data, (size_t)width, (size_t)height, f) == (size_t)height)) {
		return(image);		/* load successful */
	} else {
		return(NULL);		/* load failed */
	}
}

int
save_image_bm(f, image, jpegQuality)	/* write image to bm file */
FILE *f;
Image *image;
int	jpegQuality;
{
	fprintf(f, "Bm # PXM 8-bit greyscale image\x0A");
	fprintf(f, "%d %d 8 # width height depth\x0A",
		image->xsize, image->ysize);
	if(fwrite(image->data, (size_t)image->xsize, (size_t)image->ysize, f) == (size_t)image->ysize) {
		return(0);		/* save successful */
	} else {
		return(-1);		/* save failed */
	}
}


/* -- TGA bitmap support------------------------------------------------ */

typedef struct
{
	unsigned char	lsb, msb;
} DoubleByte;

#define INT_TO_DB(n, db)	{ (db).lsb = (unsigned char)((n) & 0xFF);\
							  (db).msb = (unsigned char)((n) >> 8); }

#define DB_TO_INT(db)		(((int)((db).msb) << 8) + (db).lsb)

typedef struct
{
	unsigned char	IDfieldLen;
	unsigned char	colorMapType;
	unsigned char	imageType;
	DoubleByte		ColorMapOrigin;
	DoubleByte		ColorMapLen;
	unsigned char	ColorMapEntrySize; /* no. of bits */
	DoubleByte		Xorigin;
	DoubleByte		Yorigin;
	DoubleByte		Width;
	DoubleByte		Height;
	unsigned char	bpp;
	unsigned char	descriptor;
} TGAheader;


int
save_image_tga(f, image, jpegQuality)	/* save image to TGA file */
FILE* f;
Image* image;
int	jpegQuality;
{
	int x, y;
	int n, j;
	TGAheader	header;
	boolean bOK = TRUE; /* assume success */

	/* Grayscale images only. */
	ASSERT(sizeof(Pixel) == 1);
		
	/* Write header */
	memset(&header, 0, sizeof(header));
	header.colorMapType = 1;
	header.imageType = 1;
	INT_TO_DB(256, header.ColorMapLen);
	header.ColorMapEntrySize = 24;
	INT_TO_DB(image->xsize, header.Width);
	INT_TO_DB(image->ysize, header.Height);
	header.bpp = 8;
	header.descriptor = 0x20; /* top down */

	bOK = (fwrite(&header, sizeof(header), 1, f) == 1);  

	/* Write palette. */
	for(n = 0; n < 256 && bOK; n++)
	{
		for(j = 0; j < 3 && bOK; j++)
			bOK = fputc(n, f) != EOF;
	}
		
	/* Write pixel index values. */
	for(y = 0; y < image->ysize && bOK; y++)
	{
		for(x = 0; x < image->xsize && bOK; x++)
			bOK = (EOF != fputc(get_pixel(image, x, y), f));
	}
	return bOK ? 0 : -1;
} /* save_image_tga */



Image *
load_image_tga(path, f)		/* read image from TGA file */
char *path;
FILE *f;
{
	Image* image = NULL;
	boolean bTopDown;
	boolean bOK = FALSE;
	TGAheader	header;
	int	width, height, c, x, y, yy;

	/* Grayscale images only. */
	ASSERT(sizeof(Pixel) == 1);

	if(fread(&header, sizeof(header), 1, f) == 1 && header.bpp == 8)
	{
		bTopDown = (header.descriptor & 0x20);
		width = DB_TO_INT(header.Width);
		height = DB_TO_INT(header.Height);

		image = new_image(width, height);
		if(image != NULL)
		{
			/* Skip palette */
			bOK = 0 == fseek(f, DB_TO_INT(header.ColorMapLen) * header.ColorMapEntrySize/8, SEEK_CUR);

			/* Read pixels */
			for(y = 0; y < height && bOK; y++)
			{
				yy = bTopDown ? y : (height-1) - y;

				for(x = 0; x < width && bOK; x++)
				{
					bOK = ((c = fgetc(f)) != EOF);
					if(bOK)
						put_pixel(image, x, yy, (Pixel)c);
				}
			}
		}
	}
	if(!bOK && image != NULL)
	{
		free_image(image);
		image = NULL;
	}

	return image;
}

/* -- End TGA bitmap support ------------------------------------------- */


/*
	ImageHandler stuff.
	An ImageHandler stores an image file's extension, 
	and pointers to functions that read and write the image format.
*/
typedef struct
{
	char* filetype;
	Image* (*reader)();
	int (*writer)();
} ImageHandler;

ImageHandler gImageHandlers[] =
{
	{ "bm", load_image_bm, save_image_bm },
	{ "tga", load_image_tga, save_image_tga },
	{ "TIF", load_image_tif, NULL },
	{ "TIFF", load_image_tif, NULL },
	{ "tif", load_image_tif, NULL },
	{ "tiff", load_image_tif, NULL },
	{ "jpg", NULL, save_image_jpeg },
	{ "jpeg", NULL, save_image_jpeg }
	/* add your image handlers here */
};


/*
	find_imagehandler()

	Given a filename, return an image handler for it. 
	Return NULL if no handler available.
*/
ImageHandler*
find_imagehandler(f)
char* f;
{
	int i;
	for(i = 0; i < sizeof(gImageHandlers) / sizeof(gImageHandlers[0]); i++)
	{
		// ex stricmp
		if(strcmp(gImageHandlers[i].filetype, fileextension(f)) == 0)
		{	//printf("image handler found! %s\n", gImageHandlers[i].filetype);
			return &gImageHandlers[i];
		}
	}
	return NULL;
}


/*
	load_image()

	Given a filename, hands off to appropriate image loader.
	Returns pointer to loaded Image, NULL if it can't.
*/
Image *
load_image(f)		/* read image from file */
char *f;
{
	Image 			*image;
	FILE* 			fp;
	ImageHandler* 	handler;
	XErr			err = noErr;

	ASSERT(f);	

	errno = noErr;
	fp = fopen(f, "rb");
	if(fp == NULL)
	{	err = errno;
		return NULL;
	}
	
	if(handler = find_imagehandler(f))
		image = handler->reader(f, fp);
	else
		image = NULL;

	fclose(fp);
	return image;
}


/*
	save_image()

	Given a filename and an Image, hands off to appropriate image saver.
	Returns -1 on error, 0 on success.
*/
int
save_image(f, image, jpegQuality)
char *f;
Image* image;
int	jpegQuality;
{
	FILE* fp;
	ImageHandler* handler;
	int nRet = -1; /* assume failure */

	ASSERT(f && image);
		
	fp = fopen(f, "wb");
	if(fp != NULL)
	{	
		//printf("Finding Writer ...\n");
		if(handler = find_imagehandler(f))
		{	//printf("Writer Found ...\n");
			nRet = handler->writer(fp, image, jpegQuality);
		}
		fclose(fp);
	}
	return nRet;
}




/*
 *	filter function definitions
 */

#define	filter_support		(1.0)

double
filter(t)
double t;
{
	/* f(t) = 2|t|^3 - 3|t|^2 + 1, -1 <= t <= 1 */
	if(t < 0.0) t = -t;
	if(t < 1.0) return((2.0 * t - 3.0) * t * t + 1.0);
	return(0.0);
}

#define	box_support		(0.5)

double
box_filter(t)
double t;
{
	if((t > -0.5) && (t <= 0.5)) return(1.0);
	return(0.0);
}

#define	triangle_support	(1.0)

double
triangle_filter(t)
double t;
{
	if(t < 0.0) t = -t;
	if(t < 1.0) return(1.0 - t);
	return(0.0);
}

#define	bell_support		(1.5)

double
bell_filter(t)		/* box (*) box (*) box */
double t;
{
	if(t < 0) t = -t;
	if(t < .5) return(.75 - (t * t));
	if(t < 1.5) {
		t = (t - 1.5);
		return(.5 * (t * t));
	}
	return(0.0);
}

#define	B_spline_support	(2.0)

double
B_spline_filter(t)	/* box (*) box (*) box (*) box */
double t;
{
	double tt;

	if(t < 0) t = -t;
	if(t < 1) {
		tt = t * t;
		return((.5 * tt * t) - tt + (2.0 / 3.0));
	} else if(t < 2) {
		t = 2 - t;
		return((1.0 / 6.0) * (t * t * t));
	}
	return(0.0);
}

double
sinc(x)
double x;
{
	x *= M_PI;
	if(x != 0) return(sin(x) / x);
	return(1.0);
}

#define	Lanczos3_support	(3.0)

double
Lanczos3_filter(t)
double t;
{
	if(t < 0) t = -t;
	if(t < 3.0) return(sinc(t) * sinc(t/3.0));
	return(0.0);
}

#define	Mitchell_support	(2.0)

#define	B	(1.0 / 3.0)
#define	C	(1.0 / 3.0)

double
Mitchell_filter(t)
double t;
{
	double tt;

	tt = t * t;
	if(t < 0) t = -t;
	if(t < 1.0) {
		t = (((12.0 - 9.0 * B - 6.0 * C) * (t * tt))
		   + ((-18.0 + 12.0 * B + 6.0 * C) * tt)
		   + (6.0 - 2 * B));
		return(t / 6.0);
	} else if(t < 2.0) {
		t = (((-1.0 * B - 6.0 * C) * (t * tt))
		   + ((6.0 * B + 30.0 * C) * tt)
		   + ((-12.0 * B - 48.0 * C) * t)
		   + (8.0 * B + 24 * C));
		return(t / 6.0);
	}
	return(0.0);
}

/*
 *	image rescaling routine
 */

typedef struct {
	int	pixel;
	double	weight;
} CONTRIB;

typedef struct {
	int	n;		/* number of contributors */
	CONTRIB	*p;		/* pointer to list of contributions */
} CLIST;

CLIST	*contrib;		/* array of contribution lists */


/*
	roundcloser()

	Round an FP value to its closest int representation.
	General routine; ideally belongs in general math lib file.
*/	
int roundcloser(double d)
{
	/* Untested potential one-liner, but smacks of call overhead */
	/* return fabs(ceil(d)-d) <= 0.5 ? ceil(d) : floor(d); */

	/* Untested potential optimized ceil() usage */
/*	double cd = ceil(d);
	int ncd = (int)cd;
	if(fabs(cd - d) > 0.5)
		ncd--;
	return ncd;
*/

	/* Version that uses no function calls at all. */
	int n = (int) d;
	double diff = d - (double)n;
	if(diff < 0)
		diff = -diff;
	if(diff >= 0.5)
	{
		if(d < 0)
			n--;
		else
			n++;
	}
	return n;
} /* roundcloser */


/* 
	calc_x_contrib()
	
	Calculates the filter weights for a single target column.
	contribX->p must be freed afterwards.

	Returns -1 if error, 0 otherwise.
*/
int calc_x_contrib(contribX, xscale, fwidth, dstwidth, srcwidth, filterf, i)
CLIST* contribX;			/* Receiver of contrib info */
double xscale;				/* Horizontal zooming scale */
double fwidth;				/* Filter sampling width */
int dstwidth;				/* Target bitmap width */
int srcwidth;				/* Source bitmap width */
double (*filterf)(double);	/* Filter proc */
int i;						/* Pixel column in source bitmap being processed */
{
	double width;
	double fscale;
	double center, left, right;
	double weight;
	int j, k, n;

	if(xscale < 1.0)
	{
		/* Shrinking image */
		width = fwidth / xscale;
		fscale = 1.0 / xscale;

		contribX->n = 0;
		contribX->p = (CONTRIB *)calloc((int) (width * 2 + 1),
				sizeof(CONTRIB));
		if(contribX->p == NULL)
			return -1;

		center = (double) i / xscale;
		left = ceil(center - width);
		right = floor(center + width);
		for(j = (int)left; j <= right; ++j)
		{
			weight = center - (double) j;
			weight = (*filterf)(weight / fscale) / fscale;
			if(j < 0)
				n = -j;
			else if(j >= srcwidth)
				n = (srcwidth - j) + srcwidth - 1;
			else
				n = j;
			
			k = contribX->n++;
			contribX->p[k].pixel = n;
			contribX->p[k].weight = weight;
		}
	
	}
	else
	{
		/* Expanding image */
		contribX->n = 0;
		contribX->p = (CONTRIB *)calloc((int) (fwidth * 2 + 1),
				sizeof(CONTRIB));
		if(contribX->p == NULL)
			return -1;
		center = (double) i / xscale;
		left = ceil(center - fwidth);
		right = floor(center + fwidth);

		for(j = (int)left; j <= right; ++j)
		{
			weight = center - (double) j;
			weight = (*filterf)(weight);
			if(j < 0) {
				n = -j;
			} else if(j >= srcwidth) {
				n = (srcwidth - j) + srcwidth - 1;
			} else {
				n = j;
			}
			k = contribX->n++;
			contribX->p[k].pixel = n;
			contribX->p[k].weight = weight;
		}
	}
	return 0;
} /* calc_x_contrib */


/*
	zoom()

	Resizes bitmaps while resampling them.
	Returns -1 if error, 0 if success.
*/
int
zoom(dst, src, filterf, fwidth)
Image* dst;
Image* src;
double (*filterf)(double);
double fwidth;
{
	Pixel* tmp;
	double xscale, yscale;		/* zoom scale factors */
	int xx;
	int i, j, k;			/* loop variables */
	int n;				/* pixel number */
	double center, left, right;	/* filter calculation variables */
	double width, fscale, weight;	/* filter calculation variables */
	Pixel pel, pel2;
	int bPelDelta;
	CLIST	*contribY;		/* array of contribution lists */
	CLIST	contribX;
	int		nRet = -1;

	/* create intermediate column to hold horizontal dst column zoom */
	tmp = (Pixel*)malloc(src->ysize * sizeof(Pixel));
	if(tmp == NULL)
		return 0;

	xscale = (double) dst->xsize / (double) src->xsize;

	/* Build y weights */
	/* pre-calculate filter contributions for a column */
	contribY = (CLIST *)calloc(dst->ysize, sizeof(CLIST));
	if(contribY == NULL)
	{
		free(tmp);
		return -1;
	}

	yscale = (double) dst->ysize / (double) src->ysize;

	if(yscale < 1.0)
	{
		width = fwidth / yscale;
		fscale = 1.0 / yscale;
		for(i = 0; i < dst->ysize; ++i)
		{
			contribY[i].n = 0;
			contribY[i].p = (CONTRIB *)calloc((int) (width * 2 + 1),
					sizeof(CONTRIB));
			if(contribY[i].p == NULL)
			{
				free(tmp);
				free(contribY);
				return -1;
			}
			center = (double) i / yscale;
			left = ceil(center - width);
			right = floor(center + width);
			for(j = (int)left; j <= right; ++j) {
				weight = center - (double) j;
				weight = (*filterf)(weight / fscale) / fscale;
				if(j < 0) {
					n = -j;
				} else if(j >= src->ysize) {
					n = (src->ysize - j) + src->ysize - 1;
				} else {
					n = j;
				}
				k = contribY[i].n++;
				contribY[i].p[k].pixel = n;
				contribY[i].p[k].weight = weight;
			}
		}
	} else {
		for(i = 0; i < dst->ysize; ++i) {
			contribY[i].n = 0;
			contribY[i].p = (CONTRIB *)calloc((int) (fwidth * 2 + 1),
					sizeof(CONTRIB));
			if(contribY[i].p == NULL)
			{
				free(tmp);
				free(contribY);
				return -1;
			}
			center = (double) i / yscale;
			left = ceil(center - fwidth);
			right = floor(center + fwidth);
			for(j = (int)left; j <= right; ++j) {
				weight = center - (double) j;
				weight = (*filterf)(weight);
				if(j < 0) {
					n = -j;
				} else if(j >= src->ysize) {
					n = (src->ysize - j) + src->ysize - 1;
				} else {
					n = j;
				}
				k = contribY[i].n++;
				contribY[i].p[k].pixel = n;
				contribY[i].p[k].weight = weight;
			}
		}
	}


	for(xx = 0; xx < dst->xsize; xx++)
	{
		if(0 != calc_x_contrib(&contribX, xscale, fwidth, 
								dst->xsize, src->xsize, filterf, xx))
		{
			goto __zoom_cleanup;
		}
		/* Apply horz filter to make dst column in tmp. */
		for(k = 0; k < src->ysize; ++k)
		{
			weight = 0.0;
			bPelDelta = FALSE;
			pel = get_pixel(src, contribX.p[0].pixel, k);
			for(j = 0; j < contribX.n; ++j)
			{
				pel2 = get_pixel(src, contribX.p[j].pixel, k);
				if(pel2 != pel)
					bPelDelta = TRUE;
				weight += pel2 * contribX.p[j].weight;
			}
			weight = bPelDelta ? roundcloser(weight) : pel;

			tmp[k] = (Pixel)CLAMP(weight, BLACK_PIXEL, WHITE_PIXEL);
		} /* next row in temp column */

		free(contribX.p);

		/* The temp column has been built. Now stretch it 
		 vertically into dst column. */
		for(i = 0; i < dst->ysize; ++i)
		{
			weight = 0.0;
			bPelDelta = FALSE;
			pel = tmp[contribY[i].p[0].pixel];

			for(j = 0; j < contribY[i].n; ++j)
			{
				pel2 = tmp[contribY[i].p[j].pixel];
				if(pel2 != pel)
					bPelDelta = TRUE;
				weight += pel2 * contribY[i].p[j].weight;
			}
			weight = bPelDelta ? roundcloser(weight) : pel;
			put_pixel(dst, xx, i,
				(Pixel)CLAMP(weight, BLACK_PIXEL, WHITE_PIXEL));
		} /* next dst row */
	} /* next dst column */
	nRet = 0; /* success */

__zoom_cleanup:
	free(tmp);

	/* free the memory allocated for vertical filter weights */
	for(i = 0; i < dst->ysize; ++i)
		free(contribY[i].p);
	free(contribY);

	return nRet;
} /* zoom */

#pragma mark-
//===========================================================================================
XErr		BifernoConvertImage(char *srcfile, char *dstfile, int jpegQuality, double scale, int width, int height, char *errMessage)
{
double		(*f)() = filter;
double		s = filter_support;
Image 		*dst, *src;
XErr		err = noErr;

	if (errMessage)
		*errMessage = 0;
	if (src = load_image(srcfile))
	{	if NOT(err = GetRescaledDims(src->xsize, src->ysize, scale, &width, &height, errMessage))
		{	if (dst = new_image(width, height))
			{	if NOT(zoom(dst, src, f, s))
				{	int		saveRes;
				
					XThreadsEnterCriticalSection();
					saveRes = save_image(dstfile, dst, jpegQuality);
					XThreadsLeaveCriticalSection();
					if (saveRes)
					{	err = 1;
						CEquStr(errMessage, "BifernoConvertImage: can't save destination image file");
					}
				}
				else
				{	err = 1;
					CEquStr(errMessage, "BifernoConvertImage: error zooming image");
				}
				free_image(dst);
			}
			else
			{	err = 1;
				CEquStr(errMessage, "BifernoConvertImage: can't allocate dest image");
			}
		}
		free_image(src);
	}
	else
	{	err = 1;
		CEquStr(errMessage, "BifernoConvertImage: can't load source image file");
	}

return err;
}

#endif
