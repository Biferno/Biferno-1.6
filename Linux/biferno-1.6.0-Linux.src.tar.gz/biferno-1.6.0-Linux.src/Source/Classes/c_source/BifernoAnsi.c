/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoAnsi.c,v 1.5 2003-06-26 17:02:38 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"

XErr	BifernoAnsi_Biferno_Dispatch(long message, Biferno_ParamBlockPtr pbPtr);

enum{
		kstrstr = 1,
		kstrch,
		kstrcmp,
		kstrcspn,
		kstrncat,
		kstrncmp,
		kstrncpy,
		kstrpbrk,
		kstrrch,
		kstrspn,
		kRandom,
		kSRandom
	};
#define TOT_FUNCTIONS	12

static long	BifernoAnsiClassID;
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//===========================================================================================
static XErr	_BifernoAnsi_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec			*initRecP = &pbPtr->param.initRec.newClassRec;
XErr				err = noErr;
BAPI_MemberRecord	ansiFuncs[TOT_FUNCTIONS] = 

{	"strstr", 		kstrstr, 	"static string strstr(string str1, string str2)",
	"strch", 		kstrch, 	"static string strch(string str, char ch)",
	"strcmp", 		kstrcmp, 	"static int strcmp(string str1, string str2)",
	"strcspn", 		kstrcspn, 	"static int strcspn(string str1, string str2)",
	"strncat", 		kstrncat, 	"static string strncat(string str1, string str2, int n)",
	"strncmp", 		kstrncmp, 	"static int strncmp(string str1, string str2, int n)",
	"strncpy", 		kstrncpy, 	"static string strncpy(string str, int n)",
	"strpbrk", 		kstrpbrk, 	"static string strpbrk(string str1, string str2)",
	"strrch", 		kstrrch, 	"static string strrch(string str, char ch)",
	"strspn", 		kstrspn, 	"static int strspn(string str1, char ch)",
	"random",		kRandom,	"static int random(void)",
	"srandom",		kSRandom,	"static void srandom(int seed)"
};
	
	if (err = BAPI_NewMethods(pbPtr->api_data, BifernoAnsiClassID, ansiFuncs, TOT_FUNCTIONS, nil))
		return err;

return err;
}

			
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*
Looks for string s2 in string s1, returns a string containing the part of s1 beginning with the found string until end
if s2 is in s1 (else returns an empty string)
*/
static XErr	_strstr(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr1, aCStr2;
char		*resStrP, *string1P, *string2P;
BlockRef	ref1, ref2;
long		string1Len, string2Len;
XErr		err = noErr;

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	resStrP = strstr(string1P, string2P);
				if (resStrP)
					err = BAPI_StringToObj(api_data, resStrP, CLen(string1P) - (resStrP - string1P), &exeMethodRecP->resultObjRef);
				else
					err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
				BAPI_ReleaseBlock(&ref2);
			}
			BAPI_ReleaseBlock(&ref1);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	

//===========================================================================================
/*
Locates the first occurrence of char ch in string s:
returns a copy of string s starting from the
first occurrence until end or an empty string if ch is not found
*/
static XErr	_strch(Biferno_ParamBlockPtr pbPtr, long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr;
char		*resStrP, *stringP;
BlockRef	ref;
long		stringLen;
XErr		err = noErr;
Byte		chStr[2];

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
		{	err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, (Ptr)chStr, nil, 2, kImplicitTypeCast);
			if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
			{	CEquStr(pbPtr->error, "The second parameter must be 1 character in length");
				err = XError(kBAPI_Error, Err_StringTooLong);
			}
			if NOT(err)
			{	resStrP = strchr(stringP, *chStr);
				if (resStrP)
					err = BAPI_StringToObj(api_data, resStrP, CLen(stringP) - (resStrP - stringP), &exeMethodRecP->resultObjRef);
				else
					err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
			}
			BAPI_ReleaseBlock(&ref);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	

//===========================================================================================
/*
Compares the string s1 with string s2:
return a positive integer if s1 > s2, 0 if s1 == s2, a negative integer if s1 < s2
*/
static XErr	_strcmp(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr1, aCStr2;
char		*string1P, *string2P;
BlockRef	ref1, ref2;
long		string1Len, string2Len;
XErr		err = noErr;
int			res;

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	res = strcmp(string1P, string2P);
				err = BAPI_IntToObj(api_data, res, &exeMethodRecP->resultObjRef);
				BAPI_ReleaseBlock(&ref2);
			}
			BAPI_ReleaseBlock(&ref1);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	

//===========================================================================================
/*
Computes the length of the maximum initial segment of the string s1 that consist entirely of
characters that are not from string s2
*/
static XErr	_strcspn(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr1, aCStr2;
char		*string1P, *string2P;
BlockRef	ref1, ref2;
long		string1Len, string2Len;
XErr		err = noErr;
int			size;

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	size = strcspn(string1P, string2P);
				err = BAPI_IntToObj(api_data, size, &exeMethodRecP->resultObjRef);
				BAPI_ReleaseBlock(&ref2);
			}
			BAPI_ReleaseBlock(&ref1);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	

//===========================================================================================
/*
Returns a new string appending string s2 to string s1 until it has appended n characters or it
has reached the end of string s2
*/
static XErr	_strncat(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr, aCStr1, aCStr2;
char		*resStrP, *string1P, *string2P;
BlockRef	ref1, ref2;
long		n, string1Len, string2Len;
XErr		err = noErr;
BlockRef	ref;

	if (totParams == 3)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &n, kImplicitTypeCast))
				{	if (resStrP = AllocString(string1Len + string2Len + 1, aCStr, &ref, &err))
					{	CopyBlock(resStrP, string1P, string1Len+1);
						resStrP = strncat(resStrP, string2P, n);
						err = BAPI_StringToObj(api_data, resStrP, CLen(resStrP), &exeMethodRecP->resultObjRef);
						DisposeString(&ref);
					}
					/*if (bl = NewBlock(string1Len + string2Len + 1, &err))
					{	LockBlock(bl);
						resStrP = GetPtr(bl);
						CopyBlock(resStrP, string1P, string1Len+1);
						resStrP = strncat(resStrP, string2P, n);
						err = BAPI_StringToObj(api_data, resStrP, CLen(resStrP), &exeMethodRecP->resultObjRef);
						DisposeBlock(&bl);
					}*/
				}
				BAPI_ReleaseBlock(&ref2);
			}
			BAPI_ReleaseBlock(&ref1);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	

//===========================================================================================
/*
Compares the string s1 with the string s2 up to a limit of n characters:
return a positive integer if s1 > s2, 0 if s1 == s2, a negative integer if s1 < s2
*/
static XErr	_strncmp(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr1, aCStr2;
char		*string1P, *string2P;
BlockRef	ref1, ref2;
long		n, string1Len, string2Len;
XErr		err = noErr;
int			res;

	if (totParams == 3)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &n, kImplicitTypeCast))
				{	res = strncmp(string1P, string2P, n);
					err = BAPI_IntToObj(api_data, res, &exeMethodRecP->resultObjRef);
				}
				BAPI_ReleaseBlock(&ref2);
			}
			BAPI_ReleaseBlock(&ref1);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
/*
Returns a new string copying characters from string s until either it has copied n characters or it
reaches the end of string s
*/
static XErr	_strncpy(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr, aCStr2;
char		*stringP, *resStrP;
BlockRef	ref;
long		n, stringLen;
XErr		err = noErr;
BlockRef	ref2;

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &n, kImplicitTypeCast))
			{	if (resStrP = AllocString(stringLen + 1, aCStr2, &ref2, &err))
				{	strncpy(resStrP, stringP, n);
					if (n > stringLen)
						n = stringLen;
					resStrP[n] = 0;
					err = BAPI_StringToObj(api_data, resStrP, CLen(resStrP), &exeMethodRecP->resultObjRef);
					DisposeString(&ref2);
				}
				/*if (bl = NewBlock(stringLen + 1, &err))
				{	LockBlock(bl);
					resStrP = GetPtr(bl);
					strncpy(resStrP, stringP, n);
					err = BAPI_StringToObj(api_data, resStrP, CLen(resStrP), &exeMethodRecP->resultObjRef);
					DisposeBlock(&bl);
				}*/
			}
			BAPI_ReleaseBlock(&ref);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
/*
Locates the first occurrence of any characters from string s2 in s1:
returns a copy of string s starting from the
first occurrence until end or an empty string if no characters are found
*/
static XErr	_strpbrk(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr1, aCStr2;
char		*string1P, *string2P, *resStrP;
BlockRef	ref1, ref2;
long		string1Len, string2Len;
XErr		err = noErr;

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	resStrP = strpbrk(string1P, string2P);
				if (resStrP)
					err = BAPI_StringToObj(api_data, resStrP, CLen(string1P) - (resStrP - string1P), &exeMethodRecP->resultObjRef);
				else
					err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
				BAPI_ReleaseBlock(&ref2);
			}
			BAPI_ReleaseBlock(&ref1);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	

//===========================================================================================
/*
Locates the last occurrence of char ch in string s:
returns a copy of string s starting from the
first occurrence until end or an empty string if ch is not found
*/
static XErr	_strrch(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr;
char		*resStrP, *stringP;
BlockRef	ref;
long		stringLen;
XErr		err = noErr;
Byte		chStr[2];

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, (Ptr)chStr, nil, 2, kImplicitTypeCast))
			{	resStrP = strrchr(stringP, *chStr);
				if (resStrP)
					err = BAPI_StringToObj(api_data, resStrP, CLen(stringP) - (resStrP - stringP), &exeMethodRecP->resultObjRef);
				else
					err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
			}
			BAPI_ReleaseBlock(&ref);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	

//===========================================================================================
/*
Computes the length of the maximum initial segment of the string s1 that consists entirely 
of characters from the string s2:
returns the lentgh of the segment
*/
static XErr	_strspn(long api_data, ExecuteMethodRec *exeMethodRecP, long totParams)
{
CStr255		aCStr1, aCStr2;
char		*string1P, *string2P;
BlockRef	ref1, ref2;
long		string1Len, string2Len;
XErr		err = noErr;
int			res;

	if (totParams == 2)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr1, &string1P, &string1Len, &ref1, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr2, &string2P, &string2Len, &ref2, kImplicitTypeCast))
			{	res = strspn(string1P, string2P);
				err = BAPI_IntToObj(api_data, res, &exeMethodRecP->resultObjRef);
				BAPI_ReleaseBlock(&ref2);
			}
			BAPI_ReleaseBlock(&ref1);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}	


#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_BifernoAnsiExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				api_data = pbPtr->api_data, totParams = exeMethodRecP->totParams;

	switch (exeMethodRecP->methodID)
	{	
		case  kstrstr:
			err = _strstr(api_data, exeMethodRecP, totParams);
			break;
		case  kstrch:
			err = _strch(pbPtr, api_data, exeMethodRecP, totParams);
			break;
		case  kstrcmp:
			err = _strcmp(api_data, exeMethodRecP, totParams);
			break;
		case  kstrcspn:
			err = _strcspn(api_data, exeMethodRecP, totParams);
			break;
		case  kstrncat:
			err = _strncat(api_data, exeMethodRecP, totParams);
			break;
		case  kstrncmp:
			err = _strncmp(api_data, exeMethodRecP, totParams);
			break;
		case  kstrncpy:
			err = _strncpy(api_data, exeMethodRecP, totParams);
			break;
		case  kstrpbrk:
			err = _strpbrk(api_data, exeMethodRecP, totParams);
			break;
		case  kstrrch:
			err = _strrch(api_data, exeMethodRecP, totParams);
			break;
		case  kstrspn:
			err = _strspn(api_data, exeMethodRecP, totParams);
			break;
		case kRandom:
			err = BAPI_IntToObj(api_data, rand(), &exeMethodRecP->resultObjRef);
			break;
		case kSRandom:
			if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &totParams, kImplicitTypeCast))
				srand(totParams);
			break;

		
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	BifernoAnsi_Biferno_Dispatch(long message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "ansi");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(ANSI String Functions)");
			BifernoAnsiClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			// not interested in api_version
			break;
		case kInit:
			err = _BifernoAnsi_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = _BifernoAnsiExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		/*case kGetErrDescr:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


