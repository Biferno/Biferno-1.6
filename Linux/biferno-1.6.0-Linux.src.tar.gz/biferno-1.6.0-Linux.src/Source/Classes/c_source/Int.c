/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Int.c,v 1.7 2004-05-04 13:21:51 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BifernoEngineAPI.h"
#include 	"StaticClasses.h"

static long		intClassID;
static long		gsApiVersion;

#define	gsPlugName		"int"

//===========================================================================================
static Boolean _Do_Int_LongOperation(long operation, LONGLONG item1, LONGLONG item2, LONGLONG *resultP)
{
LONGLONG	res = 0;

	switch(operation)
	{	case EVAL_MULT:
			if (LongLongMul(&item1, item2))
				res = item1;
			else
				return true;
			break;
		/*case EVAL_DIV:
			if (item2 && __llmul(&item1, 1/item2))
				res = item1 / item2;
			else
				return true;
			break;*/
		case EVAL_ADD:
			if (LongLongAdd(&item1, item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_MINUS:
			if (LongLongAdd(&item1, -item2))
				res = item1;
			else
				return true;
			break;
		default:
			CDebugStr("Unknown operator!");
	}

*resultP = res;
return false;
}

//===========================================================================================
// return true if overflow
static Boolean _DoIntOperation(long operation, long item1, long item2, Boolean *isBoolP, Boolean *boolResP, long *resultP, XErr *errP)
{
long		res = 0;
Boolean		boolres = false;
long		aLong;

	*isBoolP = false;
	switch(operation)
	{	case EVAL_MULT:
			if (LongMul(&item1, item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_DIV:
			if (item2)
				res = item1 / item2;
			else
				*errP = XError(kBAPI_Error, Err_Overflow);
			break;
		case EVAL_MOD:
			aLong = item2;
			res = item1 % aLong;
			break;
		case EVAL_ADD:
			if (LongAdd(&item1, item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_MINUS:
			if (LongAdd(&item1, -item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_SHIFTR:
			aLong = item2;
			res = item1 >> aLong;
			break;
		case EVAL_SHIFTL:
			aLong = item2;
			res = item1 << aLong;
			break;
		case EVAL_GTH:
			boolres = item1 > item2;
			*isBoolP = true;
			break;
		case EVAL_LTH:
			boolres = item1 < item2;
			*isBoolP = true;
			break;
		case EVAL_GEQ:
			boolres = item1 >= item2;
			*isBoolP = true;
			break;
		case EVAL_LEQ:
			boolres = item1 <= item2;
			*isBoolP = true;
			break;
		case EVAL_EQUA:
			boolres = item1 == item2;
			*isBoolP = true;
			break;
		case EVAL_NEQUA:
			boolres = item1 != item2;
			*isBoolP = true;
			break;
		case EVAL_ARAND:
			aLong = item2;
			res = item1 & aLong;
			break;
		case EVAL_AROR:
			aLong = item2;
			res = item1 | aLong;
			break;
		default:
			CDebugStr("Unknown operator!");
	}

*boolResP = boolres;
*resultP = res;
return false;
}

#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
// Ci si deve registrare dando il nome della classe (costruttore), dicendo di 
// che tipo � il plugin e ricevendo la propria classID
/*static XErr	Int_Init(Biferno_ParamBlockPtr pbPtr)
{
NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;

	initRecP->wantDestructor = false;
	initRecP->fixedSize = true;
	CEquStr(initRecP->constructor, "void int(obj num)");
	
return err;
}*/

//===========================================================================================
// Finalizzazioni
static XErr	Int_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	intClassID = 0;
	
return noErr;
}

//===========================================================================================
// Data una sequenza di caratteri (constructorRecP->data), o una sequenza di obj (varRecsP) 
// si deve creare un oggetto di tipo inta usando la callback "BAPI_BufferToObj"
static XErr	Int_Constructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			aLong;
long			api_data = pbPtr->api_data;
//BlockRef		dataBlock = 0;

	/*if (constructorRecP->dataP)
	{	if (constructorRecP->isString == INTERNAL)
		{	aLong = *(long*)constructorRecP->dataP;
			err = BAPI_BufferToObj(api_data, &aLong, sizeof(long), intClassID, true, nil, constructorRecP->scope, constructorRecP->type, &constructorRecP->resultObjRef);
		}
		else
		{	if (constructorRecP->dataLen < 255)
			{	CopyBlock(&aStr[1], constructorRecP->dataP, constructorRecP->dataLen);
				aStr[0] = constructorRecP->dataLen;
				if (PStringToNumExt(aStr, &aLong, nil) == -1)
					err = XError(kBAPI_Error, Err_Overflow);
				else
					err = BAPI_BufferToObj(api_data, &aLong, sizeof(long), intClassID, true, nil, constructorRecP->scope, constructorRecP->type, &constructorRecP->resultObjRef);
			}
			else
				err = Err_BadConstructorArgument;
		}
	}
	else */
	
	if (constructorRecP->totVars == 1)
	{	if (OBJ_CLASSID(constructorRecP->varRecsP[0].objRef) == intClassID)
			err = BAPI_CopyObj(api_data, &constructorRecP->varRecsP[0].objRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
		else
		{	if NOT(err = BAPI_ObjToInt(api_data, &constructorRecP->varRecsP->objRef, &aLong, kImplicitTypeCast))
				err = BAPI_BufferToObj(api_data, &aLong, sizeof(long), intClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "int(obj param)");
	}

	if NOT(err)
		OBJ_CLASSID(constructorRecP->resultObjRef) = intClassID;
		
return err;
}

//#define		INT_MIN_VALUE		0x80000000
//#define		INT_MAX_VALUE		0x7FFFFFFF

//===========================================================================================
// Il risultato va messo in objRef1
static XErr	Int_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err= noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				operation = exeOperationRecP->operation;
Boolean				boolres, isBool;
long				api_data = pbPtr->api_data;
long				item1;
long				res;
long				item2;

#ifdef MEM_DEBUG
	if (err = BAPI_NeedSerialize(pbPtr->api_data, &exeOperationRecP->objRef1, nil))
		return err;
	if (err = BAPI_NeedSerialize(pbPtr->api_data, &exeOperationRecP->objRef2, nil))
		return err;
#endif
	if NOT(err = BAPI_ObjToInt(api_data, &exeOperationRecP->objRef1, &item1, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeOperationRecP->objRef2, &item2, kImplicitTypeCast))
		{	if (_DoIntOperation(operation, item1, item2, &isBool, &boolres, &res, &err))
			{	LONGLONG item1_l, item2_l, res_l;
			
				if NOT(err = BAPI_ObjToLong(api_data, &exeOperationRecP->objRef1, &item1_l, kImplicitTypeCast))
				{	if NOT(err = BAPI_ObjToLong(api_data, &exeOperationRecP->objRef2, &item2_l, kImplicitTypeCast))
					{	if (_Do_Int_LongOperation(operation, item1_l, item2_l, &res_l))	// overflow
							err = XError(kBAPI_Error, Err_Overflow);
						else
							err = BAPI_LongToObj(api_data, res_l, &exeOperationRecP->resultObjRef);
					}
				}
			}
			else if NOT(err)
			{	if (isBool)
					err = BAPI_BooleanToObj(api_data, boolres, &exeOperationRecP->resultObjRef);
				else
					err = BAPI_IntToObj(api_data, res, &exeOperationRecP->resultObjRef);
			}
		}
	}

		
return err;
}

//===========================================================================================
/*static XErr	Int_Increment(Biferno_ParamBlockPtr pbPtr)
{
IncrementRec	*incrP = &pbPtr->param.incrementRec;
XErr			err = noErr;

	err = DLM_IncrementLong(OBJ_LIST(incrP->objRef), OBJ_ID(incrP->objRef), incrP->decrement);
	
return noErr;
}*/

//===========================================================================================
static XErr	Int_Opposite(Biferno_ParamBlockPtr pbPtr)
{
OppositeRec		*oppP = &pbPtr->param.oppositeRec;
XErr			err = noErr;
long			tLen, aLong;

#ifdef MEM_DEBUG
	if (err = BAPI_NeedSerialize(pbPtr->api_data, &oppP->objRef, nil))
		return err;
#endif
	tLen = sizeof(long);
	//if NOT(err = DLM_GetObj(OBJ_LIST(oppP->objRef), OBJ_ID(oppP->objRef), (Ptr)&aLong, &tLen, 0, nil))
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &oppP->objRef, (Ptr)&aLong, &tLen, 0, nil))
		err = BAPI_IntToObj(pbPtr->api_data, -aLong, &oppP->resultObjRef);	

return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	Int_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;


#ifdef MEM_DEBUG
	if (BAPI_IsObjRefValid(pbPtr->api_data, &exeMethodRecP->objRef))
	{	if (err = BAPI_NeedSerialize(pbPtr->api_data, &exeMethodRecP->objRef, nil))
			return err;
	}
#endif
/*
Ricorda, se � void devi mettere:

	exeMethodRecP->resultObjRef.id = -1;

*/


/*	ObjRef	objRef;			// in
	long		methodID;		// in
	ObjRef 	*paramVarsP;	// in
	long		totParams;		// in
	ObjRef	resultObjRef;	// out
*/
	//BAPI_InvalObjRef(pbPtr->api_data, &exeMethodRecP->resultObjRef);
	//exeMethodRecP->resultObjRef.id = -1;	// for void
	switch(exeMethodRecP->methodID)
	{
		/*case kEncode:
			break;
		case kDecode:
			break;
		case kToNum:
			break;
		case kIsEMail:
			break;
		case kGetSub:
			break;
		case kToArray:
			break;
		case kUpToLower:
			break;
		case kLowToUpper:
			break;
		case kHiliteWord:
			break;
		case kLeadingZeros:
			break;
		*/
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}

return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	Int_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	Int_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr				err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchProperty);
	
return err;
}

//===========================================================================================
/*static XErr	Int_Modify(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ModifyRec	*modifyRecP = &pbPtr->param.modifyRec;
long		aLong;
long		api_data = pbPtr->api_data;

	if NOT(err = BAPI_ObjToInt(api_data, &modifyRecP->value, &aLong, kImplicitTypeCast))
		err = BAPI_ModifyObj(api_data, &modifyRecP->varToModify, &aLong, sizeof(long), intClassID);
	
return err;
}*/

//===========================================================================================
static XErr	Int_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
long			aLong;
CStr255			aCStr;
long			cLen;
Ptr				p;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
PrimitiveUnion	*param_d;
long			tLen, api_data = pbPtr->api_data;
//ParameterRec	parameter;

#ifdef MEM_DEBUG
	if (err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, nil))
		return err;
#endif

	/*switch(typeCast->resultWanted)
	{	case kInt:
			aLong = param_s->u.intValue;
			break;
		case kLong:
			aLong = param_s->u.longValue;
			break;
		case kUnsigned:
			aLong = param_s->u.uIntValue;
			break;
		case kDouble:
			aLong = param_s->u.doubleValue;
			break;
		case kBool:
			aLong = param_s->u.boolValue;
			break;
		case kCString:
		#ifdef NUM_STRING_TYPECAST_EXPLICIT	
			if (typeCast->type != kExplicitTypeCast)
				return XError(kBAPI_Error, Err_IllegalTypeCast);
		#endif
			cLen = param_s->u.text.stringLen;
			if (cLen < 255)
			{	CopyBlock(aCStr, param_s->u.text.stringP, cLen);
				aCStr[cLen] = 0;
				if (CStringToNumExt(aCStr, &aLong, nil) == -1)
					err = XError(kBAPI_Error, Err_Overflow);
			}
			else
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
			break;
		case kObj:
			if (param_s->u.objRef.classID == intClassID)
			{	long tLen = sizeof(long);
				err = BAPI_GetObj(api_data, &param_s->u.objRef, (Ptr)&aLong, &tLen, 0, nil);
			}
			else
				err = BAPI_ObjToInt(api_data, &param_s->u.objRef, &aLong, typeCast->type);
			break;
	}*/
	tLen = sizeof(long);
	if NOT(err = BAPI_GetObj(api_data, &typeCast->objRef, (Ptr)&aLong, &tLen, 0, nil))
	{	if NOT(tLen)
			aLong = 0;
		param_d = &typeCast->result;
		switch(typeCast->resultWanted)
		{	case kInt:
				param_d->intValue = aLong;
				break;
			case kLong:
				param_d->longValue = aLong;
				break;
			case kUnsigned:
				// if ((aLong > 0) && (aLong < 2147483648))
				// 
				param_d->uIntValue = (unsigned long)aLong;// ? -aLong : (aLong > 0);
				// param_d->uIntValue = aLong + 0x7FFFFFFF;
				break;
			case kDouble:
				param_d->doubleValue = aLong;
				break;
			case kBool:
				param_d->boolValue = (aLong != 0);
				break;
			case kCString:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				CNumToString(aLong, aCStr);
				cLen = CLen(aCStr);
				if (p = param_d->text.stringP)
				{	if (param_d->text.stringMaxStorage >= (cLen + 1))
					{	CopyBlock(p, aCStr, cLen);
						p[cLen] = 0;
						param_d->text.stringLen = cLen;
					}
					else
					{	CopyBlock(p, aCStr, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = cLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = cLen;
				break;
			case kChar:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				CNumToString(aLong, aCStr);
				*param_d->theChar = *aCStr;
				break;
			/*case kObj:
				BAPI_ClearParameterRec(api_data, &parameter);
				if NOT(err = BAPI_BufferToObj(api_data, &aLong, sizeof(long), intClassID, true, nil, TEMP, VARIABLE, &parameter.objRef))
					err = BAPI_Clone(api_data, TEMP, VARIABLE, nil, param_d->objRef.classID, &parameter, 1, &param_d->objRef);
				break;*/
			default:
				CDebugStr("Unknown TypeCast Parameter");
				break;
		}
	}

return err;
}

//===========================================================================================
// N.B. no matter if type is kExplicitTypeCast or kImplicitTypeCast
/*static XErr	Int_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
TypeCast	*typeCast = &pbPtr->param.typeCast;
XErr		err = noErr;
	
	//if (typeCast->direction > 0)
	err = _DoTypeCast(pbPtr->api_data, &typeCast->param1, &typeCast->param2);
	//else
	//	err = _DoTypeCast(pbPtr->api_data, &typeCast->param2, &typeCast->param1);	
		
	/*
	ex:
	
	if NOT(err = BAPI_GetObj(api_data, &standardTypeRecP->objRef, (Ptr)&aLong, nil, nil, 0, 0, sizeof(long)))
	{	if (which == kInt)
			standardTypeRecP->intValue = aLong;
		else if (which == kUnsigned)
			standardTypeRecP->uIntValue = (aLong > 0) ? aLong : -aLong;
		else if (which == kDouble)
			standardTypeRecP->doubleValue = aLong;
		else if (which == kBool)
			standardTypeRecP->boolValue = (aLong != 0);
		else if (which == kCString)
		{	CNumToString(aLong, aCStr);
			cLen = CLen(aCStr);
			if (standardTypeRecP->stringP)
			{	if (standardTypeRecP->stringMaxStorage >= cLen)
				{	CopyBlock(standardTypeRecP->stringP, aCStr, cLen);
					standardTypeRecP->stringLen = cLen;
				}
				else
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
			}
			else
				standardTypeRecP->stringLen = cLen;
		}
	}*/
	/*
return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	int_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			intClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void int(obj num)");
			break;
		case kInit:
			//err = Int_Init(pbPtr);
			break;
		case kShutDown:
			err = Int_ShutDown(pbPtr);
			break;
		case kRun:
			// do nothing
			break;
		case kExit:
			// do nothing
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Int_Constructor(pbPtr);
			break;
		case kDestructor:
			// do nothing
			break;
		case kExecuteOperation:
			err = Int_ExecuteOperation(pbPtr);
			break;
		/*case kIncrement:
			err = Int_Increment(pbPtr);
			break;*/
		case kOpposite:
			err = Int_Opposite(pbPtr);
			break;
		case kExecuteMethod:
			err = Int_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Int_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Int_SetProperty(pbPtr);
			break;
		/*case kModify:
			err = Int_Modify(pbPtr);
			break;*/
		case kPrimitive:
			err = Int_TypeCast(pbPtr);
			break;
		case kGetErrMessage:
		case kSuperIsChanged:
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


