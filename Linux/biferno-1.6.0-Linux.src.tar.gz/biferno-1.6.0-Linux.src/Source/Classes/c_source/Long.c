/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Long.c,v 1.7 2003-07-16 13:19:24 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BifernoEngineAPI.h"
#include 	"StaticClasses.h"

#include 	<limits.h>

static long	longClassID;
static long		gsDoubleClassID, gsApiVersion;

//===========================================================================================
/*static XErr	_CheckOverflow(LONGLONG item1, LONGLONG item2, LONGLONG res)
{
XErr		err = noErr;

	if ((item1 > 0) && (item2 > 0) && (res < 0))
		err = XError(kBAPI_Error, Err_Overflow);
	else if ((item1 < 0) && (item2 < 0) && (res < 0))
		err = XError(kBAPI_Error, Err_Overflow);
	
return err;
}
*/
//===========================================================================================
/*static double	_DoLongOperation_WithDouble(long operation, LONGLONG item1, double item2, Boolean *isBoolP, Boolean *boolResP, XErr *errP)
{
XErr		err = noErr;
double		res = 0;
Boolean		boolres = false;
long		aLong;

	*isBoolP = false;
	switch(operation)
	{	case EVAL_MULT:
			res = item1 * item2;
			break;
		case EVAL_DIV:
			res = item1 / item2;
			break;
		case EVAL_MOD:
			aLong = item2;
			res = item1 % aLong;
			break;
		case EVAL_ADD:
			res = item1 + item2;
			break;
		case EVAL_MINUS:
			res = item1 - item2;
			break;
		case EVAL_SHIFTR:
			aLong = item2;
			res = item1 >> aLong;
			break;
		case EVAL_SHIFTL:
			aLong = item2;
			res = item1 << aLong;
			break;
		case EVAL_GTH:
			boolres = item1 > item2;
			*isBoolP = true;
			break;
		case EVAL_LTH:
			boolres = item1 < item2;
			*isBoolP = true;
			break;
		case EVAL_GEQ:
			boolres = item1 >= item2;
			*isBoolP = true;
			break;
		case EVAL_LEQ:
			boolres = item1 <= item2;
			*isBoolP = true;
			break;
		case EVAL_EQUA:
			boolres = item1 == item2;
			*isBoolP = true;
			break;
		case EVAL_NEQUA:
			boolres = item1 != item2;
			*isBoolP = true;
			break;
		case EVAL_ARAND:
			aLong = item2;
			res = item1 & aLong;
			break;
		case EVAL_AROR:
			aLong = item2;
			res = item1 | aLong;
			break;
		default:
			CDebugStr("Unknown operator!");
	}

*boolResP = boolres;
*errP = err;
return res;
}
*/

//===========================================================================================
static LONGLONG	_DoLongOperation(long operation, LONGLONG item1, LONGLONG item2, Boolean *isBoolP, Boolean *boolResP, LONGLONG *resultP)
{
Boolean		boolres = false;
LONGLONG	res = 0;

	*isBoolP = false;
	switch(operation)
	{	case EVAL_MULT:
			if (LongLongMul(&item1, item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_DIV:
			if (item2)
				res = item1 / item2;
			else
				return true;
			break;
		case EVAL_MOD:
			res = item1 % item2;
			break;
		case EVAL_ADD:
			if (LongLongAdd(&item1, item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_MINUS:
			if (LongLongAdd(&item1, -item2))
				res = item1;
			else
				return true;
			break;
		case EVAL_SHIFTR:
			res = item1 >> item2;
			break;
		case EVAL_SHIFTL:
			res = item1 << item2;
			break;
		case EVAL_GTH:
			boolres = item1 > item2;
			*isBoolP = true;
			break;
		case EVAL_LTH:
			boolres = item1 < item2;
			*isBoolP = true;
			break;
		case EVAL_GEQ:
			boolres = item1 >= item2;
			*isBoolP = true;
			break;
		case EVAL_LEQ:
			boolres = item1 <= item2;
			*isBoolP = true;
			break;
		case EVAL_EQUA:
			boolres = item1 == item2;
			*isBoolP = true;
			break;
		case EVAL_NEQUA:
			boolres = item1 != item2;
			*isBoolP = true;
			break;
		case EVAL_ARAND:
			res = item1 & item2;
			break;
		case EVAL_AROR:
			res = item1 | item2;
			break;
		default:
			CDebugStr("Unknown operator!");
	}

*boolResP = boolres;
*resultP = res;
return false;
}

#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
static XErr	Long_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;

	gsDoubleClassID = BAPI_ClassIDFromName(pbPtr->api_data, "double", false);
	
return err;
}

//===========================================================================================
static XErr	Long_Constructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			strLen, api_data = pbPtr->api_data;
//BlockRef		dataBlock = 0;
CStr63			aCStr;
LONGLONG		l;

	if (constructorRecP->totVars == 1)
	{	if (OBJ_CLASSID(constructorRecP->varRecsP[0].objRef) == longClassID)
			err = BAPI_CopyObj(api_data, &constructorRecP->varRecsP[0].objRef, constructorRecP->privateData, &constructorRecP->resultObjRef);
		else
		{	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP->objRef, aCStr, &strLen, 63, kImplicitTypeCast))
			{	if (BAPI_GetObjClassID(pbPtr->api_data, &constructorRecP->varRecsP->objRef) == gsDoubleClassID)
					l = (LONGLONG)CStrToReal(aCStr);
				else
					err = CStringToLongNum(aCStr, strLen, &l);
				if NOT(err)
					err = BAPI_BufferToObj(api_data, (Ptr)&l, sizeof(LONGLONG), longClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
			}
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "long(obj param)");
	}

	if NOT(err)
		OBJ_CLASSID(constructorRecP->resultObjRef) = longClassID;
		
return err;
}

//===========================================================================================
// Il risultato va messo in objRef1
static XErr	Long_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err= noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				operation = exeOperationRecP->operation;
Boolean				boolres, isBool;
long				api_data = pbPtr->api_data;
long				tLen;//, res;
//double				item2;
LONGLONG			resL, l, l2;

	tLen = sizeof(LONGLONG);
	if NOT(err = BAPI_GetObj(api_data, &exeOperationRecP->objRef1, (Ptr)&l, &tLen, 0, nil))
	{	tLen = sizeof(LONGLONG);
		if NOT(err = BAPI_GetObj(api_data, &exeOperationRecP->objRef2, (Ptr)&l2, &tLen, 0, nil))
		{	if (_DoLongOperation(operation, l, l2, &isBool, &boolres, &resL))
				err = XError(kBAPI_Error, Err_Overflow);
			else
			{	if (isBool)
					err = BAPI_BooleanToObj(api_data, boolres, &exeOperationRecP->resultObjRef);
				else
					err = BAPI_LongToObj(api_data, resL, &exeOperationRecP->resultObjRef);
			}
		}
	}

		
return err;
}

//===========================================================================================
/*static XErr	Long_Increment(Biferno_ParamBlockPtr pbPtr)
{
IncrementRec	*incrP = &pbPtr->param.incrementRec;
XErr			err = noErr;

	err = DLM_IncrementLongLong(OBJ_LIST(incrP->objRef), OBJ_ID(incrP->objRef), incrP->decrement);
	
return noErr;
}*/

//===========================================================================================
static XErr	Long_Opposite(Biferno_ParamBlockPtr pbPtr)
{
OppositeRec		*oppP = &pbPtr->param.oppositeRec;
XErr			err = noErr;
long			tLen;
LONGLONG		aLongLong;

	tLen = sizeof(LONGLONG);
	//if NOT(err = DLM_GetObj(OBJ_LIST(oppP->objRef), OBJ_ID(oppP->objRef), (Ptr)&aLongLong, &tLen, 0, nil))
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &oppP->objRef, (Ptr)&aLongLong, &tLen, 0, nil))
		err = BAPI_LongToObj(pbPtr->api_data, -aLongLong, &oppP->resultObjRef);	

return err;
}

//===========================================================================================
static XErr	Long_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
LONGLONG		l;
CStr255			aCStr;
long			cLen;
Ptr				p;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
//TypeCastParam	*param_s = &typeCast->param1, *param_d = &typeCast->param2;
long			tLen, api_data = pbPtr->api_data;
//double			aDouble;
PrimitiveUnion	*param_d;
//ParameterRec	parameter;

	tLen = sizeof(LONGLONG);
	if NOT(err = BAPI_GetObj(api_data, &typeCast->objRef, (Ptr)&l, &tLen, 0, nil))
	{	if NOT(tLen)
			l = 0;
		param_d = &typeCast->result;
		switch(typeCast->resultWanted)
		{	case kInt:
				if ((l >= LONG_MIN) && (l <= LONG_MAX))
					param_d->intValue = (long)l;
				else
					err = XError(kBAPI_Error, Err_Overflow);
				break;
			case kLong:
				param_d->longValue = (LONGLONG)l;
				break;
			case kUnsigned:
				if ((l >= 0) && (l <= ULONG_MAX))
					param_d->uIntValue = (unsigned long)l;// ? -aLong : (aLong > 0);
				else
					err = XError(kBAPI_Error, Err_Overflow);
				break;
			case kDouble:
				param_d->doubleValue = (double)l;
				break;
			case kBool:
				param_d->boolValue = (l != 0);
				break;
			case kCString:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				CLongNumToString(l, aCStr);
				cLen = CLen(aCStr);
				if (p = param_d->text.stringP)
				{	if (param_d->text.stringMaxStorage >= (cLen + 1))
					{	CopyBlock(p, aCStr, cLen);
						p[cLen] = 0;
						param_d->text.stringLen = cLen;
					}
					else
					{	CopyBlock(p, aCStr, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = cLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = cLen;
				break;
			case kChar:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				CLongNumToString(l, aCStr);
				*param_d->theChar = *aCStr;
				break;
			/*case kObj:
				BAPI_ClearParameterRec(api_data, &parameter);
				if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&l, sizeof(LONGLONG), longClassID, true, nil, TEMP, VARIABLE, &parameter.objRef))
					err = BAPI_Clone(api_data, TEMP, VARIABLE, nil, param_d->objRef.classID, &parameter, 1, &param_d->objRef);
				break;*/
			default:
				CDebugStr("Unknown TypeCast Parameter");
				break;
		}
	}


return err;
}


#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	long_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "long");
			gsApiVersion = pbPtr->param.registerRec.api_version;
			longClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void long(obj num)");
			break;
		case kInit:
			err = Long_Init(pbPtr);
			break;
		case kShutDown:
			longClassID = 0;
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Long_Constructor(pbPtr);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = Long_ExecuteOperation(pbPtr);
			break;
		/*case kIncrement:
			err = Long_Increment(pbPtr);
			break;*/
		case kOpposite:
			err = Long_Opposite(pbPtr);
			break;
		case kExecuteMethod:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = Long_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


/*
#if __MWERKS__
#pragma mark-
#endif

#elif JAVA_ENABLED

#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

static long	longClassID, intClassID;

//===========================================================================================
XErr	long_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
	return BAPI_SuperAll(message, pbPtr, "double", &longClassID, "int", &intClassID);
}

#endif
*/
