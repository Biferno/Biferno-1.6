/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: memberInfo.c,v 1.13 2005-03-18 15:26:16 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

// defines
#define	gsPlugName	"memberInfo"

// Methods
enum{
		kIsDef = 1
	};
#define TOT_METHODES	1

// Properties
#define TOT_PROPRIETIES	28
enum{
		k_name,
		k_implem,
		k_sourcePath,
		k_className,
		k_memberType,
		k_returnClass,
		k_returnAeLevel,
		k_returnAeClass,
		k_purpose,
		k_descr,
		k_errors,
		k_seeAlso,
		k_note,
		k_returns,
		k_prototype,
		k_varArgs,
		k_nonames,
		k_isStatic,
		k_isConst,
		k_visibility,
		k_totParams,
		k_paramName,
		k_paramClass,
		k_paramAeLevel,
		k_paramAeClass,
		k_paramTarget,
		k_paramDefault,
		k_paramDescr
	};

#define TOT_COSTANTS		2
	
static 	long	memberInfoClassID;

//===========================================================================================
static XErr	_MemberInfoRegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	memberInfoProperty[TOT_PROPRIETIES] = 
					{	"name",				k_name,				"string",
						"implem",			k_implem,			"int",
						"sourcePath",		k_sourcePath,		"string",
						"className",		k_className,		"string",
						"memberType",		k_memberType,		"string",
						"returnClass",		k_returnClass,		"string",
						"returnAeLevel",	k_returnAeLevel,	"int",
						"returnAeClass",	k_returnAeClass,	"string",
						"purpose",			k_purpose,			"string",
						"descr",			k_descr,			"string",
						"errors",			k_errors,			"string",
						"seeAlso",			k_seeAlso,			"string",
						"note",				k_note,				"string",
						"returns",			k_returns,			"string",
						"prototype",		k_prototype,		"string",
						"varArgs",			k_varArgs,			"boolean",
						"nonames",			k_nonames,			"boolean",
						"isStatic",			k_isStatic,			"boolean",
						"isConst",			k_isConst,			"boolean",
						"visibility",		k_visibility,		"string",
						"totParams",		k_totParams,		"int",
						"paramName[]",		k_paramName,		"int",
						"paramClass[]",		k_paramClass,		"int",
						"paramAeLevel[]",	k_paramAeLevel,		"int",
						"paramAeClass[]",	k_paramAeClass,		"int",
						"paramTarget[]",	k_paramTarget,		"string",
						"paramDefault[]",	k_paramDefault,		"int",
						"paramDescr[]",		k_paramDescr,		"int"
					};
					
BAPI_MemberRecord	memberInfoMethods[TOT_METHODES] = 
					{	"IsDef",			kIsDef, 	"static boolean	IsDef(string className, string memberName)"
					};

BAPI_MemberRecord	memberInfoCostants[TOT_COSTANTS] = 
					{	"c", 			kCImplementation,		"int",
						"biferno", 		kBifernoImplementation,	"int"
					};

	if (err = BAPI_NewProperties(api_data, memberInfoClassID, memberInfoProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewMethods(api_data, memberInfoClassID, memberInfoMethods, TOT_METHODES, nil))
		return err;
	if (err = BAPI_NewConstants(api_data, memberInfoClassID, memberInfoCostants, TOT_COSTANTS, nil))
		return err;

//out:
return err;
}

//===========================================================================================
static XErr	_AddPropertyStuff(long buffID, Boolean isStatic, Byte visibility, Boolean isConst)
{	
XErr		err = noErr;
CStr255		aCStr;

	if (err = BufferAddCString(buffID, "isStatic: ", NO_ENC, 0))
		goto out;
	if (isStatic)
		CEquStr(aCStr, "yes");
	else
		CEquStr(aCStr, "no");
	if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, "visibility: ", NO_ENC, 0))
		goto out;
	switch(visibility)
	{
		case kPublic:
			CEquStr(aCStr, "public");
			break;
		case kPrivate:
			CEquStr(aCStr, "private");
			break;
		case kProtected:
			CEquStr(aCStr, "protected");
			break;
	}
	if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, "isConst: ", NO_ENC, 0))
		goto out;
	if (isConst)
		CEquStr(aCStr, "yes");
	else
		CEquStr(aCStr, "no");
	if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
		goto out;

out:
return err;
}

//===========================================================================================
static XErr	_AddMethodStuff(long api_data, BAPI_Doc *docP, long buffID, Boolean isFunc, Boolean varArgs, Boolean noNames, Boolean isStatic, Byte visibility, long totParams, BAPI_ParameterDoc *paramP)
{	
XErr		err = noErr;
CStr255		aCStr, tStr;
long		aeLev, i;
BAPI_Descr	*descrP;

	if (docP->xmlStuff)
		descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
	else
		descrP = nil;
	if (err = BufferAddCString(buffID, "varArgs: ", NO_ENC, 0))
		goto out;
	if (varArgs)
		CEquStr(aCStr, "yes");
	else
		CEquStr(aCStr, "no");
	if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, "nonames: ", NO_ENC, 0))
		goto out;
	if (noNames)
		CEquStr(aCStr, "yes");
	else
		CEquStr(aCStr, "no");
	if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
		goto out;
	if NOT(isFunc)
	{	if (err = BufferAddCString(buffID, "isStatic: ", NO_ENC, 0))
			goto out;
		if (isStatic)
			CEquStr(aCStr, "yes");
		else
			CEquStr(aCStr, "no");
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, "visibility: ", NO_ENC, 0))
			goto out;
		switch(visibility)
		{
			case kPublic:
				CEquStr(aCStr, "public");
				break;
			case kPrivate:
				CEquStr(aCStr, "private");
				break;
			case kProtected:
				CEquStr(aCStr, "protected");
				break;
		}
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
			goto out;
	}
	if (err = BufferAddCString(buffID, "totParams: ", NO_ENC, 0))
		goto out;
	CNumToString(totParams, aCStr);
	if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
		goto out;
	if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
		goto out;
		
	for (i = 0; i < totParams; i++, paramP++)
	{
		CEquStr(aCStr, "paramName: ");
		CAddStr(aCStr, paramP->name);
		CAddStr(aCStr, EOL_STRING);
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		CEquStr(aCStr, "paramClass: ");
		if (err = BAPI_NameFromClassID(api_data, paramP->classID, tStr))
			goto out;
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, EOL_STRING);
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		if (paramP->aeLevel == AE_LEVEL_LIMIT)
			aeLev = 0;
		else
			aeLev = paramP->aeLevel;
		if (aeLev)
		{	CEquStr(aCStr, "paramAeLevel: ");
			CNumToString(aeLev, tStr);
			CAddStr(aCStr, tStr);
			CAddStr(aCStr, EOL_STRING);
			if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
				goto out;
		}
		CEquStr(aCStr, "paramAeClass: ");
		if (paramP->aeClassID)
			err = BAPI_NameFromClassID(api_data, paramP->aeClassID, tStr);
		else
			*tStr = 0;
		if (err)
			goto out;
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, EOL_STRING);
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		CEquStr(aCStr, "target: ");
		if (paramP->targetClassID)
			err = BAPI_NameFromClassID(api_data, paramP->targetClassID, tStr);
		else
			CEquStr(tStr, "");
		if NOT(err)
		{	CAddStr(aCStr, tStr);
			CAddStr(aCStr, EOL_STRING);
			if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
				goto out;
			CEquStr(aCStr, "paramDefault: ");
			CAddStr(aCStr, paramP->defaultStr);
			CAddStr(aCStr, EOL_STRING);
			if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "paramDescr: ", NO_ENC, 0))
				goto out;
			if (descrP && descrP->params[i].len)
			{	if (err = BufferAddText(buffID, (Ptr)descrP + descrP->params[i].off, descrP->params[i].len, NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
		}
	}
	
	

out:
return err;
}
//===========================================================================================
//===========================================================================================
static XErr	_GetClassName(long api_data, BAPI_Doc *docP, char *className, char *typeStr)
{	
XErr		err = noErr;

	switch(docP->type)
	{	
		case kMethod:
			if (typeStr)
				CEquStr(typeStr, "method");
			err = BAPI_NameFromClassID(api_data, docP->info.method.classID, className);
			break;
		case kProperty:
			if (typeStr)
				CEquStr(typeStr, "property");
			err = BAPI_NameFromClassID(api_data, docP->info.property.classID, className);
			break;
		case kFunction:
			if (typeStr)
				CEquStr(typeStr, "function");
			*className = 0;
			break;
		case kError:
			if (typeStr)
				CEquStr(typeStr, "error");
			err = BAPI_NameFromClassID(api_data, docP->info.property.classID, className);
			break;
		case kConstant:
			if (typeStr)
				CEquStr(typeStr, "constant");
			err = BAPI_NameFromClassID(api_data, docP->info.property.classID, className);
			break;
	}

return err;
}

//===========================================================================================
static XErr	_MemberInfoToString(long api_data, BAPI_Doc *docP, BufferID *idP)
{
XErr		err = noErr;
long		aeLev, buffID = 0;
CStr63		typeStr, aCStr, className;
BAPI_Descr	*descrP;

	if (docP->xmlStuff)
		descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
	else
		descrP = nil;
	if (buffID = BufferCreate(256, &err))
	{	if (err = _GetClassName(api_data, docP, className, typeStr))
			goto out;
		/*switch(docP->type)
		{	
			case kMethod:
				CEquStr(typeStr, "method");
				err = BAPI_NameFromClassID(api_data, docP->info.method.classID, className);
				break;
			case kProperty:
				CEquStr(typeStr, "property");
				err = BAPI_NameFromClassID(api_data, docP->info.property.classID, className);
				break;
			case kFunction:
				CEquStr(typeStr, "function");
				*className = 0;
				break;
			case kError:
				CEquStr(typeStr, "error");
				err = BAPI_NameFromClassID(api_data, docP->info.property.classID, className);
				break;
			case kConstant:
				CEquStr(typeStr, "constant");
				err = BAPI_NameFromClassID(api_data, docP->info.property.classID, className);
				break;
		}*/
		if (err = BufferAddCString(buffID, "name: ", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, docP->name, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, "prototype: ", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, docP->prototype, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, "type: ", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, typeStr, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
			goto out;
		if (*className)
		{	if (err = BufferAddCString(buffID, "className: ", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, className, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
		}
		if (docP->returnClassID)
		{	if (err = BufferAddCString(buffID, "returnClass: ", NO_ENC, 0))
				goto out;
			if (err = BAPI_NameFromClassID(api_data, docP->returnClassID, className))
				goto out;
			if (err = BufferAddCString(buffID, className, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
			if (docP->returnAeClass)
			{	if (err = BufferAddCString(buffID, "returnAeClass: ", NO_ENC, 0))
					goto out;
				if (err = BAPI_NameFromClassID(api_data, docP->returnAeClass, className))
					goto out;
				if (err = BufferAddCString(buffID, className, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
					goto out;
			}
			if (docP->returnAeLevel == AE_LEVEL_LIMIT)
				aeLev = 0;
			else
				aeLev = docP->returnAeLevel;
			if (aeLev)
			{	if (err = BufferAddCString(buffID, "returnAeLevel: ", NO_ENC, 0))
					goto out;
				CNumToString(aeLev, aCStr);
				if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
					goto out;
			}
		}
		switch(docP->type)
		{	
			case kMethod:
				{
				BAPI_MethodDoc	*methodP;
				
				methodP = &docP->info.method;
				err = _AddMethodStuff(api_data, docP, buffID, false, methodP->varArgs, methodP->noNames, docP->isStatic, methodP->visibility, docP->totParams, docP->params);
				}
				break;
			case kProperty:
				{
				BAPI_PropertyDoc	*propertyP;
				
				propertyP = &docP->info.property;
				err = _AddPropertyStuff(buffID, docP->isStatic, propertyP->visibility, propertyP->isConst);
				}
				break;
			case kFunction:
				{
				BAPI_MethodDoc	*methodP;
				
				methodP = &docP->info.method;
				err = _AddMethodStuff(api_data, docP, buffID, false, methodP->varArgs, methodP->noNames, 0, 0, docP->totParams, docP->params);
				}
				break;
			case kError:
				{
				BAPI_PropertyDoc	*propertyP;
				
				propertyP = &docP->info.property;
				err = _AddPropertyStuff(buffID, docP->isStatic, propertyP->visibility, propertyP->isConst);
				}
				break;
			case kConstant:
				{
				BAPI_PropertyDoc	*propertyP;
				
				propertyP = &docP->info.property;
				err = _AddPropertyStuff(buffID, docP->isStatic, propertyP->visibility, propertyP->isConst);
				}
				break;
		
		}
		if (descrP)
		{	if (err = BufferAddCString(buffID, "purpose: ", NO_ENC, 0))
				goto out;
			if (descrP->purpose.len)
			{	if (err = BufferAddText(buffID, (Ptr)descrP + descrP->purpose.off, descrP->purpose.len, NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "descr: ", NO_ENC, 0))
				goto out;
			if (descrP->descr.len)
			{	if (err = BufferAddText(buffID, (Ptr)descrP + descrP->descr.off, descrP->descr.len, NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "errors: ", NO_ENC, 0))
				goto out;
			if (descrP->errors.len)
			{	if (err = BufferAddText(buffID, (Ptr)descrP + descrP->errors.off, descrP->errors.len, NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "see_also: ", NO_ENC, 0))
				goto out;
			if (descrP->seeAlso.len)
			{	if (err = BufferAddText(buffID, (Ptr)descrP + descrP->seeAlso.off, descrP->seeAlso.len, NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "note: ", NO_ENC, 0))
				goto out;
			if (descrP->note.len)
			{	if (err = BufferAddText(buffID, (Ptr)descrP + descrP->note.off, descrP->note.len, NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "returns: ", NO_ENC, 0))
				goto out;
			if (descrP->returns.len)
			{	if (err = BufferAddText(buffID, (Ptr)descrP + descrP->returns.off, descrP->returns.len, NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(buffID, EOL_STRING, NO_ENC, 0))
				goto out;
		}
	out:
		if (err)
			BufferFree(buffID);
	}
	if NOT(err)
		*idP = buffID;	

return err;
}

//===========================================================================================
static XErr	_CreateObj(long api_data, BAPI_Doc *docP, long which, BAPI_ParameterDoc *paramP, long i, ObjRef *result)
{
CStr255		aCStr;
XErr		err = noErr;
BAPI_Descr	*descrP;
int			aeLev;

	switch(which)
	{
		case k_paramName:
			err = BAPI_StringToObj(api_data, paramP->name, CLen(paramP->name), result);
			break;
		case k_paramClass:
			if NOT(err = BAPI_NameFromClassID(api_data, paramP->classID, aCStr))
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
			break;
		case k_paramAeLevel:
			if (paramP->aeLevel == AE_LEVEL_LIMIT)
				aeLev = 0;
			else
				aeLev = paramP->aeLevel;
			err = BAPI_IntToObj(api_data, aeLev, result);
			break;
		case k_paramAeClass:
			if (paramP->aeClassID)
				err = BAPI_NameFromClassID(api_data, paramP->aeClassID, aCStr);
			else
				*aCStr = 0;
			if NOT(err)
				err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
			break;
		case k_paramTarget:
			if (paramP->targetClassID)
			{	if NOT(err = BAPI_NameFromClassID(api_data, paramP->targetClassID, aCStr))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
			}
			else
				err = BAPI_StringToObj(api_data, "", 0, result);
			break;
		case k_paramDefault:
			err = BAPI_StringToObj(api_data, paramP->defaultStr, CLen(paramP->defaultStr), result);
			break;
		case k_paramDescr:
			if (docP->xmlStuff)
			{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
				err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->params[i].off, descrP->params[i].len, result);
			}
			else
				err = BAPI_StringToObj(api_data, "", 0, result);
			break;
	}

return err;
}

//===========================================================================================
static XErr	_ParamElement(long api_data, ArrayIndexRec *mCoordP, BAPI_Doc *docP, Boolean fixedSize, long which, ObjRef *result)
{
XErr				err = noErr;
long				totParams, i;
BAPI_ParameterDoc	*paramP;
char				*strP;
ObjRef				tObjRef;
Boolean				found;

	totParams = docP->totParams;
	paramP = docP->params;
	if (*mCoordP->ind_name)
	{	strP = mCoordP->ind_name;
		found = false;
		for (i = 0; i < totParams; i++, paramP++)
		{	if NOT(CCompareStrings_cs(strP, paramP->name))
			{	err = _CreateObj(api_data, docP, which, paramP, i, result);
				found = true;
				break;
			}
		}
		if NOT(found)
			err = XError(kBAPI_Error, Err_ArrayElementNotFound);
	}
	else if (mCoordP->ind)
	{	if ((mCoordP->ind > 0) && (mCoordP->ind <= totParams))
		{	paramP += mCoordP->ind - 1;
			err = _CreateObj(api_data, docP, which, paramP, mCoordP->ind-1, result);
		}
		else
			err = XError(kBAPI_Error, Err_OutOfBoundary);
	}
	else
	{	if NOT(err = BAPI_ArrayToObj(api_data, fixedSize, nil, 0, nil, nil, result))
		{	totParams = totParams;
			for (i = 0; i < totParams; i++, paramP++)
			{	BAPI_InvalObjRef(api_data, &tObjRef);
				if NOT(err = _CreateObj(api_data, docP, which, paramP, i, &tObjRef))
					err = BAPI_ArrayAddElement(api_data, result, nil, &tObjRef);
			}
		}
	}

return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	MemberInfo_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	memberInfoClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.fixedSize = true;
	pbPtr->param.registerRec.wantDestructor = true;
	CEquStr(pbPtr->param.registerRec.constructor, "void memberInfo(string className, string memberName, boolean extended)");
		
//out:
return err;
}

//===========================================================================================
static XErr	MemberInfo_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _MemberInfoRegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	MemberInfo_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
CStr63			className, memberName;
long			tLen, api_data = pbPtr->api_data;
ParameterRec	*paramVarsP = constructorRecP->varRecsP;
BlockRef 		newDocBlockRef, docBlockRef;
Boolean			extended;

	if (clone)
	{	tLen = sizeof(BlockRef);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &paramVarsP[0].objRef, (Ptr)&docBlockRef, &tLen, 0, nil))
		{	if NOT(err = BAPI_DuplicateMemberDoc(api_data, docBlockRef, &newDocBlockRef))
				err = BAPI_BufferToObj(api_data, (Ptr)&newDocBlockRef, sizeof(BlockRef), memberInfoClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
	else if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, className, nil, 64, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[1].objRef, memberName, nil, 64, kImplicitTypeCast))
		{	if NOT(*memberName)
				err = XError(kBAPI_Error, Err_InvalidParameter);
			else if NOT(err = BAPI_ObjToBoolean(api_data, &paramVarsP[2].objRef, &extended, kImplicitTypeCast))
			{	if NOT(err = BAPI_GetMemberDoc(api_data, className, memberName, &docBlockRef, extended))
					err = BAPI_BufferToObj(api_data, (Ptr)&docBlockRef, sizeof(BlockRef), memberInfoClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	MemberInfo_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
BlockRef		docBlock;
long			objLen, api_data = pbPtr->api_data;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(BlockRef);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&docBlock, &objLen, 0, nil))
		{	if (objLen)
				BAPI_ReleaseMemberDoc(api_data, &docBlock);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	MemberInfo_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
XErr				err = noErr;
BlockRef			dataBlock;
long				tLen, id = 0, size, api_data = pbPtr->api_data;
Ptr					p;
Primitive_String	*textP;
PrimitiveUnion		*param_d;
Boolean				needSer;
BlockRef			docBlock;
BAPI_Doc			*docP;
CStr255				aCStr;
CStr63				className;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		param_d = &typeCast->result;
		tLen = sizeof(BlockRef);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&docBlock, &tLen, 0, nil))
		{	if (tLen)
			{	LockBlock(docBlock);
				docP = (BAPI_Doc*)GetPtr(docBlock);
			}
			else
				docBlock = 0;
			if (typeCast->resultWanted == kBool)
			{	if (docBlock)
					typeCast->result.boolValue = (*docP->name != 0);
				else
					typeCast->result.boolValue = false;
			}
			else if (typeCast->resultWanted == kCString)
			{	if (docBlock)
				{	if (param_d->text.variant == kForConstructor)
					{	id = 0;
						CEquStr(aCStr, "\"");
						if NOT(err = _GetClassName(api_data, docP, className, nil))
						{	CAddStr(aCStr, className);
							CAddStr(aCStr, "\", \"");
							CAddStr(aCStr, docP->name);
							CAddStr(aCStr, "\"");
							p = aCStr;
							size = CLen(aCStr);
						}
					}
					else
					{	if NOT(err = _MemberInfoToString(api_data, docP, &id))
						{	if (dataBlock = BufferGetBlockRef(id, &size))
							{	p = GetPtr(dataBlock);
								LockBlock(dataBlock);
							}
						}
					}
				}
				else
				{	p = aCStr;
					size = 0;
				}
				if NOT(err)
				{	textP = &param_d->text;
					if (textP->stringP)
					{	if (textP->stringMaxStorage >= (size + 1))
						{	CopyBlock(textP->stringP, p, size);
							textP->stringLen = size;
						}
						else
						{	CopyBlock(textP->stringP, p, textP->stringMaxStorage - 1);
							textP->stringP[textP->stringMaxStorage - 1] = 0;
							textP->stringLen = size;
							err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
						}
					}
					else
						textP->stringLen = size;
				}
				if (id)
					BufferFree(id);
			}
			else
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
			if (docBlock)
				UnlockBlock(docBlock);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	MemberInfo_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr				err = noErr;
long				aeLev, aLong, tLen, api_data = pbPtr->api_data;
Boolean				aBool, needSer;
Byte				visibility;
BlockRef			docBlock;
BAPI_Doc			*docP;
CStr255				aCStr;
ArrayIndexRec		mCoord;
ObjRef				*resultObjRefP = &getPropertyRec->resultObjRef;
BAPI_Descr			*descrP;

	if (getPropertyRec->isConstant)
		return BAPI_IntToObj(api_data, getPropertyRec->propertyID, &getPropertyRec->resultObjRef);
		
	if (getPropertyRec->propertyIndex)
		mCoord = getPropertyRec->propertyIndex[0];
	else
		ClearBlock(&mCoord, sizeof(ArrayIndexRec));
	if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
		err = BAPI_NeedSerialize(api_data, &getPropertyRec->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(BlockRef);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&docBlock, &tLen, 0, nil))
		{	LockBlock(docBlock);
			docP = (BAPI_Doc*)GetPtr(docBlock);
			switch(getPropertyRec->propertyID)
			{
				case k_name:
					err = BAPI_StringToObj(api_data, docP->name, CLen(docP->name), resultObjRefP);
					break;
				case k_implem:
					err = BAPI_IntToObj(api_data, docP->implem, resultObjRefP);
					break;
				case k_sourcePath:
					if (docP->implem == kBifernoImplementation)
					{	CEquStr(aCStr, FILE_HD_PREFIX);
						CAddStr(aCStr, docP->ident.b.sourceFile.filePath);
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), resultObjRefP);
						//err = BAPI_StringToObj(api_data, docP->ident.b.sourceFile.filePath, CLen(docP->ident.b.sourceFile.filePath), resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_className:
					switch(docP->type)
					{	
						case kMethod:
							err = BAPI_NameFromClassID(api_data, docP->info.method.classID, aCStr);
							break;
						case kProperty:
							err = BAPI_NameFromClassID(api_data, docP->info.property.classID, aCStr);
							break;
						case kFunction:
							CEquStr(aCStr, "function");
							break;
						case kError:
							err = BAPI_NameFromClassID(api_data, docP->info.property.classID, aCStr);
							break;
						case kConstant:
							err = BAPI_NameFromClassID(api_data, docP->info.property.classID, aCStr);
							break;
					}
					if NOT(err)
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), resultObjRefP);
					break;
				case k_memberType:
					switch(docP->type)
					{	
						case kMethod:
							CEquStr(aCStr, "method");
							break;
						case kProperty:
							CEquStr(aCStr, "property");
							break;
						case kFunction:
							CEquStr(aCStr, "function");
							break;
						case kError:
							CEquStr(aCStr, "error");
							break;
						case kConstant:
							CEquStr(aCStr, "constant");
							break;
					}
					if NOT(err)
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), resultObjRefP);
					break;
				case k_returnClass:
					if (docP->returnClassID)
						err = BAPI_NameFromClassID(api_data, docP->returnClassID, aCStr);
					else
						*aCStr = 0;
					if NOT(err)
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), resultObjRefP);
					break;
				case k_returnAeLevel:
					if (docP->returnAeLevel == AE_LEVEL_LIMIT)
						aeLev = 0;
					else
						aeLev = docP->returnAeLevel;
					err = BAPI_IntToObj(api_data, aeLev, resultObjRefP);
					break;
				case k_returnAeClass:
					if (docP->returnAeClass)
						err = BAPI_NameFromClassID(api_data, docP->returnAeClass, aCStr);
					else
						*aCStr = 0;
					if NOT(err)
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), resultObjRefP);
					break;
				case k_purpose:
					if (docP->xmlStuff)
					{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->purpose.off, descrP->purpose.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_descr:
					if (docP->xmlStuff)
					{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->descr.off, descrP->descr.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_errors:
					if (docP->xmlStuff)
					{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->errors.off, descrP->errors.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_seeAlso:
					if (docP->xmlStuff)
					{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->seeAlso.off, descrP->seeAlso.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_note:
					if (docP->xmlStuff)
					{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->note.off, descrP->note.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_returns:
					if (docP->xmlStuff)
					{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
						err = BAPI_StringToObj(api_data, (Ptr)descrP + descrP->returns.off, descrP->returns.len, resultObjRefP);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, resultObjRefP);
					break;
				case k_prototype:
					err = BAPI_StringToObj(api_data, docP->prototype, CLen(docP->prototype), resultObjRefP);
					break;
				case k_varArgs:
					switch(docP->type)
					{	
						case kMethod:
						case kFunction:
							aBool = docP->info.method.varArgs;
							break;
						case kProperty:
						case kError:
						case kConstant:
							aBool = false;
							break;
					}
					err = BAPI_BooleanToObj(api_data, aBool, resultObjRefP);
					break;
				case k_nonames:
					switch(docP->type)
					{	
						case kMethod:
						case kFunction:
							aBool = docP->info.method.noNames;
							break;
						case kProperty:
						case kError:
						case kConstant:
							aBool = false;
							break;
					}
					err = BAPI_BooleanToObj(api_data, aBool, resultObjRefP);
					break;
				case k_isStatic:
					switch(docP->type)
					{	
						case kMethod:
							aBool = docP->isStatic;
							break;
						case kFunction:
							aBool = false;
							break;
						case kProperty:
						case kError:
						case kConstant:
							aBool = docP->isStatic;
							break;
					}
					err = BAPI_BooleanToObj(api_data, aBool, resultObjRefP);
					break;
				case k_isConst:
					switch(docP->type)
					{	
						case kMethod:
						case kFunction:
							aBool = false;
							break;
						case kProperty:
						case kError:
						case kConstant:
							aBool = docP->info.property.isConst;
							break;
					}
					err = BAPI_BooleanToObj(api_data, aBool, resultObjRefP);
					break;
				case k_visibility:
					switch(docP->type)
					{	
						case kMethod:
							visibility = docP->info.method.visibility;
							break;
						case kFunction:
							visibility = 0;
							break;
						case kProperty:
						case kError:
						case kConstant:
							visibility = docP->info.property.visibility;
							break;
					}
					switch(visibility)
					{
						case kPublic:
							CEquStr(aCStr, "public");
							break;
						case kPrivate:
							CEquStr(aCStr, "private");
							break;
						case kProtected:
							CEquStr(aCStr, "protected");
							break;
						default:
							*aCStr = 0;
							break;				
					}
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), resultObjRefP);
					break;
				case k_totParams:
					switch(docP->type)
					{	
						case kMethod:
						case kFunction:
							aLong = docP->totParams;
							break;
						case kProperty:
						case kError:
						case kConstant:
							aLong = 0;
							break;
					}
					err = BAPI_IntToObj(api_data, aLong, resultObjRefP);
					break;
				case k_paramName:
					err = _ParamElement(api_data, &mCoord, docP, false, k_paramName, resultObjRefP);
					break;
				case k_paramClass:
					err = _ParamElement(api_data, &mCoord, docP, false, k_paramClass, resultObjRefP);
					break;
				case k_paramAeLevel:
					err = _ParamElement(api_data, &mCoord, docP, false, k_paramAeLevel, resultObjRefP);
					break;
				case k_paramAeClass:
					err = _ParamElement(api_data, &mCoord, docP, false, k_paramAeClass, resultObjRefP);
					break;
				case k_paramTarget:
					err = _ParamElement(api_data, &mCoord, docP, true, k_paramTarget, resultObjRefP);
					break;
				case k_paramDefault:
					err = _ParamElement(api_data, &mCoord, docP, false, k_paramDefault, resultObjRefP);
					break;
				case k_paramDescr:
					err = _ParamElement(api_data, &mCoord, docP, false, k_paramDescr, resultObjRefP);
					break;
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
			UnlockBlock(docBlock);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr	MemberInfo_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	switch(setPropertyRec->propertyID)
	{
		case k_name:
		case k_className:
		case k_memberType:
		case k_returnClass:
		case k_returnAeLevel:
		case k_returnAeClass:
		case k_purpose:
		case k_descr:
		case k_errors:
		case k_seeAlso:
		case k_note:
		case k_returns:
		case k_prototype:
		case k_varArgs:
		case k_nonames:
		case k_isStatic:
		case k_isConst:
		case k_visibility:
		case k_totParams:
		case k_paramName:
		case k_paramClass:
		case k_paramAeLevel:
		case k_paramAeClass:
		case k_paramTarget:
		case k_paramDefault:
		case k_paramDescr:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
static XErr	MemberInfo_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
ParameterRec 		*paramVarsP = exeMethodRecP->paramVarsP;
CStr63				className, memberName;
Boolean				isDef;

	switch(exeMethodRecP->methodID)
	{
		case kIsDef:
			if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, className, nil, 64, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[1].objRef, memberName, nil, 64, kImplicitTypeCast))
				{	if NOT(*memberName)
						err = XError(kBAPI_Error, Err_InvalidParameter);
					else if NOT(err = BAPI_IsMemberDef(api_data, className, memberName, &isDef))
						err = BAPI_BooleanToObj(api_data, isDef, &exeMethodRecP->resultObjRef);
				}
			}
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	memberInfo_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = MemberInfo_Register(pbPtr);
			break;
		case kInit:
			err = MemberInfo_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = MemberInfo_Constructor(pbPtr, false);
			break;
		case kClone:
			err = MemberInfo_Constructor(pbPtr, true);
			break;
		case kDestructor:
			err = MemberInfo_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = MemberInfo_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = MemberInfo_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = MemberInfo_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = MemberInfo_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


