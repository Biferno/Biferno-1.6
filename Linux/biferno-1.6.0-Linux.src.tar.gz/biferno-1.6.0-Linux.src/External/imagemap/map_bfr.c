/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: map_bfr.c,v 1.6 2005-10-07 11:44:59 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"

#include 	"map_bfr.h"
#include 	"point_bfr.h"
#include 	"mapquery_bfr.h"

#if __UNIX_XLIB__
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <errno.h>
	#include <math.h>
	#include <time.h>
	/*
	#include <wand/magick_wand.h>
	#include <wand/drawing_wand.h>
	#include <wand/pixel_wand.h>
	#include <wand/pixel_iterator.h>
	*/
#elif __WIN_XLIB__
	#include <math.h>
#endif

// Methods
enum{
		//kDraw = 1,
		kGetMapSize = 1,
		kImage2Map,
		kFindClick,
		kGetPolyCenter,
		kGetAreaShapes,
		kIsPolyInRect
	};
#define TOT_METHODES	6

// Errors
CStr63	gMapErrorsStr[] = 
	{	
		"ErrInvalidMapWidth",
		"ErrInvalidMapHeight",
		"ErrInvalidBorder",
		"ErrBadFile"
		/*,
		"ErrWhileDrawing",
		"ErrNewPixelWand",
		"ErrNewMagickWand"
		*/
		};

static long	gsMapClassID, gsStringClassID;

#define IP_MIN(x,y) (x < y ? x : y)
#define IP_MAX(x,y) (x > y ? x : y)
#define INSIDE 0
#define OUTSIDE 1

typedef struct {
   double x,y;
} Point;

//===========================================================================================
double Zoom(double zoom, double x)	
{
	if (zoom > 0)
		return (x * zoom);
	else
		return (x / -zoom);
}

//===========================================================================================
void	GetInfos(Ptr *polyPtrP, double *center_xP, double *center_yP, double zoom, long *totPolyP, long *frame_widthP, long *frame_heightP, double *x_offsetP, double *y_offsetP)
{
long		frame_width, frame_height;
Ptr			polyPtr;
long		border, totPoly;
double		center_x, center_y, min_x, min_y, max_x, max_y, width, save_width, height, save_height, x_offset, y_offset;
PolyHeader	*polHeadP;

	polyPtr = *polyPtrP;
	polHeadP = (PolyHeader*)polyPtr;
	
	frame_width = polHeadP->frame_width;
	frame_height = polHeadP->frame_height;
	border = polHeadP->frame_height;
	totPoly = polHeadP->totPoly;		
	// get enclosing rect
	min_x = polHeadP->min_x;		
	min_y = polHeadP->min_y;		
	max_x = polHeadP->max_x;		
	max_y = polHeadP->max_y;		
	width = max_x - min_x;
	if (width < 0)
		width = -width;
	save_width = width;
	width += border;
	height = max_y - min_y;
	if (height < 0)
		height = -height;
	save_height = height;
	height += border;
	
	center_x = *center_xP;
	center_y = *center_yP;
	// this point (in real map coordinates) that must be the center of the image
	if ((center_x < 0) && (center_y < 0))
	{	center_x = Zoom(zoom, save_width / 2);
		center_y = Zoom(zoom, save_height / 2);
		// center the image
		x_offset = frame_width / 2 - center_x;
		y_offset = frame_height / 2 - center_y;
	}
	else
	{	x_offset = frame_width / 2 - Zoom(zoom, center_x);
		y_offset = frame_height / 2 - Zoom(zoom, center_y);
	
	}				
	//printf("x_offset, y_offset: %f %f\n", x_offset, y_offset);

if (frame_widthP)
	*frame_widthP = frame_width;
if (frame_heightP)
	*frame_heightP = frame_height;
if (totPolyP)
	*totPolyP = totPoly;
if (x_offsetP)
	*x_offsetP = x_offset;
if (y_offsetP)
	*y_offsetP = y_offset;
*center_xP = center_x;
*center_yP = center_y;
*polyPtrP = polyPtr + POLY_FIRSTPOLY_OFFSET;
}

//===========================================================================================
void	IncrementMapRefCount(BlockRef block)
{
PolyHeader 		*polyHeadP = (PolyHeader*)GetPtr(block);

	polyHeadP->refCount++;
}

//===========================================================================================
XErr	DecrementMapRefCount(BlockRef block)
{
XErr			err = noErr;
PolyHeader 		*polyHeadP = (PolyHeader*)GetPtr(block);

	if NOT(--polyHeadP->refCount)		// 0 images point to this map
	{	DisposeBlock(&polyHeadP->offsets);
		DisposeBlock(&block);
	}
	
return err;
}

//===========================================================================================
Ptr	GetPolyPtr(BlockRef mapBlock, long polyID, PolyHeader **polyHeadPPtr)
{
PolyHeader		*polyHeadP;
long			id, thePos, max, min;
Ptr				foundPtr, polyPtr;
long			*offsetP;
long			totPoly;

	polyPtr = GetPtr(mapBlock);
	polyHeadP = *polyHeadPPtr = (PolyHeader*)polyPtr;
	offsetP = (long*)GetPtr(polyHeadP->offsets);
	foundPtr = nil;
	if (totPoly = polyHeadP->totPoly)
	{	max = totPoly;
		min = 1;
		while (max >= min)
		{	thePos = (max + min) >> 1;			
			polyPtr = ((Ptr)polyHeadP) + offsetP[thePos-1];
			id = *(long*)polyPtr;
			if (id < polyID)			// itemP->name < name
				min = thePos + 1;
			else if (id > polyID)		// itemP->name > name
				max = thePos - 1;
			else 						// res == 0
			{	max = thePos;
				foundPtr = polyPtr;
				break;
			}
		}
	}
	
return foundPtr;
}

//===========================================================================================
// top left bottom right
Boolean PolyInRect(double x_offset, double y_offset, long frame_widht, long frame_height, double zoom, double *enclosingP)
{
double		left, top, right, bottom;

	top = frame_height - (y_offset + Zoom(zoom, *enclosingP++));
	left = x_offset + Zoom(zoom, *enclosingP++);
	bottom = frame_height - (y_offset + Zoom(zoom, *enclosingP++));
	right = x_offset + Zoom(zoom, *enclosingP++);
	if ((top < frame_height) && (bottom > 0) && (left < frame_widht) && (right > 0))
		return true;
	else
		return false;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static int _InsidePolygon(Point *polygon, int N, double x, double y)
{
int		counter = 0;
int		i;
double	xinters;
Point	p1, p2;
Point	p = {x, y};

	p1 = polygon[0];
	for (i = 1;i <= N;i++)
	{	p2 = polygon[i % N];
		if (p.y > IP_MIN(p1.y,p2.y))
		{	if (p.y <= IP_MAX(p1.y,p2.y))
			{	if (p.x <= IP_MAX(p1.x,p2.x))
				{	if (p1.y != p2.y)
					{	xinters = (p.y-p1.y)*(p2.x-p1.x)/(p2.y-p1.y)+p1.x;
	       				if (p1.x == p2.x || p.x <= xinters)
	          				counter++;
					}
				}
			}
		}
	p1 = p2;
	}

if (counter % 2 == 0)
	return(OUTSIDE);
else
	return(INSIDE);
}

//===========================================================================================
static XErr	_FindClick(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr		err = noErr;
BlockRef	polyBlock;
Ptr			polyPtr;
long		objLen, id;
long		totPoints, totPoly;
double		x, y;
PolyHeader	*polHeadP;
ObjRef		tObjRef;

	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[0].objRef, &x, &y))
		return err;
	objLen = sizeof(BlockRef);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&polyBlock, &objLen, 0, nil))
	{	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &exeMethodRecP->resultObjRef))
		{	polyPtr = GetPtr(polyBlock);
			polHeadP = (PolyHeader*)polyPtr;
			totPoly = polHeadP->totPoly;		
			polyPtr += POLY_FIRSTPOLY_OFFSET;
			if (totPoly > 0)
			{	do
				{	id = *(long*)polyPtr;
					polyPtr += sizeof(long);					// skip polyID
					totPoints = *(long*)polyPtr;				// get totPoints
					polyPtr += sizeof(long);
					polyPtr += SIZE_OF_ENCLOSING;				// skip enclosing rect
					if ((totPoints > 2) && (_InsidePolygon((Point*)polyPtr, totPoints, x, y) == INSIDE))
					{	BAPI_InvalObjRef(api_data, &tObjRef);
						if NOT(err = BAPI_IntToObj(api_data, id, &tObjRef))
							err = BAPI_ArrayAddElement(api_data, &exeMethodRecP->resultObjRef, nil, &tObjRef);
					}
					polyPtr += sizeof(double) * 2 * totPoints;
				} while (--totPoly);
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_Image2Map(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr		err = noErr;
double		oldZoom, oldCenterX, oldCenterY, x, y;
Ptr			polyPtr;
double		x_offset, y_offset;
Boolean		noTransX, noTransY;
long		frame_height;
long		objLen;
BlockRef	polyBlock;

	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[0].objRef, &oldZoom, kImplicitTypeCast))
		return err;
	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[1].objRef, &oldCenterX, &oldCenterY))
		return err;
	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[2].objRef, &x, &y))
		return err;
	objLen = sizeof(BlockRef);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&polyBlock, &objLen, 0, nil))
	{	polyPtr = GetPtr(polyBlock);
		noTransX = (x < 0);
		noTransY = (y < 0);
		GetInfos(&polyPtr, &oldCenterX, &oldCenterY, oldZoom, nil, nil, &frame_height, &x_offset, &y_offset);
		if (noTransX)
			x = oldCenterX;
		else
		{	if (oldZoom > 0)
				x = (x - x_offset) / oldZoom;
			else
				x = (x - x_offset) * (-oldZoom);
		}
		if (noTransY)
			y = oldCenterY;
		else
		{	if (oldZoom > 0)
				y = (frame_height - y - y_offset) / oldZoom;
			else
				y = (frame_height - y - y_offset) * (-oldZoom);
		}
		err = Coords2Point(api_data, x, y, &exeMethodRecP->paramVarsP[2].objRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_GetPolyCenter(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			objLen, polyID;
BlockRef		polyBlock;
PolyHeader		*polHeadP;
double			*enclosingP;
double			top, left, bottom, right;

	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &polyID, kImplicitTypeCast))
		return err;
	objLen = sizeof(BlockRef);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&polyBlock, &objLen, 0, nil))
	{	if (enclosingP = (double*)GetPolyPtr(polyBlock, polyID, &polHeadP))
		{	enclosingP = (double*)(((Ptr)enclosingP) + sizeof(long) + sizeof(long));	// skip poliID and totpoints
			top = *enclosingP++;
			left = *enclosingP++;
			bottom = *enclosingP++;
			right = *enclosingP++;
			Coords2Point(api_data, left + ((right - left) / 2), top - ((top - bottom) / 2), &exeMethodRecP->resultObjRef);
		}
		else
			Coords2Point(api_data, 0, 0, &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_IsPolyInRect(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			objLen, polyID;
BlockRef		polyBlock;
Boolean			res;
double 			x_offset, y_offset, zoom, centerX, centerY;
Ptr				polyPtr;
PolyHeader		*polyHeadP;

	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &polyID, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[1].objRef, &zoom, kImplicitTypeCast))
		return err;
	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[2].objRef, &centerX, &centerY))
		return err;
	objLen = sizeof(BlockRef);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&polyBlock, &objLen, 0, nil))
	{	polyPtr = GetPtr(polyBlock);
		polyHeadP = (PolyHeader*)polyPtr;
		GetInfos(&polyPtr, &centerX, &centerY, zoom, nil, nil, nil, &x_offset, &y_offset);
		if (polyPtr = GetPolyPtr(polyBlock, polyID, &polyHeadP))
		{	polyPtr += sizeof(long) + sizeof(long);					// skip polyID and totPoints
			res = PolyInRect(x_offset, y_offset, polyHeadP->frame_width, polyHeadP->frame_height, zoom, (double*)polyPtr);
		}
		else
			res = false;
		if NOT(err)
			err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_GetMapSize(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
Ptr			polyPtr;
double		min_x, min_y, max_x, max_y, width, height;
XErr		err = noErr;
long		objLen;
BlockRef	polyBlock;

	objLen = sizeof(BlockRef);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&polyBlock, &objLen, 0, nil))
	{	polyPtr = GetPtr(polyBlock);
		polyPtr += POLY_MINMAX_OFFSET;
		min_x = *(double*)polyPtr;
		polyPtr += sizeof(double);
		min_y = *(double*)polyPtr;
		polyPtr += sizeof(double);
		max_x = *(double*)polyPtr;
		polyPtr += sizeof(double);
		max_y = *(double*)polyPtr;
		polyPtr += sizeof(double);
		width = max_x - min_x;
		if (width < 0)
			width = -width;
		height = max_y - min_y;
		if (height < 0)
			height = -height;
		if NOT(err = BAPI_DoubleToObj(api_data, width, &exeMethodRecP->paramVarsP[0].objRef))
			err = BAPI_DoubleToObj(api_data, height, &exeMethodRecP->paramVarsP[1].objRef);
	}

return err;
}

//===========================================================================================
/*
##	polyID
**	value q
*/
static XErr	_SubstituteForShapeElements(Ptr textP, long textLen, long polyID, double q, Byte decimSep, char *finalAttrString)
{
XErr		err = noErr;
short		aShort;
char		*writeP = finalAttrString;
CStr31		tempStr;
int			ch, totWritten;
char		*sourceP;

	if NOT(textLen)
	{	*finalAttrString = 0;
		return noErr;
	}
	totWritten = 0;
	while (textLen > 0)
	{	if (textLen > 1)
			aShort = *(short*)textP;
		else
			aShort = 0;
		if ((aShort == '##') || (aShort == '**'))
		{	textP += 2;
			textLen -= 2;
			switch(aShort)
			{	case '##':
					CNumToString(polyID, tempStr);
					sourceP = tempStr;
					do	{
						if NOT(ch = *sourceP++)
							break;
						if (totWritten++ >= 255)
							goto out;
						*writeP++ = ch;
						} while(1);
					break;
				case '**':
					CRealToStr(&q, tempStr, 5);
					CutRightZeroDec(tempStr, 5);
					CSubstitute(tempStr, '.', decimSep);
					/*if (cutRightZero && decimals)
						CutRightZeroDec(tempStr, decimals);
					if (wantThousSep)
					{	FormatNumber(tempStr, tempStr2, decimSep, thousSep);
						sourceP = tempStr2;
					}
					else*/
					sourceP = tempStr;
					do	{
						if NOT(ch = *sourceP++)
							break;
						if (totWritten++ >= 255)
							goto out;
						*writeP++ = ch;
						} while(1);
					break;
			}
		}
		else
		{	if (totWritten++ >= 255)
				goto out;
			*writeP++ = *textP++;
			textLen--;
		}
	}
out:
	*writeP = 0;
			
return err;
}

//===========================================================================================
/*
if shape="poly" then
coords="x1,y1,x2,y2,..,xn,yn"

<area shape ="poly" coords ="0,0,82,126" href ="sun.htm" target ="_blank" alt="Sun"/>
*/
static XErr	_GetAreaShapes(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			objLen;
long			frame_height;
CStr255			aCStr, attrStr, finalAttrString;
Ptr				polyPtr;
double			tOff, q, x_offset, y_offset, centerX, centerY;
ObjRef			mapQuery;
long			dist, polyID, i, totRec;
BlockRef		mapBlock, mapRef;
Ptr				dataP;
long			added, mapLen;
MapQueryHeader	*mpHeadP;
PolyHeader		*polyHeadP;
long			attrStrLen, savePoints, totPoints;
double			zoom;
double			x, y, x_old, y_old;
double			*buffPtr;
BufferID		buffID;
Ptr				resultPtr;
long			dist_threshold, resultSize;
Byte			decimSep;

	objLen = sizeof(BlockRef);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&mapBlock, &objLen, 0, nil))
		return err;
	polyPtr = GetPtr(mapBlock);
	polyHeadP = (PolyHeader*)polyPtr;
	// Map query object
	if (err = BAPI_GetReferenceTarget(api_data, &exeMethodRecP->paramVarsP[0].objRef, &mapQuery))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[1].objRef, &zoom, kImplicitTypeCast))
		return err;
	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[2].objRef, &centerX, &centerY))
		return err;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[3].objRef, attrStr, &attrStrLen, 255, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[4].objRef, &dist_threshold, kImplicitTypeCast))
		return err;
	if NOT(dist_threshold)
		dist_threshold = 2;
	/*if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[4].objRef, &decimals, kImplicitTypeCast))
		return err;
	if (decimals < 0)
		decimals = 0;
	if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[5].objRef, &cutRightZero, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[6].objRef, &wantThousSep, kImplicitTypeCast))
		return err;
	*/
	if (err = BAPI_GetNumberFormat(api_data, nil, &decimSep))
		return err;
	if NOT(decimSep)
		decimSep = '.';
	GetInfos(&polyPtr, &centerX, &centerY, zoom, nil, nil, &frame_height, &x_offset, &y_offset);
	if NOT(err = BAPI_GetObjBlock(api_data, &mapQuery, aCStr, &dataP, &mapLen, &mapRef))
	{	mpHeadP = (MapQueryHeader*)dataP;
		totRec = mpHeadP->totRec;
		dataP += sizeof(MapQueryHeader);
		if (buffID = BufferCreate(256, &err))
		{	for (i = 1; (i <= totRec); i++)
			{	polyID = *(long*)dataP;
				dataP += sizeof(long);
				q = *(double*)dataP;
				dataP += sizeof(double);	// skip value
				if (polyPtr = GetPolyPtr(mapBlock, polyID, &polyHeadP))
				{	polyPtr += sizeof(long);					// skip polyID
					totPoints = savePoints = *(long*)polyPtr;				// get totPoints
					polyPtr += sizeof(long);					// skip totPoints
					if (PolyInRect(x_offset, y_offset, polyHeadP->frame_width, polyHeadP->frame_height, zoom, (double*)polyPtr))
					{	polyPtr += SIZE_OF_ENCLOSING;				// skip enclosing rect
						buffPtr = (double*)polyPtr;
						added = 0;
						if (--totPoints)
						{	if (err = BufferAddCString(buffID, "\r\n<area shape=\"poly\" coords=\"", NO_ENC, 0))
								break;
							x_old = -1000000;
							y_old = -1000000;
							do
							{
								x = x_offset + Zoom(zoom, *buffPtr);
								if (x < 0)
									x = 0;
								buffPtr++;
								tOff = (y_offset + Zoom(zoom, *buffPtr));
								if (tOff < 0)
									y = frame_height;
								else
									y = frame_height - tOff;
								buffPtr++;
								// optimization
								dist = (long)sqrt((x - x_old)*(x - x_old) + (y - y_old)*(y - y_old));
								if (dist >= dist_threshold)
								{	CNumToString((long)x, aCStr);
									if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
										goto out;
									if (err = BufferAddChar(buffID, ','))
										goto out;
									CNumToString((long)y, aCStr);
									if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
										goto out;
									if (err = BufferAddChar(buffID, ','))
										goto out;
									added++;
									x_old = x;
									y_old = y;
								}
							} while (--totPoints);
							// last (put here to avoid last ',')
							x = x_offset + Zoom(zoom, *buffPtr);
							if (x < 0)
								x = 0;
							buffPtr++;
							tOff = (y_offset + Zoom(zoom, *buffPtr));
							if (tOff < 0)
								y = frame_height;
							else
								y = frame_height - tOff;
							buffPtr++;
							CNumToString((long)x, aCStr);
							if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
								break;
							if (err = BufferAddChar(buffID, ','))
								break;
							CNumToString((long)y, aCStr);
							if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
								break;						
							if (err = BufferAddCString(buffID, "\" ", NO_ENC, 0))
								break;
							added++;
							if (attrStrLen)
							{	if (err = _SubstituteForShapeElements(attrStr, attrStrLen, polyID, q, decimSep, finalAttrString))
									break;
								if (err = BufferAddCString(buffID, finalAttrString, NO_ENC, 0))
									break;
							}
							if (err = BufferAddChar(buffID, '>'))
								break;
							// printf("--> %d/%d\n", added, savePoints);
						}
					}
				}
			}
		out:
			if NOT(err)
			{	BufferGetBlockRefExtSize(buffID, &resultSize, &resultPtr);
				err = BAPI_StringToObj(api_data, resultPtr, resultSize, &exeMethodRecP->resultObjRef);
			}
			BufferFree(buffID);
		}
		BAPI_ReleaseBlock(&mapRef);
	}
	
return err;
}


#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Map_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;
long	api_data = pbPtr->api_data;
BAPI_MemberRecord	mapMethods[TOT_METHODES] = 
					{	"GetMapSize",		kGetMapSize,	"void GetMapSize(double *width, double *height)",
						"Image2Map",		kImage2Map,		"void Image2Map(double oldZoom, point oldCenter, point *p)",
						"FindClick", 		kFindClick,		"array FindClick(point p)",
						"GetPolyCenter",	kGetPolyCenter,	"point GetPolyCenter(int polyID)",
						"GetAreaShapes",	kGetAreaShapes,	"string	GetAreaShapes(mapquery *mq, double zoom, point center, string attributes, int threshold)",
						"IsPolyInRect",		kIsPolyInRect,	"boolean IsPolyInRect(int polyID, double zoom, point center)"						
					};

	gsStringClassID = BAPI_ClassIDFromName(pbPtr->api_data, "string", false);
	if (err = BAPI_NewMethods(api_data, gsMapClassID, mapMethods, TOT_METHODES, nil))
		return err;
	err = BAPI_RegisterErrors(api_data, gsMapClassID, START_ERR, gMapErrorsStr, TOT_ERRORS);

return err;
}

//===========================================================================================
static XErr Map_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
ParameterRec	*paramVarsP = constructorRecP->varRecsP;
CStr255			polyPath;
long			api_data = pbPtr->api_data, width, height, border;
BlockRef 		polyBlock;
long			polyBlockLen;
long			lineError;
Ptr				polyP;

	if (message == kClone)
	{
		// da fare
	}
	else
	{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[0].objRef, polyPath, nil, 256, kImplicitTypeCast))
		{	if NOT(err = BAPI_RealPath(api_data, polyPath, true))
			{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &width, kImplicitTypeCast))
				{	if (width < 0)
						err = XError(kBAPI_ClassError, ErrInvalidMapWidth);
					else
					{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[2].objRef, &height, kImplicitTypeCast))
						{	if (height < 0)
								err = XError(kBAPI_ClassError, ErrInvalidMapHeight);
							else
							{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[3].objRef, &border, kImplicitTypeCast))
								{	if (border < 0)
										err = XError(kBAPI_ClassError, ErrInvalidBorder);
									else
									{	if NOT(err = LoadPoly(polyPath, &polyBlock, &polyBlockLen, &lineError))
										{	polyP = GetPtr(polyBlock);
											if (err = Normalize(polyP, width, height, border))
												DisposeBlock(&polyBlock);
											else
											{	((PolyHeader*)polyP)->refCount = 1;
												err = BAPI_BufferToObj(api_data, &polyBlock, sizeof(BlockRef), gsMapClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
											}
										}
										else if (lineError)
											sprintf(pbPtr->error, "At line: %d", lineError);
									}
								}
							}
						}
					}
				}
			}
		}
	}	

return err;
}

//===========================================================================================
static XErr	Map_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
long			objLen;
BlockRef		block;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(BlockRef);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&block, &objLen, 0, nil))
		{	if (objLen)
				DecrementMapRefCount(block);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	Map_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
Boolean				needSer;

	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
		err = BAPI_NeedSerialize(api_data, &exeMethodRecP->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		switch(exeMethodRecP->methodID)
		{
			case kGetMapSize:
				err = _GetMapSize(exeMethodRecP, api_data, pbPtr->error);
				break;
				
			case kImage2Map:
				err = _Image2Map(exeMethodRecP, api_data, pbPtr->error);
				break;

			case kFindClick:
				err = _FindClick(exeMethodRecP, api_data, pbPtr->error);
				break;

			case kGetPolyCenter:
				err = _GetPolyCenter(exeMethodRecP, api_data, pbPtr->error);
				break;
			
			case kGetAreaShapes:
				err = _GetAreaShapes(exeMethodRecP, api_data, pbPtr->error);
				break;

			case kIsPolyInRect:
				err = _IsPolyInRect(exeMethodRecP, api_data, pbPtr->error);
				break;

			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
	#pragma export on
#endif
//===========================================================================================
XErr	map_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "map");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft map class");
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			gsMapClassID = pbPtr->param.registerRec.pluginID;
			CEquStr(pbPtr->param.registerRec.constructor, "void map(string polyPath, int width, int height, int border)");
			pbPtr->param.registerRec.fixedSize = true;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.nextBAPI_Dispatch = (long)point_Biferno_Dispatch;
			break;
		case kInit:
			err = Map_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Map_Constructor(pbPtr, message);
			break;
		case kDestructor:
			err = Map_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Map_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			// da fare
			break;

		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
	#pragma export off
#endif

//#endif
