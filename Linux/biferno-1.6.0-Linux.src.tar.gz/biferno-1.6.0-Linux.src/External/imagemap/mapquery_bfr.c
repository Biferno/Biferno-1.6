/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: mapquery_bfr.c,v 1.4 2005-10-04 13:15:58 valfer Exp $
	|______________________________________________________________________________
*/

#include 	"XLib.h"
#include 	"BifernoAPI.h"
#include 	"BDBAPI.h"
#include 	"BfrVersion.h"
#include 	"mapquery_bfr.h"

#if __UNIX_XLIB__
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <errno.h>
	#include <math.h>
	#include <time.h>
#endif

static long			gsMapQueryClassID;
static BDBAPI_Rec	bdbRec;

//===========================================================================================
static XErr	_InitCallBacks(long api_data, BDBAPI_Rec *theRecP)
{
XErr					err = noErr;
BDBAPI_Init_CallBack	BDBAPI_Init_EP;

	if NOT(err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, "db", false), "BDBAPI_Init", (long*)&BDBAPI_Init_EP))
		err = BDBAPI_Init_EP(&bdbRec);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*
STRUCT:
long	id
double	value
long	id
double	value
...
*/
static XErr Mapquery_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr						err = noErr;
ConstructorRec				*constructorRecP = &pbPtr->param.constructorRec;
ParameterRec				*paramVarsP = constructorRecP->varRecsP;
ObjRef						totRecObjRef, dbTarget, cursorObjRef;
CStr63						errType, driver;
ParameterRec 				paramVars;
long						tSize, i, totRec, api_data = pbPtr->api_data;
long						polyID, cursorAddress;
BDBAPI_MapFetch_CallBack	MapFetch;
double						q, min, max;
Boolean						isNull;
BlockRef					block;
Ptr							saveP, dataP;
MapQueryHeader				*mpHeadP;

	if (message == kClone)
	{	CEquStr(pbPtr->error, "mapquery objects cannot be copied and can be passed to functions only by reference");
		err = XError(kBAPI_Error, Err_IllegalOperation);
	}
	else
	{	if (err = BAPI_GetReferenceTarget(api_data, &paramVarsP[0].objRef, &dbTarget))
			goto out;
		cursorAddress = 0;
		*paramVars.name = 0;
		paramVars.objRef = paramVarsP[1].objRef;
		if (err = BAPI_ExecuteMethod(api_data, &dbTarget, &paramVars, 1, "Exec", &cursorObjRef, nil))
			goto out;
		if (err = BAPI_ObjToInt(api_data, &paramVarsP[2].objRef, &totRec, kImplicitTypeCast))
			goto out;
		if (totRec <= 0)
		{	*paramVars.name = 0;
			paramVars.objRef = cursorObjRef;
			if (err = BAPI_ExecuteMethod(api_data, &dbTarget, &paramVars, 1, "GetCurRecs", &totRecObjRef, nil))
				goto out;
			if (err = BAPI_ObjToInt(api_data, &totRecObjRef, &totRec, kImplicitTypeCast))
				goto out;
		}
		if NOT(totRec)
		{	err = XError(kBAPI_Error, Err_ClassError);
			CEquStr(pbPtr->error, "Empty record set");
			goto out;
		}
		if (err = bdbRec.BDBAPI_NativeCursor(api_data, &dbTarget, driver, &cursorAddress))
			goto out;
		if (err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, driver, true), "MapFetch", (long*)&MapFetch))
			goto out;
		tSize = sizeof(MapQueryHeader) + ((sizeof(long) + sizeof(double)) * totRec);
		if (block = NewBlock(tSize, &err, &dataP))
		{	saveP = dataP;
			mpHeadP = (MapQueryHeader*)dataP;
			mpHeadP->totRec = totRec;
			dataP += sizeof(MapQueryHeader);
			// first cycle, to initialize min and max
			if NOT(err = MapFetch(cursorAddress, &polyID, &q, &isNull))
			{	min = q;
				max = q;
				*(long*)dataP = polyID;
				dataP += sizeof(long);
				*(double*)dataP = q;
				dataP += sizeof(double);
				for (i = 2; i <= totRec; i++)
				{	if NOT(err = MapFetch(cursorAddress, &polyID, &q, &isNull))
					{	*(long*)dataP = polyID;
						dataP += sizeof(long);
						*(double*)dataP = q;
						dataP += sizeof(double);
						if (q > max)
							q = max;
						if (q < min)
							q = min;
					}
					else
						break;
				}
				if NOT(err)
				{	mpHeadP->min = min;
					mpHeadP->max = max;
					err = BAPI_BufferToObj(api_data, saveP, tSize, gsMapQueryClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
				}			
			}
			DisposeBlock(&block);
		}
	}

out:
if (err)
{	BAPI_GetErrDescription(api_data, err, pbPtr->error, nil, errType, nil, nil, BAPI_ClassIDFromName(api_data, "db", false), nil);
	if (CCompareStrings(errType, "BIFERNO ERROR"))
		err = XError(kBAPI_Error, Err_ClassError);
}
if (cursorAddress)
{
XErr	err2;

	*paramVars.name = 0;
	paramVars.objRef = cursorObjRef;
	err2 = BAPI_ExecuteMethod(api_data, &dbTarget, &paramVars, 1, "Free", nil, nil);
	if (err2 && NOT(err))
		err = err2;
}			
return err;
}

//===========================================================================================
static XErr	Mapquery_Primitive(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
long			tLen, strLen;
char			*strP, *p;
CStr255			aCStr;
PrimitiveUnion	*param_d;
MapQueryHeader	mpHead;

	if (typeCast->resultWanted == kCString)
	{	tLen = sizeof(MapQueryHeader);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&mpHead, &tLen, 0, nil))
		{	param_d = &typeCast->result;
			sprintf(aCStr, "query object of %d records", mpHead.totRec);
			if NOT(err)
			{	strP = aCStr;
				strLen = CLen(strP);
				p = param_d->text.stringP;
				if (p)
				{	if (param_d->text.stringMaxStorage >= (strLen+1))
					{	CopyBlock(p, strP, strLen);
						p[strLen] = 0;
						param_d->text.stringLen = strLen;
					}
					else
					{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = strLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = strLen;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
	#pragma export on
#endif
//===========================================================================================
XErr	mapquery_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
unsigned long	versionBAPI;

	switch(message)
	{
		case kRegister:
			BAPI_GetNumVersions(pbPtr->api_data, nil, &versionBAPI, nil);
			if (versionBAPI < 0x00010004)
			{	err = XError(kBAPI_Error, Err_BAPI_ExtensionTooNew);
				CEquStr(pbPtr->error, "BAPI >= 1.0.4 needed (Biferno >= 1.2)");
			}
			else
			{	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
				CEquStr(pbPtr->param.registerRec.pluginName, "mapquery");
				CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft mapquery class");
				VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
				if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
					CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
				gsMapQueryClassID = pbPtr->param.registerRec.pluginID;
				CEquStr(pbPtr->param.registerRec.constructor, "void mapquery(db *connection, string sqlSelect, int numRecs)");
				pbPtr->param.registerRec.fixedSize = true;
				pbPtr->param.registerRec.wantDestructor = false;
				pbPtr->param.registerRec.nextBAPI_Dispatch = nil;	// finished
			}
			break;
		case kInit:
			err = _InitCallBacks(pbPtr->api_data, &bdbRec);
			break;
		case kShutDown:
			break;
		case kRun:
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Mapquery_Constructor(pbPtr, message);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = Mapquery_Primitive(pbPtr);
			break;

		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
	#pragma export off
#endif

//#endif
