/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: point_bfr.c,v 1.4 2005-05-13 14:46:28 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"

#include 	"point_bfr.h"
#include 	"mapquery_bfr.h"

static long	gsPointClassID;

// Properties
enum{
		kX_Prop = 1,
		kY_Prop
	} Point_Property;

#define TOT_POINT_PROPERTIES	2

//===========================================================================================
XErr Point2Coords(long api_data, ObjRef *objrefP, double *xP, double *yP)
{
XErr		err = noErr;
long		objLen;
BfrPoint	pointRec;
ObjRef		target;

	if NOT(err = BAPI_GetReferenceTarget(api_data, objrefP, &target))
	{	if (BAPI_GetObjClassID(api_data, &target) == gsPointClassID)
		{	objLen = sizeof(BfrPoint);
			if (err = BAPI_GetObj(api_data, &target, (Ptr)&pointRec, &objLen, 0, nil))
				return err;
			*xP = pointRec.x;
			*yP = pointRec.y;
		}
		else
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
	}
	
return err;
}

//===========================================================================================
XErr Coords2Point(long api_data, double x, double y, ObjRef *objrefP)
{
XErr		err = noErr;
BfrPoint	pointRec;

	pointRec.x = x;
	pointRec.y = y;
	err = BAPI_BufferToObj(api_data, (Ptr)&pointRec, sizeof(BfrPoint), gsPointClassID, true, nil, objrefP);

return err;
}

//===========================================================================================
static XErr Point_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BAPI_MemberRecord	pointProperty[TOT_POINT_PROPERTIES] = 
					{	"x", 			kX_Prop,	"double",
						"y", 			kY_Prop,	"double"
					};

	if (err = BAPI_NewProperties(pbPtr->api_data, gsPointClassID, pointProperty, TOT_POINT_PROPERTIES, nil))
		return err;		


return err;
}

//===========================================================================================
static XErr Point_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
ParameterRec	*paramVarsP = constructorRecP->varRecsP;
long			objLen, api_data = pbPtr->api_data;
BfrPoint		pointRec;

	if (message == kClone)
	{	objLen = sizeof(BfrPoint);
		if NOT(err = BAPI_GetObj(api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&pointRec, &objLen, 0, nil))
			err = BAPI_BufferToObj(api_data, (Ptr)&pointRec, sizeof(BfrPoint), gsPointClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
	}
	else
	{	if (err = BAPI_ObjToDouble(api_data, &paramVarsP[0].objRef, &pointRec.x, kImplicitTypeCast))
			return err;
		if (err = BAPI_ObjToDouble(api_data, &paramVarsP[1].objRef, &pointRec.y, kImplicitTypeCast))
			return err;
		err = BAPI_BufferToObj(api_data, (Ptr)&pointRec, sizeof(BfrPoint), gsPointClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
	}

return err;
}


//===========================================================================================
static XErr	Point_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
BfrPoint		pointRec;
long			tLen, api_data = pbPtr->api_data;

	tLen = sizeof(BfrPoint);
	if NOT(err = BAPI_ReadObj(api_data, &getPropertyRec->objRef, (Ptr)&pointRec, &tLen, 0, nil))
	{	switch(getPropertyRec->propertyID)
		{
			case kX_Prop:
				err = BAPI_DoubleToObj(api_data, pointRec.x, &getPropertyRec->resultObjRef);
				break;
			case kY_Prop:
				err = BAPI_DoubleToObj(api_data, pointRec.y, &getPropertyRec->resultObjRef);
				break;

			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Point_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
SetPropertyRec		*setPropertyRec = &pbPtr->param.setPropertyRec;
long				tLen, api_data = pbPtr->api_data;
BfrPoint			pointRec;

	tLen = sizeof(BfrPoint);
	if NOT(err = BAPI_ReadObj(api_data, &setPropertyRec->objRef, (Ptr)&pointRec, &tLen, 0, nil))
	{	switch(setPropertyRec->propertyID)
		{
			case kX_Prop:
				if NOT(err = BAPI_ObjToDouble(api_data, &setPropertyRec->value, &pointRec.x, kExplicitTypeCast))
					err = BAPI_WriteObj(api_data, &setPropertyRec->objRef, (Ptr)&pointRec, sizeof(BfrPoint), 1);
				break;
			case kY_Prop:
				if NOT(err = BAPI_ObjToDouble(api_data, &setPropertyRec->value, &pointRec.y, kExplicitTypeCast))
					err = BAPI_WriteObj(api_data, &setPropertyRec->objRef, (Ptr)&pointRec, sizeof(BfrPoint), 1);
				break;
			
			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}
		
return err;
}

//===========================================================================================
static XErr	Point_Primitive(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
long			aLong;
CStr255			aCStr;
long			cLen;
Ptr				p;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
PrimitiveUnion	*param_d;
long			tLen, api_data = pbPtr->api_data;
BfrPoint		pointRec;

	tLen = sizeof(BfrPoint);
	if NOT(err = BAPI_GetObj(api_data, &typeCast->objRef, (Ptr)&pointRec, &tLen, 0, nil))
	{	if (tLen)
		{	aLong = 0;
			param_d = &typeCast->result;
			switch(typeCast->resultWanted)
			{	case kInt:
				case kLong:
				case kUnsigned:
				case kDouble:
				case kBool:
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
					break;
				case kCString:
					sprintf(aCStr, "%f,%f", pointRec.x, pointRec.y);
					cLen = CLen(aCStr);
					if (p = param_d->text.stringP)
					{	if (param_d->text.stringMaxStorage >= (cLen + 1))
						{	CopyBlock(p, aCStr, cLen);
							p[cLen] = 0;
							param_d->text.stringLen = cLen;
						}
						else
						{	CopyBlock(p, aCStr, param_d->text.stringMaxStorage - 1);
							p[param_d->text.stringMaxStorage - 1] = 0;
							param_d->text.stringLen = cLen;
							err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
						}
					}
					else
						param_d->text.stringLen = cLen;
					break;
				case kChar:
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
					break;
				default:
					CDebugStr("Unknown TypeCast Parameter");
					break;
			}
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
	#pragma export on
#endif
//===========================================================================================
XErr	point_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "point");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft point class");
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			gsPointClassID = pbPtr->param.registerRec.pluginID;
			CEquStr(pbPtr->param.registerRec.constructor, "void point(double x, double y)");
			pbPtr->param.registerRec.fixedSize = true;
			pbPtr->param.registerRec.nextBAPI_Dispatch = (long)mapquery_Biferno_Dispatch;
			break;
		case kInit:
			err = Point_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Point_Constructor(pbPtr, message);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Point_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Point_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = Point_Primitive( pbPtr);
			break;

		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
	#pragma export off
#endif

//#endif
