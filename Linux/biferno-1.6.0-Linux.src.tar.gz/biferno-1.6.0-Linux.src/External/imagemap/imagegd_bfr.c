/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: imagegd_bfr.c,v 1.12 2005-10-04 13:15:45 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"
#include 	"map_bfr.h"
#include 	"mapquery_bfr.h"
#include 	"point_bfr.h"

#include 	"gd.h"

#if __UNIX_XLIB__
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <errno.h>
	#include <math.h>
	#include <time.h>
#elif __WIN_XLIB__
	#include <math.h>
#endif

#define	MAX_MAPS	12
typedef struct
{
	BlockRef		mapBlock;
	Boolean			busy;
	Boolean			needSerialize;
	short			pad2;
	double			zoom;
	double			center_x;
	double			center_y;
	double			x_offset;
	double			y_offset;
} MapRec;

typedef struct
{
	gdImagePtr		im;
	int				curColor;
	long			width;
	long			height;
	long			totMaps;
	//long			threshold;
	CStr255			filePath;
	MapRec			mapRec[MAX_MAPS];
} BfrImageRec;

typedef struct
{
	double		step;
	int			colR;
	int			colG;
	int			colB;
} ColoredStep;

// Methods
enum{
		kDrawMap = 1,
		kGetBlob,
		kFrameMapPoly,
		kFillMapPoly,
		kTileMapPoly,
		kAttachMap,
		kFrameRect,
		kDrawLine,
		kDrawColored,
		kSetThickness,
		kLoadFromFile,
		kColorTransparent
	};
#define TOT_METHODES	12

// Methods
enum{
		kWidth = 1,
		kHeight,
		kPath
	};
#define TOT_PROPERTIES	3

// Errors
#define	START_ERR	100
enum {
		ErrInvalidImageWidth = START_ERR,
		ErrInvalidImageHeight,
		ErrGdImageCreateFailed,
		ErrWhileDrawing,
		ErrTooManyMaps,
		ErrInvalidMapID,
		ErrUnknownFormat,
		ErrEmptyStepArray,
		ErrCantOpenFile,
		ErrLoadFailed,
		ErrBadGradient
};
#define	TOT_IMAGE_ERRORS	11
CStr63	gImageErrorsStr[] = 
	{	
		"ErrInvalidImageWidth",
		"ErrInvalidImageHeight",
		"ErrGdImageCreateFailed",
		"ErrWhileDrawing",
		"ErrTooManyMaps",
		"ErrInvalidMapID",
		"ErrUnknownFormat",
		"ErrEmptyStepArray",
		"ErrCantOpenFile",
		"ErrLoadFailed",
		"ErrBadGradient"
		};

static long		gsImageClassID, gsStringClassID;

//===========================================================================================
static void _GetComponentsFromString(char *colorStr, int *r, int *g, int *b)
{
char	*strP = colorStr;
CStr15	hexStr;

	*r = *g = *b = 0;
	if (CLen(colorStr) == 6)
	{	*hexStr = 2;
		hexStr[1] = *strP++;
		hexStr[2] = *strP++;
		*r = HexStringToNum((Byte*)hexStr, nil);

		*hexStr = 2;
		hexStr[1] = *strP++;
		hexStr[2] = *strP++;
		*g = HexStringToNum((Byte*)hexStr, nil);

		*hexStr = 2;
		hexStr[1] = *strP++;
		hexStr[2] = *strP++;
		*b = HexStringToNum((Byte*)hexStr, nil);
	}
}

//===========================================================================================
static int _GetColorFromString(gdImagePtr im, char *colorStr)
{
int		r = 0, g = 0, b = 0;
char	*strP = colorStr;
CStr15	hexStr;

	if (CLen(colorStr) == 6)
	{	*hexStr = 2;
		hexStr[1] = *strP++;
		hexStr[2] = *strP++;
		r = HexStringToNum((Byte*)hexStr, nil);

		*hexStr = 2;
		hexStr[1] = *strP++;
		hexStr[2] = *strP++;
		g = HexStringToNum((Byte*)hexStr, nil);

		*hexStr = 2;
		hexStr[1] = *strP++;
		hexStr[2] = *strP++;
		b = HexStringToNum((Byte*)hexStr, nil);
	}
	
return gdImageColorAllocate(im, r, g, b);
}

//===========================================================================================
static XErr	_MyFillPolygon(BfrImageRec *imRecP, long totPoints, double *polyPtr, double x_offset, double y_offset, long frame_height, double zoom, int theColor, gdPoint *polygonsP, Boolean tiled)
{
gdPoint		*pInfoP, *saveP;
long		tLen, realPoints, dist, dist_threshold = 0;	//imRecP->threshold;;
XErr		err = noErr;
BlockRef	block;
double		x, y, oldx, oldy;

	if (totPoints > 2)
	{	if (polygonsP)
		{	pInfoP = polygonsP;
			block = 0;
		}
		else
		{	tLen = totPoints * sizeof(gdPoint);
			block = NewBlock(tLen, &err, (Ptr*)&pInfoP);
		}
		if NOT(err)
		{	saveP = pInfoP;
			oldx = -10000;
			oldy = -10000;
			realPoints = 0;
			do
			{	x = x_offset + Zoom(zoom, *polyPtr);
				polyPtr++;
				y = frame_height - (y_offset + Zoom(zoom, *polyPtr));
				polyPtr++;
				dist = (long)sqrt((x - oldx)*(x - oldx) + (y - oldy)*(y - oldy));
				if (dist >= dist_threshold)
				{	pInfoP->x = (int)x;
					pInfoP->y = (int)y;
					pInfoP++;
					oldx = x;
					oldy = y;
					realPoints++;
				}
			} while (--totPoints);
			if (tiled)
				gdImageFilledPolygon(imRecP->im, saveP, realPoints, gdTiled);
			else
				gdImageFilledPolygon(imRecP->im, saveP, realPoints, theColor);
			if (block)
				DisposeBlock(&block);
		}
	}

return err;
}

//===========================================================================================
static XErr	_MyFillPolygonWithFrame(BfrImageRec *imRecP, long totPoints, double *polyPtr, double x_offset, double y_offset, long frame_height, double zoom, int theColor, gdPoint *polygonsP, Boolean tiled)
{
gdPoint		*pInfoP, *saveP;
long		tLen, savePoints;
XErr		err = noErr;
BlockRef	block;
double		x, y, oldx, oldy, firstx, firsty;

	if (totPoints > 2)
	{	if (polygonsP)
		{	pInfoP = polygonsP;
			block = 0;
		}
		else
		{	tLen = totPoints * sizeof(gdPoint);
			block = NewBlock(tLen, &err, (Ptr*)&pInfoP);
		}
		if NOT(err)
		{	savePoints = totPoints;
			saveP = pInfoP;
			do
			{	pInfoP->x = (int)(x_offset + Zoom(zoom, *polyPtr));
				polyPtr++;
				pInfoP->y = (int)(frame_height - (y_offset + Zoom(zoom, *polyPtr)));
				polyPtr++;
				pInfoP++;
			} while (--totPoints);
			if (tiled)
				gdImageFilledPolygon(imRecP->im, saveP, savePoints, gdTiled);
			else
				gdImageFilledPolygon(imRecP->im, saveP, savePoints, theColor);
			// draw frame (after fill)
			totPoints = savePoints;
			pInfoP = saveP;
			firstx = oldx = pInfoP->x;
			firsty = oldy = pInfoP->y;
			pInfoP++;
			if (--totPoints)
			{	do
				{	x = pInfoP->x;
					y = pInfoP->y;
					gdImageLine(imRecP->im, (int)x, (int)y, (int)oldx, (int)oldy, imRecP->curColor);
					oldx = x;
					oldy = y;
					pInfoP++;
				} while (--totPoints);
				gdImageLine(imRecP->im, (int)x, (int)y, (int)firstx, (int)firsty, imRecP->curColor);
			}
			if (block)
				DisposeBlock(&block);
		}
	}

return err;
}

//===========================================================================================
static void	_ImageFrameRect(BfrImageRec *imRecP, double left, double top, double right, double bottom)
{
int	curCol = imRecP->curColor;

	gdImageLine(imRecP->im, (int)left, (int)top, (int)right, (int)top, curCol);
	gdImageLine(imRecP->im, (int)right, (int)top, (int)right, (int)bottom, curCol);
	gdImageLine(imRecP->im, (int)left, (int)bottom, (int)right, (int)bottom, curCol);
	gdImageLine(imRecP->im, (int)left, (int)bottom, (int)left, (int)top, curCol);
}

//===========================================================================================
static XErr	_GetMapRecP(BfrImageRec *imRecP, long mapID, MapRec	**mapRecPPtr)
{
XErr	err = noErr;
MapRec	*mapRecP = nil;

	if ((mapID > 0) && (mapID < MAX_MAPS))
	{	mapRecP = &imRecP->mapRec[--mapID];
		if NOT(mapRecP->busy)
			err = XError(kBAPI_ClassError, ErrInvalidMapID);
	}
	else
		err = XError(kBAPI_ClassError, ErrInvalidMapID);
	
*mapRecPPtr = mapRecP;	
return err;
}

//===========================================================================================
static void	_DrawPolylineFrame(BfrImageRec *imRecP, Ptr *buffPtrP, int totPoints, double x_offset, double y_offset, long frame_height, double zoom)
{
double		x, y, oldx, oldy, firstx, firsty;
double		*buffPtr = (double*)*buffPtrP;
long		totAdded, dist, dist_threshold = 0;	//imRecP->threshold;

	firstx = oldx = x_offset + Zoom(zoom, *buffPtr);
	buffPtr++;
	firsty = oldy = frame_height - (y_offset + Zoom(zoom, *buffPtr));
	buffPtr++;
	// printf("%f,%f _DrawPolylineFrame-----------------------------\n", firstx, firsty);
	totAdded = 1;
	//saveTotPoints = totPoints;
	if (--totPoints)
	{	do
		{	
			x = x_offset + Zoom(zoom, *buffPtr);
			buffPtr++;
			y = frame_height - (y_offset + Zoom(zoom, *buffPtr));
			buffPtr++;
			dist = (long)sqrt((x - oldx)*(x - oldx) + (y - oldy)*(y - oldy));
			if (dist >= dist_threshold)
			{	gdImageLine(imRecP->im, (int)x, (int)y, (int)oldx, (int)oldy, imRecP->curColor);
				// printf("%f, %f, %f, %f gdImageLine\n", x, y, oldx, oldy);
				totAdded++;
				oldx = x;
				oldy = y;
			}
		} while (--totPoints);
		gdImageLine(imRecP->im, (int)oldx, (int)oldy, (int)firstx, (int)firsty, imRecP->curColor);
		// printf("%f, %f, %f, %f gdImageLine\n", oldx, oldy, firstx, firsty);
		//printf("%d/%d\n", totAdded, saveTotPoints);
	}
	*buffPtrP = (Ptr)buffPtr;
}

//===========================================================================================
static XErr	_AttachMap(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			off, objLen, i;
BfrImageRec		imRec;
MapRec			*mapRecP, mapRec;
BlockRef		polyBlock;
Boolean			needSer;
double			center_x, center_y, zoom;
Ptr				polyPtr;

	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (imRec.totMaps < MAX_MAPS)
	{	objLen = sizeof(BlockRef);
		if (err = BAPI_GetObj(api_data, &exeMethodRecP->paramVarsP[0].objRef, (Ptr)&polyBlock, &objLen, 0, nil))
			return err;
		if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[1].objRef, &zoom, kImplicitTypeCast))
			return err;
		if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[2].objRef, &center_x, &center_y))
			return err;
		if (err = BAPI_NeedSerialize(api_data, &exeMethodRecP->paramVarsP[0].objRef, &needSer))
			return err;
		XThreadsEnterCriticalSection();
		mapRecP = &imRec.mapRec[0];
		for (i = 0; i < MAX_MAPS; i++, mapRecP++)
		{	if NOT(mapRecP->busy)
				break;
		}
		if (i == MAX_MAPS)
			err = XError(kBAPI_ClassError, ErrTooManyMaps);
		else
		{	ClearBlock(&mapRec, sizeof(MapRec));
			imRec.totMaps++;
			if NOT(err = BAPI_WriteObj(api_data, &exeMethodRecP->objRef, &imRec.totMaps, sizeof(long), offsetof(BfrImageRec, totMaps) + 1))
			{	mapRec.mapBlock = polyBlock;
				mapRec.zoom = zoom;
				mapRec.center_x = center_x;
				mapRec.center_y = center_y;
				mapRec.busy = true;
				mapRec.needSerialize = needSer;
				polyPtr = GetPtr(polyBlock);
				GetInfos(&polyPtr, &mapRec.center_x, &mapRec.center_y, mapRec.zoom, nil, nil, nil, &mapRec.x_offset, &mapRec.y_offset);
				off = offsetof(BfrImageRec, mapRec) + (i * sizeof(MapRec)) + 1;
				if NOT(err = BAPI_WriteObj(api_data, &exeMethodRecP->objRef, &mapRec, sizeof(MapRec), off))
				{	exeMethodRecP->sideEffect = true;
					IncrementMapRefCount(polyBlock);
					err = BAPI_IntToObj(api_data, i+1, &exeMethodRecP->resultObjRef);
				}
				else
				{	imRec.totMaps--;
					err = BAPI_WriteObj(api_data, &exeMethodRecP->objRef, &imRec.totMaps, sizeof(long), offsetof(BfrImageRec, totMaps));
				}
			}
		}
		XThreadsLeaveCriticalSection();
	}
	else
		err = XError(kBAPI_ClassError, ErrTooManyMaps);

return err;
}

//===========================================================================================
static void	_FillMapPoly_Low(MapRec	*mapRecP, BfrImageRec *imRecP, long polyID, int colorID, Boolean frame, Boolean fill, gdPoint *polygonsP, Boolean tiled)
{
PolyHeader		*polyHeadP;
Ptr				polyPtr;
long			totPoints;

	if (polyPtr = GetPolyPtr(mapRecP->mapBlock, polyID, &polyHeadP))
	{	polyPtr += sizeof(long);					// skip polyID
		totPoints = *(long*)polyPtr;				// get totPoints
		polyPtr += sizeof(long);					// skip totPoints
		if (PolyInRect(mapRecP->x_offset, mapRecP->y_offset, polyHeadP->frame_width, polyHeadP->frame_height, mapRecP->zoom, (double*)polyPtr))
		{	polyPtr += SIZE_OF_ENCLOSING;				// skip enclosing rect
			if (fill)
			{	if (frame)
					_MyFillPolygonWithFrame(imRecP, totPoints, (double*)polyPtr, mapRecP->x_offset, mapRecP->y_offset, polyHeadP->frame_height, mapRecP->zoom, colorID, polygonsP, tiled);
				else
					_MyFillPolygon(imRecP, totPoints, (double*)polyPtr, mapRecP->x_offset, mapRecP->y_offset, polyHeadP->frame_height, mapRecP->zoom, colorID, polygonsP, tiled);
			}
			else if (frame)
				_DrawPolylineFrame(imRecP, &polyPtr, totPoints, mapRecP->x_offset, mapRecP->y_offset, polyHeadP->frame_height, mapRecP->zoom);
		}
	}
}

//===========================================================================================
static XErr	_FillMapPoly(ExecuteMethodRec *exeMethodRecP, long api_data, char *error, long methodID)
{
XErr			err = noErr;
long			polyID, mapID, objLen;
BfrImageRec		imRec;
MapRec			*mapRecP;
CStr255			colorStr, tilePath;
int				colorID;
Boolean			fill, frame;
gdImagePtr 		tile;
FILE			*in;

	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &mapID, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &polyID, kImplicitTypeCast))
		return err;
	if (err = _GetMapRecP(&imRec, mapID, &mapRecP))
		return err;
	if (methodID == kTileMapPoly)
	{	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, tilePath, nil, 256, kImplicitTypeCast))
			return err;
		if (err = BAPI_RealPath(api_data, tilePath, true))
			return err;
		if NOT(in = fopen(tilePath, "rb"))
		{	CEquStr(error, "Can't open tile file");
			err = XError(kBAPI_Error, Err_ClassError);
		}
		if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[3].objRef, &frame, kImplicitTypeCast))
			return err;
		tile = gdImageCreateFromJpeg(in);
		gdImageSetTile(imRec.im, tile);
		_FillMapPoly_Low(mapRecP, &imRec, polyID, /*colorID*/0, frame, true, nil, true);
		gdImageDestroy(tile);
		fclose(in);
	}
	else
	{	if (fill = (methodID == kFillMapPoly))
		{	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, colorStr, nil, 256, kImplicitTypeCast))
				return err;
			if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[3].objRef, &frame, kImplicitTypeCast))
				return err;
			colorID = _GetColorFromString(imRec.im, colorStr);
		}
		else
		{	*colorStr = 0;
			frame = true;
		}
		//if (mapRecP->needSerialize)
		//	XThreadsEnterCriticalSection();		
		_FillMapPoly_Low(mapRecP, &imRec, polyID, colorID, frame, fill, nil, false);
	}
	//if (mapRecP->needSerialize)
	//	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	_GetBlob(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			objLen;
BfrImageRec		imRec;
CStr255			formatStr;
Ptr				imagePtr = nil;
int				imLength;

	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, formatStr, nil, 256, kImplicitTypeCast))
		return err;
	if NOT(CCompareStrings(formatStr, "gif"))
		imagePtr = gdImageGifPtr(imRec.im, &imLength);
	else if NOT(CCompareStrings(formatStr, "jpeg"))
	{	gdImageInterlace(imRec.im, 1);
		imagePtr = gdImageJpegPtr(imRec.im, &imLength, -1);
	}
	/*else if NOT(CCompareStrings(formatStr, "png"))
	{	gdImageInterlace(imRec.im, 1);
		imagePtr = gdImagePngPtr(imRec.im, &imLength);
	}*/
	else
		err = XError(kBAPI_ClassError, ErrUnknownFormat);
	if NOT(err)
	{	if (imagePtr)	// default quality
			err = BAPI_BufferToObj(api_data, imagePtr, imLength, gsStringClassID, false, nil, &exeMethodRecP->resultObjRef);
		else
			err = XError(kBAPI_ClassError, ErrWhileDrawing);
	}
	if (imagePtr)
		gdFree(imagePtr);
	
return err;
}

//===========================================================================================
static XErr	_DrawMap(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
Ptr				polyPtr;
long			totPoints, totPoly;
long			id, frame_height;
double			x_offset, y_offset;
long			mapID, objLen;
BfrImageRec		imRec;
MapRec			*mapRecP;
PolyHeader		*polyHeadP;

	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &mapID, kImplicitTypeCast))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (err = _GetMapRecP(&imRec, mapID, &mapRecP))
		return err;
	if (mapRecP->needSerialize)
		XThreadsEnterCriticalSection();
	polyPtr = GetPtr(mapRecP->mapBlock);
	polyHeadP = (PolyHeader*)polyPtr;
	// GetInfos(&polyPtr, &mapRecP->center_x, &mapRecP->center_y, mapRecP->zoom, &totPoly, nil, &frame_height, &x_offset, &y_offset);
	polyPtr += POLY_FIRSTPOLY_OFFSET;
	if ((totPoly = polyHeadP->totPoly) > 0)
	{	frame_height = polyHeadP->frame_height;
		x_offset = mapRecP->x_offset;
		y_offset = mapRecP->y_offset;
		do
		{	id = *(long*)polyPtr;
			polyPtr += sizeof(long);					// skip polyID
			totPoints = *(long*)polyPtr;				// get totPoints
			polyPtr += sizeof(long);
			polyPtr += SIZE_OF_ENCLOSING;				// skip enclosing rect
			_DrawPolylineFrame(&imRec, &polyPtr, totPoints, x_offset, y_offset, frame_height, mapRecP->zoom);
		} while (--totPoly);
	}
	if (mapRecP->needSerialize)
		XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	_FrameRect(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
double			top, left, bottom, right;
long			objLen;
BfrImageRec		imRec;

	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[0].objRef, &top, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[1].objRef, &left, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[2].objRef, &bottom, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[3].objRef, &right, kImplicitTypeCast))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	_ImageFrameRect(&imRec, left, imRec.height - top, right, imRec.height - bottom);

return err;
}

//===========================================================================================
static void	_oldGetColorRange(ColoredStep *colStepP, int totSteps, double q, int *colR, int *colG, int *colB)
{
	if (q < colStepP[1].step)
	{	*colR = colStepP[0].colR;
		*colG = colStepP[0].colG;
		*colB = colStepP[0].colB;
	}
	else
	{	colStepP++;
		totSteps -= 2;
		do
		{
			if ((q >= colStepP[0].step) && (q < colStepP[1].step))
			{	*colR = colStepP[0].colR;
				*colG = colStepP[0].colG;
				*colB = colStepP[0].colB;
				return;
			}
			colStepP++;
		} while (--totSteps);
		// the last
		*colR = colStepP[0].colR;
		*colG = colStepP[0].colG;
		*colB = colStepP[0].colB;
	}
}

//===========================================================================================
/*
0	->	ok
-1	->	before
+1	->	after
*/
static int	_WhereRange(double q, ColoredStep *curStepP, ColoredStep *colStepsP, int index, int tot)
{
int		res;

	if (q > curStepP->step)
	{	if (index == tot)
			res = 0;
		else
			res = +1;
	}
	else if (q <= curStepP->step)
	{	if ((index == 1) || (q > colStepsP[index-2].step))
			res = 0;
		else
			res = -1;
	}
	
return res;
}

//===========================================================================================
static void	_GetColorRange(ColoredStep *colStepsP, int totSteps, double q, int *colR, int *colG, int *colB)
{
int				res, thePos, max, min;
ColoredStep		*curStepP;

	if (totSteps)
	{	max = totSteps;
		min = 1;
		while (max >= min)
		{	thePos = (max + min) >> 1;			
			curStepP = &colStepsP[thePos-1];
			res = _WhereRange(q, curStepP, colStepsP, thePos, totSteps);
			if (res > 0)				// range is after current
				min = thePos + 1;
			else if (res < 0)			// range is before current
				max = thePos - 1;
			else 						// range is ok
				break;
		}
		*colR = curStepP->colR;
		*colG = curStepP->colG;
		*colB = curStepP->colB;
	}
}

//===========================================================================================
static XErr	_DrawColored(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			mapID, objLen;
BfrImageRec		imRec;
MapRec			*mapRecP;
CStr255			aCStr, nullColor, toColor, fromColor, gradientCol;
ColoredStep		*saveStepP, *stepsP;
double			min, max;
Ptr				polyPtr;
int				minColorR, minColorG, minColorB, maxColorR, maxColorG, maxColorB, colR, colG, colB,
				nullR, nullG, nullB;
double			q, factorR, factorG, factorB;
ObjRef			gradientItem, gradientArray, stepItem, stepsArray, mapQuery;
long			totSteps, totGradients, polyID, i, totRec;
Boolean			alsoFrames, isNull, hasGradient, drawNA, rangeMode;
BlockRef		polygonsBlock, mapRef, stepsBlock = 0;
int				rangeColR, rangeColG, rangeColB, stepR, stepG, stepB;
ObjRefP			stepsObjrefP, gradientObjrefP;
Ptr				dataP;
long			mapLen;
MapQueryHeader	*mpHeadP;
PolyHeader		*polyHeadP;
gdPoint			*polygonsP;

	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &mapID, kImplicitTypeCast))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (err = _GetMapRecP(&imRec, mapID, &mapRecP))
		return err;
	if (mapRecP->needSerialize)
		XThreadsEnterCriticalSection();
	polyPtr = GetPtr(mapRecP->mapBlock);
	polyHeadP = (PolyHeader*)polyPtr;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, fromColor, nil, 256, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[3].objRef, toColor, nil, 256, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[4].objRef, nullColor, nil, 256, kImplicitTypeCast))
		goto out;
	stepsObjrefP = &exeMethodRecP->paramVarsP[5].objRef;
	if (err = BAPI_IsVariableInitialized(api_data, stepsObjrefP, &rangeMode))
		goto out;
	gradientObjrefP = &exeMethodRecP->paramVarsP[6].objRef;
	if (err = BAPI_IsVariableInitialized(api_data, gradientObjrefP, &hasGradient))
		goto out;
	if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[7].objRef, &alsoFrames, kImplicitTypeCast))
		goto out;
	if (*nullColor)
	{	_GetComponentsFromString(nullColor, &nullR, &nullG, &nullB);
		drawNA = true;
	}
	else
		drawNA = false;
	_GetComponentsFromString(fromColor, &minColorR, &minColorG, &minColorB);
	_GetComponentsFromString(toColor, &maxColorR, &maxColorG, &maxColorB);
	rangeColR = maxColorR - minColorR;
	rangeColG = maxColorG - minColorG;
	rangeColB = maxColorB - minColorB;
	// Map query object
	if (err = BAPI_GetReferenceTarget(api_data, &exeMethodRecP->paramVarsP[1].objRef, &mapQuery))
		goto out;
	if NOT(err = BAPI_GetObjBlock(api_data, &mapQuery, aCStr, &dataP, &mapLen, &mapRef))
	{	mpHeadP = (MapQueryHeader*)dataP;
		totRec = mpHeadP->totRec;
		min = mpHeadP->min;
		max = mpHeadP->max;
		dataP += sizeof(MapQueryHeader);
		if (rangeMode)
		{	if (err = BAPI_GetReferenceTarget(api_data, stepsObjrefP, &stepsArray))
				goto out;
			if (err = BAPI_GetArrayInfo(api_data, &stepsArray, &totSteps, nil, nil))
				goto out;
			if NOT(totSteps)
			{	err = XError(kBAPI_ClassError, ErrEmptyStepArray);
				goto out;
			}
			if (hasGradient)
			{	if (err = BAPI_GetReferenceTarget(api_data, gradientObjrefP, &gradientArray))
					goto out;
				if (err = BAPI_GetArrayInfo(api_data, &gradientArray, &totGradients, nil, nil))
					goto out;
				if (totGradients != totSteps)
				{	err = XError(kBAPI_ClassError, ErrBadGradient);
					goto out;
				}
			}
			if (totSteps > 1)
			{	stepR = rangeColR / (totSteps-1);
				stepG = rangeColG / (totSteps-1);
				stepB = rangeColB / (totSteps-1);
			}
			else
			{	stepR = rangeColR;
				stepG = rangeColG;
				stepB = rangeColB;
			}
			if (stepsBlock = NewBlock(sizeof(ColoredStep) * totSteps, &err, (Ptr*)&stepsP))
			{	saveStepP = stepsP;
				for (i = 0; i < totSteps; i++, stepsP++)
				{	if (err = BAPI_ElementOfArray(api_data, &stepsArray, i+1, &stepItem))
						goto out;
					if (err = BAPI_ObjToDouble(api_data, &stepItem, &stepsP->step, kExplicitTypeCast))
						goto out;
					if (hasGradient)
					{	if (err = BAPI_ElementOfArray(api_data, &gradientArray, i+1, &gradientItem))
							goto out;
						if (err = BAPI_ObjToString(api_data, &gradientItem, gradientCol, nil, 256, kExplicitTypeCast))
							goto out;
						_GetComponentsFromString(gradientCol, &stepsP->colR, &stepsP->colG, &stepsP->colB);
					}
					else
					{	stepsP->colR = minColorR + (stepR * i);
						stepsP->colG = minColorG + (stepG * i);
						stepsP->colB = minColorB + (stepB * i);
					}
				}
			}
		}
		else
		{
		double	rangeQuantity;
		
			rangeQuantity = max - min;
			factorR = (double)rangeColR / (double)rangeQuantity;
			factorG = (double)rangeColG / (double)rangeQuantity;
			factorB = (double)rangeColB / (double)rangeQuantity;
		}
		if (polygonsBlock = NewBlock(polyHeadP->maxTotPoints * sizeof(gdPoint), &err, (Ptr*)&polygonsP))
		{	for (i = 1; (i <= totRec) && NOT(err); i++)
			{	isNull = false;		// temp
				polyID = *(long*)dataP;
				dataP += sizeof(long);
				q = *(double*)dataP;
				dataP += sizeof(double);
				if (isNull)
					_FillMapPoly_Low(mapRecP, &imRec, polyID, gdImageColorAllocate(imRec.im, nullR, nullG, nullB), alsoFrames, (Boolean)(NOT(drawNA)), polygonsP, false);
				else
				{	if (rangeMode)
						_GetColorRange(saveStepP, totSteps, q, &colR, &colG, &colB);
					else
					{	colR = (int)(minColorR + ((q-min) * factorR));
						colG = (int)(minColorG + ((q-min) * factorG));
						colB = (int)(minColorB + ((q-min) * factorB));
					}
					_FillMapPoly_Low(mapRecP, &imRec, polyID, gdImageColorAllocate(imRec.im, colR, colG, colB), alsoFrames, true, polygonsP, false);
				}
			}
			DisposeBlock(&polygonsBlock);
		}
		BAPI_ReleaseBlock(&mapRef);
	}
out:
	if (mapRecP->needSerialize)
		XThreadsLeaveCriticalSection();
	if (stepsBlock)
		DisposeBlock(&stepsBlock);

return err;
}

//===========================================================================================
static XErr	_DrawLine(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			objLen;
BfrImageRec		imRec;
double			x1, y1, x2, y2;

	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[0].objRef, &x1, &y1))
		return err;
	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[1].objRef, &x2, &y2))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	gdImageLine(imRec.im, (int)x1, (int)(imRec.height - y1), (int)x2, (int)(imRec.height - y2), imRec.curColor);
	//DrawLine(imRec.drawWand, x1, imRec.height - y1, x2, imRec.height - y2);

return err;
}

//===========================================================================================
static XErr	_SetThickness(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr		err = noErr;
long		objLen, thickNess;
BfrImageRec	imRec;

	objLen = sizeof(BfrImageRec);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &thickNess, kImplicitTypeCast))
			gdImageSetThickness(imRec.im, thickNess);
	}
	
return err;
}

//===========================================================================================
static XErr	_ColorTransparent(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr		err = noErr;
long		objLen;
int			transpColorID, r, g, b;
CStr255		transpColor;
BfrImageRec	imRec;

	objLen = sizeof(BfrImageRec);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, transpColor, nil, 256, kImplicitTypeCast))
		{	// transpColorID = _GetColorFromString(imRec.im, transpColor);
			_GetComponentsFromString(transpColor, &r, &g, &b);
			transpColorID = gdImageColorExact(imRec.im, r, g, b);
			gdImageColorTransparent(imRec.im, transpColorID);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_LoadFromFile(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
BfrImageRec		imRec;
char			*suffixP;
XFilePath		imagePath;
FILE			*in;

	ClearBlock(&imRec, sizeof(BfrImageRec));
	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, imagePath, nil, 256, kImplicitTypeCast))
	{	CEquStr(imRec.filePath, imagePath);
		if NOT(err = BAPI_RealPath(api_data, imagePath, true))
		{	if (in = fopen(imagePath, "rb"))
			{	suffixP = strrchr(imagePath, '.');
				if NOT(CCompareStrings(suffixP, ".gif"))
				{	
				#ifdef gdImageCreateFromGif
					imRec.im = gdImageCreateFromGif(in);
				#else
					imRec.im = 0;
				#endif
				}
				else if NOT(CCompareStrings(suffixP, ".gd"))
					imRec.im = gdImageCreateFromGd(in);
				else if NOT(CCompareStrings(suffixP, ".gd2"))
					imRec.im = gdImageCreateFromGd2(in);
				else if (NOT(CCompareStrings(suffixP, ".bmp")) || NOT(CCompareStrings(suffixP, ".wbmp")))
					imRec.im = gdImageCreateFromWBMP(in);
				else
					imRec.im = gdImageCreateFromJpeg(in);
				fclose(in);
				if (imRec.im)
				{	if (err = BAPI_BufferToObj(api_data, (Ptr)&imRec, sizeof(BfrImageRec), gsImageClassID, true, nil, &exeMethodRecP->resultObjRef))
						gdImageDestroy(imRec.im);
				}
				else
					err = XError(kBAPI_ClassError, ErrLoadFailed);
			}
			else
				err = XError(kBAPI_ClassError, ErrCantOpenFile);
		}
	}

return err;

}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Image_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;
long	api_data = pbPtr->api_data;
BAPI_MemberRecord	imageMethods[TOT_METHODES] = 
					{	"DrawMap",			kDrawMap,			"void	DrawMap(int mapID)",
						"GetBlob",			kGetBlob,  			"string	GetBlob(string format='JPEG')",
						"FrameMapPoly",		kFrameMapPoly,  	"void	FrameMapPoly(int mapID, int polyID)",
						"FillMapPoly",		kFillMapPoly,  		"void	FillMapPoly(int mapID, int polyID, string color, boolean frames)",
						"TileMapPoly",		kTileMapPoly,  		"void	TileMapPoly(int mapID, int polyID, string tileFilePath, boolean frames)",
						"AttachMap",		kAttachMap,			"int	AttachMap(map myMap, double zoomFactor=1, point center)",
						"DrawLine",			kDrawLine,			"void	DrawLine(point p1, point p2)",
						"FrameRect",		kFrameRect,			"void	FrameRect(double top, double left, double bottom, double right)",
						"DrawColored",		kDrawColored,		"void	DrawColored(int mapID, mapquery *mq, string fromColor, string toColor, string nullColor, array *steps, array *gradient, boolean frames)",
						"SetThickness",		kSetThickness,		"void	SetThickness(int thickness)",
						"LoadFromFile",		kLoadFromFile,		"static image LoadFromFile(string filePath)",
						"ColorTransparent",	kColorTransparent,	"void	ColorTransparent(string transColor)"
						
					};
BAPI_MemberRecord	imageProperty[TOT_PROPERTIES] = 
					{	"width", 	kWidth,		"int",
						"height", 	kHeight,	"int",
						"path", 	kPath,		"string"
					};

	gsStringClassID = BAPI_ClassIDFromName(pbPtr->api_data, "string", false);
	if (err = BAPI_NewMethods(api_data, gsImageClassID, imageMethods, TOT_METHODES, nil))
		return err;
	if (err = BAPI_NewProperties(api_data, gsImageClassID, imageProperty, TOT_PROPERTIES, nil))
		return err;
	if (err = err = BAPI_RegisterErrors(api_data, gsImageClassID, START_ERR, gImageErrorsStr, TOT_IMAGE_ERRORS))
		return err;
		
return err;
}

//===========================================================================================
static XErr Image_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
ParameterRec	*paramVarsP = constructorRecP->varRecsP;
long			api_data = pbPtr->api_data;
BfrImageRec		imRec;
CStr255			colorStr;
int				backGround;
gdPoint			rect[4];
Boolean			indexed;

	if (message == kClone)
	{	CEquStr(pbPtr->error, "image objects cannot be copied and can be passed to functions only by reference");
		err = XError(kBAPI_Error, Err_IllegalOperation);
	}
	else
	{	ClearBlock(&imRec, sizeof(BfrImageRec));
		if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[0].objRef, &imRec.width, kImplicitTypeCast))
		{	if (imRec.width <= 0)
				err = XError(kBAPI_ClassError, ErrInvalidImageWidth);
			else
			{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &imRec.height, kImplicitTypeCast))
				{	if (imRec.height <= 0)
						err = XError(kBAPI_ClassError, ErrInvalidImageHeight);
					else
					{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[2].objRef, colorStr, nil, 256, kImplicitTypeCast))
						{	if NOT(*colorStr)
								CEquStr(colorStr, "ffffff");
							if NOT(err = BAPI_ObjToBoolean(api_data, &paramVarsP[3].objRef, &indexed, kImplicitTypeCast))
							{	// if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[4].objRef, &imRec.threshold, kImplicitTypeCast))
								{	if (indexed)
										imRec.im = gdImageCreate(imRec.width, imRec.height);
									else
										imRec.im = gdImageCreateTrueColor(imRec.width, imRec.height);
									if (imRec.im)
									{	backGround = _GetColorFromString(imRec.im, colorStr);
										rect[0].x = 0;
										rect[0].y = 0;
										rect[1].x = 0;
										rect[1].y = imRec.height;
										rect[2].x = imRec.width;
										rect[2].y = imRec.height;
										rect[3].x = imRec.width;
										rect[3].y = 0;
										gdImageFilledPolygon(imRec.im, rect, 4, backGround);
										imRec.curColor = gdImageColorAllocate(imRec.im, 0, 0, 0); 
										err = BAPI_BufferToObj(api_data, (Ptr)&imRec, sizeof(BfrImageRec), gsImageClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
									}
									else
										err = XError(kBAPI_ClassError, ErrGdImageCreateFailed);
								}
							}
						}
					}
				}
			}
		}
		if (err)
		{	if (imRec.im)
				gdImageDestroy(imRec.im);
		}
	}

return err;
}

//===========================================================================================
static XErr	Image_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
BfrImageRec		imRec;
long			i, objLen;
MapRec			*mapRecP;

	objLen = sizeof(BfrImageRec);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
	{	if (objLen)
		{	XThreadsEnterCriticalSection();
			mapRecP = &imRec.mapRec[0];
			for (i = 0; i < MAX_MAPS; i++, mapRecP++)
			{	if (mapRecP->busy)
					DecrementMapRefCount(mapRecP->mapBlock);
			}
			XThreadsLeaveCriticalSection();
			if (imRec.im)
				gdImageDestroy(imRec.im);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Image_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;

	switch(exeMethodRecP->methodID)
	{
		case kDrawMap:
			err = _DrawMap(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kGetBlob:
			err = _GetBlob(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kFrameMapPoly:
			err = _FillMapPoly(exeMethodRecP, api_data, pbPtr->error, exeMethodRecP->methodID);
			break;
		case kFillMapPoly:
			err = _FillMapPoly(exeMethodRecP, api_data, pbPtr->error, exeMethodRecP->methodID);
			break;
		case kTileMapPoly:
			err = _FillMapPoly(exeMethodRecP, api_data, pbPtr->error, exeMethodRecP->methodID);
			break;
		case kAttachMap:
			err = _AttachMap(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kFrameRect:
			err = _FrameRect(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kDrawLine:
			err = _DrawLine(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kDrawColored:
			err = _DrawColored(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kSetThickness:
			err = _SetThickness(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kLoadFromFile:
			err = _LoadFromFile(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kColorTransparent:
			err = _ColorTransparent(exeMethodRecP, api_data, pbPtr->error);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
	
return err;
}

//===========================================================================================
static XErr	Image_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRecP = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			objLen, api_data = pbPtr->api_data;
BfrImageRec		imRec;

	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &getPropertyRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	switch(getPropertyRecP->propertyID)
	{
		case kWidth:
			err = BAPI_IntToObj(api_data, imRec.im->sx, &getPropertyRecP->resultObjRef);
			break;
		case kHeight:
			err = BAPI_IntToObj(api_data, imRec.im->sy, &getPropertyRecP->resultObjRef);
			break;
		case kPath:
			err = BAPI_StringToObj(api_data, imRec.filePath, CLen(imRec.filePath), &getPropertyRecP->resultObjRef);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
	#pragma export on
#endif
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
unsigned long	versionBAPI;

	switch(message)
	{
		case kRegister:
			BAPI_GetNumVersions(pbPtr->api_data, nil, &versionBAPI, nil);
			if (versionBAPI < 0x00010004)
			{	// "point" uses BAPI_GetReferenceTarget (that is new to BAPI 1.0.4)
				err = XError(kBAPI_Error, Err_BAPI_ExtensionTooNew);
				CEquStr(pbPtr->error, "BAPI >= 1.0.4 needed (Biferno >= 1.2)");
			}
			else
			{	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
				CEquStr(pbPtr->param.registerRec.pluginName, "image");
				CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft image class");
				VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
				if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
					CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
				gsImageClassID = pbPtr->param.registerRec.pluginID;
				CEquStr(pbPtr->param.registerRec.constructor, "void image(int width, int height, string background, boolean indexed)");
				pbPtr->param.registerRec.fixedSize = true;
				pbPtr->param.registerRec.wantDestructor = true;
				pbPtr->param.registerRec.nextBAPI_Dispatch = (long)map_Biferno_Dispatch;
			}
			break;
		case kInit:
			err = Image_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Image_Constructor(pbPtr, message);
			break;
		case kDestructor:
			err = Image_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Image_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Image_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			// da fare
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;

		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
	#pragma export off
#endif
