/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: LoadPoly.c,v 1.6 2005-10-04 13:54:35 valfer Exp $
	|______________________________________________________________________________
*/

#include "XLib.h"
#include "LoadPoly.h"
#include 	"BifernoAPI.h"

//===========================================================================================
static XErr _GetContent(XFilePathPtr filePath, BlockRef *textBlockP, long *fileSizeP)
{
XFileRef		fileRef;
long			eof;
BlockRef		block = nil;
XErr			err = noErr, err2 = noErr;
Ptr				p;

	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof)
			{	if (block = NewBlock(eof, &err, &p))
					err = ReadXFile(fileRef, p, &eof);
			}
			else
				block = NewBlock(1, &err, nil);
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	
	
if NOT(err)
{	*textBlockP = block;
	*fileSizeP = eof;
}
else
{	*textBlockP = nil;
	*fileSizeP = 0;
	if (block)
		DisposeBlock(&block);
}

return err;
}

//===========================================================================================
static long	_GetInt(Ptr *polyPPtr, long *lenP)
{
Ptr			polyP = *polyPPtr;
long		num, len = *lenP;
int			i, ch;
CStr255		tempStr;

	i = 0;
	num = 0;
	while (len > 0)
	{	ch = *polyP; 
		if ((ch >= '0') && (ch <= '9') && (i < 255))
		{	tempStr[i++] = *polyP++;
			len--;
		}
		else
		{	tempStr[i] = 0;
			CStringToNum(tempStr, &num);
			break;
		}
	}

*lenP = len;
*polyPPtr = polyP;
return num;
}

//===========================================================================================
/*static void	_GetRefString(Ptr *polyPPtr, long *lenP, char *refStr)
{
Ptr			polyP = *polyPPtr;
long		len = *lenP;
int			i, ch;

	i = 0;
	while (len > 0)
	{	ch = *polyP; 
		if ((ch >= '0') && (ch <= '9') && (i < REF_SIZE))
		{	refStr[i++] = *polyP++;
			len--;
		}
		else
			break;
	}
	while(i < REF_SIZE)
		refStr[i++] = 0;

*lenP = len;
*polyPPtr = polyP;
}
*/
//===========================================================================================
static double	_GetDouble(Ptr *polyPPtr, long *lenP)
{
Ptr			polyP = *polyPPtr;
long		len = *lenP;
int			i, ch;
CStr255		tempStr;
double		dNum;

	i = 0;
	dNum = 0;
	while (len > 0)
	{	ch = *polyP; 
		if ((((ch >= '0') && (ch <= '9')) || (ch == '.') || (ch == '-')) && (i < 255))
		{	tempStr[i++] = *polyP++;
			len--;
		}
		else
			break;
	}
	tempStr[i] = 0;
	dNum = CStrToReal(tempStr);

*lenP = len;
*polyPPtr = polyP;
return dNum;
}

//===========================================================================================
static Boolean	_OffSwap(long i, long j, PolyHeader *polHeadP, long *offsetP)
{
long		id_i, id_j;
			
	id_i = *(long*)(((Ptr)polHeadP) + offsetP[i]);
	id_j = *(long*)(((Ptr)polHeadP) + offsetP[j]);
	
return (id_i > id_j);
}

//===========================================================================================
static void	_BubbleOrderOffsets(PolyHeader *polHeadP)
{
int		j, i;
long	tempLong, *offsetP = (long*)GetPtr(polHeadP->offsets);

	// Bubble
	j = polHeadP->totPoly;
	if (--j <= 0)
		return;
	do
	{	for (i = 0; i < j; i++)
		{	if (_OffSwap(i, i+1, polHeadP, offsetP))
			{	tempLong = offsetP[i+1];
				offsetP[i+1] = offsetP[i];
				offsetP[i] = tempLong;
			}
		}
	} while(--j);
}

//===========================================================================================
/*
errors:
	1	comma expected
	
Text Format on entry (decimal is '.'):
	idpoly	x y, x y, x y
	...
	...

Binary Format on exit (see struct PolyHeader):
	1	long	number of polygons
	1	long	user frame width
	1	long	user frame height
	1	long	border (not initialized here)
	1	long	maxTotPoints
	
	1	double	min_x		// min and max coordinates
	1	double	min_y
	1	double	max_x
	1	double	max_y

	
	1	long	polyID
	1	long	tot points
	4	double	enclosing rect	(top left bottom right)
	1	double	x
	1	double	y
	1	double	x
	1	double	y
	...

	1	long	polyID
	1	long	tot points
	4	double	enclosing rect
	1	double	x
	1	double	y
	1	double	x
	1	double	y
	...
*/
XErr LoadPoly(XFilePathPtr polyPath, BlockRef *resultP, long *resultlenP, long *lineErrorP)
{
XErr		err;	
BlockRef	polyText;
long		curOffset, totPoints, idPoly, tLen, polyTextSize, lineNum, totPoly;
Ptr			aBufferP, bufferPtr, polyP;
double		pointx, pointy;
BufferID	buffid;
double		min_x = MAX_DOUBLE, min_y = MAX_DOUBLE, max_x = -MAX_DOUBLE, max_y = -MAX_DOUBLE;
PolyHeader	polyHeader, *polyHeaderP;

	if (lineErrorP)
		*lineErrorP = 0;
	if NOT(err = _GetContent(polyPath, &polyText, &polyTextSize))
	{	if (buffid = BufferCreate(polyTextSize >> 4, &err))
		{	tLen = polyTextSize;
			lineNum = 1;
			polyP = aBufferP = GetPtr(polyText);
			idPoly = 0;
			totPoly = 0;
			totPoints = 0;
			ClearBlock(&polyHeader, sizeof(PolyHeader));	// importante
			if NOT(err = BufferAddBuffer(buffid, (Ptr)&polyHeader, sizeof(PolyHeader)))
			{	while(tLen > 0)
				{	if (IsNewLineExt(&polyP, &tLen, &lineNum))
					{	
					newPoly:
						if (idPoly)
						{	BufferGetBlockRefExt(buffid, &bufferPtr);
							*(long*)(bufferPtr + curOffset) = totPoints;
						}
						idPoly = 0;
						totPoints = 0;
					}
					else if (tLen && (*polyP == '\t'))
					{	polyP++;
						tLen--;
					}
					else
					{	if (idPoly)
						{	pointx = _GetDouble(&polyP, &tLen);
							if (pointx < min_x)
								min_x = pointx;
							if (pointx > max_x)
								max_x = pointx;
							if (err = BufferAddBuffer(buffid, (Ptr)&pointx, sizeof(double)))
								break;
							SkipSpaceAndTab(&polyP, &tLen);
							pointy = _GetDouble(&polyP, &tLen);
							if (pointy < min_y)
								min_y = pointy;
							if (pointy > max_y)
								max_y = pointy;
							if (err = BufferAddBuffer(buffid, (Ptr)&pointy, sizeof(double)))
								break;
							SkipSpaceAndTab(&polyP, &tLen);
							if (tLen && *polyP == ',')
							{	polyP++;	// skip ','
								tLen--;
							}
							else if (IsNewLineExt(&polyP, &tLen, &lineNum))
							{	totPoints++;
								goto newPoly;
							}
							else if (tLen)
							{	err = XError(kBAPI_ClassError, ErrBadFile);
								if (lineErrorP)
									*lineErrorP = lineNum;
								break;
							}
							totPoints++;
							SkipSpaceAndTab(&polyP, &tLen);
						}
						else
						{	idPoly = _GetInt(&polyP, &tLen);
							if (err = BufferAddLong(buffid, idPoly))
								break;
							/*if (tLen)
							{	polyP++;	// skip '\t'
								tLen--;
							}
							_GetRefString(&polyP, &tLen, refStr);
							if (err = BufferAddBuffer(buffid, refStr, REF_SIZE))
								break;
							*/
							BufferGetBlockRef(buffid, &curOffset);		//  to update totPoints later
							if (err = BufferAddLong(buffid, totPoints))
								break;
							if (err = BufferAddBuffer(buffid, aBufferP, SIZE_OF_ENCLOSING))	// enclosing rect (update later)
								break;
							totPoly++;
							//printf("%d\r\n", totPoly);
						}
					}
				}
				if (totPoints)
				{	if (idPoly)
					{	BufferGetBlockRefExt(buffid, &bufferPtr);
						*(long*)(bufferPtr + curOffset) = totPoints;
					}
				}
			}
			if NOT(err)
			{	*resultP = BufferGetBlockRefExtSize(buffid, resultlenP, (Ptr*)&polyHeaderP);
				polyHeaderP->totPoly = totPoly;
				polyHeaderP->min_x = min_x;		
				polyHeaderP->min_y = min_y;		
				polyHeaderP->max_x = max_x;		
				polyHeaderP->max_y = max_y;		
				/*
				*(long*)bufferPtr = totPoly;	// update num poly
				bufferPtr += POLY_MINMAX_OFFSET;
				*(double*)bufferPtr = min_x;	// update min and max coordinates
				bufferPtr += sizeof(double);
				*(double*)bufferPtr = min_y;
				bufferPtr += sizeof(double);
				*(double*)bufferPtr = max_x;
				bufferPtr += sizeof(double);
				*(double*)bufferPtr = max_y;
				*/
				BufferSetLength(buffid, *resultlenP);	// to shrink
				BufferClose(buffid);
				//printf("%d/%d\r\n", *resultlenP, polyTextSize);
			}
			else
				BufferFree(buffid);
		}
		DisposeBlock(&polyText);
	}

return err;
}

//===========================================================================================
// Create also the offsets ordered block
XErr	Normalize(Ptr polyPtr, double width, double height, long border)
{
double		min_x, min_y, max_x, max_y, enc_rect_width, enc_rect_height;
double		/*save_height, */factor, x_factor, y_factor, offset_x, offset_y;
Ptr			buffPtr;
long		totPoly, totPoints, *offsetP;
PolyHeader	*polHeadP = (PolyHeader*)polyPtr;
XErr		err = noErr;
double		*enclosingP;
double		top, left, bottom, right, tx, ty;
long		maxTotPoints;

	// save user frame and border
	polHeadP->frame_width = (long)width;
	polHeadP->frame_height = (long)height;
	polHeadP->border = border;
	
	// calculate enclosing rect
	min_x = polHeadP->min_x;
	min_y = polHeadP->min_y;
	max_x = polHeadP->max_x;
	max_y = polHeadP->max_y;
	enc_rect_width = max_x - min_x;
	if (enc_rect_width < 0)
		enc_rect_width = -enc_rect_width;
	enc_rect_height = max_y - min_y;
	if (enc_rect_height < 0)
		enc_rect_height = -enc_rect_height;

	// get final width
	if (width == 0)
		width = enc_rect_width;
	if (height == 0)
		height = enc_rect_height;
	width -= 2 * border;
	height -= 2 * border;

	// calculate offset (all data will be shifted by this)
	offset_x = -min_x;
	offset_y = -min_y;
	
	// calculate factor
	x_factor = width / enc_rect_width;
	y_factor = height / enc_rect_height;
	if (x_factor < y_factor)
		factor = x_factor;
	else
		factor = y_factor;

	// update factors
	offset_x *= factor;
	//offset_x += border;
	offset_y *= factor;
	//offset_y += border;
	
	// update min and max coordinates
	//buffPtr = polyPtr;
	//totPoly = *(long*)polyPtr;
	totPoly = polHeadP->totPoly;
	if NOT(polHeadP->offsets = NewBlock(totPoly * sizeof(long), &err, (Ptr*)&offsetP))
		return err;

	polHeadP->min_x = offset_x + min_x * factor;
	polHeadP->min_y = offset_y + min_y * factor;
	polHeadP->max_x = offset_x + max_x * factor;
	polHeadP->max_y = offset_y + max_y * factor;
	
	// normalize
	buffPtr = polyPtr + POLY_FIRSTPOLY_OFFSET;
	if (totPoly > 0)
	{	maxTotPoints = 0;
		do
		{	*offsetP++ = buffPtr - polyPtr;
			buffPtr += sizeof(long);		// skip polyID
			totPoints = *(long*)buffPtr;
			if (maxTotPoints < totPoints)
				maxTotPoints = totPoints;
			buffPtr += sizeof(long);		// skip totPoints
			enclosingP = (double*)buffPtr;
			buffPtr += SIZE_OF_ENCLOSING;	// skip enclosing rect
			// load first point in enclosing vertex
			left = right = tx = offset_x + (*(double*)buffPtr) * factor;
			*(double*)buffPtr = tx;
			buffPtr += sizeof(double);
			top = bottom = ty = offset_y + (*(double*)buffPtr) * factor;
			*(double*)buffPtr = ty;
			buffPtr += sizeof(double);
			if (--totPoints)
			{	do
				{	tx = offset_x + (*(double*)buffPtr) * factor;
					*(double*)buffPtr = tx;
					if (tx < left)
						left = tx;
					if (tx > right)
						right = tx;
					buffPtr += sizeof(double);
					ty = offset_y + (*(double*)buffPtr) * factor;
					if (ty < bottom)
						bottom = ty;
					if (ty > top)
						top = ty;
					*(double*)buffPtr = ty;
					buffPtr += sizeof(double);
				} while (--totPoints);
			}
			// update enclosing rect
			*enclosingP++ = top;
			*enclosingP++ = left;
			*enclosingP++ = bottom;
			*enclosingP++ = right;
		} while (--totPoly);
	}
	_BubbleOrderOffsets(polHeadP);
	polHeadP->maxTotPoints = maxTotPoints;
	
return err;
}





