/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: image_bfr.c,v 1.2 2005-02-18 15:30:22 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"

#include 	"map_bfr.h"
#include 	"point_bfr.h"

#if __UNIX_XLIB__
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <errno.h>
	#include <math.h>
	#include <time.h>
	#include <wand/magick_wand.h>
	#include <wand/drawing_wand.h>
	#include <wand/pixel_wand.h>
	#include <wand/pixel_iterator.h>
#endif

#define	MAX_MAPS	12
typedef struct
{
	BlockRef		mapBlock;
	Boolean			busy;
	Boolean			needSerialize;
	short			pad2;
	double			zoom;
	double			center_x;
	double			center_y;
} MapRec;
typedef struct
{
	DrawingWand		*drawWand;
	MagickWand		*magickWand;
	PixelWand		*backGround;
	long			width;
	long			height;
	long			totMaps;
	MapRec			mapRec[MAX_MAPS];
} BfrImageRec;

// Methods
enum{
		kDrawMap = 1,
		kGetBlob,
		kFillMapPoly,
		kAttachMap,
		kFrameRect,
		kDrawLine
	};
#define TOT_METHODES	6

// Errors
#define	START_ERR	100
enum {
		ErrInvalidImageWidth = START_ERR,
		ErrInvalidImageHeight,
		ErrNewDrawingWandFailed,
		ErrNewMagickWandFailed,
		ErrNewPixelWandFailed,
		ErrWhileDrawing,
		ErrTooManyMaps,
		ErrInvalidMapID
};
#define	TOT_IMAGE_ERRORS	8
CStr63	gImageErrorsStr[] = 
	{	
		"ErrInvalidImageWidth",
		"ErrInvalidImageHeight",
		"ErrNewDrawingWandFailed",
		"ErrNewMagickWandFailed",
		"ErrNewPixelWandFailed",
		"ErrWhileDrawing",
		"ErrTooManyMaps",
		"ErrInvalidMapID"
		};

static long	gsImageClassID, gsStringClassID;

//===========================================================================================
static XErr	_MyDrawPolygon(DrawingWand *drawWand, long totPoints, Ptr polyPtr, double x_offset, double y_offset, long frame_height, double zoom)
{
Ptr			pInfoP, saveP;
long		saveTot, tLen;
XErr		err = noErr;
BlockRef	block;

	if (totPoints > 2)
	{	tLen = totPoints * sizeof(double) * 2;
		if (block = NewBlock(tLen, &err, (Ptr*)&pInfoP))
		{	CopyBlock(pInfoP, polyPtr, tLen);
			saveP = pInfoP;
			saveTot = totPoints;
			do
			{	*(double*)pInfoP = x_offset + Zoom(zoom, *(double*)pInfoP);
				pInfoP += sizeof(double);
				*(double*)pInfoP = frame_height - (y_offset + Zoom(zoom, *(double*)pInfoP));
				pInfoP += sizeof(double);
			} while (--totPoints);
			DrawPolygon(drawWand, saveTot, (PointInfo*)saveP);
			DisposeBlock(&block);
		}
	}

return err;
}

//===========================================================================================
static void	_ImageFrameRect(DrawingWand *drawWand, double left, double top, double right, double bottom)
{
	DrawLine(drawWand, left, top, right, top);
	DrawLine(drawWand, right, top, right, bottom);
	DrawLine(drawWand, left, bottom, right, bottom);
	DrawLine(drawWand, left, bottom, left, top);
}

//===========================================================================================
static XErr	_GetMapRecP(BfrImageRec *imRecP, long mapID, MapRec	**mapRecPPtr)
{
XErr	err = noErr;
MapRec	*mapRecP = nil;

	if ((mapID > 0) && (mapID < MAX_MAPS))
	{	mapRecP = &imRecP->mapRec[--mapID];
		if NOT(mapRecP->busy)
			err = XError(kBAPI_ClassError, ErrInvalidMapID);
	}
	else
		err = XError(kBAPI_ClassError, ErrInvalidMapID);
	
*mapRecPPtr = mapRecP;	
return err;
}

//===========================================================================================
static void	_DrawPolylineFrame(DrawingWand *drawWand, Ptr *buffPtrP, int totPoints, double x_offset, double y_offset, long frame_height, double zoom)
{
double		x, y, oldx, oldy, firstx, firsty;
Ptr			buffPtr = *buffPtrP;

	firstx = oldx = x_offset + Zoom(zoom, *(double*)buffPtr);
	buffPtr += sizeof(double);
	firsty = oldy = y_offset + Zoom(zoom, *(double*)buffPtr);
	buffPtr += sizeof(double);
	if (--totPoints)
	{	do
		{	
			x = x_offset + Zoom(zoom, *(double*)buffPtr);
			buffPtr += sizeof(double);
			y = y_offset + Zoom(zoom, *(double*)buffPtr);
			buffPtr += sizeof(double);
			DrawLine(drawWand, x, frame_height-y, oldx, frame_height-oldy);
			oldx = x;
			oldy = y;
		} while (--totPoints);
		DrawLine(drawWand, x, frame_height-y, firstx, frame_height-firsty);
	}
	*buffPtrP = buffPtr;
}

//===========================================================================================
static XErr	_AttachMap(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			off, objLen, i;
BfrImageRec		imRec;
MapRec			*mapRecP, mapRec;
BlockRef		polyBlock;
Boolean			needSer;
double			center_x, center_y, zoom;

	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (imRec.totMaps < MAX_MAPS)
	{	objLen = sizeof(BlockRef);
		if (err = BAPI_GetObj(api_data, &exeMethodRecP->paramVarsP[0].objRef, (Ptr)&polyBlock, &objLen, 0, nil))
			return err;
		if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[1].objRef, &zoom, kImplicitTypeCast))
			return err;
		if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[2].objRef, &center_x, &center_y))
			return err;
		/*if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[2].objRef, &center_x, kImplicitTypeCast))
			return err;
		if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[3].objRef, &center_y, kImplicitTypeCast))
			return err;*/
		if (err = BAPI_NeedSerialize(api_data, &exeMethodRecP->paramVarsP[0].objRef, &needSer))
			return err;
		XThreadsEnterCriticalSection();
		mapRecP = &imRec.mapRec[0];
		for (i = 0; i < MAX_MAPS; i++, mapRecP++)
		{	if NOT(mapRecP->busy)
				break;
		}
		if (i == MAX_MAPS)
			err = XError(kBAPI_ClassError, ErrTooManyMaps);
		else
		{	ClearBlock(&mapRec, sizeof(MapRec));
			imRec.totMaps++;
			if NOT(err = BAPI_WriteObj(api_data, &exeMethodRecP->objRef, &imRec.totMaps, sizeof(long), offsetof(BfrImageRec, totMaps) + 1))
			{	mapRec.mapBlock = polyBlock;
				mapRec.zoom = zoom;
				mapRec.center_x = center_x;
				mapRec.center_y = center_y;
				mapRec.busy = true;
				mapRec.needSerialize = needSer;
				off = offsetof(BfrImageRec, mapRec) + (i * sizeof(MapRec)) + 1;
				if NOT(err = BAPI_WriteObj(api_data, &exeMethodRecP->objRef, &mapRec, sizeof(MapRec), off))
				{	exeMethodRecP->sideEffect = true;
					IncrementMapRefCount(polyBlock);
					err = BAPI_IntToObj(api_data, i+1, &exeMethodRecP->resultObjRef);
				}
				else
				{	imRec.totMaps--;
					err = BAPI_WriteObj(api_data, &exeMethodRecP->objRef, &imRec.totMaps, sizeof(long), offsetof(BfrImageRec, totMaps));
				}
			}
		}
		XThreadsLeaveCriticalSection();
	}
	else
		err = XError(kBAPI_ClassError, ErrTooManyMaps);

return err;
}

//===========================================================================================
static XErr	_FillMapPoly(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
Ptr				polyPtr;
CStr255			colorStr;
long			tLen, totPoints, totPoly;
long			id, frame_width, frame_height, border;
double			x_offset, y_offset;
long			mapID, objLen, polyID;
BfrImageRec		imRec;
PixelWand		*polyColor, *saveColor, *blackColor;
MapRec			*mapRecP;

	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &mapID, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &polyID, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, colorStr, nil, 256, kImplicitTypeCast))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (err = _GetMapRecP(&imRec, mapID, &mapRecP))
		return err;
	if (mapRecP->needSerialize)
		XThreadsEnterCriticalSection();
	polyPtr = GetPtr(mapRecP->mapBlock);
	GetInfos(&polyPtr, &mapRecP->center_x, &mapRecP->center_y, mapRecP->zoom, &totPoly, &frame_width, &frame_height, &x_offset, &y_offset);
	if (totPoly > 0)
	{	do
		{	id = *(long*)polyPtr;
			polyPtr += sizeof(long);					// skip polyID
			totPoints = *(long*)polyPtr;				// get totPoints
			polyPtr += sizeof(long);
			if (id == polyID)
			{	if ((polyColor = NewPixelWand()) && (saveColor = NewPixelWand()))
				{	DrawGetFillColor(imRec.drawWand, saveColor);
					PixelSetColor(polyColor, colorStr);
					DrawSetFillColor(imRec.drawWand, polyColor);
					_MyDrawPolygon(imRec.drawWand, totPoints, polyPtr, x_offset, y_offset, frame_height, mapRecP->zoom);
					DrawSetFillColor(imRec.drawWand, saveColor);
					DestroyPixelWand(polyColor);
					DestroyPixelWand(saveColor);
					_DrawPolylineFrame(imRec.drawWand, &polyPtr, totPoints, x_offset, y_offset, frame_height, mapRecP->zoom);
				}
				break;
			}
			polyPtr += sizeof(double) * 2 * totPoints;
		} while (--totPoly);
	}
	if (mapRecP->needSerialize)
		XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	_GetBlob(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
long			tLen, objLen;
BfrImageRec		imRec;
CStr255			formatStr;
Ptr				imagePtr;
size_t			imLength;
char			*description = nil;
ExceptionType	severity;

	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, formatStr, nil, 256, kImplicitTypeCast))
		return err;
	//_ImageFrameRect(imRec.drawWand, 0, 0, imRec.width-1, imRec.height-1);
	if (MagickDrawImage(imRec.magickWand, imRec.drawWand) == MagickTrue)
	{	MagickSetImageFormat(imRec.magickWand, formatStr);
		imagePtr = MagickGetImageBlob(imRec.magickWand, &imLength);
		err = BAPI_BufferToObj(api_data, imagePtr, imLength, gsStringClassID, false, nil, &exeMethodRecP->resultObjRef);
	}
	else
	{	description = MagickGetException(imRec.magickWand, &severity);
		tLen = CLen(description);
		if (tLen > 255)
			tLen = 255;
		CopyBlock(error, description, tLen);
		error[tLen] = 0;
		description = (char*)MagickRelinquishMemory(description);
		err = XError(kBAPI_ClassError, ErrWhileDrawing);
	}

return err;
}

//===========================================================================================
static XErr	_DrawMap(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
Ptr				polyPtr;
CStr255			buffer;
long			tLen, totPoints, totPoly, polyLen;
long			id, frame_height, border;
double			x_offset, y_offset;
long			mapID, objLen;
BfrImageRec		imRec;
DrawingWand		*drawWand;
MapRec			*mapRecP;

	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &mapID, kImplicitTypeCast))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	if (err = _GetMapRecP(&imRec, mapID, &mapRecP))
		return err;
	if (mapRecP->needSerialize)
		XThreadsEnterCriticalSection();
	polyPtr = GetPtr(mapRecP->mapBlock);
	GetInfos(&polyPtr, &mapRecP->center_x, &mapRecP->center_y, mapRecP->zoom, &totPoly, nil, &frame_height, &x_offset, &y_offset);
	drawWand = imRec.drawWand;
	if (totPoly > 0)
	{	do
		{	id = *(long*)polyPtr;
			polyPtr += sizeof(long);					// skip polyID
			totPoints = *(long*)polyPtr;				// get totPoints
			polyPtr += sizeof(long);
			_DrawPolylineFrame(drawWand, &polyPtr, totPoints, x_offset, y_offset, frame_height, mapRecP->zoom);
		} while (--totPoly);
	}
	if (mapRecP->needSerialize)
		XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	_FrameRect(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
double			top, left, bottom, right;
long			objLen;
BfrImageRec		imRec;

	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[0].objRef, &top, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[1].objRef, &left, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[2].objRef, &bottom, kImplicitTypeCast))
		return err;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[3].objRef, &right, kImplicitTypeCast))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	_ImageFrameRect(imRec.drawWand, left, imRec.height - top, right, imRec.height - bottom);

return err;
}

//===========================================================================================
static XErr	_DrawLine(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr			err = noErr;
double			top, left, bottom, right;
long			objLen;
BfrImageRec		imRec;
double			x1, y1, x2, y2;

	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[0].objRef, &x1, &y1))
		return err;
	if (err = Point2Coords(api_data, &exeMethodRecP->paramVarsP[1].objRef, &x2, &y2))
		return err;
	objLen = sizeof(BfrImageRec);
	if (err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
		return err;
	DrawLine(imRec.drawWand, x1, imRec.height - y1, x2, imRec.height - y2);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Image_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;
long	api_data = pbPtr->api_data;
BAPI_MemberRecord	mapMethods[TOT_METHODES] = 
					{	"DrawMap",		kDrawMap,		"void	DrawMap(int mapID)",
						"GetBlob",		kGetBlob,  		"string	GetBlob(string format='JPEG')",
						"FillMapPoly",	kFillMapPoly,  	"void	FillMapPoly(int mapID, int polyID, string color)",
						"AttachMap",	kAttachMap,		"int	AttachMap(map myMap, double zoomFactor=1, point center)",
						"DrawLine",		kDrawLine,		"void	DrawLine(point p1, point p2)",
						"FrameRect",	kFrameRect,		"void	FrameRect(double top, double left, double bottom, double right)"
					};

	gsStringClassID = BAPI_ClassIDFromName(pbPtr->api_data, "string", false);
	if (err = BAPI_NewMethods(api_data, gsImageClassID, mapMethods, TOT_METHODES, nil))
		return err;
	
	err = BAPI_RegisterErrors(api_data, gsImageClassID, START_ERR, gImageErrorsStr, TOT_IMAGE_ERRORS);
	
return err;
}

//===========================================================================================
static XErr Image_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
ParameterRec	*paramVarsP = constructorRecP->varRecsP;
long			api_data = pbPtr->api_data;
BlockRef 		polyBlock;
long			polyBlockLen;
BfrImageRec		imRec;
CStr255			colorStr;

	if (message == kClone)
	{
		// da fare
	}
	else
	{	ClearBlock(&imRec, sizeof(BfrImageRec));
		if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[0].objRef, &imRec.width, kImplicitTypeCast))
		{	if (imRec.width <= 0)
				err = XError(kBAPI_ClassError, ErrInvalidImageWidth);
			else
			{	if NOT(err = BAPI_ObjToInt(api_data, &paramVarsP[1].objRef, &imRec.height, kImplicitTypeCast))
				{	if (imRec.height <= 0)
						err = XError(kBAPI_ClassError, ErrInvalidImageHeight);
					else
					{	if NOT(err = BAPI_ObjToString(api_data, &paramVarsP[2].objRef, colorStr, nil, 256, kImplicitTypeCast))
						{	if NOT(*colorStr)
								CEquStr(colorStr, "#ffffff");
							if (imRec.drawWand = NewDrawingWand())
							{	if (imRec.magickWand = NewMagickWand())
								{	if (imRec.backGround = NewPixelWand())
									{	PixelSetColor(imRec.backGround, colorStr);
										//printf("drawWand: %d\n", imRec.drawWand);
										if (MagickNewImage(imRec.magickWand, imRec.width, imRec.height, imRec.backGround) == MagickTrue)
											err = BAPI_BufferToObj(api_data, (Ptr)&imRec, sizeof(BfrImageRec), gsImageClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
									}
									else
										err = XError(kBAPI_ClassError, ErrNewPixelWandFailed);
								}
								else
									err = XError(kBAPI_ClassError, ErrNewMagickWandFailed);
							}
							else
								err = XError(kBAPI_ClassError, ErrNewDrawingWandFailed);
						}
					}
				}
			}
		}
	}
	if (err)
	{	if (imRec.drawWand)
			imRec.drawWand = DestroyDrawingWand(imRec.drawWand);
		if (imRec.magickWand)
			imRec.magickWand = DestroyMagickWand(imRec.magickWand);
		if (imRec.backGround)
			DestroyPixelWand(imRec.backGround);
	}

return err;
}

//===========================================================================================
static XErr	Image_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
BfrImageRec		imRec;
long			i, objLen;
MapRec			*mapRecP;

	objLen = sizeof(BfrImageRec);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&imRec, &objLen, 0, nil))
	{	if (objLen)
		{	XThreadsEnterCriticalSection();
			mapRecP = &imRec.mapRec[0];
			for (i = 0; i < MAX_MAPS; i++, mapRecP++)
			{	if (mapRecP->busy)
					DecrementMapRefCount(mapRecP->mapBlock);
			}
			XThreadsLeaveCriticalSection();
			if (imRec.drawWand)
				imRec.drawWand = DestroyDrawingWand(imRec.drawWand);
			if (imRec.magickWand)
				imRec.magickWand = DestroyMagickWand(imRec.magickWand);
			if (imRec.backGround)
				DestroyPixelWand(imRec.backGround);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Image_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;

	switch(exeMethodRecP->methodID)
	{
		case kDrawMap:
			err = _DrawMap(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kGetBlob:
			err = _GetBlob(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kFillMapPoly:
			err = _FillMapPoly(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kAttachMap:
			err = _AttachMap(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kFrameRect:
			err = _FrameRect(exeMethodRecP, api_data, pbPtr->error);
			break;
		case kDrawLine:
			err = _DrawLine(exeMethodRecP, api_data, pbPtr->error);
			break;
		
		
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
	#pragma export on
#endif
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
unsigned long	versionBAPI;

	switch(message)
	{
		case kRegister:
			BAPI_GetNumVersions(pbPtr->api_data, nil, &versionBAPI, nil);
			if (versionBAPI < 0x00010004)
			{	// "point" uses BAPI_GetReferenceTarget (that is new to BAPI 1.0.4)
				err = XError(kBAPI_Error, Err_BAPI_ExtensionTooNew);
				CEquStr(pbPtr->error, "BAPI >= 1.0.4 needed (Biferno >= 1.2)");
			}
			else
			{	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
				CEquStr(pbPtr->param.registerRec.pluginName, "image");
				CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft image class");
				VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
				if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
					CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
				gsImageClassID = pbPtr->param.registerRec.pluginID;
				CEquStr(pbPtr->param.registerRec.constructor, "void image(int width, int height, string background)");
				pbPtr->param.registerRec.fixedSize = true;
				pbPtr->param.registerRec.wantDestructor = true;
				pbPtr->param.registerRec.nextBAPI_Dispatch = (long)map_Biferno_Dispatch;
			}
			break;
		case kInit:
			err = Image_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Image_Constructor(pbPtr, message);
			break;
		case kDestructor:
			err = Image_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Image_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			// da fare
			break;

		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
	#pragma export off
#endif

//#endif
