/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: firebird_bfr.c,v 1.4 2005-06-07 15:15:35 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"
#include 	"BDBAPI.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include 	"ibase.h"

#define		MAX_FIELD_TITLE_LENGTH	63
#define		MAX_CONN_ITEM_LENGTH	255
#define		MAX_FIELD_DATA			1024

typedef struct
{		
	CStr255			name;
	BlockRef		bufferBlock;
	Ptr				buffer;
	short			flag;
	short			pad;
} FirebirdColumnDescr;

typedef struct
{		
	isc_stmt_handle		stmt;
	long				curPos;
	long				numCols;
	BlockRef			columnDescrBlock;
	XSQLDA				*sqldaP;
	BlockRef			sqldaBlock;
} FirebirdCursorRec;

typedef struct
{		
	CStr255				DbName;
	CStr255 			UserName;
	CStr255 			Password;
	isc_db_handle   	db;
	char				*dpb;
	Boolean				autocommit;
	Boolean				trans_started;
	short				pad2;
	isc_tr_handle		trans;
} FirebirdConnectionRec;

typedef struct
{
    short          vary_length;
    char           vary_string[1];
} VARY;

#ifndef ISC_INT64_FORMAT

/* Define a format string for printf.  Printing of 64-bit integers
   is not standard between platforms */

#if (defined(_MSC_VER) && defined(WIN32))
#define	ISC_INT64_FORMAT	"I64"
#else
#define	ISC_INT64_FORMAT	"ll"
#endif
#endif

static long			gsFirebirdClassID;
static long			gsApiVersion;
static BDBAPI_Rec	bdbRec;

#define	MAX_ERROR_MESSAGE		(255-3)
#define	ISC_ERROR(x)			(x[0] == 1 && x[1])
#define	ARBITRARY_INIT_XSQLDA	3

//===========================================================================================
static Boolean _fbAddToError(char *source, char *error)
{
int			available, curLen, sourceLen;
Boolean		finished;

	curLen = CLen(error);
	sourceLen = CLen(source);
	available = MAX_ERROR_MESSAGE - curLen;
	if (available > sourceLen)
	{	CAddStr(error, source);
		CAddStr(error, " - ");
		finished = false;
	}
	else if (available > 0)
	{	CopyBlock(error + curLen, source, available);
		error[curLen + available] = 0;
		CAddStr(error, "...");
		finished = true;
	}
	else
		finished = true;
	
return finished;
}

//===========================================================================================
static XErr _fbSetErrorMsg(char *error, ISC_STATUS_ARRAY status)
{
long		*pvector;
char		msg[512];
Boolean		finished, more;

	pvector = status;
	do
	{	if (more = isc_interprete(msg, &pvector))
		{	if (finished = _fbAddToError(msg, error))
				break;
		}
		else
			break;
	} while(1);
	if NOT(finished)
		error[CLen(error) - 3] = 0;		// remove last ' - '


return XError(kBAPI_ClassError, ErrDBMSError);
}

//===========================================================================================
static XErr	_fbTokenize(char *strP, long len, FirebirdConnectionRec *fbRecP)
{
Ptr				tempP;
long			tempLen;
Ptr				addrs[3];
int				k;
XErr			err = noErr;

	addrs[0] = fbRecP->DbName;
	addrs[1] = fbRecP->UserName;
	addrs[2] = fbRecP->Password;
	SkipSpaceAndTab(&strP, &len);
	if (len)
	{	tempP = strP;
		tempLen = 0;
		k = 0;
		do {
			if (len && ((*strP == ',') || (*strP == ' ') || (*strP == '\t')))
			{	SkipUntilChar(&strP, &len, ',', nil);
				if (len && (*strP != ','))
					err = XError(kBAPI_Error, Err_BadSyntax);
				else if (len)
				{	strP++;
					len--;
					SkipSpaceAndTab(&strP, &len);
				}
				if (tempLen < MAX_CONN_ITEM_LENGTH)
					CopyBlock(addrs[k], tempP, tempLen);
				else
					err = XError(kBAPI_Error, Err_StringTooLong);
				if NOT(err)
				{	addrs[k][tempLen] = 0;
					tempLen = 0;
					tempP = strP;
					k++;
				}
			}
			else
			{	strP++;
				len--;
				tempLen++;
			}
		} while ((len > 0) && (k < 3) && NOT(err));
		if NOT(err)
		{	if (len)
				err = XError(kBAPI_Error, Err_BadSyntax);
			else if (tempLen && (k < 4))
			{	if (tempLen < MAX_CONN_ITEM_LENGTH)
					CopyBlock(addrs[k], tempP, tempLen);
				else
					err = XError(kBAPI_Error, Err_StringTooLong);
				addrs[k][tempLen] = 0;
			}
		}
	}	

return err;
}

//===========================================================================================
static XErr	_fbDisposeColumns(FirebirdCursorRec	*cursorP)
{
FirebirdColumnDescr		*colDescrP;
int						i, numCols;

	if (cursorP->columnDescrBlock)
	{	colDescrP = (FirebirdColumnDescr*)GetPtr(cursorP->columnDescrBlock);
		numCols = cursorP->numCols;
		for (i = 0; i < numCols; i++, colDescrP++)
		{	if (colDescrP->bufferBlock)
				DisposeBlock(&colDescrP->bufferBlock);
		}
		DisposeBlock(&cursorP->columnDescrBlock);
	}
}

//===========================================================================================
static XErr	_fbDescribeColumns(FirebirdConnectionRec *fbRecP, FirebirdCursorRec	*cursorP)
{
XErr					err = noErr;
int						len, tSize, i, numCols;
FirebirdColumnDescr		*colDescrP;
XSQLVAR					*varP;
 
	numCols = cursorP->numCols;
	if (cursorP->columnDescrBlock = NewBlock(tSize = (numCols * sizeof(FirebirdColumnDescr)), &err, (Ptr*)&colDescrP))
	{	ClearBlock(colDescrP, tSize);
		varP = cursorP->sqldaP->sqlvar;
		for (i = 0; i < numCols; i++, colDescrP++, varP++)
		{	if (colDescrP->bufferBlock = NewBlock(cursorP->sqldaP->sqlvar[i].sqllen + 1 + sizeof(short), &err, &colDescrP->buffer))
			{	CEquStr(colDescrP->name, varP->sqlname);
				varP->sqldata = colDescrP->buffer;
				varP->sqlind  = &colDescrP->flag;
			}
			else
				break;
		}
		if (err)
			_fbDisposeColumns(cursorP);
	}

return err;
}

#ifdef __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_fbConnect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
FirebirdConnectionRec	*fbRecP;
BlockRef				connBlock = 0;
ConnectRec				*connectRecP = &pbPtr->param.connectRec;
short					dpb_length = 0;
ISC_STATUS_ARRAY		status;
int						userLen, pwdLen;
char					*copy;

	if (connBlock = NewBlock(sizeof(FirebirdConnectionRec), &err, (Ptr*)&fbRecP))
	{	ClearBlock(fbRecP, sizeof(FirebirdConnectionRec));
		if NOT(err = _fbTokenize(connectRecP->connString, connectRecP->connStringLen, fbRecP))
		{	userLen = CLen(fbRecP->UserName);
			pwdLen = CLen(fbRecP->Password);
			if (copy = fbRecP->dpb = (char*)malloc(userLen + pwdLen + 128))
			{	dpb_length = 0;		// expand if needed
				isc_expand_dpb(&fbRecP->dpb, &dpb_length, isc_dpb_user_name, fbRecP->UserName, isc_dpb_password, fbRecP->Password,  NULL);
				isc_attach_database(status, 0, fbRecP->DbName, &fbRecP->db, dpb_length, fbRecP->dpb); 
				if ISC_ERROR(status)
					err = _fbSetErrorMsg(pbPtr->error, status);
				else
				{	fbRecP->autocommit = true;
					connectRecP->connBufferLength = sizeof(FirebirdConnectionRec);
					connectRecP->connBuffer = connBlock;
					connectRecP->connPointer = nil;
				}
				free(copy);		// isc_expand_dpb reallocates it
			}
			else
			{	CEquStr(pbPtr->error, "Can't allocate DBP");
				err = XError(kBAPI_ClassError, ErrDBMSError);
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_fbFreeCallBack(long api_data, long db_api_data, Ptr cursorP, long userData, char *error)
{
XErr				err = noErr;
FirebirdCursorRec	*fb_cursorP = (FirebirdCursorRec*)cursorP;
ISC_STATUS_ARRAY	status;

	_fbDisposeColumns(fb_cursorP);
	if (fb_cursorP->sqldaBlock)
		DisposeBlock(&fb_cursorP->sqldaBlock);
	isc_dsql_free_statement(status, &fb_cursorP->stmt, DSQL_drop);
	if ISC_ERROR(status)
		err = _fbSetErrorMsg(error, status);

return err;
}

//===========================================================================================
static XErr	_fbDisconnect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
FirebirdConnectionRec	*fbRecP;
int						disposed, maxCursors, i, allocatedCursors;
long 					api_data = pbPtr->api_data;
DisconnectRec			*disconnectRecP = &pbPtr->param.disconnectRec;
ISC_STATUS_ARRAY		status;

	fbRecP = (FirebirdConnectionRec*)pbPtr->connBufferPtr;	
	if (fbRecP->autocommit && fbRecP->trans_started)
		 isc_commit_transaction(status, &fbRecP->trans);
	err = bdbRec.BDBAPI_DisposeAllCursorsSlots(pbPtr->api_data, pbPtr->db_api_data, _fbFreeCallBack, 0, pbPtr->error);
    isc_detach_database(status, &fbRecP->db);
    isc_free(fbRecP->dpb);
	DisposeBlock(&disconnectRecP->connBuffer);

return err;
}

//===========================================================================================
static XErr	_fbFreeResult(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
FreeResultRec			*freeResultRecP = &pbPtr->param.freeResultRec;

	err = bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, _fbFreeCallBack, 0, pbPtr->error);

return err;
}

//===========================================================================================
static XErr	_fbExec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
FirebirdConnectionRec	*fbRecP;
FirebirdCursorRec		*cursorP, cursoOnStack;
ExecRec					*execRecP = &pbPtr->param.execRec;
ISC_STATUS_ARRAY		status;

	if (execRecP->dontReturnCursor)
	{	cursorP = &cursoOnStack;
		ClearBlock(cursorP, sizeof(FirebirdCursorRec));
	}
	else
		err = bdbRec.BDBAPI_NewCursorSlot(pbPtr->api_data, pbPtr->db_api_data, &execRecP->cursorID, (Ptr*)&cursorP);
	if (err)
		return err;
	fbRecP = (FirebirdConnectionRec*)pbPtr->connBufferPtr;
	if (execRecP->cursorMode == kDynamic)
	{	CEquStr(pbPtr->error, "_Exec: Dynamic cursor not supported");
		return XError(kBAPI_ClassError, ErrDBMSError);
	}	
	else
	{	if (cursorP->sqldaBlock = NewBlock(XSQLDA_LENGTH(ARBITRARY_INIT_XSQLDA), &err, (Ptr*)&cursorP->sqldaP))
		{	cursorP->sqldaP->sqln = ARBITRARY_INIT_XSQLDA;
			cursorP->sqldaP->version = SQLDA_VERSION1;
			if (fbRecP->autocommit && NOT(fbRecP->trans_started))
			{	if (isc_start_transaction(status, &fbRecP->trans, 1, &fbRecP->db, 0, NULL))
					err = _fbSetErrorMsg(pbPtr->error, status);
				else
					fbRecP->trans_started = true;
			}
			if NOT(err)
			{	if NOT(isc_dsql_allocate_statement(status, &fbRecP->db, &cursorP->stmt))
				{	if NOT(isc_dsql_prepare(status, &fbRecP->trans, &cursorP->stmt, 0, execRecP->sqlStringP, SQL_DIALECT_CURRENT, cursorP->sqldaP))
					{	if NOT(isc_dsql_describe(status, &cursorP->stmt, 1, cursorP->sqldaP))
						{	cursorP->numCols = cursorP->sqldaP->sqld;
							cursorP->curPos = 1;
							if (cursorP->sqldaP->sqld)		// select statement
							{	if (cursorP->sqldaP->sqln < cursorP->sqldaP->sqld)		// Reallocate SQLDA if necessary
								{	if NOT(err = SetBlockSize(cursorP->sqldaBlock, XSQLDA_LENGTH(cursorP->numCols)))
									{	cursorP->sqldaP = (XSQLDA*)GetPtr(cursorP->sqldaBlock);
										cursorP->sqldaP->version = SQLDA_VERSION1;
										cursorP->sqldaP->sqln = cursorP->numCols;
										if (isc_dsql_describe(status, &cursorP->stmt, 1, cursorP->sqldaP))	// Re-describe the statement
											err = _fbSetErrorMsg(pbPtr->error, status);
									}
									else
										CEquStr(pbPtr->error, "Can't reallocate XSQLDA");
								}
							}
							if NOT(err)					
							{	if NOT(isc_dsql_execute(status, &fbRecP->trans, &cursorP->stmt, 1, NULL))
								{	if (cursorP->sqldaP->sqld)
										err = _fbDescribeColumns(fbRecP, cursorP);
									else
									{	if (fbRecP->autocommit)
										{	if (isc_commit_transaction(status, &fbRecP->trans))
												err = _fbSetErrorMsg(pbPtr->error, status);
											else
												fbRecP->trans_started = false;
										}
									}
								}
							}
						}
					}
				}
			}
			if (NOT(err) && ISC_ERROR(status))
			{	err = _fbSetErrorMsg(pbPtr->error, status);
				if (cursorP->stmt)
					isc_dsql_free_statement(status, &cursorP->stmt, DSQL_drop);
				/*if (fbRecP->trans_started && fbRecP->autocommit)	
				{	if NOT(isc_rollback_transaction(status, &fbRecP->trans))
						fbRecP->trans_started = false;
				}*/
			}
			if (err && cursorP->sqldaBlock)
				DisposeBlock(&cursorP->sqldaBlock);
		}
		else
			CEquStr(pbPtr->error, "Can't allocate XSQLDA");
	}
	if (execRecP->dontReturnCursor && NOT(err))
		_fbFreeCallBack(pbPtr->api_data, pbPtr->db_api_data, (Ptr)cursorP, 0, pbPtr->error);
	else if (err && NOT(execRecP->dontReturnCursor))
		bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, execRecP->cursorID, nil, 0, pbPtr->error);	// free the slot

return err;
}

//===========================================================================================
static void	_fbGetValue(XSQLVAR *var, char *data)
{
XErr		err = noErr;
short		dtype;
char		*p;
char		blob_s[20], date_s[25];
VARY		*vary;
short		len; 
struct tm	times;
ISC_QUAD	bid;

    dtype = var->sqltype & ~1;
    p = data;
    
    // Null handling.  If the column is nullable and null
    if ((var->sqltype & 1) && (*var->sqlind < 0))
    {
        switch (dtype)
        {
            case SQL_TEXT:
            case SQL_VARYING:
                len = var->sqllen;
                break;
            case SQL_SHORT:
                len = 6;
		if (var->sqlscale > 0) len += var->sqlscale;
                break;
            case SQL_LONG:
                len = 11;
		if (var->sqlscale > 0) len += var->sqlscale;
                break;
	    case SQL_INT64:
		len = 21;
		if (var->sqlscale > 0) len += var->sqlscale;
		break;
            case SQL_FLOAT:
                len = 15;
                break;
            case SQL_DOUBLE:
                len = 24;
                break;
	    case SQL_TIMESTAMP:
		len = 24;
		break;
	    case SQL_TYPE_DATE:
		len = 10;
		break;
	    case SQL_TYPE_TIME:
		len = 13;
		break;
            case SQL_BLOB:
            case SQL_ARRAY:
            default:
                len = 17;
                break;
        }
        if ((dtype == SQL_TEXT) || (dtype == SQL_VARYING))
            sprintf(p, "%-*s ", len, "NULL");
        else
            sprintf(p, "%*s ", len, "NULL");
    }
    else
    {
        switch (dtype)
        {
            case SQL_TEXT:
                if (var->sqllen <= MAX_FIELD_DATA)
                	sprintf(p, "%.*s ", var->sqllen, var->sqldata);
                break;

            case SQL_VARYING:
                vary = (VARY*)var->sqldata;
                vary->vary_string[vary->vary_length] = '\0';
                if (var->sqllen <= MAX_FIELD_DATA)
                	sprintf(p, "%-*s ", var->sqllen, vary->vary_string);
                break;

            case SQL_SHORT:
            case SQL_LONG:
	    case SQL_INT64:
		{
		ISC_INT64	value;
		short		field_width;
		short		dscale;
		switch (dtype)
		    {
		    case SQL_SHORT:
			value = (ISC_INT64) *(short *) var->sqldata;
			field_width = 6;
			break;
		    case SQL_LONG:
			value = (ISC_INT64) *(long *) var->sqldata;
			field_width = 11;
			break;
		    case SQL_INT64:
			value = (ISC_INT64) *(ISC_INT64 *) var->sqldata;
			field_width = 21;
			break;
		    }
		dscale = var->sqlscale;
		if (dscale < 0)
		    {
		    ISC_INT64	tens;
		    short	i;

		    tens = 1;
		    for (i = 0; i > dscale; i--)
			tens *= 10;

		    if (value >= 0)
			sprintf (p, "%*" ISC_INT64_FORMAT "d.%0*" ISC_INT64_FORMAT "d",
				field_width - 1 + dscale, 
				(ISC_INT64) value / tens,
				-dscale, 
				(ISC_INT64) value % tens);
		    else if ((value / tens) != 0)
			sprintf (p, "%*" ISC_INT64_FORMAT "d.%0*" ISC_INT64_FORMAT "d",
				field_width - 1 + dscale, 
				(ISC_INT64) (value / tens),
				-dscale, 
				(ISC_INT64) -(value % tens));
		    else
			sprintf (p, "%*s.%0*" ISC_INT64_FORMAT "d",
				field_width - 1 + dscale, 
				"-0",
				-dscale, 
				(ISC_INT64) -(value % tens));
		    }
		else if (dscale)
		    sprintf (p, "%*" ISC_INT64_FORMAT "d%0*d", 
			    field_width, 
			    (ISC_INT64) value,
			    dscale, 0);
		else
		    sprintf (p, "%*" ISC_INT64_FORMAT "d%",
			    field_width, 
			    (ISC_INT64) value);
		};
                break;

            case SQL_FLOAT:
                sprintf(p, "%15g ", *(float *) (var->sqldata));
                break;

            case SQL_DOUBLE:
		sprintf(p, "%24f ", *(double *) (var->sqldata));
                break;

	    case SQL_TIMESTAMP:
		isc_decode_timestamp((ISC_TIMESTAMP *)var->sqldata, &times);
		sprintf(date_s, "%04d-%02d-%02d %02d:%02d:%02d.%04d",
				times.tm_year + 1900,
				times.tm_mon+1,
				times.tm_mday,
				times.tm_hour,
				times.tm_min,
				times.tm_sec,
				((ISC_TIMESTAMP *)var->sqldata)->timestamp_time % 10000);
		sprintf(p, "%*s ", 24, date_s);
		break;

	    case SQL_TYPE_DATE:
		isc_decode_sql_date((ISC_DATE *)var->sqldata, &times);
		sprintf(date_s, "%04d-%02d-%02d",
				times.tm_year + 1900,
				times.tm_mon+1,
				times.tm_mday);
		sprintf(p, "%*s ", 10, date_s);
		break;

	    case SQL_TYPE_TIME:
		isc_decode_sql_time((ISC_TIME *)var->sqldata, &times);
		sprintf(date_s, "%02d:%02d:%02d.%04d",
				times.tm_hour,
				times.tm_min,
				times.tm_sec,
				(*((ISC_TIME *)var->sqldata)) % 10000);
		sprintf(p, "%*s ", 13, date_s);
		break;

            case SQL_BLOB:
            case SQL_ARRAY:
                /* Print the blob id on blobs or arrays */
                bid = *(ISC_QUAD *) var->sqldata;
                sprintf(blob_s, "%08x:%08x", bid.isc_quad_high, bid.isc_quad_low);
                sprintf(p, "%17s ", blob_s);
                break;

            default:
                break;
        }
    }
}

//===========================================================================================
static XErr	_fbFetchRec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
char					fieldData[MAX_FIELD_DATA];
FirebirdConnectionRec	*connP = (FirebirdConnectionRec*)pbPtr->connBufferPtr;
FirebirdCursorRec		*cursorP;
long					api_data = pbPtr->api_data;
FetchRec				*fetchRecP = &pbPtr->param.fetchRec;
ObjRef					arrayElement;
Boolean					undefNull, isNull;
int						fLen, zapped, res, i, numCols, length;
FirebirdColumnDescr		*colDescrP;
ISC_STATUS_ARRAY		status;

	undefNull = fetchRecP->undefNull;
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, fetchRecP->cursorID, (Ptr*)&cursorP))		
	{	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &fetchRecP->object))
		{	if (res = isc_dsql_fetch(status, &cursorP->stmt, 1, cursorP->sqldaP))
			{	if (res != 100)
					err = _fbSetErrorMsg(pbPtr->error, status);
			}
			else
			{	numCols = cursorP->numCols;
				colDescrP = (FirebirdColumnDescr*)GetPtr(cursorP->columnDescrBlock);
				for (i = 0; i < numCols; i++, colDescrP++)
				{	_fbGetValue(&cursorP->sqldaP->sqlvar[i], fieldData);
   					// Zap it
					fLen = CLen(fieldData);
					if (zapped = ZapText((Byte*)fieldData, fLen))
						fLen -= zapped;
					BAPI_InvalObjRef(api_data, &arrayElement);							
					isNull = (colDescrP->flag == -1);
					if NOT(isNull)
					{	length = *(short*)colDescrP->buffer;
						err = BAPI_StringToObj(api_data, fieldData, fLen, &arrayElement);
					}
					else
					{	if NOT(undefNull)
							err = BAPI_StringToObj(api_data, "", 0, &arrayElement);
					}
					if NOT(err)
					{	err = BAPI_ArrayAddElement(api_data, &fetchRecP->object, colDescrP->name, &arrayElement);
						if (err && (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName)))
						{	
						int			titleLen, index;
						CStr15		tStr;
						CStr255		aCStr;
						
							index = 2;
							titleLen = CLen(colDescrP->name);
							do {
								CNumToString(index++, tStr);
								if ((titleLen + 1 + CLen(tStr)) < 255)
								{	CEquStr(aCStr, colDescrP->name);
									CAddStr(aCStr, "_");
									CAddStr(aCStr, tStr);
									err = BAPI_ArrayAddElement(api_data, &fetchRecP->object, aCStr, &arrayElement);
								}
								else
								{	err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
									break;
								}
							} while (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName));
						}
					}
				}
				cursorP->curPos++;
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_fbTransaction(BDBAPI_ParamBlockPtr pbPtr, BDBAPI_Message message)
{
FirebirdConnectionRec	*fbRecP = (FirebirdConnectionRec*)pbPtr->connBufferPtr;
XErr					err = noErr;
ISC_STATUS_ARRAY		status;
int						res;

	switch(message)
	{
		case kTransaction:
			if NOT(res = isc_start_transaction(status, &fbRecP->trans, 1, &fbRecP->db, 0, NULL))
			{	fbRecP->autocommit = false;
				fbRecP->trans_started = true;
			}
			break;
		case kCommit:
			if NOT(res = isc_commit_transaction(status, &fbRecP->trans))
			{	fbRecP->autocommit = true;
				fbRecP->trans_started = false;
			}
			break;
		case kRollBack:
			if NOT(res = isc_rollback_transaction(status, &fbRecP->trans))
			{	fbRecP->autocommit = true;
				fbRecP->trans_started = false;
			}
			break;
	}
	if (res)
		err = _fbSetErrorMsg(pbPtr->error, status);


return err;
}

//===========================================================================================
static XErr	_fbTell(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
FirebirdConnectionRec	*fbRecP = (FirebirdConnectionRec*)pbPtr->connBufferPtr;
FirebirdCursorRec		*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, pbPtr->param.tellRec.cursorID, (Ptr*)&cursorP))
		pbPtr->param.tellRec.pos = cursorP->curPos;

out:
return err;
}

//===========================================================================================
static XErr	_fbSeek(BDBAPI_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
FirebirdConnectionRec	*fbRecP = (FirebirdConnectionRec*)pbPtr->connBufferPtr;
FirebirdCursorRec		*cursorP;
int						destpos, res, curPos;
ISC_STATUS_ARRAY		status;

	destpos = pbPtr->param.seekRec.pos;
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, pbPtr->param.seekRec.cursorID, (Ptr*)&cursorP))
	{	curPos = cursorP->curPos;
		if (destpos >= curPos)
		{	while(curPos < destpos)
			{	if (res = isc_dsql_fetch(status, &cursorP->stmt, 1, cursorP->sqldaP))
				{	err = _fbSetErrorMsg(pbPtr->error, status);
					break;
				}
				else
					curPos++;
			}
			cursorP->curPos = curPos;
		}
		else
		{	XError(kBAPI_ClassError, ErrDBMSError);
			CEquStr(pbPtr->error, "Backward seek is not supported");
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_FireBirdMapFetch(long cursorAddress, long *polyIDP, double *valueP, Boolean *isNullP)
{
XErr				err = noErr;
FirebirdCursorRec	*cursorP = (FirebirdCursorRec*)cursorAddress;
int					t;
void				*p;
int					res;
char				fieldData[MAX_FIELD_DATA];
short				dtype;
XSQLVAR				*var;
ISC_STATUS_ARRAY	status;

	if (cursorP->numCols >= 2)
	{	if (res = isc_dsql_fetch(status, &cursorP->stmt, 1, cursorP->sqldaP))
		{	if (res != 100)
				err = XError(kBAPI_ClassError, ErrDBMSError);
			*polyIDP = 0;
			*valueP = 0;
		}
		else
		{	cursorP->curPos++;
			_fbGetValue(&cursorP->sqldaP->sqlvar[0], fieldData);
			CStringToNum(fieldData, polyIDP);
			_fbGetValue(&cursorP->sqldaP->sqlvar[1], fieldData);
			*valueP = CStrToReal(fieldData);
			*isNullP = false;
			/*var = &cursorP->sqldaP->sqlvar[0];
			if ((var->sqltype & 1) && (*var->sqlind < 0))
				*polyIDP = 0;
			else
			{	dtype = var->sqltype & ~1;
				switch (dtype)
				{
					case SQL_SHORT:
						*polyIDP = (ISC_INT64) *(short *) var->sqldata;
						break;
					case SQL_LONG:
						*polyIDP = (ISC_INT64) *(long *) var->sqldata;
						break;
					case SQL_INT64:
						*polyIDP = (ISC_INT64) *(ISC_INT64 *) var->sqldata;
						break;
				}
			}
			var = &cursorP->sqldaP->sqlvar[1];
			if ((var->sqltype & 1) && (*var->sqlind < 0))
			{	*valueP = 0;
				*isNullP = true;
			}
			else
			{
				switch (dtype)
				{
					case SQL_SHORT:
						*valueP = (ISC_INT64) *(short *) var->sqldata;
						break;
					case SQL_LONG:
						*valueP = (ISC_INT64) *(long *) var->sqldata;
						break;
					case SQL_INT64:
						*valueP = (ISC_INT64) *(ISC_INT64 *) var->sqldata;
						break;
					case SQL_FLOAT:
						*valueP = *(float*)(var->sqldata);
						break;
					case SQL_DOUBLE:
						*valueP = *(double*)(var->sqldata);
						break;
					default:
						*valueP = 0;
						break;
				}
			}*/
		}
	}
	else
	{	*polyIDP = 0;
		*valueP = 0;
	}
	
return err;
}

#ifdef __MWERKS__
#pragma mark-
#endif
//===========================================================================================
/**
*	Function called by the db class.
*	This function is called by the db class.
*	\param	message	tells what event have been sent to this plugi->
*	\param	pbPtr	the param block containing the message for the class
*	
*/
#pragma export on
static XErr firebird_DBDispatch(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kConnect:
			err = _fbConnect(pbPtr);
			break;
		case kDisconnect:
			err = _fbDisconnect(pbPtr);
			break;
		case kExec:
			err = _fbExec(pbPtr);
			break;
		case kCall:
		case kCallExt:
		case kPrepare:
		case kRowSetSize:
		case kGetPrepared:
		case kBind:
		case kBindAll:
		case kExecPrepared:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kFreeResult:
			err = _fbFreeResult(pbPtr);
			break;
		case kSeek:
			err = _fbSeek(pbPtr);
			break;
		case kTell:
			err = _fbTell(pbPtr);
			break;
		case kWarning:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kGetCurRecs:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kGetAffectedRecs:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kFetchRec:
			err = _fbFetchRec(pbPtr);
			break;
		case kTransaction:
		case kCommit:
		case kRollBack:
			err = _fbTransaction(pbPtr, message);
			break;
		case kRealEscape:
		case kRealUnescape:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;		
		default:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
	}

return err;
}
#pragma export off

//===========================================================================================
static XErr	InitCallBacks(long api_data, BDBAPI_Rec *theRecP)
{
XErr					err = noErr;
BDBAPI_Init_CallBack	BDBAPI_Init_EP;

	if NOT(err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, "db", false), "BDBAPI_Init", (long*)&BDBAPI_Init_EP))
		err = BDBAPI_Init_EP(&bdbRec);

return err;
}

//===========================================================================================
static XErr	firebird_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	if NOT(err = InitCallBacks(api_data, &bdbRec))
	{	if NOT(err = bdbRec.BDBAPI_Register("firebird", firebird_DBDispatch, sizeof(FirebirdCursorRec), true))
			err = BAPI_RegisterSymbol(pbPtr->api_data, gsFirebirdClassID, "MapFetch", (long)_FireBirdMapFetch);
	}

out:	
return err;
}

//===========================================================================================
/**
*	Biferno Register Function.
*	Register the class returning some values (class name, description etc...) to biferno.
*/
static XErr	firebird_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
RegisterRec		*registerRecP = &pbPtr->param.registerRec;

	registerRecP->pluginType = kNewFunctionsPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, "firebird");
	CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft firebird native support");
	VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
	if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
		CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
	gsFirebirdClassID = pbPtr->param.registerRec.pluginID;
	
return err;
}

#pragma export on
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = firebird_Register(pbPtr);
			break;
		case kInit:
			err = firebird_Init(pbPtr);
			break;
		case kShutDown:
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#pragma export off
