/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: oracle_bfr.c,v 1.29 2006-10-24 12:46:05 valfer Exp $
	|______________________________________________________________________________
*/

// Methods
/*enum{
		kLobWrite = 1,
		kLobRead
	};
#define TOT_METHODES	2*/

//#ifdef WITH_OCI
#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"
#include 	"StaticClasses.h"
#include 	"DBConnectPool.h"

#include 	"BDBAPI.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include "oci.h"

#define		MAX_FIELD_TITLE_LENGTH			63
#define		MAX_ARRAY_ROW_SIZE				10000

#define		MAX_CONN_ITEM_LENGTH	255

#define	MAX_PARAMETERS				32
#define	DEFAULT_LONG_ALLOCATION		(1024L * 16L)	// 16 K

typedef struct
{		
	OCIServer		*serverHP;
	OCIError		*errorHP;
	OCISvcCtx		*serviceContextHP;
	OCISession		*sessionHP;
} BOCIPoolBuffer;

typedef struct
{		
	char 			title[MAX_FIELD_TITLE_LENGTH+1];
	long			maxSize;
	long			columnType;
	long			exType;
	long			npieces;
	//long			rowSetSize;
	BlockRef		boundVariableBlock;
	Ptr				boundVariableP;
	BlockRef		valueSizeIndicatorBlock;
	sb2				*valueSizeIndicatorP;
	BlockRef		valueLenBlock;
	ub2				*valueLenP;
} BOCI_ColumnDescr;

typedef struct
{		
	OCIStmt 			*stmtHP;
	long				curPos;
	long				firstFetched;
	long				lastFetched;
	long				realPos;
	Boolean				cursorExists;
	Boolean				pad;
	Boolean				fetchOff;
	Boolean				fromPool;
	Boolean				endOfCursor;	// ex notTotalBound;
	Boolean				isSelect;
	short				pad2;
	long				cursorType;
	long				rowArraySize;
	long				totRecs;
	long				totColumns;
	BlockRef			columnDescr;
	BOCI_ColumnDescr	*columnDescrP;
	CStr255				sqlString;
	BlockRef			sqlStringBlock;
	long				sqlStringLen;
	ub4					numRowsFetched;
	long				totParameters;
	long				longAllocation;
	BlockRef			parameters[MAX_PARAMETERS];
} BOCI_CursorRec;	

typedef struct
{		
	OCIServer		*serverHP;
	OCISvcCtx		*serviceContextHP;
	OCISession		*sessionHP;
	OCIError		*errorHP;
	CStr255			errMsg;
	CStr255			warning;
	long			slot;
	long			poolConnectIndex;
	Boolean			inTransaction;
	Byte			pad1;
	short			pad2;
} BOCI_Rec;

/*typedef struct
{		
	CStr255			name;		// name of the biferno bound obj
	char			staticStorage[MAX_BOUND_PARAM_LENGTH + 1];
	Ptr				valueP;
	BlockRef		valueBlock;
	long			valueStorage;
	long			paramNum;
	long			length;
	long			mode;
} BOCI_ParameterDescr;*/

typedef struct
{
	PrepareRec		*prepareRecP;
	BOCI_Rec		*ociRecP;
	Ptr				sqlStringP;
	long			sqlStringLen;
} PrepareCallBackRec;

typedef struct {
				BOCI_Rec	*ociRecP;
				BindRec		*bindRecP;
				} BindRecord;

#define	BOCI_ClassName		"oracle"

static	OCIEnv				*gsEnvHP = nil;
static	long				oracleClassID;
static	long				gsApiVersion, gsMaxUsers;
//static	long				gsStringClassID;
static	PoolRef				gsBOCIRecPoolRef = 0;
static	BlockRef			gsPoolConnectRecBlock = 0;
static	PoolConnectRec		*gsPoolConnectRecP;
static	BDBAPI_Rec			bdbRec;

#define	COUNT_STR		"SELECT COUNT(*) "
#define	COUNT_STR_LEN	16

//===========================================================================================
static void _bociErrorString(OCIError *errorHP, char *resultString)
{
b4			errcode;
text		errbuf[512];
int			buffLen;

	if (errorHP)
	{	if NOT(OCIErrorGet((dvoid*)errorHP, (ub4)1, (text*)NULL, &errcode, errbuf, (ub4)sizeof(errbuf), (ub4)OCI_HTYPE_ERROR))
		{	buffLen = CLen((char*)errbuf);
			if (buffLen > 255)
				buffLen = 255;
			CopyBlock(resultString, errbuf, buffLen);
			resultString[buffLen] = 0;
		}
		else
			*resultString = 0;
	}
	else
		*resultString = 0;
}

//===========================================================================================
static Boolean	_bociErr(BOCI_Rec *ociRecP, XErr *errP, char *message)
{
Boolean		stopProcess = true;
CStr255		aCStr;
char		*mgsP;

	if (ociRecP)
		mgsP = ociRecP->errMsg;
	else
	{	mgsP = aCStr;
		*aCStr = 0;
	}
	switch(*errP)
	{
	case OCI_SUCCESS:
		stopProcess = false;
		break;
	case OCI_SUCCESS_WITH_INFO:
		stopProcess = false;
		_bociErrorString(ociRecP->errorHP, mgsP);
		_bociErrorString(ociRecP->errorHP, ociRecP->warning);
		break;
	case OCI_NEED_DATA:
		CEquStr(mgsP, "Error - OCI_NEED_DATA\n");
		break;
	case OCI_NO_DATA:
		CEquStr(mgsP, "Error - OCI_NODATA\n");
		break;
	case OCI_ERROR:
		if (ociRecP && ociRecP->errorHP)
			_bociErrorString(ociRecP->errorHP, mgsP);
		break;
	case OCI_INVALID_HANDLE:
		CEquStr(mgsP, "Error - OCI_INVALID_HANDLE\n");
		break;
	case OCI_STILL_EXECUTING:
		CEquStr(mgsP, "Error - OCI_STILL_EXECUTE\n");
		break;
	case OCI_CONTINUE:
		CEquStr(mgsP, "Error - OCI_CONTINUE\n");
		break;
	default:
		break;
	}
	if (message)
		CEquStr(message, mgsP);
	if (stopProcess)
		*errP = XError(kBAPI_ClassError, ErrDBMSError);
		
return stopProcess;
}

//===========================================================================================
static XErr	_bociSetError(BOCI_Rec *ociRecP, char *optString)
{
CStr255		nativeStr, errorNumberStr, localString;
OCIError 	*errorHP;
char		*mgsP;

	if (ociRecP)
	{	mgsP = ociRecP->errMsg;
		errorHP = ociRecP->errorHP;
		_bociErrorString(errorHP, nativeStr);
	}
	else
	{	mgsP = localString;
		*localString = 0;
		*nativeStr = 0;
	}
	CEquStr(mgsP, ":");
	CNumToString(ErrDBMSError, errorNumberStr);
	CAddStr(mgsP, errorNumberStr);
	CAddStr(mgsP, ":oci:");
	if (optString)
		CAddStr(mgsP, optString);
	if (*nativeStr)
	{	CAddStr(mgsP, " - ");
		CAddStr(mgsP, nativeStr);
	}
	
return XError(kBAPI_ClassError, ErrDBMSError);
}

#ifdef __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_bociFreeColumnsDefines(BOCI_CursorRec *cursorP)
{
XErr				err = noErr;
BOCI_ColumnDescr	*descrP;
int					rowSet, totCols, i, j;
OCILobLocator		**lobArrayP;

	if (cursorP->columnDescr)
	{	descrP = cursorP->columnDescrP;
		totCols = cursorP->totColumns;
		for (i = 0; i < totCols; i++, descrP++)
		{	if (descrP->boundVariableBlock)
			{	// Dispose LOB locators (if any)
				if ((descrP->columnType == SQLT_CLOB) || (descrP->columnType == SQLT_BLOB))
				{	rowSet = cursorP->rowArraySize;
					lobArrayP = (OCILobLocator**)descrP->boundVariableP;
					for (j = 0; j < rowSet; j++)
						OCIDescriptorFree((dvoid *)lobArrayP[j], (ub4)OCI_DTYPE_LOB);
				}
				DisposeBlock(&descrP->boundVariableBlock);
			}
			if (descrP->valueSizeIndicatorBlock)
				DisposeBlock(&descrP->valueSizeIndicatorBlock);
			if (descrP->valueLenBlock)
				DisposeBlock(&descrP->valueLenBlock);
		}
		if (cursorP->columnDescr)
			DisposeBlock(&cursorP->columnDescr);
	}
	
return err;
}

//===========================================================================================
static XErr	_bociFreeNormalCursor(BOCI_CursorRec *cursorP, BOCI_Rec *ociRecP)
{
XErr	err = noErr;
	
	_bociFreeColumnsDefines(cursorP);
	if (cursorP->sqlStringBlock)
		DisposeBlock(&cursorP->sqlStringBlock);
	if (cursorP->cursorExists && cursorP->stmtHP)
	{	err = OCIHandleFree(cursorP->stmtHP, OCI_HTYPE_STMT);
		_bociErr(ociRecP, &err, nil);
	}
	
return err;
}

//===========================================================================================
static void	_bociFreeParameters(BOCI_CursorRec *cursorP)
{
	bdbRec.BDBAPI_DisposeParams(0, 0, cursorP->parameters, cursorP->totParameters);
	cursorP->totParameters = 0;
	/*if (totParameters = cursorP->totParameters)
	{	for (i = 0; i < MAX_PARAMETERS; i++)
		{	if (tBl = cursorP->parameters[i])
			{	paramDescrP = (BOCI_ParameterDescr*)GetPtr(tBl);
				if (paramDescrP->valueBlock)
					DisposeBlock(&paramDescrP->valueBlock);
				DisposeBlock(&cursorP->parameters[i]);
				if NOT(--totParameters)
					break;
			}
		}
		cursorP->totParameters = 0;
	}*/
}

//===========================================================================================
static XErr	_bociFreePreparedCursor(BOCI_CursorRec *cursorP, BOCI_Rec *ociRecP, char *error, Boolean disposeStmt, Boolean freeColumnsDefines)
{
XErr				err = noErr;

	XThreadsEnterCriticalSection();
	if (cursorP->fromPool)
	{	_bociFreeParameters(cursorP);
		if (disposeStmt)
		{	err = OCIHandleFree(cursorP->stmtHP, OCI_HTYPE_STMT);
			_bociErr(ociRecP, &err, nil);
		}
		if (freeColumnsDefines)
			_bociFreeColumnsDefines(cursorP);
	}
	else
		err = _bociSetError(ociRecP, "_FreePrepared: Not a prepared Cursor");
	XThreadsLeaveCriticalSection();

if (err)
	CEquStr(error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	_bociFreePreparedCursorCB(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
#ifdef __MWERKS__
#pragma unused(api_data, error)
#endif
BOCI_CursorRec		*cursorP = (BOCI_CursorRec*)the_cursorP;
BOCI_Rec			*ociRecP = (BOCI_Rec*)userData;

	_bociFreePreparedCursor(cursorP, ociRecP, error, true, true);

return noErr;
}

#ifdef __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_bociCloseSessionCB(Ptr buffer)
{
BOCIPoolBuffer	*pBuffP = (BOCIPoolBuffer*)buffer;
XErr			err = noErr;
	
	err = OCISessionEnd(pBuffP->serviceContextHP, pBuffP->errorHP, pBuffP->sessionHP, OCI_DEFAULT);

	err = OCIServerDetach(pBuffP->serverHP, pBuffP->errorHP, OCI_DEFAULT);
	
	err = OCIHandleFree(pBuffP->serverHP, OCI_HTYPE_SERVER);
	
	err = OCIHandleFree(pBuffP->errorHP, OCI_HTYPE_ERROR);

	err = OCIHandleFree(pBuffP->serviceContextHP, OCI_HTYPE_SVCCTX);

	err = OCIHandleFree(pBuffP->sessionHP, OCI_HTYPE_SESSION);	// ?

return err;
}

//===========================================================================================
static XErr	_bociTokenizeConnString(char *strP, long len, char *instance, char *username, char *password)
{
Ptr		tempP;
long	tempLen;
Ptr		addrs[3];
int		k;
XErr	err = noErr;

	addrs[0] = instance;
	addrs[1] = username;
	addrs[2] = password;
	SkipSpaceAndTab(&strP, &len);
	if (len)
	{	tempP = strP;
		tempLen = 0;
		k = 0;
		do {
			if (len && ((*strP == ',') || (*strP == ' ') || (*strP == '\t')))
			{	SkipUntilChar(&strP, &len, ',', nil);
				if (len && (*strP != ','))
					err = XError(kBAPI_Error, Err_BadSyntax);
				else if (len)
				{	strP++;
					len--;
					SkipSpaceAndTab(&strP, &len);
				}
				if (tempLen < MAX_CONN_ITEM_LENGTH)
					CopyBlock(addrs[k], tempP, tempLen);
				else
					err = XError(kBAPI_Error, Err_StringTooLong);
				if NOT(err)
				{	addrs[k][tempLen] = 0;
					tempLen = 0;
					tempP = strP;
					k++;
				}
			}
			else
			{	strP++;
				len--;
				tempLen++;
			}
		} while ((len > 0) && (k < 3) && NOT(err));
		if NOT(err)
		{	if (len)
				err = XError(kBAPI_Error, Err_BadSyntax);
			else if (tempLen && (k < 4))
			{	if (tempLen < MAX_CONN_ITEM_LENGTH)
					CopyBlock(addrs[k], tempP, tempLen);
				else
					err = XError(kBAPI_Error, Err_StringTooLong);
				addrs[k][tempLen] = 0;
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_bociPlaceHoders(Ptr *sqlStringP, long *sqlStringLen, char *cStr, BlockRef *blockP)
{
XErr		err = noErr;
long		sLen = *sqlStringLen;
Ptr			pToAdd, sP = *sqlStringP, p;
BufferID	resBuffID;
long		po_idx, lenToAdd;
int			ch;
CStr63		tStr, poStr;

	*blockP = 0;
	resBuffID = 0;
	if (sLen)
	{	if (resBuffID = BufferCreate(256, &err))
		{	lenToAdd = 0;
			pToAdd = (Ptr)sP;
			po_idx = 1;
			do	{
				ch = *sP++;
				sLen--;
				switch(ch)
				{
					case '\'':
						if (*sP == '\'')
						{	sP++;
							sLen--;
							lenToAdd += 2;
						}
						else
						{	lenToAdd++;
							if (err = BufferAddBuffer(resBuffID, pToAdd, lenToAdd))
								goto out;
							pToAdd = (Ptr)sP;
							lenToAdd = 0;
							do
							{	ch = *sP++;
								sLen--;
								lenToAdd++;
								if (ch == '\'')
								{	if (sLen && (*sP == '\''))
									{	ch = *sP++;
										sLen--;
										lenToAdd++;
									}	
									else
										break;
								}
							} while (sLen);
							if (err = BufferAddBuffer(resBuffID, pToAdd, lenToAdd))
								goto out;
							pToAdd = (Ptr)sP;
							lenToAdd = 0;
						}
						break;
					
					case '?':
						if (err = BufferAddBuffer(resBuffID, pToAdd, lenToAdd))
							goto out;
						pToAdd = (Ptr)sP;
						lenToAdd = 0;
						CNumToString(po_idx++, tStr);
						CEquStr(poStr, ":");
						CAddStr(poStr, tStr);
						if (err = BufferAddCString(resBuffID, poStr, NO_ENC, 0))
							goto out;
						break;
						
					default:
						lenToAdd++;
						break;
				}
			} while((sLen > 0) && NOT(err));
			if NOT(err)
			{	// last part
				if (err = BufferAddBuffer(resBuffID, pToAdd, lenToAdd))
					goto out;
				if (err = BufferAddChar(resBuffID, 0))
					goto out;
				*blockP = BufferGetBlockRefExtSize(resBuffID, sqlStringLen, sqlStringP);
				(*sqlStringLen)--;
				BufferClose(resBuffID);
			}
		}
	}
	else
	{	if (sLen < 255)
		{	CEquStr(cStr, sP);
			*sqlStringP = cStr;
			*sqlStringLen = sLen;
		}
		else if (*blockP = NewBlock(sLen+1, &err, &p))
		{	CopyBlock(p, sP, sLen);
			p[sLen] = 0;
			*sqlStringLen = sLen;
		}
	}
out:
if (err && resBuffID)
	BufferFree(resBuffID);
return err;
}

//===========================================================================================
static XErr	_bociSaveQuery(BOCI_CursorRec *cursorP, char *sqlStringP, long sqlStringLen)
{
XErr	err = noErr;
Ptr		p;

	if (cursorP->sqlStringBlock)
		DisposeBlock(&cursorP->sqlStringBlock);
	if (sqlStringLen < 255)
	{	CEquStr(cursorP->sqlString, sqlStringP);
		cursorP->sqlStringBlock = 0;
		cursorP->sqlStringLen = sqlStringLen;
	}
	else if (cursorP->sqlStringBlock = NewBlock(sqlStringLen+1, &err, &p))
	{	CopyBlock(p, sqlStringP, sqlStringLen);
		p[sqlStringLen] = 0;
		cursorP->sqlStringLen = sqlStringLen;
	}

return err;
}

//===========================================================================================
static XErr	_bociExecuteQuery(BOCI_CursorRec *cursorP, char *sqlStringP, long sqlStringLen, Boolean onlyPrepare, Boolean firstTime, BOCI_Rec *ociRecP, char *error)
{
XErr		err = noErr;
Boolean		doIt = true, noRecordsInSelection = false;
ub4			prefetch = 0, iters, mode;
ub2			queryType;

	if (err = _bociSaveQuery(cursorP, sqlStringP, sqlStringLen))
		goto out;		
	if (firstTime)
	{	err = OCIHandleAlloc((dvoid*)gsEnvHP, (dvoid**)&cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, 0, (dvoid**)0);
		if (_bociErr(ociRecP, &err, error))
			goto out;
		else
			cursorP->cursorExists = true;
	}
	err = OCIStmtPrepare(cursorP->stmtHP, ociRecP->errorHP, (text*)sqlStringP, (ub4)sqlStringLen, (ub4)OCI_NTV_SYNTAX, (ub4)OCI_DEFAULT);
	if (_bociErr(ociRecP, &err, error))
		goto out;

	// Disable prefetch
	err = OCIAttrSet((dvoid *)cursorP->stmtHP,(ub4)OCI_HTYPE_STMT, &prefetch, (ub4)0, (ub4)OCI_ATTR_PREFETCH_ROWS, ociRecP->errorHP);
	if (_bociErr(ociRecP, &err, error))
		goto out;
	err = OCIAttrSet((dvoid *)cursorP->stmtHP,(ub4)OCI_HTYPE_STMT, &prefetch, (ub4)0, (ub4)OCI_ATTR_PREFETCH_MEMORY, ociRecP->errorHP);
	if (_bociErr(ociRecP, &err, error))
		goto out;

	err = OCIAttrGet((dvoid*)cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, (dvoid*)&queryType, (ub4*)0, (ub4)OCI_ATTR_STMT_TYPE, ociRecP->errorHP);
	if (_bociErr(ociRecP, &err, error))
		goto out;
	if (queryType == OCI_STMT_SELECT)
	{	iters = 0;
		cursorP->isSelect = true;
	}
	else
	{	iters = 1;
		cursorP->isSelect = false;
	}
	if (onlyPrepare)
	{	mode = OCI_DESCRIBE_ONLY;
		if NOT(cursorP->isSelect)
			doIt = false;
	}
	else
	{	if ((ociRecP->inTransaction) || (queryType == OCI_STMT_SELECT))
			mode = OCI_DEFAULT;
		else
			mode = OCI_COMMIT_ON_SUCCESS;
	}
	if (doIt)
	{	err = OCIStmtExecute(ociRecP->serviceContextHP, cursorP->stmtHP, ociRecP->errorHP, (ub4)iters, (ub4) 0, (OCISnapshot*)NULL, (OCISnapshot*) NULL, mode);
		if (err == OCI_NO_DATA)
		{	err = noErr;
			noRecordsInSelection = true;
		}
		else if (_bociErr(ociRecP, &err, error))
			goto out;
		if (firstTime)
		{	cursorP->curPos = 1;
			if NOT(noRecordsInSelection)
				cursorP->totRecs = -1;
		}
		cursorP->realPos = 1;
	}
out:
if (err)
{	if (firstTime && cursorP->stmtHP)
	{	OCIHandleFree(cursorP->stmtHP, OCI_HTYPE_STMT);
		cursorP->stmtHP = nil;
	}
	if (cursorP->sqlStringBlock)
		DisposeBlock(&cursorP->sqlStringBlock);
}
return err;
}

//===========================================================================================
/*static sb4 _boci_ocbfp(ctxp, dfnhp, iter, bufpp, alenpp, piecep, indpp, rcpp)
dvoid		*ctxp;
OCIDefine	*dfnhp;
ub4			iter;	// is 0-based
dvoid		**bufpp;
ub4			**alenpp;
ub1			*piecep;
dvoid		**indpp;
ub2			**rcpp;
{
#pragma unused(dfnhp)
XErr				err = noErr;
BOCI_ColumnDescr	*descrP = (BOCI_ColumnDescr*)ctxp;
long				itemSize;

	switch(*piecep)
	{
		case OCI_ONE_PIECE:
			itemSize = LONG_CHUNCK_SIZE;
			break;
		case OCI_FIRST_PIECE:
			itemSize = LONG_CHUNCK_SIZE;
			(descrP->npieces)++;
			break;
		case OCI_NEXT_PIECE:
			itemSize = LONG_CHUNCK_SIZE * descrP->npieces;
			(descrP->npieces)++;
			break;
		case OCI_LAST_PIECE:
			itemSize = LONG_CHUNCK_SIZE * descrP->npieces;
			break;
	}
	if NOT(err = SetBlockSize(descrP->boundVariableBlock, itemSize * descrP->rowSetSize))
	{	descrP->boundVariableP = GetPtr(descrP->boundVariableBlock);	// reload
		*bufpp = descrP->boundVariableP + (iter * itemSize);
		*rcpp = (void*)&gsDummyUb4;
		*alenpp = (ub4*)((Ptr)descrP->valueLenP + (iter * sizeof(ub4)));
		**alenpp = itemSize;
		*indpp = descrP->valueSizeIndicatorP + iter;
	}

return OCI_CONTINUE;
}*/

//===========================================================================================
static XErr	_bociDefineAllColumns(BOCI_CursorRec *cursorP, BOCI_Rec *ociRecP, Boolean alsoDefine, char *error, Boolean zeroDefs, Boolean noSetBlockSize)
{
BOCI_ColumnDescr	*descrP;
XErr				err = noErr;
long				s, totCols;
OCIParam 			*param;
OCIError			*errorHP = ociRecP->errorHP;
char				*strP;
long				index, totSize, strLen;
//ub2					maxSize;
OCIDefine			*defnp;
OCILobLocator     	**lobArrayP = nil;
int					t, i, rowSet;
//sb2					*vsizeP;
//ub2					*vlenP;
int					tsize;	//, mode;

	// Get the number of columns
	err = OCIAttrGet((dvoid*)cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, (dvoid*)&totCols, (ub4*)0, (ub4)OCI_ATTR_PARAM_COUNT, ociRecP->errorHP);
	if (_bociErr(ociRecP, &err, error))
		goto out;
	if (totCols)
	{	// Get the first attr param
		rowSet = cursorP->rowArraySize;
		err = OCIParamGet(cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, errorHP, (dvoid*)&param, (ub4)1);
		if (_bociErr(ociRecP, &err, error))
			goto out;
		cursorP->totColumns = totCols;
		totSize = sizeof(BOCI_ColumnDescr) * totCols;
		if NOT(cursorP->columnDescr)
		{	if (cursorP->columnDescr = NewPtrBlock(totSize, &err, (Ptr*)&cursorP->columnDescrP))
			{	descrP = cursorP->columnDescrP;
				ClearBlock(descrP, totSize);
			}
		}
		else
			descrP = cursorP->columnDescrP;
		if NOT(err)
		{	index = 1;
			do
			{	err = OCIAttrGet((dvoid*)param, (ub4)OCI_DTYPE_PARAM, (dvoid*)&strP, (ub4*)&strLen, (ub4)OCI_ATTR_NAME, (OCIError*)errorHP);
				if (_bociErr(ociRecP, &err, error))
					goto out;
				if (strLen > MAX_FIELD_TITLE_LENGTH)
					strLen = MAX_FIELD_TITLE_LENGTH;	// just in case
				CopyBlock(descrP->title, strP, strLen);
				descrP->title[strLen] = 0;
				// Get the external type
				err = OCIAttrGet((dvoid*)param, (ub4)OCI_DTYPE_PARAM, (dvoid*)&descrP->columnType, (ub4*)0, (ub4)OCI_ATTR_DATA_TYPE, (OCIError*)errorHP);
				if (_bociErr(ociRecP, &err, error))
					goto out;
				switch(descrP->columnType)
				{
					case SQLT_CLOB:
					case SQLT_BLOB:
						descrP->maxSize = sizeof(OCILobLocator*);
						descrP->exType = descrP->columnType;
						if (descrP->boundVariableBlock)
						{	if NOT(noSetBlockSize)
								err = SetBlockSize(descrP->boundVariableBlock, descrP->maxSize * rowSet);
						}
						else
						{	descrP->boundVariableBlock = NewBlock(descrP->maxSize * rowSet, &err, nil);
							LockBlock(descrP->boundVariableBlock);
						}
						if NOT(err)
						{	// Allocate the LOB locator
							descrP->boundVariableP = GetPtr(descrP->boundVariableBlock);
							lobArrayP = (OCILobLocator**)descrP->boundVariableP;
							ClearBlock(lobArrayP, sizeof(OCILobLocator*) * rowSet);
							for (i = 0; i < rowSet; i++)
							{	err = OCIDescriptorAlloc((dvoid*)gsEnvHP, (void**)&lobArrayP[i], (ub4)OCI_DTYPE_LOB, (size_t)0, (dvoid **)0);
								if (_bociErr(ociRecP, &err, error))
									goto out;
							}
						}
						break;
						
					default:
						if ((t = descrP->columnType) == SQLT_DAT)
						{	//mode = OCI_DEFAULT;
							descrP->maxSize = 256;
						}
						else if (t == SQLT_LNG)
						{	//mode = OCI_DYNAMIC_FETCH;
							descrP->maxSize = cursorP->longAllocation;
							//descrP->rowSetSize = rowSet;
						}
						else
						{	//mode = OCI_DEFAULT;
							err = OCIAttrGet((dvoid*)param, (ub4)OCI_DTYPE_PARAM, (dvoid*)&descrP->maxSize, (ub4*)0, (ub4)OCI_ATTR_DATA_SIZE, (OCIError*)errorHP);
							if (_bociErr(ociRecP, &err, error))
								goto out;
						}
						//descrP->maxSize = maxSize;
						descrP->exType = SQLT_CHR;
						if (descrP->boundVariableBlock)
						{	if NOT(noSetBlockSize)
								err = SetBlockSize(descrP->boundVariableBlock, descrP->maxSize * rowSet);
						}
						else
						{	descrP->boundVariableBlock = NewBlock(descrP->maxSize * rowSet, &err, nil);
							LockBlock(descrP->boundVariableBlock);
						}
						if NOT(err)
							descrP->boundVariableP = GetPtr(descrP->boundVariableBlock);
						break;
				}
				if NOT(err)
				{	if (descrP->valueSizeIndicatorBlock)
					{	//if NOT(noSetBlockSize)
							err = SetBlockSize(descrP->valueSizeIndicatorBlock, sizeof(sb2) * rowSet);
					}
					else
					{	descrP->valueSizeIndicatorBlock = NewBlock(sizeof(sb2) * rowSet, &err, nil);
						LockBlock(descrP->valueSizeIndicatorBlock);
					}
					if NOT(err)
					{	descrP->valueSizeIndicatorP = (sb2*)GetPtr(descrP->valueSizeIndicatorBlock);
						/*if (mode == OCI_DYNAMIC_FETCH)
							tsize = sizeof(ub4);
						else*/
						tsize = sizeof(ub2);
						if (descrP->valueLenBlock)
						{	//if NOT(noSetBlockSize)
								err = SetBlockSize(descrP->valueLenBlock, tsize * rowSet);
						}
						else
						{	descrP->valueLenBlock = NewBlock(tsize * rowSet, &err, nil);
							LockBlock(descrP->valueLenBlock);
						}
						if NOT(err)
						{	descrP->valueLenP = (ub2*)GetPtr(descrP->valueLenBlock);
							if (alsoDefine)
							{	if (zeroDefs)
								{	//vsizeP = nil;
									//vlenP = nil;
									s = 0;
								}
								else
								{	//vsizeP = descrP->valueSizeIndicatorP;
									//vlenP = descrP->valueLenP;
									s = descrP->maxSize;
								}
								err = OCIDefineByPos(cursorP->stmtHP, &defnp, errorHP, (ub4)index, (dvoid*)descrP->boundVariableP, (sb4)s, descrP->exType, (dvoid*)descrP->valueSizeIndicatorP, (ub2*) descrP->valueLenP, (ub2*)0, (ub4)OCI_DEFAULT);
								if (_bociErr(ociRecP, &err, error))
									goto out;
								err = OCIDefineArrayOfStruct(defnp, errorHP, s, sizeof(ub2), sizeof(ub2), 0);
								if (_bociErr(ociRecP, &err, error))
									goto out;
								/*if (mode == OCI_DYNAMIC_FETCH)
								{	err = OCIDefineDynamic(defnp, errorHP, (dvoid*)descrP, (OCICallbackDefine)_boci_ocbfp);
 									if (_bociErr(ociRecP, &err, error))
										goto out;
								}*/
							}
						}
					}
				}
				if (index >= totCols)
					break;
				else
				{	// Get the Next Param
					err = OCIParamGet(cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, errorHP, (dvoid*)&param, (ub4)++index);
					if (_bociErr(ociRecP, &err, error))
						goto out;
					descrP++;
				}
			} while NOT(err);
			if (err)
				DisposeBlock(&cursorP->columnDescr);
		}
	}
	else
		cursorP->cursorExists = false;
	
out:
return err;
}

//===========================================================================================
static XErr	_bociRedefineColumns(BOCI_CursorRec *cursorP, BOCI_Rec *ociRecP, char *error)
{	
XErr				err = noErr;
int					totCols;
BOCI_ColumnDescr	*descrP;
//OCIStmt 			*hstmt  = cursorP->stmtHP;
int					i;
OCIDefine			*defnp;
OCIError			*errorHP = ociRecP->errorHP;

	if (cursorP->isSelect)
	{	descrP = cursorP->columnDescrP;
		totCols = cursorP->totColumns;
		for (i = 1; (i <= totCols) && NOT(err); i++, descrP++)
		{	err = OCIDefineByPos(cursorP->stmtHP, &defnp, errorHP, (ub4)i, (dvoid*)descrP->boundVariableP, (sb4)descrP->maxSize, descrP->exType, (dvoid*)descrP->valueSizeIndicatorP, (ub2*)descrP->valueLenP, (ub2*)0, (ub4)OCI_DEFAULT);
			if (_bociErr(ociRecP, &err, error))
				break;
			err = OCIDefineArrayOfStruct(defnp, errorHP, descrP->maxSize, sizeof(ub2), sizeof(ub2), 0);
			if (_bociErr(ociRecP, &err, error))
				break;
		}
	}
	
return err;
}

//===========================================================================================
/*static BOCI_CursorRec*	_bociGetCursorP(long api_data, BOCI_Rec *ociRecP, long cursID, Boolean poolMandatory)
{
long			cursRealID, poolID;
BOCI_CursorRec	*cursorP = nil;

	_GetCursorValueCB(api_data, cursID, &poolID, &cursRealID);
	if (poolID)
	{	BlockRef	preparedBlock;
	
		if ((poolID > 0) && (poolID <= ociRecP->totPrepared))
		{	preparedBlock = ociRecP->prepared[poolID-1].block;
			cursorP = ((BOCI_CursorRec*)GetPtr(preparedBlock)) + (cursRealID - 1);
		}
	}
	else if (poolMandatory)
		cursorP = nil;
	else
		cursorP = &ociRecP->cursor[cursRealID-1];
	
return cursorP;
}
*/
//===========================================================================================
static XErr	_bociLOBToObj(long api_data, BOCI_Rec *ociRecP, OCILobLocator *lobLocator, ObjRef *objRefP)
{
XErr		err = noErr;
ub4			len;
Ptr			textP;
BlockRef	block;

	err = OCILobGetLength(ociRecP->serviceContextHP, ociRecP->errorHP, lobLocator, &len);
	if NOT(_bociErr(ociRecP, &err, nil))
	{	if (len)
		{	if (block = NewPtrBlock(len, &err, &textP))
			{	err = OCILobRead(ociRecP->serviceContextHP, ociRecP->errorHP, lobLocator, &len, 1, textP, len, nil, nil, nil, SQLCS_IMPLICIT);
				if NOT(_bociErr(ociRecP, &err, nil))
					err = BAPI_StringToObj(api_data, textP, len, objRefP);
				DisposeBlock(&block);
			}
		}
		else
			err = BAPI_StringToObj(api_data, "", 0, objRefP);	
	}
	
return err;
}
//===========================================================================================
// per ora non usata
/*static XErr	_bociLOBToObjAlternative(long api_data, BOCI_Rec *ociRecP, OCILobLocator *lobLocator, ObjRef *objRefP)
{
XErr		err = noErr;
Ptr			textP;
BlockRef	block;
ub4			chunk_size, toRead;
long		curSize, offset, totLen;

	if NOT(err = OCILobGetChunkSize (ociRecP->serviceContextHP, ociRecP->errorHP, lobLocator, &chunk_size))
	{	curSize = chunk_size;
		if (block = NewBlock(chunk_size, &err, &textP))
		{	offset = totLen = 0;
			do
			{	toRead = chunk_size;
				err = OCILobRead(ociRecP->serviceContextHP, ociRecP->errorHP, lobLocator, &toRead, offset+1, textP + offset, toRead, nil, nil, nil, SQLCS_IMPLICIT);
				if NOT(_bociErr(ociRecP, &err, nil))
				{	totLen += toRead;
					if (toRead < chunk_size)
						break;
					else						
					{	curSize += chunk_size;
						if NOT(err = SetBlockSize(block, curSize))
						{	textP = GetPtr(block);
							offset += toRead;
						}
					}
				}
			} while NOT(err);
			if NOT(err)
				err = BAPI_StringToObj(api_data, textP, totLen, objRefP);
			DisposeBlock(&block);
		}
	}
	
return err;
}*/

//===========================================================================================
static XErr	_bociBindCursor(BOCI_Rec *ociRecP, BOCI_CursorRec *cursorP, long paramNum, long paramMode, long paramStorage, char *paramObjName, char *error)
{
XErr					err = noErr;
BlockRef				storageBlock;
BDBAPI_ParameterDescr	*paramP;
BDBAPI_ParameterDescr	*paramDescrP;
long					paramNumZB = paramNum - 1;
OCIBind      			*bindp;

	if (paramNum > MAX_PARAMETERS)
		err = _bociSetError(ociRecP, "_Bind: Invalid Param Num");
	else if (cursorP->parameters[paramNumZB])	// exists
	{	paramDescrP = (BDBAPI_ParameterDescr*)GetPtr(cursorP->parameters[paramNumZB]);
		if (paramDescrP->valueBlock)
			DisposeBlock(&paramDescrP->valueBlock);
		DisposeBlock(&cursorP->parameters[paramNumZB]);
		cursorP->totParameters--;
	}
	if NOT(err)
	{	if (storageBlock = NewPtrBlock(sizeof(BDBAPI_ParameterDescr), &err, (Ptr*)&paramP))
		{	ClearBlock(paramP, sizeof(BDBAPI_ParameterDescr));
			paramP->valueStorage = paramStorage + 1;
			if (paramP->valueBlock = NewPtrBlock(paramP->valueStorage, &err, (Ptr*)&paramP->valueP))
			{	bindp = NULL;
				err = OCIBindByPos(cursorP->stmtHP, &bindp, ociRecP->errorHP, paramNum, paramP->valueP, paramP->valueStorage, SQLT_STR, (dvoid *)0, (ub2 *)0, (ub2 *)0, (ub4)0, (ub4 *)0, (ub4)OCI_DEFAULT);
				if NOT(_bociErr(ociRecP, &err, error))
				{	if (cursorP->totParameters < MAX_PARAMETERS)
					{	CEquStr(paramP->name, paramObjName);
						paramP->mode = paramMode;
						paramP->paramNum = paramNum;
						cursorP->parameters[paramNumZB] = storageBlock;
						cursorP->totParameters++;
					}
					else
						err = _bociSetError(ociRecP, "_Bind: Too many parameters");
				}
				if (err)
					DisposeBlock(&paramP->valueBlock);
			}
			if (err)
				DisposeBlock(&storageBlock);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_bociBindCursorCB(long api_data, long db_api_data, Ptr cursorP, long userData, char *error)
{
#ifdef __MWERKS__
#pragma unused(api_data)
#endif
BindRecord		*bindRecordP = (BindRecord*)userData;
BindRec			*bindRecP = bindRecordP->bindRecP;

	return _bociBindCursor(bindRecordP->ociRecP, (BOCI_CursorRec*)cursorP, bindRecP->paramNum, bindRecP->paramMode, bindRecP->paramStorage, bindRecP->paramObjName, error);
}

//===========================================================================================
static XErr	_bociCreateFetchArray(long api_data, BOCI_Rec *ociRecP, BOCI_CursorRec *cursorP, long index, ObjRef *resultObjRefP, Boolean undefNull, Boolean fetchLocator)
{	
XErr				err = noErr;
BOCI_ColumnDescr	*descrP;
long				totCols;
ObjRef				tObjRef, arrayObjRef;
int					i;
int					varLen;
Ptr					boundP;
CStr255				aCStr;
CStr15				tStr;
int					ind, titleLen;
int					columnType;


	descrP = cursorP->columnDescrP;
	totCols = cursorP->totColumns;
	arrayObjRef = *resultObjRefP;
	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &arrayObjRef))
	{	if (index != -1)
		{	for (i = 1; i <= totCols; i++, descrP++)
			{	boundP = descrP->boundVariableP + (index * descrP->maxSize);
				columnType = descrP->columnType;
				BAPI_InvalObjRef(api_data, &tObjRef);
				switch(descrP->valueSizeIndicatorP[index])
				{	// ok
					case 0:
						varLen = descrP->valueLenP[index];
						if ((columnType == SQLT_CLOB) || (columnType == SQLT_BLOB))
						{	if (fetchLocator)
							{	CNumToString((long)(*(OCILobLocator**)boundP), aCStr);
								err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &tObjRef);
							}
							else
								err = _bociLOBToObj(api_data, ociRecP, *(OCILobLocator**)boundP, &tObjRef);
						}
						else
							err = BAPI_StringToObj(api_data, boundP, varLen, &tObjRef);
						break;
					// The selected value is null, and the value of the output variable is unchanged. 
					case -1:
						if (undefNull)
							err = BAPI_StringToObj(api_data, DB_NULL_VALUE, DB_NULL_VALUE_LEN, &tObjRef);
						else
							err = BAPI_StringToObj(api_data, "", 0, &tObjRef);
						break;
					// The length of the item is greater than the length of the output variable; 
					// the item has been truncated. Additionally, the original length is longer 
					// than the maximum data length that can be returned in the sb2 indicator variable. 
					case -2:
						err = BAPI_StringToObj(api_data, "[ORA_DATA_TRUNCATED_1]", 22, &tObjRef);
						break;
					// > 0: The length of the item is greater than the length of the output
					// variable; the item has been truncated. The positive value returned 
					// in the indicator variable is the actual length before truncation. 
					default:
						err = BAPI_StringToObj(api_data, "[ORA_DATA_TRUNCATED_2]", 22, &tObjRef);
						break;
				}
				if NOT(err)
				{	err = BAPI_ArrayAddElement(api_data, &arrayObjRef, descrP->title, &tObjRef);
					if (err && (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName)))
					{	ind = 2;
						titleLen = CLen(descrP->title);
						do {
							CNumToString(ind++, tStr);
							if ((titleLen + 1 + CLen(tStr)) < 255)
							{	CEquStr(aCStr, descrP->title);
								CAddStr(aCStr, "_");
								CAddStr(aCStr, tStr);
								err = BAPI_ArrayAddElement(api_data, &arrayObjRef, aCStr, &tObjRef);
							}
							else
							{	err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
								break;
							}
						} while (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName));
					}
				}
				else
					break;
			}
		}
		if NOT(err)
			*resultObjRefP = arrayObjRef;
	}
	
return err;
}

//===========================================================================================
static XErr	_bociPrepareOneCursorCB(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
#ifdef __MWERKS__
#pragma unused(api_data)
#endif
BOCI_CursorRec			*cursorP = (BOCI_CursorRec*)the_cursorP;
PrepareCallBackRec		*prepCBRecP = (PrepareCallBackRec*)userData;
XErr					err = noErr;
PrepareRec				*prepareRecP = prepCBRecP->prepareRecP;

	cursorP->cursorType = prepareRecP->cursorMode;
	cursorP->rowArraySize = prepareRecP->rowSetSize;
	cursorP->fromPool = true;
	if NOT(err = _bociExecuteQuery(cursorP, prepCBRecP->sqlStringP, prepCBRecP->sqlStringLen, true, true, prepCBRecP->ociRecP, error))
	{	if (cursorP->isSelect)
			err = _bociDefineAllColumns(cursorP, prepCBRecP->ociRecP, false, error, false, false);
	}
return err;
}

//===========================================================================================
static XErr	_bociRebindFast(BOCI_Rec *ociRecP, BOCI_CursorRec *cursorP, OCIStmt	*getCurRecsStmtHP, char *error)
{
XErr					err = noErr;
long					totParameters;
int						tp, tot, index;
BDBAPI_ParameterDescr	*paramP;
BlockRef				tBl;
OCIBind      			*bindp;

	if (totParameters = cursorP->totParameters)
	{	index = 0;
		tot = MAX_PARAMETERS;
		tp = totParameters;
		do 
		{	if (tBl = cursorP->parameters[index++])
			{	tp--;
				paramP = (BDBAPI_ParameterDescr*)GetPtr(tBl);
				if ((paramP->mode == kInputBindMode) || (paramP->mode == kInputOutputBindMode))
				{	bindp = NULL;
					if (err = OCIBindByPos(getCurRecsStmtHP, &bindp, ociRecP->errorHP, paramP->paramNum, paramP->valueP, paramP->valueStorage - 1, SQLT_CHR, nil, nil, nil, nil, nil, OCI_DEFAULT))
						_bociErr(ociRecP, &err, error);
				}
			}
		} while (--tot && tp && NOT(err));
	}

return err;
}

//===========================================================================================
static XErr	_bociCountInSql(Ptr *sqlPPtr, long *lenP, BlockRef *newBlockRefP)
{
XErr	err = noErr;
Ptr		textP = *sqlPPtr, p;
long	tot, offset, textLen = *lenP;

	// here substitute COUNT(*) between select and from
	if (FindStringInText("from", 4, textP, textLen, &offset, false, false))
	{	offset--;	// 0 - based
		tot = COUNT_STR_LEN + textLen - offset;
		if (*newBlockRefP = NewPtrBlock(tot + 1, &err, &p))
		{	CopyBlock(p, COUNT_STR, COUNT_STR_LEN);
			CopyBlock(p + COUNT_STR_LEN, textP + offset, textLen - offset);
			p[tot] = 0;
			*sqlPPtr = p;
			*lenP = tot;
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);
	
return err;
}

//===========================================================================================
static XErr	_bociForwardScroll(BOCI_Rec *ociRecP, BOCI_CursorRec *cursorP)
{
XErr		err = noErr;
long		saveRowArraySize, gap;

	gap = cursorP->curPos - cursorP->realPos;
	if (gap)
	{	saveRowArraySize = cursorP->rowArraySize;
		cursorP->rowArraySize = gap;
		if NOT(err = _bociDefineAllColumns(cursorP, ociRecP, true, nil, true, true))
		{	err = OCIStmtFetch(cursorP->stmtHP, ociRecP->errorHP, gap, OCI_FETCH_NEXT, OCI_DEFAULT);
			if (err == OCI_NO_DATA)
			{	cursorP->endOfCursor = true;
				err = OCIAttrGet(cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, (dvoid*)&cursorP->numRowsFetched, (ub4*)0, (ub4)OCI_ATTR_ROW_COUNT, ociRecP->errorHP);
				if NOT(_bociErr(ociRecP, &err, nil))
				{	cursorP->realPos = cursorP->numRowsFetched + 1;
					cursorP->lastFetched = cursorP->realPos - 1;
				}
			}
			else if (err)
				err = noErr;
		}
		cursorP->rowArraySize = saveRowArraySize;
		if (err = _bociDefineAllColumns(cursorP, ociRecP, true, nil, false, true))
			goto out;
		cursorP->realPos = cursorP->curPos;
	}

out:
return err;
}

//===========================================================================================
static XErr	_bociFreeNormalCursorCB(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
XErr			err = noErr;
BOCI_CursorRec	*cursorP = (BOCI_CursorRec*)the_cursorP;
BOCI_Rec		*ociRecP = (BOCI_Rec*)userData;

	if (cursorP->stmtHP)			// gi� disposto?
		err = _bociFreeNormalCursor(cursorP, ociRecP);

return err;
}

#ifdef __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	boci_Warning(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;

	CEquStr(pbPtr->param.warningRec.warning, ociRecP->warning);
	
return err;
}

//===========================================================================================
static XErr	boci_RowSetSize(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
RowSetSizeRec	*rowSetSizeRecP = &pbPtr->param.rowSetSizeRec;
BOCI_CursorRec	*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, rowSetSizeRecP->cursorID, (Ptr*)&cursorP))
	{	cursorP->rowArraySize = rowSetSizeRecP->size;
		err = _bociDefineAllColumns(cursorP, ociRecP, true, pbPtr->error, false, false);
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_GetAffectedRecs(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
GetAffectedRecsRec	*getAffectedRecsRecP = &pbPtr->param.getAffectedRecsRec;
BOCI_CursorRec		*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getAffectedRecsRecP->cursorID, (Ptr*)&cursorP))
	{	err = OCIAttrGet(cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, (dvoid*)&cursorP->numRowsFetched, (ub4*)0, (ub4)OCI_ATTR_ROW_COUNT, ociRecP->errorHP);
		if NOT(_bociErr(ociRecP, &err, nil))
			getAffectedRecsRecP->affectedRecs = cursorP->numRowsFetched;
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_GetCurRecs(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
GetCurRecsRec		*getCurRecsRecP = &pbPtr->param.getCurRecsRec;
BOCI_CursorRec		*cursorP;
BlockRef			bl, newBlockRef = 0;
long				len;
Ptr					sqlP;
ub4					prefetch = 0;
OCIStmt				*tempStmtHP = nil;
OCIDefine			*defnp;
CStr31				totalRecStr;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getCurRecsRecP->cursorID, (Ptr*)&cursorP))
	{	if (cursorP->isSelect)
		{	// here redo the query with COUNT(*) between select and from
			bl = cursorP->sqlStringBlock;
			if (bl)
				sqlP = GetPtr(bl);
			else
				sqlP = cursorP->sqlString;
			len = cursorP->sqlStringLen;
			if NOT(err = _bociCountInSql(&sqlP, &len, &newBlockRef))
			{	err = OCIHandleAlloc((dvoid*)gsEnvHP, (dvoid**)&tempStmtHP, (ub4)OCI_HTYPE_STMT, 0, (dvoid**)0);
				if (_bociErr(ociRecP, &err, nil))
					goto out;
				err = OCIStmtPrepare(tempStmtHP, ociRecP->errorHP, (text*)sqlP, (ub4)len, (ub4)OCI_NTV_SYNTAX, (ub4)OCI_DEFAULT);
				if (_bociErr(ociRecP, &err, nil))
					goto out;
				err = OCIAttrSet((dvoid *)tempStmtHP,(ub4)OCI_HTYPE_STMT, &prefetch, (ub4)0, (ub4)OCI_ATTR_PREFETCH_MEMORY, ociRecP->errorHP);
				if (_bociErr(ociRecP, &err, nil))
					goto out;
				err = OCIAttrSet((dvoid *)tempStmtHP,(ub4)OCI_HTYPE_STMT, &prefetch, (ub4)0, (ub4)OCI_ATTR_PREFETCH_ROWS, ociRecP->errorHP);
				if (_bociErr(ociRecP, &err, nil))
					goto out;
				err = OCIDefineByPos(tempStmtHP, &defnp, ociRecP->errorHP, (ub4)1, (dvoid*)totalRecStr, (sb4)32, SQLT_CHR, (dvoid*)0, (ub2*)0, (ub2*)0, (ub4)OCI_DEFAULT);
				if (_bociErr(ociRecP, &err, nil))
					goto out;
				if NOT(_bociRebindFast(ociRecP, cursorP, tempStmtHP, nil))
				{	err = OCIStmtExecute(ociRecP->serviceContextHP, tempStmtHP, ociRecP->errorHP, (ub4)0, (ub4) 0, (OCISnapshot*)NULL, (OCISnapshot*) NULL, OCI_DEFAULT);
					if (_bociErr(ociRecP, &err, nil))
						goto out;
					err = OCIStmtFetch(tempStmtHP, ociRecP->errorHP, 1, OCI_FETCH_NEXT, OCI_DEFAULT);
					if (_bociErr(ociRecP, &err, nil))
						goto out;
					getCurRecsRecP->curRecs = atoi(totalRecStr);
				}
			}
		}
		else
			err = XError(kBAPI_Error, Err_IllegalOperation);
	}
	
out:
if (tempStmtHP)
	OCIHandleFree(tempStmtHP, OCI_HTYPE_STMT);
if (newBlockRef)
	DisposeBlock(&newBlockRef);
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_SeekTell(BDBAPI_ParamBlockPtr pbPtr, long which)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
BOCI_CursorRec	*cursorP;
long			t, cursID;

	if (which == kSeek)
		cursID = pbPtr->param.seekRec.cursorID;
	else
		cursID = pbPtr->param.tellRec.cursorID;
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, cursID, (Ptr*)&cursorP))
	{	if (which == kSeek)
		{	// only forward
			if ((t = pbPtr->param.seekRec.pos) >= cursorP->realPos)
				cursorP->curPos = t;
			else
			{	err = XError(kBAPI_Error, Err_IllegalOperation);
				CEquStr(ociRecP->errMsg, "Cursor scroll is forward only");
			}
		}
		else
			pbPtr->param.tellRec.pos = cursorP->curPos;
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static Boolean 	_IsParamNull(BDBAPI_ParameterDescr *paramP, long index, long userData)
{
	return (paramP->length == 0);
}

//===========================================================================================
static XErr	boci_ExecPrepared(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
ExecPreparedRec		*execPreparedRecP = &pbPtr->param.execPreparedRec;
BOCI_CursorRec		*cursorP;
long				api_data = pbPtr->api_data, db_api_data = pbPtr->db_api_data;
ub4					iters, mode;
char				*error = pbPtr->error;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, db_api_data, execPreparedRecP->cursorID, (Ptr*)&cursorP))
	{	/*if (totParameters = cursorP->totParameters)
		{	index = 0;
			tot = MAX_PARAMETERS;
			tp = totParameters;
			do 
			{	if (tBl = cursorP->parameters[index++])
				{	tp--;
					paramP = (BOCI_ParameterDescr*)GetPtr(tBl);
					if ((paramP->mode == kInputBindMode) || (paramP->mode == kInputOutputBindMode))
					{	if NOT(err = BAPI_IsVariableDefined(api_data, (char*)paramP->name, 0, &isDef, &tObjRef))
						{	if (isDef)
								err = BAPI_ObjToString(api_data, &tObjRef, (char*)paramP->valueP, &paramP->length, paramP->valueStorage, kExplicitTypeCast);
							else
							{	CEquStr(aCStr, "_ExecPrepared: Bind Variable not defined (");
								CAddStr(aCStr, paramP->name);
								CAddStr(aCStr, ")");
								err = _bociSetError(ociRecP, aCStr);
							}
						}
					}
				}
			} while (--tot && tp && NOT(err));
		}*/
		if NOT(err = bdbRec.BDBAPI_FlushParamsInputs(api_data, db_api_data, cursorP->parameters, cursorP->totParameters, error, nil))
		{	if (cursorP->isSelect)
				iters = 0;
			else
				iters = 1;
			if (ociRecP->inTransaction)
				mode = OCI_DEFAULT;
			else
				mode = OCI_COMMIT_ON_SUCCESS;
			err = OCIStmtExecute(ociRecP->serviceContextHP, cursorP->stmtHP, ociRecP->errorHP, (ub4)iters, (ub4) 0, (OCISnapshot*)NULL, (OCISnapshot*) NULL, mode);
			if (err == OCI_NO_DATA)
				err = noErr;
			else if (err)
				_bociErr(ociRecP, &err, error);
			if NOT(err)
			{	
				err = bdbRec.BDBAPI_LoadParamsOutputs(api_data, db_api_data, cursorP->parameters, cursorP->totParameters, _IsParamNull, 0, error, nil);
				/*if (totParameters = cursorP->totParameters)		// retrieve parameters for stored procs
				{	
				Ptr			strToEvalP;
				BlockRef	tempBlock;
				long		strToEvalLen;
				
					index = 0;
					tot = MAX_PARAMETERS;
					tp = totParameters;
					do 
					{	if (tBl = cursorP->parameters[index++])
						{	tp--;
							paramP = (BOCI_ParameterDescr*)GetPtr(tBl);
							if ((paramP->mode == kOutputBindMode) || (paramP->mode == kInputOutputBindMode))
							{	strToEvalLen = CLen(paramP->name) + 2 + paramP->length + 1 + 1;
								if (strToEvalLen > 255)
								{	strToEvalP = aCStr;
									tempBlock = 0;
								}
								else
									tempBlock = NewPtrBlock(strToEvalLen, &err, &strToEvalP);
								if NOT(err)
								{	strToEvalP = GetPtr(tempBlock);
									CEquStr(strToEvalP, paramP->name);
									CAddStr(strToEvalP, "=\"");
									if (paramP->length > 0)
									{	paramP->valueP[paramP->length] = 0;
										CAddStr(strToEvalP, (char*)paramP->valueP);
									}
									CAddStr(strToEvalP, "\"");
									BAPI_InvalObjRef(api_data, &tObjRef);
									if (err = BAPI_Eval(api_data, strToEvalP, strToEvalLen, &tObjRef, true))
										break;
									if (tempBlock)
										DisposeBlock(&tempBlock);
								}
							}
						}
					} while (--tot && tp);
				}*/
				if (cursorP->isSelect)
					cursorP->cursorExists = true;
			}
		}
	}
	
if (err)
	CEquStr(error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_Bind(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
BindRec				*bindRecP = &pbPtr->param.bindRec;
BOCI_CursorRec		*cursorP;
//long 				api_data = pbPtr->api_data;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, bindRecP->cursorID, (Ptr*)&cursorP))
		err = _bociBindCursor(ociRecP, cursorP, bindRecP->paramNum, bindRecP->paramMode, bindRecP->paramStorage, bindRecP->paramObjName, pbPtr->error);

return err;
}

//===========================================================================================
static XErr	boci_BindAll(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
BindRec			*bindRecP = &pbPtr->param.bindRec;
BindRecord		bindRecord;

	bindRecord.ociRecP = ociRecP;
	bindRecord.bindRecP = bindRecP;
	err = bdbRec.BDBAPI_PrepareLoop(pbPtr->api_data, pbPtr->db_api_data, bindRecP->prepareID, _bociBindCursorCB, (long)&bindRecord, pbPtr->error);
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_GetPrepared(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
GetPreparedRec		*getPreparedRecP = &pbPtr->param.getPreparedRec;
BOCI_CursorRec		*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetPreparedCursor(pbPtr->api_data, pbPtr->db_api_data, getPreparedRecP->prepareID, &getPreparedRecP->cursorID, (Ptr*)&cursorP))
	{	cursorP->fromPool = true;
		cursorP->curPos = cursorP->realPos = 1;
		cursorP->totRecs = -1;
		cursorP->firstFetched = 0;
		cursorP->longAllocation = DEFAULT_LONG_ALLOCATION;
		cursorP->lastFetched = 0;
		cursorP->cursorExists = false;
		cursorP->fetchOff = 0;
		cursorP->numRowsFetched = 0;
		err = _bociRedefineColumns(cursorP, ociRecP, pbPtr->error);
	}

if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_FreePrepare(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
FreePrepareRec		*freePrepareRecP = &pbPtr->param.freePrepareRec;

	err = bdbRec.BDBAPI_DisposePrepare(pbPtr->api_data, pbPtr->db_api_data, freePrepareRecP->prepareID, _bociFreePreparedCursorCB, (long)ociRecP, pbPtr->error);
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_Prepare(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
PrepareRec			*prepareRecP = &pbPtr->param.prepareRec;
PrepareCallBackRec	prepCBRec;
long				sqlStringLen;
Ptr					sqlStringP;
BlockRef			blockRef;
CStr255				cStr;
PrepareParams		params;

	params.sqlStringP = prepareRecP->sqlStringP;
	params.sqlStringLen = prepareRecP->sqlStringLen;
	params.totCursors = prepareRecP->totCursors;
	//params.cursorMode = prepareRecP->cursorMode;
	params.userData = (long)ociRecP;
	sqlStringP = prepareRecP->sqlStringP;
	sqlStringLen = prepareRecP->sqlStringLen;
	if NOT(err = _bociPlaceHoders(&sqlStringP, &sqlStringLen, cStr, &blockRef))
	{	prepCBRec.prepareRecP = prepareRecP;
		prepCBRec.ociRecP = ociRecP;
		prepCBRec.sqlStringP = sqlStringP;
		prepCBRec.sqlStringLen = sqlStringLen;
		if NOT(err = bdbRec.BDBAPI_NewPrepare(pbPtr->api_data, pbPtr->db_api_data, &params, _bociPrepareOneCursorCB, (long)&prepCBRec, pbPtr->error))
			prepareRecP->prepareID = params.prepareID;
		DisposeBlock(&blockRef);
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_FetchRec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
BOCI_CursorRec	*cursorP;
Boolean			undefNull, fetchLocator;
Boolean			toRefetch;
int				realPos, index, curPos;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, pbPtr->param.fetchRec.cursorID, (Ptr*)&cursorP))
	{	curPos = cursorP->curPos;
		realPos = cursorP->realPos;
		undefNull = pbPtr->param.fetchRec.undefNull;
		fetchLocator = pbPtr->param.fetchRec.fetchLocator;
		toRefetch = (cursorP->curPos < cursorP->firstFetched) || (cursorP->curPos > cursorP->lastFetched);
		if (toRefetch)
		{	if (realPos != curPos)
			{	if (curPos > realPos)
					err = _bociForwardScroll(ociRecP, cursorP);
				else
					err = XError(kBAPI_Error, Err_IllegalOperation);
			}
			if NOT(err)
			{	if (cursorP->endOfCursor)
					curPos = cursorP->lastFetched + 1;
				else
				{	cursorP->firstFetched = curPos;
					err = OCIStmtFetch(cursorP->stmtHP, ociRecP->errorHP, cursorP->rowArraySize, OCI_FETCH_NEXT, OCI_DEFAULT);
					if (err == OCI_NO_DATA)
					{	cursorP->endOfCursor = true;
						err = noErr;
					}
					if NOT(err)
					{	err = OCIAttrGet(cursorP->stmtHP, (ub4)OCI_HTYPE_STMT, (dvoid*)&cursorP->numRowsFetched, (ub4*)0, (ub4)OCI_ATTR_ROW_COUNT, ociRecP->errorHP);
						if NOT(_bociErr(ociRecP, &err, nil))
						{	cursorP->realPos = cursorP->numRowsFetched + 1;
							cursorP->lastFetched = cursorP->realPos - 1;
						}
					}
					else
						err = _bociErr(ociRecP, &err, nil);
				}
			}
		}			
		if NOT(err)
		{	if (curPos > cursorP->lastFetched)
				index = -1;
			else
				index = curPos-cursorP->firstFetched;
			if NOT(err = _bociCreateFetchArray(pbPtr->api_data, ociRecP, cursorP, index, &pbPtr->param.fetchRec.object, undefNull, fetchLocator))
			{
			
			}
			cursorP->curPos++;
		}
	}

if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_FreeResult(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
FreeResultRec	*freeResultRecP = &pbPtr->param.freeResultRec;
BOCI_CursorRec	*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, (Ptr*)&cursorP))
	{	if (cursorP->fromPool)
			err = _bociFreePreparedCursor(cursorP, ociRecP, pbPtr->error, false, false);
		else
			err = _bociFreeNormalCursor(cursorP, ociRecP);
		bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, nil, 0, pbPtr->error);	// free the slot
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_Exec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
ExecRec			*execRecP = &pbPtr->param.execRec;
BOCI_CursorRec	*cursorP, cursoOnStack;

	if (execRecP->dontReturnCursor)
	{	cursorP = &cursoOnStack;
		ClearBlock(cursorP, sizeof(BOCI_CursorRec));
	}
	else
		err = bdbRec.BDBAPI_NewCursorSlot(pbPtr->api_data, pbPtr->db_api_data, &execRecP->cursorID, (Ptr*)&cursorP);
	if NOT(err)
	{	cursorP->cursorType = execRecP->cursorMode;
		cursorP->rowArraySize = execRecP->rowSetSize;
		cursorP->firstFetched = 0;
		cursorP->lastFetched = 0;
		cursorP->endOfCursor = false;
		cursorP->longAllocation = DEFAULT_LONG_ALLOCATION;
		if NOT(err = _bociExecuteQuery(cursorP, execRecP->sqlStringP, execRecP->sqlStringLen, execRecP->onlyPrepare, true, ociRecP, nil))
		{	if (cursorP->isSelect)
				err = _bociDefineAllColumns(cursorP, ociRecP, true, nil, false, false);
		}
		if (execRecP->dontReturnCursor && NOT(err))
			_bociFreeNormalCursorCB(pbPtr->api_data, pbPtr->db_api_data, (Ptr)cursorP, (long)ociRecP, pbPtr->error);
		else if (err && NOT(execRecP->dontReturnCursor))
			bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, execRecP->cursorID, nil, 0, pbPtr->error);	// free the slot
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_Disconnect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP;
char			*error = pbPtr->error;

	ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
	err = bdbRec.BDBAPI_DisposeAllCursorsSlots(pbPtr->api_data, pbPtr->db_api_data, _bociFreeNormalCursorCB, (long)ociRecP, error);
	ReleasePoolConnect(gsPoolConnectRecP, ociRecP->poolConnectIndex);
	err = bdbRec.BDBAPI_DisposeAllPrepares(pbPtr->api_data, pbPtr->db_api_data, _bociFreePreparedCursorCB, (long)ociRecP, error);
	PoolDisposePtr(gsBOCIRecPoolRef, ociRecP->slot);

if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
// instance = TABAORA user/pass tabasoft/tabasoft (credo!)
static XErr	boci_Connect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
CStr255			instance;
CStr255			username;
CStr255			password;
BOCI_Rec		*bociRecP;
uint32_t		slot;
ConnectRec		*connectRecP = &pbPtr->param.connectRec;
Boolean			newOne = false, servAttached = false, sessionBeginned = false;
BOCIPoolBuffer	pBuff;

	slot = 0;
	if NOT(err = PoolNewPtr(gsBOCIRecPoolRef, (Ptr*)&bociRecP, &slot))
	{	ClearBlock(bociRecP, sizeof(BOCI_Rec));
		bociRecP->slot = slot;
		ClearBlock(&pBuff, sizeof(BOCIPoolBuffer));
		if NOT(err = GetPoolConnect(gsPoolConnectRecP, (Ptr)&pBuff, sizeof(BOCIPoolBuffer), connectRecP->connString, &bociRecP->poolConnectIndex))
		{	if (pBuff.serverHP)	// found one free
			{	bociRecP->serverHP = pBuff.serverHP;
				bociRecP->errorHP = pBuff.errorHP;
				bociRecP->serviceContextHP = pBuff.serviceContextHP;
				bociRecP->sessionHP = pBuff.sessionHP;
			}
			else
			{	newOne = true;
				if NOT(err = _bociTokenizeConnString(connectRecP->connString, connectRecP->connStringLen, instance, username, password))
				{	// Alloc the server Record
					err = OCIHandleAlloc((dvoid*)gsEnvHP, (dvoid**)&bociRecP->serverHP, OCI_HTYPE_SERVER, 0, (dvoid**)0);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					// Alloc the error Record
					err = OCIHandleAlloc((dvoid*)gsEnvHP, (dvoid**)&bociRecP->errorHP, OCI_HTYPE_ERROR, 0, (dvoid**)0);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					// Alloc the context Record
					err = OCIHandleAlloc((dvoid*)gsEnvHP, (dvoid**)&bociRecP->serviceContextHP, OCI_HTYPE_SVCCTX, 0, (dvoid**)0);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					// Attach the server to the instance requested
					err = OCIServerAttach(bociRecP->serverHP, bociRecP->errorHP, (text*)instance, (sb4)CLen((char*)instance), (ub4) OCI_DEFAULT);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					servAttached = true;
					// set attribute server context in the service context
					err = OCIAttrSet((dvoid*)bociRecP->serviceContextHP, (ub4)OCI_HTYPE_SVCCTX, (dvoid*)bociRecP->serverHP, (ub4)0, (ub4) OCI_ATTR_SERVER, bociRecP->errorHP);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					// Alloc the session Record
					err = OCIHandleAlloc((dvoid *)gsEnvHP, (dvoid **)&bociRecP->sessionHP, (ub4) OCI_HTYPE_SESSION, (size_t)0, (dvoid **)0);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					// Set username of session
					err = OCIAttrSet((dvoid *)bociRecP->sessionHP, (ub4)OCI_HTYPE_SESSION, (dvoid*)username, (ub4)strlen((char *)username), (ub4) OCI_ATTR_USERNAME, bociRecP->errorHP);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					// Set password of session
					err = OCIAttrSet((dvoid *)bociRecP->sessionHP, (ub4) OCI_HTYPE_SESSION, (dvoid*)password, (ub4)strlen((char*)password), (ub4)OCI_ATTR_PASSWORD, bociRecP->errorHP);
					if (_bociErr(bociRecP, &err, nil))
						goto out;
					// Begin Session
					err = OCISessionBegin(bociRecP->serviceContextHP, bociRecP->errorHP, bociRecP->sessionHP, OCI_CRED_RDBMS, OCI_DEFAULT);
 					if (_bociErr(bociRecP, &err, nil))
						goto out;
          			sessionBeginned = true;
           			// set attribute service context in the session context
           			OCIAttrSet((dvoid *)bociRecP->serviceContextHP, (ub4)OCI_HTYPE_SVCCTX, (dvoid *)bociRecP->sessionHP, (ub4)0, OCI_ATTR_SESSION, bociRecP->errorHP);
 					if (_bociErr(bociRecP, &err, nil))
						goto out;
           			// Add the connection to the pool
					pBuff.serverHP = bociRecP->serverHP;
					pBuff.errorHP = bociRecP->errorHP;
					pBuff.serviceContextHP = bociRecP->serviceContextHP;
					pBuff.sessionHP = bociRecP->sessionHP;
					err = AddPoolConnect(gsPoolConnectRecBlock, &gsPoolConnectRecP, (Ptr)&pBuff, sizeof(BOCIPoolBuffer), connectRecP->connString, &bociRecP->poolConnectIndex);
				}
			}
		}
	}

out:
if (err)
{	if (bociRecP)
		CEquStr(pbPtr->error, bociRecP->errMsg);
	if (newOne)
	{	
	XErr	err2 = noErr;
	
		if (sessionBeginned)
			err2 = OCISessionEnd(bociRecP->serviceContextHP, bociRecP->errorHP, bociRecP->sessionHP, OCI_DEFAULT);
		if (servAttached)
			err2 = OCIServerDetach(bociRecP->serverHP, bociRecP->errorHP, OCI_DEFAULT);
		if (bociRecP->serverHP)
			err2 = OCIHandleFree(bociRecP->serverHP, OCI_HTYPE_SERVER);
		if (bociRecP->errorHP)
			err2 = OCIHandleFree(bociRecP->errorHP, OCI_HTYPE_ERROR);
		if (bociRecP->serviceContextHP)
			err2 = OCIHandleFree(bociRecP->serviceContextHP, OCI_HTYPE_SVCCTX);
	}
	if (slot)
		PoolDisposePtr(gsBOCIRecPoolRef, slot);
	err = XError(kBAPI_ClassError, ErrDBMSError);
}
else
{	connectRecP->connBufferLength = sizeof(BOCI_Rec);
	connectRecP->connBuffer = 0L;
	connectRecP->connPointer = (Ptr)bociRecP;
}
return err;
}

//===========================================================================================
static XErr	boci_BeginTran(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;

	err = OCITransStart(ociRecP->serviceContextHP, ociRecP->errorHP, 60, OCI_TRANS_NEW);
	_bociErr(ociRecP, &err, nil);
	if NOT(err)
		ociRecP->inTransaction = true;
		
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_EndTran(BDBAPI_ParamBlockPtr pbPtr, Boolean toCommit)
{
XErr			err = noErr;
BOCI_Rec		*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;

	if (toCommit)
		OCITransCommit(ociRecP->serviceContextHP, ociRecP->errorHP, (ub4) 0);
	else
		OCITransRollback(ociRecP->serviceContextHP, ociRecP->errorHP, (ub4) 0);
	_bociErr(ociRecP, &err, nil);
	if NOT(err)
		ociRecP->inTransaction = false;
		
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_SetSpecific(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
BOCI_CursorRec		*cursorP;
SetSpecificRec		*setSpecificRecP = &pbPtr->param.setSpecificRec;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, setSpecificRecP->cursorID, (Ptr*)&cursorP))
	{	if NOT(CCompareStrings_cs(setSpecificRecP->name, "LONG_ALLOC"))
		{	cursorP->longAllocation = atoi(setSpecificRecP->value);
			err = _bociDefineAllColumns(cursorP, ociRecP, true, pbPtr->error, false, false);
		}
		//else if NOT(CCompareStrings_cs(setSpecificRecP->name, "LOCATOR"))
		//	cursorP->fetchLocator = atoi(setSpecificRecP->value);
		else
			err = XError(kBAPI_ClassError, ErrUnknownSpecific);
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_GetSpecific(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
BOCI_CursorRec		*cursorP;
GetSpecificRec		*getSpecificRecP = &pbPtr->param.getSpecificRec;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getSpecificRecP->cursorID, (Ptr*)&cursorP))
	{	if NOT(CCompareStrings_cs(getSpecificRecP->name, "LONG_ALLOC"))
			CNumToString(cursorP->longAllocation, getSpecificRecP->value);
		//else if NOT(CCompareStrings_cs(getSpecificRecP->name, "LOCATOR"))
		//	CNumToString(cursorP->fetchLocator, getSpecificRecP->value);
		else
			err = XError(kBAPI_ClassError, ErrUnknownSpecific);
	}
	
if (err)
	CEquStr(pbPtr->error, ociRecP->errMsg);
return err;
}

//===========================================================================================
static XErr	boci_LobRead(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BOCI_Rec			*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
LobRec				*lobRecP = &pbPtr->param.lobRec;
ub4					len, offset;
BlockRef			block;
Ptr					textP;

	offset = lobRecP->offset + 1;
	err = _bociLOBToObj(pbPtr->api_data, ociRecP, (OCILobLocator*)lobRecP->locator, &lobRecP->outObj);
	if (lobRecP->len)
		len = lobRecP->len;
	else
	{	if (err = OCILobGetLength(ociRecP->serviceContextHP, ociRecP->errorHP, (OCILobLocator*)lobRecP->locator, &len))
			_bociErr(ociRecP, &err, nil);
	}
	if NOT(err)
	{	if (len)
		{	if (block = NewPtrBlock(len, &err, &textP))
			{	err = OCILobRead(ociRecP->serviceContextHP, ociRecP->errorHP, (OCILobLocator*)lobRecP->locator, &len, offset, textP, len, nil, nil, nil, SQLCS_IMPLICIT);
				if NOT(_bociErr(ociRecP, &err, nil))
					err = BAPI_StringToObj(pbPtr->api_data, textP, len, &lobRecP->outObj);
				DisposeBlock(&block);
			}
		}
		else
			err = BAPI_StringToObj(pbPtr->api_data, "", 0, &lobRecP->outObj);	
	}

return err;
}

//===========================================================================================
static XErr	boci_LobWrite(BDBAPI_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
BOCI_Rec	*ociRecP = (BOCI_Rec*)pbPtr->connBufferPtr;
LobRec		*lobRecP = &pbPtr->param.lobRec;
ub4			toWrite;
ub4			offset;

	offset = lobRecP->offset + 1;
	toWrite = lobRecP->len;
	err = OCILobWrite (ociRecP->serviceContextHP,
			ociRecP->errorHP,
			(OCILobLocator*)lobRecP->locator,
			&toWrite,
			offset,
			(dvoid*)lobRecP->buffer, 
			toWrite,
			OCI_ONE_PIECE,
			NULL, 
			NULL, 
			0,
			0);
	if (err)
		_bociErr(ociRecP, &err, pbPtr->error);
	
return err;
}

#ifdef __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr BOCI_BDBAPI_Dispatch(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kConnect:
			err = boci_Connect(pbPtr);
			break;
		case kDisconnect:
			err = boci_Disconnect(pbPtr);
			break;
		case kExec:
			err = boci_Exec(pbPtr);
			break;
		case kCall:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kCallExt:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kPrepare:
			err = boci_Prepare(pbPtr);
			break;
		case kFreePrepare:
			err = boci_FreePrepare(pbPtr);
			break;
		case kRowSetSize:
			err = boci_RowSetSize(pbPtr);
			break;
		case kGetPrepared:
			err = boci_GetPrepared(pbPtr);
			break;
		case kBind:
			err = boci_Bind(pbPtr);
			break;
		case kBindAll:
			err = boci_BindAll(pbPtr);
			break;
		case kExecPrepared:
			err = boci_ExecPrepared(pbPtr);
			break;
		case kFreeResult:
			err = boci_FreeResult(pbPtr);
			break;
		case kSeek:
			err = boci_SeekTell(pbPtr, kSeek);
			break;
		case kTell:
			err = boci_SeekTell(pbPtr, kTell);
			break;
		case kWarning:
			err = boci_Warning(pbPtr);
			break;
		case kGetCurRecs:
			err = boci_GetCurRecs(pbPtr);
			break;
		case kGetAffectedRecs:
			err = boci_GetAffectedRecs(pbPtr);
			break;
		case kFetchRec:
			err = boci_FetchRec(pbPtr);
			break;
		case kTransaction:
			err = boci_BeginTran(pbPtr);
			break;
		case kCommit:
			err = boci_EndTran(pbPtr, true);
			break;
		case kRollBack:
			err = boci_EndTran(pbPtr, false);
			break;
		case kRealEscape:
		case kRealUnescape:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kGetSpecific:
			err = boci_GetSpecific(pbPtr);
			break;
		case kSetSpecific:
			err = boci_SetSpecific(pbPtr);
			break;
		case kLobWrite:
			err = boci_LobWrite(pbPtr);
			break;
		case kLobRead:
			err = boci_LobRead(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
	}

return err;
}

#ifdef __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	BOCI_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

	if (gsPoolConnectRecBlock)
		ClosePoolConnect(gsPoolConnectRecBlock, gsPoolConnectRecP, _bociCloseSessionCB);
	if (gsBOCIRecPoolRef)
		DeletePool(gsBOCIRecPoolRef);
	gsPoolConnectRecBlock = 0;
	gsBOCIRecPoolRef = nil;
	err = OCIHandleFree(gsEnvHP, OCI_HTYPE_ENV);
	gsEnvHP = nil;

//out:
if (err)
	_bociErrorString(nil, pbPtr->error);
return err;
}

//===========================================================================================
static XErr	InitCallBacks(long api_data, BDBAPI_Rec *theRecP)
{
XErr					err = noErr;
BDBAPI_Init_CallBack	BDBAPI_Init_EP;

	if NOT(err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, "db", false), "BDBAPI_Init", (long*)&BDBAPI_Init_EP))
		err = BDBAPI_Init_EP(&bdbRec);

return err;
}

//===========================================================================================
static XErr	BOCI_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
CStr255			errMsg;
long			api_data = pbPtr->api_data;

	gsPoolConnectRecBlock = 0;
	gsBOCIRecPoolRef = nil;
	gsEnvHP = nil;
	*errMsg = 0;
	if (gsPoolConnectRecBlock = NewBlockLocked(sizeof(PoolConnectRec), &err, (Ptr*)&gsPoolConnectRecP))
	{	ClearBlock(gsPoolConnectRecP, sizeof(PoolConnectRec));
		err = OCIEnvCreate(&gsEnvHP, OCI_THREADED, (dvoid*)0, NULL, NULL, NULL, 0, (dvoid**)0);
		if NOT(_bociErr(nil, &err, errMsg))
		{	if NOT(err = InitCallBacks(api_data, &bdbRec))
			{	if NOT(err = bdbRec.BDBAPI_Register("oracle", BOCI_BDBAPI_Dispatch, sizeof(BOCI_CursorRec), false))
					err = NewPool(sizeof(BOCI_Rec), gsMaxUsers, &gsBOCIRecPoolRef);
			}
		}
	}

if (err)
{	CEquStr(pbPtr->error, errMsg);
	if (gsPoolConnectRecBlock)
	{	DisposeBlock(&gsPoolConnectRecBlock);
		gsPoolConnectRecBlock = 0;
	}
	if (gsEnvHP)
		OCIHandleFree(gsEnvHP, OCI_HTYPE_ENV);
	if (gsBOCIRecPoolRef)
		DeletePool(gsBOCIRecPoolRef);
	gsPoolConnectRecBlock = 0;
	gsBOCIRecPoolRef = nil;
	gsEnvHP = nil;
}
return err;
}

//===========================================================================================
/*static XErr	oracle_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				api_data = pbPtr->api_data;

	switch(exeMethodRecP->methodID)
	{
		case kLobWrite:
			err = _bociObjectToLob(pbPtr, exeMethodRecP, api_data);
			break;
		case kLobRead:
			err = _bociLobToObject(pbPtr, exeMethodRecP, api_data);
			break;
	}
	
return err;
}*/

#ifdef __MWERKS__
#pragma mark-
#pragma export on
#endif
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, BOCI_ClassName);
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(oracle support)");
			gsApiVersion = pbPtr->param.registerRec.api_version;
			oracleClassID = pbPtr->param.registerRec.pluginID;
			//BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
			//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			gsMaxUsers = pbPtr->param.registerRec.maxUsers;
			break;
		case kInit:
			err = BOCI_Init(pbPtr);
			break;
		case kShutDown:
			err = BOCI_ShutDown(pbPtr);
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			//err = oracle_ExecuteMethod(pbPtr);
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteFunction:
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
//#endif
#ifdef __MWERKS__
#pragma export off
#endif
