/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: jclass_bfr.c,v 1.42 2006-05-30 14:53:14 valfer Exp $
	|______________________________________________________________________________
*/
#if __MACOSX__
	#include <JavaVM/jni.h>
#else
	#include 	"jni.h"
#endif

#include 	"BifernoAPI.h"
#include 	"jclass_bfr.h"
#include 	"jclass_utils.h"
#include 	"BfrVersion.h"

static short				jClassID;
static long					gsApiVersion;
static CStr255				gsStreamOutPath, gsStreamErrPath, gsStreamOutPathXLib, gsStreamErrPathXLib;

// Methods
enum{
		kNew = 1
	} JClass_Method;
#define TOT_METHODES	1

// Properties
enum{
		kNull = 1
	} JClass_Props;
#define TOT_PROPS	1

typedef struct
	{
	int			paramType;
	CStr255		paramSign;
	CStr255		qualifier;
	jclass		jcl;
	} JParam;

enum {
	k_Void = 1,
	k_Boolean,
	k_Byte,
	k_Char,
	k_Short,
	k_Int,
	k_Long,
	k_Float,
	k_Double,
	k_Object
};

static long		gs_bool_id, gs_int_id, gs_unsigned_id, gs_float_id, gs_double_id, gs_char_id, gs_string_id, gs_array_id, gs_byte_id, gs_short_id, gs_long_id;
static char		gs_Initer[] = "<init>";

#define	DECR(x)		{if (x){(*x)--;}}
#define	INCR(x)		{if (x){(*x)++;}}

#define	NULL_JAVA_OBJECT_POINTER	((jobject)-1)

CStr63	gJClassErrorsStr[] = 
	{	
		"Err_JClassError",
		"Err_JavaClassNotFound",
		"Err_JavaException",
		"Err_JavaStringTooLong",
		"Err_JavaFieldNotFound"
		};

typedef struct
	{
	unsigned long	threadID;
	JNIEnv 			*envP;
	jclass			integerClass;
	jclass			booleanClass;
	jclass			floatClass;
	jclass			charClass;
	jclass			byteClass;
	jclass			shortClass;
	jclass			longClass;
	jclass			doubleClass;
	jclass			javaLangStringClass;
	jclass			javaLangArrayClass;
	jclass			classClass;
	jclass			reflectionMethodClass;
	jclass			reflectionFieldClass;
	jclass			reflectionModifierClass;
	
	jobject			systemClassLoader;
	
	jmethodID		cloneID;
	jmethodID		getDeclaredMethodID;
	jmethodID		getMethodsID;
	jmethodID		getConstructorsID;
	jmethodID		getDeclaredFieldID;
	jmethodID		getdFieldsID;
	jmethodID		isAssignableFromID;
	jmethodID		getSuperclassID;
	jmethodID		getTypeID;
	jmethodID		getReturnTypeID;
	jmethodID		getMethodModifiersID;
	jmethodID		getMethodParameterTypesID;
	jmethodID		getConstructorParameterTypesID;
	jmethodID		getMethodNameID;
	jmethodID		getFieldNameID;
	jmethodID		getFieldModifiersID;
	jmethodID		isStaticID;
	jmethodID		isPublicID;
	jmethodID		getNameID;
	jmethodID		forNameID;
	
	// for redirect
	jclass			fileClass;
	jclass			printStreamClass;
	jclass			fileOutputStreamClass;
	jclass			systemClass;
	jmethodID		fileConstr;
	jmethodID		fileOutputStreamConstr;
	jmethodID		printStreamConstr;
	jmethodID		systemSetOut;
	jmethodID		systemSetErr;
	jmethodID		closeID;
	jobject			outFile;
	jobject			outStream;
	jobject			errFile;
	jobject			errStream;
	
	// optional
	//jclass		bfrClassLoaderClass;
	//jmethodID		bfrLoadClass;
	} JClassRunRecord;

typedef struct
	{
	unsigned long	threadID;
	jclass			j_class;
	jobject			j_classLoaded;
	jobject			j_object;
	CStr255			class_name;
	} JClassDescr;

typedef struct
	{
	JNIEnv 					*envP;
	JClassRunRecord 		*runRecP;
	Biferno_ParamBlockPtr 	pbPtr;
	ExecuteMethodRec		*exeMethodRecP;
	JClassDescr				jClassDescr;
	Boolean					isStatic;
	Boolean					isConstructor;
	short					pad2;
	jvalue					*args;
	//jmethodID				methodID;
	char					*methodNameP;
	char					*method_signature;
	char					*returnTypeSignature;
	char					*returnQualifier;
	long					retType;
	long					totParams;
	JParam					*jParamsP;
	} ExecRecord;

//===========================================================================================
static XErr _JClassReadFile(XFilePathPtr filePath, BlockRef *textBlockP, long *fileSizeP)
{
XFileRef		fileRef;
long			eof;
BlockRef		block = nil;
XErr			err = noErr, err2 = noErr;
Ptr				p;

	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof)
			{	if (block = NewBlock(eof, &err, &p))
					err = ReadXFile(fileRef, p, &eof);
			}
			else
				block = NewBlock(1, &err, nil);
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	
	
if NOT(err)
{	*textBlockP = block;
	*fileSizeP = eof;
}
else
{	*textBlockP = nil;
	*fileSizeP = 0;
	if (block)
		DisposeBlock(&block);
}

return err;
}

//===========================================================================================
static XErr	_RedirectStd(JClassRunRecord *runRecP, Boolean redirStdErr, jobject *resStreamP)
{
XErr			err = noErr;
jobject			j_PrintStream;
JNIEnv			*envP = runRecP->envP;
jobject			j_FileOutputStream;

	// FileOutputStream	fop = new FileOutputStream(f);
	if (redirStdErr)
		j_FileOutputStream = (*envP)->NewObject(envP, runRecP->fileOutputStreamClass, runRecP->fileOutputStreamConstr, runRecP->errFile);
	else
		j_FileOutputStream = (*envP)->NewObject(envP, runRecP->fileOutputStreamClass, runRecP->fileOutputStreamConstr, runRecP->outFile);
	if (j_FileOutputStream)
	{	// ps = new PrintStream(fop)
		if (j_PrintStream = (*envP)->NewObject(envP, runRecP->printStreamClass, runRecP->printStreamConstr, j_FileOutputStream))
		{	// System.setErr/Out(ps);
			if (redirStdErr)
				(*envP)->CallStaticVoidMethod(envP, runRecP->systemClass, runRecP->systemSetErr, j_PrintStream);
			else
				(*envP)->CallStaticVoidMethod(envP, runRecP->systemClass, runRecP->systemSetOut, j_PrintStream);
		}
	}
	
if ((*envP)->ExceptionOccurred(envP) != NULL)
{	(*envP)->ExceptionDescribe(envP);
	(*envP)->ExceptionClear(envP);
	err = XError(kBAPI_ClassError, Err_JavaException);
}
if NOT(err)
	*resStreamP = j_FileOutputStream;
return err;
}

//===========================================================================================
static XErr	_CloseStd(JClassRunRecord *runRecP, jobject outStream)
{
	(*runRecP->envP)->CallVoidMethod(runRecP->envP, outStream, runRecP->closeID);

return noErr;
}

//===========================================================================================
static XErr	_reset_out(Boolean isErr)
{
XErr		err = noErr;
XFileRef	fileRef;
char		*strP;

	if (isErr)
		strP = gsStreamErrPath;
	else
		strP = gsStreamOutPath;
	if NOT(err = OpenXFile(strP, OPEN_FILE_EXISTING, READ_WRITE_PERM, false, &fileRef))
	{	if NOT(err = SetXEOF(fileRef, 0))
			CloseXFile(&fileRef);
	}

return noErr;
}

//===========================================================================================
XErr	_jclassRedirOutput(JClassRunRecord *runRecP, XErr (*_Func)(long userData), long userData, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP)
{
XErr		err = noErr;
//CStr255		error;

	XThreadsEnterCriticalSection();
	if NOT(err = _reset_out((Boolean)(stdErrP != nil)))
	{	if NOT(err = _Func(userData))
		{	if (stdOutP)
				err = _JClassReadFile(gsStreamOutPathXLib, stdOutP, stdOutLenP);
			if (NOT(err) && stdErrP)
				err = _JClassReadFile(gsStreamErrPathXLib, stdErrP, stdErrLenP);
		}
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
static XErr	_DescribeException(long userData)
{
JNIEnv *envP = (JNIEnv*)userData;

	(*envP)->ExceptionDescribe(envP);

return noErr;
}

//===========================================================================================
static void	_BlockToStr255(BlockRef block, long len, char *str)
{
Boolean		addPeriods;

	if (len > 252)
	{	len = 252;
		addPeriods = true;
	}
	else
		addPeriods = false;
	CopyBlock(str, GetPtr(block), len);
	str[len] = 0;
	if (addPeriods)
		CAddStr(str, "...");
}

//===========================================================================================
static XErr	_CheckException(JClassRunRecord *runRecP, Biferno_ParamBlockPtr pbPtr, XErr *errPtr)
{
XErr		err = noErr, err2 = noErr;
BlockRef	stdErr;
long		stdErrLen;
JNIEnv 		*envP = runRecP->envP;
	
	if (errPtr)
		err = *errPtr;
	if ((*envP)->ExceptionOccurred(envP) != NULL)
	{	if NOT(err2 = _jclassRedirOutput(runRecP, _DescribeException, (long)envP, nil, nil, &stdErr, &stdErrLen))
		{	err = _DescribeException((long)envP);
			_BlockToStr255(stdErr, stdErrLen, pbPtr->error);
			DisposeBlock(&stdErr);
		}
		(*envP)->ExceptionClear(envP);
		if NOT(err)
			err = XError(kBAPI_ClassError, Err_JavaException);
		if (stdErrLen)	// close and reopen input stream (to reset)
		{
		XErr	err2 = noErr;
		
			_CloseStd(runRecP, runRecP->errStream);
			err2 = _RedirectStd(runRecP, true, &runRecP->errStream);
			if (err2 && NOT(err))
				err = err2;
		}
	}
	if (errPtr)
		*errPtr = err;
	
return err;
}

//===========================================================================================
static XErr	_FillJClassDescr(JClassRunRecord *runRecP, JClassDescr *jClassDescrP, char *className, Biferno_ParamBlockPtr pbPtr, ParameterRec *paramP)
{
XErr			err = noErr;
JNIEnv			*envP = runRecP->envP ;
jstring			jClassName;

	if (paramP)
	{
	JClassDescr		classLoader;
	long			tLen;
	BlockRef		data;
	long			dataLen, api_data = pbPtr->api_data;
	CStr255			filePath;
	jstring			jFilePath;
	jclass			cLoaderClass;
	jmethodID		loadMethID;
	
		if NOT(err = BAPI_ObjToString(api_data, &paramP[0].objRef, jClassDescrP->class_name, nil, 255, kExplicitTypeCast))
		{	tLen = sizeof(JClassDescr);
			if NOT(err = BAPI_ReadObj(api_data, &paramP[1].objRef, (Ptr)&classLoader, &tLen, 0, nil))
			{	if NOT(err = BAPI_ObjToString(api_data, &paramP[2].objRef, filePath, nil, 255, kExplicitTypeCast))
				{	if NOT(err = BAPI_RealPath(api_data, filePath, false))
					{	if NOT(err = _JClassReadFile(filePath, &data, &dataLen))
						{	if (jClassDescrP->j_class = (*envP)->DefineClass(envP, jClassDescrP->class_name, classLoader.j_object, (const jbyte*)GetPtr(data), (jsize)dataLen))
							{	if NOT(err = CString2jstring(envP, jClassDescrP->class_name, &jClassName, pbPtr->error))
								{	if NOT(err = BAPI_NativePath(api_data, filePath))
									{	if NOT(err = CString2jstring(envP, filePath, &jFilePath, pbPtr->error))
										{	if (cLoaderClass = (*envP)->GetObjectClass(envP, classLoader.j_object))
											{	if (loadMethID = (*envP)->GetMethodID(envP, cLoaderClass, "loadClass", "(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/Class;"))
													jClassDescrP->j_classLoaded = (*envP)->CallObjectMethod(envP, classLoader.j_object, loadMethID, jClassName, jFilePath, true);
											}
										}
									}
								}
							}
							DisposeBlock(&data);
						}
					}
				}
			}
		}
	}
	else
	{	CSubstitute(className, '.', '/');									// FindClass wants '/'
		if NOT(jClassDescrP->j_class)
			jClassDescrP->j_class = (*envP)->FindClass(envP, className);
		if (jClassDescrP->j_class)
		{	CSubstitute(className, '/', '.');								// forName wants '.'
			CEquStr(jClassDescrP->class_name, className);
			if NOT(err = CString2jstring(envP, className, &jClassName, pbPtr->error))
			{	if NOT(jClassDescrP->j_classLoaded = (*envP)->CallStaticObjectMethod(envP, runRecP->classClass, runRecP->forNameID, jClassName, 1, runRecP->systemClassLoader))
					err = XError(kBAPI_ClassError, Err_JavaClassNotFound);
			}
		}
		else
		{	CEquStr(pbPtr->error, className);
			err = XError(kBAPI_ClassError, Err_JavaClassNotFound);
		}
	}

return _CheckException(runRecP, pbPtr, &err);
}

//===========================================================================================
static XErr	_GetJClassObject(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, ObjRef *objRef, JClassDescr *jClassDescrP, Boolean *sideEffectP)
{
long			tLen;
XErr			err = noErr;
unsigned long	threadID;

	tLen = sizeof(JClassDescr);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, objRef, (Ptr)jClassDescrP, &tLen, 0, nil))
	{	if NOT(err = XGetCurrentThread(&threadID))
		{	if (threadID != jClassDescrP->threadID)
			{	if NOT(err = _FillJClassDescr(runRecP, jClassDescrP, jClassDescrP->class_name, pbPtr, nil))
				{	jClassDescrP->threadID = threadID;
					if NOT(err = BAPI_ModifyObj(pbPtr->api_data, objRef, (Ptr)jClassDescrP, sizeof(JClassDescr)))
					{	if (sideEffectP)
							*sideEffectP = true;
					}
				}
			}
		}
	}
	
return err;
}	

//===========================================================================================
static XErr	_UpdateNeededJClasses(JClassRunRecord *runRecP, Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
JNIEnv 		*envP;
jclass		classLoaderClass, reflectionConstructorClass;
jmethodID	getSystemClassLoaderID;
jobject		jobj;

	envP = runRecP->envP;
	if NOT(runRecP->integerClass = (*envP)->FindClass(envP, "java/lang/Integer"))
		goto out_err;
	if NOT(runRecP->booleanClass = (*envP)->FindClass(envP, "java/lang/Boolean"))
		goto out_err;
	if NOT(runRecP->floatClass = (*envP)->FindClass(envP, "java/lang/Float"))
		goto out_err;
	if NOT(runRecP->charClass = (*envP)->FindClass(envP, "java/lang/Character"))
		goto out_err;		
	if NOT(runRecP->byteClass = (*envP)->FindClass(envP, "java/lang/Byte"))
		goto out_err;
	if NOT(runRecP->shortClass = (*envP)->FindClass(envP, "java/lang/Short"))
		goto out_err;
	if NOT(runRecP->longClass = (*envP)->FindClass(envP, "java/lang/Long"))
		goto out_err;
	if NOT(runRecP->doubleClass = (*envP)->FindClass(envP, "java/lang/Double"))
		goto out_err;
	if NOT(runRecP->javaLangStringClass = (*envP)->FindClass(envP, "java/lang/String"))
		goto out_err;
	if NOT(runRecP->javaLangArrayClass = (*envP)->FindClass(envP, "java/lang/reflect/Array"))
		goto out_err;
	if NOT(runRecP->classClass = (*envP)->FindClass(envP, "java/lang/Class"))
		goto out_err;
	if NOT(runRecP->reflectionMethodClass = (*envP)->FindClass(envP, "java/lang/reflect/Method"))
		goto out_err;
	if NOT(reflectionConstructorClass = (*envP)->FindClass(envP, "java/lang/reflect/Constructor"))
		goto out_err;
	if NOT(runRecP->reflectionFieldClass = (*envP)->FindClass(envP, "java/lang/reflect/Field"))
		goto out_err;
	if NOT(runRecP->reflectionModifierClass = (*envP)->FindClass(envP, "java/lang/reflect/Modifier"))
		goto out_err;
	if NOT(classLoaderClass = (*envP)->FindClass(envP, "java/lang/ClassLoader"))
		goto out_err;
	
	// for redirect
	if NOT(runRecP->fileClass = (*envP)->FindClass(envP, "java/io/File"))
		goto out_err;
	if NOT(runRecP->fileConstr = (*envP)->GetMethodID(envP, runRecP->fileClass, "<init>", "(Ljava/lang/String;)V"))
		goto out_err;
	if NOT(runRecP->fileOutputStreamClass = (*envP)->FindClass(envP, "java/io/FileOutputStream"))
		goto out_err;
	if NOT(runRecP->fileOutputStreamConstr = (*envP)->GetMethodID(envP, runRecP->fileOutputStreamClass, "<init>", "(Ljava/io/File;)V"))
		goto out_err;
	if NOT(runRecP->printStreamClass = (*envP)->FindClass(envP, "java/io/PrintStream"))
		goto out_err;
	if NOT(runRecP->printStreamConstr = (*envP)->GetMethodID(envP, runRecP->printStreamClass, "<init>", "(Ljava/io/OutputStream;)V"))
		goto out_err;
	if NOT(runRecP->systemClass = (*envP)->FindClass(envP, "java/lang/System"))
		goto out_err;
	if NOT(runRecP->systemSetOut = (*envP)->GetStaticMethodID(envP, runRecP->systemClass, "setOut", "(Ljava/io/PrintStream;)V"))
		goto out_err;
	if NOT(runRecP->systemSetErr = (*envP)->GetStaticMethodID(envP, runRecP->systemClass, "setErr", "(Ljava/io/PrintStream;)V"))
		goto out_err;
	if NOT(runRecP->closeID = (*envP)->GetMethodID(envP, runRecP->fileOutputStreamClass, "close", "()V"))
		goto out_err;
	if (err = CString2jstring(envP, gsStreamOutPath, &jobj, pbPtr->error))
		goto out_err;
	if NOT(runRecP->outFile = (*envP)->NewObject(envP, runRecP->fileClass, runRecP->fileConstr, jobj))
		goto out_err;
	if (err = CString2jstring(envP, gsStreamErrPath, &jobj, pbPtr->error))
		goto out_err;
	if NOT(runRecP->errFile = (*envP)->NewObject(envP, runRecP->fileClass, runRecP->fileConstr, jobj))
		goto out_err;
	if (err = _RedirectStd(runRecP, false, &runRecP->outStream))
		goto out_err;
	if (err = _RedirectStd(runRecP, true, &runRecP->errStream))
		goto out_err;
	
	// Class loader
	if NOT(getSystemClassLoaderID = (*envP)->GetStaticMethodID(envP, classLoaderClass, "getSystemClassLoader", "()Ljava/lang/ClassLoader;"))
		goto out_err;
	if NOT(runRecP->systemClassLoader = (*envP)->CallStaticObjectMethod(envP, classLoaderClass, getSystemClassLoaderID))
		goto out_err;
	
	/*runRecP->classReloader = nil;
	if (classReloader = (*envP)->FindClass(envP, "ClassReloader"))
	{
	jmethodID	methodID;						
	
		methodID = (*envP)->GetMethodID(envP, classReloader, "<init>", "()V");
		runRecP->classReloader = (*envP)->NewObject(envP, classReloader, methodID);
		runRecP->reloaderLoadClassID = (*envP)->GetMethodID(envP, classReloader, "loadClass", "(Ljava/lang/String;Z)Ljava/lang/Class;");
	}
	else
		(*envP)->ExceptionClear(envP);*/
	
	// Reflection
	if NOT(runRecP->getDeclaredMethodID = (*envP)->GetMethodID(envP, runRecP->classClass, "getDeclaredMethod", "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;"))
		goto out_err;
	if NOT(runRecP->getMethodsID = (*envP)->GetMethodID(envP, runRecP->classClass, "getMethods", "()[Ljava/lang/reflect/Method;"))
		goto out_err;
	if NOT(runRecP->getConstructorsID = (*envP)->GetMethodID(envP, runRecP->classClass, "getConstructors", "()[Ljava/lang/reflect/Constructor;"))
		goto out_err;
	if NOT(runRecP->getDeclaredFieldID = (*envP)->GetMethodID(envP, runRecP->classClass, "getDeclaredField", "(Ljava/lang/String;)Ljava/lang/reflect/Field;"))
		goto out_err;
	if NOT(runRecP->getdFieldsID = (*envP)->GetMethodID(envP, runRecP->classClass, "getFields", "()[Ljava/lang/reflect/Field;"))
		goto out_err;
	if NOT(runRecP->isAssignableFromID = (*envP)->GetMethodID(envP, runRecP->classClass, "isAssignableFrom", "(Ljava/lang/Class;)Z"))
		goto out_err;
	if NOT(runRecP->getSuperclassID = (*envP)->GetMethodID(envP, runRecP->classClass, "getSuperclass", "()Ljava/lang/Class;"))
		goto out_err;
	// Methods
	if NOT(runRecP->getReturnTypeID = (*envP)->GetMethodID(envP, runRecP->reflectionMethodClass, "getReturnType", "()Ljava/lang/Class;"))
		goto out_err;
	if NOT(runRecP->getMethodModifiersID = (*envP)->GetMethodID(envP, runRecP->reflectionMethodClass, "getModifiers", "()I"))
		goto out_err;
	if NOT(runRecP->getMethodParameterTypesID = (*envP)->GetMethodID(envP, runRecP->reflectionMethodClass, "getParameterTypes", "()[Ljava/lang/Class;"))
		goto out_err;
	if NOT(runRecP->getConstructorParameterTypesID = (*envP)->GetMethodID(envP, reflectionConstructorClass, "getParameterTypes", "()[Ljava/lang/Class;"))
		goto out_err;
	if NOT(runRecP->getMethodNameID = (*envP)->GetMethodID(envP, runRecP->reflectionMethodClass, "getName", "()Ljava/lang/String;"))
		goto out_err;
	// Fields
	if NOT(runRecP->getTypeID = (*envP)->GetMethodID(envP, runRecP->reflectionFieldClass, "getType", "()Ljava/lang/Class;"))
		goto out_err;
	if NOT(runRecP->getFieldModifiersID = (*envP)->GetMethodID(envP, runRecP->reflectionFieldClass, "getModifiers", "()I"))
		goto out_err;
	if NOT(runRecP->getFieldNameID = (*envP)->GetMethodID(envP, runRecP->reflectionMethodClass, "getName", "()Ljava/lang/String;"))
		goto out_err;
	if NOT(runRecP->isStaticID = (*envP)->GetStaticMethodID(envP, runRecP->reflectionModifierClass, "isStatic", "(I)Z"))
		goto out_err;
	if NOT(runRecP->isPublicID = (*envP)->GetStaticMethodID(envP, runRecP->reflectionModifierClass, "isPublic", "(I)Z"))
		goto out_err;
	if NOT(runRecP->getNameID = (*envP)->GetMethodID(envP, runRecP->classClass, "getName", "()Ljava/lang/String;"))
		goto out_err;
	if NOT(runRecP->forNameID = (*envP)->GetStaticMethodID(envP, runRecP->classClass, "forName", "(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;"))
		goto out_err;

return noErr;

out_err:
return _CheckException(runRecP, pbPtr, &err);
}

//===========================================================================================
static XErr	_CreateRunRecord(long api_data, uint32_t *plugin_run_dataP, Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
JClassRunRecord		*runRecP;

	if (*plugin_run_dataP = NewPtrBlock(sizeof(JClassRunRecord), &err, (Ptr*)&runRecP))
	{	runRecP->threadID = 0;
		runRecP->outStream = 0;
		runRecP->errStream = 0;
	}

return err;
}

//===========================================================================================
static void	_DeleteRunRecord(long api_data, uint32_t *plugin_run_dataP)
{
JClassRunRecord		*runRecP = (JClassRunRecord*)GetPtr(*plugin_run_dataP);

	if (runRecP->outStream)
		_CloseStd(runRecP, runRecP->outStream);
	if (runRecP->errStream)
		_CloseStd(runRecP, runRecP->errStream);
	DisposeBlock(plugin_run_dataP);
}

//===========================================================================================
static XErr	_GetRunRecord(long api_data, uint32_t *plugin_run_dataP, JClassRunRecord **runRecPPtr, Biferno_ParamBlockPtr pbPtr)
{
unsigned long 		threadID;
JClassRunRecord		*runRecP;
XErr				err = noErr;

	if NOT(err = XGetCurrentThread(&threadID))
	{	runRecP = (JClassRunRecord*)GetPtr(*plugin_run_dataP);
		if (threadID != runRecP->threadID)
		{	if NOT(err = BAPI_JavaGetCurrentJNIEnv(api_data, (void**)&runRecP->envP))
			{	if NOT(err = _UpdateNeededJClasses(runRecP, pbPtr))
					runRecP->threadID = threadID;
			}
		}
		if NOT(err)
			*runRecPPtr = runRecP;
		else
			*runRecPPtr = nil;
	}
	
return err;
}

//===========================================================================================
static XErr	_ObjRefToString(long api_data, JNIEnv *envP, ObjRef *tObjRefP, ArrayIndexRec *index, jstring	*theJStringP)
{
CStr255		aCStr;
BlockRef	ref;
char		*stringP;
long		stringLen;
XErr		err = noErr;

	// ex if NOT(err = BAPI_ResolveArrayElem(api_data, tObjRefP, index, 1, nil, nil, nil, tObjRefP))
	if NOT(err = BAPI_ElementOfArrayExt(api_data, tObjRefP, index, 1, tObjRefP))
	{	if NOT(err = BAPI_GetStringBlock(api_data, tObjRefP, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
		{	stringP[stringLen] = 0;
			err = CString2jstring(envP, stringP, theJStringP, nil);
			BAPI_ReleaseBlock(&ref);
		}
	}

return err;
}

//===========================================================================================
static XErr	_JClassObjRefToJClass(long api_data, ObjRef *objRefP, ArrayIndexRec *index, jclass *theJClassP, jobject *theJObjectP, char *qualifiedName, char *strError)
{
XErr		err = noErr;
JClassDescr	jClassDescr;
long		tLen;

	// ex if NOT(err = BAPI_ResolveArrayElem(api_data, objRefP, index, 1, nil, nil, nil, objRefP))
	if NOT(err = BAPI_ElementOfArrayExt(api_data, objRefP, index, 1, objRefP))
	{	tLen = sizeof(JClassDescr);
		if NOT(err = BAPI_ReadObj(api_data, objRefP, (Ptr)&jClassDescr, &tLen, 0, nil))
		{	if (jClassDescr.j_object)
			{	*theJClassP = jClassDescr.j_class;
				*theJObjectP = jClassDescr.j_object;
				if (qualifiedName)
					CEquStr(qualifiedName, jClassDescr.class_name);
			}
			else
			{	err = XError(kBAPI_ClassError, Err_JClassError);
				CEquStr(strError, "Error: the Method is not static, object is required");
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_ArrayToJArray(long api_data, JClassRunRecord *runRecP , ObjRef *arrayObjRef, jarray *jArrayP, char *qualifier, char *signature, Biferno_ParamBlockPtr pbPtr)
{
long			aLong, arrayDim, arrayType;
jarray			jArray;
BlockRef		bl = 0;
Ptr				p;
int				i;
ArrayIndexRec	index;
ObjRef			tObjRef;
XErr			err = noErr;
JNIEnv 			*envP = runRecP->envP;

	CEquStr(qualifier, "[");
	*index.ind_name = 0;
	if NOT(err = BAPI_GetArrayInfo(api_data, arrayObjRef, &arrayDim, &arrayType, nil))
	{	if (arrayType == gs_bool_id)
		{	if (jArray = (*envP)->NewBooleanArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jboolean) * arrayDim, &err, &p))
				{	//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						// ex if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToBoolean(api_data, &tObjRef, (Boolean*)p, kExplicitTypeCast);
							p += sizeof(jboolean);
						}
					}
					(*envP)->SetBooleanArrayRegion(envP, jArray, 0, arrayDim, (jboolean*)GetPtr(bl));
					CAddStr(qualifier, "Z");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_int_id)
		{	if (jArray = (*envP)->NewIntArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jint) * arrayDim, &err, &p))
				{	//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						// if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToInt(api_data, &tObjRef, (long*)p, kExplicitTypeCast);
							p += sizeof(jint);
						}
					}
					(*envP)->SetIntArrayRegion(envP, jArray, 0, arrayDim, (jint*)GetPtr(bl));
					CAddStr(qualifier, "I");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_byte_id)
		{	if (jArray = (*envP)->NewByteArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jbyte) * arrayDim, &err, &p))
				{	//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						// if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToInt(api_data, &tObjRef, &aLong, kExplicitTypeCast);
							*(Byte*)p = (Byte)aLong;
							p += sizeof(jbyte);
						}
					}
					(*envP)->SetByteArrayRegion(envP, jArray, 0, arrayDim, (jbyte*)GetPtr(bl));
					CAddStr(qualifier, "B");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_short_id)
		{	if (jArray = (*envP)->NewShortArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jshort) * arrayDim, &err, &p))
				{	//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						// if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToInt(api_data, &tObjRef, &aLong, kExplicitTypeCast);
							*(jshort*)p = (jshort)aLong;
							p += sizeof(jshort);
						}
					}
					(*envP)->SetShortArrayRegion(envP, jArray, 0, arrayDim, (jshort*)GetPtr(bl));
					CAddStr(qualifier, "S");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_long_id)
		{	LONGLONG 	ll;
			
			if (jArray = (*envP)->NewLongArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jlong) * arrayDim, &err, &p))
				{	//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						// if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToLong(api_data, &tObjRef, &ll, kExplicitTypeCast);
							*(jlong*)p = ll;
							p += sizeof(jlong);
						}
					}
					(*envP)->SetLongArrayRegion(envP, jArray, 0, arrayDim, (jlong*)GetPtr(bl));
					CAddStr(qualifier, "J");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_unsigned_id)
		{	if (jArray = (*envP)->NewIntArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jint) * arrayDim, &err, &p))
				{	unsigned long	uLong;
					
					//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						// if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToUnsigned(api_data, &tObjRef, &uLong, kExplicitTypeCast);
							*(jint*)p = uLong;
							p += sizeof(jint);
						}
					}
					(*envP)->SetIntArrayRegion(envP, jArray, 0, arrayDim, (jint*)GetPtr(bl));
					CAddStr(qualifier, "I");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_float_id)
		{	if (jArray = (*envP)->NewFloatArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jfloat) * arrayDim, &err, &p))
				{	double	r;
				
					//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						// if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToDouble(api_data, &tObjRef, &r, kExplicitTypeCast);
							*(jfloat*)p = (jfloat)r;
							p += sizeof(jfloat);
						}
					}
					(*envP)->SetFloatArrayRegion(envP, jArray, 0, arrayDim, (jfloat*)GetPtr(bl));
					CAddStr(qualifier, "F");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_double_id)
		{	if (jArray = (*envP)->NewDoubleArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jdouble) * arrayDim, &err, &p))
				{	double	r;
					
					//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						//if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToDouble(api_data, &tObjRef, &r, kExplicitTypeCast);
							*(jdouble*)p = r;
							p += sizeof(jdouble);
						}
					}
					(*envP)->SetDoubleArrayRegion(envP, jArray, 0, arrayDim, (jdouble*)GetPtr(bl));
					CAddStr(qualifier, "D");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_char_id)
		{	if (jArray = (*envP)->NewCharArray(envP, arrayDim))
			{	if (bl = NewBlockLocked(sizeof(jchar) * arrayDim, &err, &p))
				{	char	ch;
				
					//LockBlock(bl);
					//p = GetPtr(bl);
					for (i = 1; i <= arrayDim; i++)
					{	tObjRef = *arrayObjRef;
						index.ind = i;
						//if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
						if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
						{	err = BAPI_ObjToString(api_data, &tObjRef, &ch, nil, 1, kExplicitTypeCast);
							*(jchar*)p = ch;
							p += sizeof(jchar);
						}
					}
					(*envP)->SetCharArrayRegion(envP, jArray, 0, arrayDim, (jchar*)GetPtr(bl));
					CAddStr(qualifier, "C");
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JClassError);
		}
		else if (arrayType == gs_string_id)
		{	if (arrayDim)
			{	jstring	theJString;
			
				tObjRef = *arrayObjRef;
				index.ind = 1;
				if NOT(err = _ObjRefToString(api_data, envP, &tObjRef, &index, &theJString))
				{	if (jArray = (*envP)->NewObjectArray(envP, arrayDim, runRecP->javaLangStringClass, theJString))
					{	if (arrayDim > 1)
						{	for (i = 2; (i <= arrayDim) && NOT(err); i++)
							{	tObjRef = *arrayObjRef;
								index.ind = i;
								if NOT(err = _ObjRefToString(api_data, envP, &tObjRef, &index, &theJString))
								{	(*envP)->SetObjectArrayElement(envP, jArray, i-1, theJString);
									if ((*envP)->ExceptionOccurred(envP))
										err = _CheckException(runRecP, pbPtr, &err);
									/*{	(*envP)->ExceptionDescribe(envP);
										(*envP)->ExceptionClear(envP);
										err = XError(kBAPI_ClassError, Err_JavaException);
									}*/
								}
							}
						}
						CEquStr(qualifier, "java.lang.reflect.Array");
						CEquStr(signature, "[Ljava/lang/String;");
					}
				}
			}
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
		}
		else if (arrayType == gs_array_id)
		{	tObjRef = *arrayObjRef;
			index.ind = 1;
			//if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &index, 1, nil, nil, nil, &tObjRef))
			if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &index, 1, &tObjRef))
				err = _ArrayToJArray(api_data, runRecP, &tObjRef, jArrayP, qualifier, signature, pbPtr);
		}
		else if (arrayType == jClassID)
		{	if (arrayDim)
			{	jobject	theJObject;
				jclass	theJClass;
				CStr255	qualifiedName;
			
				tObjRef = *arrayObjRef;
				index.ind = 1;
				if NOT(err = _JClassObjRefToJClass(api_data, &tObjRef, &index, &theJClass, &theJObject, qualifiedName, pbPtr->error))
				{	if (jArray = (*envP)->NewObjectArray(envP, arrayDim, theJClass, theJObject))
					{	if (arrayDim > 1)
						{	for (i = 2; (i <= arrayDim) && NOT(err); i++)
							{	tObjRef = *arrayObjRef;
								index.ind = i;
								if NOT(err = _JClassObjRefToJClass(api_data, &tObjRef, &index, &theJClass, &theJObject, nil, pbPtr->error))
								{	(*envP)->SetObjectArrayElement(envP, jArray, i-1, theJObject);
									if ((*envP)->ExceptionOccurred(envP))
										err = _CheckException(runRecP, pbPtr, &err);
									/*{	(*envP)->ExceptionDescribe(envP);
										(*envP)->ExceptionClear(envP);
										err = XError(kBAPI_ClassError, Err_JavaException);
									}*/
								}
							}
						}
						CEquStr(qualifier, "java.lang.reflect.Array");
						CEquStr(signature, "[L");
						CAddStr(signature, qualifiedName);
						CAddStr(signature, ";");
					}
				}
			}
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
		}
		else
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
	}

	if NOT(err)
		*jArrayP = jArray;
	if (bl)
		DisposeBlock(&bl);

if NOT(*signature)
	CEquStr(signature, qualifier);
return err;
}

//===========================================================================================
static XErr	_GetObjectClass(Biferno_ParamBlockPtr pbPtr, JNIEnv *envP, JParam *jParamsP, jvalue *arg, jobject *jClassObjectP)
{
XErr		err = noErr;

	if (jParamsP->paramType == k_Object)
	{	if ((arg->l == NULL_JAVA_OBJECT_POINTER) || NOT(arg->l))
			*jClassObjectP = jParamsP->jcl;
		else
			*jClassObjectP = (*envP)->GetObjectClass(envP, arg->l);
		if NOT(*jClassObjectP)
			err = XError(kBAPI_ClassError, Err_JClassError);
	}
	else
		err = GetObjectField(envP, jParamsP->jcl, "TYPE", "Ljava/lang/Class;", jClassObjectP, pbPtr->error);

return err;
}

//===========================================================================================
static XErr	_ClassArray2jclassarray(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, JParam *jParamsP, long totJClasses, jvalue *args, jarray *theJArrayP)
{
int			i;
XErr		err = noErr;
jobject		jClassObject;
JNIEnv 		*envP = runRecP->envP;

	if (totJClasses > 0)
	{	if NOT(err = _GetObjectClass(pbPtr, envP, jParamsP, &args[0], &jClassObject))
		{	if (*theJArrayP = (*envP)->NewObjectArray(envP, totJClasses, runRecP->classClass, jClassObject))
			{	if (totJClasses > 1)
				{	jParamsP++;
					for (i = 1; (i < totJClasses) && NOT(err); i++, jParamsP++)
					{	if NOT(err = _GetObjectClass(pbPtr, envP, jParamsP, &args[i], &jClassObject))
							(*envP)->SetObjectArrayElement(envP, *theJArrayP, i, jClassObject);
					}
				}
			}
		}
	}

if ((*envP)->ExceptionOccurred(envP))
	err = _CheckException(runRecP, pbPtr, &err);
return err;
}

//===========================================================================================
static XErr	_SignatureFromType(char *type, char *returnSignature, long *typeP)															
{
XErr		err = noErr;
CStr255		aStr;

	if (*type == '[')
	{	*typeP = k_Object;
		CEquStr(aStr, type);
		CSubstitute(aStr, '.', '/');
		CEquStr(returnSignature, aStr);
	}
	else if NOT(CCompareStrings_cs(type, "void"))
	{	CEquStr(returnSignature, "V");
		*typeP = k_Void;
	}
	else if NOT(CCompareStrings_cs(type, "boolean"))
	{	CEquStr(returnSignature, "Z");
		*typeP = k_Boolean;
	}
	else if NOT(CCompareStrings_cs(type, "byte"))
	{	CEquStr(returnSignature, "B");
		*typeP = k_Byte;
	}
	else if NOT(CCompareStrings_cs(type, "char"))
	{	CEquStr(returnSignature, "C");
		*typeP = k_Char;
	}
	else if NOT(CCompareStrings_cs(type, "short"))
	{	CEquStr(returnSignature, "S");
		*typeP = k_Short;
	}
	else if NOT(CCompareStrings_cs(type, "int"))
	{	CEquStr(returnSignature, "I");
		*typeP = k_Int;
	}
	else if NOT(CCompareStrings_cs(type, "long"))
	{	CEquStr(returnSignature, "J");
		*typeP = k_Long;
	}
	else if NOT(CCompareStrings_cs(type, "float"))
	{	CEquStr(returnSignature, "F");
		*typeP = k_Float;
	}
	else if NOT(CCompareStrings_cs(type, "double"))
	{	CEquStr(returnSignature, "D");
		*typeP = k_Double;
	}
	else
	{	if (CLen(type) < 255)
		{	CEquStr(aStr, "L");
			CAddStr(aStr, type);
			CAddStr(aStr, ";");
			CSubstitute(aStr, '.', '/');
			CEquStr(returnSignature, aStr);
		}
		else
			err = XError(kBAPI_ClassError, Err_JClassError);
		*typeP = k_Object;
	}
														
return err;													
}

//===========================================================================================
static jboolean	_ParametersMatch(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, jobject jMethodObject, jarray theJArray, char *method_signature, jmethodID getParametersTypeID)
{
XErr		err = noErr;
JNIEnv 		*envP = runRecP->envP;
jarray		methodTypes;
jsize		totParams, totArrayParams;
int			i;
jobject		j_curType, j_wantedType;
jboolean	match = true;
long		type;
CStr255		sign, curTypeName;
jstring		j_curTypeName;

	CEquStr(method_signature, "(");
	if (methodTypes = (*envP)->CallObjectMethod(envP, jMethodObject, getParametersTypeID))
	{	if (methodTypes)
			totParams = (*envP)->GetArrayLength(envP, methodTypes);
		else
			totParams = 0;
		if (theJArray)
			totArrayParams = (*envP)->GetArrayLength(envP, theJArray);
		else
			totArrayParams = 0;
		if (totParams == totArrayParams)		// have the same number of parameters
		{	for (i = 0; (i < totParams) && NOT(err); i++)
			{	if (j_curType = (*envP)->GetObjectArrayElement(envP, methodTypes, i))
				{	if (j_wantedType = (*envP)->GetObjectArrayElement(envP, theJArray, i))
					{	match = (*envP)->CallBooleanMethod(envP, j_curType, runRecP->isAssignableFromID, j_wantedType);
						if NOT(match)
							match = false;
						else
						{	if (j_curTypeName = (*envP)->CallObjectMethod(envP, j_curType, runRecP->getNameID))
							{	if NOT(err = jstring2CString(envP, j_curTypeName, curTypeName, 256, pbPtr->error))
								{	if NOT(err = _SignatureFromType(curTypeName, sign, &type))
										CAddStr(method_signature, sign);
								}
							}
							else
								err = XError(kBAPI_ClassError, Err_JavaException);
						}
					}
					else
						err = XError(kBAPI_ClassError, Err_JavaException);
				}
				else
					err = XError(kBAPI_ClassError, Err_JavaException);
			}
		}
		else
			match = false;
	}
	CAddStr(method_signature, ")");

if (err)
	match = false;
return match;
}

//===========================================================================================
static jobject	_IdentifyAssignableMethod(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, jobject j_classLoaded, char *methodName, jarray theJArray, char *method_signature)
{
jobject		publicMethods, jMethodObject;
JNIEnv 		*envP = runRecP->envP;
jsize		totMethods;
jobject		j_curMethod;
jstring		j_curName;
int			i;
XErr		err = noErr;
CStr255		curName;

	jMethodObject = nil;
#ifdef JCLASS_DEBUG
	jstring2CString(envP, (*envP)->CallObjectMethod(envP, j_classLoaded, runRecP->getNameID), curName, 256, pbPtr->error);
	printf("look for %s() in: %s\n", methodName, curName);
#endif
	if (publicMethods = (*envP)->CallObjectMethod(envP, j_classLoaded, runRecP->getMethodsID))
	{	totMethods = (*envP)->GetArrayLength(envP, publicMethods);
		for (i = 0; (i < totMethods) && NOT(err); i++)
		{	if (j_curMethod = (*envP)->GetObjectArrayElement(envP, publicMethods, i))
			{	if (j_curName = (*envP)->CallObjectMethod(envP, j_curMethod, runRecP->getMethodNameID))
				{	if NOT(err = jstring2CString(envP, j_curName, curName, 256, pbPtr->error))
					{	if NOT(CCompareStrings_cs(curName, methodName))
						{	if (_ParametersMatch(pbPtr, runRecP, j_curMethod, theJArray, method_signature, runRecP->getMethodParameterTypesID))
							{	jMethodObject = j_curMethod;
								goto out;
							}
						}
					}
				}
				else
					err = XError(kBAPI_ClassError, Err_JavaException);
			}
			else
				err = XError(kBAPI_ClassError, Err_JavaException);
		}
	}

out:
return jMethodObject;
}

//===========================================================================================
static XErr	_GetJMethodReturnType(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, JClassDescr *jClassDescrP, char *methodName, JParam *jParamsP, long totParams, jvalue *args, jclass *returnTypeP, char *returnSignature, char *returnQualifier, long *retTypeP, Boolean *isStaticP, char *method_signature)
{
XErr		err = noErr;
jstring		jMethodName;
jarray		theJArray;
jobject		jMethodObject;
jstring		jStringName;
jint		modifiers;
JNIEnv 		*envP = runRecP->envP;

	// J String of Method Name
	if (err = CString2jstring(envP, methodName, &jMethodName, pbPtr->error))
		goto out;
	// J Array of method's parameters classes
	if (jParamsP)
	{	if (err = _ClassArray2jclassarray(pbPtr, runRecP, jParamsP, totParams, args, &theJArray))
			goto out;
	}
	else
		theJArray = 0;	
	// method = myclass.getDeclaredMethod(jMethodName)
	if NOT(jMethodObject = (*envP)->CallObjectMethod(envP, jClassDescrP->j_classLoaded, runRecP->getDeclaredMethodID, jMethodName, theJArray))
	{	err = XError(kBAPI_Error, Err_NoSuchMethod);
		_CheckException(runRecP, pbPtr, &err);	// it is absolutely necessary to clear exception before continuing
		if (jMethodObject = _IdentifyAssignableMethod(pbPtr, runRecP, jClassDescrP->j_classLoaded, methodName, theJArray, method_signature))
		{	err = noErr;
			*pbPtr->error = 0;
		}
		else
			goto out;
	}
	// retType = method.getReturnType()
	if NOT(*returnTypeP = (*envP)->CallObjectMethod(envP, jMethodObject, runRecP->getReturnTypeID))
		goto out;
	// method.getModifiers()
	modifiers = (*envP)->CallIntMethod(envP, jMethodObject, runRecP->getMethodModifiersID);
	if ((*envP)->ExceptionOccurred(envP))
		goto out;
	// myMethodModifiers.isPublic()
	if NOT((*envP)->CallStaticBooleanMethod(envP, runRecP->reflectionModifierClass, runRecP->isPublicID, modifiers))
	{	err = XError(kBAPI_Error, Err_CantAccessThisMember);
		goto out;
	}
	// method.isStatic()
	*isStaticP = (*envP)->CallStaticBooleanMethod(envP, runRecP->reflectionModifierClass, runRecP->isStaticID, modifiers);
	if ((*envP)->ExceptionOccurred(envP))
		goto out;
	// retType.getName()
	if NOT(jStringName = (*envP)->CallObjectMethod(envP, *returnTypeP, runRecP->getNameID))
		goto out;
	if (err = jstring2CString(envP, jStringName, returnQualifier, 256, pbPtr->error))
		goto out;
	err = _SignatureFromType(returnQualifier, returnSignature, retTypeP);
	
out:
return _CheckException(runRecP, pbPtr, &err);
}

//===========================================================================================
static jobject	_IdentifyAssignableField(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, jobject j_classLoaded, char *fieldName, jvalue *valueP, JParam *jParamP)
{
jobject		publicFields, jFieldObject;
JNIEnv 		*envP = runRecP->envP;
jsize		totFields;
jobject		j_curField, j_wantedType, j_curType;
jstring		j_curName;
int			i;
XErr		err = noErr;
CStr255		curName;

	jFieldObject = nil;
	// for set property we check also that the value class isAssignableFrom
	// for get property the name match is enough
	if (valueP)
		err = _GetObjectClass(pbPtr, envP, jParamP, valueP, &j_wantedType);
	else
		j_wantedType = nil;
	if NOT(err)
	{	
	#ifdef JCLASS_DEBUG
		jstring2CString(envP, (*envP)->CallObjectMethod(envP, j_classLoaded, runRecP->getNameID), curName, 256, pbPtr->error);
		printf("look for %s in: %s\n", fieldName, curName);
	#endif
		if (publicFields = (*envP)->CallObjectMethod(envP, j_classLoaded, runRecP->getdFieldsID))
		{	totFields = (*envP)->GetArrayLength(envP, publicFields);
			for (i = 0; (i < totFields) && NOT(err); i++)
			{	if (j_curField = (*envP)->GetObjectArrayElement(envP, publicFields, i))
				{	if (j_curName = (*envP)->CallObjectMethod(envP, j_curField, runRecP->getFieldNameID))
					{	if NOT(err = jstring2CString(envP, j_curName, curName, 256, pbPtr->error))
						{	
						#ifdef JCLASS_DEBUG
							printf("field %s\n", curName);
						#endif
							if NOT(CCompareStrings_cs(curName, fieldName))
							{	if (j_wantedType)
								{	if (j_curType = (*envP)->CallObjectMethod(envP, j_curField, runRecP->getTypeID))
									{	if ((*envP)->CallBooleanMethod(envP, j_curType, runRecP->isAssignableFromID, j_wantedType))
										{	jFieldObject = j_curField;
											goto out;
										}
									}
								}
								else
								{	jFieldObject = j_curField;
									goto out;
								}
							}
						}
					}
					else
						err = XError(kBAPI_ClassError, Err_JavaException);
				}
				else
					err = XError(kBAPI_ClassError, Err_JavaException);
			}
		}
	}

out:
return jFieldObject;
}

//===========================================================================================
static XErr	_GetJFieldType(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, JClassDescr *jClassDescrP, char *fieldName, jclass *fieldTypeP, char *returnSignature, char *returnQualifier, long *retTypeP, Boolean *isStaticP, jvalue *valueP, JParam *jParamP)
{
XErr		err = noErr;
jstring		jFieldName;
jobject		jFieldObject;
jstring		jStringName;
jint		modifiers;
JNIEnv 		*envP = runRecP->envP;

	// J String of Field Name
	if (err = CString2jstring(envP, fieldName, &jFieldName, pbPtr->error))
		goto out;
	// myClass.getDeclaredField(fieldName)
	if NOT(jFieldObject = (*envP)->CallObjectMethod(envP, jClassDescrP->j_classLoaded, runRecP->getDeclaredFieldID, jFieldName))
	{	err = XError(kBAPI_Error, Err_NoSuchProperty);
		_CheckException(runRecP, pbPtr, &err);	// it is absolutely necessary to clear exception before continuing
		if (jFieldObject = _IdentifyAssignableField(pbPtr, runRecP, jClassDescrP->j_classLoaded, fieldName, valueP, jParamP))
		{	err = noErr;
			*pbPtr->error = 0;
		}
		else
			goto out;
	}
	// check if it is public
	
	// type = myField.getType()
	if NOT(*fieldTypeP = (*envP)->CallObjectMethod(envP, jFieldObject, runRecP->getTypeID))
		goto out;
	// myField.getModifiers()
	modifiers = (*envP)->CallIntMethod(envP, jFieldObject, runRecP->getFieldModifiersID);
	if ((*envP)->ExceptionOccurred(envP))
		goto out;
	// myFieldModifiers.isPublic()
	if NOT((*envP)->CallStaticBooleanMethod(envP, runRecP->reflectionModifierClass, runRecP->isPublicID, modifiers))
	{	err = XError(kBAPI_Error, Err_CantAccessThisMember);
		goto out;
	}
	// myFieldModifiers.isStatic()
	*isStaticP = (*envP)->CallStaticBooleanMethod(envP, runRecP->reflectionModifierClass, runRecP->isStaticID, modifiers);
	if ((*envP)->ExceptionOccurred(envP))
		goto out;
	// type.getName()
	if NOT(jStringName = (*envP)->CallObjectMethod(envP, *fieldTypeP, runRecP->getNameID))
		goto out;
	if (err = jstring2CString(envP, jStringName, returnQualifier, 256, pbPtr->error))
		goto out;
	err = _SignatureFromType(returnQualifier, returnSignature, retTypeP);
	
out:
return _CheckException(runRecP, pbPtr, &err);
}

//===========================================================================================
static XErr	_JError(JClassRunRecord *runRecP, Biferno_ParamBlockPtr pbPtr)
{
JNIEnv 		*envP = runRecP->envP;

	if ((*envP)->ExceptionOccurred(envP))
		return _CheckException(runRecP, pbPtr, nil);
	else
		return XError(kBAPI_ClassError, Err_JClassError);
}

//===========================================================================================
static XErr	_JObjectToObjRef(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, jobject jObject, ObjRef *objRefP, char *returnSignature, char *returnQualifier, char *strError)
{
int			ch = *returnSignature;
XErr		err = noErr;
JClassDescr	jClassDescr;
long		api_data = pbPtr->api_data;
JNIEnv 		*envP = runRecP->envP;

	if (jObject)
	{	if (ch == '[')
		{	jsize			arrDim = (*envP)->GetArrayLength(envP, jObject);
			long			errElemIDX;
			jboolean		isCopy;
			int				i;
			ParameterRec	*varRecs = nil;
			BlockRef		varRecsBlock = 0;
			Ptr				p;
			
			if (arrDim)
			{	if (varRecsBlock = NewBlockLocked(arrDim * sizeof(ParameterRec), &err, (Ptr*)&varRecs))
					ClearBlock(varRecs, arrDim * sizeof(ParameterRec));
			}
			if NOT(err)
			{	returnQualifier++;
				switch(ch = *(++returnSignature))
				{	case 'Z':
						if (p = (Ptr)(*envP)->GetBooleanArrayElements(envP, jObject, &isCopy))
						{	Boolean		aBool;
							jboolean	*tempP = (jboolean*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aBool = *tempP++;
								*varRecs[i].name = 0;
								err = BAPI_BooleanToObj(api_data, aBool, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseBooleanArrayElements(envP, jObject, (jboolean*)p, JNI_ABORT);
						}
						break;
					case 'B':
						if (p = (Ptr)(*envP)->GetByteArrayElements(envP, jObject, &isCopy))
						{	long	aLong;
							jbyte	*tempP = (jbyte*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aLong = *tempP++;
								*varRecs[i].name = 0;
								err = BAPI_IntToObj(api_data, aLong, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseByteArrayElements(envP, jObject, (jbyte*)p, JNI_ABORT);
						}
						break;
					case 'C':
						if (p = (Ptr)(*envP)->GetCharArrayElements(envP, jObject, &isCopy))
						{	char	aChar;
							jchar	*tempP = (jchar*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aChar = (char)*tempP++;
								*varRecs[i].name = 0;
								err = BAPI_StringToObj(api_data, &aChar, 1, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseCharArrayElements(envP, jObject, (jchar*)p, JNI_ABORT);
						}
						break;
					case 'S':
						if (p = (Ptr)(*envP)->GetShortArrayElements(envP, jObject, &isCopy))
						{	long	aLong;
							jshort	*tempP = (jshort*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aLong = *tempP++;
								*varRecs[i].name = 0;
								err = BAPI_IntToObj(api_data, aLong, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseShortArrayElements(envP, jObject, (jshort*)p, JNI_ABORT);
						}
						break;
					case 'I':
						if (p = (Ptr)(*envP)->GetIntArrayElements(envP, jObject, &isCopy))
						{	long	aLong;
							jint	*tempP = (jint*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aLong = *tempP++;
								*varRecs[i].name = 0;
								err = BAPI_IntToObj(api_data, aLong, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseIntArrayElements(envP, jObject, (jint*)p, JNI_ABORT);
						}
						break;
					case 'J':
						if (p = (Ptr)(*envP)->GetLongArrayElements(envP, jObject, &isCopy))
						{	LONGLONG	aLong;
							jlong		*tempP = (jlong*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aLong = (long)*tempP++;
								*varRecs[i].name = 0;
								err = BAPI_LongToObj(api_data, aLong, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseLongArrayElements(envP, jObject, (jlong*)p, JNI_ABORT);
						}
						break;
					case 'F':
						if (p = (Ptr)(*envP)->GetDoubleArrayElements(envP, jObject, &isCopy))
						{	double	aDouble;
							jdouble	*tempP = (jdouble*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aDouble = *tempP++;
								*varRecs[i].name = 0;
								err = BAPI_DoubleToObj(api_data, aDouble, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseDoubleArrayElements(envP, jObject, (jdouble*)p, JNI_ABORT);
						}
						break;
					case 'D':
						if (p = (Ptr)(*envP)->GetDoubleArrayElements(envP, jObject, &isCopy))
						{	double	aDouble;
							jdouble	*tempP = (jdouble*)p;
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	aDouble = *tempP++;
								*varRecs[i].name = 0;
								err = BAPI_DoubleToObj(api_data, aDouble, &varRecs[i].objRef);
							}
							if NOT(err)
								err = BAPI_ArrayToObj(api_data, true, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							(*envP)->ReleaseDoubleArrayElements(envP, jObject, (jdouble*)p, JNI_ABORT);
						}
						break;
					case '[':
						{
						jobject	jObj;
						
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	*varRecs[i].name = 0;
								if (jObj = (*envP)->GetObjectArrayElement(envP, jObject, i))
									err = _JObjectToObjRef(pbPtr, runRecP, jObj, &varRecs[i].objRef, returnSignature, returnQualifier, strError);
							}
							if NOT(err)
							{
							long 	type;
							Boolean	fixedSize;
								
								if (arrDim)
								{	type = BAPI_GetObjClassID(api_data, &varRecs[0].objRef);								
									if ((type == gs_int_id) || (type == gs_float_id) || (type == gs_unsigned_id) || (type == gs_bool_id) ||
										(type == gs_double_id) || (type == gs_byte_id) || (type == gs_short_id) || (type == gs_long_id))
										fixedSize = true;
									else
										fixedSize = false;
								}
								else
									fixedSize = false;
								err = BAPI_ArrayToObj(api_data, fixedSize, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							}
						}
						break;
					case 'L':
						{
						jobject	jObj;
						CStr255	objQualifier;
						char	*objQualifierP = objQualifier;
						
							CEquStr(objQualifierP, returnQualifier+1);
							objQualifierP[CLen(returnQualifier)-2] = 0;
						
							for (i = 0; (i < arrDim) && NOT(err); i++)
							{	*varRecs[i].name = 0;
								if (jObj = (*envP)->GetObjectArrayElement(envP, jObject, i))
									err = _JObjectToObjRef(pbPtr, runRecP, jObj, &varRecs[i].objRef, returnSignature, objQualifier, strError);
							}
							if NOT(err)
							{	
							long 		type;
							Boolean		fixedSize;
								
								if (arrDim)
								{	type = BAPI_GetObjClassID(api_data, &varRecs[0].objRef);
									if ((type == gs_int_id) || (type == gs_float_id) || (type == gs_unsigned_id) || (type == gs_bool_id) ||
										(type == gs_double_id) || (type == gs_byte_id) || (type == gs_short_id) || (type == gs_long_id))
										fixedSize = true;
									else
										fixedSize = false;
								}
								else
									fixedSize = false;
								err = BAPI_ArrayToObj(api_data, fixedSize, varRecs, arrDim, &errElemIDX,	nil, objRefP);
							}
						}
						break;
				}
				if (varRecsBlock)
					DisposeBlock(&varRecsBlock);
			}
		}
		else
		{	if NOT(CCompareStrings_cs(returnQualifier, "java.lang.String"))
			{	long		length;
				BlockRef	bl;
				Ptr			p;
			
				length = (*envP)->GetStringUTFLength(envP, jObject);
				if (bl = NewBlockLocked(length+1, &err, &p))
				{	if NOT(err = jstring2CString(envP, jObject, p, length+1, strError))
						err = BAPI_StringToObj(api_data, p, length, objRefP);
					DisposeBlock(&bl);
				}
			}
			else
			{	
			jstring		jStringName;
			
				ClearBlock(&jClassDescr, sizeof(JClassDescr));
				jClassDescr.j_class = (*envP)->GetObjectClass(envP, jObject);
				jClassDescr.j_object = (*envP)->NewGlobalRef(envP, jObject);
				jStringName = (*envP)->CallObjectMethod(envP, jClassDescr.j_class, runRecP->getNameID);
				jstring2CString(envP, jStringName, jClassDescr.class_name, 256, pbPtr->error);
				if NOT(err = XGetCurrentThread(&jClassDescr.threadID))
				{	if NOT(err = _FillJClassDescr(runRecP, &jClassDescr, jClassDescr.class_name, pbPtr, nil))
						err = BAPI_BufferToObj(api_data, (Ptr)&jClassDescr, sizeof(JClassDescr), jClassID, false, nil, objRefP);
				}
			}
		}
	}
	else
	{	// null object
		ClearBlock(&jClassDescr, sizeof(JClassDescr));
		CEquStr(jClassDescr.class_name, returnQualifier);
		CSubstitute(returnQualifier, '.', '/');
		jClassDescr.j_class = (*envP)->FindClass(envP, returnQualifier);
		jClassDescr.j_object = NULL_JAVA_OBJECT_POINTER;
		if NOT(err = XGetCurrentThread(&jClassDescr.threadID))
		{	if NOT(err = _FillJClassDescr(runRecP, &jClassDescr, jClassDescr.class_name, pbPtr, nil))
				err = BAPI_BufferToObj(api_data, (Ptr)&jClassDescr, sizeof(JClassDescr), jClassID, false, nil, objRefP);
		}
	}

return err;
}

//===========================================================================================
static XErr	_ObjRef2JValue(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, ObjRef *objRefP, JParam *jParamsP, jvalue *jValueP)
{
XErr		err = noErr;
long		classID = BAPI_GetObjClassID(pbPtr->api_data, objRefP), api_data = pbPtr->api_data;
CStr255		classSignature;
JNIEnv 		*envP = runRecP->envP;

	if (classID == gs_bool_id)
	{	Boolean	boolValue;
	
		CEquStr(jParamsP->paramSign, "Z");
		err = BAPI_ObjToBoolean(api_data, objRefP, &boolValue, kImplicitTypeCast);
		jValueP->z = boolValue;
		CEquStr(jParamsP->qualifier, "");
		jParamsP->paramType = k_Boolean;
		jParamsP->jcl = runRecP->booleanClass;
	}
	else if (classID == gs_int_id)
	{	long	longValue;
	
		CEquStr(jParamsP->paramSign, "I");
		err = BAPI_ObjToInt(api_data, objRefP, &longValue, kImplicitTypeCast);
		jValueP->i = longValue;
		CEquStr(jParamsP->qualifier, "");
		jParamsP->paramType = k_Int;
		jParamsP->jcl = runRecP->integerClass;
	}
	else if (classID == gs_byte_id)
	{	long	longValue;
	
		CEquStr(jParamsP->paramSign, "B");
		err = BAPI_ObjToInt(api_data, objRefP, &longValue, kImplicitTypeCast);
		jValueP->b = (char)longValue;
		CEquStr(jParamsP->qualifier, "");
		jParamsP->paramType = k_Byte;
		jParamsP->jcl = runRecP->byteClass;
	}
	else if (classID == gs_short_id)
	{	long	longValue;
	
		CEquStr(jParamsP->paramSign, "S");
		err = BAPI_ObjToInt(api_data, objRefP, &longValue, kImplicitTypeCast);
		jValueP->s = (short)longValue;
		CEquStr(jParamsP->qualifier, "");
		jParamsP->paramType = k_Short;
		jParamsP->jcl = runRecP->shortClass;
	}
	else if (classID == gs_long_id)
	{	long	longValue;
	
		CEquStr(jParamsP->paramSign, "J");
		err = BAPI_ObjToInt(api_data, objRefP, &longValue, kImplicitTypeCast);
		jValueP->j = longValue;
		CEquStr(jParamsP->qualifier, "");
		jParamsP->paramType = k_Long;
		jParamsP->jcl = runRecP->longClass;
	}
	else if (classID == gs_unsigned_id)
	{	unsigned long	uLongValue;
	
		CEquStr(jParamsP->paramSign, "I");
		err = BAPI_ObjToUnsigned(api_data, objRefP, &uLongValue, kImplicitTypeCast);
		jValueP->i = uLongValue;
		CEquStr(jParamsP->qualifier, "");
		jParamsP->paramType = k_Int;
		jParamsP->jcl = runRecP->integerClass;
	}
	else if (classID == gs_float_id)
	{	double	doubleValue;
	
		err = BAPI_ObjToDouble(api_data, objRefP, &doubleValue, kImplicitTypeCast);
		CEquStr(jParamsP->paramSign, "F");
		jValueP->f = (float)doubleValue;
		jParamsP->paramType = k_Float;
		jParamsP->jcl = runRecP->floatClass;
		CEquStr(jParamsP->qualifier, "");
	}
	else if (classID == gs_double_id)
	{	double	doubleValue;
	
		err = BAPI_ObjToDouble(api_data, objRefP, &doubleValue, kImplicitTypeCast);
		CEquStr(jParamsP->paramSign, "D");
		jValueP->d = doubleValue;
		jParamsP->paramType = k_Double;
		jParamsP->jcl = runRecP->doubleClass;
		CEquStr(jParamsP->qualifier, "");
	}
	else if (classID == gs_char_id)
	{	char	ch;
	
		CEquStr(jParamsP->paramSign, "C");
		err = BAPI_ObjToString(api_data, objRefP, &ch, nil, 1, kImplicitTypeCast);
		jValueP->c = ch;
		CEquStr(jParamsP->qualifier, "");
		jParamsP->paramType = k_Char;
		jParamsP->jcl = runRecP->charClass;
	}
	else if (classID == gs_string_id)
	{	
		CStr255		aCStr;
		BlockRef	ref = 0;
		long		stringLen;
		jstring		j_string;
		char		*stringP;
	
		if NOT(err = BAPI_GetStringBlock(api_data, objRefP, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
		{	stringP[stringLen] = 0;
			if NOT(err = CString2jstring(envP, stringP, &j_string, nil))
			{	CEquStr(jParamsP->paramSign, "Ljava/lang/String;");
				jValueP->l = j_string;
				CEquStr(jParamsP->qualifier, "java.lang.String");
				jParamsP->paramType = k_Object;
				jParamsP->jcl = 0;
			}
			BAPI_ReleaseBlock(&ref);
		}
	}
	else if (classID == gs_array_id)
	{
		jarray	jArray;
		
		if NOT(err = _ArrayToJArray(api_data, runRecP, objRefP, &jArray, jParamsP->qualifier, jParamsP->paramSign, pbPtr))
		{	jValueP->l = jArray;
			jParamsP->paramType = k_Object;
			jParamsP->jcl = 0;
		}
	}
	else if (classID == jClassID)
	{	JClassDescr	jClassDescr;
		long		tLen;
		
		tLen = sizeof(JClassDescr);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, objRefP, (Ptr)&jClassDescr, &tLen, 0, nil))
		{	if (jClassDescr.j_object)
			{	CEquStr(jParamsP->paramSign, "L");
				CEquStr(classSignature, jClassDescr.class_name);
				CSubstitute(classSignature, '.', '/');
				CAddStr(jParamsP->paramSign, classSignature);
				CAddStr(jParamsP->paramSign, ";");
				CEquStr(jParamsP->qualifier, jClassDescr.class_name);
				jParamsP->paramType = k_Object;
				jParamsP->jcl = jClassDescr.j_class;
				if (jClassDescr.j_object == NULL_JAVA_OBJECT_POINTER)
					jValueP->l = 0;
				else
					jValueP->l = jClassDescr.j_object;
			}
			else
			{	err = XError(kBAPI_ClassError, Err_JClassError);
				CEquStr(pbPtr->error, "jclass object required");
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);

return err;
}

//===========================================================================================
static XErr	_JValue2ObjRef(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, long retType, jvalue *valueP, char *returnTypeSignature, char *returnQualifier, ObjRef *resultObjRefP, char *strError)
{
XErr		err = noErr;
long		api_data = pbPtr->api_data;
//JNIEnv		*envP = runRecP->envP;

	switch(retType)
	{	case k_Void:
			BAPI_InvalObjRef(api_data, resultObjRefP);
			break;
		case k_Boolean:
			err = BAPI_BooleanToObj(api_data, valueP->z, resultObjRefP);
			break;
		case k_Byte:
			if NOT(err = BAPI_IntToObj(api_data, valueP->b, resultObjRefP))
				err = BAPI_ModifyObjClassID(api_data, resultObjRefP, gs_byte_id);
			break;
		case k_Char:
			if NOT(err = BAPI_StringToObj(api_data, (Ptr)&valueP->c, 1, resultObjRefP))
				err = BAPI_ModifyObjClassID(api_data, resultObjRefP, gs_char_id);
			break;
		case k_Short:
			if NOT(err = BAPI_IntToObj(api_data, valueP->s, resultObjRefP))
				err = BAPI_ModifyObjClassID(api_data, resultObjRefP, gs_short_id);
			break;
		case k_Int:
			err = BAPI_IntToObj(api_data, valueP->i, resultObjRefP);
			break;
		case k_Long:
			if NOT(err = BAPI_LongToObj(api_data, valueP->j, resultObjRefP))
				err = BAPI_ModifyObjClassID(api_data, resultObjRefP, gs_long_id);
			break;
		case k_Float:
			if NOT(err = BAPI_DoubleToObj(api_data, valueP->f, resultObjRefP))
				err = BAPI_ModifyObjClassID(api_data, resultObjRefP, gs_float_id);
			break;
		case k_Double:
			err = BAPI_DoubleToObj(api_data, valueP->d, resultObjRefP);
			break;
		case k_Object:
			err = _JObjectToObjRef(pbPtr, runRecP, valueP->l, resultObjRefP, returnTypeSignature, returnQualifier, strError);
			break;
	}

return err;
}


//===========================================================================================
static XErr	_GetJParamsFromParameters(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, ParameterRec *paramVarsP, long totParams, BlockRef *jParamsBlockRefP, BlockRef *jValueBlockRefP, char *method_signature)
{
BlockRef	jparamBl = 0, jvaluesBl = 0;
XErr		err = noErr;
JParam		*jParamsP;
//long		api_data = pbPtr->api_data;
jvalue		*jValuesP;
int			i, curLen;
//JNIEnv 		*envP = runRecP->envP;

	CEquStr(method_signature, "(");
	curLen = 1;
	if (totParams)
	{	if (jparamBl = NewBlockLocked(totParams * sizeof(JParam), &err, (Ptr*)&jParamsP))
		{	if (jvaluesBl = NewBlockLocked(totParams * sizeof(jvalue), &err, (Ptr*)&jValuesP))
			{	for (i = 0; i < totParams; i++, jParamsP++, paramVarsP++, jValuesP++)
				{	err = _ObjRef2JValue(pbPtr, runRecP, &paramVarsP->objRef, jParamsP, jValuesP);
					if NOT(err)
					{	if (curLen < 255)
						{	CAddStr(method_signature, jParamsP->paramSign);
							curLen += CLen(jParamsP->paramSign);
						}
						else
							err = XError(kBAPI_ClassError, Err_JClassError);
					}
				}
			}
		}
	}
	CAddStr(method_signature, ")");

if (err)
{	if (jparamBl)
		DisposeBlock(&jparamBl);
	if (jvaluesBl)
		DisposeBlock(&jvaluesBl);
}
else
{	*jParamsBlockRefP = jparamBl;
	*jValueBlockRefP = jvaluesBl;
}
return err;
}

//===========================================================================================
static XErr	_ArrayIndex(Biferno_ParamBlockPtr pbPtr, ObjRef *objRefP, ArrayIndexRec *indexRecP, long dim)
{
XErr	err = noErr;

	if ((BAPI_GetObjClassID(pbPtr->api_data, objRefP) == gs_array_id) && indexRecP->ind)
		err = BAPI_ElementOfArrayExt(pbPtr->api_data, objRefP, indexRecP, (short)dim, objRefP);
		//err = BAPI_ResolveArrayElem(pbPtr->api_data, objRefP, indexRecP, dim, nil, nil, nil, objRefP);
	
return err;
}

//===========================================================================================
static jobject	_IdentifyAssignableConstructor(Biferno_ParamBlockPtr pbPtr, JClassRunRecord *runRecP, jobject j_classLoaded, jarray theJArray, char *method_signature)
{
jobject		constructors, jMethodObject;
JNIEnv 		*envP = runRecP->envP;
jsize		totConstr;
jobject		j_curConstr;
int			i;
XErr		err = noErr;

	jMethodObject = nil;
	if (constructors = (*envP)->CallObjectMethod(envP, j_classLoaded, runRecP->getConstructorsID))
	{	totConstr = (*envP)->GetArrayLength(envP, constructors);
		for (i = 0; (i < totConstr) && NOT(err); i++)
		{	if (j_curConstr = (*envP)->GetObjectArrayElement(envP, constructors, i))
			{	if (_ParametersMatch(pbPtr, runRecP, j_curConstr, theJArray, method_signature, runRecP->getConstructorParameterTypesID))
				{	jMethodObject = j_curConstr;
					goto out;
				}
			}
			else
				err = XError(kBAPI_ClassError, Err_JavaException);
		}
	}

out:
return jMethodObject;
}

//===========================================================================================
static XErr	_ExecRedirected(long userData)
{
ExecRecord	*execRecordP = (ExecRecord*)userData;
XErr		err = noErr;
jvalue		returnValue;
jmethodID	methodID;

	if NOT(execRecordP->isStatic)
	{	if NOT(execRecordP->jClassDescr.j_object)
		{	err = XError(kBAPI_ClassError, Err_JClassError);
			CEquStr(execRecordP->pbPtr->error, "Error: the Method is not static, object is required");
		}
		else if (execRecordP->jClassDescr.j_object == NULL_JAVA_OBJECT_POINTER)
		{	err = XError(kBAPI_ClassError, Err_JClassError);
			CEquStr(execRecordP->pbPtr->error, "Error: can't apply method to null");
		}
		else if (methodID = (*execRecordP->envP)->GetMethodID(execRecordP->envP, execRecordP->jClassDescr.j_class, execRecordP->methodNameP, execRecordP->method_signature))
		{	switch(execRecordP->retType)
			{	case k_Void:
					(*execRecordP->envP)->CallVoidMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Boolean:
					returnValue.z = (*execRecordP->envP)->CallBooleanMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Byte:
					returnValue.b = (*execRecordP->envP)->CallByteMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Char:
					returnValue.c = (*execRecordP->envP)->CallCharMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Short:
					returnValue.s = (*execRecordP->envP)->CallShortMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Int:
					returnValue.i = (*execRecordP->envP)->CallIntMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Long:
					returnValue.j = (*execRecordP->envP)->CallLongMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Float:
					returnValue.f = (*execRecordP->envP)->CallFloatMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Double:
					returnValue.d = (*execRecordP->envP)->CallDoubleMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
				case k_Object:
					returnValue.l = (*execRecordP->envP)->CallObjectMethodA(execRecordP->envP, execRecordP->jClassDescr.j_object, methodID, execRecordP->args);
					break;
			}
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchMethod);
	}
	else
	{	if (execRecordP->jClassDescr.j_object)
		{	err = XError(kBAPI_ClassError, Err_JClassError);
			CEquStr(execRecordP->pbPtr->error, "Error: The Method is declared static, not applicable on object ");
		}
		else if (execRecordP->isConstructor)
		{	methodID = (*execRecordP->envP)->GetMethodID(execRecordP->envP, execRecordP->jClassDescr.j_class, execRecordP->methodNameP, execRecordP->method_signature);
			if NOT(methodID)
			{
			jobject		constr;
			jarray		theJArray;
			
				_CheckException(execRecordP->runRecP, execRecordP->pbPtr, &err);		// clear the exception
				if NOT(err = _ClassArray2jclassarray(execRecordP->pbPtr, execRecordP->runRecP, execRecordP->jParamsP, execRecordP->totParams, execRecordP->args, &theJArray))
				{	constr = _IdentifyAssignableConstructor(execRecordP->pbPtr, execRecordP->runRecP, execRecordP->jClassDescr.j_classLoaded, theJArray, execRecordP->method_signature);
					if (constr)
					{	CAddStr(execRecordP->method_signature, "V");
						methodID = (*execRecordP->envP)->GetMethodID(execRecordP->envP, execRecordP->jClassDescr.j_class, execRecordP->methodNameP, execRecordP->method_signature);
					}
				}
			}
		}
		else
			methodID = (*execRecordP->envP)->GetStaticMethodID(execRecordP->envP, execRecordP->jClassDescr.j_class, execRecordP->methodNameP, execRecordP->method_signature);
		if (methodID)
		{	switch(execRecordP->retType)
			{	case k_Void:
					(*execRecordP->envP)->CallStaticVoidMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Boolean:
					returnValue.z = (*execRecordP->envP)->CallStaticBooleanMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Byte:
					returnValue.b = (*execRecordP->envP)->CallStaticByteMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Char:
					returnValue.c = (*execRecordP->envP)->CallStaticCharMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Short:
					returnValue.s = (*execRecordP->envP)->CallStaticShortMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Int:
					returnValue.i = (*execRecordP->envP)->CallStaticIntMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Long:
					returnValue.j = (*execRecordP->envP)->CallStaticLongMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Float:
					returnValue.f = (*execRecordP->envP)->CallStaticFloatMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Double:
					returnValue.d = (*execRecordP->envP)->CallStaticDoubleMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
				case k_Object:
					if (execRecordP->isConstructor)
					{	CEquStr(execRecordP->returnTypeSignature, execRecordP->jClassDescr.class_name);
						returnValue.l = (*execRecordP->envP)->NewObjectA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					}
					else
						returnValue.l = (*execRecordP->envP)->CallStaticObjectMethodA(execRecordP->envP, execRecordP->jClassDescr.j_class, methodID, execRecordP->args);
					break;
			}
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchMethod);
	}				
	if NOT(err)
	{	if ((*execRecordP->envP)->ExceptionOccurred(execRecordP->envP))
			err = _CheckException(execRecordP->runRecP, execRecordP->pbPtr, &err);
		else
			err = _JValue2ObjRef(execRecordP->pbPtr, execRecordP->runRecP, execRecordP->retType, &returnValue, execRecordP->returnTypeSignature, execRecordP->returnQualifier, &execRecordP->exeMethodRecP->resultObjRef, execRecordP->pbPtr->error);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	JClass_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				api_data = pbPtr->api_data;
JNIEnv 				*envP;
BAPI_MemberRecord	jclassMethods[TOT_METHODES] = 
					{	"new", 			kNew, 				"jclass new(...)"
					};
BAPI_MemberRecord	jclassProps[TOT_PROPS] = 
					{	"null", 		kNull, 				"jclass"
					};

	if (err = BAPI_JavaLoadJVM(api_data))
	{	if (err == XError(kBAPI_Error, Err_NotImplemented))
			CEquStr(pbPtr->error, "Biferno >= 1.0.2 is needed");
		goto out;
	}
	if NOT(gs_bool_id = BAPI_ClassIDFromName(api_data, "boolean", false))
		goto out;
	if NOT(gs_byte_id = BAPI_ClassIDFromName(api_data, "byte", false))
		goto out;
	if NOT(gs_short_id = BAPI_ClassIDFromName(api_data, "short", false))
		goto out;
	if NOT(gs_int_id = BAPI_ClassIDFromName(api_data, "int", false))
		goto out;
	if NOT(gs_long_id = BAPI_ClassIDFromName(api_data, "long", false))
		goto out;
	if NOT(gs_unsigned_id = BAPI_ClassIDFromName(api_data, "unsigned", false))
		goto out;
	if NOT(gs_float_id = BAPI_ClassIDFromName(api_data, "float", false))
		goto out;
	if NOT(gs_double_id = BAPI_ClassIDFromName(api_data, "double", false))
		goto out;
	if NOT(gs_char_id = BAPI_ClassIDFromName(api_data, "char", false))
		goto out;
	if NOT(gs_string_id = BAPI_ClassIDFromName(api_data, "string", false))
		goto out;
	if NOT(gs_array_id = BAPI_ClassIDFromName(api_data, "array", false))
		goto out;
	if (err = BAPI_RegisterErrors(api_data, jClassID, START_ERR, gJClassErrorsStr, TOT_ERRORS))
		goto out;
	
	if NOT(err = BAPI_JavaGetCurrentJNIEnv(api_data, (void**)&envP))
	{	BAPI_GetBifernoHome(api_data, gsStreamOutPath);
		CAddStr(gsStreamOutPath, "jclass_bfr_out.txt");
		BAPI_RealPath(api_data, gsStreamOutPath, false);
		BAPI_NativePath(api_data, gsStreamOutPath);
		CEquStr(gsStreamOutPathXLib, gsStreamOutPath);
		BAPI_BifernoPath(api_data, gsStreamOutPathXLib);
		CEquStr(gsStreamOutPathXLib, gsStreamOutPathXLib + 6);

		BAPI_GetBifernoHome(api_data, gsStreamErrPath);
		CAddStr(gsStreamErrPath, "jclass_bfr_err.txt");
		BAPI_RealPath(api_data, gsStreamErrPath, false);
		BAPI_NativePath(api_data, gsStreamErrPath);
		CEquStr(gsStreamErrPathXLib, gsStreamErrPath);
		BAPI_BifernoPath(api_data, gsStreamErrPathXLib);
		CEquStr(gsStreamErrPathXLib, gsStreamErrPathXLib + 6);
		if NOT(err = BAPI_NewMethods(api_data, jClassID, jclassMethods, TOT_METHODES, nil))
			err = BAPI_NewProperties(api_data, jClassID, jclassProps, TOT_PROPS, nil);
	}

out:
return err;
}

//===========================================================================================
static XErr	JClass_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			stringLen;
long			api_data = pbPtr->api_data;
CStr255			aCStr;
Ptr				stringP;
BlockRef		ref = 0;
JNIEnv 			*envP;
JClassDescr		jClassDescr;
JClassRunRecord *runRecP;
jmethodID		cloneID;

	if NOT(err = _GetRunRecord(pbPtr->api_data, pbPtr->plugin_run_dataP, &runRecP, pbPtr))
	{
	ParameterRec		*paramP = constructorRecP->varRecsP;
	
		envP = runRecP->envP;
		switch(message)
		{
			case kConstructor:
				ClearBlock(&jClassDescr, sizeof(JClassDescr));
				if NOT(err = XGetCurrentThread(&jClassDescr.threadID))
				{	if (constructorRecP->totVars == 1)
					{	if NOT(err = BAPI_GetStringBlock(api_data, &paramP->objRef, aCStr, &stringP, &stringLen, &ref, kImplicitTypeCast))
						{	stringP[stringLen] = 0;
							err = _FillJClassDescr(runRecP, &jClassDescr, stringP, pbPtr, nil);
							BAPI_ReleaseBlock(&ref);
						}
					}
					else if (constructorRecP->totVars == 3)
						err = _FillJClassDescr(runRecP, &jClassDescr, nil, pbPtr, paramP);
					else
					{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
						CEquStr(pbPtr->error, "jclass(string classPath)");
					}
					if NOT(err)
						err = BAPI_BufferToObj(api_data, (Ptr)&jClassDescr, sizeof(JClassDescr), jClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
				}
				break;
				
			case kTypeCast:
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
				break;

			case kClone:
				if NOT(err = _GetJClassObject(pbPtr, runRecP, &constructorRecP->varRecsP->objRef, &jClassDescr, nil))
				{	if (jClassDescr.j_object)
					{	
						if (cloneID = (*envP)->GetStaticMethodID(envP, jClassDescr.j_classLoaded, "clone", "()Ljava/lang/Object;"))
						{	if NOT(jClassDescr.j_object = (*envP)->CallObjectMethod(envP, jClassDescr.j_object, cloneID))
								_CheckException(runRecP, pbPtr, &err);
						}
						else
							_CheckException(runRecP, pbPtr, &err);
					}
					else
						err = BAPI_BufferToObj(api_data, (Ptr)&jClassDescr, sizeof(JClassDescr), jClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
					
				}
				break;
		}
	}

return err;
}

//===========================================================================================
static XErr	JClass_Destructor(Biferno_ParamBlockPtr pbPtr)
{
#if __MWERKS__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
JNIEnv 			*envP = nil;
JClassDescr		jClassDescr;
long			tLen;

	tLen = sizeof(JClassDescr);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&jClassDescr, &tLen, 0, nil))
	{	if (tLen && jClassDescr.j_object && (jClassDescr.j_object != NULL_JAVA_OBJECT_POINTER))
		{	if NOT(err = BAPI_JavaGetCurrentJNIEnv(pbPtr->api_data, (void**)&envP))
				(*envP)->DeleteGlobalRef(envP, jClassDescr.j_object);
		}
	}

if (envP)
{	if ((*envP)->ExceptionOccurred(envP) != NULL)
	{	(*envP)->ExceptionDescribe(envP);
		(*envP)->ExceptionClear(envP);
	}
}
return err;
}

//===========================================================================================
static XErr	JClass_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
#if __MWERKS__
	#pragma unused(pbPtr)
#endif
XErr				err= noErr;

	err = XError(kBAPI_Error, Err_IllegalOperation);
		
return err;
}

//===========================================================================================
static XErr	JClass_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				retType;
CStr255				returnQualifier, returnTypeSignature, method_signature;
long 				api_data = pbPtr->api_data;
//long				totParams = exeMethodRecP->totParams;
BlockRef			jParamsBlockRef, jValuesBlockRef;
JNIEnv 				*envP;
JClassDescr			jClassDescr;
jclass				returnType;
Boolean				isStatic, isConstructor;
char				*methodNameP;
jvalue				*args = nil;
JClassRunRecord 	*runRecP;
ExecRecord			execRecord;
BlockRef			stdOut;
long				stdOutLen;

	if NOT(err = _GetRunRecord(api_data, pbPtr->plugin_run_dataP, &runRecP, pbPtr))
	{	envP = runRecP->envP;
		if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
			err = _GetJClassObject(pbPtr, runRecP, &exeMethodRecP->objRef, &jClassDescr, &exeMethodRecP->sideEffect);
		else
			err = XError(kBAPI_Error, Err_NoSuchMethod);
		if NOT(err)
		{	if NOT(err = _GetJParamsFromParameters(pbPtr, runRecP, exeMethodRecP->paramVarsP, exeMethodRecP->totParams, &jParamsBlockRef, &jValuesBlockRef, method_signature))
			{	if (jValuesBlockRef)
					args = (jvalue*)GetPtr(jValuesBlockRef);
				else
					args = nil;
				if (exeMethodRecP->methodID == kNew)
				{	isStatic = true;
					methodNameP = gs_Initer;
					retType = k_Object;
					returnType = jClassDescr.j_class;
					CEquStr(returnTypeSignature, "V");
					CEquStr(returnQualifier, "");	// cos� crea comunque un oggetto
					isConstructor = true;
				}
				else
				{	JParam	*jParamsP;
					
					if (jParamsBlockRef)
						jParamsP = (JParam*)GetPtr(jParamsBlockRef);
					else
						jParamsP = nil;
					err =  _GetJMethodReturnType(pbPtr, runRecP, &jClassDescr, exeMethodRecP->methodName, jParamsP, exeMethodRecP->totParams, args, &returnType, returnTypeSignature, returnQualifier, &retType, &isStatic, method_signature);
					methodNameP = exeMethodRecP->methodName;
					isConstructor = false;
				}
				if NOT(err)
				{	CAddStr(method_signature, returnTypeSignature);
					execRecord.isStatic = isStatic;
					execRecord.jClassDescr = jClassDescr;
					execRecord.envP = envP;
					execRecord.runRecP = runRecP;
					execRecord.pbPtr = pbPtr;
					execRecord.exeMethodRecP = exeMethodRecP;
					execRecord.retType = retType;
					execRecord.returnQualifier = returnQualifier;
					execRecord.returnTypeSignature = returnTypeSignature;
					execRecord.isConstructor = isConstructor;
					execRecord.args = args;
					execRecord.methodNameP = methodNameP;
					execRecord.method_signature = method_signature;
					execRecord.totParams = exeMethodRecP->totParams;
					execRecord.jParamsP = (JParam*)GetPtr(jParamsBlockRef);
					if NOT(err = _jclassRedirOutput(runRecP, _ExecRedirected, (long)&execRecord, &stdOut, &stdOutLen, nil, nil))
					{	err = BAPI_StandardOutput(api_data, GetPtr(stdOut), stdOutLen, true);
						DisposeBlock(&stdOut);
						if (stdOutLen)	// close and reopen input stream (to reset)
						{	
						XErr	err2 = noErr;
							
							_CloseStd(runRecP, runRecP->outStream);
							err2 = _RedirectStd(runRecP, false, &runRecP->outStream);
							if (err2 && NOT(err))
								err = err2;
						}						
					}
				}
				DisposeBlock(&jParamsBlockRef);
				DisposeBlock(&jValuesBlockRef);
			}
		}
	}
return _CheckException(runRecP, pbPtr, &err);
}

//===========================================================================================
static XErr	JClass_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetPropertyRec		*getPropertyRecP = &pbPtr->param.getPropertyRec;
long				retType;
jfieldID			propertyID;
CStr255				returnQualifier, field_signature;
long 				api_data = pbPtr->api_data;
JNIEnv 				*envP;
JClassDescr			jClassDescr;
jvalue				returnValue;
jclass				fieldType;
Boolean				isStatic;
JClassRunRecord 	*runRecP;

	if NOT(err = _GetRunRecord(pbPtr->api_data, pbPtr->plugin_run_dataP, &runRecP, pbPtr))
	{	envP = runRecP->envP;
		if NOT(err = _GetJClassObject(pbPtr, runRecP, &getPropertyRecP->objRef, &jClassDescr, nil))
		{	if (getPropertyRecP->propertyID == kNull)
			{	
			JClassDescr		nullJClassDescr;
			
				nullJClassDescr = jClassDescr;
				nullJClassDescr.j_object = NULL_JAVA_OBJECT_POINTER;
				err = BAPI_BufferToObj(api_data, (Ptr)&nullJClassDescr, sizeof(JClassDescr), jClassID, true, nil, &getPropertyRecP->resultObjRef);
			}
			else
			{	err =  _GetJFieldType(pbPtr, runRecP, &jClassDescr, getPropertyRecP->propertyName, &fieldType, field_signature, returnQualifier, &retType, &isStatic, nil, nil);
				if NOT(err)
				{	if NOT(isStatic)
					{	if NOT(jClassDescr.j_object)
						{	err = XError(kBAPI_ClassError, Err_JClassError);
							CEquStr(pbPtr->error, "Error: the Method is not static, object is required");
						}
						else if (jClassDescr.j_object == NULL_JAVA_OBJECT_POINTER)
						{	err = XError(kBAPI_ClassError, Err_JClassError);
							CEquStr(pbPtr->error, "Error: can't apply property to null");
						}
						else if (propertyID = (*envP)->GetFieldID(envP, jClassDescr.j_class, getPropertyRecP->propertyName, field_signature))
						{	switch(retType)
							{	case k_Void:
									err = XError(kBAPI_ClassError, Err_JClassError);
									break;
								case k_Boolean:
									returnValue.z = (*envP)->GetBooleanField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Byte:
									returnValue.b = (*envP)->GetByteField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Char:
									returnValue.c = (*envP)->GetCharField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Short:
									returnValue.s = (*envP)->GetShortField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Int:
									returnValue.i = (*envP)->GetIntField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Long:
									returnValue.j = (*envP)->GetLongField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Float:
									returnValue.f = (*envP)->GetFloatField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Double:
									returnValue.d = (*envP)->GetDoubleField(envP, jClassDescr.j_object, propertyID);
									break;
								case k_Object:
									returnValue.l = (*envP)->GetObjectField(envP, jClassDescr.j_object, propertyID);
									break;
							}
						}
						else
							err = XError(kBAPI_Error, Err_NoSuchProperty);
					}
					else
					{	if (jClassDescr.j_object)
						{	err = XError(kBAPI_ClassError, Err_JClassError);
							CEquStr(pbPtr->error, "Error: The Method is declared static, not applicable on object ");
						}
						else
							propertyID = (*envP)->GetStaticFieldID(envP, jClassDescr.j_class, getPropertyRecP->propertyName, field_signature);
						if (propertyID)
						{	switch(retType)
							{	case k_Void:
									err = XError(kBAPI_ClassError, Err_JClassError);
									break;
								case k_Boolean:
									returnValue.z = (*envP)->GetStaticBooleanField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Byte:
									returnValue.b = (*envP)->GetStaticByteField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Char:
									returnValue.c = (*envP)->GetStaticCharField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Short:
									returnValue.s = (*envP)->GetStaticShortField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Int:
									returnValue.i = (*envP)->GetStaticIntField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Long:
									returnValue.j = (*envP)->GetStaticLongField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Float:
									returnValue.f = (*envP)->GetStaticFloatField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Double:
									returnValue.d = (*envP)->GetStaticDoubleField(envP, jClassDescr.j_class, propertyID);
									break;
								case k_Object:
									returnValue.l = (*envP)->GetStaticObjectField(envP, jClassDescr.j_class, propertyID);
									break;
							}
						}
						else
							err = XError(kBAPI_Error, Err_NoSuchProperty);
					}				
					if NOT(err)
					{	if ((*envP)->ExceptionOccurred(envP))
							err = _CheckException(runRecP, pbPtr, &err);
						else
						{	if NOT(err = _JValue2ObjRef(pbPtr, runRecP, retType, &returnValue, field_signature, returnQualifier, &getPropertyRecP->resultObjRef, pbPtr->error))
								err = _ArrayIndex(pbPtr, &getPropertyRecP->resultObjRef, getPropertyRecP->propertyIndex, getPropertyRecP->propertyDim);
						}
					}
				}
			}
		}
		if ((*envP)->ExceptionOccurred(envP))
			err = _CheckException(runRecP, pbPtr, &err);
	}

return err;
}


//===========================================================================================
static XErr	JClass_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
jfieldID			propertyID;
CStr255				fieldQualifier, field_signature;
//long 				api_data = pbPtr->api_data;
JNIEnv 				*envP;
JClassDescr			jClassDescr;
Boolean				isStatic;
jvalue				value;
long				fieldType;
jclass				fieldTypeJClass;
JParam				jParam;
JClassRunRecord 	*runRecP;

	if (setPropertyRecP->propertyDim)
	{	CEquStr(pbPtr->error, "Java array fields must be set as a whole");
		return XError(kBAPI_Error, Err_IllegalOperation);
	}
	if NOT(err = _GetRunRecord(pbPtr->api_data, pbPtr->plugin_run_dataP, &runRecP, pbPtr))
	{	envP = runRecP->envP;
		if NOT(err = _GetJClassObject(pbPtr, runRecP, &setPropertyRecP->objRef, &jClassDescr, nil))
		{	if NOT(err = _ObjRef2JValue(pbPtr, runRecP, &setPropertyRecP->value, &jParam, &value))
			{	if NOT(err =  _GetJFieldType(pbPtr, runRecP, &jClassDescr, setPropertyRecP->propertyName, &fieldTypeJClass, field_signature, fieldQualifier, &fieldType, &isStatic, &value, &jParam))
				{	if NOT(isStatic)
					{	if NOT(jClassDescr.j_object)
						{	err = XError(kBAPI_ClassError, Err_JClassError);
							CEquStr(pbPtr->error, "Error: the Method is not static, object is required");
						}
						else if (jClassDescr.j_object == NULL_JAVA_OBJECT_POINTER)
						{	err = XError(kBAPI_ClassError, Err_JClassError);
							CEquStr(pbPtr->error, "Error: can't apply property to null");
						}
						else if (propertyID = (*envP)->GetFieldID(envP, jClassDescr.j_class, setPropertyRecP->propertyName, field_signature))
						{	switch(fieldType)
							{	case k_Void:
									err = XError(kBAPI_ClassError, Err_JClassError);
									break;
								case k_Boolean:
									(*envP)->SetBooleanField(envP, jClassDescr.j_object, propertyID, value.z);
									break;
								case k_Byte:
									(*envP)->SetByteField(envP, jClassDescr.j_object, propertyID, value.b);
									break;
								case k_Char:
									(*envP)->SetCharField(envP, jClassDescr.j_object, propertyID, value.c);
									break;
								case k_Short:
									(*envP)->SetShortField(envP, jClassDescr.j_object, propertyID, value.s);
									break;
								case k_Int:
									(*envP)->SetIntField(envP, jClassDescr.j_object, propertyID, value.i);
									break;
								case k_Long:
									(*envP)->SetLongField(envP, jClassDescr.j_object, propertyID, value.j);
									break;
								case k_Float:
									(*envP)->SetFloatField(envP, jClassDescr.j_object, propertyID, value.f);
									break;
								case k_Double:
									(*envP)->SetDoubleField(envP, jClassDescr.j_object, propertyID, value.d);
									break;
								case k_Object:
									(*envP)->SetObjectField(envP, jClassDescr.j_object, propertyID, value.l);
									break;
							}
						}
						else
							err = XError(kBAPI_Error, Err_NoSuchProperty);
					}
					else
					{	if (jClassDescr.j_object)
						{	err = XError(kBAPI_ClassError, Err_JClassError);
							CEquStr(pbPtr->error, "Error: The Method is declared static, not applicable on object ");
						}
						else
							propertyID = (*envP)->GetStaticFieldID(envP, jClassDescr.j_class, setPropertyRecP->propertyName, field_signature);
						if (propertyID)
						{	switch(fieldType)
							{	case k_Void:
									err = XError(kBAPI_ClassError, Err_JClassError);
									break;
								case k_Boolean:
									(*envP)->SetStaticBooleanField(envP, jClassDescr.j_class, propertyID, value.z);
									break;
								case k_Byte:
									(*envP)->SetStaticByteField(envP, jClassDescr.j_class, propertyID, value.b);
									break;
								case k_Char:
									(*envP)->SetStaticCharField(envP, jClassDescr.j_class, propertyID, value.c);
									break;
								case k_Short:
									(*envP)->SetStaticShortField(envP, jClassDescr.j_class, propertyID, value.s);
									break;
								case k_Int:
									(*envP)->SetStaticIntField(envP, jClassDescr.j_class, propertyID, value.i);
									break;
								case k_Long:
									(*envP)->SetStaticLongField(envP, jClassDescr.j_class, propertyID, value.j);
									break;
								case k_Float:
									(*envP)->SetStaticFloatField(envP, jClassDescr.j_class, propertyID, value.f);
									break;
								case k_Double:
									(*envP)->SetStaticDoubleField(envP, jClassDescr.j_class, propertyID, value.d);
									break;
								case k_Object:
									(*envP)->SetStaticObjectField(envP, jClassDescr.j_class, propertyID, value.l);
									break;
							}
						}
						else
							err = XError(kBAPI_Error, Err_NoSuchProperty);
					}				
					if NOT(err)
					{	if ((*envP)->ExceptionOccurred(envP))
							err = _CheckException(runRecP, pbPtr, &err);
					}
				}
			}
		}
		if ((*envP)->ExceptionOccurred(envP))
			err = _CheckException(runRecP, pbPtr, &err);
	}

return err;
}

//===========================================================================================
/*static XErr	JClass_Modify(Biferno_ParamBlockPtr pbPtr)
{
#if __MWERKS__
	#pragma unused(pbPtr)
XErr	err = noErr;

	err = XError(kBAPI_Error, Err_IllegalOperation);
		
return err;
}*/

//===========================================================================================
static XErr	JClass_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
PrimitiveRec			*typeCast = &pbPtr->param.primitiveRec;
//TypeCastParam		*param_s = &typeCast->param1, *param_d = &typeCast->param2;
ObjRef				*objRefP;
XErr				err = noErr;
long				maxStorage;//, size, len1, len2;
Primitive_String	*textP;
JNIEnv 				*envP;
JClassDescr			jClassDescr;
jmethodID			methodID;
jobject				jStringName;
Ptr					stringP;
long				aCStrLen, tLen, strLen;
BlockRef			bl_ref = 0;
CStr255				aCStr;
PrimitiveUnion		*param_d;
JClassRunRecord 	*runRecP;

	if NOT(err = _GetRunRecord(pbPtr->api_data, pbPtr->plugin_run_dataP, &runRecP, pbPtr))
	{	envP = runRecP->envP;
		objRefP = &typeCast->objRef;
		tLen = sizeof(JClassDescr);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, objRefP, (Ptr)&jClassDescr, &tLen, 0, nil))
		{	if (jClassDescr.j_object)
			{	if (jClassDescr.j_object == NULL_JAVA_OBJECT_POINTER)
				{	CEquStr(aCStr, "null [");
					CAddStr(aCStr, jClassDescr.class_name);
					CAddStr(aCStr, "]");
					strLen = CLen(aCStr);
					if (bl_ref = NewBlock(strLen + 1, &err, &stringP))
						CopyBlock(stringP, aCStr, strLen);
				}
				else
				{	if (methodID = (*envP)->GetMethodID(envP, jClassDescr.j_class, "toString", "()Ljava/lang/String;"))
					{	if (jStringName = (*envP)->CallObjectMethod(envP, jClassDescr.j_object, methodID))
						{	if NOT(err = jstring2CStringExt(envP, jStringName, &bl_ref, &strLen, pbPtr->error))
							{	CEquStr(aCStr, " [");
								CAddStr(aCStr, jClassDescr.class_name);
								CAddStr(aCStr, "]");
								aCStrLen = CLen(aCStr);
								if NOT(err = SetBlockSize(bl_ref, strLen + aCStrLen))
								{	stringP = GetPtr(bl_ref);
									CopyBlock(stringP + strLen, aCStr, aCStrLen);
									strLen += aCStrLen;
								}
							}
						}
						else
							err = _JError(runRecP, pbPtr);
					}
					else
						err = _JError(runRecP, pbPtr);
				}
			}
			else
			{	CEquStr(aCStr, "[");
				CAddStr(aCStr, jClassDescr.class_name);
				CAddStr(aCStr, "]");
				stringP = aCStr;
				strLen = CLen(aCStr);
			}
			if NOT(err)
			{	param_d = &typeCast->result;
				if (typeCast->resultWanted == kCString)
				{	textP = &param_d->text;
					maxStorage = textP->stringMaxStorage;
					if (textP->stringP)
					{	if (maxStorage >= (strLen + 1))
						{	CopyBlock(textP->stringP, stringP, strLen);
							textP->stringLen = strLen;
						}
						else
						{	CopyBlock(textP->stringP, stringP, maxStorage - 1);
							textP->stringP[maxStorage - 1] = 0;
							textP->stringLen = strLen;
							err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
						}
					}
					else
						textP->stringLen = strLen;
				}
				else
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
			}
			if (bl_ref)
				DisposeBlock(&bl_ref);
		}
		if ((*envP)->ExceptionOccurred(envP))
			err = _CheckException(runRecP, pbPtr, &err);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "jclass");
			gsApiVersion = pbPtr->param.registerRec.api_version;
			jClassID = (short)pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.fixedSize = true;
			pbPtr->param.registerRec.dynamic = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void jclass(string className ...)");
			pbPtr->param.registerRec.nextBAPI_Dispatch = (long)byte_Biferno_Dispatch;
			//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			break;
		case kInit:
			err = JClass_Init(pbPtr);
			break;
		case kShutDown:
			//BufferFree(gStdErrBuffer);
			break;
		case kRun:
			err = _CreateRunRecord(pbPtr->api_data, pbPtr->plugin_run_dataP, pbPtr);
			break;
		case kExit:
			if (pbPtr->plugin_run_dataP)
				_DeleteRunRecord(pbPtr->api_data, pbPtr->plugin_run_dataP);
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = JClass_Constructor(pbPtr, message);
			break;
		case kDestructor:
			err = JClass_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = JClass_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = JClass_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = JClass_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = JClass_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = JClass_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
return err;
}
#if __MWERKS__
#pragma export off
#endif
