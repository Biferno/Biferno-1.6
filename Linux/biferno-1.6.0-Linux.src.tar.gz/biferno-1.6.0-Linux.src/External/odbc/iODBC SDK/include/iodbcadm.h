/*
 *  iodbcadm.h
 *
 *  $Id: iodbcadm.h,v 1.1 2004-05-20 12:17:53 valfer Exp $
 *
 *  The iODBC driver manager.
 *  
 *  Copyright (C) 1999 by OpenLink Software <iodbc@openlinksw.com>
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library; if not, write to the Free
 *  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifdef __APPLE__
#  include <iODBCinst/odbcinst.h>
#else
#  include <odbcinst.h>
#endif

#ifndef	_IODBCADM_H
#define	_IODBCADM_H

#define USER_DSN	0
#define SYSTEM_DSN	1
#define FILE_DSN	2

SQLRETURN SQL_API _iodbcdm_drvconn_dialbox (HWND hwnd, LPSTR szInOutConnStr,
    DWORD cbInOutConnStr, int FAR * sqlStat, SQLUSMALLINT fDriverCompletion,
    UWORD * config);
SQLRETURN SQL_API _iodbcdm_fdrvconn_dialbox (HWND hwnd,
    LPSTR szCurrentDirectory, LPSTR szInOutConnStr, DWORD cbInOutConnStr,
    int FAR * sqlStat);
SQLRETURN SQL_API _iodbcdm_drvchoose_dialbox (HWND hwnd, LPSTR szInOutDrvStr,
    DWORD cbInOutDrvStr, int FAR * sqlStat);
SQLRETURN SQL_API _iodbcdm_trschoose_dialbox (HWND hwnd, LPSTR szInOutDrvStr,
    DWORD cbInOutDrvStr, int FAR * sqlStat);

void SQL_API _iodbcdm_errorbox (HWND hwnd, LPCSTR szDSN, LPCSTR szText);
void SQL_API _iodbcdm_nativeerrorbox (HWND hwnd, HENV henv, HDBC hdbc,
    HSTMT hstmt);
void SQL_API _iodbcdm_messagebox (HWND hwnd, LPCSTR szDSN, LPCSTR szText);
BOOL SQL_API _iodbcdm_confirmbox (HWND hwnd, LPCSTR szDSN, LPCSTR szText);

SQLRETURN SQL_API _iodbcdm_admin_dialbox (HWND hwnd);

typedef SQLRETURN SQL_API (*pDrvConnFunc) (HWND hwnd, LPSTR szInOutConnStr,
    DWORD cbInOutConnStr, int FAR * sqlStat, SQLUSMALLINT fDriverCompletion);

#endif
