/*
 *  isqltypes.h
 *
 *  $Id: isqltypes.h,v 1.1 2004-05-20 12:17:56 valfer Exp $
 *
 *  iODBC typedefs
 *
 *  The iODBC driver manager.
 *  
 *  Copyright (C) 1995 by Ke Jin <kejin@empress.com> 
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library; if not, write to the Free
 *  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* 
 *  This file is deprecated in favor of sqltypes.h and will be removed 
 *  sometime in the future. Please recode your applications to use 
 *  the standard names sql.h, sqlext.h and sqltypes.h.
 */
#ifdef __APPLE__
#  include <iODBC/sqltypes.h>
#else
#  include <sqltypes.h>
#endif
