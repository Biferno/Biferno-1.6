#!/bin/sh
#
# get a 4-bytes version number from a C header file and print its bytes separated by ":"
# The first parameter is the header file, the second is the constant name
# Example:
# If the definition is in file foo.h and looks like
# #define CUR_BIFERNO_VERSION                             (unsigned long)0x00010014
# call this script as <script_name> foo.h CUR_BIFERNO_VERSION


sed -n "s/.*#define.*$2.*0x\(..\)\(..\)\(..\)\(..\).*/\1:\2:\3:\4/p" $1
