/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XUtilsUnix.c,v 1.8 2005-11-07 15:56:46 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#ifndef __MACOSX__
	#include <malloc.h>
#endif

extern CStr255		gSysString;

#ifdef __UNIX_XLIB__
//===========================================================================================
static void	__Tokenize(char *executablePath, char *commandLineString, long strLen, Ptr *argv)
{
char	*strP;
int		k = 0;

	argv[k++] = executablePath;
	strP = commandLineString;
	SkipSpaceAndTab(&strP, &strLen);
	if (strLen)
	{	argv[k++] = strP;
		do
		{	if (SkipSpaceAndTab(&strP, &strLen))
			{	*(strP-1) = 0;
				if (*strP)
					argv[k++] = strP;
			}
		} while (*strP++);
	}
	argv[k] = nil;
	
	/*printf("Params: %d\n", k);
	for (i = 0; i < k; i++)
	{	printf(argv[i]);
		printf("\n");
	}*/
	
}

//===========================================================================================
XErr	XLaunchProcess(char *executablePath, char *commandLineString, Boolean waitEnd, unsigned long timeout_ms)
{
XErr			err = noErr;
pid_t			pid;
unsigned long	start_ms, now_ms;
int				result = 0;
char			*argvPtr;
long			commLen;
CStr255			commandStr;

	errno = noErr;
	if ((pid = fork()) < 0)
		err = errno;
	else if (pid == 0)		// child
	{	commLen = CLen(commandLineString);
		if (argvPtr = (Ptr)malloc(commLen * sizeof(char*)))
		{	
		long		zapped, exeLen;
		BlockRef	block = nil;
		Ptr			textP;
		int			res;

			exeLen = CLen(executablePath);
			if (zapped = ZapText((Byte*)executablePath, exeLen))
				exeLen -= zapped;
			executablePath[exeLen] = 0;
			if (commLen < 255)
				textP = commandStr;
			else
				block = NewBlockLocked(commLen + 1, &err, &textP);
			CEquStr(textP, commandLineString);
			__Tokenize(executablePath, textP, commLen, (Ptr*)argvPtr);
			errno = noErr;
			res = execvp(executablePath, (Ptr*)argvPtr);
			if (res == -1)
				err = errno;
			//printf("execvp: '%s' %d %d (%s)\n", executablePath, res, err, strerror(err));
			free(argvPtr);
			if (block)
				DisposeBlock(&block);
		}
		exit(127);
	}
	// parent
	if (waitEnd)
	{	
	unsigned long	t;
	
		XGetMilliseconds(&start_ms);
		now_ms = start_ms;
		while NOT(err)
		{	XGetMilliseconds(&t);
			if ((t - now_ms) > 100)	// not more than every 0.1 secs
			{	errno = noErr;
				result = waitpid(pid, nil, WNOHANG);
				if (result)
				{	if (result < 0)
						err = errno;
					break;
				}
				else
				{	if ((t - start_ms) > timeout_ms)
						err = XError(kXLibError, ErrXThreads_Timeout);
					else
						now_ms = t;
				}
			}
		}
	}
		
return err;
}

/*
//===========================================================================================
XErr	XLaunchProcess(char *executablePath, char *commandLineString, Boolean waitEnd, long timeout_ms)
{
#pragma unused(executablePath, waitEnd, timeout_ms)
XErr		err = noErr;
CStr255		resultStr, commandStr;
int			totLen, exeLen, commLen;
char		*textP;
BlockRef	block = 0;

	exeLen = CLen(executablePath);
	commLen = CLen(commandLineString);
	totLen = exeLen + commLen;
	if (totLen < 255)
		textP = commandStr;
	else
		block = NewBlockLocked(totLen + 1, &err, &textP);
	CEquStr(textP, executablePath);
	CAddStr(textP, commandLineString);
	Command(textP, resultStr);
	if (block)
		DisposeBlock(&block);
		
return err;
}*/
#endif

//===========================================================================================
/*static char	*my_strerror(int errNum)
{
	#ifdef __MACOSX__
		return strerror(errNum);
	#else
		return strerror();
	#endif
}*/

#ifdef __UNIX_XLIB__
//===========================================================================================
void	XGetSysInfo(char *sysStr)
{

	CEquStr(sysStr, gSysString);
/*FILE	*p;
size_t	size;
int		res;

	*sysStr = 0;
	XThreadsEnterCriticalSection();
	if (p = popen("uname -a", "r"))
	{	size = fread(sysStr, 1, 250, p);
		if (size >= 0)
			sysStr[size-1] = 0;	// per il \n finale
		else
			sprintf(sysStr, "Error on fread(): %d (%s)", ferror(p), my_strerror(ferror(p)));
		if (res = pclose(p))
			sprintf(sysStr, "Error on pclose(): %s", my_strerror(ferror(p)));
	}
	else
		sprintf(sysStr, "Error on popen()");
	XThreadsLeaveCriticalSection();
*/
}

#if __MWERKS__
#pragma mark-
#endif

//#define	READ_STEP	1024
//===========================================================================================
// note that must be: args[totArgs] = nil;
/*static XErr	_read_from_file(FILE *f, BlockRef *resBlockP, long *resLenP)
{
XErr		err = noErr;
int			offset = 0;
Ptr			textP;
BlockRef	resBlock;
char		*strP;

	if (resBlock = NewBlock(READ_STEP, &err, &textP))
	{	while (strP = fgets(textP + offset, READ_STEP, f))
		{	offset += CLen(strP);
			if (err = SetBlockSize(resBlock, offset + READ_STEP))
				break;
			else
				textP = GetPtr(resBlock);
		}
		if NOT(err)
		{	if NOT(err = SetBlockSize(resBlock, offset + 1))
			{	textP = GetPtr(resBlock);
				textP[offset] = 0;
				*resBlockP = resBlock;
				*resLenP = offset;
			}
		}
		if (err)
			DisposeBlock(&resBlock);
	}
		
return err;
}*/

//===========================================================================================
/*XErr	RedirOutput(XErr (*_Func)(long userData), long userData, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP)
{
XErr		err = noErr;
int			fdErr[2]={-1, -1}, fdOut[2]={-1, -1};
int			fdSaveErr = -1, fdSaveOut = -1, fileFlags;
FILE		*streamOut0 = nil, *streamErr0 = nil;

	XThreadsEnterCriticalSection();
	errno = noErr;
	if (stdOutP)
	{	if ((fdSaveOut = dup(STDOUT_FILENO)) < 0)
			err = errno;
		else if (pipe(fdOut) < 0)
			err = errno;
		else if (dup2(fdOut[1], STDOUT_FILENO) < 0)
			err = errno;
	}
	if (err)
		goto out;
	if (stdErrP)
	{	errno = noErr;
		if ((fdSaveErr = dup(STDERR_FILENO)) < 0)
			err = errno;
		else if (pipe(fdErr) < 0)
			err = errno;
		else if (dup2(fdErr[1], STDERR_FILENO) < 0)
			err = errno;
	}
	if (err)
		goto out;
	if NOT(err = _Func(userData))
	{	errno = noErr;
		if (stdOutP)
		{	fileFlags = fcntl(fdOut[0], F_GETFL);
			if (fcntl(fdOut[0], F_SETFL, fileFlags | O_NONBLOCK) < 0)
				err = errno;
			else
			{	if (streamOut0 = fdopen(fdOut[0], "r"))
					err = _read_from_file(streamOut0, stdOutP, stdOutLenP);
				else
					err = errno;
			}
		}
		if (err)
			goto out;
		if (stdErrP)
		{	fileFlags = fcntl(fdErr[0], F_GETFL);
			if (fcntl(fdErr[0], F_SETFL, fileFlags | O_NONBLOCK) < 0)
				err = errno;
			else
			{	if (streamErr0 = fdopen(fdErr[0], "r"))
					err = _read_from_file(streamErr0, stdErrP, stdErrLenP);
				else
					err = errno;
			}
		}
	}

out:
// std out
if (streamOut0)
	fclose(streamOut0);
else if (fdOut[0] >= 0)
	close(fdOut[0]);
if (fdOut[1] >= 0)
	close(fdOut[1]);
if (fdSaveOut >= 0)
{	dup2(fdSaveOut, STDOUT_FILENO);		// re-connect
	close(fdSaveOut);
}
// std err
if (streamErr0)
	fclose(streamErr0);
else if (fdErr[0] >= 0)
	close(fdErr[0]);
if (fdErr[1] >= 0)
	close(fdErr[1]);
if (fdSaveErr >= 0)
{	dup2(fdSaveErr, STDERR_FILENO);		// re-connect
	close(fdSaveErr);
}
XThreadsLeaveCriticalSection();
return err;
}*/
#endif
