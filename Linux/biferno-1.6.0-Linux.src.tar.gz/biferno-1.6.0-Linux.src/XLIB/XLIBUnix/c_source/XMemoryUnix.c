/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XMemoryUnix.c,v 1.4 2005-11-07 15:37:38 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XMemoryPrivate.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

//extern CStr255				globalErrStr;

//===========================================================================================
static long	_NewHeapBlockP_low(long size, Boolean cleared, XErr *errPtr)
{
Ptr		thePtr = 0L;
XErr	err = noErr;

	if NOT(size)
	{	*errPtr = XError(kXLibError, ErrXMemory_NullSize);
		return nil;
	}
	
	#ifdef MEM_DEBUG
		size += 16;		// space for page guardians
	#endif

	errno = 0;
	if (cleared)
		thePtr = calloc(size, 1);
	else
		thePtr = malloc(size);
	if NOT(thePtr)
	{	err = XGetError();
		if (errPtr)
			*errPtr = err;
	}

	#ifdef MEM_DEBUG
		if (thePtr && NOT(err))
		{	long action;
			
			if (cleared)
				action = CLEAR;
			else
				action = FILL;
			_WritePageGuardians(thePtr, size, action);
			//OneMorePtr();
			return (long)thePtr;
		}
		else
			return nil;
	#else
		return (long)thePtr;	
	#endif
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
long	NewBlock_low(long size, XErr *errPtr)
{
	return _NewHeapBlockP_low(size, false, errPtr);
}

//===========================================================================================
long 	NewBlockClear_low(long size, XErr *errPtr)
{
	return _NewHeapBlockP_low(size, true, errPtr);
}

//===========================================================================================
long	NewPtrBlock_low(long size, XErr *errPtr)
{
	return _NewHeapBlockP_low(size, false, errPtr);
}

//===========================================================================================
XErr	DisposeBlock_low(long *addressP, unsigned long size)
{
#if !MEM_DEBUG && __C_HAS_PRAGMA_UNUSED__
	#pragma unused(size)
#endif
XErr			err = noErr;
Ptr				p;

	if (addressP && *addressP)
	{
	#ifdef MEM_DEBUG
		unsigned long	i;
		long			*longP;
		
		p = (Ptr)*addressP;
		i = size + 16;
		if (i > 0)
		{	_CheckPageGuardians(p, i, "DisposeBlock");
			i = i / sizeof(long);
			longP = (long*)p;
			do	{
				*longP++ = 0xDEADBEEF;
				} while (--i);
		}
		else if (i <= 0)
			CDebugStr("XMemoryUnix.c (DisposeBlock): Size negative");
	#else
		p = (Ptr)*addressP;
	#endif
		errno = 0;
		free(p);
		err = XGetError();
		//if NOT(err)
		//	OneLessPtr();
		*addressP = nil;
	}
	else
	{	err = XError(kXLibError, ErrXMemory_BadRef);
		//CEquStr(globalErrStr, "in DisposeBlock");
	}

return err;
}

//===========================================================================================
Ptr	GetPtr_low(long address)
{
	
	if (address)
	{
		#ifdef MEM_DEBUG
			return (Ptr)(address + 8);
		#else
			return (Ptr)address;
		#endif
	}

return nil;
}

//===========================================================================================
/*unsigned long	GetBlockSize_low(BlockRef blockRef, XErr *errP)
{
unsigned long	size;
XErr			err = noErr;
UnixBlockRef	*uniRefP;

	if (blockRef)
	{	uniRefP = (UnixBlockRef*)&blockRef;
		
		#ifdef MEM_DEBUG
			size = uniRefP->size + 16;
			if NOT(err)
				_CheckPageGuardians(uniRefP->p, size, "GetBlockSize");
		#endif
		size = uniRefP->size;
	}
	else
	{	*errP = ErrXMemory_BadRef;
		CEquStr(globalErrStr, "in GetBlockSize");
	}
	
return size;
}*/

//===========================================================================================
XErr SetBlockSize_low(long *addressP, unsigned long oldSize, unsigned long newSize)
{
#if !MEM_DEBUG && __C_HAS_PRAGMA_UNUSED__
	#pragma unused(oldSize, newSize)
#endif
XErr			err = noErr;
Ptr				p;
	
	if NOT(newSize)
		return XError(kXLibError, ErrXMemory_NullSize);

	if (addressP && *addressP)
	{	p = (Ptr)*addressP;
		#ifdef MEM_DEBUG		
			oldSize += 16;
			_CheckPageGuardians(p, oldSize, "SetBlockSize");
			newSize += 16;
		#endif
		errno = 0;
		if NOT(p = realloc(p, newSize))
			err = XGetError();
		else
			*addressP = (long)p;
		#ifdef MEM_DEBUG
			if NOT(err)
				_WritePageGuardians(p, newSize, NOACTION);
		#endif
	}
	else
	{	err = XError(kXLibError, ErrXMemory_BadRef);
		//CEquStr(globalErrStr, "in SetBlockSize");
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
void	CopyBlock(void *dest, void *source, long len)
{
	System_EnterCS();
	memmove(dest, source, len);
	System_LeaveCS();
}
