/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XSocketsUnix.c,v 1.15 2008-09-08 11:58:12 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

#ifdef __XLIB_WITH_HELPERS__

#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <errno.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/socketvar.h>
#include <sys/file.h>
#include <sys/un.h>
#include <pthread.h>
#include <fcntl.h>
#ifndef __MACOSX__
	#include <malloc.h>
	#include <arpa/inet.h>
#endif

#ifdef __MACOSX__
	#ifndef GREATER_EQU_PANTHER					// before panther (10.3)
		typedef unsigned int	socklen_t;		// versions before 10.3 (Panther) didn't define this
	#endif
#endif

#if CAN_USE_POSIX_THREADS && PER_THREAD_ACCEPT
	#include <pthread.h>
	
	static pthread_mutex_t		gsSocketAcceptMutex = PTHREAD_MUTEX_INITIALIZER;
#endif

//#define	PACK_SIZE	(1024L * 4L * sizeof(char))

typedef struct {
				long						userData;
				long						socket;
				ProcessClientRequest_Func	func;
				} SocketParamData, *SocketParamDataP;

static	long		gNConnection = 0;
static	Boolean		gPrefixed, gsStopServer = false;
static	int			gServerSocket = 0;
static	long		gsServerPort;
static	CStr255		gsUnixfile;

#ifndef MAXPACKET							// make sure a maximum packet size is declared by BIND
	#define MAXPACKET 		8192				// BIND maximum packet size
#endif

#define MAXMXHOSTS		32					// max number of MX records returned
#define MXBUFFERSIZE 	(128 * MAXMXHOSTS)

#ifndef HFIXEDSZ							// make sure header size is declared
	#define HFIXEDSZ 		12
#endif

#define MX_NOBUFFERMEM		-1
#define MX_NODATA			-2
#define MX_UNKNOWNERROR		-3
#define MX_TEMPFAIL			-4
#define MX_QUERROR			-5
#define	MX_HOSTNOTFOUND		-6

// define custom data types
typedef union
{
	HEADER	hdr;				// define a header structure
	u_char	qbuf[MAXPACKET];	// define a query buffer
} mxquery;

#define	kYieldTimeout		(unsigned long)(1000L * 30L)	// milliseconds (= 30 secs)

static	XServerOnceHook		gsOnceHook = nil;
static	long				gsOnceHookUData = 0;
static	Boolean				gsExecuteHook = false;

extern	Boolean				gExitForced;
//===========================================================================================
/*static	XErr	_mygethostbyname(char *name, struct hostent *shost)
{
struct hostent 	*shostGlobalP;
XErr			err = noErr;

	XThreadsEnterCriticalSection();
	h_errno = 0;
	if ((shostGlobalP = gethostbyname(name)) == NULL)
	{	switch(h_errno)
		{	case HOST_NOT_FOUND:
			case TRY_AGAIN:
			case NO_RECOVERY:
			case NO_DATA:
			default:
				err = ENOENT;
				break;
		}
	}
	else
		*shost = *shostGlobalP;
	XThreadsLeaveCriticalSection();

return err;
}
*/
//===========================================================================================
static int _ZeroMemory( void *ptr, int size)
{
	// zeroes out a memory buffer
	if (memset( ptr, 0, size) < 0)
		return -1;
	else
		return 1;
}

//===========================================================================================
static int _MxRecordsLoop( char *dname, char **mxhosts, u_short *mxprefs, char *mxbuf)
{
// a function that queries a DNS server for MX records for the specified host
// host - string containing host name
// mxhosts - a pointer to an array of pointers each pointing to an MX record (in the same buffer, for efficiency)
// mxprefs - a pointer to an array of unsigned shorts that specify the preferances of each MX host
// mxbuf - a pointer to an allocated buffer that will contain all the host names (each name's pointer is in the mxhosts array)

u_char			*end, *puChar;						// pointers to end of message, generic u_char pointer.
int				i, j, n, nmx;
char			*pByte;								// generic char pointer
HEADER			*hp;								// points to a header struct
mxquery			answer;								// declare an mxquey buffer
int				answers, questions, buflen;
u_short			pref, type, *pPrefs;
XSafeHostent	h;									// for the A record, if needed

	// check pointers
	if (mxprefs == NULL)
		return(MX_NOBUFFERMEM);
	if (mxhosts == NULL)
		return(MX_NOBUFFERMEM);
	if (mxbuf == NULL)
		return(MX_NOBUFFERMEM);

	// make query
	errno=0;
	do {
		n = res_query( dname, C_IN, T_MX, (u_char *) &answer, sizeof( answer));
		} while ((n < 0) && (h_errno == TRY_AGAIN));
	if (n < 0)
	{
		// handle error conditions
		switch(h_errno)
		{
			case HOST_NOT_FOUND:
				// couldn't find domain
				return(MX_HOSTNOTFOUND);
				break;
			case NO_DATA:
			case NO_RECOVERY:
				// no MX RRs, try the A record..
				if NOT(GetHostByNameSafe(dname, &h))
				{	// returned a resolved result, store
					if (h.h_name != NULL)
					{	if ( strlen( h.h_name) != 0)
							snprintf( mxbuf, MXBUFFERSIZE-1, h.h_name);
					}
					else
						snprintf( mxbuf, MXBUFFERSIZE-1, dname);
					// set the arrays
					nmx=0;
					mxprefs[nmx]=0;
					mxhosts[nmx]=mxbuf;
					nmx++;
					return( nmx);
				}
				return( MX_NODATA);
				break;
			case TRY_AGAIN:
			case -1:
				// couldn't connect or temp failure
				return( MX_TEMPFAIL);
				break;
			default:
				return( MX_UNKNOWNERROR);
				break;
		}
		// who knows what happened
		return( MX_UNKNOWNERROR);
	}
	// make sure we don't exceed buffer length
	if ( n > sizeof( answer))
	n = sizeof( answer);

	// skip the question portion of the DNS packet
	hp = (HEADER *) &answer;
	puChar = (u_char*)&answer + HFIXEDSZ;			// point after the header
	end = (u_char*)&answer + n;						// point right after the entire answer
	pPrefs = mxprefs;								// initialize the pointer to the array of preferences
	
	for(questions = ntohs((u_short)hp->qdcount); questions > 0 ;questions--, puChar += n+QFIXEDSZ)
	{	// loop on question count (taken from header), and skip them one by one
		if ( (n = dn_skipname(puChar, end)) < 0)
		{	// couldn't account for a question portion in the packet.
			return ( MX_QUERROR);
		}
	}
	// initialize and start decompressing the answer
	nmx = 0;
	buflen = MXBUFFERSIZE-1;
	pByte = mxbuf;		// point to start of mx hosts string buffer
	_ZeroMemory( mxbuf, MXBUFFERSIZE);
	_ZeroMemory( mxhosts, MAXMXHOSTS * 4);
	_ZeroMemory( pPrefs, MAXMXHOSTS * sizeof(u_short));
	answers = ntohs((u_short)hp->ancount);		// number of answers

	while( (--answers >= 0) && (puChar < end) && (nmx < MAXMXHOSTS-1) )
	{
		// puChar constantly changes (moves forward in the answer buffer)
		// pByte points to the mx buffer, moves forward after we stored a host name

		// decompress the domain's default host name into the buffer so we can skip it and check if it's an����� 
		// MXhost
		if ( (n = dn_expand( (u_char *) &answer, end, puChar, (char *)pByte, buflen)) < 0)
			break;	// error in answer

		puChar += n;							// skip the name, go to its attributes
		GETSHORT( type, puChar);				// get the type and move forward
		puChar += INT16SZ + INT32SZ;			// skip the class and TTL portion of the answer RR
		GETSHORT( n, puChar);					// get the resource size and move on
		if ( type != T_MX)
		{										// type of record is somehow NOT an MX record, move on
			puChar += n;
			continue;
		}
		GETSHORT( pref, puChar);				// get the preference of the RR and move on
		if ( (n = dn_expand( (u_char *) &answer, end, puChar, (char *)pByte, buflen)) < 0)	// expand the MXRR
			break;								// error in decompression
		puChar += n;

		// store it's attributes
		pPrefs[nmx] = pref;
		mxhosts[nmx] = pByte;
		nmx++;
		n = strlen( pByte);
		pByte += n+1;							// make sure it's null terminated, notice the buffer was set to 0 initially
		buflen -= n+1;
	}
	// in case the records aren't sorted, bubble sort them
	for( i=0 ; i < nmx ; i++)
		for( j=i+1 ; j < nmx ; j++)
			if ( pPrefs[i] > pPrefs[j])
			{	int temp;
				char *temp2;

				temp = pPrefs[i];
				pPrefs[i] = pPrefs[j];
				pPrefs[j] = temp;
				temp2 = mxhosts[i];
				mxhosts[i] = mxhosts[j];
				mxhosts[j] = temp2;
			}
	// remove duplicates
	for( i=0 ; i < nmx-1 ; i++)
	{	if (strcasecmp( mxhosts[i], mxhosts[i+1]) != 0)
			continue;
		else
		{	// found a duplicate
			for( j=i+1 ; j < nmx ; j++)
			{	mxhosts[j] = mxhosts[j+1];
				pPrefs[j] = pPrefs[j+1];
			}
			nmx--;								// 1 less MX record
		}
	}

// all done, bug out
return nmx;
}

//===========================================================================================
XErr	GetMXRecords(CStr255 domain, MXRecord *mxRecordP, long *mxtot)
{
int		res;	//, mxTot;
XErr	err = noErr;
char	*mxHosts[MAXMXHOSTS];
char	mxbuf[MXBUFFERSIZE];
u_short	mxprefs[MAXMXHOSTS];
int		i;

	res = _MxRecordsLoop(domain, mxHosts, mxprefs, mxbuf);
	if (res > 0)
	{	if (res > *mxtot)
			res = *mxtot;
		for (i = 0; i < res; i++, mxRecordP++)
		{	mxRecordP->preference = mxprefs[i];
			CEquStr(mxRecordP->name, mxHosts[i]);
		}
		*mxtot = res;
	}
	else
	{	*mxtot = 0;
		switch(res)
		{	case MX_NOBUFFERMEM:
				break;
			case MX_NODATA:
				break;
			case MX_UNKNOWNERROR:
				break;
			case MX_TEMPFAIL:
				break;
			case MX_QUERROR:
				break;
			case MX_HOSTNOTFOUND:
				err = ENOENT;
				break;
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
// la prima long � la lunghezza da mandare (la prima long esclusa)
/*static void	_dump(char *p, long len, long id)
{
CStr255		path, tStr;
XFileRef	refNum;
XErr		err = noErr;

	CEquStr(path, "/home/valerio/BifernoHome/MyDump");
	//CAddStr(path, "/MyDump");
	CNumToString(id, tStr);
	CAddStr(path, tStr);
	CAddStr(path, ".txt");
	if (len)
	{	if NOT(err = OpenXFile(path, CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &refNum))
		{	err = WriteXFile(refNum, p, &len);
			CloseXFile(&refNum);
		}
	}
}
*/
//===========================================================================================
/*
static Boolean	_RespondToStop(long c_socket)
{
BlockRef	stopMessage, response;
long		tLen, strLen, stopMessageLen;
Ptr			p;
XErr		err = noErr;
Boolean		result = false;

	if NOT(err = XSocketsReceive(c_socket, &stopMessage, &stopMessageLen, gPrefixed))
	{	if ((stopMessageLen == (tLen = CLen(STOP_STRING))) && NOT(CompareBlock(GetPtr(stopMessage), STOP_STRING, tLen)))
			result = true;
		strLen = CLen(OK_STOP);
		if (response = NewBlock(strLen + 1, &err))
		{	p = GetPtr(response);
			CopyBlock(p, OK_STOP, strLen);
			p[strLen] = 0;
			err = XSocketsSend(c_socket, response, strLen, gPrefixed);
			DisposeBlock(&response);
			result = true;
		}
		DisposeBlock(&stopMessage);
	}
	
return result;
}
*/

//===========================================================================================
static void	sock_ntop(const struct sockaddr *sa, socklen_t salen, char *str)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(salen)
#endif
	*str = 0;
	switch(sa->sa_family)
	{
		case AF_INET:
			{
			#ifndef __MACOSX__
			struct sockaddr_in	*sin = (struct sockaddr_in	*)sa;
				
				// no inet_ntop on MacOSX
					inet_ntop(AF_INET, &sin->sin_addr, str, 255);
			#endif
			}
			break;
	}
}

//===========================================================================================
// la prima long � la lunghezza da mandare (la prima long esclusa)
/*static XErr	_MySend(long socketRef, BlockRef buffToSendBlock, long buffToSendLength, Boolean prefixed)
{
int			c_socket = (int)socketRef;
long		totalSent, bytesSent, bytesToSent, t;
char		*buffToSend;
XErr		err = noErr;

	if (prefixed)
	{	if NOT(err = SetBlockSize(buffToSendBlock, buffToSendLength + sizeof(long)))
		{	buffToSend = GetPtr(buffToSendBlock);
			CopyBlock(buffToSend + sizeof(long), buffToSend, buffToSendLength);
			*(long*)buffToSend = htonl(buffToSendLength);
			buffToSendLength += sizeof(long);
		}
	}
	else
		buffToSend = GetPtr(buffToSendBlock);
	if NOT(err)
	{	totalSent = 0;
		bytesToSent = buffToSendLength;
		do {
			t = bytesToSent;
			System_EnterCS();
			errno = noErr;
			bytesSent = send(c_socket, buffToSend + totalSent, t, 0);
			if (bytesSent < 0)
				err = errno;
			System_LeaveCS();
			if (err)
				break;
			totalSent += bytesSent;
			bytesToSent -= bytesSent;
		} while (totalSent < buffToSendLength);
	}
	
return err;
}

//===========================================================================================
// la prima long � la lunghezza da ricevere (la prima long esclusa)
static XErr	_MyReceive(long socketRef, BlockRef *buffReceivedBlockP, long *buffReceivedLengthP, Boolean prefixed, ReceiveCompleteCallBack _completeFunc, long completeCallBackParam)
{
int				c_socket = (int)socketRef;
long			buffID, maxStorage, bytesRcv, newSize, bytesReceived, bytesToReceive;
char			*pToAdd, *tempBufP;
XErr			err = noErr;
Boolean			first, moved;
char			*pBuf = nil;

	buffID = 0;
	System_EnterCS();
	pBuf = (char*)malloc(PACK_SIZE+1);
	System_LeaveCS();
	if NOT(pBuf)
		return -1;

	if (prefixed)
	{	
	BlockRef	recvBlock;
	Ptr			recvPtr;
	
		if NOT(err = _first_recv(c_socket, pBuf, PACK_SIZE, &bytesToReceive, &bytesReceived, &recvBlock, &recvPtr)
		{	while (NOT(err) && (bytesReceived < bytesToReceive))
			{	errno = noErr;
				bytesRcv = recv(c_socket, recvPtr + bytesReceived, bytesToReceive - bytesReceived, 0);
				if (bytesRcv < 0)
				{	err = errno;
					break;
				}
				else if (bytesRcv == 0)
					break;
				else
					bytesReceived += bytesRcv;	
			}
			if NOT(err)
			{	*(recvPtr + bytesReceived) = 0;
				*buffReceivedBlock = recvBlock;
				*buffReceivedLengthP = bytesReceived;
				UnlockBlock(recvBlock);
			}
			else
				DisposeBlock(&recvBlock);
		}
		
		ex
		first = true;
		maxStorage = PACK_SIZE;
		bytesReceived = 0;
		tempBufP = pBuf;
		while NOT(err)
		{	System_EnterCS();
			errno = noErr;
			bytesRcv = recv(c_socket, tempBufP + bytesReceived, maxStorage, 0);
			if (bytesRcv < 0)
				err = errno;
			System_LeaveCS();
			if (err || (bytesRcv == 0))
				break;
			if (first)
			{	pToAdd = tempBufP + 4;
				bytesRcv -= 4;
				bytesToReceive = ntohl(*(long*)tempBufP);
				first = false;
				if NOT(buffID = BufferCreate(PACK_SIZE, &err))
					break;
			}
			else
				pToAdd = tempBufP + bytesReceived;
			bytesReceived += bytesRcv;		
			if (err = BufferAddBuffer(buffID, pToAdd, bytesRcv))
				break;
			if (bytesReceived >= bytesToReceive)
				break;
			else
			{	maxStorage = bytesToReceive - bytesReceived;
				newSize = maxStorage + bytesReceived;
				if NOT(err = BufferCheck(buffID, newSize, &moved))
				{	
					tempBufP = GetPtr(BufferGetBlockRef(buffID, nil));
				}
			}
		}
		if (first && (err != EWOULDBLOCK))
			err = XError(kXLibError, ErrConnectionBroken);
		if NOT(err)
		{	if NOT(err = BufferAddChar(buffID, 0))
			{	*buffReceivedBlockP = BufferGetBlockRef(buffID, buffReceivedLengthP);
				(*buffReceivedLengthP)--;
				BufferClose(buffID);
			}
		}
	}
	else
	{	long	tot;
	
		if (buffID = BufferCreate(PACK_SIZE, &err))
		{	tot = 0;
			do {	
				errno = noErr;
				System_EnterCS();
				errno = noErr;
				bytesRcv = recv(c_socket, pBuf, PACK_SIZE, 0);
				if (bytesRcv < 0)
					err = errno;
				System_LeaveCS();
				if (err)
					break;
				else if NOT(bytesRcv)
					break;
				else
				{	tot += bytesRcv;
					err = BufferAddBuffer(buffID, pBuf, bytesRcv);
				}
				if (NOT(err) && _completeFunc)
				{	if (_completeFunc(buffID, tot, completeCallBackParam))
						break;
				}
			} while NOT(err);
			if NOT(err)
			{	*buffReceivedBlockP = BufferGetBlockRef(buffID, buffReceivedLengthP);
				BufferClose(buffID);
			}
		}
	}

if (pBuf)
{	System_EnterCS();
	free(pBuf);
	System_LeaveCS();
}
if (err && buffID)	
	BufferFree(buffID);

// Debug
if (err)
{	BlockRef	bl;
	char		aCStr[512];
	CStr15		tStr;
	XErr		err2;
	
	if (bl = NewBlock(255, &err2))
	{	LockBlock(bl);
		CEquStr(aCStr, "HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n_MyReceive err = ");
		CNumToString(err, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, " where");
		CAddStr(aCStr, whereStr);
		CopyBlock(GetPtr(bl), aCStr, CLen(aCStr));
		*buffReceivedBlockP = bl;
		*buffReceivedLengthP = CLen(aCStr);
		err = noErr;
	}
}

// End Debug
return err;
}
*/
#ifdef PER_THREAD_ACCEPT
//===========================================================================================
static void*	_processClientRequest(void* param_dataP)
{
SocketParamDataP	sockParamP = param_dataP;
BlockRef			block;
long				totLen;
XErr				err = noErr;
int					clilen, addrlen, c_socket;
struct sockaddr_in	caddr;
	
#if CAN_USE_POSIX_THREADS
	pthread_detach(pthread_self());
#endif

	addrlen = sizeof(struct sockaddr_in);
	for (;NOT(err);)
	{	clilen = addrlen;
		pthread_mutex_lock(&gsSocketAcceptMutex);
		c_socket = accept(sockParamP->socket, &caddr, &clilen);
		gNConnection++;
		pthread_mutex_unlock(&gsSocketAcceptMutex);
		err = XSocketsReceive(c_socket, &block, &totLen, gPrefixed);
		if NOT(err)
		{	
			/*
			BlockRef	bl;
			long		tLen;
			CStr255		aCStr;
			
			CEquStr(aCStr, "bella giornata");
			tLen = CLen(aCStr);
			if (bl = NewBlock(tLen, &err))
			{	CopyBlock(GetPtr(bl), aCStr, tLen);
				XServerSendToClient(c_socket, bl, tLen);
				DisposeBlock(&bl);
			*/
			sockParamP->func(c_socket, block, totLen, sockParamP->userData);
			DisposeBlock(&block);
			XThreadsEnterCriticalSection();
			shutdown(c_socket, 2);
			close(c_socket);
			gNConnection--;
			XThreadsLeaveCriticalSection();
			//}
		}	
	}
	System_EnterCS();
	free(param_dataP);
	System_LeaveCS();

return (void*)err;
}
#else
//===========================================================================================
static void*	_processClientRequest(void* param_dataP)
{
SocketParamDataP	sockParamP = param_dataP;
BlockRef			block;
long				totLen;
XErr				err = noErr;

#if CAN_USE_POSIX_THREADS
	pthread_detach(pthread_self());
#endif
	if NOT(err = XSocketsReceive(sockParamP->socket, &block, &totLen, gPrefixed, nil, 0))
	{	sockParamP->func(sockParamP->socket, block, totLen, sockParamP->userData);
		DisposeBlock(&block);
		XThreadsEnterCriticalSection();
		shutdown(sockParamP->socket, 2);
		close(sockParamP->socket);
		free(param_dataP);
		gNConnection--;
		XThreadsLeaveCriticalSection();
	}	

return (void*)err;
}
#endif

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
/*
static void	io_handler(int signo)
{
}

#if __MWERKS__
#pragma mark-
#endif
*/

//===========================================================================================
XErr	XStopServer(void)
{
XErr				err = noErr;
/*
unsigned long 		initMilliSecs, millisecs, lastTicks = 0;
BlockRef			block, response;
Ptr					p;
int					strLen;
long				responseLen;
CStr255				errString, serverAddr;
*/
	gsStopServer = true;
	// raise(SIGINT);
	
	/*
	raise(SIGALRM/SIGINT);
	
	XGetMilliseconds(&initMilliSecs);
	while NOT(err)
	{	XGetMilliseconds(&millisecs);
		if ((millisecs - initMilliSecs) > (2 * 1000))
			break;
	}
	if NOT(gsServerStopped)
	{	if (gsServerPort)
		{	errno = 0;
			if (gethostname(serverAddr, 255) < 0)
				err = errno;
		}
		else
			*serverAddr = 0;
		if NOT(err)
		{	gsStopServer = true;
			strLen = CLen(STOP_STRING);
			if (block = NewBlock(strLen + 1, &err))
			{	p = GetPtr(block);
				CopyBlock(p, STOP_STRING, strLen);
				p[strLen] = 0;
				if NOT(err = XClientCall(serverAddr, gsServerPort, block, strLen, &response, &responseLen, true, gsUnixfile, errString))
					DisposeBlock(&response);
				DisposeBlock(&block);
			}
		}
	}
	*/

return err;
}

//===========================================================================================
/*
XErr	xXStopServer(void)
{
XErr				err = noErr;
BlockRef	block, response;
Ptr			p;
int			strLen;
long		responseLen;
CStr255		errString, serverAddr;

	exit(0);	// boh!
	
	if (gsServerPort)
	{	errno = 0;
		if (gethostname(serverAddr, 255) < 0)
			err = errno;
	}
	else
		*serverAddr = 0;
	if NOT(err)
	{	gsStopServer = true;
		strLen = CLen(STOP_STRING);
		if (block = NewBlock(strLen + 1, &err))
		{	p = GetPtr(block);
			CopyBlock(p, STOP_STRING, strLen);
			p[strLen] = 0;
			if NOT(err = XClientCall(serverAddr, gsServerPort, block, strLen, &response, &responseLen, true, gsUnixfile, errString))
				DisposeBlock(&response);
			DisposeBlock(&block);
		}
	}
	

return err;
}*/

//===========================================================================================
static void	catch_pipe_signal(int signo)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(signo)
#endif
}


//===========================================================================================
XErr	XServerSetOnceHook(XServerOnceHook hook, long uData)
{
	XThreadsEnterCriticalSection();		
	if NOT(gsExecuteHook)
	{	gsOnceHook = hook;
		gsOnceHookUData = uData;
		gsExecuteHook = true;
	}
	XThreadsLeaveCriticalSection();
	
return noErr;
}

//===========================================================================================
// Client request must 0 terminated
// server_port == 0 => Unix Protocol (only local)
XErr	XServerLoop(long server_port, long listen_queue, ProcessClientRequest_Func proc_func, long userData, Boolean prefixed, Boolean onlyLocal, char *unixfile, char *errString)
{
XErr				err = noErr;
int					s_socket = -1;
int					opt = 1;
unsigned long		threadID;
unsigned long		lastTicks = 0, initMilliSecs, millisecs;
SocketParamDataP	sockParamP;
CStr255				localAddr, remoteAddr;
#ifdef	XLIB_NON_BLOCKING
	int				fileFlags;
#endif
Boolean				ok = false;
struct sigaction	sa_old;
struct sigaction	sa_new;

 	sa_new.sa_handler = catch_pipe_signal;
	sigfillset(&sa_new.sa_mask);
	sa_new.sa_flags = 0;
	sigaction(SIGPIPE, &sa_new, &sa_old);	

	if (errString)
		*errString = 0;

	//_SetIntSignal();
	
	// first, we get a socket to play with
	errno = 0;
	if (server_port)
		s_socket = socket(PF_INET, SOCK_STREAM, 0);
	else
		s_socket = socket(AF_LOCAL, SOCK_STREAM, 0);
	if (s_socket < 0)
		return errno;

	gServerSocket = s_socket;
	gPrefixed = prefixed;
	gsServerPort = server_port;
	if (unixfile)
		CEquStr(gsUnixfile, unixfile);

#ifdef	XLIB_NON_BLOCKING
	errno = 0;
	if (fileFlags = fcntl(s_socket, F_GETFL) == -1)
		return errno;
	errno = 0;
	if (fcntl(s_socket, F_SETFL, fileFlags | O_NONBLOCK) == -1)
		return errno;
#endif

	// asyncronous
	/*
	signal(SIGIO, io_handler);
	errno = 0;
	if (fcntl(s_socket, F_SETOWN, getpid()) < 0)
		return errno;
	errno = 0;
	if (fileFlags = fcntl(s_socket, F_GETFL) == -1)
		return errno;
	errno = 0;
	if (fcntl(s_socket, F_SETFL, fileFlags | FNDELAY | FASYNC) == -1)
		return errno;
	*/

	// now we set the members of the sockaddr_in struct
	if (server_port)
	{
	struct sockaddr_in	saddr;
	
		saddr.sin_family = AF_INET;
		saddr.sin_addr.s_addr = INADDR_ANY;
		saddr.sin_port = htons(server_port);
		// we need to set some socket options too
		errno = 0;
		if ((setsockopt(s_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int))) < 0)
			return errno;
		// now we bind to the address and port from above */
		errno = 0;
		if ((bind(s_socket, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in))) < 0)
			return errno;
	}
	else
	{
	struct sockaddr_un	un_saddr;
	
		unlink(unixfile);
		bzero(&un_saddr, sizeof(un_saddr));
		un_saddr.sun_family = AF_LOCAL;
		strcpy(un_saddr.sun_path, unixfile);
		errno = 0;
		if ((bind(s_socket, (struct sockaddr*)&un_saddr, sizeof(un_saddr))) < 0)
			return errno;
		errno = 0;
		if (chmod(unixfile, S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IWGRP|S_IXGRP|S_IROTH|S_IWOTH|S_IXOTH) == -1)
		{	if (errString)
				CEquStr(errString, "chmod on Unix AF_LOCAL file failed");
			err = errno;
		}
	}
	
	// we are the server so we must listen on this socket
	errno = 0;
	if ((listen(s_socket, listen_queue)) < 0)
		return errno;

#ifdef	PER_THREAD_ACCEPT
	for (i = 0; i < listen_queue; i++)
	{	if (sockParamP = (SocketParamDataP)malloc(sizeof(SocketParamData)))
		{	sockParamP->userData = userData;
			sockParamP->socket = (long)s_socket;
			sockParamP->func = proc_func;
			err = XNewThread(&threadID, 0L, _processClientRequest, 1024L * 256L, (void*)sockParamP);
		}
	}	
	if NOT(err)
	{	for (;;)
			pause();
	}
#else
{	
	if (server_port)
	{
		struct sockaddr_in	caddr;
		int					c_socket;
		int					addrlen;

		addrlen = sizeof(struct sockaddr_in);
		// we want buffer space
		for(;NOT(err);)
		{	// accept returns a "copy" of the socket to work with
			c_socket = accept(s_socket, (struct sockaddr *)&caddr, (socklen_t *)&addrlen);
			if (gsStopServer)
				break;			
		#ifdef	XLIB_NON_BLOCKING
			if (c_socket < 0)
			{	if (errno == EWOULDBLOCK)
					continue;
				else
					err = errno;
			}
		#endif
			if (server_port)
			{	if NOT(err = XLocalAddress(c_socket, localAddr))
				{	if NOT(err = XRemoteAddress(c_socket, remoteAddr))
					{	if (onlyLocal && CCompareStrings_cs(remoteAddr, localAddr))
						{	errno = noErr;
							if (send(c_socket, "Forbidden", 9, 0) < 0)
								err = errno;
							ok = false;
						}
					}
				}
			}
			else
				ok = true;
			if (NOT(err) && ok)
			{	if (sockParamP = (SocketParamDataP)malloc(sizeof(SocketParamData)))
				{	sockParamP->userData = userData;
					sockParamP->socket = (long)c_socket;
					sockParamP->func = proc_func;
					gNConnection++;
					// monothread: _processClientRequest((void*)sockParamP);
					err = XNewThread(&threadID, nil, _processClientRequest, 1024L * 64L, (void*)sockParamP);
				}
				else
					err = -1;
			}
			if (err)
				proc_func((long)c_socket, 0, err, userData);
		}
	}
	else
	{
		struct sockaddr_un	caddr;
		int					c_socket;
		int					addrlen;
		//BlockRef			stopMessage;
		//long				stopMessageLen;
		
		for(;NOT(err);)
		{	// accept returns a "copy" of the socket to work with
			addrlen = sizeof(caddr);
			errno = 0;
			c_socket = accept(s_socket, (struct sockaddr *)&caddr, (socklen_t *)&addrlen);
			if (gsStopServer)
				break;
			// Once Hook is pending
			XThreadsEnterCriticalSection();		
			if (gsExecuteHook)
			{	gsExecuteHook = false;
				XThreadsLeaveCriticalSection();
				// Note that "hook" never be executed inside critical section
				// (think to the Biferno reload command that waits for users to exit)
				gsOnceHook(gsOnceHookUData);	// <-- exec hook once
			}
			else
				XThreadsLeaveCriticalSection();
			if (sockParamP = (SocketParamDataP)malloc(sizeof(SocketParamData)))
			{	sockParamP->userData = userData;
				sockParamP->socket = (long)c_socket;
				sockParamP->func = proc_func;
				// monothread->		_processClientRequest((void*)sockParamP);
				gNConnection++;
				err = XNewThread(&threadID, nil, _processClientRequest, 1024L * 64L, (void*)sockParamP);
			}
			else
				err = -1;

			if (err)
			{
				proc_func((long)c_socket, 0, err, userData);
				err = noErr;	// continue
			}
		}
	}
	XGetMilliseconds(&initMilliSecs);
	while ((gNConnection > 0) && NOT(gExitForced))
	{	XYield(&lastTicks);
		XGetMilliseconds(&millisecs);
		if ((millisecs - initMilliSecs) > kYieldTimeout)
			break;
	}
}       
#endif
	
return err;
}

//===========================================================================================
XErr	XServerSendToClient(long socketRef, BlockRef buffToSend, long buffToSendLength)
{
//int		c_socket = (int)socketRef;
XErr	err = noErr;
	
	err = XSocketsSend(socketRef, buffToSend, buffToSendLength);
		
return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	connect_nonblock(int c_socket, struct sockaddr *un_saddr, int sizeofUn_saddr, unsigned long timeout_secs)
{
int				flags;
XErr			err = noErr;
fd_set        	read_sd_set, write_sd_set;
struct timeval	tv;
int				res, error;
socklen_t		len;

	flags = fcntl(c_socket, F_GETFL, 0);
	fcntl(c_socket, F_SETFL, flags | O_NONBLOCK);
	errno = 0;
	res = connect(c_socket, un_saddr, sizeofUn_saddr);
	if NOT(res)
		goto done;
	else
		err = errno;
	if (err == EINPROGRESS)	
	{	FD_ZERO(&read_sd_set);
		FD_SET(c_socket, &read_sd_set);
		write_sd_set = read_sd_set;
		tv.tv_sec = timeout_secs;
		tv.tv_usec = 0;
		errno = noErr;
		res = select(c_socket+1, &read_sd_set, &write_sd_set, NULL, timeout_secs ? &tv : NULL);
		if (res)
			err = ETIMEDOUT;
		else
		{	if (FD_ISSET(c_socket, &read_sd_set) || FD_ISSET(c_socket, &write_sd_set))
			{	len = sizeof(error);
				if (getsockopt(c_socket, SOL_SOCKET, SO_ERROR, &error, &len))
					err = error;	// Solaris pending error
			}
			else
				err = ECONNREFUSED;
		}
	}

done:
fcntl(c_socket, F_SETFL, flags);
return err;
}

//===========================================================================================
// server_port == 0 => Unix Protocol (only local)
XErr	XClientCall(char *serverAddr, long server_port, BlockRef dataToSend, long dataToSendLen, BlockRef *serverResponseP, long *serverResponseLenP, char *unixfile, char *errString, ReceiveCompleteCallBack completeCallBack, long completeCallBackParam, long timeout_secs, Boolean expectPrefixed)
{
int				c_socket = -1;
//struct		hostent shost;
XSafeHostent	shost;
CStr255			thisServerAddr;
char			*servP = nil;
XErr			err = noErr;
BlockRef		serverResponseBlock = 0;
long			serverResponseLen = 0;

	if (errString)
		*errString = 0;
	if (serverResponseP)
		*serverResponseP = 0;
	if (serverResponseLenP)
		*serverResponseLenP = 0;
	
	// Server address
	if (server_port)
	{	if (serverAddr && *serverAddr)
			servP = serverAddr;
		else
		{	System_EnterCS();
			errno = 0;
			if (gethostname(thisServerAddr, 255) < 0)
				err = errno;
			else
				servP = thisServerAddr;
			System_LeaveCS();
		}
	}
	
	if NOT(err)
	{
		// Let's create a new client socket
		System_EnterCS();
		errno = 0;
		if (server_port)
			c_socket = socket(PF_INET, SOCK_STREAM, 0);
		else
			c_socket = socket(AF_LOCAL, SOCK_STREAM, 0);
		if (c_socket < 0)
			err = errno;
		System_LeaveCS();
		if NOT(err)
		{	// we need the client to know about the server
			if (server_port)
			{	
			struct sockaddr_in saddr;

				if (err = GetHostByNameSafe(servP, &shost))
				{	CEquStr(errString, "Can't resolve name: ");
					CAddStr(errString, servP);
				}
				/*
				System_EnterCS();
				errno = 0;
				if ((shost = gethostbyname(servP)) == NULL)
				{	if NOT(err = errno)
						err = ENOENT;
				}
				if (err && errString)
				{	CEquStr(errString, "Can't resolve name: ");
					CAddStr(errString, servP);
				}
				System_LeaveCS();
				*/
				if NOT(err)
				{	System_EnterCS();
					saddr.sin_family = AF_INET;
					memcpy(&saddr.sin_addr, shost.h_addr_list0, shost.h_length);
					saddr.sin_port = htons(server_port);
					// now we connect to the server
					errno = 0;
					if ((connect(c_socket, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in))) < 0)
						err = errno;
					if (err)
						err = connect_nonblock(c_socket, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in), timeout_secs);
					System_LeaveCS();
				}
			}
			else
			{
			struct sockaddr_un un_saddr;
			
				System_EnterCS();
				bzero(&un_saddr, sizeof(un_saddr));
				un_saddr.sun_family = AF_LOCAL;
				strcpy(un_saddr.sun_path, unixfile);
				errno = 0;
				if ((connect(c_socket, (struct sockaddr*)&un_saddr, sizeof(un_saddr))) < 0)
					err = errno;
				if (err)
					err = connect_nonblock(c_socket, (struct sockaddr*)&un_saddr, sizeof(un_saddr), timeout_secs);
				System_LeaveCS();
			}
			if NOT(err)
			{			
				/*if (timeout_secs)
				{
				struct timeval tv;
				
					if (timeout_secs > 60)
						tv.tv_sec = 60;
					else
						tv.tv_sec = timeout_secs;
					tv.tv_usec = 0;
					errno = 0;
					if (setsockopt(c_socket, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0)
						err = errno;
				}*/
				if NOT(err)
				{	// send
					if NOT(err = XSocketsSend(c_socket, dataToSend, dataToSendLen))
					{	// receive
						if (serverResponseP)	// nil -> don't wait for response
						{	if (timeout_secs)
							{
							fd_set        	read_sd_set;
							struct timeval	tv;
							int				status;
							
								FD_ZERO(&read_sd_set);
								FD_SET(c_socket, &read_sd_set);
								tv.tv_sec = timeout_secs;
								tv.tv_usec = 0;
								errno = noErr;
								status = select(c_socket+1, &read_sd_set, NULL, NULL, &tv);
								if (status < 0)			// error
									err = errno;
								else if (status == 0)	// timeout
									err = EWOULDBLOCK;
							}
							if NOT(err)
								err = XSocketsReceive(c_socket, &serverResponseBlock, &serverResponseLen, expectPrefixed, completeCallBack, completeCallBackParam);
						}
					}
				}
			}
		}
	}

//out:
if (serverResponseBlock)
{	if (serverResponseP)
		*serverResponseP = serverResponseBlock;
	else
		DisposeBlock(&serverResponseBlock);
}
if (serverResponseLenP)
	*serverResponseLenP = serverResponseLen;

if (c_socket >= 0)
	close(c_socket);
return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	XLocalAddress(long socketRef, char *addr)
{

XErr				err = noErr;
struct sockaddr		*clientAddr;
socklen_t			len;

	errno = 0;
	clientAddr = (struct sockaddr*)malloc(255);
	len = 255;
	if (getsockname(socketRef, clientAddr, &len) < 0)
		err = errno;
	sock_ntop(clientAddr, len, addr);
	free(clientAddr);
	
return err;
}

//===========================================================================================
XErr	XRemoteAddress(long socketRef, char *addr)
{
XErr				err = noErr;
struct sockaddr		*clientAddr;
socklen_t			len;

	errno = 0;
	clientAddr = (struct sockaddr*)malloc(255);
	len = 255;
	if (getpeername(socketRef, clientAddr, &len) < 0)
		err = errno;
	sock_ntop(clientAddr, len, addr);
	free(clientAddr);
	
return err;
}

#endif // __XLIB_WITH_HELPERS__

