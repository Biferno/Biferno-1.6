/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XDateTimeUnix.c,v 1.5 2005-12-06 11:33:57 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

#include <sys/time.h>
#include <errno.h>
#include <unistd.h>

struct	timeval		gsStartupTimeVal = {0, 0};

//===========================================================================================
void	XGetMilliseconds(unsigned long *milliSecondsP)
{
struct timeval	tv;
long			secs, micro_secs;

	//if NOT(gsStartupTimeVal.tv_sec)
	//	gettimeofday(&gsStartupTimeVal, NULL);
	// secs + microsecs from 1970
	System_EnterCS();
	gettimeofday(&tv, NULL);
	secs = tv.tv_sec - gsStartupTimeVal.tv_sec;
	micro_secs = tv.tv_usec - gsStartupTimeVal.tv_usec;
	if (micro_secs < 0)
	{	--secs;
		micro_secs = 1000000 + micro_secs;
	}
	// millisecs from startUp
	*milliSecondsP = (secs * 1000) + (micro_secs / 1000);
	System_LeaveCS();
}

//===========================================================================================
void	XInitGetTicks()
{
	XThreadsEnterCriticalSection();
	gettimeofday(&gsStartupTimeVal, NULL);
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
// gluata solo per unix
#ifndef __XLIB_CLIENT__
	// 1/60 of secs
	unsigned long	XGetTicks(void)
	{
	struct timeval	tv;
	unsigned long	secs;
	long			micro_secs;

		//if NOT(gsStartupTimeVal.tv_sec)
		//	gettimeofday(&gsStartupTimeVal, NULL);
		gettimeofday(&tv, NULL);
		secs = tv.tv_sec - gsStartupTimeVal.tv_sec;
		micro_secs = tv.tv_usec - gsStartupTimeVal.tv_usec;
		if (micro_secs < 0)
		{	--secs;
			micro_secs = 1000000 + micro_secs;
		}
		
	return ((secs * 60) + (micro_secs * 60 / 1000000));
	}

	/*unsigned long	XGetTicksExt(struct timeval *curTimeVal, struct timeb *curTimeB)
	{
	struct timeval	tv;
	unsigned long	secs;
	long			micro_secs;

		gettimeofday(&tv, NULL);
		secs = tv.tv_sec - gsStartupTimeVal.tv_sec;
		micro_secs = tv.tv_usec - gsStartupTimeVal.tv_usec;
		if (micro_secs < 0)
		{	--secs;
			micro_secs = 1000000 + micro_secs;
		}
		if (curTimeVal)
			*curTimeVal = tv;
		if (curTimeB)
			ftime(curTimeB);  
		
	return ((secs * 60) + (micro_secs * 60 / 1000000));
	}*/

#else
extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;

	unsigned long	XGetTicks(void)
	{
	unsigned long	(*p)(void) = (void*)gXLibCallBacksRecPtr->XGetTicks;

		return p();
	}
#endif
//===========================================================================================
void	XDelay(unsigned long ticks)
{
	System_EnterCS();
	sleep(ticks/60);
	System_LeaveCS();
}


