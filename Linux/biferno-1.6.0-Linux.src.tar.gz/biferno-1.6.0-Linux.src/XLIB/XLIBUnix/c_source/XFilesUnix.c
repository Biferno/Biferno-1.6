/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XFilesUnix.c,v 1.26 2006-05-19 11:50:04 valfer Exp $
	|______________________________________________________________________________
*/
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <assert.h>
#include <errno.h>
#include <time.h>
#ifdef WITH_WALKFOLDER
	#include <ftw.h>
#endif
#include <pwd.h>
#include <grp.h>
#include <utime.h>
#include <grp.h>
#include <stdlib.h>
#include <sys/param.h>

#include "XLib.h"
#include "XLibPrivate.h"
#include "XFilesUnixPrivate.h"

// type cast of: typedef unsigned long long	XFileRef;
typedef struct {
				long		fd;
				Byte		magicNumber;	// because on unix fd can be 0, not in XLib
				Byte		reserved1;
				Byte		reserved2;
				Byte		reserved3;
				} UnixFRef;

typedef struct {
				Boolean				pad;		//onlyWithEmptySuffix;
				Boolean				recursive;
				short				initialPathLength;
				CStr255				suffix;
				CStr255				initialPath;
				WalkXFolderCallBack	callBack;
				long				userData;
			} DirWalkRec, *DirWalkRecP;

#if	WITH_WALKFOLDER
	static DirWalkRec	gDirWalkRec;
#endif

#ifdef __LITTLE_ENDIAN__		// INTEL
	#define	_SO		'os'
#else
	#define	_SO		'so'
#endif

#if __MAC_XLIB__ && __MACOSX__ && TARGET_API_MAC_CARBON
	XErr	CopyResourceFork(FSSpec *scrPtr, FSSpec *dstPtr);
#endif

//===========================================================================================
int		_XRef2Fd(XFileRef xrefNum)
{
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;

	return uniFRefP->fd;
}

//===========================================================================================
/*XErr	_GetUnixFullPath(XFilePathPtr filePath, XFilePathPtr fullPath)
{

	CEquStr(fullPath, filePath);
	
return noErr;
}*/

//===========================================================================================
static XErr	_OnSameDrive(XFilePathPtr path1, XFilePathPtr path2, Boolean *resultP)
{
struct stat		stat1, stat2;
XErr			err = noErr;

	ClearBlock(&stat1, sizeof(struct stat));
	errno = 0;
	if (stat(path1, &stat1) != 0)
		err = errno;
	else
	{	ClearBlock(&stat2, sizeof(struct stat));
		errno = 0;
		if (stat(path2, &stat2) != 0)
			err = errno;
		else
			*resultP = (stat1.st_dev == stat2.st_dev);
	}
	if (err)
	{	if (err == ENOENT)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ENOENT)
			err = noErr;
		*resultP = false;
	}

return err;
}

//===========================================================================================
static XErr	_ResolveXAlias(XFilePathPtr filePath)
{
XErr		err = noErr;
XFilePath	fullPath;
int			totChars;

	CEquStr(fullPath, filePath);
	errno = 0;
	totChars = readlink(fullPath, filePath, 255);
	if (totChars < 0)
	{	err = errno;
		if (err == EINVAL)
		{	err = noErr;
			CEquStr(filePath, fullPath);
		}
	}
	else
		filePath[totChars] = 0;

return err;
}

//===========================================================================================
static XErr	_GetEOF(int fd, long *eofP)
{
XErr		err = noErr;
long		curPos;

	errno = 0;
	curPos = lseek(fd, 0, SEEK_CUR);
	if (curPos == -1)
		err = errno;
	else
	{	errno = 0;
		*eofP = lseek(fd, 0, SEEK_END);
		if (*eofP == -1)
			err = errno;
		curPos = lseek(fd, curPos, SEEK_SET);
		if (curPos == -1)
			err = errno;
	}

return err;
}

//===========================================================================================
static XErr	_WriteFile(int fd, Ptr bufferP, long *bufferLenP)
{
ssize_t		bytesWritten, toWrite;
XErr		err = noErr;

	errno = 0;
	toWrite = *bufferLenP;
	bytesWritten = write(fd, bufferP, *bufferLenP);
	if (toWrite && NOT(bytesWritten))
	{	err = XError(kXLibError, ErrXFiles_EndOfFile);
		*bufferLenP = 0;
	}
	else if (bytesWritten < 0)
		err = errno;
	else
		*bufferLenP = bytesWritten;
	
return err;
}

//===========================================================================================
static XErr	_ReadFile(int fd, Ptr bufferP, long *bufferLenP)
{
XErr		err = noErr;
ssize_t		bytesRead;

	errno = 0;
	bytesRead =	read(fd, bufferP, *bufferLenP);
	if NOT(bytesRead)
	{	err = XError(kXLibError, ErrXFiles_EndOfFile);
		*bufferLenP = 0;
	}
	else if (bytesRead < 0)
		err = errno;
	else
	{	if (*bufferLenP != bytesRead)
			err = XError(kXLibError, ErrXFiles_EndOfFile);
		*bufferLenP = bytesRead;
	}

return err;
}

#define	MAX_TRANSFER_BLOCK	(50L * 1024L)	// 50K
//===========================================================================================
static XErr	_TranferBytes(int sourceFD, int destFD)
{	
XErr		err = noErr, readErr = noErr;
long		inCount, eof;
long		totCount;
BlockRef	block;
char		*p;
	
	if NOT(err = _GetEOF(sourceFD, &eof))
	{	if (eof)
		{	if (block = NewBlockLocked(eof, &err, &p))
			{	if NOT(err = _ReadFile(sourceFD, p, &eof))
					err = _WriteFile(destFD, p, &eof);
				DisposeBlock(&block);
			}
			else	// a pezzi
			{	if (block = NewBlockLocked(MAX_TRANSFER_BLOCK, &err, &p))
				{	totCount = 0;
					do{
							inCount = MAX_TRANSFER_BLOCK;
							readErr = _ReadFile(sourceFD, p, &inCount);
							if (readErr && (readErr != XError(kXLibError, ErrXFiles_EndOfFile)))
								err = readErr;
							else
							{	if ((totCount + inCount) >= eof)
								{	inCount = (eof - totCount);
									readErr = XError(kXLibError, ErrXFiles_EndOfFile);
								}
								err = _WriteFile(destFD, p, &inCount);
								totCount += inCount;
							}
						} while ((readErr == noErr) && (err == noErr));
					DisposeBlock(&block);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetFileInfo(XFilePathPtr filePath, XFileInfoP xFileInfoP, Boolean isAlias, long *modeP)
{
XErr			err = noErr;
struct stat		theStat;
struct tm		dc;
#if __UNIX_XLIB__ || __MACOSX__
	struct passwd	*pwp;
	struct group	*grp;
#endif
int				filePathLen, res;

	errno = 0;
	if (isAlias)
		res = lstat(filePath, &theStat);
	else
		res = stat(filePath, &theStat);
	if (res < 0)
		err = errno;
	else
	{	ClearBlock(xFileInfoP, sizeof(XFileInfo));
		CopyBlock(&dc, localtime(&theStat.st_mtime), sizeof(dc));
		ANSI2XDateTime((Ptr)&dc, &xFileInfoP->modifDate);
		if (modeP)
			*modeP = theStat.st_mode;
		ClearBlock(&xFileInfoP->creatDate, sizeof(XDateTimeRec)); // su Unix non c'�
		filePathLen = CLen(filePath);
			xFileInfoP->isDLL = (filePathLen > 3) && (filePath[filePathLen-3] == '.') && (*(short*)&filePath[filePathLen-2] == _SO);
	#if __UNIX_XLIB__ || __MACOSX__
		if (pwp = getpwuid(theStat.st_uid))
		{	CEquStr(xFileInfoP->user, pwp->pw_name);
			if (grp = getgrgid(theStat.st_gid))
				CEquStr(xFileInfoP->group, grp->gr_name);
		}
	#endif
	}
	
return err;
}

//===========================================================================================
static XErr	_SetFileInfo(XFilePathPtr filePath, XFileInfoP xFileInfoP, Boolean isAlias, long *modeP)
{
XErr			err = noErr, err2 = noErr;
struct utimebuf {
				time_t		act_time;
				time_t		mod_time;
				} timebuf;
struct stat		theStat;
int				res;
struct passwd	*ent;
struct group	*grp;

	errno = 0;
	if (isAlias)
		res = lstat(filePath, &theStat);
	else
		res = stat(filePath, &theStat);
	if (res < 0)
		err = errno;
	else
	{	// File times
		timebuf.act_time = theStat.st_atime;
		XDateTimeToSeconds(&xFileInfoP->modifDate, &timebuf.mod_time);
		if (timebuf.mod_time != theStat.st_mtime)
		{	errno = 0;
			#if __UNIX_XLIB__
			if (utime(filePath, (const struct utimbuf *)&timebuf) < 0)		// doesn't compile with CW
				err = errno;
			#endif
		}
		// Owner and Group
	#if __UNIX_XLIB__ || __MACOSX__
		if (ent = getpwnam(xFileInfoP->user))
		{	if (grp = getgrnam(xFileInfoP->group))
			{	if ((ent->pw_uid != theStat.st_uid) || (grp->gr_gid != theStat.st_gid))
				{	errno = 0;
					if (isAlias)
					{	
					#ifndef __MACOSX__
						res = lchown(filePath, ent->pw_uid, grp->gr_gid);
					#endif
					}
					else
						res = chown(filePath, ent->pw_uid, grp->gr_gid);
					if (res < 0)
						err2 = errno;
				}
			}
			else
				err2 = XError(kXLibError, ErrXFiles_UnknownGroup);
		}
		else
			err2 = XError(kXLibError, ErrXFiles_UnknownUser);
		if (err2 && NOT(err))
			err = err2;
		// Modes
		if (modeP)
		{	errno = 0;
			if (chmod(filePath, *modeP) == -1)
			{	err2 = errno;
				if (err2 && NOT(err))
					err = err2;
			}
		}
	#endif		
	}
	
return err;
}

//===========================================================================================
/*static XErr	_LinUnlinkFile(XFilePathPtr oldFullPath, XFilePathPtr newFullPath, Boolean isAlias)
{
XErr		err = noErr;
XFilePath	originalPath;

	XThreadsEnterCriticalSection();
	if (isAlias)
	{	CEquStr(originalPath, oldFullPath);
		if NOT(err = _ResolveXAlias(originalPath))
		{	errno = 0;
			if (symlink(originalPath, newFullPath) < 0)
				err = errno;
		}
	}
	else
	{	errno = 0;
		if (link(oldFullPath, newFullPath) < 0)
			err = errno;
	
	}
	if NOT(err)
	{	errno = 0;
		if (unlink(oldFullPath) < 0)
			err = errno;
	}
	if (err == EEXIST)
		err = XError(kXLibError, ErrXFiles_DuplicatedFile);
	XThreadsLeaveCriticalSection();
	
return err;
}*/

//===========================================================================================
/*static XErr	_GetTempPath(char *tempPath)
{
XErr		err = noErr;

	errno = 0;
	if NOT(tmpnam(tempPath))
		err = errno;
	
	
	//CEquStr(tempPath, "/tmp/temp.XXXXXX");
	//if NOT(mktemp(tempPath))
	//	err = errno;
		
return err;
}
*/
//===========================================================================================
/*static XErr	_ExchangeFiles(char *file1, char *file2, Boolean isAlias)
{
XErr		err = noErr;
CStr255		temp;
Boolean		isAlias_2;

	if NOT(err = XIsAlias(file2, &isAlias_2))
	{	if NOT(err = _GetTempPath(temp))
		{	// Move file1 to temp
			if NOT(err = _LinUnlinkFile(file1, temp, isAlias))
			{	// move file2 to file1
				if NOT(err = _LinUnlinkFile(file2, file1, isAlias_2))
				{	// move temp to file2
					err = _LinUnlinkFile(temp, file2, isAlias);
				}
			}
		}
	}
	
return err;
}*/

//===========================================================================================
static XErr	_SetDestFileInfo(XFilePathPtr destFullPath, XFileInfo *xFileInfoP, Boolean isAlias, long *modeP)
{
XErr	err = noErr;

	err = _SetFileInfo(destFullPath, xFileInfoP, isAlias, modeP);
	if (err == EPERM)
		err = noErr;	// Can't set user/pass
	
return err;
}

#if __MAC_XLIB__ && __MACOSX__ && TARGET_API_MAC_CARBON
//===========================================================================================
static XErr	_DuplicateMacOSStuff(XFilePathPtr sourceFullPath, XFilePathPtr destFullPath)
{
XErr	err = noErr;

	if NOT(err)
	{	
	FSSpec			sourceSpec, destSpec;
	HFileInfo		theFileInfo;
	
		if NOT(err = GetMacOSSpecExt(sourceFullPath, &sourceSpec, false, true))
		{	if NOT(err = GetMacOSSpecExt(destFullPath, &destSpec, false, true))
			{	if NOT(err = CopyResourceFork(&sourceSpec, &destSpec))
				{	theFileInfo.ioCompletion = nil;
					theFileInfo.ioNamePtr = sourceSpec.name;
					theFileInfo.ioVRefNum = sourceSpec.vRefNum;
					theFileInfo.ioDirID = sourceSpec.parID;
					theFileInfo.ioFDirIndex = 0;
					theFileInfo.ioFRefNum = 0;
					if NOT(err = PBGetCatInfoSync((CInfoPBPtr)&theFileInfo))
					{	theFileInfo.ioCompletion = nil;
						theFileInfo.ioNamePtr = destSpec.name;
						theFileInfo.ioVRefNum = destSpec.vRefNum;
						theFileInfo.ioDirID = destSpec.parID;
						theFileInfo.ioFDirIndex = 0;
						theFileInfo.ioFRefNum = 0;
						err = PBSetCatInfoSync((CInfoPBPtr)&theFileInfo);
					}
				}
			}
		}
	}
return err;
}
#endif

//===========================================================================================
static XErr	_DuplicateFile(XFilePathPtr sourceFullPath, XFilePathPtr destFullPath, Boolean replaceExisting, Boolean removeOriginal, Boolean destExists, Boolean isAlias)
{	
XFilePath	sourceOriginal;	//, tempPath;
XErr		err = noErr, err2 = noErr;
//Boolean		copyOk, created;
XFileInfo 	xFileInfo;
int			res, sourceFD, tempFD;
long		permission;
long		mode;
CStr255		temp_file, destFullFolder;

	if (destExists && NOT(replaceExisting))
		err = XError(kXLibError, ErrXFiles_DuplicatedFile);
	else
	{	if NOT(err = _GetFileInfo(sourceFullPath, &xFileInfo, true, &mode))
		{	if (isAlias)
			{	CEquStr(sourceOriginal, sourceFullPath);
				if NOT(err = _ResolveXAlias(sourceOriginal))
				{	if (destExists)
					{	if (replaceExisting)
							err = DeleteXFile(destFullPath);
						else
							err = XError(kXLibError, ErrXFiles_DuplicatedFile);
					}
					if NOT(err)
					{	// Make an alias to the original in location tempPath
						errno = 0;
						if (symlink(sourceOriginal, destFullPath) < 0)
							err = errno;
					}
				}
			}
			else
			{	CEquStr(destFullFolder, destFullPath);
				*strrchr(destFullFolder, '/') = 0;
				CEquStr(temp_file, destFullFolder);
				CAddStr(temp_file, "/temp.XXXXXX");
				errno = 0;
				tempFD = mkstemp(temp_file);
				if (tempFD == -1)
					err = errno;
				else
				{	errno = 0;
					permission = O_RDONLY;
					sourceFD = open(sourceFullPath, permission);
					if (sourceFD == -1)
						err = errno;
					else
					{	errno = 0;
						if (flock(sourceFD, LOCK_EX) < 0)
							err = errno;
						if NOT(err)
						{	err = _TranferBytes(sourceFD, tempFD);
							errno = 0;
							flock(sourceFD, LOCK_UN);	// no check error (we are going to close it)
						}
					}
					res = close(sourceFD);
					if NOT(err)
					{	errno = 0;
						// Note: rename deletes destFullPath if exists
						if (rename(temp_file, destFullPath) == -1)
						{	err = errno;
							// delete temp file
							unlink(temp_file);
							tempFD = -1;
						}
					}
					if (tempFD != -1)
						res = close(tempFD);
				}
			}
		}
		if NOT(err)
		{	if NOT(err = _SetDestFileInfo(destFullPath, &xFileInfo, isAlias, &mode))
			{	
			#if __MAC_XLIB__ && __MACOSX__ && TARGET_API_MAC_CARBON
				err = _DuplicateMacOSStuff(sourceFullPath, destFullPath);
			#endif
			}
			if (removeOriginal)
			{	errno = 0;
				if (unlink(sourceFullPath) < 0)
					err2 = errno;
				if (err2 && NOT(err))
					err = err2;
			}
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	_DuplicateFile(XFilePathPtr sourceFullPath, XFilePathPtr destFullPath, Boolean replaceExisting, Boolean removeOriginal)
{	
XFilePath	sourceOriginal, tempPath;
XErr		err = noErr, err2 = noErr;
Boolean		copyOk, created, isAlias, destFileExists;
XFileInfo 	xFileInfo;
int			sourceFD, destFD;
long		permission;
long		mode;

	created = false;
	copyOk = false;
	if NOT(err = XIsAlias(sourceFullPath, &isAlias))
	{	destFileExists = (CheckPath(destFullPath, false) == noErr);
		if (isAlias)
		{	CEquStr(sourceOriginal, sourceFullPath);
			if NOT(_GetFileInfo(sourceFullPath, &xFileInfo, true, &mode))
			{	if NOT(err = _ResolveXAlias(sourceOriginal))
				{	if (destFileExists && replaceExisting)
						err = _GetTempPath(tempPath);
					else
						CEquStr(tempPath, destFullPath);
					if NOT(err)
					{	// Make an alias to the original in location tempPath
						errno = 0;
						if (symlink(sourceOriginal, tempPath) < 0)
						{	err = errno;
							if (err == EEXIST)
								err = XError(kXLibError, ErrXFiles_DuplicatedFile);
						}
						else
						{	created = true;
							copyOk = true;
						}
					}
				}
			}
		}
		else
		{	if NOT(_GetFileInfo(sourceFullPath, &xFileInfo, false, &mode))
			{	if (destFileExists && replaceExisting)
					err = _GetTempPath(tempPath);
				else
					CEquStr(tempPath, destFullPath);
				if NOT(err)
				{	errno = 0;
					permission = O_RDWR | O_CREAT;
					destFD = open(tempPath, permission);
					err = errno;
				}
				if NOT(err)
				{	created = true;
					// Open source file
					errno = 0;
					permission = O_RDONLY;
					sourceFD = open(sourceFullPath, permission);
					err = errno;
					if NOT(err)
					{	err = _TranferBytes(sourceFD, destFD);
						errno = 0;
						close(sourceFD);
						err2 = errno;
						if (err2 && NOT(err))
							err = err2;
					}
					errno = 0;
					close(destFD);
					err2 = errno;
					if (err2 && NOT(err))
						err = err2;
					if NOT(err)
						copyOk = true;
				}
				else if (err == EACCES)
					err = XError(kXLibError, ErrXFiles_DuplicatedFile);
			}
		}
		if (copyOk)
		{	if (destFileExists && replaceExisting)
				err = _ExchangeFiles(tempPath, destFullPath, isAlias);
			if NOT(err)
			{	err = _SetFileInfo(destFullPath, &xFileInfo, false, &mode);
				if (err == EPERM)
					err = noErr;	// Can't set user/pass
				if (removeOriginal)
				{	errno = 0;
					if (unlink(sourceFullPath) < 0)
						err2 = errno;
					if (err2 && NOT(err))
						err = err2;
				}
			}
		}
		if (created && destFileExists && replaceExisting)
		{	err2 = DeleteXFile(tempPath);
			if (err2 && NOT(err))
				err = err2;
		}
	}

#if __MAC_XLIB__ && __MACOSX__ && TARGET_API_MAC_CARBON
	if NOT(err)
	{	
	FSSpec			sourceSpec, destSpec;
	HFileInfo		theFileInfo;
	
		if NOT(err = GetMacOSSpecExt(sourceFullPath, &sourceSpec, false, true))
		{	if NOT(err = GetMacOSSpecExt(destFullPath, &destSpec, false, true))
			{	if NOT(err = CopyResourceFork(&sourceSpec, &destSpec))
				{	theFileInfo.ioCompletion = nil;
					theFileInfo.ioNamePtr = sourceSpec.name;
					theFileInfo.ioVRefNum = sourceSpec.vRefNum;
					theFileInfo.ioDirID = sourceSpec.parID;
					theFileInfo.ioFDirIndex = 0;
					theFileInfo.ioFRefNum = 0;
					if NOT(err = PBGetCatInfoSync((CInfoPBPtr)&theFileInfo))
					{	theFileInfo.ioCompletion = nil;
						theFileInfo.ioNamePtr = destSpec.name;
						theFileInfo.ioVRefNum = destSpec.vRefNum;
						theFileInfo.ioDirID = destSpec.parID;
						theFileInfo.ioFDirIndex = 0;
						theFileInfo.ioFRefNum = 0;
						err = PBSetCatInfoSync((CInfoPBPtr)&theFileInfo);
					}
				}
			}
		}
	}
#endif

return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	OpenXFile(XFilePathPtr fullPath, short mode, long permission, Boolean dontUseCache, XFileRef *xrefNumP)
{
XErr		err = noErr;
int			fd = 0;
UnixFRef	*uniFRefP = (UnixFRef*)xrefNumP;
	
	if (permission == READ_PERM)
		permission = O_RDONLY;
	else
		permission = O_RDWR;
	
	if (dontUseCache)
		permission |= O_FSYNC;
	
	errno = 0;
	switch(mode)
	{	case CREATE_FILE_NEW:
			err = CheckPath(fullPath, true);
			if (err == XError(kXLibError, ErrXFiles_FileNotFound))
			{	errno = 0;
				permission |= O_CREAT;
				fd = open(fullPath, permission);
				err = errno;
			}
			else if NOT(err)
				err = XError(kXLibError, ErrXFiles_DuplicatedFile);
			break;
		case CREATE_FILE_ALWAYS:
			if (unlink(fullPath) < 0)
			{	if (errno != ENOENT)
					err = errno;
			}
			if NOT(err)
			{	errno = 0;
				permission |= O_CREAT;	// ex | O_TRUNC);
				fd = open(fullPath, permission);
				err = errno;
			}
			break;
		case OPEN_FILE_EXISTING:
			fd = open(fullPath, permission);
			err = errno;
			break;
		case OPEN_FILE_ALWAYS:
			fd = open(fullPath, permission);
			if ((fd == -1)/* && (errno == ENOENT)*/)
			{	errno = 0;
				permission |= O_CREAT;
				fd = open(fullPath, permission);		
			}
			err = errno;
			break;
	}
	
	if (NOT(err) && (permission & O_CREAT))
	{	errno = 0;
		if (fchmod(fd, S_IRUSR+S_IWUSR+S_IRGRP+S_IROTH) == -1)
			err = errno;
	}

if NOT(err)
{	*xrefNumP = 0;		// clean bits
	uniFRefP->fd = fd;
	uniFRefP->magicNumber = 0xFF;
}
//else
//	CEquStr(globalErrStr, fullPath);

if (err == ENOENT)
	err = XError(kXLibError, ErrXFiles_FileNotFound);

return err;
}

//===========================================================================================
XErr	CloseXFile(XFileRef *xrefNumP)
{
UnixFRef	*uniFRefP = (UnixFRef*)xrefNumP;
XErr		err = noErr;

	
	if (uniFRefP && (uniFRefP->fd))
	{	errno = 0;
		close(uniFRefP->fd);
		err = errno;
		uniFRefP->fd = -1;
	}
	

return err;
}

//===========================================================================================
XErr	ReadXFile(XFileRef xrefNum, Ptr bufferP, long *bufferLenP)
{
//XErr		err = noErr;
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;

	return _ReadFile(uniFRefP->fd, bufferP, bufferLenP);
	/*errno = 0;
	bytesRead =	read(uniFRefP->fd, bufferP, *bufferLenP);
	if NOT(bytesRead)
	{	err = XError(kXLibError, ErrXFiles_EndOfFile);
		*bufferLenP = 0;
	}
	else if (bytesRead < 0)
		err = errno;
	else
	{	if (*bufferLenP != bytesRead)
			err = XError(kXLibError, ErrXFiles_EndOfFile);
		*bufferLenP = bytesRead;
	}*/
}

//===========================================================================================
XErr	WriteXFile(XFileRef xrefNum, Ptr bufferP, long *bufferLenP)
{
//XErr		err = noErr;
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
	
	return _WriteFile(uniFRefP->fd, bufferP, bufferLenP);
	/*errno = 0;
	toWrite = *bufferLenP;
	bytesWritten = write(uniFRefP->fd, bufferP, *bufferLenP);
	if (toWrite && NOT(bytesWritten))
	{	err = XError(kXLibError, ErrXFiles_EndOfFile);
		*bufferLenP = 0;
	}
	else if (bytesWritten < 0)
		err = errno;
	else
		*bufferLenP = bytesWritten;
	
	
return err;*/
}

//===========================================================================================
XErr	FlushXFile(XFileRef xrefNum)
{
XErr		err = noErr;
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
		
	
	errno = 0;
	if (fsync(uniFRefP->fd) < 0)
		err = errno;
	
	
return err;
}

//===========================================================================================
XErr	DeleteXFile(XFilePathPtr fullPath)
{
XErr		err = noErr;
//Boolean		isAlias;

	errno = 0;
	if (unlink(fullPath) < 0)
		err = errno;
	
return err;
}

//===========================================================================================
static void		_FileFolderPath(XFilePathPtr tempStr)
{
char	*strP;
int		tLen;

	strP = strrchr(tempStr, '/');
	tLen = CLen(tempStr);
	if (tempStr[tLen-1] == '/')
	{	tempStr[tLen-2] = 0;
		strP = strrchr(tempStr, '/');
		tempStr[strP - tempStr] = 0;
	}
	else
		tempStr[strP - tempStr] = 0;
}

//===========================================================================================
static XErr	_CheckIfFolder(char *newPath, char *oldPath)
{
XErr		err = noErr;
Boolean		isDir = false;
char		*strP;

	if NOT(err = XIsFolder(newPath, &isDir))
	{	if (isDir)
		{	if (strP = strrchr(oldPath, '/'))
			{	if (*(strP+1))
				{	if (newPath[CLen(newPath)-1] != '/')
						CAddChar(newPath, '/');
					CAddStr(newPath, strP+1);
				}
			}
		}
	}
	else if ((err == ENOENT) || (err == XError(kXLibError, ErrXFiles_FolderNotFound)))
		err = noErr;

return err;
}

//===========================================================================================
XErr	TranferBytes(XFileRef sourceRef, XFileRef destRef)
{
int			sourceFD = ((UnixFRef*)&sourceRef)->fd;
int			destFD = ((UnixFRef*)&destRef)->fd;
XErr		err = noErr;
	
	err = _TranferBytes(sourceFD, destFD);

return err;
}

//===========================================================================================
XErr	MoveXFile(XFilePathPtr oldFullPath, XFilePathPtr newFullPath, Boolean replaceExisting)
{
XErr			err = noErr;
Boolean			onSameDrive = false, isAlias = false;
CStr255			tempStr;
Boolean			destExists;
//XFilePath		originalPath;

	XThreadsEnterCriticalSection();
	if NOT(err = _CheckIfFolder(newFullPath, oldFullPath))
	{	err = CheckPath(newFullPath, false);
		if NOT(err)
			destExists = true;
		else if (err == XError(kXLibError, ErrXFiles_FileNotFound))
		{	destExists = false;
			err = noErr;
		}
		if NOT(err)
		{	CEquStr(tempStr, newFullPath);
			_FileFolderPath(tempStr);
			if NOT(err = _OnSameDrive(oldFullPath, tempStr, &onSameDrive))
			{	if NOT(err = XIsAlias(oldFullPath, &isAlias))
				{	if (onSameDrive && NOT(isAlias))
					{	if (destExists)
						{	if (replaceExisting)
								err = DeleteXFile(newFullPath);
							else
								err = XError(kXLibError, ErrXFiles_DuplicatedFile);
						}
						if NOT(err)
						{	errno = 0;
							if (link(oldFullPath, newFullPath) < 0)
								err = errno;
						}
						if NOT(err)
						{	errno = 0;
							if (unlink(oldFullPath) < 0)
								err = errno;
						}
					}
					else
						err = _DuplicateFile(oldFullPath, newFullPath, replaceExisting, true, destExists, isAlias);
				}
			}
		}
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	CopyXFile(XFilePathPtr oldFullPath, XFilePathPtr newFullPath, Boolean replaceExisting)
{
XErr		err = noErr;
Boolean		isAlias = false;

	XThreadsEnterCriticalSection();
	if NOT(err = _CheckIfFolder(newFullPath, oldFullPath))
	{	if NOT(err = XIsAlias(oldFullPath, &isAlias))
			err = _DuplicateFile(oldFullPath, newFullPath, replaceExisting, false, NOT(CheckPath(newFullPath, false)), isAlias);
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	RenameXFile(XFilePathPtr oldPath, XFilePathPtr newPath)
{
XErr	err = noErr;
//int		res = 0;

	XThreadsEnterCriticalSection();
	if (CheckPath(newPath, false) == noErr)
		err = XError(kXLibError, ErrXFiles_DuplicatedFile);
	else
	{	errno = 0;
		if (rename(oldPath, newPath) == -1)
			err = errno;
	}
	XThreadsLeaveCriticalSection();
	
return err;
}


//===========================================================================================
XErr	GetXEOF(XFileRef xrefNum, long *eofP)
{
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
//XErr		err = noErr;
//long		curPos;
	
	return _GetEOF(uniFRefP->fd, eofP);
	/*errno = 0;
	curPos = lseek(uniFRefP->fd, 0, SEEK_CUR);
	if (curPos == -1)
		err = errno;
	else
	{	errno = 0;
		*eofP = lseek(uniFRefP->fd, 0, SEEK_END);
		if (*eofP == -1)
			err = errno;
		curPos = lseek(uniFRefP->fd, curPos, SEEK_SET);
		if (curPos == -1)
			err = errno;
	}*/
}

//===========================================================================================
XErr	GetXEOFFromPath(XFilePathPtr fullPath, long *eofP)
{
XErr			err = noErr;
struct stat		theStat;

	ClearBlock(&theStat, sizeof(struct stat));
	errno = 0;
	if (stat(fullPath, &theStat) != 0)
		err = errno;
	else
		*eofP = theStat.st_size;

return err;
}

//===========================================================================================
XErr	GetXResForkSize(XFilePathPtr filePath, long *eofP)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(filePath)
#endif

	*eofP = 0;

return noErr;
}

//===========================================================================================
XErr	SetXEOF(XFileRef xrefNum, long newEOF)
{
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
XErr		err = noErr;

	
	errno = 0;
	if (ftruncate(uniFRefP->fd, newEOF))
		err = errno;
	
	
return err;
}

//===========================================================================================
XErr	GetXFileInfo(XFilePathPtr fullPath, XFileInfoP xFileInfoP)
{
XErr			err = noErr;
Boolean			isAlias = false;

	if NOT(err = XIsAlias(fullPath, &isAlias))
		err = _GetFileInfo(fullPath, xFileInfoP, isAlias, nil);
	/*	errno = 0;
		if (stat(fullPath, &theStat) < 0)
			err = errno;
		else
		{	ClearBlock(xFileInfoP, sizeof(XFileInfo));
			CopyBlock(&dc, localtime(&theStat.st_mtime), sizeof(dc));
			ANSI2XDateTime((Ptr)&dc, &xFileInfoP->creatDate);
			CopyBlock(&dc, localtime(&theStat.st_ctime), sizeof(dc));
			ANSI2XDateTime((Ptr)&dc, &xFileInfoP->modifDate);
			xFileInfoP->st_mode = theStat.st_mode;
			if (pwp = getpwuid(theStat.st_uid))
			{	CEquStr(xFileInfoP->user, pwp->pw_name);
				if (grp = getgrgid(theStat.st_gid))
					CEquStr(xFileInfoP->group, grp->gr_name);
			}
		}
	}*/

return err;
}

//===========================================================================================
XErr	SetXFileInfo(XFilePathPtr fullPath, XFileInfoP xFileInfoP)
{
XErr			err = noErr;
Boolean			isAlias = false;

	if NOT(err = XIsAlias(fullPath, &isAlias))
		err = _SetFileInfo(fullPath, xFileInfoP, isAlias, nil);
	
return err;
}

//===========================================================================================
XErr	SetXFPos(XFileRef xrefNum, long mode, long offset)
{
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
XErr		err = noErr;
long		newOffset;

	
	if (mode == FROM_START)
		mode = SEEK_SET;
	else if (mode == FROM_MARK)
		mode = SEEK_CUR;
	else if (mode == FROM_EOF)
		mode = SEEK_END;
	
	errno = 0;
	newOffset = lseek(uniFRefP->fd, offset, mode);
	if (newOffset < 0)
		err = errno;
	

return err;
}

//===========================================================================================
XErr	GetXFPos(XFileRef xrefNum, long *offsetP)
{
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
XErr		err = noErr;	
	
	*offsetP = lseek(uniFRefP->fd, 0, SEEK_CUR);
	
return err;
}

//===========================================================================================
XErr	GetFileMode(XFileRef xrefNum, XFilePathPtr fullPath, long *modeP)
{
XErr		err = noErr;
struct stat	theStat;
UnixFRef	*uniFRefP;

	if (xrefNum)
	{	uniFRefP = (UnixFRef*)&xrefNum;
		errno = 0;
		if (fstat(uniFRefP->fd, &theStat) == -1)
			err = errno;
	}
	else
	{	errno = 0;
		if (lstat(fullPath, &theStat) == -1)
			err = errno;
	}
	if NOT(err)
		*modeP = theStat.st_mode;

return err;
}

//===========================================================================================
XErr	ChangeFileMode(XFileRef xrefNum, XFilePathPtr fullPath, long modeFlags)
{
XErr		err = noErr;
mode_t		mode = modeFlags;
UnixFRef	*uniFRefP;

	if (xrefNum)
	{	uniFRefP = (UnixFRef*)&xrefNum;
		errno = 0;
		if (fchmod(uniFRefP->fd, mode) == -1)
			err = errno;
	}
	else
	{	errno = 0;
		if (chmod(fullPath, mode) == -1)
			err = errno;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	LockXFile(XFileRef xrefNum, long start, long length, Boolean wait)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(start, length)
#endif
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
XErr		err = noErr;
int			flags;

	if (wait)
		flags = LOCK_EX;
	else
		flags = LOCK_EX + LOCK_NB;
	errno = 0;
	if (flock(uniFRefP->fd, flags) < 0)
		err = errno;
	

return err;
}

//===========================================================================================
XErr	UnlockXFile(XFileRef xrefNum, long start, long length)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(start, length)
#endif
UnixFRef	*uniFRefP = (UnixFRef*)&xrefNum;
XErr		err = noErr;
	
	errno = 0;
	if (flock(uniFRefP->fd, LOCK_UN) < 0)
		err = errno;
	

return err;
}

//===========================================================================================
/*static struct flock* file_lock(short type, short whence) 
{
    static struct flock ret ;
    ret.l_type = type ;
    ret.l_start = 0 ;
    ret.l_whence = whence ;
    ret.l_len = 0 ;
    ret.l_pid = getpid() ;
    return &ret ;
}*/

//===========================================================================================
// usa lsof (oppure si possono usare i lock, ma non o capito come!)
XErr	IsXFileOpen(XFilePathPtr fullPath, Boolean *isOpenP)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(fullPath, isOpenP)
#endif
XErr		err = noErr;
	
	err = XError(kXLibError, ErrNotImplementedInXLib);
	
/*char		command[512], result[512];		
	
	CEquStr(command, "lsof -Ff ");
	CAddChar(command, '\'');
	CAddStr(command, fullPath);
	CAddChar(command, '\'');
	*result = 0;
	Command(command, result);
	*isOpenP = (*result != 0);*/
	
return err;
}

//===========================================================================================
XErr	XIsFolder(XFilePathPtr fullPath, Boolean *isDirP)
{
XErr			err = noErr;
//int 			fd;
struct stat		theStat;
//struct tm		dc;

	ClearBlock(&theStat, sizeof(struct stat));
	errno = 0;
	if (lstat(fullPath, &theStat) != 0)
	{	err = errno;
		if (err == ENOENT)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}
	else
		*isDirP = S_ISDIR(theStat.st_mode);

return err;
}

//===========================================================================================
/*XErr	XIsAlias(XFilePathPtr filePath, Boolean *isAliasP)
{
XErr		err = noErr;
XFilePath	fullPath;
int			totChars;
CStr255		tempPath;
	
	if NOT(err = _GetUnixFullPath(filePath, fullPath))
	{	errno = 0;
		totChars = readlink(fullPath, tempPath, 255);
		if (totChars < 0)
		{	err = errno;
			if (err == EINVAL)
			{	err = noErr;
				*isAliasP = false;
			}
		}
		else
		{	tempPath[totChars] = 0;
			*isAliasP = CCompareStrings_cs(fullPath, tempPath);
		}
	} 

return err;
}*/

//===========================================================================================
XErr	XIsAlias(XFilePathPtr fullPath, Boolean *isAliasP)
{
XErr			err = noErr;
struct stat		theStat;
	
	errno = 0;
	if (lstat(fullPath, &theStat) < 0)
		err = errno;
	else
		*isAliasP = S_ISLNK(theStat.st_mode); 

return err;
}

//===========================================================================================
XErr	XResolveAlias(XFilePathPtr fullPath)
{
XErr		err = noErr;
//int			totChars;
	
	err = _ResolveXAlias(fullPath);
	/*errno = 0;
	totChars = readlink(fullPath, filePath, 255);
	if (totChars < 0)
	{	err = errno;
		if (err == EINVAL)
		{	err = noErr;
			CEquStr(filePath, fullPath);
		}
	}
	else
		filePath[totChars] = 0;
	*/


return err;
}

//===========================================================================================
XErr	XMakeAlias(XFilePathPtr fullPath, XFilePathPtr fullAliasPath)
{
XErr			err = noErr;
//long			curPos;
	
	errno = 0;
	if (symlink(fullPath, fullAliasPath) < 0)
		err = errno;
	if (err == EEXIST)
		err = XError(kXLibError, ErrXFiles_DuplicatedFile);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	CreateXFolder(XFilePathPtr fullPath)
{
XErr		err = noErr;
char		*strP;
int			fullPathLen;
XFilePath	tempStr;

	fullPathLen = CLen(fullPath);
	if (fullPath[--fullPathLen] == '/')
	{	CEquStr(tempStr, fullPath);
		tempStr[fullPathLen] = 0;
		strP = tempStr;
	}
	else
		strP = fullPath;
	errno = 0;
	if (mkdir(strP, S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH) < 0)
		err = errno;
	
return err;
}

//===========================================================================================
XErr	DeleteXFolder(XFilePathPtr fullPath)
{
XErr		err = noErr;

#ifdef __MACOSX__
{	
long	tLen = CLen(fullPath);
	
	if (fullPath[tLen-1] == '/')
		fullPath[tLen-1] = 0;
}
#endif
	errno = 0;
	if (rmdir(fullPath) < 0)
		err = errno;
	
return err;
}

//===========================================================================================
XErr	RenameXFolder(XFilePathPtr folderPath, char *newName)
{
XErr		err = noErr;
int			newPathLen, foldPathLen, res = 0;
CStr255		newPath;
char		*strP;

	CEquStr(newPath, folderPath);
	newPathLen = foldPathLen = CLen(newPath);
	if (newPath[newPathLen-1] == '/')
		newPath[newPathLen-1] = 0;
	strP = strrchr(newPath, '/')+1;
	if (strP)
		*strP = 0;
	CAddStr(newPath, newName);
	errno = noErr;
#ifdef __MACOSX__	
	if (folderPath[foldPathLen-1] == '/')
		folderPath[foldPathLen-1] = 0;
#endif
	XThreadsEnterCriticalSection();
	if (CheckPath(newPath, false) == noErr)
		err = XError(kXLibError, ErrXFiles_DuplicatedFile);
	else
	{	res = rename(folderPath, newPath);
		if (res < 0)
			err = errno;
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

#define WALK_MAX_DEPTH	12

#if	WITH_WALKFOLDER || WITH_OPENDIR
//===========================================================================================
/*static Boolean	_IsRightSuffix(XFilePathPtr fileName, char *theSuffix, Boolean onlyWithEmptySuffix)
{
int		fileNameLen, suffLen, ch1, ch2;
Byte	*chPtr, *suffPtr;

	suffLen = CLen(theSuffix);
	if ((suffLen == 1) && (*theSuffix == '*'))
		return true;
	else if NOT(CCompareStrings(theSuffix, "*.*"))
	{	if (strchr(fileName, '.'))
			return true;
		else
			return false;
	}
	else
	{	fileNameLen = CLen(fileName);
		chPtr = (Byte*)&fileName[fileNameLen-1];
		suffPtr = (Byte*)&theSuffix[suffLen-1];
		if (suffLen && (fileNameLen >= suffLen))
		{	do {
				ch1 = *chPtr--;
				ch2 = *suffPtr--;
				LOW_CHAR(ch1);
				LOW_CHAR(ch2);
				if (ch1 != ch2)
					return false;
			} while (--suffLen);
		}
		else if (onlyWithEmptySuffix)
		{	fileNameLen = CLen(fileName);
			do {
				if (*chPtr-- == '.')
					return false;
			} while (--fileNameLen);
			return true;
		}
		else
			return true;
	}
	
if (suffLen)
	return false;
else
	return true;
}*/
#endif

#if	WITH_WALKFOLDER // bugged: can't use global if called recursively in same thread

// Non so se � pericoloso, altrimenti non compila
/*#ifndef	FTW_PHYS
	#define	FTW_PHYS	1	// come in ftw.h if D__USE_XOPEN_EXTENDED
	typedef struct FTW
	  {
	    int base;
	    int level;
	  };
#endif
*/

//===========================================================================================
static int	_WalkCallBack(const char *path, const struct stat *statBuf, int flag, struct FTW *s)
{
XErr			err = noErr;
DirWalkRecP		tDirP = &gDirWalkRec;
long			variant = 0;
int				savePathLen, removed, pathLen, oldChar, ch;
char			*strP, *realPathP;
CStr255			realPath;
long			level = s->level;

	if (NOT(tDirP->recursive) && (level > 1))
		return 0;

	pathLen = CLen(path);
	if ((pathLen == tDirP->initialPathLength-1) && NOT(CompareBlock((char*)path, tDirP->initialPath, tDirP->initialPathLength-1)))
		return noErr;
	
	if (pathLen)
	{	savePathLen = pathLen;
		strP = (char*)path;
		realPathP = realPath;
		oldChar = removed = 0;
		do {
			ch = *strP;
			if ((ch == '/') && (oldChar == '/'))
				removed++;
			else
				*realPathP++ = ch;
			oldChar = ch;
			strP++;
			pathLen--;
		} while (pathLen > 0);
		realPath[savePathLen - removed] = 0;
	}
	switch (flag)
	{
		case FTW_F:		// file
			if NOT(strP = strrchr(realPath, '/'))
				strP = realPath;
			if (WFFilter(strP, tDirP->suffix/*, tDirP->onlyWithEmptySuffix*/))
			{	if (S_ISREG(statBuf->st_mode))
					err = tDirP->callBack(realPath, variant, tDirP->userData);
			}
			break;
		case FTW_D:		// dir
		case FTW_DNR:	// directory non leggibile:
			variant |= kPathIsFolder;
			CAddChar(realPath, '/');
			err = tDirP->callBack(realPath, variant, tDirP->userData);
			break;
		case FTW_SL:	// sym link
			variant |= kPathIsAlias;
			err = tDirP->callBack((XFilePathPtr)path, variant, tDirP->userData);
			break;
		case FTW_NS:	// file nessuno stato disponibile
			if NOT(strP = strrchr(realPath, '/'))
				strP = realPath;
			if (WFFilter(strP, tDirP->suffix/*, tDirP->onlyWithEmptySuffix*/))
			{	if (*(strP+1) != '.')
					err = tDirP->callBack(realPath, variant, tDirP->userData);
			}
			break;
	}

return err;
}

//===========================================================================================
// use global (gDirWalkRec) 
XErr	WalkXFolder(XFilePathPtr fullPath, char *suffix, Boolean recursive, 
											WalkXFolderCallBack callBack, long userData)
{
XErr			err = noErr;
int				flags = 0;		// vedi man di nftw per queste flags
int				depth;
DirWalkRecP		tDirP;
	
	XThreadsEnterCriticalSection();
	tDirP = &gDirWalkRec;
	tDirP->callBack = callBack;
	tDirP->userData = userData;
	if (suffix)
	{	CEquStr(tDirP->suffix, suffix);
		//tDirP->onlyWithEmptySuffix = true;
	}
	else
	{	*tDirP->suffix = 0;			// suffix is "", want files with empty suffix
		//tDirP->onlyWithEmptySuffix = false;
	}
	depth = WALK_MAX_DEPTH;
	flags = FTW_PHYS;
	tDirP->initialPathLength = CLen(fullPath);
	tDirP->recursive = recursive;
	CEquStr(tDirP->initialPath, fullPath);
	err = nftw(fullPath, _WalkCallBack, depth, flags);
	if (err == -1)
		err = XError(kXLibError, ErrXFiles_FileNotFound);		
	if (err == XError(kXLibError, ErrXFiles_WalkFolderAbort))
		err = noErr;
	XThreadsLeaveCriticalSection();
	
return err;
}
#elif WITH_OPENDIR
// open dir
#include <dirent.h>
//===========================================================================================
static XErr	_WalkXFolderLow(XFilePathPtr fullPath, char *suffix, Boolean recursive, WalkXFolderCallBack callBack, long userData)
{
XErr			err = noErr;
DIR 			*dirh;
struct dirent 	*dirp;
struct stat 	statBuf;
long			d_namlen, initialPathLength, variant;
//Boolean			onlyWithEmptySuffix;
CStr255			initialPath;
CStr31			thesuffix;
char			*nameP;
XFilePath		realPath;

	XThreadsEnterCriticalSection();
	WFPrepareFilter(suffix, thesuffix);
	/*if (suffix)
	{	CEquStr(thesuffix, suffix);
		//onlyWithEmptySuffix = true;
	}
	else
	{	*thesuffix = 0;
		//onlyWithEmptySuffix = false;
	}*/
	initialPathLength = CLen(fullPath);
	CEquStr(initialPath, fullPath);
	if (initialPath[initialPathLength-1] != '/')
	{	CAddChar(initialPath, '/');
		initialPathLength++;
	}
	errno = noErr;
	if ((dirh = opendir(fullPath)) == NULL)
	{	err = errno;
		goto out;
	}

	errno = noErr;
	for (dirp = readdir(dirh); (dirp != NULL) && NOT(err); dirp = readdir(dirh))
	{	nameP = dirp->d_name;
	#if __MACOSX__
		d_namlen = dirp->d_namlen;
	#else
		d_namlen = CLen(nameP);		// on linux "d_namlen" is not a field of "dirent"
	#endif
		if (d_namlen && (*nameP == '.'))
		 	continue;
		CEquStr(realPath, initialPath);
		CAddStr(realPath, nameP);
		errno = noErr;
		if (lstat(realPath,&statBuf) == 0)
		{	variant = 0;
			if (S_ISLNK(statBuf.st_mode))
			{	variant |= kPathIsAlias;
				if (WFFilter(realPath, thesuffix))
					err = callBack(realPath, variant, userData);
			}
			else if(statBuf.st_mode & S_IFDIR)	// Is Folder
			{	variant |= kPathIsFolder;
				CAddChar(realPath, '/');
				err = callBack(realPath, variant, userData);
				if (NOT(err) && recursive)
					err = _WalkXFolderLow(realPath, suffix, recursive, callBack, userData);
			}
			else
			{	if (WFFilter(realPath, thesuffix))
				{	if (S_ISREG(statBuf.st_mode))
						err = callBack(realPath, variant, userData);
				}
			}
		}
		else
			break;
	}
	if NOT(err)
		err = errno;

closedir(dirh);
out:
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	WalkXFolder(XFilePathPtr fullPath, char *suffix, Boolean recursive, WalkXFolderCallBack callBack, long userData)
{
XErr			err = noErr;

	err = _WalkXFolderLow(fullPath, suffix, recursive, callBack, userData);
	if (err == XError(kXLibError, ErrXFiles_WalkFolderAbort))
		err = noErr;
	
return err;
}
#else
//===========================================================================================
XErr	WalkXFolder(XFilePathPtr fullPath, char *suffix, Boolean recursive, WalkXFolderCallBack callBack, long userData)
{
	return XError(kXLibError, ErrNotImplementedInXLib);
}
#endif
//===========================================================================================
XErr	GetXApplicationCurrentDir(XFilePathPtr xAppCurrentDir)
{
//CStr255		aCStr;
XErr		err = noErr;

	errno = 0;
	if (getcwd(xAppCurrentDir, 255))
		CAddChar(xAppCurrentDir, '/');
	else
		err = errno;	// ERANGE => 255 not enough
	
return err;
}

//===========================================================================================
/*static XErr	_ResolveOne(XFilePathPtr tempPath, XFilePathPtr strP, long *totAliasP)
{
XErr		err = noErr;
Boolean		isAlias;
CStr255		realPath;
//int			totChars;
CStr255		aCStr;
Ptr			p;

	if (strP)
		*strP = 0;
	if NOT(err = XIsAlias(tempPath, &isAlias))
	{	if (isAlias)
		{	(*totAliasP)++;
			if NOT(err = _ResolveXAlias(tempPath))
			{	CEquStr(realPath, tempPath);
				if (*realPath != '/')
				{	CEquStr(aCStr, tempPath);
					if (p = strrchr(aCStr, '/'))
						*(p+1) = 0;
					CAddStr(aCStr, realPath);
					CEquStr(realPath, aCStr);
				}
				if (strP)
				{	*strP = '/';
					CEquStr(aCStr, strP);
				}
				else
					*aCStr = 0;
				CEquStr(tempPath, realPath);
				CAddStr(tempPath, aCStr);
			}
		}
		else if (strP)
			*strP = '/';
	}

return err;
}*/

//===========================================================================================
/*
This must:
	- interpret /../
	- resolve folder alias of the path
	- if (resolveAlias == true): resolve alias of the name of the path
	- return ErrXFiles_FileNotFound if path is ok dut name doesn't exists
	- return ErrXFiles_FolderNotFound if path is not ok (apart from name of file)
*/
/*static XErr	exCheckPath(XFilePathPtr fullPath, Boolean resolveAlias)
{
XErr			err = noErr;//, saveErr = noErr;
struct stat		theStat;
//Boolean			isAlias, isDir = false;
XFilePath		tempPath;
//char			*strP;
//long			totAlias = 0;
char			*strP, *nextCharP;
int				res;

	ClearBlock(&theStat, sizeof(struct stat));
	errno = 0;
	if (resolveAlias)
	{	res = stat(fullPath, &theStat);
		if (res >= 0)
			err = _ResolveXAlias(fullPath);
	}
	else
		res = lstat(fullPath, &theStat);
	if (res < 0)
		err = errno;
	if (err == ENOENT)
	{	CEquStr(tempPath, fullPath);
		if (strP = strrchr(tempPath, '/'))
		{	nextCharP = strP+1;
			if (*nextCharP == 0)
				err = XError(kXLibError, ErrXFiles_FolderNotFound);
			else
			{	*nextCharP = 0;
				errno = 0;
				if (resolveAlias)
					res = stat(tempPath, &theStat);
				else
					res = lstat(tempPath, &theStat);
				if (res < 0)
					err = XError(kXLibError, ErrXFiles_FolderNotFound);
				else
					err = XError(kXLibError, ErrXFiles_FileNotFound);
			}
		}
	}
	
return err;
}*/

//===========================================================================================
/*
This must:
	- interpret /../
	- resolve folder alias of the path
	- if (resolveAlias == true): resolve alias of the name of the path
	- return ErrXFiles_FileNotFound if path is ok dut name doesn't exists
	- return ErrXFiles_FolderNotFound if path is not ok (apart from name of file)
*/
XErr	CheckPath(XFilePathPtr fullPath, Boolean resolveAlias)
{
XErr			err = noErr;
struct stat		theStat;
char			*strP;
int				pathLen, res;
XFilePath		path;
Boolean			wasSlash;
CStr255			saveName;
char			tempPath[MAXPATHLEN];

	if NOT(pathLen = CEquStr(path, fullPath))
		return XError(kXLibError, ErrXFiles_FileNotFound);
	strP = &path[pathLen-1];
	if (*strP == '/')
	{	*strP = 0;
		wasSlash = true;
	}
	else
		wasSlash = false;
	if NOT(resolveAlias)
	{	// get the path without name
		if (strP = strrchr(path, '/'))
		{	strP++;						// start after /
			CEquStr(saveName, strP);	// save the name
			*strP++ = '.';				// dont resolve last part
			*strP = 0;
		}
		else
			err = XError(kXLibError, ErrXFiles_FileNotFound);
	}
	if NOT(err)
	{	errno = 0;
		if NOT(realpath(path, tempPath))
			err = errno;
		if (err)
		{	if (err == ENOENT)
			{	
			/*#if __MACOSX__
				err = XError(kXLibError, ErrXFiles_FolderNotFound);
			#else*/
				if NOT(CCompareStrings_cs(path, tempPath))		// Error was on last component?
					err = noErr;
				else
					err = XError(kXLibError, ErrXFiles_FolderNotFound);
			//#endif
			}
		}
		if NOT(err)
		{	if NOT(resolveAlias)
			{	CAddChar(tempPath, '/');
				CAddStr(tempPath, saveName);
			}
			// file exists?
			errno = 0;
			if (resolveAlias)
				res = stat(tempPath, &theStat);
			else
				res = lstat(tempPath, &theStat);
			if (res < 0)
				err = errno;
			if (wasSlash)
			{	CAddChar(tempPath, '/');
				// if the path ends with '/' (slash) and it is not a folder -> error
				if (err || NOT(S_ISDIR(theStat.st_mode)))
					err = XError(kXLibError, ErrXFiles_FolderNotFound);
			}
			else if (err)
				err = XError(kXLibError, ErrXFiles_FileNotFound);
			CEquStr(fullPath, tempPath);
		}
	}
		
return err;
}

//===========================================================================================
XErr	XGetExtensionsFolderPath(XFilePathPtr extensionsPath)
{
	// UNIX Extension Folder is determined by var *PATH
	*extensionsPath = 0;

return noErr;
}
