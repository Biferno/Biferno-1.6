/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XUnix.c,v 1.14 2006-05-30 14:53:51 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"
#include "XThreadsPrivate.h"

#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>

CStr255				gSysString, gFragLocator_u_onDisk_path;
unsigned long		gTotalApplicationMemory;
long				gXLibNewThread, gThreads;
Boolean				gAbortThreads, gExitForced;
size_t				gUnixStackSize;
unsigned long		gMainThreadID;

//===========================================================================================
static void	_Command(char *command, char *resultStr)
{
FILE		*p;
size_t		size;
CStr255		errorStr;
	
	*resultStr = 0;
	*errorStr = 0;
//#ifdef __UNIX_XLIB__
	XThreadsEnterCriticalSection();
	errno = 0;
	if (p = popen(command, "r"))
	{	size = fread(resultStr, 1, 250, p);
		if (size > 0)
			resultStr[size-1] = 0;	// per il \n finale
		else if (size < 0)
			sprintf(errorStr, "Error on fread(): %d (%s)", ferror(p), strerror(ferror(p)));
		if (pclose(p) && ferror(p))
			sprintf(errorStr, "Error on pclose(): %s", strerror(ferror(p)));
	}
	else
		sprintf(errorStr, "Error on popen(): %s", strerror(errno));
	XThreadsLeaveCriticalSection();	
//#endif	
}

XErr	XCommonInit(void);
XErr	XMemoryInit(void);
XErr	XMemoryEnd(void);
XErr	XCommonEnd(void);

#define	kUNIX_THREADS_STACK_SIZE		(1024L * 512L)		// 512 K

//===========================================================================================
static XErr _GetStackSize(size_t *tsizeP)
{
XErr			err = noErr;
#ifdef CAN_USE_POSIX_THREADS
pthread_attr_t	tattr; 

	if NOT(err = pthread_attr_init(&tattr))
		err = pthread_attr_getstacksize(&tattr, tsizeP);

#else
	*tsizeP = kUNIX_THREADS_STACK_SIZE;
#endif
return err;
}

//===========================================================================================
XErr	XInit(XFilePathPtr applicationPath)
{
XErr				err = noErr;
//struct	timeval		tv;
//void 				*libjvm;
//char				*s;
//CStr255				libJVMPath;
#ifndef __XLIB_CLIENT__
	char 				cName[] = "intl";
	unsigned long		ourID;
#endif
CStr255				cwDir;
	
#if __MACOSX__	&& CAN_USE_POSIX_THREADS && !__XLIB_CLIENT__
	if (err = InitRecursiveMutex())
		return err;
#endif

#ifndef __XLIB_CLIENT__
	if (err = XCommonInit())
		return err;
#endif

	gTotalApplicationMemory = 0;
	gXLibNewThread = 0;
	gAbortThreads = false;
	gExitForced = false;
	
	XInitGetTicks();
	
	if (_GetStackSize(&gUnixStackSize))
		gUnixStackSize = kUNIX_THREADS_STACK_SIZE;
	
/*#ifdef JAVA_ENABLED
	err = Init_JVM();
	if NOT(err)
		gJavaOK = true;
	else
	{	gJavaOK = false;
		err = noErr;
	}
#endif*/

	//gNConnection = 0;
	if NOT(err = XMemoryInit())
	{
	#if CHECK_LEAKING
		InitMemoryLeakingMgr();
	#endif

		if (applicationPath)
		{	CEquStr(gFragLocator_u_onDisk_path, applicationPath);
			if (applicationPath[CLen(applicationPath) - 1] != '/')
				CAddChar(gFragLocator_u_onDisk_path, '/');
		}
		else
		{	if (getcwd(cwDir, 255))
			{	CAddChar(cwDir, '/');
				CEquStr(gFragLocator_u_onDisk_path, cwDir);
			}
			else
				err = errno;
		}
	}
	

#ifdef __XLIB_WITH_HELPERS__
	if NOT(err)
		err = InitHelpers();
#endif

#ifndef __XLIB_CLIENT__
	if NOT(err)
	{	XGetCurrentThread(&ourID);
		gMainThreadID = ourID;
		if NOT(ourID)
			CDebugStr("Thread id in XInit is 0!");
		if (err = _XThreadsNewTLS(ourID, (long)&cName, gUnixStackSize))
			return err;
		gThreads = 0;
	}
#endif
	
	gXLibNewThread = XThreadsCreateSemaphore(_GREEN, &err);

	_Command("uname -a", gSysString);
	/*
	debug
	{
	XFileRef	xrefNum;
	long		tLen;
	CStr63		aCStr;
	
	OpenXFile("/Users/biferno/bug.valerio", CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &xrefNum);
	
	CNumToString(gXLibNewThread, aCStr);
	tLen = CLen(aCStr);
	WriteXFile(xrefNum, aCStr, &tLen);
	
	CEquStr(aCStr, "*");
	tLen = CLen(aCStr);
	WriteXFile(xrefNum, aCStr, &tLen);
	
	CNumToString(err, aCStr);
	tLen = CLen(aCStr);
	WriteXFile(xrefNum, aCStr, &tLen);
	
	CloseXFile(&xrefNum);
	}
	*/
	
return err;
}

//===========================================================================================
XErr	XEnd(long threadsToRemain)
{
XErr			err = noErr;
unsigned long	ourID;
	
	XThreadsStopThreads(threadsToRemain);
	
	XGetCurrentThread(&ourID);
#ifndef __XLIB_CLIENT__
	_XThreadsDisposeTLS(ourID, nil);
	_XThreadsCloseTLSSystem();
#endif
	
	// mai XThreadsCloseSemaphore(gXLibNewThread);
	
#ifdef __XLIB_WITH_HELPERS__
	err = EndHelpers();
#endif
	
	err = XMemoryEnd();
		
/*#ifdef JAVA_ENABLED
	if (gJavaOK)
		err = End_JVM();
#endif*/

#ifndef __XLIB_CLIENT__
	err = XCommonEnd();
#endif

//#ifdef JAVA_ENABLED
#ifdef __XLIB_WITH_HELPERS__
	XLibEnd_JVM_API();
#endif
//#endif
return err;
}
