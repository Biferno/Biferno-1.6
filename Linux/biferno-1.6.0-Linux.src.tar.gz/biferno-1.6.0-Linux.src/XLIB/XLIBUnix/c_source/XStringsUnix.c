/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XStringsUnix.c,v 1.3 2005-11-07 15:37:38 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>

// Special Characters (If are not on Unix you see WRONG chars!!)
// Note: Lower are Upper + 31 (Until 62)
/*Byte	isoChar[] = {	
'�',	'�',	'�',	'�',	'�',
'�',	'�',	'�',	'�',	'�',
'�',	'�',	'�',	'�',	'�',
'�',	'�',	'�',	'�',	'�',
'�',	'�',	'�',	'�',	'�',	
'�',	'�',	'�',	'�',	'�',	
'�',	'�',	'�',	'�',	'�',
'�',	'�',	'�',	'�',	'�',	
'�',	'�',	'�',	'�',	'�',	
'�',	'�',	'�',	'�',	'�',	
'�',	'�',	'�',	'�',	'�',
'�',	'�',	'�',	'�',	'�',	
'�',	'�',	' ',	'e',	'&',
'"',	'>',	'<'	,	162,	169,
164,	176,	247,	171,	181,
172,	186,	170,	182,	177,
163,	187,	174,	167,	173
// l'ultima e sarebbe l'euro, ma non so editarlo su Linux
};
*/
//===========================================================================================
int			GetSeparators(Byte *theDecSep, Byte *theThousSep, char *sepDate, char *sepTime)
{
char		*langP;
int			dateOrder;
CStr255		lang;

	if (langP = getenv("LANG"))
		CEquStr(lang, langP);
	else
		*lang = 0;
	
	// Italy
	if NOT(CCompareStrings(lang, "it_IT"))
	{	if (theDecSep)
			*theDecSep = ',';
		if (theThousSep)
			*theThousSep = '.';
		if (sepDate)
			CEquStr(sepDate, "-");
		if (sepTime)
			CEquStr(sepTime, ":");
		dateOrder = _DMY;
	}
	else	// otherwise USA
	{	if (theDecSep)
			*theDecSep = '.';
		if (theThousSep)
			*theThousSep = ',';
		if (sepDate)
			CEquStr(sepDate, "/");
		if (sepTime)
			CEquStr(sepTime, ":");
		dateOrder = _MDY;
	}
	
return dateOrder;
}
#if __MWERKS__
#pragma mark-
#endif

//============================================================
static void	_StringToLog(char *stringMessage)
{
CStr255	msgStr;

	// openlog("Biferno", LOG_PID, LOG_USER);					su CW non compila
	// syslog(LOG_ERR, "%s (errno: %m)\n", stringMessage);		su CW non compila
	// closelog();												su CW non compila
	CEquStr(msgStr, stringMessage);
	CAddStr(msgStr, "\n");
	System_EnterCS();
	printf(msgStr);
#ifdef ON_ERROR_EXIT
	{
	Ptr	p = 0;

	*p = 0;				// to dump core and abort process
	// ex exit(1);
	}
#endif
	System_LeaveCS();
	
	/*
	*p = 0;				// per fargli dumpare il core!
	printf("--------------------------------------------------exiting _StringToLog\n");
	exit(0);
	*/
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void		PNumToString(long num, StringPtr str)
{
CStr255		cStr;
	
	System_EnterCS();
	sprintf(cStr, "%ld", num);
	CToPascal(cStr, str);
	System_LeaveCS();
}

//===========================================================================================
void		PStringToNum(StringPtr str, long *numP)
{
CStr255		cStr;

	System_EnterCS();
	PascalToC(str, cStr);
	*numP = atoi(cStr);
	System_LeaveCS();
}

//===========================================================================================
void 		PRealToStr(double *d, StringPtr sP, short digits)
{
CStr255		cStr;
CStr15		formatStr;
Str15		digStr;
	
	CEquStr(formatStr, "%.");
	PNumToString(digits, digStr);
	AddPascalToCStr(formatStr, digStr);
	CAddStr(formatStr, "f");
	System_EnterCS();
	sprintf(cStr, formatStr, d);
	System_LeaveCS();
	CToPascal(cStr, sP);
}

//===========================================================================================
/*double 		PStrToReal(const StringPtr sP)
{
CStr255		cStr;
double		res;

	PascalToC(sP, cStr);
	res = atof(cStr);

return res;
}*/
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
void		CNumToString(long num, char *str)
{
	System_EnterCS();
	sprintf(str, "%ld", num);
	System_LeaveCS();
}

//===========================================================================================
void		CStringToNum(char *str, long *numP)
{
	System_EnterCS();
	*numP = atoi(str);
	System_LeaveCS();
}

//===========================================================================================
void 		CRealToStr(double *d, char *sP, short digits)
{
CStr15		formatStr;
Str15		digStr;
	
	CEquStr(formatStr, "%.");
	PNumToString(digits, digStr);
	AddPascalToCStr(formatStr, digStr);
	CAddStr(formatStr, "f");
	System_EnterCS();
	sprintf(sP, formatStr, *d);
	System_LeaveCS();
}

//===========================================================================================
/*double 		CStrToReal(const char *sP)
{
double		res;

	System_EnterCS();
	res = atof(sP);
	System_LeaveCS();

return res;
}
*/
#if __MWERKS__
#pragma mark-
#endif
//============================================================
void	PDebugStr(StringPtr	stringMessage)
{
CStr255	cStr;

	PascalToC(stringMessage, cStr);
	_StringToLog(cStr);
}

//============================================================
void	CDebugStr(char	*stringMessage)
{
	_StringToLog(stringMessage);
}
