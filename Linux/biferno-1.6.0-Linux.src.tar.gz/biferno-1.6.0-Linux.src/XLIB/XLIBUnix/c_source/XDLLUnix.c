/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XDLLUnix.c,v 1.10 2005-11-07 16:10:31 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XFilesUnixPrivate.h"
#include "XLibPrivate.h"

#ifdef __MACOSX__
	//#include <Carbon/Carbon.h>
	//#include <CoreServices/CoreServices.h>
	//#include <CoreFoundation/CoreFoundation.h>
	//#include <CFBundle.h>
	
	#include <mach-o/dyld.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include </usr/include/string.h>
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <stdarg.h>
	#include <limits.h>
	#include <mach-o/dyld.h>
	#include <mach-o/nlist.h>
#else
	#include <fcntl.h>
	#include <dlfcn.h>
#endif
#include <unistd.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

//extern CStr255		globalErrStr;

#ifdef __MACOSX__

typedef struct {
	const struct mach_header		*macHeader;
	NSModule 						handle;
} MacOSXDllRec;

#ifndef PATH_MAX
	#define	PATH_MAX	255
#endif

#define MAX_SEARCH_PATHS	32
static const char * safegetenv(const char * s)
{
	const char * ss = getenv(s);
	return ss? ss : "";
}

//===========================================================================================
static const char *searchList(void)
{
	char * buf;
	const char * ldlp = safegetenv("LD_LIBRARY_PATH");
	const char * dyldlp = safegetenv("DYLD_LIBRARY_PATH");
	size_t	buf_size = strlen(ldlp) + strlen(dyldlp) + 40;
	buf = malloc(buf_size);
	snprintf(buf, buf_size, "%s:%s:/usr/lib:/lib:/sw/lib:/sw/mysql/lib", dyldlp, ldlp);
	return buf;
}

//===========================================================================================
static const char * getSearchPath(int i)
{
	static const char * list = 0;
	static const char * path[MAX_SEARCH_PATHS] = {0};
	static int end = 0;
	if (!list && !end) 
		list = searchList();
	while (!path[i] && !end) 
	{
		path[i] = strsep((char**)&list, ":");
		if (path[i][0] == 0)
			path[i] = 0;
		end = list == 0;
	}
	return path[i];
}

//===========================================================================================
static const char * getFullPath(int i, const char * file)
{
	static char buf[PATH_MAX];
	const char * path = getSearchPath(i);
	if (path)
		snprintf(buf, PATH_MAX, "%s/%s", path, file);
	return path? buf : 0;
}

//===========================================================================================
static const struct stat * findFile(const char * file, const char ** fullPath)
{
	int i = 0;
	static struct stat sbuf;
	//debug("finding file %s",file);
	*fullPath = file;
	do
	{
		if (0 == stat(*fullPath, &sbuf))
			return &sbuf;
	}
	while ((*fullPath = getFullPath(i++, file)));
	return 0;
}
#endif
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	XLoadDLL(XFilePathPtr dllPath, long *dllRef, char *errString, long *xlibVersion, Boolean macosxBundle)
{
XErr	err = noErr;
void	*dllHandle = nil;

	if (errString)
		*errString = 0;

#ifdef __MACOSX__
#if __USE_CARBON_FRAMEWORK__
	if (macosxBundle)
	{	if NOT(err = Bundle_Load((long)dllPath))
			dllHandle = (void*)dllPath;
	}
	else
#endif
	{
	int					res;
	NSObjectFileImage 	image;
	CStr255				tempStr;
	MacOSXDllRec		*dlXRefP = nil;
	const struct stat 	*sbuf;
	const char 			*fullPath;
	const char 			*path = (const char *)&dllPath[0];
	Boolean				checkLinkErr = false;
	
		if (dlXRefP = calloc(1, sizeof(MacOSXDllRec)))
		{	if (sbuf = findFile(path, &fullPath))
				CEquStr(tempStr, (char *)fullPath);
			else
				CEquStr(tempStr, dllPath);
			res = NSCreateObjectFileImageFromFile(tempStr, &image);
			if (res == NSObjectFileImageInappropriateFile)
			{	if NOT(dlXRefP->macHeader = NSAddImage(tempStr, NSADDIMAGE_OPTION_RETURN_ON_ERROR))
					err = XError(kXLibError, ErrXDLLCantLoadObject);
			}
			else if (res == NSObjectFileImageSuccess)
			{	if (dlXRefP->handle = NSLinkModule(image, tempStr, NSLINKMODULE_OPTION_PRIVATE | /*NSLINKMODULE_OPTION_BINDNOW | */NSLINKMODULE_OPTION_RETURN_ON_ERROR))
					NSDestroyObjectFileImage(image);
				else
				{	err = XError(kXLibError, ErrXDLLCantLoadObject);
					checkLinkErr = true;
				}
			}
			else
				err = XError(kXLibError, ErrXDLLCantLoadObject);
			if (err)
			{	if (checkLinkErr)
				{	
				NSLinkEditErrors	c;
				int					e, strPLen;
				const char 			*fileName;
				const char 			*errorString;
		
					NSLinkEditError(&c, &e, &fileName, &errorString);
					strPLen = CLen(errorString);
					if (strPLen > 255)
					{	CopyBlock(errString, (void*)errorString, 252);
						errString[252] = '.';
						errString[253] = '.';
						errString[254] = '.';
						errString[255] = 0;
					}
					else
						CEquStr(errString, (char*)errorString);
					if NOT(err = e)
						err = XError(kXLibError, ErrXDLLCantLoadObject);
				}
				else
					err = XError(kXLibError, ErrXDLLCantLoadObject);
				if NOT(*errString)
				{	switch(res)
					{   case NSObjectFileImageFailure:
							CEquStr(errString, "NSObjectFileImageFailure");
							break;
						case NSObjectFileImageSuccess:
							CEquStr(errString, "NSObjectFileImageSuccess");
							break;
						case NSObjectFileImageInappropriateFile:
							CEquStr(errString, "NSObjectFileImageInappropriateFile");
							break;
						case NSObjectFileImageArch:
							CEquStr(errString, "NSObjectFileImageArch");
							break;
						case NSObjectFileImageFormat:
							CEquStr(errString, "NSObjectFileImageFormat");
							break;
						case NSObjectFileImageAccess:
							CEquStr(errString, "NSObjectFileImageAccess");
							break;
					}
				}
			}
			if (err)
				free(dlXRefP);
			else
				dllHandle = (void*)dlXRefP;
		}
		else
			err = XError(kXLibError, ErrXMemory_Full);
	}
#else
	dlerror();		// clean error
	errno = noErr;
	if NOT(dllHandle = dlopen(dllPath, RTLD_LAZY))
	{	if (errno)
			err = errno;
		else
			err = XError(kXLibError, ErrXDLLCantLoadObject);
		if (errString)
			sprintf(errString, "%s", dlerror());
	}
#endif

	if NOT(err)
	{	*dllRef = (long)dllHandle;
		if (xlibVersion)
			err = RegisterDllXLib((long)dllHandle, errString, xlibVersion, macosxBundle);
	}
	else
	{	if (errString)
		{	CAddStr(errString, " (while looking for: ");
			CAddStr(errString, dllPath);
			CAddStr(errString, ")");
		}
	}
	
return err;
}

//===========================================================================================
XErr	XGetDLLSymbol(long dllRef, char *entryPointSymbol, long *entryPointP, Boolean macosxBundle)
{
XErr	err = noErr;

#ifdef __MACOSX__
NSSymbol 		symbol;
char 			*symname2;
MacOSXDllRec	*dlXRefP = (MacOSXDllRec*)dllRef;
    
#if __USE_CARBON_FRAMEWORK__
	if (macosxBundle)
		err = Bundle_GetSymbol(dllRef, entryPointSymbol, entryPointP);
	else
#elif __C_HAS_PRAGMA_UNUSED__
	#pragma unused(macosxBundle)
#endif
	{
		symname2 = (char*)malloc(sizeof(char)*(strlen(entryPointSymbol)+2));
		sprintf(symname2, "_%s", entryPointSymbol);
		if (dlXRefP->handle)
			symbol = NSLookupSymbolInModule(dlXRefP->handle, symname2);
		else
			symbol = NSLookupSymbolInImage(dlXRefP->macHeader, symname2, NSLOOKUPSYMBOLINIMAGE_OPTION_RETURN_ON_ERROR);
		if (symbol)
		{	if NOT(*entryPointP = (long)NSAddressOfSymbol(symbol))
				err = XError(kXLibError, ErrXDLLCantFindSymbol);
		}
		else
			err = XError(kXLibError, ErrXDLLCantFindSymbol);
		free(symname2);
	}
#else
	dlerror();		// clean error
	errno = noErr;
	if NOT(*entryPointP = (long)dlsym((void*)dllRef, entryPointSymbol))
	{	if (errno)
			err = errno;
		else
			err = XError(kXLibError, ErrXDLLCantFindSymbol);
	}
#endif
	
return err;
}

//===========================================================================================
XErr	XFreeDLL(long *dllRef, Boolean macosxBundle)
{
XErr	err = noErr;

#ifdef __MACOSX__
#if __USE_CARBON_FRAMEWORK__
	if (macosxBundle)
		Bundle_Unload(*dllRef);
	else
#elif __C_HAS_PRAGMA_UNUSED__
	#pragma unused(macosxBundle)
#endif
	{
		MacOSXDllRec	*dlXRefP = (MacOSXDllRec*)*dllRef;
	
		if (dlXRefP->handle)
			err = NSUnLinkModule(dlXRefP->handle, NSUNLINKMODULE_OPTION_RESET_LAZY_REFERENCES);
		free(dlXRefP);
	}
#else
	dlerror();		// clean error
	errno = noErr;
	dlclose((void*)*dllRef);
	if (dlerror())
	{	if (errno)
			err = errno;
		else
			err = XError(kXLibError, ErrXDLLCantCloseObject);
	}
#endif
	
return err;
}
