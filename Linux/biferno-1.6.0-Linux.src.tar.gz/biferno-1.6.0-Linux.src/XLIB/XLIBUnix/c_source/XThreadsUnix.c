/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XThreadsUnix.c,v 1.15 2008-09-10 11:57:40 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __XLIB_CLIENT__

#include "XLib.h"
#include "XThreadsPrivate.h"

#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <syslog.h>
#include <signal.h>
#include <stdlib.h>
#ifndef __MACOSX__
	#include <malloc.h>
#endif

#ifdef __MACOSX__
	#include <mach/semaphore.h>
#else
	#include <semaphore.h>
#endif
#include <pthread.h>

#ifdef CAN_USE_POSIX_THREADS
	#include <pthread.h>
	#ifdef __MACOSX__
		#include <mach/sync_policy.h>
		static pthread_mutex_t		gMutex;
	#else
		static pthread_mutex_t		gMutex = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
	#endif
	static Boolean				gIsChild = false;
#else
	static	int gThreadsID = 1;
#endif

#define	kTryInterval		1000L


#if defined(__GNU_LIBRARY_) && !defined(_SEM_SEMUN_IUNDEFINED)
	/* union defined in sys/sem.h*/
#else
	union semun {
		int					vale;		// value for SETVAL
		struct semid_ds		*buf;		// buffer for IPC_STAT, IPC_SET
		unsigned short int	*array;		// array for GET_ALL, SET_ALL
		struct seminfo		*__buf;		// buffer for IPC_INFO
		};
#endif

typedef struct {
				void		*args;
				Boolean		toDetach;
				Byte		pad1;
				short		pad2;
				void* 		(*func)(void*);
				} EntryPRec;

//extern	long			gThreads;
extern	long			gXLibNewThread;
extern	size_t			gUnixStackSize;

#if __MACOSX__ && CAN_USE_POSIX_THREADS
#include "XFilesUnixPrivate.h"
//===========================================================================================
XErr	InitRecursiveMutex(void)
{
pthread_mutexattr_t		mutex_attr;
int						result;

	errno = noErr;
	if (result = pthread_mutexattr_init(&mutex_attr))
		return errno;
	errno = noErr;
	if (result = pthread_mutexattr_settype(&mutex_attr, PTHREAD_MUTEX_RECURSIVE))
		return errno;
	errno = noErr;
	if (result = pthread_mutex_init(&gMutex, &mutex_attr))
		return errno;

return 0;
}
#endif

//===========================================================================================
static void	_EnterCriticalSection(Boolean checkLocks)
{
#if (!CHECK_LEAKING || !CAN_USE_POSIX_THREADS) && __C_HAS_PRAGMA_UNUSED__
	#pragma unused(checkLocks)
#endif
#if CAN_USE_POSIX_THREADS
	if (gIsChild)
	{	
		pthread_mutex_lock(&gMutex);
		//printf("_EnterCriticalSection\n");
	#if CHECK_LEAKING
		if (checkLocks)
			_OneMoreLock();
	#endif
	}
#endif
}
//===========================================================================================
static void	_LeaveCriticalSection(Boolean checkLocks)
{
#if (!CHECK_LEAKING || !CAN_USE_POSIX_THREADS) && __C_HAS_PRAGMA_UNUSED__
	#pragma unused(checkLocks)
#endif
#if CAN_USE_POSIX_THREADS
	if (gIsChild)
	{
	#if CHECK_LEAKING
		if (checkLocks)
			_OneLessLock();
	#endif
		//printf("_LeaveCriticalSection\n");
		pthread_mutex_unlock(&gMutex);
	}
#endif
}

//===========================================================================================
void	__XThreadsEnterCriticalSection(void)
{
	_EnterCriticalSection(false);
}
//===========================================================================================
void	__XThreadsLeaveCriticalSection(void)
{
	_LeaveCriticalSection(false);
}

//===========================================================================================
/*static void	_DebugSemaphore(sem_t *semaphoreP)
{
long			val;

	sem_getvalue(semaphoreP, &val);	
	printf("value = %d\n", val);

}*/

//===========================================================================================
#if CAN_USE_POSIX_THREADS
static void* _EntryP(void *args)
{
EntryPRec		*entP = (EntryPRec*)args;
void			*result;
unsigned long	ourID;
XErr			err = noErr;

	_MoreThread();
	//XThreadsSemaphoreGreen(&gXLibNewThread); // spostato fuori (in XNewThread)
	ourID = (unsigned long)pthread_self();
#ifdef CAN_USE_POSIX_THREADS
	if (entP->toDetach)
		err = pthread_detach((pthread_t)ourID);
#endif
	if NOT(err)
	{	if NOT(err = _XThreadsNewTLS(ourID, (long)&entP, gUnixStackSize))
		{	result = entP->func(entP->args);
			_XThreadsDisposeTLS(ourID, nil);
		}
		free((Ptr)entP);
	}
	_LessThread();
	
return result;
}
#endif
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	XNewCS(BlockRef *csBlockRefP)
{
	pthread_mutexattr_t		mutex_attr;
	int						result;
	pthread_mutex_t			*theMutexP;
	BlockRef				theMutexBlock = nil;
	XErr					err = noErr;
	
	if (theMutexBlock = NewBlock(sizeof(pthread_mutex_t), &err, (Ptr*)&theMutexP))
	{
		errno = noErr;
		if not(result = pthread_mutexattr_init(&mutex_attr))
		{
			errno = noErr;
			if not(result = pthread_mutexattr_settype(&mutex_attr, PTHREAD_MUTEX_RECURSIVE))
			{
				errno = noErr;
				if not(result = pthread_mutex_init(theMutexP, &mutex_attr))
				{
					*csBlockRefP = theMutexBlock;
				}
				else
					err = errno;
			}
			else
				err = errno;
		}
		else
			err = errno;
	}
	if (err && theMutexBlock)
		DisposeBlock(&theMutexBlock);
	return err;
}

//===========================================================================================
void	XDeleteCS(BlockRef *csBlockRefP)
{
	pthread_mutex_t	*theMutexP = (pthread_mutex_t*)GetPtr(*csBlockRefP);
	pthread_mutex_destroy(theMutexP);
	DisposeBlock(csBlockRefP);
}

//===========================================================================================
void	XEnterCS(BlockRef csBlockRef)
{
#if CAN_USE_POSIX_THREADS
	int	result;
		
	if (gIsChild)
	{	
		pthread_mutex_t	*theMutexP = (pthread_mutex_t*)GetPtr(csBlockRef);
		result = pthread_mutex_lock(theMutexP);
	}
#endif
}

//===========================================================================================
void	XExitCS(BlockRef csBlockRef)
{
#if CAN_USE_POSIX_THREADS
	int	result;

	if (gIsChild)
	{
		pthread_mutex_t	*theMutexP = (pthread_mutex_t*)GetPtr(csBlockRef);
		result = pthread_mutex_unlock(theMutexP);
	}
#endif
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	XGetCurrentThread(unsigned long *threadIDP)
{
#ifdef CAN_USE_POSIX_THREADS
	*threadIDP = (unsigned long)pthread_self();
#else
	*threadIDP = gThreadsID;
#endif
	return noErr;
}

/*#ifdef JAVA_ENABLED
	#include	"JNIUtils.h"

	jobject		globalLockObject;
#endif*/

//===========================================================================================
void	XThreadsEnterCriticalSection(void)
{
	_EnterCriticalSection(true);
}
//===========================================================================================
void	XThreadsLeaveCriticalSection(void)
{
	_LeaveCriticalSection(true);
}

//===========================================================================================
XErr	XNewThread(unsigned long *threadID, long flags, void* (*func)(void*), unsigned long newThreadStackSize, void *args)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(newThreadStackSize)
#endif
#if CAN_USE_POSIX_THREADS	// && !JAVA_ENABLED
XErr			err = noErr;
unsigned long	ourID;
EntryPRec		*entP;
Boolean			waitEnd;
void			*status;
Boolean         disposeThreadRec;
	
	//if (err = _XThreadsCheckForceQuit())
	//	return err;
	// 	if alloc something across not joined threads, use malloc, not NewBlock
	//	(Check leaking gets confused!!)
	disposeThreadRec = false;
	if (entP = (EntryPRec*)malloc(sizeof(EntryPRec)))
	{	
		disposeThreadRec = true;
		entP->args = args;
		entP->func = func;
		gIsChild = true;
		ourID = (unsigned long)pthread_self();
		waitEnd = flags & kWaitEndOfThread; 
		#ifdef CHECK_LEAKING
			if (waitEnd)
			{	XThreadsEnterCriticalSection();
				entP->toDetach = false;
			}
			else
				entP->toDetach = true;
		#else
			if (waitEnd)
				entP->toDetach = false;
			else
				entP->toDetach = true;
		#endif
		
		if NOT(err = XThreadsWaitSemaphore(&gXLibNewThread, kXLibStopThreadsTimeout))
		{	
			err = pthread_create((pthread_t*)threadID, nil, _EntryP, (void*)entP);
			XThreadsSemaphoreGreen(&gXLibNewThread);
			if not(err)
				disposeThreadRec = false;
		}
		if NOT(err)
		{	if (waitEnd)
			{
			#ifdef CHECK_LEAKING
				CheckLeakingMoreThread(ourID, *threadID);
				XThreadsLeaveCriticalSection();
			#endif
				if NOT(err = pthread_join((pthread_t)*threadID, &status))
					err = (XErr)status;
			#ifdef CHECK_LEAKING
				CheckLeakingLessThread();
			#endif
			}
		}
		else
		{
		#ifdef CHECK_LEAKING
			if (waitEnd)
				XThreadsLeaveCriticalSection();
		#endif
		}
	}
	if (disposeThreadRec)
		free((Ptr)entP);
	
return err;
#else
	*threadID = ++gThreadsID;

return (XErr)func((void*)args);
#endif
}

//===========================================================================================
XErr	XThreadsNewPool(long maxThreads, unsigned long size)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(maxThreads, size)
#endif
	return noErr;
}

//===========================================================================================
XErr	XThreadsSemaphoreGreen(long *semaphore)
{
XErr			err = noErr;
#ifdef CAN_USE_SEMAPHORE
#if __MACOSX__
	//semaphore_t		*semaphoreP = (semaphore_t*)(*semaphore);
#else
	sem_t			*semaphoreP = (sem_t*)(*semaphore);
#endif

	#if __MACOSX__
		err = semaphore_signal(*semaphore);
	#else
	int res;

		errno = 0;
		res = sem_post(semaphoreP);
		if (res == -1)
			err = errno;
	#endif
	//_DebugSemaphore(semaphoreP);
	
#endif
return err;
}

//===========================================================================================
// timeout in milliseconds
XErr	XThreadsWaitSemaphore(volatile long *semaphore, long timeout)
{
XErr			err = noErr;
#if (!CAN_USE_SEMAPHORE || __MACOSX__) && __C_HAS_PRAGMA_UNUSED__
	#pragma unused(timeout)
#endif
#ifdef CAN_USE_SEMAPHORE
#if __MACOSX__
	//semaphore_t		*semaphoreP = (semaphore_t*)(*semaphore);
	
	//err = noErr;
	//printf("%d semaphore_wait\n", pthread_self());
	//BAPI_Log(0, "semaphore_wait");
	err = semaphore_wait(*semaphore);// == -1)
	
	/*{
	CStr255	aCStr;
	
	sprintf(aCStr, "semaphore_wait: %d %d", err, *semaphore);
	BAPI_Log(0, aCStr);
	}*/
	
	//	err = noErr;
	//printf("%d semaphore_wait passed %d\n", pthread_self(), err);
#else
unsigned long 	initMilliSecs, millisecs;

	sem_t			*semaphoreP = (sem_t*)(*semaphore);

	XGetMilliseconds(&initMilliSecs);
	while (1)
	{	err = noErr;
		if (sem_trywait(semaphoreP) == -1)
			err = errno;
		if (err != EAGAIN)	// also noErr
			break;
		XGetMilliseconds(&millisecs);
		if ((millisecs - initMilliSecs) > timeout)
		{	err = XError(kXLibError, ErrXThreads_Timeout);
			break;
		}
	}
#endif
#endif
return err;
}


//===========================================================================================
// timeout in milliseconds (ex, no timeout)
/*static XErr	xXThreadsWaitSemaphore(volatile long *semaphore, long timeout)
{
XErr			err = noErr;
#ifdef CAN_USE_SEMAPHORE
sem_t			*semaphoreP = (sem_t*)(*semaphore);

	errno = 0;
	if (sem_wait(semaphoreP) == -1)
		err = errno;
	//_DebugSemaphore(semaphoreP);
#endif

return err;
}*/

//===========================================================================================
long	XThreadsCreateSemaphore(long initialState, XErr *errP)
{
#ifdef CAN_USE_SEMAPHORE
XErr			err = noErr;
#if __MACOSX__
	//semaphore_t		*semaphoreP = nil;
	semaphore_t			newsem;
#else
	sem_t			*semaphoreP = nil;
#endif
int				value;
	
	errno = 0;
#if __MACOSX__
	if (initialState == _RED)
		value = 0;
	else
		value = 1;
	//BAPI_Log(0, "semaphore_create");
	err = semaphore_create(mach_task_self(), &newsem, SYNC_POLICY_FIFO, value);
	if (errP)
		*errP = err;
	/*{
	CStr255	aCStr;
	
	sprintf(aCStr, "semaphore_create: %d %d", err, newsem);
	BAPI_Log(0, aCStr);
	}*/
	
return (long)newsem;
	
	/*if (semaphoreP = (semaphore_t*)malloc(sizeof(semaphore_t)))
	{	bzero(semaphoreP, sizeof(semaphore_t));
		if (initialState == _RED)
			value = 0;
		else
			value = 1;
		//errno = 0;
		err = semaphore_create(mach_task_self(), semaphoreP, SYNC_POLICY_FIFO, value);// == -1)
		//	err = errno;
	}*/
#else
	if (semaphoreP = (sem_t*)malloc(sizeof(sem_t)))
	{	bzero(semaphoreP, sizeof(sem_t));
		if (initialState == _RED)
			value = 0;
		else
			value = 1;
		errno = 0;
		if (sem_init(semaphoreP, 0, value) == -1)
			err = errno;
	}
	else
		err = errno;
	if (err)
	{	if (semaphoreP)
		{	free(semaphoreP);
			semaphoreP = nil;
		}
	}
	if (errP)
		*errP = err;

return (long)semaphoreP;
#endif

#else
	return 0;
#endif
}

//===========================================================================================
XErr	XThreadsCloseSemaphore(long semaphore)
{
XErr			err = noErr;
#ifdef CAN_USE_SEMAPHORE
#if __MACOSX__
	//semaphore_t		*semaphoreP = (semaphore_t*)semaphore;
#else
	sem_t			*semaphoreP = (sem_t*)semaphore;
#endif

	//_DebugSemaphore(semaphoreP);
	
	#if __MACOSX__
		err = semaphore_destroy(mach_task_self(), semaphore);
	#else
	int		res;
	
		errno = 0;
		res = sem_destroy(semaphoreP);
		if (res == -1)
			err = errno;
		free(semaphoreP);
	#endif

return err;
#endif
return err;
}

#endif	// #ifndef __XLIB_CLIENT__

