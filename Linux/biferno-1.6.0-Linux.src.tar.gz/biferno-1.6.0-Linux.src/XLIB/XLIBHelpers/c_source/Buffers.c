/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Buffers.c,v 1.7 2005-11-04 14:15:19 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"
#include	"SlotMgr.h"

//#include	"Helpers.h"

#ifndef __XLIB_CLIENT__

//#include	"HTTPMgr.h"
//#include	<stdio.h>

#ifdef __XLIB_CLIENT__
	#include "XAsSharedLib.h"
	extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
#else
	typedef struct BufferRec
	{
		BlockRef	block;
		short		padShort;
		Boolean		padByte;
		Boolean		cleared;
		long		size;
		long		blocks;
		long		physSize;
		long		expandStep;
	} BufferSlot, *BufferSlotP;

static	SlotMgrRef 		gsBufferSlotMgrRef = 0;

#ifdef MEM_DEBUG
	#define	BUFFER_MGR_DEFAULT_SLOTS	128
#else
	#define	BUFFER_MGR_DEFAULT_SLOTS	4096
#endif

#define ONE_BLOCK_4K			(long)(4L * 1024L)
	/*
	#define	BUFFER_SLOTS_ALLOC_STEP	256

	typedef struct {
					unsigned long	slotCnt;
					unsigned long	usedSlotCnt;
					unsigned long	firstFreeSlot;
					unsigned long	max;
					unsigned long	maxLastMove;
					BufferSlot		bufSlot[BUFFER_SLOTS_ALLOC_STEP];
					} BufferArraySlot, *BufferArraySlotP;

	static BlockRef			gsBuffArrayBlock = nil;
	static Boolean			gsInitialized = 0;*/
	//extern CStr255			globalErrStr;

	/*
	#define	GET_BUFF_ARRAY()			((BufferArraySlotP)GetPtr(gsBuffArrayBlock))
	#define	GET_BUFF_SLOT(id)			(&GET_BUFF_ARRAY()->bufSlot[id-1])

	#define	UNDEFINED_SLOT	0xFFFFFFFF

	#define	RESET_TIME		(60L * 5L)	// 5 minutes
	*/
//#define	BUFFERS_WHILE_DEBUGGING_NO_OPTIMIZATION	1

//===========================================================================================
/*static void	_CountFree(BufferArraySlotP bufArraySlotP)
{
BufferSlotP		tRecP;
int				usedCnt, k, tot = bufArraySlotP->slotCnt;

	tRecP = &bufArraySlotP->bufSlot[0];
	usedCnt = 0;
	for (k = 0; k < tot; k++, tRecP++)
	{	if (tRecP->block)
			usedCnt++;
	}
	
	if (bufArraySlotP->usedSlotCnt != usedCnt)
		Debugger();
}*/

//===========================================================================================
static XErr	_BufferZeroSlot(Ptr slotP, SlotRef slot, long disposeTheBlock)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(slot)
#endif
BufferSlotP		buffRecP = (BufferSlotP)slotP;
XErr			err = noErr;
BlockRef		block;

	block = buffRecP->block;
	if (block)
	{	if (disposeTheBlock)
			DisposeBlock(&block);
		buffRecP->block = nil;
	}
	else
	{	if (disposeTheBlock)
		{	CDebugStr("Buffers_Err_AttemptToFreeTwice");
			err = XError(kXHelperError, Buffers_Err_AttemptToFreeTwice);
		}
		else
		{	CDebugStr("Buffers_Err_AttemptToCloseTwice");
			err = XError(kXHelperError, Buffers_Err_AttemptToCloseTwice);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_BufferDispose(long id, Boolean disposeTheBlock)
{
uint32_t	slot;
XErr		err = noErr;
	
	if (id && (slot = id))
		err = FreeSlotElem(gsBufferSlotMgrRef, &slot, _BufferZeroSlot, disposeTheBlock);
	else
		err = XError(kXHelperError, Buffers_Err_BadID);

return err;
}

/*static XErr	_BufferDispose(long id, Boolean disposeTheBlock)
{
BufferSlotP 		buffRecP;
BlockRef			block;
long				slot;
XErr				err = noErr;
//BufferArraySlotP	bufArraySlotP;
	
	XThreadsEnterCriticalSection();
	if (id && (slot = id))
	{	slot--;
		bufArraySlotP = GET_BUFF_ARRAY();
		//_CountFree(bufArraySlotP);
		buffRecP = &bufArraySlotP->bufSlot[slot];
		block = buffRecP->block;
		if (block)
		{	if (disposeTheBlock)
			{	DisposeBlock(&block);
				#ifdef __MEM_CANMOVE__
					bufArraySlotP = GET_BUFF_ARRAY();
					buffRecP = &bufArraySlotP->bufSlot[slot];	// reload after DisposeBlock
				#endif
			}
			buffRecP->block = nil;
		#ifndef BUFFERS_WHILE_DEBUGGING_NO_OPTIMIZATION
			if (slot < bufArraySlotP->firstFreeSlot)
				bufArraySlotP->firstFreeSlot = slot;
		#endif
			(bufArraySlotP->usedSlotCnt)--;
			//_CountFree(bufArraySlotP);
		}
		else
		{	if (disposeTheBlock)
			{	CDebugStr("Buffers_Err_AttemptToFreeTwice");
				err = XError(kXHelperError, Buffers_Err_AttemptToFreeTwice);
			}
			else
			{	CDebugStr("Buffers_Err_AttemptToCloseTwice");
				err = XError(kXHelperError, Buffers_Err_AttemptToCloseTwice);
			}
		}
	}
	else
		err = XError(kXHelperError, Buffers_Err_BadID);
	XThreadsLeaveCriticalSection();

return err;
}
*/
//===========================================================================================
/*static XErr	_ExpandMainBlock(void)
{
XErr				err = noErr;
BufferSlot			*tRecP;
int					i;
long				curBlkSize;
BufferArraySlotP	buffArraySlotP;

	buffArraySlotP = GET_BUFF_ARRAY();
	curBlkSize = offsetof(BufferArraySlot, bufSlot) + buffArraySlotP->slotCnt * sizeof(BufferSlot);
	if NOT(err = SetBlockSize(gsBuffArrayBlock, curBlkSize + sizeof(BufferSlot) * BUFFER_SLOTS_ALLOC_STEP))
	{	buffArraySlotP = GET_BUFF_ARRAY();
		tRecP = &buffArraySlotP->bufSlot[buffArraySlotP->slotCnt];
		buffArraySlotP->slotCnt += BUFFER_SLOTS_ALLOC_STEP;
		for (i = 0; i < BUFFER_SLOTS_ALLOC_STEP; i++, tRecP++)
			tRecP->block = nil;
	}
		
return err;
}
*/
//===========================================================================================
// if err returns -1
static long		_BufferCreate(long theExpandStep, Boolean cleared, Boolean userBit, XErr *errP)
{
BlockRef		block;
XErr			err = noErr;
BufferSlotP		tRecP;
SlotRef			slotRef = 0;

	if NOT(err = NewSlotElem(gsBufferSlotMgrRef, &slotRef, (Ptr*)&tRecP, userBit))
	{	if (theExpandStep)
			tRecP->expandStep = theExpandStep;
		else
			tRecP->expandStep = ONE_BLOCK_4K;
		if (cleared)
			block = NewBlockClear(tRecP->expandStep, &err, nil);
		else
			block = NewBlock(tRecP->expandStep, &err, nil);
		if (block && NOT(err))
		{	tRecP->block = block;		
			tRecP->size = 0;
			tRecP->blocks = 1;
			tRecP->physSize = tRecP->expandStep;
			tRecP->cleared = cleared;
		}
		else
			FreeSlotElem(gsBufferSlotMgrRef, &slotRef, nil, 0);
	}

if (errP)
	*errP = err;
if (err)
	return 0;
else
	return (long)slotRef;
}

/*static long		_BufferCreate(long theExpandStep, Boolean cleared, XErr *errP)
{
long				i, slot;
BufferArraySlotP	bufArraySlotP;
BlockRef			block;
XErr				err = noErr;
BufferSlotP			tRecP;

	XThreadsEnterCriticalSection();
	if (gsInitialized)
	{	
		bufArraySlotP = GET_BUFF_ARRAY();
		//_CountFree(bufArraySlotP);
		if (bufArraySlotP->usedSlotCnt == bufArraySlotP->slotCnt)
		{	bufArraySlotP->firstFreeSlot = bufArraySlotP->slotCnt;
			if (err = _ExpandMainBlock())
				goto esci;
			else
				bufArraySlotP = GET_BUFF_ARRAY();
		}
		if NOT(err)
		{	
		#ifdef	BUFFERS_WHILE_DEBUGGING_NO_OPTIMIZATION
			tRecP = &bufArraySlotP->bufSlot[0];
			i = 0;
			while (tRecP->block)
			{	tRecP++;
				i++;
			}
			slot = i;
		#else
			slot = bufArraySlotP->firstFreeSlot;
		#endif			
			tRecP = &bufArraySlotP->bufSlot[slot];
			if (slot >= bufArraySlotP->max)
			{	bufArraySlotP->max = slot;
				XGetSeconds(&bufArraySlotP->maxLastMove);
			}
			if (theExpandStep)
				tRecP->expandStep = theExpandStep;
			else
				tRecP->expandStep = ONE_BLOCK_4K;
			if (cleared)
				block = NewBlockClear(tRecP->expandStep, &err);
			else
				block = NewBlock(tRecP->expandStep, &err);
			if (block && NOT(err))
			{	
			#ifdef __MEM_CANMOVE__
				bufArraySlotP = GET_BUFF_ARRAY();
				tRecP = &bufArraySlotP->bufSlot[slot];
			#endif
				tRecP->block = block;		
				tRecP->size = 0;
				tRecP->blocks = 1;
				tRecP->physSize = tRecP->expandStep;
				tRecP->cleared = cleared;
				bufArraySlotP->usedSlotCnt++;
			#ifndef BUFFERS_WHILE_DEBUGGING_NO_OPTIMIZATION		
				if (bufArraySlotP->usedSlotCnt < bufArraySlotP->slotCnt)
				{	i = slot;
					do	{
						tRecP++;
						i++;
						} while (tRecP->block);
					bufArraySlotP->firstFreeSlot = i;
				}
				else
				{
					bufArraySlotP->firstFreeSlot = UNDEFINED_SLOT;		// expand next time
				}
			#endif
			}
		}
		//_CountFree(bufArraySlotP);
	}
	else
		err = XError(kXHelperError, Buffers_Err_NotInitialized);

esci:
	XThreadsLeaveCriticalSection();

if (errP)
	*errP = err;
if (err)
	return 0;
else
	return slot+1;
}
*/
//===========================================================================================
static XErr	_AddToBuffer(long id, Ptr buffPtr, long sizeOfBuff)
{
XErr				err = noErr;
BufferSlotP 		buffRecP;
Boolean				moved;
Ptr					p;

	buffRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id);
	//XThreadsEnterCriticalSection();
	//buffRecP = GET_BUFF_SLOT(id);
	if NOT(err = BufferCheck(id, buffRecP->size + sizeOfBuff, &moved))
	{	
	/*#ifdef __MEM_CANMOVE__
		if (moved)
			buffRecP = GET_BUFF_SLOT(id);
	#endif*/
		p = GetPtr(buffRecP->block);
		CopyBlock(p + buffRecP->size, buffPtr, sizeOfBuff);	
		buffRecP->size += sizeOfBuff;
	}
	//XThreadsLeaveCriticalSection();

return err;
}
#endif

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	Buffer_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{
		//xlibCallBacksRecPtr->BufferOptimize = (long)BufferOptimize;
		xlibCallBacksRecPtr->BufferCreate = (long)BufferCreate;
		xlibCallBacksRecPtr->BufferCreateClear = (long)BufferCreateClear;
		xlibCallBacksRecPtr->BufferFree = (long)BufferFree;
		xlibCallBacksRecPtr->BufferClose = (long)BufferClose;
		xlibCallBacksRecPtr->BufferClone = (long)BufferClone;
		xlibCallBacksRecPtr->BufferSetLength = (long)BufferSetLength;
		xlibCallBacksRecPtr->BufferReset = (long)BufferReset;
		xlibCallBacksRecPtr->BufferGetBlockRef = (long)BufferGetBlockRef;
		xlibCallBacksRecPtr->BufferGetBlockRefExt = (long)BufferGetBlockRefExt;
		xlibCallBacksRecPtr->BufferGetBlockRefExtSize = (long)BufferGetBlockRefExtSize;
		xlibCallBacksRecPtr->BufferAddLongString = (long)BufferAddLongString;
		xlibCallBacksRecPtr->BufferAddPString = (long)BufferAddPString;
		xlibCallBacksRecPtr->BufferAddCString = (long)BufferAddCString;
		xlibCallBacksRecPtr->BufferAddText = (long)BufferAddText;
		xlibCallBacksRecPtr->BufferAddChar = (long)BufferAddChar;
		xlibCallBacksRecPtr->BufferAddBuffer = (long)BufferAddBuffer;
		xlibCallBacksRecPtr->BufferAddLong = (long)BufferAddLong;
		xlibCallBacksRecPtr->BufferCheck = (long)BufferCheck;
}

//===========================================================================================
/*XErr	BufferOptimize(void)
{
unsigned long		lastSlotUsed, tot, i;
BufferArraySlotP	bufArraySlotP;
XErr				err = noErr;
unsigned long		now, totSlots, totBlocks, mainBlockSize;
BufferSlot			*slotP;

	XThreadsEnterCriticalSection();
	if (gsInitialized)
	{	bufArraySlotP = GET_BUFF_ARRAY();
		XGetSeconds(&now);
		if ((now - bufArraySlotP->maxLastMove) > RESET_TIME)
		{	tot = bufArraySlotP->slotCnt;
			slotP = &bufArraySlotP->bufSlot[tot-1];
			// find last used
			for (i = 0; i < tot; i++, slotP--)
			{	if (slotP->block)
					break;
			}
			lastSlotUsed = tot - i;
			if (lastSlotUsed < (tot / 2))		// contiguous last free part is more than 50%
			{	totBlocks = (lastSlotUsed / BUFFER_SLOTS_ALLOC_STEP) + 1;
				totSlots = totBlocks * BUFFER_SLOTS_ALLOC_STEP;
				mainBlockSize = offsetof(BufferArraySlot, bufSlot) + (totSlots * sizeof(BufferSlot));
				if NOT(err = SetBlockSize(gsBuffArrayBlock, mainBlockSize))
				{	bufArraySlotP = GET_BUFF_ARRAY();
					if (bufArraySlotP->firstFreeSlot == UNDEFINED_SLOT)
						bufArraySlotP->firstFreeSlot = totSlots;	// just added one block
					bufArraySlotP->slotCnt = totSlots;
					bufArraySlotP->max = lastSlotUsed;
					XGetSeconds(&bufArraySlotP->maxLastMove);
				}
			}
		}
	}
	XThreadsLeaveCriticalSection();
	
return err;
}
*/
//===========================================================================================
XErr	BufferCheck(long id, long newSize, Boolean *movedP)
{
XErr				err = noErr;
BufferSlotP 		buffRecP;

	//XThreadsEnterCriticalSection();
	//buffRecP = GET_BUFF_SLOT(id);
	buffRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id);
	if (newSize > (buffRecP->physSize))
	{
	int				oldBlocks, expandStep, newBlocks, oldPhSize, newPhSize;

		expandStep = buffRecP->expandStep;				// the expand step
		oldBlocks = buffRecP->blocks;					// how many blocks are now
		oldPhSize = buffRecP->physSize;		// ex: oldBlocks * expandStep;				// old physical size
														// how many blocks will be
		// ((newSize + expandStep - 1) / expandStep) * expandStep
		newBlocks = (newSize / expandStep) + ((int)((newSize % expandStep) != 0));
		newPhSize = newBlocks * expandStep;				// new physical size
		if NOT(err = SetBlockSize(buffRecP->block, newPhSize))
		{
		/*#ifdef __MEM_CANMOVE__
			buffRecP = GET_BUFF_SLOT(id);
		#endif*/
			// buffRecP->block = tBlock;
			if (buffRecP->cleared)						// clear the new blocks
				ClearBlock(GetPtr(buffRecP->block) + oldPhSize, newPhSize - oldPhSize);
			buffRecP->physSize = newPhSize;
			buffRecP->blocks = newBlocks;
			if (movedP)
				*movedP = true;							// the block moved
		}
		//else
		//	CEquStr(globalErrStr, "in BufferCheck");
	}
	else if (movedP)
		*movedP = false;
	//XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	BufferInit(void)
{	
XErr				err = noErr;
//BufferArraySlotP	bufArraySlotP;

	err = NewSlotMgrBlock(sizeof(BufferSlot), BUFFER_MGR_DEFAULT_SLOTS, &gsBufferSlotMgrRef);
	/*
	XThreadsEnterCriticalSection();
	gsBuffArrayBlock = NewBlockClear(sizeof(BufferArraySlot), &err);
	bufArraySlotP = GET_BUFF_ARRAY();
	bufArraySlotP->slotCnt = BUFFER_SLOTS_ALLOC_STEP;
	bufArraySlotP->usedSlotCnt = 0;				// just to explicitate since they are already zero
	bufArraySlotP->firstFreeSlot = 0;
	bufArraySlotP->max = 0;
	XGetSeconds(&bufArraySlotP->maxLastMove);
	gsInitialized = true;
	XThreadsLeaveCriticalSection();
	*/
	
return err;
}

//===========================================================================================
XErr	BufferEnd(void)
{	
XErr		err = noErr;

	err = DisposeSlotMgrBlock(&gsBufferSlotMgrRef);
	/*XThreadsEnterCriticalSection();
	if (gsBuffArrayBlock)
	{	DisposeBlock(&gsBuffArrayBlock);
		gsInitialized = false;
	}
	XThreadsLeaveCriticalSection();
	*/
	
return err;
}

//===========================================================================================
/*static void	_CompactBlocks(BufferSlotP slotP, long totElemCnt, long *totGoodsP)
{
long			saveTotElemCnt, totGoods;
BufferSlotP		runElemP;

	saveTotElemCnt = totElemCnt;
	do	{					// skip to first elem to remove
		if (slotP->block)
			slotP++;
		else
			break;
	} while(--totElemCnt);

	if (totElemCnt)
	{	totGoods = saveTotElemCnt - totElemCnt;
		runElemP = slotP;
		do {
			if (slotP->block)
			{	*runElemP++ = *slotP;
				totGoods++;
			}
			slotP++;
		} while(--totElemCnt);
		*totGoodsP = totGoods;
	}
	else
		*totGoodsP = saveTotElemCnt;
}
*/
//===========================================================================================
long	BufferCreate(long theExpandStep, XErr *errP)
{
	return _BufferCreate(theExpandStep, false, 0, errP);
}

//===========================================================================================
long	BufferCreateClear(long theExpandStep, XErr *errP)
{
	return _BufferCreate(theExpandStep, true, 0, errP);
}

//===========================================================================================
long	BufferCreateExt(long theExpandStep, Boolean userBit, XErr *errP)
{
	return _BufferCreate(theExpandStep, false, userBit, errP);
}

//===========================================================================================
XErr	BufferFree(long id)
{
	return _BufferDispose(id, true);
	
/*BufferSlotP 		buffRecP;
BlockRef			block;
long				slot;
XErr				err = noErr;
BufferArraySlotP	bufArraySlotP;
	
	XThreadsEnterCriticalSection();
	if (id && (slot = id))
	{	slot--;
		bufArraySlotP = GET_BUFF_ARRAY();
		//_CountFree(bufArraySlotP);
		buffRecP = &bufArraySlotP->bufSlot[slot];
		block = buffRecP->block;
		if (block)
		{	DisposeBlock(&block);
			#ifdef __MEM_CANMOVE__
				bufArraySlotP = GET_BUFF_ARRAY();
				buffRecP = &bufArraySlotP->bufSlot[slot];	// reload after DisposeBlock
			#endif
			buffRecP->block = nil;
		#ifndef BUFFERS_WHILE_DEBUGGING_NO_OPTIMIZATION
			if (slot < bufArraySlotP->firstFreeSlot)
				bufArraySlotP->firstFreeSlot = slot;
		#endif
			(bufArraySlotP->usedSlotCnt)--;
			//_CountFree(bufArraySlotP);
		}
		else
		{	CDebugStr("Buffers_Err_AttemptToFreeTwice");
			err = XError(kXHelperError, Buffers_Err_AttemptToFreeTwice);
		}
	}
	else
		err = XError(kXHelperError, Buffers_Err_BadID);
	XThreadsLeaveCriticalSection();

return err;*/
}

//===========================================================================================
XErr	BufferClose(long id)
{
	return _BufferDispose(id, false);

/*BufferSlotP 		buffRecP;
BufferArraySlotP	bufArraySlotP;
XErr				err = noErr;
long				slot;

	XThreadsEnterCriticalSection();
	if (id && (slot = id))
	{	slot--;
		bufArraySlotP = GET_BUFF_ARRAY();
		//_CountFree(bufArraySlotP);
		buffRecP = &bufArraySlotP->bufSlot[slot];
		if (buffRecP->block)
		{	buffRecP->block = nil;
		#ifndef BUFFERS_WHILE_DEBUGGING_NO_OPTIMIZATION
			if (slot <  bufArraySlotP->firstFreeSlot)
				bufArraySlotP->firstFreeSlot = slot;
		#endif
			bufArraySlotP->usedSlotCnt--;
			//_CountFree(bufArraySlotP);
		}
		else
		{	CDebugStr("Buffers_Err_AttemptToCloseTwice");
			err = XError(kXHelperError, Buffers_Err_AttemptToCloseTwice);
		}
	}
	else
		err = XError(kXHelperError, Buffers_Err_BadID);
	XThreadsLeaveCriticalSection();

return err;*/
}

//===========================================================================================
XErr	BufferClone(long sourceId, long *destIDP, long lenToClone)
{
BufferSlotP 		/*buffRecP, */oldRecP, newRecP;
long				newID;
XErr				err = noErr;
Ptr					p;
	
	//XThreadsEnterCriticalSection();
	//buffRecP = GET_BUFF_SLOT(sourceId);
	oldRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, sourceId);
	newID = BufferCreate(oldRecP->expandStep, &err);
	// load bufArraySlotP and oldRecP here because BufferCreate can change value of gsBuffRecBlock
	// oldRecP = GET_BUFF_SLOT(sourceId);
	LockBlock(oldRecP->block);
	if NOT(err)
	{	//newRecP = GET_BUFF_SLOT(newID);
		newRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, newID);
		newRecP->cleared = oldRecP->cleared;
		if (lenToClone < 0)
			lenToClone = oldRecP->size;
		p = GetPtr(oldRecP->block);
		if NOT(err = _AddToBuffer(newID, p, lenToClone))
			*destIDP = newID;
	}
	UnlockBlock(oldRecP->block);
	//XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	BufferReset(long id)
{
BufferSlotP 		buffRecP;
XErr				err = noErr;

	//XThreadsEnterCriticalSection();
	buffRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id);
	//buffRecP = GET_BUFF_SLOT(id);
	buffRecP->size = 0;
	buffRecP->blocks = 1;
	buffRecP->physSize = buffRecP->expandStep;
	if NOT(err = SetBlockSize(buffRecP->block, buffRecP->expandStep))	// schrinked
	{	
		/*#ifdef __MEM_CANMOVE__
			(GET_BUFF(id))->block = block;						// reload after SetBlockSize
		#else
			buffRecP->block = block;
		#endif*/
	}
	//XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	BufferSetLength(long id, long newSize)
{
BufferSlotP 		buffRecP;
XErr				err = noErr;
unsigned long		ts;

	//XThreadsEnterCriticalSection();
	//buffRecP = GET_BUFF_SLOT(id);
	buffRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id);
	if (newSize == 0)
		ts = 1;
	else
		ts = newSize;
	if NOT(err = SetBlockSize(buffRecP->block, ts))
	{
	/*#ifdef __MEM_CANMOVE__
		buffRecP = GET_BUFF_SLOT(id);
	#endif*/
		buffRecP->size = newSize;
		buffRecP->blocks = (newSize / buffRecP->expandStep);
		buffRecP->physSize = newSize;
	}
	//XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
BlockRef	BufferGetBlockRef(long id, long *sizeP)
{
BufferSlotP 	buffRecP;

	//XThreadsEnterCriticalSection();
	//buffRecP = GET_BUFF_SLOT(id);
	buffRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id);
	if (sizeP)
		*sizeP = buffRecP->size;
	//XThreadsLeaveCriticalSection();

return buffRecP->block;
}

//===========================================================================================
BlockRef	BufferGetBlockRefExtSize(long id, long *sizeP, Ptr *thePPtr)
{
BufferSlotP 	buffRecP;
BlockRef		bl;

	buffRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id);
	bl = buffRecP->block;
	if (sizeP)
		*sizeP = buffRecP->size;
	if (thePPtr)
		*thePPtr = GetPtr(bl);

return bl;
}

//===========================================================================================
BlockRef	BufferGetBlockRefExt(long id, Ptr *thePPtr)
{
BlockRef	block;

	block = ((BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id))->block;
	*thePPtr = GetPtr(block);

return block;
}

//===========================================================================================
/*Boolean	BufferGetUserBit(long id)
{
	return GetSlotUserBit(id);
}
*/
//===========================================================================================
// Pascal ext (length in two first bytes)
XErr	BufferAddLongString(long id, Byte *fieldStrP, long encodeType, long variant)
{
XErr		err = noErr;
Ptr			aPtr;
long		len, cLen = *(short*)fieldStrP;
BlockRef	result = nil;
Boolean 	alsoCR, tagsVisible, spaceToPlus;
	
	alsoCR = variant & kAlsoCR;
	tagsVisible = variant & kTagsVisible;
	spaceToPlus = variant & kSpaceToPlus;

	if (cLen)
	{	if (encodeType)
		{	if (encodeType == URL_ENC)
				err = EncodeURL((Byte*)&fieldStrP[2], cLen, &result, &len, spaceToPlus, nil);
			else if (encodeType == ISOLATIN_ENC)
				err = EncodeIsolatin((Byte*)&fieldStrP[2], cLen, &result, &len, alsoCR, tagsVisible, false, false, 0);
			if (err)
				return err;
			else
			{	LockBlock(result);
				aPtr = GetPtr(result);
			}
		}
		else
		{	len = cLen;
			aPtr = ((Ptr)fieldStrP + 2);
		}
		err = _AddToBuffer(id, aPtr, len);
		if (result)
			DisposeBlock(&result);
	}
	
return err;
}

//===========================================================================================
XErr	BufferAddCString(long id, char *fieldStr, long encodeType, long variant)
{
XErr		err = noErr;
Ptr			aPtr;
long		len, cLen = CLen(fieldStr);
BlockRef	result = nil;
Boolean 	alsoCR, tagsVisible, spaceToPlus;
	
	alsoCR = variant & kAlsoCR;
	tagsVisible = variant & kTagsVisible;
	spaceToPlus = variant & kSpaceToPlus;

	if (cLen)
	{	if (encodeType)
		{	if (encodeType == URL_ENC)
				err = EncodeURL((Byte*)fieldStr, cLen, &result, &len, spaceToPlus, nil);
			else if (encodeType == ISOLATIN_ENC)
				err = EncodeIsolatin((Byte*)fieldStr, cLen, &result, &len, alsoCR, tagsVisible, false, false, 0);
			if (err)
				return err;
			else
			{	LockBlock(result);
				aPtr = GetPtr(result);
			}
		}
		else
		{	len = cLen;
			aPtr = fieldStr;
		}
		err = _AddToBuffer(id, aPtr, len);
		if (result)
			DisposeBlock(&result);
	}
	
return err;
}

//static long	gLog = 0;
//===========================================================================================
XErr	BufferAddText(long id, char *textP, long size, long encodeType, long variant)
{
XErr		err = noErr;
Ptr			aPtr;
long		len;
BlockRef	result = nil;
Boolean 	alsoCR, tagsVisible, spaceToPlus;
	
	alsoCR = variant & kAlsoCR;
	tagsVisible = variant & kTagsVisible;
	spaceToPlus = variant & kSpaceToPlus;

	if (size)
	{	if (encodeType)
		{	if (encodeType == URL_ENC)
				err = EncodeURL((Byte*)textP, size, &result, &len, spaceToPlus, nil);
			else if (encodeType == ISOLATIN_ENC)
				err = EncodeIsolatin((Byte*)textP, size, &result, &len, alsoCR, tagsVisible, false, false, 0);
			if (err)
				return err;
			else
			{	LockBlock(result);
				aPtr = GetPtr(result);
			}
		}
		else
		{	len = size;
			aPtr = textP;
		}
		err = _AddToBuffer(id, aPtr, len);
		if (result)
			DisposeBlock(&result);
	}
	
return err;
}

//===========================================================================================
XErr	BufferAddPString(long id, StringPtr fieldStr, long encodeType, long variant)
{
XErr		err = 0;
Byte		*aPtr;
long		len;
BlockRef	result = nil;
Boolean 	alsoCR, tagsVisible, spaceToPlus;
	
	alsoCR = variant & kAlsoCR;
	tagsVisible = variant & kTagsVisible;
	spaceToPlus = variant & kSpaceToPlus;

	if (fieldStr[0])
	{	if (encodeType)
		{	if (encodeType == URL_ENC)
				err = EncodeURL((Byte*)&fieldStr[1], fieldStr[0], &result, &len, spaceToPlus, nil);
			else if (encodeType == ISOLATIN_ENC)
				err = EncodeIsolatin((Byte*)&fieldStr[1], fieldStr[0], &result, &len, alsoCR, tagsVisible, false, false, 0);
			if (err)
				return err;
			else
			{	LockBlock(result);
				aPtr = (Byte*)GetPtr(result);
			}
		}
		else
		{	len = fieldStr[0];
			aPtr = &fieldStr[1];
		}
		err = _AddToBuffer(id, (Ptr)aPtr, len);
		if (result)
			DisposeBlock(&result);
	}

return err;
}

//===========================================================================================
XErr	BufferAddBuffer(long id, Ptr buff, long sizeofBuf)
{
	if (sizeofBuf)
		return _AddToBuffer(id, buff, sizeofBuf);
	else
		return noErr;
}

//===========================================================================================
XErr	BufferAddChar(long id, Byte ch)
{
XErr				err = noErr;
BufferSlotP 		buffRecP;
Boolean				moved = false;

	//XThreadsEnterCriticalSection();
	//buffRecP = GET_BUFF_SLOT(id);
	buffRecP = (BufferSlotP)GetSlotElem(gsBufferSlotMgrRef, id);
	if ((buffRecP->size + 1) > buffRecP->physSize)
		err = BufferCheck(id, buffRecP->size + 1, &moved);
	if NOT(err)
	{	
	/*#ifdef __MEM_CANMOVE__
		if (moved)
			buffRecP = GET_BUFF_SLOT(id);
	#endif*/
		*(GetPtr(buffRecP->block) + buffRecP->size) = ch;
		buffRecP->size++;
	}
	//XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	BufferAddLong(long id, uint32_t theLong)
{
	return _AddToBuffer(id, (Ptr)&theLong, sizeof(uint32_t));
}

#else
#if __MWERKS__
#pragma mark-
#endif

extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
//===========================================================================================
/*XErr	BufferOptimize(void)
{
XErr	(*p)(void) = (void*)gXLibCallBacksRecPtr->BufferOptimize;

	return p();
}
*/
//===========================================================================================
XErr	BufferCheck(long id, long newSize, Boolean *movedP)
{
XErr	(*p)(long id, long newSize, Boolean *movedP) = (void*)gXLibCallBacksRecPtr->BufferCheck;

	return p(id, newSize, movedP);
}

//===========================================================================================
XErr	BufferInit(void)
{	
	return noErr;
}

//===========================================================================================
XErr	BufferEnd(void)
{
	return noErr;
}

//===========================================================================================
long	BufferCreate(long theExpandStep, XErr *errP)
{
long	(*p)(long theExpandStep, XErr *errP) = (void*)gXLibCallBacksRecPtr->BufferCreate;

	return p(theExpandStep, errP);
}

//===========================================================================================
long	BufferCreateClear(long theExpandStep, XErr *errP)
{
long	(*p)(long theExpandStep, XErr *errP) = (void*)gXLibCallBacksRecPtr->BufferCreateClear;

	return p(theExpandStep, errP);
}

//===========================================================================================
XErr	BufferFree(long id)
{
XErr	(*p)(long id) = (void*)gXLibCallBacksRecPtr->BufferFree;

	return p(id);
}

//===========================================================================================
XErr	BufferClose(long id)
{
XErr	(*p)(long id) = (void*)gXLibCallBacksRecPtr->BufferClose;

	return p(id);
}

//===========================================================================================
XErr	BufferClone(long sourceId, long *destIDP, long lenToClone)
{
XErr	(*p)(long sourceId, long *destIDP, long lenToClone) = (void*)gXLibCallBacksRecPtr->BufferClone;

	return p(sourceId, destIDP, lenToClone);
}

//===========================================================================================
XErr	BufferReset(long id)
{
XErr	(*p)(long id) = (void*)gXLibCallBacksRecPtr->BufferReset;

	return p(id);
}

//===========================================================================================
XErr	BufferSetLength(long id, long newSize)
{
XErr	(*p)(long id, long newSize) = (void*)gXLibCallBacksRecPtr->BufferSetLength;

	return p(id, newSize);
}

//===========================================================================================
BlockRef	BufferGetBlockRef(long id, long *sizeP)
{
XErr	(*p)(long id, long *sizeP) = (void*)gXLibCallBacksRecPtr->BufferGetBlockRef;

	return p(id, sizeP);
}

//===========================================================================================
BlockRef	BufferGetBlockRefExt(long id, Ptr *thePPtr)
{
BlockRef	(*p)(long id, Ptr *thePPtr) = (void*)gXLibCallBacksRecPtr->BufferGetBlockRefExt;

	return p(id, thePPtr);
}

//===========================================================================================
BlockRef	BufferGetBlockRefExtSize(long id, long *sizeP, Ptr *thePPtr)
{
BlockRef	(*p)(long id, long *sizeP, Ptr *thePPtr) = (void*)gXLibCallBacksRecPtr->BufferGetBlockRefExtSize;

	return p(id, sizeP, thePPtr);
}

//===========================================================================================
XErr	BufferAddLongString(long id, Byte *fieldStrP, long encodeType, long variant)
{
XErr	(*p)(long id, Byte *fieldStrP, long encodeType, long variant) = (void*)gXLibCallBacksRecPtr->BufferAddLongString;

	return p(id, fieldStrP, encodeType, variant);
}

//===========================================================================================
XErr	BufferAddCString(long id, char *fieldStr, long encodeType, long variant)
{
XErr	(*p)(long id, char *fieldStr, long encodeType, long variant) = (void*)gXLibCallBacksRecPtr->BufferAddCString;

	return p(id, fieldStr, encodeType, variant);
}

//static long	gLog = 0;
//===========================================================================================
XErr	BufferAddText(long id, char *textP, long size, long encodeType, long variant)
{
XErr	(*p)(long id, char *textP, long size, long encodeType, long variant) = (void*)gXLibCallBacksRecPtr->BufferAddText;

	return p(id, textP, size, encodeType, variant);
}

//===========================================================================================
XErr	BufferAddPString(long id, StringPtr fieldStr, long encodeType, long variant)
{
XErr	(*p)(long id, StringPtr fieldStr, long encodeType, long variant) = (void*)gXLibCallBacksRecPtr->BufferAddPString;

	return p(id, fieldStr, encodeType, variant);
}

//===========================================================================================
XErr	BufferAddBuffer(long id, Ptr buff, long sizeofBuf)
{
XErr	(*p)(long id, Ptr buff, long sizeofBuf) = (void*)gXLibCallBacksRecPtr->BufferAddBuffer;

	return p(id, buff, sizeofBuf);
}

//===========================================================================================
XErr	BufferAddChar(long id, Byte ch)
{
XErr	(*p)(long id, Byte ch) = (void*)gXLibCallBacksRecPtr->BufferAddChar;

	return p(id, ch);
}

//===========================================================================================
XErr	BufferAddLong(long id, uint32_t theLong)
{
XErr	(*p)(long id, uint32_t theLong) = (void*)gXLibCallBacksRecPtr->BufferAddLong;

	return p(id, theLong);
}
#endif	// __XLIB_CLIENT__

//===========================================================================================
/*void	DumpBufferInfo(long id, XErr (*logFunc)(long userData, char *string), long userData)
{
CStr255		aCSTR, tStr;
BufferRecP 	buffRecP = GET_BUFF(id);

	CEquStr(aCSTR, "Buffer => ");
	
	CAddStr(aCSTR, " id: ");
	CNumToString(id, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " cleared: ");
	CNumToString(buffRecP->cleared, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " size: ");
	CNumToString(buffRecP->size, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " used: ");
	CNumToString(buffRecP->used, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " blocks: ");
	CNumToString(buffRecP->blocks, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " physSize: ");
	CNumToString(buffRecP->physSize, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " expandStep: ");
	CNumToString(buffRecP->expandStep, tStr);
	CAddStr(aCSTR, tStr);
	
	CAddStr(aCSTR, " block dump:");

	logFunc(userData, aCSTR);
	DumpBlockRef(buffRecP->block, logFunc, userData);
}*/
