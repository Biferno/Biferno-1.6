/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Helpers.c,v 1.4 2003-11-20 10:32:19 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

//

static CStr63	gHelpersErrorsStr[] = 
	{	"Buffers_Err_NotInitialized",
		"Buffers_Err_BadID",
		"Buffers_Err_AttemptToFreeTwice",
		"Buffers_Err_AttemptToCloseTwice",
		
		"Cache_Err_NotInitialized",
		"Cache_Err_PathTooLong",
		//"Cache_Err_UserDataTooLong",
		
		"DLM_Err_InvalidListRef",
		//"DLM_Err_ObjNameRequired",
		"DLM_Err_ListDontAcceptNames",
		"DLM_Err_DuplicatedObject",
		"DLM_Err_OutOfBoundary",
		"DLM_Err_BufferToSmall",
		"DLM_Err_ObjectNotFound",
		"DLM_Err_CantModifyLength",
		"DLM_Err_ObjectIsConstant",
		"DLM_Err_ObjectIsLocked",
		"DLM_Err_ListIsLocked",
		"DLM_Err_ObjectIsNotArray",
		"DLM_Err_BadArrayDimension",
		"DLM_Err_ArrayElemWrongType",
		"DLM_Err_InvalidArrayIndex",
		"DLM_Err_InvalidPos",
		"DLM_Err_InvalidLength",
		"DLM_Err_NoMoreDataInObject",
		//"DLM_Err_CantDeleteObject",
		"DLM_Err_NoResolveOnDupList",
		"DLM_Err_NameTooLong",
		"DLM_Err_InvalidListType",
		"DLM_Err_IllegalOperation",
		"DLM_Err_InvalidFile",
		
		"TextUtils_Err_NotInitialized",
		
		"ErrJavaHelperJVMLoadFailed",
		"ErrJavaHelperAttachCurrentThreadException"
		
		//"JavaError"
		
		/*"JNIUtils_JavaError",
		"JNIUtils_StringTooLong",
		"JNIUtils_FieldNotFound"*/
		};

//extern CStr255	globalErrStr;
//extern Boolean	gMustInitializeHelpers;

//===========================================================================================
XErr	ErrorGetDescr(XErr theError, char *eNameStr, char *eMsg)
{
int		idx;
long	errValue, eType;

	// ex: if ((theError >= HELPERS_BASE_ERROR) && (theError <= HELPERS_LAST_ERROR))
	XErrorGetTypeValue(theError, &errValue, &eType);
	if (eType == kXHelperError)
	{	idx = errValue - HELPERS_BASE_ERROR;
		if (eNameStr)
		{	if ((idx >= 0) && (idx < ErrXLibHelperLastError))
				CEquStr(eNameStr, gHelpersErrorsStr[idx]);
			else
				CEquStr(eNameStr, "Unknown Error");
		}
		if (eMsg)
			*eMsg = 0;
	}
	else
		XErrorGetDescr(theError, eNameStr, eMsg);
		
	/*if (eMsg && NOT(*eMsg))
	{	CEquStr(eMsg, globalErrStr);
		*globalErrStr = 0;
	}*/
		
return noErr;
}

//===========================================================================================
XErr	InitHelpers(void)
{
XErr				err = noErr;

	if NOT(err = BufferInit())
	{	if NOT(err = InitTextUtils())
		{
			err = CFInit(true, true, false);
		}
	}
	
return err;
}

//===========================================================================================
XErr	EndHelpers(void)
{
XErr		err = noErr;

	if NOT(CFEnd())
	{	if NOT(err = EndTextUtils())
		{
			err = BufferEnd();
		}
	}
	
return err;
}

