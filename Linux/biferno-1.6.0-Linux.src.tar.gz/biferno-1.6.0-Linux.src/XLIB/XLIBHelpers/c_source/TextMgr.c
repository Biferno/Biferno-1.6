/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: TextMgr.c,v 1.17 2008-02-05 17:23:03 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

#ifndef __XLIB_CLIENT__

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define ONE_BLOCK_1K		1024L

#define HTMLTAGS_ARRAYDIM	87		// following array
static CStr15	htmlName[HTMLTAGS_ARRAYDIM] = {	
	"boolean",		"a",		"address",	"applet",	"area",	
	"b",			"base",		"basefont",	"big",		"blink",	
	"blockquote",	"body",		"tbody",	"br",		"caption",	
	"center",		"cite",		"code",		"comments",	"dd",	
	"dir",			"div",		"dl",		"dt",		"em",	
	"embed",		"font",		"form",		"frame",	"frameset",	
	"h1",			"h2",		"h3",		"h4",		"head",	
	"hr",			"html",		"i",		"ilayer",	"img",	
	"input",		"isindex",	"kbd",		"keygen",	"layer",	
	"li",			"link",		"map",		"menu",		"meta",	
	"multicol",		"nobr",		"noembed",	"noframes",	"nolayer",	
	"noscript",		"object",	"ol",		"option",	"p",	
	"param",		"plaintext","pre",		"s",		"script",	
	"select",		"server",	"small",	"spacer",	"span",	
	"strike",		"strong",	"style",	"sub",		"sup",	
	"table",		"td",		"textarea",	"th",		"title",	
	"tr",			"tt",		"u",		"ul",		"var",	
	"wbr",			"xmp"
};

#ifdef __LITTLE_ENDIAN__
	#define	TYPE_LOW_TAG		'epyt'
	#define	TYPE_UPPER_TAG		'EPYT'
	#define	TEXT_LOW_TAG		'txet'
	#define	TEXT_UPPER_TAG		'TXET'

	#define	BR_TAG				'>rb<'

	//#define	kCR					0x0A0D	// '\n\r'
	#define	kTD					'dt'
	#define	kTH					'ht'
	#define	kTR					'rt'
	#define	kBR					'rb'
	#define	CRLFCRLF			0x0a0d0a0d	//'\n\r\n\r'
	#define	CRLF				0x0a0d		//'\n\r'
#else
	#define	TYPE_LOW_TAG		'type'
	#define	TYPE_UPPER_TAG		'TYPE'
	#define	TEXT_LOW_TAG		'text'
	#define	TEXT_UPPER_TAG		'TEXT'
	
	#define	BR_TAG				'<br>'

	//#define	kCR					'\r\n'
	#define	kTD					'td'
	#define	kTH					'th'
	#define	kTR					'tr'
	#define	kBR					'br'
	#define	CRLFCRLF			'\r\n\r\n'
	#define	CRLF				'\r\n'
#endif

#if __UNIX_XLIB__
	#define	FIRST_NEWLINE_CHAR	'\n'
	#define	SECOND_NEWLINE_CHAR	0
#elif __MAC_XLIB__
	#define	FIRST_NEWLINE_CHAR	'\r'
	#define	SECOND_NEWLINE_CHAR	0
#else	// Windows
	#define	FIRST_NEWLINE_CHAR	'\r'
	#define	SECOND_NEWLINE_CHAR	'\n'
#endif

static int		gCharset = CHARSET_UNIX;
// Static
static DLMRef	gsMacNativeFromIso, gsMacIsoFromNative, gsMacEntityFromNative, gsMacNativeFromEntity;
static DLMRef	gsUnixNativeFromIso, gsUnixIsoFromNative, gsUnixEntityFromNative, gsUnixNativeFromEntity;

static DLMRef	gsHTMLTagsList;

//===========================================================================================
// Get the next tag html or iso letter (agrave etc...)
// return false if the string has more than "theStrMaxLen" chars 
// (theStrMaxLen is without len-char)
static Boolean _GetNextObjectName(Ptr theP, long len, char *theStr, long theStrMaxLen, Boolean *closedP)
{
int		k;

	//theStr[0] = 0;
	SkipSpaceAndTab(&theP, &len);
	if ((len > 0) && (*theP == '/'))		// tag closed
	{	theP++;
		len--;
		SkipSpaceAndTab(&theP, &len);
		if (closedP)
			*closedP = true;
	}
	else if (closedP)
		*closedP = false;
	
	if (len > 0)
	{	k = 0;
		do {
			if ((*theP == ' ') || (*theP == '>') || (*theP == ';') || (*theP == '\n') || (*theP == '\r'))
				break;
			else
				theStr[k++] = *theP;
			theP++;
			len--;
 		} while (len && (k < theStrMaxLen));
 		if (k == theStrMaxLen)
 			return false;
 		else
 			theStr[k] = 0;
 	}
 
return true;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static Byte	_GetNativeFromIso(int isoCode, int charSet)
{
long	result;
CStr15	isoCodeStr;
DLMRef	currentList;
	
	currentList = (charSet == CHARSET_UNIX) ? gsUnixNativeFromIso : gsMacNativeFromIso;
	CNumToString(isoCode, isoCodeStr);
	if NOT(DLM_GetObjID(currentList, isoCodeStr, nil, &result))
		result = 0;
	
return (Byte)result;
}

//===========================================================================================
static int	_GetIsoFromNative(Byte nativeCode, long getSecond_lower, int charSet)
{
long	result;
char	name[2];
DLMRef	currentList;
	
	currentList = (charSet == CHARSET_UNIX) ? gsUnixIsoFromNative : gsMacIsoFromNative;
	name[1] = 0;
	name[0] = nativeCode;
	if NOT(DLM_GetIndexObjID(currentList, name, 1 + getSecond_lower, nil, &result))
		result = 0;
	
return result;
}

//===========================================================================================
static void	_GetEntityFromNative(Byte nativeCode, char *entity, int charSet)
{
long	tLen, objID;
char	name[2];
DLMRef	currentList;
	
	currentList = (charSet == CHARSET_UNIX) ? gsUnixEntityFromNative : gsMacEntityFromNative;
	name[1] = 0;
	name[0] = nativeCode;
	if (objID = DLM_GetObjID(currentList, name, nil, nil))
	{	tLen = 16;
		DLM_GetObj(currentList, objID, entity, &tLen, 0, nil);
	}
	else
		*entity = 0;
}

//===========================================================================================
static Byte _GetNativeFromEntity(char *entname, int charSet)
{
long	result;
DLMRef	currentList = (charSet == CHARSET_UNIX) ? gsUnixNativeFromEntity : gsMacNativeFromEntity;
	
	if NOT(DLM_GetObjID(currentList, entname, nil, &result))
		result = 0;
	
return (Byte)result;
}

//===========================================================================================
static Boolean	_IsEntity(Ptr stringP, long stringLen, int charSet)
{
CStr63		cStr;
long		tLen, tagNameLen;
Byte		ch;
Boolean		res = true;
DLMRef		currentList = (charSet == CHARSET_UNIX) ? gsUnixNativeFromEntity : gsMacNativeFromEntity;

	if (stringLen)
	{	ch = *stringP;
		if ((ch == ' ') || (ch == '\t') || (ch == '\r') || (ch == '\n'))
			res = false;
		else if (_GetNextObjectName((Ptr)stringP, stringLen, cStr, sizeof(Str63) - 1, nil))
		{	CUp2LowerStr(cStr, 0);
			tagNameLen = CLen(cStr);
			tLen = sizeof(Byte);
			if NOT(DLM_GetObjID(currentList, cStr, nil, nil))
				res = false;
		}
	}
	else
		res = false;
	
return res;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static Byte _Local_CharToLower(Byte ch, int charset)
{
	
	if (ch > 127)
	{	
		long	tLen, objID;
		char	name[2];
		Byte	firstChar;
		CStr15	theEntity;
		DLMRef	currentList = (charset == CHARSET_UNIX) ? gsUnixEntityFromNative : gsMacEntityFromNative;
		
		name[1] = 0;
		name[0] = ch;
		if ((objID = DLM_GetObjID(currentList, name, nil, nil)) && (objID > 1))
		{	if (objID < TOT_ISO_ENTITIES)
		{	tLen = 16;
			DLM_GetObj(currentList, objID, theEntity, &tLen, 0, nil);
			firstChar = *theEntity;
			if (firstChar <= 'Z' && firstChar >= 'A')	// is upper
			{	DLM_GetInfo(currentList, objID-1, nil, nil, name);
				ch = *name;
			}
		}
		}
		else
			ch = tolower(ch);
	}
	else
		ch = tolower(ch);
	
	return ch;
}

//===========================================================================================
Byte CharToLower(Byte ch)
{
	return _Local_CharToLower(ch, gCharset);
}

//===========================================================================================
static Byte _Local_CharToUpper(Byte ch, int charset)
{
	if (ch > 127)
	{	
		long	tLen, objID;
		char	name[2];
		Byte	firstChar;
		CStr15	theEntity;
		DLMRef	currentList = (charset == CHARSET_UNIX) ? gsUnixEntityFromNative : gsMacEntityFromNative;
		
		name[1] = 0;
		name[0] = ch;
		if ((objID = DLM_GetObjID(currentList, name, nil, nil)) && (objID < TOT_ISO_ENTITIES))
		{	if (objID < TOT_ISO_ENTITIES)
		{	tLen = 16;
			DLM_GetObj(currentList, objID, theEntity, &tLen, 0, nil);
			firstChar = *theEntity;
			if (firstChar <= 'z' && firstChar >= 'a')	// is lower
			{	DLM_GetInfo(currentList, objID+1, nil, nil, name);
				ch = *name;
			}
		}
		}
		else
			ch = toupper(ch);
	}
	else
		ch = toupper(ch);
	
	return ch;
}

//===========================================================================================
Byte CharToUpper(Byte ch)
{
	return _Local_CharToUpper(ch, gCharset);
}

//===========================================================================================
static Byte	_Local_HexStringToChar(short hexCh, Boolean isoLatin, int charset)
{
	register Byte	hiCh, lowCh, res;
	
	hiCh = *(Byte*)&hexCh;
	if ( (hiCh <= '9') && (hiCh >= '0') )
		hiCh = (hiCh - '0') << 4;
	else if ( (hiCh <= 'F') && (hiCh >= 'A') )
		hiCh = (hiCh - 'A' + 10) << 4;
	else if ( (hiCh <= 'f') && (hiCh >= 'a') )
		hiCh = (hiCh - 'a' + 10) << 4;
	else
		return 0;
	
	lowCh = *(Byte*)((Ptr)&hexCh + 1);
	if ( (lowCh <= '9') && (lowCh >= '0') )
		lowCh = lowCh - '0';
	else if ( (lowCh <= 'F') && (lowCh >= 'A') )
		lowCh = lowCh - 'A' + 10;
	else if ( (lowCh <= 'f') && (lowCh >= 'a') )
		lowCh = lowCh - 'a' + 10;
	else
		return 0;
	
	res = hiCh + lowCh;
	if ((res >= 0x80) && isoLatin)
		res = _GetNativeFromIso(res, charset);	// convCh[res - 0x80];
	
	return res;
}

//===========================================================================================
Byte	HexStringToChar(short hexCh, Boolean isoLatin)
{
	return _Local_HexStringToChar(hexCh, isoLatin, gCharset);
}

//===========================================================================================
static XErr	_CreateIsoLists(IsoEntity *theIsoEntity, int charSet)
{
XErr		err = noErr;
int			i;
//char		name[2];
long		userData, tot;
IsoEntity	*entityP;
CStr15		nameStr;
DLMRef		*destListP;
	
	// list to find Iso Code fom Native code (i.e. to Encode)
	destListP = (charSet == CHARSET_UNIX) ? &gsUnixIsoFromNative : &gsMacIsoFromNative;
	if NOT(err = DLM_CreateAcceptDupl(destListP, NAMECS_LIST, LOCAL_LIST))
	{	tot = TOT_ISO_ENTITIES;
		entityP = theIsoEntity;
		nameStr[1] = 0;
		for (i = 0; (i < tot) && NOT(err); i++, entityP++)
		{	if ((entityP->nativeCode > 0xFF) || NOT(entityP->nativeCode))
			entityP->nativeCode = '?';
			nameStr[0] = (char)entityP->nativeCode;
			// Value is in user data
			userData = entityP->isoCode;
			DLM_NewObj(*destListP, nameStr, nil, 0, userData, kFixedSize, &err);
		}
	}
	
	// list to find Native Code fom Iso code (i.e. to Decode)
	if NOT(err)
	{
		destListP = (charSet == CHARSET_UNIX) ? &gsUnixNativeFromIso : &gsMacNativeFromIso;
		if NOT(err = DLM_Create(destListP, NAMECS_LIST, LOCAL_LIST))
		{	tot = TOT_ISO_ENTITIES;
			entityP = theIsoEntity;
			for (i = 0; (i < tot) && NOT(err); i++, entityP++)
			{	CNumToString(entityP->isoCode, nameStr);
				if ((entityP->nativeCode > 0xFF) || NOT(entityP->nativeCode))
					entityP->nativeCode = '?';
				userData = entityP->nativeCode;
				// Value is in user data
				DLM_NewObj(*destListP, nameStr, nil, 0, userData, kFixedSize, &err);
			}
		}
	}
	
	// list to find Entity fom Native code
	if NOT(err)
	{	
		destListP = (charSet == CHARSET_UNIX) ? &gsUnixEntityFromNative : &gsMacEntityFromNative;
		if NOT(err = DLM_CreateAcceptDupl(destListP, NAMECS_LIST, LOCAL_LIST))
		{	tot = TOT_ISO_ENTITIES;
			entityP = theIsoEntity;
			nameStr[1] = 0;
			for (i = 0; (i < tot) && NOT(err); i++, entityP++)
			{	if ((entityP->nativeCode > 0xFF) || NOT(entityP->nativeCode))
				entityP->nativeCode = '?';
				nameStr[0] = (char)entityP->nativeCode;
				DLM_NewObj(*destListP, nameStr, entityP->entity, CLen(entityP->entity)+1, 0L, kFixedSize, &err);
			}
		}
	}
	
	// list to find Native code from Entity
	if NOT(err)
	{	
		destListP = (charSet == CHARSET_UNIX) ? &gsUnixNativeFromEntity : &gsMacNativeFromEntity;
		if NOT(err = DLM_CreateAcceptDupl(destListP, NAMECS_LIST, LOCAL_LIST))
		{	tot = TOT_ISO_ENTITIES;
			entityP = theIsoEntity;
			for (i = 0; (i < tot) && NOT(err); i++, entityP++)
			{	if ((entityP->nativeCode > 0xFF) || NOT(entityP->nativeCode))
				entityP->nativeCode = '?';
				userData = entityP->nativeCode;
				// Value is in user data
				DLM_NewObj(*destListP, entityP->entity, nil, 0, userData, kFixedSize, &err);
			}
		}
	}
	
	return err;
}

//===========================================================================================
static XErr	_InitTextManagerLists(void)
{
XErr		err = noErr;
int			i;

#ifdef __XLIB_WITH_HELPERS__
//#if __MAC_XLIB__ || __MACOSX__
IsoEntity	theMacIsoEntity[TOT_ISO_ENTITIES] = 
{
// Mac Code	(0-255) - Iso Code 0(64258) - Entity (max 8 chars)
// Rule: Lower case is followed by Upper case if this exists
250,	729,	"#729",
198,	8710,	"#8710",
240,	63743,	"#63743",
222,	64257,	"#64257",
223,	64258,	"#64258",
251,	730,	"#730",
254,	731,	"#731",
245,	305,	"#305",
255,	711,	"#711",
253,	733,	"#733",
249,	728,	"#728",
135,	225,	"aacute",
231,	193,	"Aacute",
137,	226,	"acirc",
229,	194,	"Acirc",
171,	180,	"acute",
174,	198,	"AElig",
190,	230,	"aelig",
136,	224,	"agrave",
203,	192,	"Agrave",
0,	8501,	"alefsym",
0,	945,	"alpha",
0,	913,	"Alpha",
38,	38,	"amp",
0,	8743,	"and",
0,	8736,	"ang",
140,	229,	"aring",
129,	197,	"Aring",
197,	8776,	"asymp",
139,	227,	"atilde",
204,	195,	"Atilde",
138,	228,	"auml",
128,	196,	"Auml",
227,	8222,	"bdquo",
0,	946,	"beta",
0,	914,	"Beta",
248,	166,	"brvbar",
165,	8226,	"bull",
0,	8745,	"cap",
141,	231,	"ccedil",
130,	199,	"Ccedil",
252,	184,	"cedil",
162,	162,	"cent",
0,	967,	"chi",
0,	935,	"Chi",
246,	710,	"circ",
0,	9827,	"clubs",
0,	8773,	"cong",
169,	169,	"copy",
0,	8629,	"crarr",
0,	8746,	"cup",
26,	164,	"curren",
160,	8224,	"dagger",
224,	8225,	"Dagger",
0,	8595,	"darr",
0,	8659,	"dArr",
161,	176,	"deg",
0,	948,	"delta",
0,	916,	"Delta",
0,	9830,	"diams",
214,	247,	"divide",
142,	233,	"eacute",
131,	201,	"Eacute",
144,	234,	"ecirc",
230,	202,	"Ecirc",
143,	232,	"egrave",
233,	200,	"Egrave",
0,	8709,	"empty",
0,	8195,	"emsp",
0,	8194,	"ensp",
0,	949,	"epsilon",
0,	917,	"Epsilon",
0,	8801,	"equiv",
0,	951,	"eta",
0,	919,	"Eta",
0,	208,	"ETH",
0,	240,	"eth",
145,	235,	"euml",
232,	203,	"Euml",
219,	8364,	"euro",
0,	8707,	"exist",
196,	402,	"fnof",
0,	8704,	"forall",
0,	189,	"frac12",
0,	188,	"frac14",
0,	190,	"frac34",
218,	8260,	"frasl",
0,	947,	"gamma",
0,	915,	"Gamma",
179,	8805,	"ge",
62,	62,	"gt",
0,	8596,	"harr",
0,	8660,	"hArr",
0,	9829,	"hearts",
201,	8230,	"hellip",
146,	237,	"iacute",
234,	205,	"Iacute",
148,	238,	"icirc",
235,	206,	"Icirc",
193,	161,	"iexcl",
147,	236,	"igrave",
237,	204,	"Igrave",
0,	8465,	"image",
176,	8734,	"infin",
186,	8747,	"int",
0,	953,	"iota",
192,	191,	"iquest",
0,	8712,	"isin",
149,	239,	"iuml",
236,	207,	"Iuml",
0,	954,	"kappa",
0,	922,	"Kappa",
0,	955,	"lambda",
0,	923,	"Lambda",
0,	9001,	"lang",
199,	171,	"laquo",
0,	8656,	"lArr",
0,	8592,	"larr",
0,	8968,	"lceil",
210,	8220,	"ldquo",
178,	8804,	"le",
0,	8970,	"lfloor",
0,	8727,	"lowast",
215,	9674,	"loz",
0,	8206,	"lrm",
220,	8249,	"lsaquo",
212,	8216,	"lsquo",
60,	60,	"lt",
0,	175,	"macr",
209,	8212,	"mdash",
181,	181,	"micro",
225,	183,	"middot",
0,	8722,	"minus",
0,	924,	"Mu",
0,	956,	"mu",
0,	8711,	"nabla",
202,	160,	"nbsp",
208,	8211,	"ndash",
173,	8800,	"ne",
0,	8715,	"ni",
194,	172,	"not",
0,	8713,	"notin",
0,	8836,	"nsub",
150,	241,	"ntilde",
132,	209,	"Ntilde",
0,	957,	"nu",
0,	925,	"Nu",
151,	243,	"oacute",
238,	211,	"Oacute",
153,	244,	"ocirc",
239,	212,	"Ocirc",
207,	339,	"oelig",
206,	338,	"OElig",
152,	242,	"ograve",
241,	210,	"Ograve",
0,	8254,	"oline",
0,	969,	"omega",
189,	937,	"Omega",
0,	959,	"omicron",
0,	927,	"Omicron",
0,	8853,	"oplus",
0,	8744,	"or",
187,	170,	"ordf",
188,	186,	"ordm",
191,	248,	"oslash",
175,	216,	"Oslash",
155,	245,	"otilde",
205,	213,	"Otilde",
0,	8855,	"otimes",
154,	246,	"ouml",
133,	214,	"Ouml",
166,	182,	"para",
182,	8706,	"part",
228,	8240,	"permil",
0,	8869,	"perp",
0,	966,	"phi",
0,	934,	"Phi",
185,	960,	"pi",
0,	928,	"Pi",
0,	982,	"piv",
177,	177,	"plusmn",
163,	163,	"pound",
0,	8242,	"prime",
0,	8243,	"Prime",
184,	8719,	"prod",
0,	8733,	"prop",
0,	968,	"psi",
0,	936,	"Psi",
34,	34,	"quot",
195,	8730,	"radic",
0,	9002,	"rang",
200,	187,	"raquo",
0,	8594,	"rarr",
0,	8658,	"rArr",
0,	8969,	"rceil",
211,	8221,	"rdquo",
0,	8476,	"real",
168,	174,	"reg",
0,	8971,	"rfloor",
0,	961,	"rho",
0,	929,	"Rho",
0,	8207,	"rlm",
221,	8250,	"rsaquo",
213,	8217,	"rsquo",
226,	8218,	"sbquo",
0,	353,	"scaron",
0,	352,	"Scaron",
0,	8901,	"sdot",
164,	167,	"sect",
0,	173,	"shy",
0,	963,	"sigma",
0,	931,	"Sigma",
0,	962,	"sigmaf",
0,	8764,	"sim",
0,	9824,	"spades",
0,	8834,	"sub",
0,	8838,	"sube",
183,	8721,	"sum",
0,	8835,	"sup",
0,	185,	"sup1",
0,	178,	"sup2",
0,	179,	"sup3",
0,	8839,	"supe",
167,	223,	"szlig",
0,	964,	"tau",
0,	932,	"Tau",
0,	8756,	"there4",
0,	952,	"theta",
0,	920,	"Theta",
0,	977,	"thetasym",
0,	8201,	"thinsp",
0,	254,	"thorn",
0,	222,	"THORN",
247,	732,	"tilde",
0,	215,	"times",
170,	8482,	"trade",
156,	250,	"uacute",
242,	218,	"Uacute",
0,	8593,	"uarr",
0,	8657,	"uArr",
158,	251,	"ucirc",
243,	219,	"Ucirc",
157,	249,	"ugrave",
244,	217,	"Ugrave",
172,	168,	"uml",
0,	978,	"upsih",
0,	965,	"upsilon",
0,	933,	"Upsilon",
159,	252,	"uuml",
134,	220,	"Uuml",
0,	8472,	"weierp",
0,	958,	"xi",
0,	926,	"Xi",
0,	253,	"yacute",
0,	221,	"Yacute",
180,	165,	"yen",
0,	921,	"Iota",
216,	255,	"yuml",
217,	376,	"Yuml",
0,	950,	"zeta",
0,	918,	"Zeta",
0,	8205,	"zwj",
0,	8204,	"zwnj",
219,128,"euro",
226,130,"sbquo",
196,131,"fnof",
227,132,"bdquo",
201,133,"hellip",
160,134,"dagger",
224,135,"Dagger",
246,136,"circ",
228,137,"permil",
0,138,"Scaron",
220,139,"lsaquo",
206,140,"OElig",
0,142,"#142",
212,145,"lsquo",
213,146,"rsquo",
210,147,"ldquo",
211,148,"rdquo",
165,149,"bull",
208,150,"ndash",
209,151,"mdash",
247,152,"tilde",
170,153,"trade",
0,154,"scaron",
221,155,"rsaquo",
207,156,"oelig",
0,158,"#158",
217,159,"Yuml",
};
//#elif __UNIX_XLIB__ || __WIN_XLIB__
IsoEntity	theUnixIsoEntity[TOT_ISO_ENTITIES] = 
{
// Unix Code (0-255) - Iso Code 0(64258) - Entity (max 8 chars)
// Rule: Lower case is followed by Upper case if this exists

// Problem on Unix, some native code are > 255 !!!

729,	729,	"#729",
8710,	8710,	"#8710",
63743,	63743,	"#63743",
64257,	64257,	"#64257",
64258,	64258,	"#64258",
730,	730,	"#730",
731,	731,	"#731",
305,	305,	"#305",
711,	711,	"#711",
733,	733,	"#733",
728,	728,	"#728",
225,	225,	"aacute",
193,	193,	"Aacute",
226,	226,	"acirc",
194,	194,	"Acirc",
180,	180,	"acute",
198,	198,	"AElig",
230,	230,	"aelig",
224,	224,	"agrave",
192,	192,	"Agrave",
8501,	8501,	"alefsym",
945,	945,	"alpha",
913,	913,	"Alpha",
38,		38,		"amp",
8743,	8743,	"and",
8736,	8736,	"ang",
229,	229,	"aring",
197,	197,	"Aring",
8776,	8776,	"asymp",
227,	227,	"atilde",
195,	195,	"Atilde",
228,	228,	"auml",
196,	196,	"Auml",
132,	8222,	"bdquo",
946,	946,	"beta",
914,	914,	"Beta",
166,	166,	"brvbar",
149,	8226,	"bull",
8745,	8745,	"cap",
231,	231,	"ccedil",
199,	199,	"Ccedil",
184,	184,	"cedil",
162,	162,	"cent",
967,	967,	"chi",
935,	935,	"Chi",
136,	710,	"circ",
9827,	9827,	"clubs",
8773,	8773,	"cong",
169,	169,	"copy",
8629,	8629,	"crarr",
8746,	8746,	"cup",
164,	164,	"curren",
134,	8224,	"dagger",
135,	8225,	"Dagger",
8595,	8595,	"darr",
8659,	8659,	"dArr",
176,	176,	"deg",
948,	948,	"delta",
916,	916,	"Delta",
9830,	9830,	"diams",
247,	247,	"divide",
233,	233,	"eacute",
201,	201,	"Eacute",
234,	234,	"ecirc",
202,	202,	"Ecirc",
232,	232,	"egrave",
200,	200,	"Egrave",
8709,	8709,	"empty",
8195,	8195,	"emsp",
8194,	8194,	"ensp",
949,	949,	"epsilon",
917,	917,	"Epsilon",
8801,	8801,	"equiv",
951,	951,	"eta",
919,	919,	"Eta",
208,	208,	"ETH",
240,	240,	"eth",
235,	235,	"euml",
203,	203,	"Euml",
128,	8364,	"euro",
128,	128,	"euro",
8707,	8707,	"exist",
131,	402,	"fnof",
8704,	8704,	"forall",
189,	189,	"frac12",
188,	188,	"frac14",
190,	190,	"frac34",
8260,	8260,	"frasl",
947,	947,	"gamma",
915,	915,	"Gamma",
8805,	8805,	"ge",
62,		62,		"gt",
8596,	8596,	"harr",
8660,	8660,	"hArr",
9829,	9829,	"hearts",
133,	8230,	"hellip",
237,	237,	"iacute",
205,	205,	"Iacute",
238,	238,	"icirc",
206,	206,	"Icirc",
161,	161,	"iexcl",
236,	236,	"igrave",
204,	204,	"Igrave",
8465,	8465,	"image",
8734,	8734,	"infin",
8747,	8747,	"int",
953,	953,	"iota",
191,	191,	"iquest",
8712,	8712,	"isin",
239,	239,	"iuml",
207,	207,	"Iuml",
954,	954,	"kappa",
922,	922,	"Kappa",
955,	955,	"lambda",
923,	923,	"Lambda",
9001,	9001,	"lang",
171,	171,	"laquo",
8656,	8656,	"lArr",
8592,	8592,	"larr",
8968,	8968,	"lceil",
147,	8220,	"ldquo",
8804,	8804,	"le",
8970,	8970,	"lfloor",
8727,	8727,	"lowast",
9674,	9674,	"loz",
8206,	8206,	"lrm",
139,	8249,	"lsaquo",
145,	8216,	"lsquo",
60,		60,		"lt",
175,	175,	"macr",
151,	8212,	"mdash",
181,	181,	"micro",
183,	183,	"middot",
8722,	8722,	"minus",
924,	924,	"Mu",
956,	956,	"mu",
8711,	8711,	"nabla",
160,	160,	"nbsp",
150,	8211,	"ndash",
8800,	8800,	"ne",
8715,	8715,	"ni",
172,	172,	"not",
8713,	8713,	"notin",
8836,	8836,	"nsub",
241,	241,	"ntilde",
209,	209,	"Ntilde",
957,	957,	"nu",
925,	925,	"Nu",
243,	243,	"oacute",
211,	211,	"Oacute",
244,	244,	"ocirc",
212,	212,	"Ocirc",
156,	339,	"oelig",
140,	338,	"OElig",
242,	242,	"ograve",
210,	210,	"Ograve",
8254,	8254,	"oline",
969,	969,	"omega",
937,	937,	"Omega",
959,	959,	"omicron",
927,	927,	"Omicron",
8853,	8853,	"oplus",
8744,	8744,	"or",
170,	170,	"ordf",
186,	186,	"ordm",
248,	248,	"oslash",
216,	216,	"Oslash",
245,	245,	"otilde",
213,	213,	"Otilde",
8855,	8855,	"otimes",
246,	246,	"ouml",
214,	214,	"Ouml",
182,	182,	"para",
8706,	8706,	"part",
137,	8240,	"permil",
8869,	8869,	"perp",
966,	966,	"phi",
934,	934,	"Phi",
960,	960,	"pi",
928,	928,	"Pi",
982,	982,	"piv",
177,	177,	"plusmn",
163,	163,	"pound",
8242,	8242,	"prime",
8243,	8243,	"Prime",
8719,	8719,	"prod",
8733,	8733,	"prop",
968,	968,	"psi",
936,	936,	"Psi",
34,		34,		"quot",
8730,	8730,	"radic",
9002,	9002,	"rang",
187,	187,	"raquo",
8594,	8594,	"rarr",
8658,	8658,	"rArr",
8969,	8969,	"rceil",
148,	8221,	"rdquo",
8476,	8476,	"real",
174,	174,	"reg",
8971,	8971,	"rfloor",
961,	961,	"rho",
929,	929,	"Rho",
8207,	8207,	"rlm",
155,	8250,	"rsaquo",
146,	8217,	"rsquo",
130,	8218,	"sbquo",
154,	353,	"scaron",
138,	352,	"Scaron",
8901,	8901,	"sdot",
167,	167,	"sect",
173,	173,	"shy",
963,	963,	"sigma",
931,	931,	"Sigma",
962,	962,	"sigmaf",
8764,	8764,	"sim",
9824,	9824,	"spades",
8834,	8834,	"sub",
8838,	8838,	"sube",
8721,	8721,	"sum",
8835,	8835,	"sup",
185,	185,	"sup1",
178,	178,	"sup2",
179,	179,	"sup3",
8839,	8839,	"supe",
223,	223,	"szlig",
964,	964,	"tau",
932,	932,	"Tau",
8756,	8756,	"there4",
952,	952,	"theta",
920,	920,	"Theta",
977,	977,	"thetasym",
8201,	8201,	"thinsp",
254,	254,	"thorn",
222,	222,	"THORN",
152,	732,	"tilde",
215,	215,	"times",
153,	8482,	"trade",
250,	250,	"uacute",
218,	218,	"Uacute",
8593,	8593,	"uarr",
8657,	8657,	"uArr",
251,	251,	"ucirc",
219,	219,	"Ucirc",
249,	249,	"ugrave",
217,	217,	"Ugrave",
168,	168,	"uml",
978,	978,	"upsih",
965,	965,	"upsilon",
933,	933,	"Upsilon",
252,	252,	"uuml",
220,	220,	"Uuml",
8472,	8472,	"weierp",
958,	958,	"xi",
926,	926,	"Xi",
253,	253,	"yacute",
221,	221,	"Yacute",
165,	165,	"yen",
921,	921,	"Iota",
255,	255,	"yuml",
159,	376,	"Yuml",
950,	950,	"zeta",
918,	918,	"Zeta",
8205,	8205,	"zwj",
8204,	8204,	"zwnj",
130,130,"sbquo",
131,131,"fnof",
132,132,"bdquo",
133,133,"hellip",
134,134,"dagger",
135,135,"Dagger",
136,136,"circ",
137,137,"permil",
138,138,"Scaron",
139,139,"lsaquo",
140,140,"OElig",
142,142,"#142",
145,145,"lsquo",
146,146,"rsquo",
147,147,"ldquo",
148,148,"rdquo",
149,149,"bull",
150,150,"ndash",
151,151,"mdash",
152,152,"tilde",
153,153,"trade",
154,154,"scaron",
155,155,"rsaquo",
156,156,"oelig",
158,158,"#158",
159,159,"Yuml"
};
//#endif
#endif	// __XLIB_WITH_HELPERS__

	// ... qui
	if not(err = _CreateIsoLists(theMacIsoEntity, CHARSET_MAC))
		err = _CreateIsoLists(theUnixIsoEntity, CHARSET_UNIX);
	
	// HTML List
	if NOT(err)
	{	if NOT(err = DLM_Create(&gsHTMLTagsList, NAME_LIST, LOCAL_LIST))
		{	for (i = 0; (i < HTMLTAGS_ARRAYDIM) && NOT(err); i++)
				DLM_NewObj(gsHTMLTagsList, htmlName[i], "", 0, 0, kFixedSize, &err);
		}
	}
	
return err;
}

//===========================================================================================
// Check if <input type etc... is of type TEXT
static Boolean _IsTypeTEXT(Ptr tempP, long len)
{
Boolean	isInputText = false;

	if (len > 0)
	{
		do {
			if ((len > 3) && ((*(long*)tempP == TYPE_LOW_TAG) || (*(long*)tempP == TYPE_UPPER_TAG)))
			{	tempP += 4;
				len -= 4;
				if (len > 0)
				{	do {
						if ((len > 3) && ((*(long*)tempP == TEXT_LOW_TAG) || (*(long*)tempP == TEXT_UPPER_TAG)))
						{	tempP += 4;
							len -= 4;
							isInputText = true;
							goto out;
						}
						tempP++;
						len--;
					} while(len > 0);
				}
			}
			tempP++;
			len--;
		} while (len > 0);
	}
	
out:
return isInputText;
}

//===========================================================================================
// skip the section value = ", consider \" ... \"
static void	_SkipUntilGreaterExt(Ptr *tempPPtr, long *lenPtr)
{
long	len = *lenPtr;
Ptr		tempP = *tempPPtr;
Boolean	inCommas = false;

	if (len && (*tempP != '>'))
	{	do {
			if (*tempP == '\"')
				inCommas = NOT(inCommas);
			else if (NOT(inCommas) && (*tempP == '>'))
			{	tempP++;
				len--;
				break;
			}
			tempP++;
			len--;
		} while(len && (*tempP != '>'));
	}
	if (len && (*tempP == '>'))
	{	tempP++;
		len--;
	}

*lenPtr = len;
*tempPPtr = tempP;
}

//===========================================================================================
// skip the section value = "
static void	_SkipUntilGreater(Ptr *tempPPtr, long *lenPtr)
{
long	len = *lenPtr;
Ptr		tempP = *tempPPtr;

	if (len && (*tempP != '>'))
	{	do {
			tempP++;
			len--;
			} while(len && (*tempP != '>'));
	}
	if (len && (*tempP == '>'))
	{	tempP++;
		len--;
	}

*lenPtr = len;
*tempPPtr = tempP;
}

//===========================================================================================
// skip the section value = "
static Boolean	_SkipUntilValue(Ptr *tempPPtr, long *lenPtr)
{
long	len = *lenPtr;
Ptr		tempP = *tempPPtr;
Boolean	commas = false;

	if (len > 0) 
	{	SkipSpaceAndTab(&tempP, &len);
		if (len && (*tempP == '='))
		{	tempP++;
			len--;
		}
		SkipSpaceAndTab(&tempP, &len);
		if (len && (*tempP == '\"'))
		{	commas = true;
			tempP++;
			len--;
		}
		*lenPtr = len;
		*tempPPtr = tempP;
	}
return commas;
}

//===========================================================================================
// Note that in forms elements like: 
// input type="TEXT" name = "name" value="value"> the only part
// to encode is the value argument
static XErr	_AddValueArgument(Ptr *tempPPtr, long *lenPtr, Boolean commas, long resBuffID, int charset)
{
long	len = *lenPtr;
Ptr		tempP = *tempPPtr;
Byte	ch;
XErr	err = noErr;
Str15	numStr;

	if (len > 0)
	{	do {
			ch = *tempP;
			if ((commas && (ch == '\"')) || (NOT(commas) && (ch == ' ')))
				break;
			else
			{	if (ch < 0x80)
				{	if (err = BufferAddChar(resBuffID, ch))
						break;
				}
				else
				{	if NOT(err = BufferAddCString(resBuffID, "&#", NO_ENC, 0))
					{	PNumToString(_GetIsoFromNative(ch, 0, charset), numStr);
						if NOT(BufferAddPString(resBuffID, numStr, NO_ENC, 0))
						{	if (err = BufferAddChar(resBuffID, ';'))
								break;
						}
					}
				}
			}
			tempP++;
			len--;							
		} while (len);
	}

*lenPtr = len;
*tempPPtr = tempP;	
return err;
}

//===========================================================================================
// Process string when an < char is encountered
static XErr	_SkipHTML(Ptr *stringP, long *stringLenP, Boolean *isHTMLTagP)
{
Ptr			tempP;
long		len;
CStr63		tagCStr;
XErr		err = noErr;

	if (isHTMLTagP)
		*isHTMLTagP = false;
	tempP = *stringP;
	len = *stringLenP;
	
	if (_GetNextObjectName(tempP, len, tagCStr, sizeof(Str63) - 1, nil))
	{	CUp2LowerStr(tagCStr, 0);
		if (DLM_GetObjID(gsHTMLTagsList, tagCStr, nil, nil))	// is an html tag
		{	// cs (is lower)
			_SkipUntilGreater(&tempP, &len);
			*stringP = tempP;
			*stringLenP = len;
			if (isHTMLTagP)
				*isHTMLTagP = true;
		}
	}
//out:
return err;
}

//===========================================================================================
// Process string when an < char is encountered
static XErr	_FilterHTMLTag(long resBuffID, Ptr *stringP, long *stringLenP, Boolean *isHTMLTagP, Boolean extTags, DLMRef tagList, int charset)
{
Ptr		saveTempP, tempP;
long	tagCStrLen, len, htmlID = 0;
CStr63	tagCStr;
XErr	err = noErr;
Boolean	found = false, commas;

	*isHTMLTagP = false;
	tempP = *stringP;
	len = *stringLenP;
	
	if (_GetNextObjectName(tempP, len, tagCStr, sizeof(Str63) - 1, nil))
	{	tagCStrLen = CLen(tagCStr);
		if (tagCStr[--tagCStrLen] == '/') 	// self closed tags
			tagCStr[tagCStrLen] = 0;
		CUp2LowerStr(tagCStr, 0);
		if ((htmlID = DLM_GetObjID(tagList, tagCStr, nil, nil)) || extTags)	// is an html tag
		{	// cs (is lower)
			if (htmlID && NOT(CCompareStrings(tagCStr, "input")) && resBuffID && (_IsTypeTEXT(tempP, len)))			// input
			{	// encode only part inside: value = "..."
				if (len)
				{	do {
						if (Begins(tempP, len, "value", 5) || Begins(tempP, len, "VALUE", 5) || Begins(tempP, len, "Value", 5))
						{	tempP += 5;
							len -= 5;
							commas = _SkipUntilValue(&tempP, &len);
							// Add all until here
							if (err = BufferAddChar(resBuffID, '<'))
								goto out;
							if (err = BufferAddBuffer(resBuffID,*stringP,(tempP - *stringP)))
								goto out;
							if (err = _AddValueArgument(&tempP, &len, commas, resBuffID, charset))
								goto out;
							saveTempP = tempP;
							_SkipUntilGreater(&tempP, &len);
							err = BufferAddBuffer(resBuffID, saveTempP, (tempP - saveTempP));
							found = true;
							break;
						}
						else
						{	tempP++;
							len--;
						}
					} while((len > 0) && (*tempP != '>'));
					if NOT(found)
					{	if NOT(err = BufferAddChar(resBuffID, '<'))
							err = BufferAddBuffer(resBuffID, *stringP, (tempP - *stringP));
					}
				}	
			}
			else
			{	_SkipUntilGreater(&tempP, &len);
				if (resBuffID)
				{	if NOT(err = BufferAddChar(resBuffID, '<'))
						err = BufferAddBuffer(resBuffID, *stringP, (tempP - *stringP));
				}
			}
			*stringP = tempP;
			*stringLenP = len;
			*isHTMLTagP = true;
		}
	}
out:
return err;
}

//===========================================================================================
XErr	_EncodeESA(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, Boolean spaceToPlus, char *preStr, long options)
{
XErr		err = noErr;
int			ch;
long		resBuffID, lenToAdd;
Byte		hexDigit[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
Ptr			pToAdd;
int			charset = gCharset;
	
	*resultStringHP = nil;
	*resultLenP = 0;
	if ((resBuffID = BufferCreate(ONE_BLOCK_1K, &err)) <= 0)
		return err;
	if NOT(stringLen)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
			return noErr;
		}
	}

	lenToAdd = 0;
	pToAdd = (Ptr)stringP;
	do	{
		ch = *stringP++;
		stringLen--;
		if (spaceToPlus && (ch == ' '))
		{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
			err = BufferAddChar(resBuffID, '+');
			pToAdd = (Ptr)stringP;
			lenToAdd = 0;
		}
		else if (((ch <= 'z') && ((ch >= 'a') || (ch <= 'Z') && ((ch >= 'A') || (ch <= '9') && (ch >= '0')))) /*|| (ch == '/') || (ch == ':')*/)
		{	lenToAdd++;
			// err = BufferAddChar(resBuffID, ch);
		}
		else
		{	if ((options == LIGHT_ENCODE) && ((ch == '/') || (ch == '.') || (ch == '_')))
				lenToAdd++;
			else
			{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
				if (preStr && *preStr)
					err = BufferAddCString(resBuffID, preStr/*"\\x"*/, NO_ENC, 0);
				else
					err = BufferAddChar(resBuffID, '%');
				if NOT(err)
				{	Byte	nib1, nib2, nib3, nib4;
				
					if (ch > 0x80)
						ch = _GetIsoFromNative((Byte)ch, 1, charset);
					if (ch <= 255)
					{	nib1 = (ch & 0xF0) >> 4;
						nib2 = ch & 0x0F;
						if NOT(err = BufferAddChar(resBuffID, hexDigit[nib1]));
							err = BufferAddChar(resBuffID, hexDigit[nib2]);
					}
					else
					{	nib1 = (ch & 0xF000) >> 12;
						nib2 = (ch & 0x0F00) >> 8;
						nib3 = (ch & 0x00F0) >> 4;
						nib4 = ch & 0x000F;
						if NOT(err = BufferAddChar(resBuffID, hexDigit[nib1]))
						{	if NOT(err = BufferAddChar(resBuffID, hexDigit[nib2]))
							{	if NOT(err = BufferAddChar(resBuffID, hexDigit[nib3]))
									err = BufferAddChar(resBuffID, hexDigit[nib4]);
							}
						}
					}
						// ex ch = deConvCh[ch-0x80];
				}
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
			}
		}
	} while((stringLen > 0) && NOT(err));
	
	if NOT(err)
	{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
		if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
		}
		else
			BufferFree(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

//===========================================================================================
static XErr	_DecodeESA(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, 
														Boolean plusToSpace, char *preStr, int charset)
{
XErr		err = noErr;
Byte		ch;
long		resBuffID, lenToAdd;
Ptr			pToAdd;

	*resultStringHP = nil;
	*resultLenP = 0;
	if ((resBuffID = BufferCreate(ONE_BLOCK_1K, &err)) <= 0)
		return err;
	if NOT(stringLen)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
			return noErr;
		}
	}

	lenToAdd = 0;
	pToAdd = (Ptr)stringP;
	if (preStr && *preStr)
	{	long	preStrLen = CLen(preStr);
		do	{
			// if ((ch == *preStr) && ((preStrLen == 1) || ())			// stringLen && (*stringP == 'x')))
			if ((stringLen >= preStrLen) && NOT(CompareBlock(preStr, stringP, preStrLen)))
			{	stringP += preStrLen;
				stringLen -= preStrLen;
				BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
				if (stringLen >= sizeof(short))
				{	err = BufferAddChar(resBuffID, _Local_HexStringToChar(*(short*)stringP, true, charset));
					stringP += 2;
					stringLen -= 2;
				}
				else
					err = BufferAddChar(resBuffID, '?');
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
			}
			else
			{	lenToAdd++;
				stringP++;
				stringLen--;
			}
		} while((stringLen > 0) && NOT(err));
	}
	else
	{	do	{
			ch = *stringP++;
			stringLen--;
			if (ch == '%')
			{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
				if (stringLen >= sizeof(short))
				{	err = BufferAddChar(resBuffID, _Local_HexStringToChar(*(short*)stringP, true, charset));
					stringP += 2;
					stringLen -= 2;
				}
				else
					err = BufferAddChar(resBuffID, '?');
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
			}
			else if (plusToSpace && (ch == '+'))
			{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
				err = BufferAddChar(resBuffID, ' ');
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
			}
			else
				lenToAdd++;
		} while((stringLen > 0) && NOT(err));
	}
	
	if NOT(err)
	{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
		if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
		}
		else
			BufferFree(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

//===========================================================================================
/*
*	in len must be get with CLen, the in string must be a 0-terminated
*	as the out string
*/
static XErr	_DecodeESAFast(char *readP, Boolean plusToSpace, char *preStr, long *resultLenP, int charset)
{
XErr		err = noErr;
Byte		ch;
char		*writeP, *saveP;
long		readLen;

	readLen = CLen(readP);
	if NOT(readLen)
	{	if (resultLenP)
			*resultLenP = 0;
		return noErr;
	}
	writeP = saveP = readP;
	if (preStr && *preStr)
	{	long	preStrLen = CLen(preStr);
		do	{
			if ((readLen >= preStrLen) && NOT(CompareBlock(preStr, readP, preStrLen)))
			{	readP += preStrLen;
				readLen -= preStrLen;
				if (readLen >= sizeof(short))
					*writeP++ = _Local_HexStringToChar(*(short*)readP, true, charset);
				else
					*writeP++ = '?';
				readP += 2;
				readLen -= 2;
			}
			else
			{	*writeP++ = *readP++;
				readLen--;
			}
		} while((readLen > 0) && NOT(err));
	}
	else
	{	do	{
			ch = *readP++;
			readLen--;
			if (ch == '%')
			{	if (readLen >= sizeof(short))
					*writeP++ = _Local_HexStringToChar(*(short*)readP, true, charset);
				else
					*writeP++ = '?';
				readP += 2;
				readLen -= 2;
			}
			else if (plusToSpace && (ch == '+'))
				*writeP++ = ' ';
			else
				*writeP++ = ch;
		} while((readLen > 0) && NOT(err));
	}
	
	if NOT(err)
	{	*writeP = 0;
		if (resultLenP)
			*resultLenP = writeP - saveP;
	}
		
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	SetCharacterSetGlobal(int charset)
{
	gCharset = charset;
}

//===========================================================================================
int	GetCharacterSetGlobal(int charset)
{
	return charset;
}

//===========================================================================================
void	TextMgr_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{

	xlibCallBacksRecPtr->HexStringToChar = (long)HexStringToChar;
	xlibCallBacksRecPtr->EncodeIsolatin = (long)EncodeIsolatin;
	xlibCallBacksRecPtr->DecodeIsolatin = (long)DecodeIsolatin;
	xlibCallBacksRecPtr->DecodeIsolatinFast = (long)DecodeIsolatinFast;
	xlibCallBacksRecPtr->EncodeURL = (long)EncodeURL;
	xlibCallBacksRecPtr->DecodeURL = (long)DecodeURL;
	xlibCallBacksRecPtr->DecodeURLFast = (long)DecodeURLFast;
	//xlibCallBacksRecPtr->EncodeEsa = (long)EncodeEsa;
	//xlibCallBacksRecPtr->DecodeEsa = (long)DecodeEsa;
	xlibCallBacksRecPtr->OffsetsInText = (long)OffsetsInText;
	xlibCallBacksRecPtr->HiliteInText = (long)HiliteInText;
	xlibCallBacksRecPtr->SubstituteExt = (long)SubstituteExt;
	xlibCallBacksRecPtr->FindStringInText = (long)FindStringInText;
	xlibCallBacksRecPtr->FindStringInTextSkipInside = (long)FindStringInTextSkipInside;
	xlibCallBacksRecPtr->Encode_UTF = (long)Encode_UTF;
	xlibCallBacksRecPtr->Decode_UTF = (long)Decode_UTF;
	xlibCallBacksRecPtr->HTML2Txt = (long)HTML2Txt;
	xlibCallBacksRecPtr->IsoToNative = (long)IsoToNative;
	xlibCallBacksRecPtr->NativeToIso = (long)NativeToIso;

	xlibCallBacksRecPtr->Capitalize = (long)Capitalize;
	xlibCallBacksRecPtr->CUp2LowerStr = (long)CUp2LowerStr;
	xlibCallBacksRecPtr->CLow2UpperStr = (long)CLow2UpperStr;
	xlibCallBacksRecPtr->PUp2LowerStr = (long)PUp2LowerStr;
	xlibCallBacksRecPtr->PLow2UpperStr = (long)PLow2UpperStr;
	xlibCallBacksRecPtr->CharToLower = (long)CharToLower;
	xlibCallBacksRecPtr->CharToUpper = (long)CharToUpper;
}

//===========================================================================================
// must return XErr (see the XLIbClient version)
XErr	IsoToNative(Ptr textP, long len)
{
register unsigned char ch;
int			charset = gCharset;

	if (len)
	{	do {
			ch = *textP;
			if (ch >= 0x80)
				*textP = _GetNativeFromIso(ch, charset);	//convCh[ch-0x80];
			textP++;
			len--;
			} while (len > 0);
	}

return noErr;
}

//===========================================================================================
// must return XErr (see the XLIbClient version)
XErr	NativeToIso(Ptr textP, long len)
{
register unsigned char ch;
int			charset = gCharset;

	if (len)
	{	do {
			ch = *textP;
			if (ch >= 0x80)
				*textP = _GetIsoFromNative(ch, 1, charset);	//convCh[ch-0x80];
			textP++;
			len--;
			} while (len > 0);
	}

return noErr;
}

//===========================================================================================
XErr	InitTextUtils(void)
{
XErr	err = noErr;

	XThreadsEnterCriticalSection();
	err = _InitTextManagerLists();
	/*if NOT(err = _InitTextManagerList(&gsHTMLTagsList, HTML_TAGS, NAME_LIST))
	{	if NOT(err = _InitTextManagerList(&gsHTMLIsoLettersList, ISOCHARS_TAG, NAMECS_LIST))
			err = _InitTextManagerList(&gsHTMLIsoLettersInverseList, ISOCHARS_TAG_INVERSE, NAMECS_LIST);
	}*/
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	EndTextUtils(void)
{
XErr	err = noErr;

	XThreadsEnterCriticalSection();
	
	DLM_Dispose(&gsHTMLTagsList, nil, 0);
	
	DLM_Dispose(&gsUnixNativeFromIso, nil, 0);
	DLM_Dispose(&gsUnixIsoFromNative, nil, 0);
	DLM_Dispose(&gsUnixEntityFromNative, nil, 0);
	DLM_Dispose(&gsUnixNativeFromEntity, nil, 0);
	
	DLM_Dispose(&gsMacNativeFromIso, nil, 0);
	DLM_Dispose(&gsMacIsoFromNative, nil, 0);
	DLM_Dispose(&gsMacEntityFromNative, nil, 0);
	DLM_Dispose(&gsMacNativeFromEntity, nil, 0);
	
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
/*XErr	GetIsoChars(BlockRef *resultStringHP, long *resultLenP)
{
long		resBuffID;
int			j;
XErr		err = noErr;
CStr15		numStr;//, macCharStr;
CStr255		finalStr;
//int			numChars;

	if ((resBuffID = BufferCreate(ONE_BLOCK_1K, &err)) <= 0)
		return err;
	for (j = 0; (j < 62) && NOT(err); j++)
	{	*finalStr = isoChar[j];
		finalStr[1] = 0;
		CAddStr(finalStr, " (");
		CNumToString(isoChar[j], numStr);
		CAddStr(finalStr, numStr);
		CAddStr(finalStr, "), ");
		err = BufferAddCString(resBuffID, finalStr, NO_ENC, 0);
	}
	
	if NOT(err)
		*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
	
return err;
}
*/

//===========================================================================================
/*static Boolean	_IsTag(DLMRef tagList, Ptr tempP, long len, Boolean extTags)
{
CStr63		tagCStr;
Boolean		res;

	if (_GetNextObjectName(tempP, len, tagCStr, sizeof(Str63) - 1, nil))
	{	if (DLM_GetObjID(tagList, tagCStr, nil, nil) || extTags)
			res = true;
		else
			res = false;
	}
	else
		res = false;
		
return res;
}*/

//===========================================================================================
XErr	EncodeIsolatin(Byte *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP, Boolean alsoCR, Boolean tagsVisible, Boolean useNames, Boolean extTags, long userTagList)
{
XErr			err = noErr;
Byte			ch, oldCh;
Str15			numStr;
CStr15			cnumStr;
long			toAdvance, resBuffID, lenToAdd;
Boolean			isHtmlTag;
Ptr				pToAdd;
DLMRef			tagList;
	int			charset = gCharset;

	if NOT(gsHTMLTagsList)
		return XError(kXHelperError, TextUtils_Err_NotInitialized);

	*resultStringHP = nil;
	*resultLenP = 0;

	if (userTagList)
		tagList = (DLMRef)userTagList;
	else
		tagList = gsHTMLTagsList;
	
	if ((resBuffID = BufferCreate(ONE_BLOCK_1K, &err)) <= 0)
		return err;

	if NOT(stringLen)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
			return noErr;
		}
	}
	oldCh = 0;
	lenToAdd = 0;
	pToAdd = (Ptr)stringP;
	do	{
		if (alsoCR && IsNewLine((Ptr)stringP, stringLen, &toAdvance))
		{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd + toAdvance);
			if (err = BufferAddCString(resBuffID, "<br>", NO_ENC, 0))
				break;
			stringP += toAdvance;
			stringLen -= toAdvance;
			pToAdd = (Ptr)stringP;
			lenToAdd = 0;
			if NOT(stringLen)
				break;
		}
		ch = *stringP++;
		stringLen--;
		switch(ch)
		{
			case '\"':
				BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
				if (useNames)
					err = BufferAddCString(resBuffID, "&quot;", NO_ENC, 0);
				else
					err = BufferAddCString(resBuffID, "&#34;", NO_ENC, 0);
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
				break;
			
			case '<':
				BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
				if (tagsVisible || (ch == oldCh))					// tags visible or '<<'
				{	if (useNames)
						err = BufferAddCString(resBuffID, "&lt;", NO_ENC, 0);
					else
						err = BufferAddCString(resBuffID, "&#60;", NO_ENC, 0);
				}
				else
				{	// if tag HTML, put until '>' 
					err = _FilterHTMLTag(resBuffID, (Ptr*)&stringP, &stringLen, &isHtmlTag, extTags, tagList, charset);
					if NOT(err)
					{	if (isHtmlTag)
							oldCh = ch = *(stringP-1);							// last char
						else
						{	if (useNames)
								err = BufferAddCString(resBuffID, "&lt;", NO_ENC, 0);	// '<'
							else
								err = BufferAddCString(resBuffID, "&#60;", NO_ENC, 0);	// '<'
						}				
					}
				}
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
				break;
				
			case '>':
				BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
				if (useNames)
					err = BufferAddCString(resBuffID, "&gt;", NO_ENC, 0);				// '>'
				else
					err = BufferAddCString(resBuffID, "&#62;", NO_ENC, 0);				// '>'
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
				break;

			case '&':
				if (NOT(tagsVisible) && (stringLen && ((*stringP == '#') /*|| extTags*/ || _IsEntity((Ptr)stringP, stringLen, charset))))
					lenToAdd++;
				else
				{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
					if (useNames)
						err = BufferAddCString(resBuffID, "&amp;", NO_ENC, 0);			// '&'
					else
						err = BufferAddCString(resBuffID, "&#38;", NO_ENC, 0);			// '&'
					pToAdd = (Ptr)stringP;
					lenToAdd = 0;
				}
				break;

			case '#':
				if (tagsVisible)
				{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
					err = BufferAddCString(resBuffID, "&#35;", NO_ENC, 0);
					pToAdd = (Ptr)stringP;
					lenToAdd = 0;
					break;
				}
			
			default:
				if (ch < 0x80)
					lenToAdd++;
				else
				{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
					if (useNames)
					{	if NOT(err = BufferAddCString(resBuffID, "&", NO_ENC, 0))
						{	_GetEntityFromNative(ch, cnumStr, charset);
							err = BufferAddCString(resBuffID, cnumStr, NO_ENC, 0);
							if NOT(err)
								err = BufferAddChar(resBuffID, ';');
						}
					}
					else
					{	if NOT(err = BufferAddCString(resBuffID, "&#", NO_ENC, 0))
						{	PNumToString(_GetIsoFromNative(ch, 0, charset), numStr);
							err = BufferAddPString(resBuffID, numStr, NO_ENC, 0);
							if NOT(err)
								err = BufferAddChar(resBuffID, ';');
						}
					}
					pToAdd = (Ptr)stringP;
					lenToAdd = 0;
				}
				break;
		}
		oldCh = ch;
	} while((stringLen > 0) && NOT(err));
	
	if NOT(err)
	{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
		if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
		}
		else
			BufferFree(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

//===========================================================================================
XErr	DecodeIsolatin(	Byte *stringP, long stringLen, BlockRef *resultStringHP, 
						long *resultLenP, Boolean alsoCR)
{
XErr	err = noErr;
Byte	ch, *saveTempP;
Str255	numStr;
long	tagNameLen, aLong, resBuffID, i, lenToAdd;
CStr63	cStr;
Ptr		pToAdd;
	int			charset = gCharset;

	//if NOT(gsHTMLIsoLettersList)
	//	return XError(kXHelperError, TextUtils_Err_NotInitialized);

	*resultStringHP = nil;
	*resultLenP = 0;
	if ((resBuffID = BufferCreate(ONE_BLOCK_1K, &err)) <= 0)
		return err;
	if NOT(stringLen)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
			return noErr;
		}
	}

	lenToAdd = 0;
	pToAdd = (Ptr)stringP;
	do	{
		if (alsoCR && Begins(stringP, stringLen, "<p>", 3))
		{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
			if NOT(err = BufferAddCString(resBuffID, "\r\n", NO_ENC, 0))
				err = BufferAddCString(resBuffID, "\r\n", NO_ENC, 0);
			stringP += 3;
			stringLen -= 3;
			pToAdd = (Ptr)stringP;
			lenToAdd = 0;
			continue;
		}
		else if (alsoCR && (stringLen > 3) && (*(long*)stringP == BR_TAG))
		{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
			err = BufferAddCString(resBuffID, "\r\n", NO_ENC, 0);
			stringP += 4;
			stringLen -= 4;
			pToAdd = (Ptr)stringP;
			lenToAdd = 0;
			continue;
		}
		else if (stringLen && (*stringP == '&'))
		{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
			ch = *stringP;
			saveTempP = stringP;
			stringP++;
			stringLen--;
			if (*stringP == '#')
			{	stringP++;
				stringLen--;
				i = 1;
				while((stringLen > 0) && (i < 255) && (*stringP >= '0') && (*stringP <= '9'))
				{	numStr[i++] = *stringP++;
					stringLen--;
				}
				if (*stringP == ';')
				{	stringP++;
					stringLen--;
					numStr[0] = (char)--i;
					PStringToNum(numStr, &aLong);
					if (aLong >= 0x80)
						ch = _GetNativeFromIso(aLong, charset);
					else
						ch = (Byte)aLong;
					if (ch)
						err = BufferAddChar(resBuffID, ch);
					else
						goto simpAdd;
				}
				else
				{	
				simpAdd:
					err = BufferAddBuffer(resBuffID, (char*)saveTempP, stringP - saveTempP);
				}				
				pToAdd = (Ptr)stringP;
				lenToAdd = 0;
				continue;
			}
			else	// if (stringLen > MIN_ISOCHARSDIM)
					// {	// agrave, acute...
				if (_GetNextObjectName((Ptr)stringP, stringLen, cStr, sizeof(Str63) - 1, nil))
				{	Byte	nativeCh;
				
					CUp2LowerStr(cStr, 0);
					tagNameLen = CLen(cStr);
					//PascalToC(tagName, cStr);
					
					/*tLen = sizeof(Byte);
					err = DLM_GetObj(gsHTMLIsoLettersList, DLM_GetObjID(gsHTMLIsoLettersList, cStr, nil, nil), (Ptr)&ch, &tLen, 0, nil);
					if (err == XError(kXHelperError, DLM_Err_ObjectNotFound))*/
					if NOT(nativeCh = _GetNativeFromEntity(cStr, charset))
					{	err = BufferAddChar(resBuffID, ch);
						pToAdd = (Ptr)stringP;
						lenToAdd = 0;
						continue;
					}
					else if NOT(err)
					{	if NOT(err = BufferAddChar(resBuffID, nativeCh))
						{	stringP += tagNameLen;
							stringLen -= tagNameLen;
							if (*stringP == ';')
							{	stringP++;
								stringLen--;
							}
							pToAdd = (Ptr)stringP;
							lenToAdd = 0;
							continue;
						}
					}
				}
			//}
			pToAdd = (Ptr)stringP;
			lenToAdd = 0;
		}
		else
		{	lenToAdd++;
			// err = BufferAddChar(resBuffID, *stringP);
		}
		stringP++;
		stringLen--;
	} while((stringLen > 0) && NOT(err));
	
	if NOT(err)
	{	BufferAddBuffer(resBuffID, pToAdd, lenToAdd);
		if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
		}
		else
			BufferFree(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

//===========================================================================================
/*
*	in len must be get with CLen, the in string must be a 0-terminated
*	as the out string
*/
XErr	DecodeIsolatinFast(char *readP, Boolean alsoCR, long *resultLenP)
{
XErr	err = noErr;
char	ch, *writeP, *saveP, *saveTempP;
Str255	numStr;
long	tagNameLen, aLong, i;
CStr63	cStr;
long 	readLen;
	int			charset = gCharset;

	readLen = CLen(readP);
	if NOT(readLen)
	{	if (resultLenP)
			*resultLenP = 0;
		return noErr;
	}	
	writeP = saveP = readP;
	do	{
		if (alsoCR && Begins(readP, readLen, "<p>", 3))
		{	*(long*)writeP++ = CRLFCRLF;
			readP += 3;	// <p>
			readLen -= 3;
		}
		else if (alsoCR && (readLen > 3) && (*(long*)readP == BR_TAG))
		{	*(short*)writeP++ = CRLF;
			readP += 4;	// "<br>"
			readLen -= 4;
		}
		else if (readLen && (*readP == '&'))
		{	saveTempP = readP;
			ch = *readP++;
			readLen--;
			if (*readP == '#')
			{	readP++;
				readLen--;
				i = 1;
				while((readLen > 0) && (i < 255) && (*readP >= '0') && (*readP <= '9'))
				{	numStr[i++] = *readP++;
					readLen--;
				}
				if (*readP == ';')
				{	readP++;
					readLen--;
					numStr[0] = (Byte)--i;
					PStringToNum(numStr, &aLong);
					if (aLong >= 0x80)
						ch = _GetNativeFromIso(aLong, charset);
					else
						ch = (char)aLong;
					if (ch)
						*writeP++ = ch;
					else
						goto simpAdd;
				}
				else
				{   
				simpAdd:
					i = readP - saveTempP;
					CopyBlock(writeP, saveTempP, i);
					writeP += i;
				}
			}
			else if (_GetNextObjectName((Ptr)readP, readLen, cStr, sizeof(Str63) - 1, nil))
			{	Byte	nativeCh;
			
				CUp2LowerStr(cStr, 0);
				tagNameLen = CLen(cStr);
				if NOT(nativeCh = _GetNativeFromEntity(cStr, charset))
					*writeP++ = ch;
				else if NOT(err)
				{	*writeP++ = nativeCh;
					readP += tagNameLen;
					readLen -= tagNameLen;
					if (*readP == ';')
					{	readP++;
						readLen--;
					}
				}
			}
		}
		else
		{	*writeP++ = *readP++;
			readLen--;
		}
	} while((readLen > 0) && NOT(err));
	
if NOT(err)
{	*writeP = 0;
	if (resultLenP)
		*resultLenP = writeP - saveP;
}			
return err;
}

//===========================================================================================
XErr	EncodeURL(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, Boolean spaceToPlus, char *preStr)
{
	return _EncodeESA(stringP, stringLen, resultStringHP, resultLenP, spaceToPlus, preStr, 0);
}

//===========================================================================================
XErr	DecodeURL(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, Boolean plusToSpace, char *preStr)
{
	return _DecodeESA(stringP, stringLen, resultStringHP, resultLenP, plusToSpace, preStr, gCharset);
}

//===========================================================================================
XErr	DecodeURLFast(char *readP, Boolean plusToSpace, char *preStr, long *resultLenP)
{
	return _DecodeESAFast(readP, plusToSpace, preStr, resultLenP, gCharset);
}

//===========================================================================================
/*XErr	EncodeEsa(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr)
{
	return _EncodeESA(stringP, stringLen, resultStringHP, resultLenP, false, preStr);
}

//===========================================================================================
XErr	DecodeEsa(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr)
{
	return _DecodeESA(stringP, stringLen, resultStringHP, resultLenP, false, preStr);
}*/

//===========================================================================================
Boolean FindStringInText(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML)
{
register int	cnt2 = 0, tStrLen;
long			chToCheck;
Ptr				saveTextP;
	int				charset = gCharset;
	
if (offsetP)
	*offsetP = -1;
if (stringLen > textLen)
	return false;

chToCheck = textLen - stringLen + 1;

do {
	register int		ch1, ch2;
	register Byte 		*tPtr, *sPtr;

	sPtr = (Byte*)stringP;
	ch1 = *sPtr++;
	if NOT(cs)
		ch1 = _Local_CharToLower((Byte)ch1, charset);
	do { 	
	 	ch2 = *textP++;
	 	if (skipHTML && (ch2 == '<'))
	 	{	chToCheck--;
	 		cnt2++;
	 		saveTextP = textP;
	 		_SkipHTML(&textP, &chToCheck, nil);
	 		if NOT(chToCheck)
	 			break;
	 		cnt2 += textP - saveTextP;
	 		ch2 = *textP++;
	 	}
	 	cnt2++;
		if NOT(cs)
			ch2 = _Local_CharToLower((Byte)ch2, charset);
		if (ch1 == ch2)
		{	tPtr = (Byte*)textP;
			tStrLen = stringLen;
			while(--tStrLen)
			{	ch2 = *tPtr++;
				if NOT(cs)
					ch2 = _Local_CharToLower((Byte)ch2, charset);
				ch1 = *sPtr++;
				if NOT(cs)
					ch1 = _Local_CharToLower((Byte)ch1, charset);
				if (ch1 != ch2)
					goto nxt;
	 		}
			if (offsetP)
				*offsetP = cnt2;
	 		return true;
	 	}
	 } while (--chToCheck > 0);	 	
	 return false;				// not found
nxt:;
 	} while(--chToCheck > 0);
 return false;					// not found
}

//===========================================================================================
Boolean FindStringInTextSkipInside(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML, int skipInsideChar)
{
register int	cnt2 = 0, tStrLen;
long			chToCheck;
Ptr				saveTextP;
Boolean			weAreInside = false;
	int				charset = gCharset;

if (offsetP)
	*offsetP = -1;
if (stringLen > textLen)
	return false;

chToCheck = textLen - stringLen + 1;

do {
	register int		ch1, ch2;
	register Byte 		*tPtr, *sPtr;

	sPtr = (Byte*)stringP;
	ch1 = *sPtr++;
	if NOT(cs)
		ch1 = _Local_CharToLower((Byte)ch1, charset);
	do { 	
	 	ch2 = *textP++;
	 	if (ch2 == skipInsideChar)
	 		weAreInside = weAreInside ? false : true;
	 	else if (skipHTML && (ch2 == '<'))
	 	{	chToCheck--;
	 		cnt2++;
	 		saveTextP = textP;
	 		_SkipHTML(&textP, &chToCheck, nil);
	 		if NOT(chToCheck)
	 			break;
	 		cnt2 += textP - saveTextP;
	 		ch2 = *textP++;
	 	}
	 	cnt2++;
		if NOT(cs)
			ch2 = _Local_CharToLower((Byte)ch2, charset);
		if (NOT(weAreInside) && (ch1 == ch2))
		{	tPtr = (Byte*)textP;
			tStrLen = stringLen;
			while(--tStrLen)
			{	ch2 = *tPtr++;
				if NOT(cs)
					ch2 = _Local_CharToLower((Byte)ch2, charset);
				ch1 = *sPtr++;
				if NOT(cs)
					ch1 = _Local_CharToLower((Byte)ch1, charset);
				if (ch1 != ch2)
					goto nxt;
	 		}
			if (offsetP)
				*offsetP = cnt2;
	 		return true;
	 	}
	 } while (--chToCheck > 0);	 	
	 return false;				// not found
nxt:;
 	} while(--chToCheck > 0);
 return false;					// not found
}

//===========================================================================================
XErr	OffsetsInText(char *textP, long textLen, char *stringToHilite, Boolean cs, long *offsets, long *end_offsets, long *totOffsetP, long maxOffsets, Boolean skipHTML)
{
long	off, stringToHiliteLength;
XErr	err = noErr;
long	tLen, cPos, t;
int		i;

		stringToHiliteLength = CLen(stringToHilite);
		off = cPos = 0;
		tLen = textLen;
		i = 0;
		while ((tLen > 0) && NOT(err) && FindStringInText(stringToHilite, stringToHiliteLength, textP, tLen, &off, cs, skipHTML))
		{	if (i < maxOffsets)
			{	offsets[i] = off + cPos;
				end_offsets[i] = offsets[i] + stringToHiliteLength;
				i++;
			}
			t = off + stringToHiliteLength - 1;
			cPos += t;
			tLen -= t;
			textP += t;
		}
		*totOffsetP = i;

return err;
}

//===========================================================================================
static XErr	_SubstituteForHilite(Ptr textP, long textLen, BlockRef *resultStringBlockP, long *resultLenP, Ptr newString, long newStringLen)
{
XErr		err = noErr;
long		pToAddLen, encodedLen, resBuffID;
BlockRef	encoded;
Ptr			pToAdd;
short		aShort;

	*resultStringBlockP = 0;
	*resultLenP = 0;
	if NOT(resBuffID = BufferCreate(255L, &err))
		return err;
	if NOT(textLen)
	{	*resultStringBlockP = BufferGetBlockRef(resBuffID, nil);
		BufferClose(resBuffID);
		return noErr;
	}
	
	pToAddLen = 0;
	pToAdd = textP;
	while ((textLen > 0) && NOT(err))
	{	if (textLen > 1)
			aShort = *(short*)textP;
		else
			aShort = 0;
		if ((aShort == '##') || (aShort == '**') || (aShort == '$$'))
		{	BufferAddBuffer(resBuffID, pToAdd, pToAddLen);
			textP += 2;
			textLen -= 2;
			pToAddLen = 0;
			pToAdd = textP;
			switch(aShort)
			{	case '$$':
					if NOT(err = EncodeURL((Byte*)newString, newStringLen, &encoded, &encodedLen, false, nil))
					{	LockBlock(encoded);
						BufferAddBuffer(resBuffID, GetPtr(encoded), encodedLen);
						DisposeBlock(&encoded);
					}
					break;
				case '##':
					if NOT(err = EncodeIsolatin((Byte*)newString, newStringLen, &encoded, &encodedLen, false, false, false, false, 0L))
					{	LockBlock(encoded);
						BufferAddBuffer(resBuffID, GetPtr(encoded), encodedLen);
						DisposeBlock(&encoded);
					}
					break;
				case '**':
					err = BufferAddBuffer(resBuffID, newString, newStringLen);
					break;
			}
		}
		else
		{	pToAddLen++;
			textP++;
			textLen--;
		}
	}
	
	// l'ultimo pezzo
	BufferAddBuffer(resBuffID, pToAdd, pToAddLen);
	
	if NOT(err)
	{	*resultStringBlockP = BufferGetBlockRef(resBuffID, resultLenP);
		BufferClose(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

//===========================================================================================
static XErr	_AddWord(long id, long index, char *textP, long *offsets, long *end_offsets, char *preStr, long preLen, char *postStr, long postLen)
{
XErr		err = noErr;
long		tLen;
long		pBlockLen;
BlockRef	pBlock;
Ptr			strP;

	tLen = end_offsets[index] - offsets[index];
	if NOT(err = _SubstituteForHilite(preStr, preLen, &pBlock, &pBlockLen, textP + offsets[index] - 1, tLen))
	{	LockBlock(pBlock);
		strP = GetPtr(pBlock);
		strP[pBlockLen] = 0;
		if NOT(err = BufferAddCString(id, strP, NO_ENC, 0))
		{	DisposeBlock(&pBlock);
			if NOT(err = BufferAddBuffer(id, textP + offsets[index] - 1, tLen))
			{	if NOT(err = _SubstituteForHilite(postStr, postLen, &pBlock, &pBlockLen, textP + offsets[index] - 1, tLen))
				{	LockBlock(pBlock);
					strP = GetPtr(pBlock);
					strP[pBlockLen] = 0;
					err = BufferAddCString(id, strP, NO_ENC, 0);
					DisposeBlock(&pBlock);
				}
			}
		}
	}

return err;
}

//===========================================================================================
XErr	HiliteInText(char *textP, long textLen, BlockRef *textResultBlockP, long *textResultLenP, long *offsets, long *end_offsets, long totOffset, char *preStr, char *postStr)
{
long		id;
XErr		err = noErr;
long		preLen, postLen, tempItem;
int			i, j;
Ptr			textResultP;

		if NOT(totOffset)
		{	if (textLen)
				i = textLen;
			else
				i = 1;
			if (*textResultBlockP = NewBlock(i, &err, &textResultP))
			{	CopyBlock(textResultP, textP, textLen);
				*textResultLenP = textLen;
			}
			return err;
		}
		
		// Sort the list
		j = totOffset;
		if (--j > 0)
		{	do
			{	for (i=0; i<j; i++)
				{	if (offsets[i] > offsets[i+1])
					{	tempItem = offsets[i+1];
						offsets[i+1] = offsets[i];
						offsets[i] = tempItem;
						tempItem = end_offsets[i+1];
						end_offsets[i+1] = end_offsets[i];
						end_offsets[i] = tempItem;
					}
				}
			} while(--j);
		}

		// Overlap
		j = totOffset - 1;
		for (i = 0; i < j; i++)
		{	if (end_offsets[i] >= offsets[i+1])
			{	offsets[i+1] = 0;
				if (end_offsets[i+1] > end_offsets[i])
					end_offsets[i] = end_offsets[i+1];
				end_offsets[i+1] = 0;
				if (i + 2 < totOffset)
				{	CopyBlock(&end_offsets[i+1], &end_offsets[i+2], (totOffset-i-2) * sizeof(long));
					CopyBlock(&offsets[i+1], &offsets[i+2], (totOffset-i-2) * sizeof(long));
					end_offsets[j] = 0;
					offsets[j] = 0;
				}
				--j;
				--totOffset;
				--i;
			}	
		}
		
		// Write out
		preLen = CLen(preStr);
		postLen = CLen(postStr);
		if (id = BufferCreate(textLen, &err))
		{	// first
			if (totOffset && NOT(err = BufferAddBuffer(id, textP, offsets[0] -1 )))
				err = _AddWord(id, 0, textP, offsets, end_offsets, preStr, preLen, postStr, postLen);
			if NOT(err)
			{	for (i = 1; i < totOffset; i++)
				{	if NOT(err = BufferAddBuffer(id, textP + end_offsets[i-1] - 1, offsets[i] - end_offsets[i-1]))
						err = _AddWord(id, i, textP, offsets, end_offsets, preStr, preLen, postStr, postLen);
				}
			}
			// last part of text
			if NOT(err)
			{	if NOT(err = BufferAddBuffer(id, textP + end_offsets[i-1] - 1, textLen + 1 - end_offsets[i-1]))
				{	*textResultBlockP = BufferGetBlockRef(id, textResultLenP);
					BufferClose(id);
				}
			}
			else
			{	*textResultBlockP = nil;
				*textResultLenP = 0;
				BufferFree(id);
			}
		}

return err;
}

//===========================================================================================
XErr	SubstituteExt(Ptr textP, long textLen, BlockRef *resultStringBlockP, long *resultLenP, char *oldString, long oldStringLen, Ptr newString, long newStringLen, Boolean cs, Boolean skipHTML)
{
XErr		err = noErr;
long		tLen, offset, relPos, resBuffID;

	*resultStringBlockP = 0;
	*resultLenP = 0;
	if NOT(resBuffID = BufferCreate(255L, &err))
		return err;
	if NOT(textLen)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringBlockP = BufferGetBlockRef(resBuffID, nil);
			*resultLenP = 0;
			BufferClose(resBuffID);
			return noErr;
		}
	}
	relPos = 0;
	offset = 0;
	tLen = textLen;
	//oldStringLen = CLen(oldString);
	while ((tLen > 0) && NOT(err) && FindStringInText(oldString, oldStringLen, textP+relPos, tLen, &offset, cs, skipHTML))
	{	BufferAddBuffer(resBuffID, textP + relPos, offset - 1);
		BufferAddBuffer(resBuffID, newString, newStringLen);
		relPos += offset + oldStringLen - 1;
		tLen = textLen - relPos;
	}
	
	// l'ultimo pezzo
	BufferAddBuffer(resBuffID, textP+relPos, tLen);
	
	if NOT(err)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringBlockP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
		}
		else
			BufferFree(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

//===========================================================================================
XErr	Encode_UTF(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP)
{
XErr		err = noErr;
int			ch;
long		resBuffID;
//Byte		hexDigit[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

	*resultStringHP = nil;
	*resultLenP = 0;
	if ((resBuffID = BufferCreate(ONE_BLOCK_1K, &err)) <= 0)
		return err;
	if NOT(stringLen)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
			return noErr;
		}
	}

	do	{
		ch = *stringP++;
		stringLen--;
		if ((ch & 0x80) == 0)
			err = BufferAddChar(resBuffID, (Byte)ch);
		else
		{	err = BufferAddChar(resBuffID, (Byte)(0xC0 | (0x03 & (ch >> 6))));
			err = BufferAddChar(resBuffID, (Byte)(0x80 | (0x3F & ch)));
		}
	} while((stringLen > 0) && NOT(err));
	
	if NOT(err)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
		}
		else
			BufferFree(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

/* A map from the most-significant 6 bits of the first byte
  to the total number of bytes in a UTF-8 character.
*/
static char UTF8len[64]
= {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* erroneous */
  2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 5, 6};

//===========================================================================================
XErr	Decode_UTF(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP)
{
XErr		err = noErr;
int			ch;
long		resBuffID;
//Byte		hexDigit[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

	*resultStringHP = nil;
	*resultLenP = 0;
	if ((resBuffID = BufferCreate(ONE_BLOCK_1K, &err)) <= 0)
		return err;
	if NOT(stringLen)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
			return noErr;
		}
	}

	do	{
			auto int len;
			register unsigned long u = 0;

			ch = *stringP++;
			stringLen--;
			len = UTF8len [(ch >> 2) & 0x3F];
			switch (len)
			{
				case 6: u = ch & 0x01; break;
				case 5: u = ch & 0x03; break;
				case 4: u = ch & 0x07; break;
				case 3: u = ch & 0x0F; break;
				case 2: u = ch & 0x1F; break;
				case 1: u = ch & 0x7F; break;
				case 0: /* erroneous: c is the middle of a character. */
					u = ch & 0x3F; len = 5; break;
			}
			while (--len > 0)
			{	ch = *stringP++;
				stringLen--;
				if ((ch & 0xC0) == 0x80)
				{
					u = (u << 6) | (ch & 0x3F);
				}
				else
				{	/* unexpected start of a new character */
					stringP--;
					stringLen++;
					// ungetc (c, stdin);
					break;
				}
			}
			if (u <= 0xFF)
			{
				err = BufferAddChar(resBuffID, (Byte)u);
				//putchar (u);
			}
			else
			{	/* this character can't be represented in Latin-1 */
				err = BufferAddChar(resBuffID, '?');
				//putchar ('?'); /* a reasonable alternative is 0x1A (SUB) */
			}
	} while((stringLen > 0) && NOT(err));
	
	if NOT(err)
	{	if NOT(err = BufferAddChar(resBuffID, 0))
		{	*resultStringHP = BufferGetBlockRef(resBuffID, resultLenP);
			--(*resultLenP);
			BufferClose(resBuffID);
		}
		else
			BufferFree(resBuffID);
	}
	else
		BufferFree(resBuffID);
			
return err;
}

//===========================================================================================
XErr	HTML2Txt(BlockRef *textBlockP, long *lenP, Boolean skipHeader)
{
XErr		err = noErr;
Ptr			saveP, readP, writeP, textP;
long		tagLen, skipLen, nlsize, len, tLen;
BlockRef	finalBlock;
CStr63		tagName;
Boolean		closed;
Byte		charToAdd, charToAdd2;

	if (len = *lenP)
	{	textP = GetPtr(*textBlockP);
		if (skipHeader)
		{	while (len > 0)
			{	if ((len > 3) && (*(long*)textP == CRLFCRLF))
				{	textP += sizeof(long);
					len -= sizeof(long);
					break;
				}
				else
				{	textP++;
					len--;
				}
			}
		}
		if (len > 0)
		{	LockBlock(*textBlockP);
			readP = writeP = textP;
			tLen = len;
			do {
				if (tLen && *readP == '<')
				{	readP++;
					tLen--;
					if (_GetNextObjectName(readP, tLen, tagName, sizeof(Str63) - 1, &closed))
					{	CUp2LowerStr(tagName, 0);
						if (DLM_GetObjID(gsHTMLTagsList, tagName, nil, nil))	// is an html tag
						{	tagLen = CLen(tagName);
							saveP = readP-1;
							_SkipUntilGreaterExt(&readP, &tLen);
							skipLen = readP-saveP;
							if (tagLen == 2)
							{	if (((*(short*)tagName == kTD) || (*(short*)tagName == kTH)) && closed)
								{	charToAdd = '\t';
									charToAdd2 = 0;
								}
								else if ((*(short*)tagName == kBR) || ((*(short*)tagName == kTR) && closed))
								{	charToAdd = FIRST_NEWLINE_CHAR;
									charToAdd2 = SECOND_NEWLINE_CHAR;
								}
								else
									charToAdd = charToAdd2 = 0;
							}
							else if ((tagLen == 1) && (*tagName == 'p'))
							{	charToAdd = FIRST_NEWLINE_CHAR;
								charToAdd2 = SECOND_NEWLINE_CHAR;
							}
							else
								charToAdd = charToAdd2 = 0;
							if (charToAdd2)
							{	*writeP++ = charToAdd;
								*writeP++ = charToAdd2;
								len -= (skipLen - 2);
							}
							else if (charToAdd)
							{	*writeP++ = charToAdd;
								len -= (skipLen - 1);
							}
							else
								len -= skipLen;
						}
						else
							*writeP++ = '<';
					}
					else
						*writeP++ = '<';
				}
				else if (IsNewLine(readP, tLen, &nlsize))
				{	readP += nlsize;
					tLen -= nlsize;
					len -= nlsize;
				}			
				else
				{	*writeP++ = *readP++;
					tLen--;
				}
			} while ((tLen > 0) && NOT(err));
			
			if NOT(err)
			{	if NOT(err = DecodeIsolatin((Byte*)textP, len, &finalBlock, lenP, false))
				{	DisposeBlock(textBlockP);
					*textBlockP = finalBlock;
				}
			}
			else
				UnlockBlock(*textBlockP);
		}
	}

return err;
}

//===========================================================================================
/*
ex
XErr	HTML2Txt(BlockRef *textBlockP, long *lenP)
{
Ptr			saveP, textP, initP;
long		nlsize, skipLen, len = *lenP;
XErr		err = noErr;
CStr63		tagName;
BlockRef	text = *textBlockP, finalBlock;
Boolean		closed;

	if NOT(err = SetBlockSize(*textBlockP, (*lenP)+1))
	{	LockBlock(text);
		textP = initP = GetPtr(text);
		if (len)
		{	do {
				if (len && *textP == '<')
				{	textP++;
					len--;
					if (_GetNextObjectName(textP, len, tagName, sizeof(Str63) - 1, &closed))
					{	CUp2LowerStr(tagName, 0);
						if (DLM_GetObjID(gsHTMLTagsList, tagName, nil, nil))	// is an html tag
						{	saveP = textP-1;
							_SkipUntilGreaterExt(&textP, &len);
							skipLen = textP-saveP;
							if (((*(short*)tagName == kTD) || (*(short*)tagName == kTH)) && closed)
							{	*saveP = '\t';
								CopyBlock(saveP+1, textP, len);
								(*lenP) -= (skipLen - 1);
								textP = saveP + 1;
							}
							else if (((*(short*)tagName == kTR) && closed) || (*tagName == 'p') || (*(short*)tagName == kBR))
							{	*saveP = '\r';
								*(saveP+1) = '\n';
								CopyBlock(saveP+2, textP, len);
								(*lenP) -= (skipLen - 2);
								textP = saveP + 2;
							}
							else
							{	CopyBlock(saveP, textP, len);
								(*lenP) -= skipLen;
								textP = saveP;
							}
						}
					}
				}
				else if (IsNewLine(textP, len, &nlsize))	// (len > 1) && *(short*)textP == kCR)
				{
				// skip
				//textP += nlsize;
				//len -= nlsize;
				#if __UNIX_XLIB__
					// remove CR (first)
					CopyBlock(textP, textP+1, len);
					(*lenP)--;
				#elif __MAC_XLIB__
					// remove LF (second)
					textP++;
					len--;
					CopyBlock(textP, textP+1, len);
					(*lenP)--;
				#else	// Windows ok
					textP++;
					len--;
				#endif
				}			
				else
				{	textP++;
					len--;
				}
			} while (len > 0);
		}
		initP[*lenP] = 0;

		if NOT(err)
		{	if NOT(err = DecodeIsolatin((Byte*)initP, *lenP, &finalBlock, lenP, false))
			{	DisposeBlock(textBlockP);
				*textBlockP = finalBlock;
			}
		}
		else
			UnlockBlock(text);
	}
	
return err;
}
*/
//===========================================================================================
void	PUp2LowerStr(register StringPtr strPtr)
{
register Byte	cnt, ch;
	int				charset = gCharset;

if (cnt = *strPtr++)
	{
	do{
		ch = *strPtr;
		*strPtr++ = _Local_CharToLower(ch, charset);
		}while(--cnt);
	}
}

//===========================================================================================
void	CUp2LowerStr(register char *strPtr, long subLen)
{
register Byte	cnt, ch;
	int				charset = gCharset;

if (cnt = CLen(strPtr))
	{
	if (subLen && (cnt > subLen))
		cnt = (Byte)subLen;
	do{
		ch = *strPtr;
		*strPtr++ = _Local_CharToLower(ch, charset);
		}while(--cnt);
	}
}

//===========================================================================================
void	CLow2UpperStr(register char *strPtr, long subLen)
{

register Byte	cnt, ch;
	int				charset = gCharset;

if (cnt = CLen(strPtr))
	{
	if (subLen && (cnt > subLen))
		cnt = (Byte)subLen;
	do {
		ch = *strPtr;
		*strPtr++ = _Local_CharToUpper(ch, charset);
		}while(--cnt);
	}
}

//===========================================================================================
void	PLow2UpperStr(register StringPtr strPtr)
{

register Byte	cnt, ch;
	int				charset = gCharset;

if (cnt = *strPtr++)
	{
	do{
		ch = *strPtr;
		*strPtr++ = _Local_CharToUpper(ch, charset);
		}while(--cnt);
	}
}

//===========================================================================================
void	Capitalize(Byte *stringP, long stringLen)
{
register int	oldCh, ch = 0;
long			advance;
	int				charset = gCharset;

	oldCh = 0;
	advance = 0;
	while (stringLen > 0)
	{	if (NOT(oldCh) || IsSeparChar((Ptr)stringP, stringLen, &advance))
		{	stringP += advance;
			stringLen -= advance;
			if (stringLen)
			{	SkipSpaceAndTabCRLF((char**)&stringP, &stringLen, nil);
				if (stringLen)
				{	ch = *stringP;
					*stringP = _Local_CharToUpper((Byte)ch, charset);
				}
				else
					break;
			}
			else
				break;
		}
		else
			*stringP = _Local_CharToLower(*stringP, charset);
		stringP++;
		stringLen--;
		oldCh = ch;
	}
}

#else	// else #ifndef __XLIB_CLIENT__
#if __MWERKS__
#pragma mark-
#endif

extern 	XLIB_CallBacksRec*		gXLibCallBacksRecPtr;
extern 	long					gCallerXLibVersion;
//===========================================================================================
XErr	IsoToNative(Ptr textP, long len)
{
XErr	(*p)(Ptr textP, long len) = (void*)gXLibCallBacksRecPtr->IsoToNative;

	return p(textP, len);
}

//===========================================================================================
XErr	NativeToIso(Ptr textP, long len)
{
XErr	(*p)(Ptr textP, long len), err = noErr;

	if (gCallerXLibVersion >= 0x00010001)
	{	p = (void*)gXLibCallBacksRecPtr->NativeToIso;
		err = p(textP, len);
	}
	else
		err = XError(kXLibError, ErrNotImplementedInXLib);
		
return err;
}

//===========================================================================================
Byte	HexStringToChar(short hexCh, Boolean isoLatin)
{
Byte	(*p)(short hexCh, Boolean isoLatin) = (void*)gXLibCallBacksRecPtr->HexStringToChar;

	return p(hexCh, isoLatin);
}
//===========================================================================================
XErr	InitTextUtils(void)
{
	return noErr;
}
//===========================================================================================
XErr	EndTextUtils(void)
{
	return noErr;
}
//===========================================================================================
XErr	EncodeIsolatin(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR, Boolean htmlTagsVisible, Boolean useNames, Boolean extTags, long userTagList)
{
XErr	(*p)(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR, Boolean htmlTagsVisible, Boolean useNames, Boolean extTags, long userTagList) = (void*)gXLibCallBacksRecPtr->EncodeIsolatin;

	return p(stringP, stringLen, resultStringP, resultLenP, alsoCR, htmlTagsVisible, useNames, extTags, userTagList);
}
//===========================================================================================
XErr	DecodeIsolatin(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR)
{
XErr	(*p)(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR) = (void*)gXLibCallBacksRecPtr->DecodeIsolatin;

	return p(stringP, stringLen, resultStringP, resultLenP, alsoCR);
}
//===========================================================================================
XErr	DecodeIsolatinFast(char *readP, Boolean alsoCR, long *resultLenP)
{
XErr	(*p)(char *readP, Boolean alsoCR, long *resultLenP) = (void*)gXLibCallBacksRecPtr->DecodeIsolatinFast;

	return p(readP, alsoCR, resultLenP);
}
//===========================================================================================
XErr	EncodeURL(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean spaceToPlus, char *preStr)
{
XErr	(*p)(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean spaceToPlus, char *preStr) = (void*)gXLibCallBacksRecPtr->EncodeURL;

	return p(stringP, stringLen, resultStringP, resultLenP, spaceToPlus, preStr);
}
//===========================================================================================
XErr	DecodeURL(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean plusToSpace, char *preStr)
{
XErr	(*p)(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean plusToSpace, char *preStr) = (void*)gXLibCallBacksRecPtr->DecodeURL;

	return p(stringP, stringLen, resultStringP, resultLenP, plusToSpace, preStr);
}
//===========================================================================================
XErr	DecodeURLFast(char *readP, Boolean plusToSpace, char *preStr, long *resultLenP)
{
XErr	(*p)(char *readP, Boolean plusToSpace, char *preStr, long *resultLenP) = (void*)gXLibCallBacksRecPtr->DecodeURLFast;

	return p(readP, plusToSpace, preStr, resultLenP);
}
//===========================================================================================
/*XErr	EncodeEsa(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr)
{
XErr	(*p)(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr) = (void*)gXLibCallBacksRecPtr->EncodeJavaScript;

	return p(stringP, stringLen, resultStringHP, resultLenP, preStr);
}
//===========================================================================================
XErr	DecodeEsa(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr)
{
XErr	(*p)(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr) = (void*)gXLibCallBacksRecPtr->DecodeJavaScript;

	return p(stringP, stringLen, resultStringHP, resultLenP, preStr);
}*/
//===========================================================================================
/*XErr	GetIsoChars(BlockRef *resultStringHP, long *resultLenP)
{
XErr	(*p)(BlockRef *resultStringHP, long *resultLenP) = (void*)gXLibCallBacksRecPtr->GetIsoChars;

	return p(resultStringHP, resultLenP);
}*/
//===========================================================================================
XErr	OffsetsInText(char *textP, long textLen, char *stringToHilite, Boolean cs, long *offsets, long *end_offsets, long *totOffsetP, long maxOffsets, Boolean skipHTML)
{
XErr	(*p)(char *textP, long textLen, char *stringToHilite, Boolean cs, long *offsets, long *end_offsets, long *totOffsetP, long maxOffsets, Boolean skipHTML) = (void*)gXLibCallBacksRecPtr->OffsetsInText;

	return p(textP, textLen, stringToHilite, cs, offsets, end_offsets, totOffsetP, maxOffsets, skipHTML);
}
//===========================================================================================
XErr	HiliteInText(char *textP, long textLen, BlockRef *textResultBlockP, long *textResultLenP, long *offsets, long *end_offsets, long totOffset, char *preStr, char *postStr)
{
XErr	(*p)(char *textP, long textLen, BlockRef *textResultBlockP, long *textResultLenP, long *offsets, long *end_offsets, long totOffset, char *preStr, char *postStr) = (void*)gXLibCallBacksRecPtr->HiliteInText;

	return p(textP, textLen, textResultBlockP, textResultLenP, offsets, end_offsets, totOffset, preStr, postStr);
}
//===========================================================================================
XErr	SubstituteExt(Ptr textP, long textLen, BlockRef *resultStringBlockP, long *resultLenP, char *oldString, long oldStringLen, Ptr newString, long newStringLen, Boolean cs, Boolean skipHTML)
{
XErr	(*p)(Ptr textP, long textLen, BlockRef *resultStringBlockP, long *resultLenP, char *oldString, long oldStringLen, Ptr newString, long newStringLen, Boolean cs, Boolean skipHTML) = (void*)gXLibCallBacksRecPtr->SubstituteExt;

	return p(textP, textLen, resultStringBlockP, resultLenP, oldString, oldStringLen, newString, newStringLen, cs, skipHTML);
}
//===========================================================================================
Boolean FindStringInText(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML)
{
Boolean	(*p)(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML) = (void*)gXLibCallBacksRecPtr->FindStringInText;

	return p(stringP, stringLen, textP, textLen, offsetP, cs, skipHTML);
}
//===========================================================================================
Boolean FindStringInTextSkipInside(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML, int skipInsideChar)
{
Boolean	(*p)(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML, int skipInsideChar) = (void*)gXLibCallBacksRecPtr->FindStringInTextSkipInside;

	return p(stringP, stringLen, textP, textLen, offsetP, cs, skipHTML, skipInsideChar);
}
//===========================================================================================
XErr	Encode_UTF(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP)
{
XErr	(*p)(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP) = (void*)gXLibCallBacksRecPtr->Encode_UTF;

	return p(stringP, stringLen, resultStringHP, resultLenP);
}
//===========================================================================================
XErr	Decode_UTF(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP)
{
XErr	(*p)(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP) = (void*)gXLibCallBacksRecPtr->Decode_UTF;

	return p(stringP, stringLen, resultStringHP, resultLenP);
}
//===========================================================================================
XErr	HTML2Txt(BlockRef *textBlockP, long *lenP, Boolean skipHeader)
{
XErr	(*p)(BlockRef *textBlockP, long *lenP, Boolean skipHeader) = (void*)gXLibCallBacksRecPtr->HTML2Txt;

	return p(textBlockP, lenP, skipHeader);
}
//===========================================================================================
void	PUp2LowerStr(register StringPtr strPtr)
{
void	(*p)(register StringPtr strPtr) = (void*)gXLibCallBacksRecPtr->PUp2LowerStr;

	p(strPtr);
}

//===========================================================================================
void	CUp2LowerStr(register char *strPtr, long subLen)
{
void	(*p)(register char *strPtr, long subLen) = (void*)gXLibCallBacksRecPtr->CUp2LowerStr;

	p(strPtr, subLen);
}

//===========================================================================================
void	CLow2UpperStr(register char *strPtr, long subLen)
{
void	(*p)(register char *strPtr, long subLen) = (void*)gXLibCallBacksRecPtr->CLow2UpperStr;

	p(strPtr, subLen);
}

//===========================================================================================
void	PLow2UpperStr(register StringPtr strPtr)
{
void	(*p)(register StringPtr strPtr) = (void*)gXLibCallBacksRecPtr->PLow2UpperStr;

	p(strPtr);
}

//===========================================================================================
void	Capitalize(Byte *stringP, long stringLen)
{
void	(*p)(Byte *stringP, long stringLen) = (void*)gXLibCallBacksRecPtr->Capitalize;

	p(stringP, stringLen);
}

//===========================================================================================
Byte CharToLower(Byte ch)
{
Byte	(*p)(Byte ch) = (void*)gXLibCallBacksRecPtr->CharToLower;

	return p(ch);
}

//===========================================================================================
Byte CharToUpper(Byte ch)
{
Byte	(*p)(Byte ch) = (void*)gXLibCallBacksRecPtr->CharToUpper;

	return p(ch);
}

#endif
