/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XLibPrivate.h,v 1.8 2005-11-14 17:11:16 valfer Exp $
	|______________________________________________________________________________
*/
#ifndef	__XLIBPRIVATE__
	#define __XLIBPRIVATE__

XErr	XInit(XFilePathPtr applicationPath);	// applicationPath is not mandatory
XErr	XEnd(long threadsToRemain);

XErr	XCommonInit(void);
XErr	XCommonEnd(void);
XErr	RegisterDllXLib(long dllRef, char *errString, long *dllXLibVersionP, Boolean macosxBundle);

Boolean	_XErrorString(XErr theError, char *eNameStr);

#define	TOT_ISO_ENTITIES	290
typedef struct {
				unsigned short			nativeCode;		// really a Byte
				unsigned short			isoCode;
				char					entity[12];
				} IsoEntity;

//===========================================================================================
//
//-------------------------------------- X Debug --------------------------------------------
//
//===========================================================================================

#ifdef __MAC_XLIB__
	// Mac Profiler
	#ifdef PROFILE_ACTIVE
		#include "Profiler.h"
		#define Prof_START(x, y)	ProfilerInit(collectDetailed, bestTimeBase, x, y)
		#define Prof_END			ProfilerTerm()
		#define Prof_ON				ProfilerSetStatus(true)
		#define Prof_OFF			ProfilerSetStatus(false)
		#define Prof_DUMP			ProfilerDump("\pProfilerResults")
		#define Prof_CLEAR			ProfilerClear()
	#else
		#define Prof_START(x, y)	(false)
		#define Prof_END			((void)0)
		#define Prof_ON				((void)0)
		#define Prof_OFF			((void)0)
		#define Prof_DUMP			((void)0)
		#define Prof_CLEAR			((void)0)
	#endif
	
	// Disable Unix TRACE
	#define	TRACE(a)				((void)0);
	#define	TRACEN(a, x, y)			((void)0);
	#define	TRACEEXT(a, x, y, z)	((void)0);
#else
	// Unix TRACE
	#if __UNIX_XLIB__ && DEBUG_TRACE
		#define	TRACE(a) {printf("%s @ %u: %s\n", __FILE__, __LINE__, a); fflush(stdout);}
		#define	TRACEN(a, x, y) {printf("%s @ %u: %s %d %d\n", __FILE__, __LINE__, a, x, y); fflush(stdout);}
		#define	TRACEEXT(a, x, y, z) {printf("%s @ %u: %s %d %d %d\n", __FILE__, __LINE__, a, x, y, z); fflush(stdout);}
		#define	TRACET(a, x) {printf("%d: %s %d \n", pthread_self(), a, x); fflush(stdout);}
		void	Command(char *command, char *resultStr);
	#else
		#define	TRACE(a)				0;
		#define	TRACEN(a, x, y)			0;
		#define	TRACEEXT(a, x, y, z)	0;
		#define	TRACET(a, x)			0;
	#endif
#endif

typedef struct {
		// Files
		long	XGetApplicationFolderPath;
		
		// Memory
		long	NewBlock;
		long	NewBlockLocked;
		long	NewBlockClear;		
		long	NewPtrBlock;
		long	DisposeBlock;
		long	GetBlockSize;
		long	SetBlockSize;
		long	ExpandBlockClear;
		long	GetPtr;
		long	GetAddress;
		long	DuplicateBlock;
	//ex (on MacOSX MAC_XLIB load UNIX DLL so struct dialignment!! #ifdef __MAC_XLIB__
		long	LockBlock;
		long	UnlockBlock;
		long	IsLocked;
	//#endif
		long	AllocString;
		long	DisposeString;
		//long	XMemoryOptimize;

		long	ResetLeaking;
		long	CheckLeaking;
		
		// Threads
		long	XYield;
		long	XGetCurrentThread;
		long	XThreadsEnterCriticalSection;
		long	XThreadsLeaveCriticalSection;
		long	XNewThread;
		long	XThreadsNewPool;
		long	XThreadsCreateSemaphore;
		long	XThreadsCloseSemaphore;
		long	XThreadsSemaphoreGreen;
		long	XThreadsWaitSemaphore;
		long	XThreadsSetTLS;
		long	XThreadsGetTLS;
		long	XThreadsGetThreadInfo;
		long	XThreadsStopThreads;
		long	XThreadsResumeThreads;
		
	//ex (on MacOSX MAC_XLIB load UNIX DLL so struct dialignment!! #ifdef __MAC_XLIB__
		long	XPlaySound;
	//#endif
		
	#ifdef __XLIB_WITH_HELPERS__	// must be at the end of the struct
		// Buffers
		//long	BufferOptimize;
		long	BufferCreate;
		long	BufferCreateClear;
		long	BufferFree;
		long	BufferClose;
		long	BufferClone;
		long	BufferSetLength;
		long	BufferReset;
		long	BufferGetBlockRef;
		long	BufferGetBlockRefExt;
		long	BufferGetBlockRefExtSize;
		long	BufferAddLongString;
		long	BufferAddPString;
		long	BufferAddCString;
		long	BufferAddText;
		long	BufferAddChar;
		long	BufferAddBuffer;
		long	BufferAddLong;
		long	BufferCheck;
		
		// Cache
		long	CFDeferredRun;
		long	CFDeferredExit;
		long	CFGetFile;
		long	CFGetFileSpecial;
		long	CFGetFileInfo;
		long	CFReleaseFile;
		long	CFFlushFile;
		long	CFFlushFilesMatching;
		long	CFFlush;
		long	CFReload;
		long	CFNeedReload;
		long	CFLoop;
		long	CFGetCacheInfo;
		//long	CFGetCacheFileInfo;
		
		// Pool
		long	NewPool;
		long	DeletePool;
		long	PoolNewPtr;
		long	PoolDisposePtr;

		// Text Mgr Utils
		long	HexStringToChar;
		long	EncodeIsolatin;
		long	DecodeIsolatin;
		long	DecodeIsolatinFast;
		long	EncodeURL;
		long	DecodeURL;
		long	DecodeURLFast;
		//long	EncodeEsa;
		//long	DecodeEsa;
		//long	GetIsoChars;
		long	OffsetsInText;
		long	HiliteInText;
		long	SubstituteExt;
		long	FindStringInText;
		long	FindStringInTextSkipInside;
		long	Encode_UTF;
		long	Decode_UTF;
		long	HTML2Txt;
		long	IsoToNative;

		long	Capitalize;
		long	CUp2LowerStr;
		long	CLow2UpperStr;
		long	PUp2LowerStr;
		long	PLow2UpperStr;
		long	CharToLower;
		long	CharToUpper;
		
		// XLib >= 0x00010001
		long	NativeToIso;
		
		long	XGetTicks;
	#endif
		} XLIB_CallBacksRec;

void	XFiles_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
void	XMemory_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
void	XThreads_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
#if __UNIX_XLIB__
	void	XDateTime_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
#endif

void	Buffer_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
void	Cache_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
void	Pool_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
void	TextMgr_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);

#ifdef __MAC_XLIB__
	void	MacUtils_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr);
#endif

#ifdef __WIN_XLIB__
	XErr	XWinGetLastError(void);
	#ifdef XLIB_WIN_DEBUG
		void	_DebugCreate(void);
		void	_DebugWrite(char *cStr);
	#else
		#define	_DebugCreate()		0
		#define	_DebugWrite(x)		0
	#endif
	void	_UnloadDNS_EPs(void);
#endif

//===========================================================================================
//
//-------------------------------------- X Sound (MacOS) ------------------------------------
//
//===========================================================================================

#ifdef __MAC_XLIB__
	void	InitSound(void);
	void	EndSound(void);
#endif

void	ZeroErrno(void);
// Initialize of startup time
void	XInitGetTicks(void);
#endif
