/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XErrorsCommon.c,v 1.2 2003-11-20 10:34:22 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

static CStr63	gErrorsStr[] = 
	{	"ErrXFiles_FileNotFound",
		"ErrXFiles_FolderNotFound",
		"ErrXFiles_PathTooLong",
		"ErrXFiles_LockNotSupported",
		"ErrXFiles_FolderIsNotEmpty",
		"ErrXFiles_EndOfFile",
		"ErrXFiles_WalkFolderAbort",
		"ErrXFiles_DuplicatedFile",
		"ErrXFiles_UnknownUser",
		"ErrXFiles_UnknownGroup",
		"ErrXFiles_BadFileRef",
		
		"ErrXMemory_BadRef",
		"ErrXMemory_NullSize",
		"ErrXMemory_BadBlockSize",
		"ErrXMemory_Full",
		"ErrXMemory_AttemptToDisposeTwice",
		
		"ErrXThreads_Timeout",
		"ErrXThreads_InternalErr",
		"ErrXThreads_NotFound",
				
		"ErrXDateTimeFormatError",

		"ErrXDLLCantLoadObject",
		"ErrXDLLCantFindSymbol",
		"ErrXDLLCantCloseObject",
		
		"ErrXConvertingStringToLong",
		"ErrXConversion",
		"ErrXLibNumOverFlow",
		
		"ErrNotImplementedInXLib",
		
		"ErrConnectionBroken",

		"ErrXLibTooOld",
		"ErrXLibTooNew",
		"ErrXLibCallerTooOld",
		"ErrXLibCallerTooNew",
		
		"ErrThreadAborted"
		};

//===========================================================================================
XErr XError(long eType, long eNum)
{
XErr			theError;
XErrStructP		errP = (XErrStructP)&theError;

	errP->type = eType;
	errP->value = eNum;

return theError;
}

//===========================================================================================
void XErrorGetTypeValue(XErr theError, long *eNumP, long *eTypeP)
{
long			eNum, eType;
XErrStructP		errP = (XErrStructP)&theError;

	eNum = errP->value;
	eType = errP->type;

	if (eNumP)
		*eNumP = eNum;
	if (eTypeP)
		*eTypeP = eType;
}

//===========================================================================================
Boolean	_XErrorString(XErr theError, char *eNameStr)
{
int		idx;
long	errValue, eType;

	XErrorGetTypeValue(theError, &errValue, &eType);
	if (eType == kXLibError)
	{	idx = errValue - XLIB_BASE_ERROR;
		if (eNameStr)
		{	if ((idx >= 0) && (idx < ErrXLibLastError))
				CEquStr(eNameStr, gErrorsStr[idx]);
			else
				CEquStr(eNameStr, "Unknown Error");
		}
		return true;
	}
	else
		return false;
}
