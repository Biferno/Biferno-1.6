/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: SlotMgr.c,v 1.9 2006-05-19 11:50:03 valfer Exp $
	|______________________________________________________________________________
*/
// ------------------------------------------------------------------------
#include	"XLib.h"
#include	"XLibPrivate.h"
#include	"SlotMgr.h"

#if __UNIX_XLIB__
	#include	<errno.h>
	#include <stdlib.h>
#endif

// ------------------------------------------------------------------------
#define		MAX_MAIN_LIST			32
#define		MAX_SUB_LIST			256
#define		MAX_SLOT_IN_LIST		(1<<16)	// 65536
#define		DEFAULT_SLOT_IN_LIST	4096

#define		UNDEFINED_SLOT	0xFFFFFFFF

/*#if __LITTLE_ENDIAN__
	#define		GET_LIST_ID(sRef)	((sRef & 0xFFFF) - 1)	// 1 - based
	#define		GET_SLOT_ID(sRef)	(sRef >> 16)			// 0 - based
#else
	#define		GET_LIST_ID(sRef)	((sRef >> 16) - 1)		// 1 - based
	#define		GET_SLOT_ID(sRef)	(sRef & 0xFFFF)			// 0 - based
#endif*/
#if __LITTLE_ENDIAN__
	#define		GET_LIST_ID(sRef)	(((sRef >> 1) & 0x7FFF) - 1)	// 1 - based
	#define		GET_SLOT_ID(sRef)	(sRef >> 16)			// 0 - based
#else
	#define		GET_LIST_ID(sRef)	(((sRef >> 16) & 0x7FFF) - 1)		// 1 - based
	#define		GET_SLOT_ID(sRef)	(sRef & 0xFFFF)						// 0 - based
#endif

typedef struct	{
				uint32_t	usedSlotCnt;	// currently used slots (total size in MainListBlk)
				uint32_t	firstFreeSlot;	// first available slot free to be used
				} ListHead, *ListHeadP;			// slot array after this header
				
												// virtual List Rec
typedef struct	{
				ListHead	listHead;
				Boolean		slotState[1];
				long		slot[1];
				} SListRec, *SListRecP;
				
typedef struct	{
				long		globalIDX;
				long		listArrayCnt;			// number of list elems currently allocated (listP[])
				long		listSlotMaxCnt;			// space allocated for slots item in list (after ListHead)
				long		slotSize;				// size in byte (padded on long boundary) for each slot item
				ListHeadP	listP[MAX_SUB_LIST];	// array of pointers to list blocks
				} MainLstBlk, *MainLstBlkP;

typedef struct	{
				long		mainListCnt;				// number of main lists allocated
				MainLstBlkP	mainListP[MAX_MAIN_LIST];	// array of pointers to list blocks
				} SlotMgrRec, *SlotMgrRecP;
				
// ------------------------------------------------------------------------------------------------------

static SlotMgrRec	gSlotMgrRec;

#if __WIN_XLIB__
	extern HANDLE	gMyHeap;
#endif

// ================================================================================
static XErr AllocPtr(long blkSize, Ptr *PPtr)
{
XErr	err = noErr;

	#if __MAC_XLIB__
		if NOT(*PPtr = NewPtrClear(blkSize))
			err = XGetError();
	#elif __UNIX_XLIB__
		errno = 0;
		if NOT(*PPtr = (Ptr)calloc(1, blkSize))
			err = errno;
	#else
		if NOT(*PPtr = HeapAlloc(gMyHeap, HEAP_ZERO_MEMORY, blkSize))
			err = XWinGetLastError();
	#endif

return err;
}
// ------------------------------------------------------------------------
static XErr DeallocPtr(Ptr P)
{
XErr	err = 0;

	#if __MAC_XLIB__
		DisposePtr(P);
	#elif __UNIX_XLIB__
		free(P);
	#else
		HeapFree(gMyHeap, 0L, P);
	#endif

return err;
}
// ================================================================================
#if __MWERKS__
#pragma mark-
#endif

// ================================================================================
static XErr _AddListToMainBlk(MainLstBlkP mainLstBlkP, unsigned long *listIdxP)
{
XErr			err = 0;
ListHeadP		listP;
unsigned long	freeListIdx, listCnt;

listCnt = mainLstBlkP->listArrayCnt;
if (listCnt < MAX_SUB_LIST)
	{
	for (freeListIdx = 0; freeListIdx < listCnt; freeListIdx++)			// first see if we can find a free elem in list array
		{
		if not(mainLstBlkP->listP[freeListIdx])
			break;
		}

	if not(err = AllocPtr(sizeof(ListHead) + (sizeof(Boolean) * mainLstBlkP->listSlotMaxCnt) +
								(mainLstBlkP->slotSize * mainLstBlkP->listSlotMaxCnt), (Ptr*)&listP))
		{
		mainLstBlkP->listArrayCnt++;
		mainLstBlkP->listP[freeListIdx] = listP;
		*listIdxP = freeListIdx;
		}
	}
else
	err = XError(kXLibError, ErrXMemory_SlotsFull);

return err;
}
// ------------------------------------------------------------------------
/*static XErr _DelListFromMainBlk(MainLstBlkP mainLstBlkP, int listIdx)
{
XErr		err = 0;
ListHeadP	listP;

if not(listP = mainLstBlkP->listP[listIdx])
	return -1;

err = DeallocPtr((Ptr)listP);
mainLstBlkP->listP[listIdx] = nil;
mainLstBlkP->listArrayCnt--;

return err;
}*/
// ------------------------------------------------------------------------
static long _FindNextFreeSlotInList(ListHeadP listP, long slotsInList)
{
long	nextFreeSlot;
Boolean	*slotStateP, *savedSlotStateP;

// WARNING: assumo che se questa routine viene chiamata c'� almeno uno slot libero !
if (((long)listP->usedSlotCnt + 1) < slotsInList)		// we need at least 1 more free slot (+ 1) besides the firstFreeSlot
	{
	nextFreeSlot = listP->firstFreeSlot + 1;
	savedSlotStateP = &((SListRecP)listP)->slotState[nextFreeSlot];
	if (*savedSlotStateP)
		{
		slotStateP = savedSlotStateP + 1;
		while (*slotStateP++);
		nextFreeSlot += slotStateP - savedSlotStateP - 1;
		}
	}
else
	nextFreeSlot = UNDEFINED_SLOT;

return nextFreeSlot;
}
#if __MWERKS__
#pragma mark-
#endif

// ================================================================================
void InitSlotManager(void)
{
	ClearBlock(&gSlotMgrRec, sizeof(gSlotMgrRec));
}

// ================================================================================
void TerminateSlotManager(void)
{
MainLstBlkP	mainLstBlkP, *mainLstArrayP;
ListHeadP	listP;
int			listIdx, listArrayTot, i, listArrayCnt, mainListCnt;

if not(mainLstArrayP = gSlotMgrRec.mainListP)
	return;

if (mainListCnt = gSlotMgrRec.mainListCnt)
	{	
	for (i = 0; i < MAX_MAIN_LIST; i++, mainLstArrayP++)
		{
		if (mainLstBlkP = *mainLstArrayP)
			{
			listArrayTot = MAX_SUB_LIST;
			listArrayCnt = mainLstBlkP->listArrayCnt;
			for (listIdx = 0; listIdx < listArrayTot; listIdx++)
				{
				if (listP = mainLstBlkP->listP[listIdx])
					{
					DeallocPtr((Ptr)listP);
					if not(--listArrayCnt)
						break;
					}
				}
			DeallocPtr((Ptr)mainLstBlkP);
			if (--mainListCnt)
				break;
			}
		}
	}
}

// ================================================================================
XErr NewSlotMgrBlock(int slotSize, int defaulElementCount, SlotMgrRef *slotMgrRefP)
{
XErr				err = 0;
MainLstBlkP			mainLstBlkP, *mainLstArrayP;
//ListHeadP	listP;
unsigned long		i, listIdx;

XThreadsEnterCriticalSection();

if not(defaulElementCount)
	defaulElementCount = DEFAULT_SLOT_IN_LIST;		// user dont care (use default)
else if(defaulElementCount > MAX_SLOT_IN_LIST)
	defaulElementCount = MAX_SLOT_IN_LIST;

if (gSlotMgrRec.mainListCnt < MAX_MAIN_LIST)
{	mainLstArrayP = gSlotMgrRec.mainListP;
	for (i = 0; i < MAX_MAIN_LIST; i++, mainLstArrayP++)
		{
		if (*mainLstArrayP == nil)
			break;
		}

	if not(err = AllocPtr(sizeof(MainLstBlk), (Ptr*)&mainLstBlkP))
		{
		mainLstBlkP->globalIDX = i;
		mainLstBlkP->listArrayCnt = 0;
		mainLstBlkP->listSlotMaxCnt = defaulElementCount;
		mainLstBlkP->slotSize = slotSize;
		// mainLstBlkP->listP[] pulite dalla AlocPtr();
		if not(err = _AddListToMainBlk(mainLstBlkP, &listIdx))
			{
			gSlotMgrRec.mainListCnt++;
			gSlotMgrRec.mainListP[i] = mainLstBlkP;
			}
		else
			DeallocPtr((Ptr)mainLstBlkP);
		}
	*slotMgrRefP = (SlotMgrRef)mainLstBlkP;
}
else
	err = XError(kXLibError, ErrXMemory_SlotsFull);

XThreadsLeaveCriticalSection();
return err;
}
// ------------------------------------------------------------------------
XErr DisposeSlotMgrBlock(SlotMgrRef *slotMgrRefP)
{
XErr	err = 0;
MainLstBlkP	mainLstBlkP, *mainLstArrayP;
ListHeadP	listP;
int			i, listArrayTot, listArrayCnt;

XThreadsEnterCriticalSection();
if (mainLstBlkP = (MainLstBlkP)*slotMgrRefP)
	{	
	gSlotMgrRec.mainListCnt--;
	mainLstArrayP = gSlotMgrRec.mainListP;
	for (i = 0; i < MAX_MAIN_LIST; i++, mainLstArrayP++)
		{
		mainLstBlkP = *mainLstArrayP;
		if (mainLstBlkP == (MainLstBlkP)*slotMgrRefP)
			{
			*mainLstArrayP = nil;
			break;
			}
		}

	listArrayTot = MAX_SUB_LIST;
	listArrayCnt = mainLstBlkP->listArrayCnt;
	for (i = 0; i < listArrayTot; i++)
		{
		if (listP = mainLstBlkP->listP[i])
			{
			DeallocPtr((Ptr)listP);
			if not(--listArrayCnt)
				break;
			}
		}
	err = DeallocPtr((Ptr)mainLstBlkP);
}
else
	err = XError(kXLibError, ErrXMemory_SlotMgrUninitialized);

XThreadsLeaveCriticalSection();
return err;
}
// ------------------------------------------------------------------------
XErr NewSlotElem(SlotMgrRef slotMgrRef, SlotRef *slotRefP, Ptr *pPtr, Boolean userBit)
{
XErr				err = 0;
MainLstBlkP			mainLstBlkP;
ListHeadP			listP;
unsigned long		slodIdx, slotsInList, listIdx, listArrayTot, listArrayCnt;

XThreadsEnterCriticalSection();
if (mainLstBlkP = (MainLstBlkP)slotMgrRef)
{	listArrayTot = MAX_SUB_LIST;
	listArrayCnt = mainLstBlkP->listArrayCnt;
	slotsInList = mainLstBlkP->listSlotMaxCnt;
	slodIdx = UNDEFINED_SLOT;
	for (listIdx = 0; listIdx < listArrayTot; listIdx++)
		{
		if (listP = mainLstBlkP->listP[listIdx])
			{
			if (listP->usedSlotCnt < slotsInList)
				{
				slodIdx = listP->firstFreeSlot;
				listP->firstFreeSlot = _FindNextFreeSlotInList(listP, slotsInList);
				break;
				}
			if not(--listArrayCnt)
				break;
			}
		}

	if	(slodIdx == -1)	// all lists full (must alloc a new list to main block)
		{
		if NOT(err = _AddListToMainBlk(mainLstBlkP, &listIdx))
			{
			listP = mainLstBlkP->listP[listIdx];
			gSlotMgrRec.mainListP[mainLstBlkP->globalIDX] = mainLstBlkP;
			slodIdx = 0;				// first slot in new list
			listP->firstFreeSlot = 1;	// next slot is free
			}
		}	

	if NOT(err)
		{	
		listP->usedSlotCnt++;
		((SListRecP)listP)->slotState[slodIdx] = true;				// set slot as in use
		if (pPtr)
			*pPtr = (Ptr)&(((SListRecP)listP)->slotState[mainLstBlkP->listSlotMaxCnt]) + (slodIdx * mainLstBlkP->slotSize);
		((SRP)slotRefP)->userBit = userBit;			
		((SRP)slotRefP)->listID = listIdx + 1;		// no slotRef can be zero
		((SRP)slotRefP)->slotID = slodIdx;
		}
}
else
	err = XError(kXLibError, ErrXMemory_SlotMgrUninitialized);
	//if ((listIdx == 1) && (slodIdx == 0x7D))
	//	DebugStr("\peccolo");

XThreadsLeaveCriticalSection();
return err;
}

// ------------------------------------------------------------------------
XErr FreeSlotElem(SlotMgrRef slotMgrRef, SlotRef *slotRefP, FreeSlotCallBack freeSCallback, long userData)
{
XErr			err = 0;
ListHeadP		listP;
MainLstBlkP		mainLstBlkP = (MainLstBlkP)slotMgrRef;
SlotRef			slotRef = *slotRefP;
unsigned long	listIdx = GET_LIST_ID(slotRef), slotIdx = GET_SLOT_ID(slotRef);

XThreadsEnterCriticalSection();
listP = mainLstBlkP->listP[listIdx];
if (freeSCallback)
	{
	Ptr		sP = ((Ptr)listP) + sizeof(ListHead) + (sizeof(Boolean) * ((MainLstBlkP)slotMgrRef)->listSlotMaxCnt) +
				(((MainLstBlkP)slotMgrRef)->slotSize * slotIdx);
	if (err = freeSCallback(sP, slotRef, userData))
		{
		XThreadsLeaveCriticalSection();
		return err;
		}
	}

((SListRecP)listP)->slotState[slotIdx] = false;		// set it free
if not(--(listP->usedSlotCnt))
	{
	// _DelListFromMainBlk(mainLstBlkP, listIdx);
	listP->firstFreeSlot = 0;
	}
else
	{
	if (slotIdx < listP->firstFreeSlot)
		listP->firstFreeSlot = slotIdx;
	}
	
*slotRefP = 0;
XThreadsLeaveCriticalSection();
return err;
}
// ------------------------------------------------------------------------
Ptr	GetSlotElem(SlotMgrRef slotMgrRef, SlotRef slotRef)
{
return (Ptr)(((MainLstBlkP)slotMgrRef)->listP[GET_LIST_ID(slotRef)]) +
		sizeof(ListHead) + (sizeof(Boolean) * ((MainLstBlkP)slotMgrRef)->listSlotMaxCnt) +
		(((MainLstBlkP)slotMgrRef)->slotSize * GET_SLOT_ID(slotRef));
}

// ------------------------------------------------------------------------
/*Boolean	GetSlotUserBit(register SlotRef slotRef)
{
	return SLOTMGR_GET_USER_BIT(slotRef);
}
*/
// ------------------------------------------------------------------------
/*
static Ptr	GetSlotElem_x8(SlotMgrRef slotMgrRef, SlotRef slotRef)
{
return (Ptr)(((MainLstBlkP)slotMgrRef)->listP[GET_LIST_ID(slotRef)]) +
		sizeof(ListHead) + (sizeof(Boolean) * ((MainLstBlkP)slotMgrRef)->listSlotMaxCnt) +
		(GET_SLOT_ID(slotRef) * 8);
}
*/
// ------------------------------------------------------------------------
XErr	GetSlotCnt(SlotMgrRef slotMgrRef, long *slotCntP)
{
XErr		err = 0;
MainLstBlkP	mainLstBlkP;
ListHeadP	listP;
int			slotCnt, listIdx, listArrayTot, listArrayCnt;

if not(mainLstBlkP = (MainLstBlkP)slotMgrRef)
	return XError(kXLibError, ErrXMemory_SlotMgrUninitialized);

listArrayTot = MAX_SUB_LIST;
listArrayCnt = mainLstBlkP->listArrayCnt;
slotCnt = 0;
for (listIdx = 0; listIdx < listArrayTot; listIdx++)
	{
	if (listP = mainLstBlkP->listP[listIdx])
		{
		slotCnt += listP->usedSlotCnt;
		if not(--listArrayCnt)
			break;
		}
	}
*slotCntP = slotCnt;
return err;
}
