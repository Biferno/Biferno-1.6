/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XUtilsCommon.c,v 1.5 2006-05-19 11:50:03 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

static unsigned long	gLastXIdle = 0;

#define	XIDLE_INTERVAL		(60L * 5L)	// 5 minutes

#include 	<limits.h>
#if __MAC_XLIB__ && !TARGET_API_MAC_CARBON
	#include 	<arith.h>
#endif

#ifndef __VISUALCPP__
#include <errno.h>
//===========================================================================================
void	ZeroErrno(void)
{
	errno = noErr;
}
#endif
//===========================================================================================
void	XIdle(void)
{
unsigned long	now;

	XGetSeconds(&now);
	if ((now - gLastXIdle) > XIDLE_INTERVAL)
	{		
	#ifdef __XLIB_WITH_HELPERS__
		//BufferOptimize();
	#endif
		//XMemoryOptimize();
		gLastXIdle = now;
	}
}

// questo poiche' su Unix mod_biferno non compilava
#if (LONG_LONG_MIN || !__UNIX_XLIB__) || __MACOSX__
//===========================================================================================
/* hh 980122 added LONGLONG support */
int LongLongAdd(LONGLONG * x, LONGLONG y)
{
	LONGLONG _x = *x;
	
	if (y < 0)
	{
		if (_x < 0 && y < LLONG_MIN - _x)
			return(0);
	}
	else
		if (_x > 0 && y > LLONG_MAX - _x)
			return(0);
	
	*x = _x + y;
	
	return(1);
}

//===========================================================================================
//- hh 980122 -
int LongLongMul(LONGLONG * x, LONGLONG y)
{
	LONGLONG	_x = *x;
	int		sign;
	
	sign = ((_x < 0) ^ (y < 0)) ? -1 : 1;
	
	if (_x < 0) _x = -_x;
	if ( y < 0)  y = - y;
	
	if (y && (_x > LLONG_MAX / y))
		return(0);
	
	*x = _x * y * sign;
	
	return(1);
}
#endif

//===========================================================================================
int LongAdd(long * x, long y)	//- cc 010510 -
{
	long _x = *x;
	
	if (y < 0)
	{
		if (_x < 0 && y < LONG_MIN - _x)
			return(0);
	}
	else
		if (_x > 0 && y > LONG_MAX - _x)
			return(0);
	
	*x = _x + y;
	
	return(1);
}

//===========================================================================================
int LongMul(long * x, long y)	//- cc 010510 -
{
	long	_x = *x;
	int		sign;
	
	sign = ((_x < 0) ^ (y < 0)) ? -1 : 1;
	
	if (_x < 0) _x = -_x;
	if ( y < 0)  y = - y;
	
	if (y && (_x > LONG_MAX / y))
		return(0);
	
	*x = _x * y * sign;
	
	return(1);
}
// HTTP

//===========================================================================================
long GetPOSTLimit(char *pathArgs)
{
Str31	tStr;
long	postMax = 0, pathLen;

	if (pathArgs)
	{	pathLen = CLen(pathArgs);
		if (pathLen > 4)
		{	if NOT(CompareBlock(pathArgs, "MAX=", 4))
			{	pathLen -= 4;
				pathArgs += 4;
				if (pathLen < 31)
				{	CopyBlock(&tStr[1], pathArgs, pathLen);
					tStr[0] = (Byte)pathLen;
					PStringToNum(tStr, &postMax);
					if (postMax < 0) 
						postMax = 0;
					postMax *= 1024;	// KBytes
				}
			}
		}
	}
	
return postMax;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
long	SwapLong(long aLong, Byte byteOrder)
{
long		result;
Boolean		toSwap;
Ptr			readP, writeP;

#ifdef __LITTLE_ENDIAN__
	if (byteOrder == X_BIG_ENDIAN)
		toSwap = true;
	else
		toSwap = false;
#else
	if (byteOrder == X_LITTLE_ENDIAN)
		toSwap = true;
	else
		toSwap = false;
#endif
	if (toSwap)
	{	readP = (Ptr)&aLong + 3;
		writeP = (Ptr)&result;
		*writeP++ = *readP--;
		*writeP++ = *readP--;
		*writeP++ = *readP--;
		*writeP = *readP;
	}
	else
		result = aLong;

return result;
}

//===========================================================================================
short	SwapShort(short aLong, Byte byteOrder)
{
short		result;
Boolean		toSwap;
Ptr			readP, writeP;

#ifdef __LITTLE_ENDIAN__
	if (byteOrder == X_BIG_ENDIAN)
		toSwap = true;
	else
		toSwap = false;
#else
	if (byteOrder == X_LITTLE_ENDIAN)
		toSwap = true;
	else
		toSwap = false;
#endif
	if (toSwap)
	{	readP = (Ptr)&aLong + 1;
		writeP = (Ptr)&result;
		*writeP++ = *readP--;
		*writeP = *readP;
	}
	else
		result = aLong;

return result;
}
#if __MWERKS__
#pragma mark-
#endif

#ifdef __XLIB_WITH_HELPERS__
//===========================================================================================
void	SortMXRecords(MXRecord *mxRecordP, long mxtot)
{
int			i, j;
MXRecord	tempMX;

	j = mxtot;
	if (--j <= 0)
		return;
	do
	{	for (i = 0; i < j; i++)
		{	if (mxRecordP[i].preference > mxRecordP[i+1].preference)
			{	tempMX = mxRecordP[i+1];
				mxRecordP[i+1] = mxRecordP[i];
				mxRecordP[i] = tempMX;
			}
		}
	} while(--j);
}
#endif


