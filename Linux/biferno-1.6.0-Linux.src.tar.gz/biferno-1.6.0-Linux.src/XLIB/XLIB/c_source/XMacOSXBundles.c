/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XMacOSXBundles.c,v 1.2 2003-06-23 12:39:50 valfer Exp $
	|______________________________________________________________________________
*/
#if __MACOSX__ && __USE_CARBON_FRAMEWORK__

#include "XLib.h"

#include <CoreServices/CoreServices.h>

#define kBundleAnyType NULL

//===========================================================================================
static long	_Bundle_Folder(char *folderURL)
{
CFURLRef    folderURLRef;
CFArrayRef	ar;
CFStringRef myCFStrRef;

	myCFStrRef = CFStringCreateWithCString(NULL, folderURL, kCFStringEncodingMacRoman); 
	folderURLRef = CFURLCreateWithFileSystemPath(NULL, myCFStrRef, kCFURLPOSIXPathStyle, true);
	ar = CFBundleCreateBundlesFromDirectory(kCFAllocatorDefault, folderURLRef, kBundleAnyType);
	CFRelease(myCFStrRef);
	CFRelease(folderURLRef);
	
return (long)ar;
}

//===========================================================================================
XErr	LoadBundles(XFilePathPtr folderPath, WalkXFolderCallBack _LoadDynamicClass, long userData)
{
CFArrayRef	bundlesArray = (CFArrayRef)_Bundle_Folder(folderPath);
int			indexBundles, totBundles;
CFBundleRef	bund;
XErr		err = noErr;

	if (bundlesArray)
	{	totBundles = CFArrayGetCount(bundlesArray);
		indexBundles = 0;
		while (indexBundles < totBundles)
		{	bund = (CFBundleRef)CFArrayGetValueAtIndex(bundlesArray, indexBundles++);
			err = _LoadDynamicClass((Ptr)bund, 0, userData);
			if (err)
				break;
		}
	}

return err;
}

//===========================================================================================
XErr	Bundle_Load(long myBundle)
{
Boolean 	didLoad = false;
XErr		err = noErr;

	if NOT(didLoad = CFBundleLoadExecutable((CFBundleRef)myBundle))
		err = XError(kXLibError, ErrXDLLCantLoadObject);
		 
return err;
}

//===========================================================================================
XErr	Bundle_Unload(long myBundle)
{
//Boolean didLoad = false;

	CFBundleUnloadExecutable((CFBundleRef)myBundle);

return noErr;
}

//===========================================================================================
XErr	Bundle_GetSymbol(long myBundle, char *symbolName, long *symbolEntryPointP)
{
XErr		err = noErr;
CFStringRef myCFStrRef;
	
	if (symbolEntryPointP)
		*symbolEntryPointP = 0;
	myCFStrRef = CFStringCreateWithCString(NULL, symbolName, kCFStringEncodingMacRoman); 
    if NOT(*symbolEntryPointP = (long)CFBundleGetFunctionPointerForName((CFBundleRef)myBundle, myCFStrRef))
		err = XError(kXLibError, ErrXDLLCantFindSymbol);
	CFRelease(myCFStrRef);
	
return err;
}
#endif
