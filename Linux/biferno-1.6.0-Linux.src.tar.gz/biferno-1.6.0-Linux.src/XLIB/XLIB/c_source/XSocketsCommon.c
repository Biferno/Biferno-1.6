/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XSocketsCommon.c,v 1.7 2006-10-09 10:40:42 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"

#ifdef __XLIB_WITH_HELPERS__

#ifdef __UNIX_XLIB__
	#include <sys/types.h>
	#include <netinet/in.h>
	#include <netdb.h>
	#include <stdio.h>
	#include <errno.h>
	#include <arpa/nameser.h>
	#include <resolv.h>
	#include <signal.h>
	#include <unistd.h>
	#include <sys/socket.h>
	#include <sys/socketvar.h>
	#include <sys/file.h>
	#include <sys/un.h>
	#include <pthread.h>
	#include <fcntl.h>
	#ifndef __MACOSX__
		#include <malloc.h>
	#endif
#endif

#ifdef __UNIX_XLIB__
	#define	ZEROERRNO		errno = noErr
	#define	_TIMEOUT_ERROR	EWOULDBLOCK
#else
	#define	ZEROERRNO	0
	#define	_TIMEOUT_ERROR	WSAETIMEDOUT
#endif

#ifdef __MAC_XLIB__
	long	XHostToNetwork(long n)
	{return n;}	
#else

//===========================================================================================
XErr	GetHostByNameSafe(const char* name, XSafeHostent* shostentP)
{
XErr			err = noErr;
struct hostent*	host_ent;

	XThreadsEnterCriticalSection();
	ZEROERRNO;
	if ((host_ent = gethostbyname(name)) && (host_ent->h_length < XSAFE_HOSTENT_LENGTH))
	{	memcpy(shostentP->h_addr_list0, host_ent->h_addr_list[0], host_ent->h_length);
		shostentP->h_length = host_ent->h_length;
		//printf("%d %s", host_ent->h_length, shostentP->h_addr_list0);
		CEquStr(shostentP->h_name, host_ent->h_name);
	}
	else
	{	
	#if __UNIX_XLIB__
		err = errno;
		switch(err)
		{	case HOST_NOT_FOUND:
			case TRY_AGAIN:
			case NO_RECOVERY:
			case NO_DATA:
			default:
				err = ENOENT;
				break;
		}
	#else
		err = XWinGetLastError();
	#endif
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
static XErr		_GetErr(void)
{
	#ifdef __UNIX_XLIB__
		return errno;
	#else
		return XWinGetLastError();
	#endif
}

//===========================================================================================
// assure that at least 4 bytes are received (buff must be at least 4)
static int		_prefixed_recv(int c_socket, Ptr buff, long max, XErr *errP)
{
long	res, totRes;

	totRes = 0;
	do {
		res = recv(c_socket, buff + totRes, max - totRes, 0);
		if (res > 0)
			totRes += res;
		else if (res < 0)
		{	totRes = res;
			break;
		}
		else
		{	/*
			from recv  Man page:
				If  no  messages  are  available to be
    			received and the peer has  performed  an  orderly  shutdown,
    			recv()  returns  0
    		*/
			*errP = XError(kXLibError, ErrConnectionBroken);
			break;
		}
	} while (totRes < 4);

return totRes;
}

//===========================================================================================
// Perform the first recv and initialize the buffer
static XErr	_first_recv(int c_socket, Ptr buff, long maxStorage, long *bytesToReceiveP, long *bytesReceivedP, BlockRef *bufferBlockP, Ptr *bufferPtrP)
{
long		bytesToReceive, bytesRcv;
XErr		err = noErr;
Ptr			bufferPtr;
BlockRef	bufferBlock;

	*bytesToReceiveP = 0;
	*bytesReceivedP = 0;
	*bufferPtrP = 0;
	*bufferBlockP = 0;

	ZEROERRNO;
	bytesRcv = _prefixed_recv(c_socket, buff, maxStorage, &err);
	if (NOT(err) && (bytesRcv < 0))
		err = _GetErr();
	// note that if bytesRcv == 0 allocate 1 byte (only the zero final)
	// nevertheless, it should never happen
	if NOT(err)
	{	if (bytesRcv)
			bytesToReceive = XNetworkToHost(*(uint32_t*)buff);
		else
			bytesToReceive = 0;
		if (bufferBlock = NewBlock(bytesToReceive + 1, &err, (Ptr*)&bufferPtr))	// final 0
		{	LockBlock(bufferBlock);
			if (bytesRcv > 4)
			{	*bytesReceivedP = bytesRcv - 4;
				CopyBlock(bufferPtr, buff + 4, *bytesReceivedP);
			}
			else
				*bytesReceivedP = 0;
			*bytesToReceiveP = bytesToReceive;
			*bufferPtrP = bufferPtr;
			*bufferBlockP = bufferBlock;
		}
	}
	if (err && (err != _TIMEOUT_ERROR))
		err = XError(kXLibError, ErrConnectionBroken);
	
return err;
}

//===========================================================================================
// la prima long � la lunghezza da ricevere (la prima long esclusa)
XErr	XSocketsReceive(long socketRef, BlockRef *buffReceivedBlockP, long *buffReceivedLengthP, Boolean expectPrefixed, ReceiveCompleteCallBack _completeFunc, long completeCallBackParam)
{
int				c_socket = (int)socketRef;
long			buffID, bytesRcv, bytesReceived, bytesToReceive;
//char			*pToAdd, *tempBufP;
XErr			err = noErr;
//Boolean			first, moved;
char			*pBuf = nil;

	buffID = 0;
	System_EnterCS();
	pBuf = (char*)malloc(PACK_SIZE+1);
	System_LeaveCS();
	if NOT(pBuf)
		return -1;

	if (expectPrefixed)
	{	
	BlockRef	recvBlock;
	Ptr			recvPtr;
	
		if NOT(err = _first_recv(c_socket, pBuf, PACK_SIZE, &bytesToReceive, &bytesReceived, &recvBlock, &recvPtr))
		{	while (NOT(err) && (bytesReceived < bytesToReceive))
			{	
				ZEROERRNO;
				bytesRcv = recv(c_socket, recvPtr + bytesReceived, bytesToReceive - bytesReceived, 0);
				if (bytesRcv < 0)
				{	err = _GetErr();		
					break;
				}
				else if (bytesRcv == 0)
					break;
				else
					bytesReceived += bytesRcv;	
			}
			if NOT(err)
			{	*(recvPtr + bytesReceived) = 0;
				*buffReceivedBlockP = recvBlock;
				*buffReceivedLengthP = bytesReceived;
				UnlockBlock(recvBlock);
			}
			else
				DisposeBlock(&recvBlock);
		}			
		/*
		ex
		first = true;
		maxStorage = PACK_SIZE;
		bytesReceived = 0;
		tempBufP = pBuf;
		while NOT(err)
		{	System_EnterCS();
			bytesRcv = recv(c_socket, tempBufP + bytesReceived, maxStorage, 0);
			if (bytesRcv < 0)
				err = XWinGetLastError();
			System_LeaveCS();
			if (err || (bytesRcv == 0))
				break;
			if (first)
			{	pToAdd = tempBufP + 4;
				bytesRcv -= 4;
				bytesToReceive = ntohl(*(long*)tempBufP);
				first = false;
				if NOT(buffID = BufferCreate(PACK_SIZE, &err))
					break;
			}
			else
				pToAdd = tempBufP + bytesReceived;
			bytesReceived += bytesRcv;		
			if (err = BufferAddBuffer(buffID, pToAdd, bytesRcv))
				break;
			if (bytesReceived >= bytesToReceive)
				break;
			else
			{	maxStorage = bytesToReceive - bytesReceived;
				newSize = maxStorage + bytesReceived;
				if NOT(err = BufferCheck(buffID, newSize, &moved))
				{	
					tempBufP = GetPtr(BufferGetBlockRef(buffID, nil));
				}
			}
		}
		if (first && (err != WSAETIMEDOUT))
			err = XError(kXLibError, ErrConnectionBroken);
		if NOT(err)
		{	if NOT(err = BufferAddChar(buffID, 0))
			{	*buffReceivedBlockP = BufferGetBlockRef(buffID, buffReceivedLengthP);
				(*buffReceivedLengthP)--;
				BufferClose(buffID);
			}
		}*/
	}
	else
	{	long	tot;
	
		if (buffID = BufferCreate(PACK_SIZE, &err))
		{	tot = 0;
			do {	
				ZEROERRNO;
				bytesRcv = recv(c_socket, pBuf, PACK_SIZE, 0);
				if (bytesRcv < 0)
				{	err = _GetErr();
					break;
				}
				else if NOT(bytesRcv)
					break;
				else
				{	tot += bytesRcv;
					err = BufferAddBuffer(buffID, pBuf, bytesRcv);
				}
				if (NOT(err) && _completeFunc)
				{	if (_completeFunc(buffID, tot, completeCallBackParam))
						break;
				}
			} while NOT(err);
			if NOT(err)
			{	*buffReceivedBlockP = BufferGetBlockRef(buffID, buffReceivedLengthP);
				BufferClose(buffID);
			}
		}
	}

if (pBuf)
{	System_EnterCS();
	free(pBuf);
	System_LeaveCS();
}
if (err && buffID)	
	BufferFree(buffID);
	
return err;
}

//===========================================================================================
// la prima long � la lunghezza da mandare (la lunghezza senza la prima long)
XErr	XSocketsSend(long socketRef, BlockRef buffToSendBlock, long buffToSendLength)
{
int			c_socket = (int)socketRef;
long		totalSent, bytesSent, bytesToSent, t;
char		*buffToSend;
XErr		err = noErr;
	
	/*if (putPrefix)
	{	if NOT(err = SetBlockSize(buffToSendBlock, buffToSendLength + sizeof(long)))
		{	buffToSend = GetPtr(buffToSendBlock);
			CopyBlock(buffToSend + sizeof(long), buffToSend, buffToSendLength);
			*(long*)buffToSend = htonl(buffToSendLength);
			buffToSendLength += sizeof(long);
		}
	}
	else*/
	buffToSend = GetPtr(buffToSendBlock);
	if NOT(err)
	{	totalSent = 0;
		bytesToSent = buffToSendLength;
		do {
			t = bytesToSent;
			ZEROERRNO;
			bytesSent = send(c_socket, buffToSend + totalSent, t, 0);
			if (bytesSent < 0)
			{	err = _GetErr();
				break;
			}
			totalSent += bytesSent;
			bytesToSent -= bytesSent;
		} while (totalSent < buffToSendLength);
	}
	
return err;
}

//===========================================================================================
long	XHostToNetwork(long n)
{
	return htonl(n);
}

//===========================================================================================
long	XNetworkToHost(long n)
{
	return ntohl(n);
}

#endif	// __XLIB_WITH_HELPERS__
#endif	// else __MAC_XLIB__
