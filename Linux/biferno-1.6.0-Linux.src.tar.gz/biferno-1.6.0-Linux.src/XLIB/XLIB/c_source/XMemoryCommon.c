/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XMemoryCommon.c,v 1.9 2006-10-27 14:26:11 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"
#include "SlotMgr.h"

#include "XMemoryPrivate.h"

#include <stdio.h>

#ifdef __XLIB_CLIENT__
	static unsigned long	gTotalApplicationMemory;
#else
	extern 	unsigned long	gTotalApplicationMemory;
#endif
//static	long			gsMainMemBlock = nil;
static	SlotMgrRef 		gsMemorySlotMgrRef = 0;
//#define	MEMORY_WHILE_DEBUGGING_NO_OPTIMIZATION	1

//===========================================================================================
#ifdef __MAC_XLIB__
	static BlockRef	_NewBlock(long size, XErr *errP, long (*allocFunc)(long, XErr*), Ptr *thePtrP, Boolean toLock)
#else
	static BlockRef	_NewBlock(long size, XErr *errP, long (*allocFunc)(long, XErr*), Ptr *thePtrP)
#endif
{
MemSlot			*tRecP;
long			address;
XErr			err = noErr;
SlotRef			slotRef = 0;

	if NOT(err = NewSlotElem(gsMemorySlotMgrRef, &slotRef, (Ptr*)&tRecP, 0))
	{	address = allocFunc(size, &err);
		if NOT(err)
		{	gTotalApplicationMemory += size;
		#ifdef __MAC_XLIB__
			tRecP->isHandle = (allocFunc != NewPtrBlock_low);
			if (toLock)
			{	HLock((Handle)address);
				tRecP->lockCount = 1;
			}
			else
				tRecP->lockCount = 0;
		#endif
			tRecP->address = address;		
			tRecP->size = size;
			if (thePtrP)
			{
			#if MEM_DEBUG
				#if __MAC_XLIB__
					*thePtrP = GetPtr_low(tRecP->address, tRecP->isHandle);
				#else
					*thePtrP = GetPtr_low(tRecP->address);
				#endif
			#else
				#if __MAC_XLIB__
					if (tRecP->isHandle)
						*thePtrP = *(Handle)address;
					else
						*thePtrP = (Ptr)address;
				#else
					*thePtrP = (Ptr)address;
				#endif
			#endif
			}
		}
		else
			FreeSlotElem(gsMemorySlotMgrRef, &slotRef, nil, 0);
	}

//if (((slotRef >> 16) == 2) && ((slotRef & 0xFFFF) == 0x7D))
//	DebugStr("\peccolo");

if (errP)
	*errP = err;
return (BlockRef)slotRef;
}

//===========================================================================================
/*static XErr	_ExpandMemBlock(void)
{
XErr			err = noErr;
MemSlot			*tRecP;
int				i;
unsigned long	newSize, curBlkSize;
MemArraySlotP	memArraySlotP;

	UnlockBlock_low(gsMainMemBlock);
	memArraySlotP = GET_MEM_ARRAY();	// (MemArraySlotP)GetPtr_low(gsMainMemBlock, true);
	curBlkSize = offsetof(MemArraySlot, memSlot) + memArraySlotP->slotCnt * sizeof(MemSlot);
	newSize = curBlkSize + sizeof(MemSlot) * SLOTS_ALLOC_STEP;
	if NOT(err = SetBlockSize_low(&gsMainMemBlock, true, curBlkSize, newSize))
	{	gTotalApplicationMemory += newSize - curBlkSize;
		memArraySlotP = GET_MEM_ARRAY();
		tRecP = &memArraySlotP->memSlot[memArraySlotP->slotCnt];
		memArraySlotP->slotCnt += SLOTS_ALLOC_STEP;
		for (i = 0; i < SLOTS_ALLOC_STEP; i++, tRecP++)
			tRecP->address = nil;
	}
		
return err;
}

//===========================================================================================
static BlockRef	_NewBlock(long size, XErr *errP, long (*allocFunc)(long, XErr*))
{
MemSlot			*tRecP;
long			i, address, slot = 0;
XErr			err = noErr;
MemArraySlotP	memArraySlotP;

XThreadsEnterCriticalSection();

	memArraySlotP = GET_MEM_ARRAY();
	if (memArraySlotP->usedSlotCnt == memArraySlotP->slotCnt)
	{	memArraySlotP->firstFreeSlot = memArraySlotP->slotCnt;
		if (err = _ExpandMemBlock())
			goto esci;
		else
			memArraySlotP = GET_MEM_ARRAY();
	}
		
	address = allocFunc(size, &err);
	if NOT(err)
	{	gTotalApplicationMemory += size;
		#ifdef __MEM_CANMOVE__
			memArraySlotP = GET_MEM_ARRAY();
		#endif
	#ifdef MEMORY_WHILE_DEBUGGING_NO_OPTIMIZATION		
		tRecP = &memArraySlotP->memSlot[0];
		i = 0;
		while (tRecP->address)
		{	tRecP++;
			i++;
		}
		slot = i;
	#else
		slot = memArraySlotP->firstFreeSlot;
	#endif
		if (slot >= memArraySlotP->max)
		{	memArraySlotP->max = slot;
			XGetSeconds(&memArraySlotP->maxLastMove);
		}
		tRecP = &memArraySlotP->memSlot[slot];
		tRecP->isHandle = (allocFunc != NewPtrBlock_low);
		tRecP->address = address;		
		tRecP->size = size;
		tRecP->lockCount = 0;
		memArraySlotP->usedSlotCnt++;
		
	#ifndef MEMORY_WHILE_DEBUGGING_NO_OPTIMIZATION
		if (memArraySlotP->usedSlotCnt < memArraySlotP->slotCnt)
			{
			i = slot;
			do	{
				tRecP++;
				i++;
				} while (tRecP->address);
			memArraySlotP->firstFreeSlot = i;
			}
		else
			{
			memArraySlotP->firstFreeSlot = UNDEFINED_SLOT;		// expand next time
			}
	#endif
	}
esci:
XThreadsLeaveCriticalSection();
	
if (errP)
	*errP = err;
if (err)
	return 0;
else
	return slot+1;
}
*/

#ifdef MEM_DEBUG

//===========================================================================================
static void	_StringInDebugger(char *message, char *funcName)
{
CStr255	aStr;

	CEquStr(aStr, message);	
	CAddStr(aStr, funcName);
	CAddChar(aStr, ')');
	CDebugStr(aStr);
}

#define		FIRST_HEADER	0x12345678
#define		FIRST_FOOTER	0xABCDEF12
#define		SECOND_FOOTER	0x3456789A

//===========================================================================================
// Note: the size is comprensive of header (8) and footer (8)
void	_WritePageGuardians(Ptr p, unsigned long size, short action)
{
unsigned long	realSize = size - 16;

	if (p)
	{	// header
		*(long*)p = FIRST_HEADER;
		*(long*)(p + sizeof(long)) = realSize;
		
		// fill content
		p += 8;
		if (action == FILL)
			FillBlock(p, realSize, 'Q');
		else if (action == CLEAR)
			ClearBlock(p, realSize);
		
		// footer
		p += realSize;
		*(long*)p = FIRST_FOOTER;
		*(long*)(p + sizeof(long)) = SECOND_FOOTER;
	}
}

//===========================================================================================
// Note: the size is comprensive of header (8) and footer (8)
void	_CheckPageGuardians(Ptr p, unsigned long size, char *funcName)
{
unsigned long	realSize = size - 16;
long	long1, long2;

	if (p)
	{	// header
		long1 = *(long*)p;
		long2 = *(long*)(p + sizeof(long));

		if (long1 != (long)FIRST_HEADER)
			_StringInDebugger("Page Guardian Header Overwritten (", funcName);
		else if (long2 != (long)realSize)
			_StringInDebugger("Page Guardian Size Overwritten (", funcName);
		
		// footer
		p += 8 + realSize;
		long1 = *(long*)p;
		long2 = *(long*)(p + sizeof(long));
		if (long1 != FIRST_FOOTER)
			_StringInDebugger("Page Guardian Footer 1 Overwritten (", funcName);
		else if (long2 != SECOND_FOOTER)
			_StringInDebugger("Page Guardian Footer 2 Overwritten (", funcName);
	}
}
#endif
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	XMemory_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{
		// Memory
		xlibCallBacksRecPtr->NewBlock = (long)NewBlock;
#ifdef __MAC_XLIB__
		xlibCallBacksRecPtr->NewBlockLocked = (long)NewBlockLocked;
#else
		xlibCallBacksRecPtr->NewBlockLocked = (long)NewBlock;
#endif
		xlibCallBacksRecPtr->NewBlockClear = (long)NewBlockClear;
		xlibCallBacksRecPtr->NewPtrBlock = (long)NewPtrBlock;
		xlibCallBacksRecPtr->DisposeBlock = (long)DisposeBlock;
		xlibCallBacksRecPtr->GetBlockSize = (long)GetBlockSize;
		xlibCallBacksRecPtr->SetBlockSize = (long)SetBlockSize;
		xlibCallBacksRecPtr->ExpandBlockClear = (long)ExpandBlockClear;
		xlibCallBacksRecPtr->GetPtr = (long)GetPtr;
		xlibCallBacksRecPtr->GetAddress = (long)GetAddress;
		xlibCallBacksRecPtr->DuplicateBlock = (long)DuplicateBlock;
#ifdef __MAC_XLIB__
		xlibCallBacksRecPtr->LockBlock = (long)LockBlock;
		xlibCallBacksRecPtr->UnlockBlock = (long)UnlockBlock;
		xlibCallBacksRecPtr->IsLocked = (long)IsLocked;
#endif
		xlibCallBacksRecPtr->AllocString = (long)AllocString;
		xlibCallBacksRecPtr->DisposeString = (long)DisposeString;
		//xlibCallBacksRecPtr->XMemoryOptimize = (long)XMemoryOptimize;
		
		xlibCallBacksRecPtr->ResetLeaking = (long)ResetLeaking;
		xlibCallBacksRecPtr->CheckLeaking = (long)CheckLeaking;
}

//===========================================================================================
XErr	XMemoryInit(void)
{
XErr			err = noErr;
//MemArraySlotP	memArraySlotP;

#ifdef __XLIB_CLIENT__
	return noErr;
#endif	

	err = NewSlotMgrBlock(sizeof(MemSlot), MEMORY_MGR_DEFAULT_SLOTS, &gsMemorySlotMgrRef);
	/*
	gsMainMemBlock = NewBlockClear_low(sizeof(MemArraySlot), &err);
	gTotalApplicationMemory += sizeof(MemArraySlot);
	memArraySlotP = GET_MEM_ARRAY();
	memArraySlotP->slotCnt = SLOTS_ALLOC_STEP;
	memArraySlotP->usedSlotCnt = 0;				// just to explicitate since they are already zero
	memArraySlotP->firstFreeSlot = 0;
	memArraySlotP->max = 0;
	XGetSeconds(&memArraySlotP->maxLastMove);
	*/
	
return err;
}

//===========================================================================================
XErr	XMemoryEnd(void)
{
XErr			err = noErr;
//MemArraySlotP	memArraySlotP;
	
#ifdef __XLIB_CLIENT__
	return noErr;
#endif	
	
	err = DisposeSlotMgrBlock(&gsMemorySlotMgrRef);
	
	/*
	memArraySlotP = GET_MEM_ARRAY();	// (MemArraySlotP)GetPtr_low(gsMainMemBlock, true);
	err = DisposeBlock_low(&gsMainMemBlock, true, offsetof(MemArraySlot, memSlot) + memArraySlotP->slotCnt * sizeof(MemSlot));
	*/
	
return err;
}
#if __MWERKS__
#pragma mark-
#endif


// CopyBlock is OS Dependent
//===========================================================================================
// returns true if different
Boolean	CompareBlock( void *aPtr_p, void *bPtr_p, long size )
{
register long	cnt;
register uint32_t*	aPtr=(uint32_t*)aPtr_p;
register uint32_t*	bPtr=(uint32_t*)bPtr_p;

	if (cnt = size >> 2)
		{
		do	{
			if (*aPtr++ != *bPtr++)
				return(true);
			}
		while(--cnt);
		}
	if (cnt = size & 3)
		{
		do	{
			if( *(Ptr)aPtr != *(Ptr)bPtr )
				return(true);
			aPtr = (uint32_t*)((Ptr)aPtr + 1);
			bPtr = (uint32_t*)((Ptr)bPtr + 1);
			}while(--cnt);
		}

return(false);
}

//===========================================================================================
// returns true if different
/*
es:
	if (Begins(theP, len, "pippo", 5))
		...
*/
Boolean	Begins(void *aPtr_p, long aPtr_pLen, void *bPtr_p, long size)
{
	if (size > aPtr_pLen)
		return false;
	else
		return NOT(CompareBlock(aPtr_p, bPtr_p, size));
}

//===========================================================================================
/* ------------------------ */
void ClearBlock(void* blockPtr_p, long thSize)
{
#ifdef __UNIX_XLIB__
	bzero(blockPtr_p, thSize);
#else
register long	cnt;
char			zeroM[8] = "\0\0\0\0\0\0\0\0";
register double	zeroDoubl = *(double*)zeroM, *blockPtr = blockPtr_p;
Ptr				tPtr;

if (thSize >= sizeof(double))		// if < of 2 doubles just copy byte by byte
	{
	long	quadDoubl;
	if (cnt = ((long)blockPtr & (sizeof(double) - 1)))	// align to double boundary
		{
		cnt = sizeof(double) - cnt;
		tPtr = (Ptr)blockPtr;
		thSize -= cnt;
		blockPtr = (double*)((Ptr)blockPtr + cnt);
		do	{
			*tPtr++ = 0;
			} while(--cnt);
		}

	#ifdef __USEVECT__
	 if ((thSize >= sizeof(double)) && ((long)blockPtr & ((sizeof(double) * 2) - 1)))	// align to vector boundary
	 	{
	 	*blockPtr++ = zeroDoubl;
	 	thSize -= sizeof(double);
	 	}
	 #endif
	 
	cnt = thSize / sizeof(double);
	if (quadDoubl = cnt / 4)
		{
		cnt -= (quadDoubl * 4);
		 #ifdef __USEVECT__
			{
			vector unsigned long	vZero;
			long					vCnt = 0,  numDblAdd = quadDoubl * 4;
			vZero = vec_splat_u32(0);		// Makes a vector with all zeros
			do	{
				vec_stl(vZero, vCnt, (vector unsigned long*)blockPtr);
				vCnt += sizeof(vZero);
				vec_stl(vZero, vCnt, (vector unsigned long*)blockPtr);
				vCnt += sizeof(vZero);
				} while(--quadDoubl);
			blockPtr += numDblAdd;
			}
		#else
			do	{
				*blockPtr++ = zeroDoubl;
				*blockPtr++ = zeroDoubl;
				*blockPtr++ = zeroDoubl;
				*blockPtr++ = zeroDoubl;
				} while(--quadDoubl);
		#endif
		if (cnt)
			{
			do	{
				*blockPtr++ = zeroDoubl;
				} while(--cnt);
			}
		}
	else if (cnt)
		{
		do	{
			*blockPtr++ = zeroDoubl;
			} while(--cnt);
		}
	}

if (cnt = thSize & 7)
	{
	tPtr = (Ptr)blockPtr;
	do	{
		*tPtr++ = 0;
		} while(--cnt);
	}
#endif
}
/*
void	ClearBlock(void* blockPtr_p, long thSize)
{
register long	cnt;
register double	zeroDoubl = 0, *blockPtr = blockPtr_p;
Ptr				tPtr;

if (thSize <= 0)
	return;

if (cnt = ((sizeof(double) - ((long)blockPtr & 7)) & 7))	// align to double boundary
	{
	if (cnt > thSize)
		cnt = thSize;
	tPtr = (Ptr)blockPtr;
	thSize -= cnt;
	blockPtr = (double*)((Ptr)blockPtr + cnt);
	do	{
		*tPtr++ = 0;
		} while(--cnt);
	}

if (cnt = (thSize >> 3))
	{
	long	treDoub;
	if (treDoub = cnt / 3)
		{
		cnt -= (treDoub * 3);
		do	{
			*blockPtr++ = zeroDoubl;
			*blockPtr++ = zeroDoubl;
			*blockPtr++ = zeroDoubl;
			} while(--treDoub);
		if (cnt)
			{
			do	{
				*blockPtr++ = zeroDoubl;
				} while(--cnt);
			}
		}
	else
		{
		do	{
			*blockPtr++ = zeroDoubl;
			} while(--cnt);
		}
	}
	
if (cnt = thSize & 7)
	{
	tPtr = (Ptr)blockPtr;
	do	{
		*tPtr++ = 0;
		} while(--cnt);
	}
}
*/
//===========================================================================================
// Note: this doesn't work in sytems where doubles are not 8-bytes long
void	FillBlock(void* blockP, long thSize, char fillVal)
{
register long		cnt;
register double*	blockPtr=(double*)blockP;

if (cnt = thSize >> 3)
	{
	//char				t[8], *saveT = t;
	register double		fillDoubVal;
	//int					i;

	short	sh = fillVal;
	long	lg;
	double	db;
	*(char*)&sh = fillVal;
	lg = sh;
	*(short*)&lg = sh;
	*(long*)((Ptr)&db + sizeof(long)) = lg;
	*(long*)&db = lg;
	fillDoubVal = db;
	
	//for (i = 0; i < sizeof(double); i++)
	//	*t++ = fillVal;
	//fillDoubVal = *(double*)saveT;
	do	{
		*blockPtr++ = fillDoubVal;
		} while(--cnt);
	}
	
if (cnt = thSize & 7)
	{
	do	{
		*(Ptr)blockPtr = (char)fillVal;
		blockPtr = (double*)((Ptr)blockPtr + 1);
		} while(--cnt);
	}
}

//===========================================================================================
void	ShiftDownLongArray(long* srcP, long longCnt)
{
long	*destP, quadCnt;

destP = srcP + longCnt;
srcP = destP - 1;
if (quadCnt = (longCnt >> 2))
	{
	longCnt -= (quadCnt << 2);
	do	{
		*destP-- = *srcP--;
		*destP-- = *srcP--;
		*destP-- = *srcP--;
		*destP-- = *srcP--;
		} while (--quadCnt);
	}

if (longCnt)
	{
	do	{
		*destP-- = *srcP--;
		} while (--longCnt);
	}
}
#ifndef __XLIB_CLIENT__
//===========================================================================================
BlockRef		NewBlock(long size, XErr *errPtr, Ptr *thePtrP)
{
BlockRef	bl;

#ifdef __MAC_XLIB__
	bl = _NewBlock(size, errPtr, NewBlock_low, thePtrP, false);
#else
	bl = _NewBlock(size, errPtr, NewBlock_low, thePtrP);
#endif

#ifdef CHECK_LEAKING
	if (bl)
		_OneMoreHandle(bl);
	#if MEM_DEBUG_DUMP_LEAK	&& __MEM_CANMOVE__	// this moves memory -> reload P
	if (thePtrP)
		*thePtrP = GetPtr(bl);
	#endif
#endif

return bl;
}

#if __MAC_XLIB__
//===========================================================================================
BlockRef		NewBlockLocked(long size, XErr *errPtr, Ptr *thePtrP)
{
BlockRef	bl;

#ifdef __MAC_XLIB__
	bl = _NewBlock(size, errPtr, NewBlock_low, thePtrP, true);
#else
	bl = _NewBlock(size, errPtr, NewBlock_low, thePtrP);
#endif
#ifdef CHECK_LEAKING
	if (bl)
		_OneMoreHandle(bl);
	#if MEM_DEBUG_DUMP_LEAK	&& __MEM_CANMOVE__	// this moves memory -> reload P
	if (thePtrP)
		*thePtrP = GetPtr(bl);
	#endif
#endif

return bl;
}
#endif

//===========================================================================================
BlockRef		NewBlockClear(long size, XErr *errPtr, Ptr *thePtrP)
{
BlockRef	bl;

#ifdef __MAC_XLIB__
	bl = _NewBlock(size, errPtr, NewBlockClear_low, thePtrP, false);
#else
	bl = _NewBlock(size, errPtr, NewBlockClear_low, thePtrP);
#endif
#ifdef CHECK_LEAKING
	if (bl)
		_OneMoreHandle(bl);
	#if MEM_DEBUG_DUMP_LEAK	&& __MEM_CANMOVE__	// this moves memory -> reload P
	if (thePtrP)
		*thePtrP = GetPtr(bl);
	#endif
#endif

return bl;
}

//===========================================================================================
BlockRef		NewPtrBlock(long size, XErr *errPtr, Ptr *thePtrP)
{
BlockRef	bl;

#ifdef __MAC_XLIB__
	bl = _NewBlock(size, errPtr, NewPtrBlock_low, thePtrP, false);
#else
	bl = _NewBlock(size, errPtr, NewPtrBlock_low, thePtrP);
#endif

#ifdef CHECK_LEAKING
	if (bl)
		_OneMorePtr(bl);
	#if MEM_DEBUG_DUMP_LEAK	&& __MEM_CANMOVE__	// this moves memory -> reload P
	if (thePtrP)
		*thePtrP = GetPtr(bl);
	#endif
#endif

return bl;
}

//===========================================================================================
/*XErr			DisposeBlock(BlockRef *blockRefP)
{
MemSlot 		*memSlotP;
long			address, slot;
XErr			err = noErr;
//MemArraySlotP	memArraySlotP;
BlockRef		blockToDispose;

	XThreadsEnterCriticalSection();
	if (blockRefP && (slot = *blockRefP))
	{	slot--;
		memArraySlotP = GET_MEM_ARRAY();
		memSlotP = &memArraySlotP->memSlot[slot];
		address = memSlotP->address;
		blockToDispose = *blockRefP;
		*blockRefP = 0L;		// clean it before moving memory
		if (address)
			err = DisposeBlock_low(&address, memSlotP->isHandle, memSlotP->size);
		else
		{	CDebugStr("ErrXMemory_AttemptToDisposeTwice");
			err = XError(kXLibError, ErrXMemory_AttemptToDisposeTwice);
		}
		if NOT(err)
			{
			#ifdef __MEM_CANMOVE__
				memArraySlotP = GET_MEM_ARRAY();
				memSlotP = &memArraySlotP->memSlot[slot];
			#endif
			gTotalApplicationMemory -= memSlotP->size;
			memSlotP->address = nil;
			#ifdef CHECK_LEAKING
				if (memSlotP->isHandle)
					_OneLessHandle(slot+1);
				else
					_OneLessPtr(slot+1);
			#endif
		#ifndef MEMORY_WHILE_DEBUGGING_NO_OPTIMIZATION
			if (slot < memArraySlotP->firstFreeSlot)
				memArraySlotP->firstFreeSlot = slot;
		#endif
			memArraySlotP->usedSlotCnt--;
			}
		if (err)
			*blockRefP = blockToDispose;
	}
	else
	{	
	#ifdef MEM_DEBUG
		CDebugStr("ErrXMemory_BadRef");
	#endif
		err = XError(kXLibError, ErrXMemory_BadRef);
	}
	XThreadsLeaveCriticalSection();

return err;
}*/

//===========================================================================================
static XErr	_ZeroSlot(Ptr slotP, SlotRef slot, long userData)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(userData)
#endif
#ifndef CHECK_LEAKING
	#if __C_HAS_PRAGMA_UNUSED__
		#pragma unused(slot)
	#endif
#endif
MemSlot		*memSlotP = (MemSlot*)slotP;
XErr		err = noErr;
long		address;

	address = memSlotP->address;
	if (address)
	{	
	#if __MAC_XLIB__
		err = DisposeBlock_low(&address, memSlotP->isHandle, memSlotP->size);
	#else
		err = DisposeBlock_low(&address, memSlotP->size);
	#endif
	if NOT(err)
			memSlotP->address = 0;
	}
	else
	{	CDebugStr("ErrXMemory_AttemptToDisposeTwice");
		err = XError(kXLibError, ErrXMemory_AttemptToDisposeTwice);
	}
	if NOT(err)
	{	gTotalApplicationMemory -= memSlotP->size;
	#ifdef CHECK_LEAKING
		#if __MAC_XLIB__
			if (memSlotP->isHandle)
				_OneLessHandle(slot);
			else
				_OneLessPtr(slot);
		#else
			_OneLessPtr(slot);
		#endif
	#endif
	}
	
return err;
}

//===========================================================================================
XErr			DisposeBlock(BlockRef *blockRefP)
{
XErr			err = noErr;
BlockRef		slot;

	if (blockRefP && (slot = *blockRefP))
	{	*blockRefP = 0L;		// clean it before moving memory
		if (err = FreeSlotElem(gsMemorySlotMgrRef, &slot, _ZeroSlot, 0))
			*blockRefP = slot;
	}
	else
	{	
	#ifdef MEM_DEBUG
		CDebugStr("ErrXMemory_BadRef");
	#endif
		err = XError(kXLibError, ErrXMemory_BadRef);
	}

return err;
}

//===========================================================================================
unsigned long	GetBlockSize(BlockRef blockRef, XErr *errP)
{
#if !__MAC_XLIB__ && __C_HAS_PRAGMA_UNUSED__
	#pragma unused(errP)
#endif
MemSlot 		*memSlotP;
unsigned long	size;

	//XThreadsEnterCriticalSection();
	if (blockRef)
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
	#ifdef __UNIX_XLIB__	
		size = memSlotP->size;
		#ifdef MEM_DEBUG
			_CheckPageGuardians((Ptr)memSlotP->address, size + 16, "in GetBlockSize");
		#endif
	#else
		#if __MAC_XLIB__
			size = GetBlockSize_low(memSlotP->address, memSlotP->isHandle, errP);
		#else
			size = GetBlockSize_low(memSlotP->address, errP);
		#endif
		if (size != (unsigned long)memSlotP->size)
			CDebugStr("BlockMem sizes are different!");
	#endif
	}
	else
		size = 0;
	//XThreadsLeaveCriticalSection();

return size;
}

//===========================================================================================
XErr			SetBlockSize(BlockRef blockRef, unsigned long newSize)
{
MemSlot 		*memSlotP;
XErr			err = noErr;
long			tAddr;
//MemArraySlotP	memArraySlotP;

	//XThreadsEnterCriticalSection();
	//memArraySlotP = GET_MEM_ARRAY();
	if (blockRef > 0)// && (blockRef <= memArraySlotP->slotCnt))
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
		// memSlotP = &memArraySlotP->memSlot[blockRef-1];
		if (tAddr = memSlotP->address)
		{	
		#if __MAC_XLIB__
			err = SetBlockSize_low(&tAddr, memSlotP->isHandle, memSlotP->size, newSize);
		#else
			err = SetBlockSize_low(&tAddr, memSlotP->size, newSize);
		#endif
			if NOT(err)
			{	//memSlotP = GET_MEM_SLOT(blockRef);
				memSlotP->address = tAddr;
				gTotalApplicationMemory += newSize - memSlotP->size;
				memSlotP->size = newSize;
			}
		}
		else
			err = XError(kXLibError, ErrXMemory_BadRef);
	}
	else
		err = XError(kXLibError, ErrXMemory_BadRef);
	//XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr			ExpandBlockClear(BlockRef blockRef, unsigned long newSize)
{
MemSlot 		*memSlotP;
XErr			err = noErr;
long			tAddr;
//MemArraySlotP	memArraySlotP;
Ptr				p;
long			xpanSize;

	//XThreadsEnterCriticalSection();
	//memArraySlotP = GET_MEM_ARRAY();
	if (blockRef > 0)// && (blockRef <= memArraySlotP->slotCnt))
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
		//memSlotP = &memArraySlotP->memSlot[blockRef-1];
		if (tAddr = memSlotP->address)
		{	
		#if __MAC_XLIB__
			err = SetBlockSize_low(&tAddr, memSlotP->isHandle, memSlotP->size, newSize);
		#else
			err = SetBlockSize_low(&tAddr, memSlotP->size, newSize);
		#endif
			if NOT(err)
			{	//memSlotP = GET_MEM_SLOT(blockRef);
				memSlotP->address = tAddr;
				gTotalApplicationMemory += newSize - memSlotP->size;
				if ((xpanSize = newSize - memSlotP->size) > 0)
					{
				#if __MAC_XLIB__	
					p = (memSlotP->isHandle) ? *(Ptr*)tAddr: (Ptr)tAddr;
				#else
					p = (Ptr)tAddr;
				#endif
					ClearBlock(p + memSlotP->size, xpanSize);
					}
				memSlotP->size = newSize;
			}
		}
		else
			err = XError(kXLibError, ErrXMemory_BadRef);
	}
	else
		err = XError(kXLibError, ErrXMemory_BadRef);
	//XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
Ptr				GetPtr(BlockRef blockRef)
{
#if MEM_DEBUG
	MemSlot 	*memSlotP;
	Ptr			p;
	//XErr		err = noErr;

		if (blockRef)
		{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
		#if __MAC_XLIB__
			p = GetPtr_low(memSlotP->address, memSlotP->isHandle);
		#else
			p = GetPtr_low(memSlotP->address);
		#endif
		}
		else
			p = nil;

	return p;
#else
	#if __MAC_XLIB__
		if (blockRef)
		{	MemSlot 	*memSlotP;
		
			memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
			if (memSlotP->isHandle)
				return *(Handle)(memSlotP->address);
			else
				return (Ptr)memSlotP->address;
		}
		else
			return nil;
	#else
		if (blockRef)
			return (Ptr)(((MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef))->address);
		else
			return nil;
	#endif
#endif
}

//===========================================================================================
long				GetAddress(BlockRef blockRef)
{
MemSlot 	*memSlotP;
long		ad;
//XErr		err = noErr;

	//XThreadsEnterCriticalSection();
	if (blockRef)
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
		ad = memSlotP->address;
	}
	else
		ad = 0;
	//XThreadsLeaveCriticalSection();

return ad;
}

//===========================================================================================
XErr	DuplicateBlock(BlockRef source, BlockRef *destBlkP)
{
unsigned long	size;
XErr			err = noErr;
BlockRef		newBlock = 0;
MemSlot 		*memSlotP;
Ptr				destP = nil;

	//XThreadsEnterCriticalSection();
	if (source)
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, source);
		//memSlotP = GET_MEM_SLOT(source);
		size = GetBlockSize(source, &err);
	#if __MAC_XLIB__
		if (memSlotP->isHandle)
			newBlock = NewBlock(size, &err, &destP);
		else
			newBlock = NewPtrBlock(size, &err, &destP);
	#else
		newBlock = NewBlock(size, &err, &destP);
	#endif
		if (newBlock && NOT(err))
			CopyBlock(destP, GetPtr(source), size);
	}
	else
		err = XError(kXLibError, ErrXMemory_BadRef);
	if (err)
		*destBlkP = 0L;
	else
		*destBlkP = newBlock;
	//XThreadsLeaveCriticalSection();

return err;
}

#ifdef __MAC_XLIB__
//===========================================================================================
Boolean	IsLocked(BlockRef blockRef)
{
MemSlot 		*memSlotP;
XErr			err = noErr;
//MemArraySlotP	memArraySlotP;
Boolean			isLocked;

	//XThreadsEnterCriticalSection();
	//memArraySlotP = GET_MEM_ARRAY();
	if (blockRef > 0) //&& (blockRef <= memArraySlotP->slotCnt))
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
		//memSlotP = &memArraySlotP->memSlot[blockRef-1];
		if (memSlotP->address)
			isLocked = IsLocked_low(memSlotP->address);
		else
			err = XError(kXLibError, ErrXMemory_BadRef);		
	}	
	else
		err = XError(kXLibError, ErrXMemory_BadRef);		
	//XThreadsLeaveCriticalSection();

return isLocked;
}

//===========================================================================================
XErr		LockBlock(BlockRef blockRef)
{
MemSlot 		*memSlotP;
XErr			err = noErr;
//MemArraySlotP	memArraySlotP;

	//XThreadsEnterCriticalSection();
	//memArraySlotP = GET_MEM_ARRAY();
	if (blockRef > 0) //&& (blockRef <= memArraySlotP->slotCnt))
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
		//memSlotP = &memArraySlotP->memSlot[blockRef-1];
		if (memSlotP->address)
		{	if (memSlotP->isHandle)
			{	if NOT(memSlotP->lockCount++)
					LockBlock_low(memSlotP->address);
			}
		}
		else
			err = XError(kXLibError, ErrXMemory_BadRef);		
	}	
	else
		err = XError(kXLibError, ErrXMemory_BadRef);		
	//XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr		UnlockBlock(BlockRef blockRef)
{
XErr			err = noErr;
MemSlot 		*memSlotP;
//MemArraySlotP	memArraySlotP;

	//XThreadsEnterCriticalSection();
	//memArraySlotP = GET_MEM_ARRAY();
	if (blockRef > 0)// && (blockRef <= memArraySlotP->slotCnt))
	{	memSlotP = (MemSlot*)GetSlotElem(gsMemorySlotMgrRef, blockRef);
		//memSlotP = &memArraySlotP->memSlot[blockRef-1];
		if (memSlotP->address)
		{	if (memSlotP->isHandle)
			{	if NOT(--memSlotP->lockCount)
					UnlockBlock_low(memSlotP->address);
				if (memSlotP->lockCount < 0)
					CDebugStr("Errore: lockCount < 0");
			}
		}
		else
			err = XError(kXLibError, ErrXMemory_BadRef);		
	}
	//XThreadsLeaveCriticalSection();

return err;
}
#endif

//===========================================================================================
char*	AllocString(long size, char *aCStr, BlockRef *refP, XErr *errP)
{		
XErr		err = noErr;
BlockRef	dataBlock;
char		*stringP;

	*refP = 0;
	stringP = nil;
	if (aCStr && (size < 255))
		stringP = aCStr;
	else
	{	if (dataBlock = NewBlock(size, &err, &stringP))
		{	LockBlock(dataBlock);
			// stringP = GetPtr(dataBlock);
			*refP = dataBlock;
		}
	}
	
*errP = err;
return stringP;
}

//===========================================================================================
XErr	DisposeString(BlockRef *refP)
{		
	if (refP && *refP)
		return DisposeBlock(refP);
	else
		return noErr;
}

//===========================================================================================
/*XErr	XMemoryOptimize(void)
{
unsigned long		lastSlotUsed, tot, i;
MemSlot 			*memSlotP;
MemArraySlotP		memArraySlotP;
XErr				err = noErr;
unsigned long		now, oldSize, totSlots, totBlocks, newSize;

	XThreadsEnterCriticalSection();
	memArraySlotP = GET_MEM_ARRAY();
	XGetSeconds(&now);
	if ((now - memArraySlotP->maxLastMove) > RESET_TIME)
	{	tot = memArraySlotP->slotCnt;
		memSlotP = &memArraySlotP->memSlot[tot-1];
		// find last used
		for (i = 0; i < tot; i++, memSlotP--)
		{	if (memSlotP->address)
				break;
		}
		lastSlotUsed = tot - i;
		if (lastSlotUsed < (tot / 2))		// contiguous last free part is more than 50%
		{	totBlocks = (lastSlotUsed / SLOTS_ALLOC_STEP) + 1;
			totSlots = totBlocks * SLOTS_ALLOC_STEP;
			newSize = offsetof(MemArraySlot, memSlot) + (totSlots * sizeof(MemSlot));
			oldSize = offsetof(MemArraySlot, memSlot) + memArraySlotP->slotCnt * sizeof(MemSlot);
			if NOT(err = SetBlockSize_low(&gsMainMemBlock, true, oldSize, newSize))
			{	memArraySlotP = GET_MEM_ARRAY();
				if (memArraySlotP->firstFreeSlot == UNDEFINED_SLOT)
					memArraySlotP->firstFreeSlot = totSlots;	// just added one block
				gTotalApplicationMemory += newSize - oldSize;
				memArraySlotP->slotCnt = totSlots;
				memArraySlotP->max = lastSlotUsed;
				XGetSeconds(&memArraySlotP->maxLastMove);
			}
		}
	}
	XThreadsLeaveCriticalSection();
	
return err;
}*/
#else	// else #ifndef __XLIB_CLIENT__
#if __MWERKS__
#pragma mark-
#endif

extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
//===========================================================================================
BlockRef		NewBlock(long size, XErr *errPtr, Ptr *thePtrP)
{
XErr	(*p)(long size, XErr *errPtr, Ptr *thePtrP) = (void*)gXLibCallBacksRecPtr->NewBlock;

	return p(size, errPtr, thePtrP);
}

#if __MAC_XLIB__
//===========================================================================================
BlockRef		NewBlockLocked(long size, XErr *errPtr, Ptr *thePtrP)
{
XErr	(*p)(long size, XErr *errPtr, Ptr *thePtrP) = (void*)gXLibCallBacksRecPtr->NewBlockLocked;

	return p(size, errPtr, thePtrP);
}
#endif
//===========================================================================================
BlockRef		NewBlockClear(long size, XErr *errPtr, Ptr *thePtrP)
{
XErr	(*p)(long size, XErr *errPtr, Ptr *thePtrP) = (void*)gXLibCallBacksRecPtr->NewBlockClear;

	return p(size, errPtr, thePtrP);
}

//===========================================================================================
BlockRef		NewPtrBlock(long size, XErr *errPtr, Ptr *thePtrP)
{
XErr	(*p)(long size, XErr *errPtr, Ptr *thePtrP) = (void*)gXLibCallBacksRecPtr->NewPtrBlock;

	return p(size, errPtr, thePtrP);
}

//===========================================================================================
XErr			DisposeBlock(BlockRef *blockRefP)
{
XErr	(*p)(BlockRef *blockRefP) = (void*)gXLibCallBacksRecPtr->DisposeBlock;

	return p(blockRefP);
}

//===========================================================================================
unsigned long	GetBlockSize(BlockRef blockRef, XErr *errP)
{
XErr	(*p)(BlockRef blockRef, XErr *errP) = (void*)gXLibCallBacksRecPtr->GetBlockSize;

	return p(blockRef, errP);
}

//===========================================================================================
XErr			SetBlockSize(BlockRef blockRef, unsigned long newSize)
{
XErr	(*p)(BlockRef blockRef, unsigned long newSize) = (void*)gXLibCallBacksRecPtr->SetBlockSize;

	return p(blockRef, newSize);
}

//===========================================================================================
XErr			ExpandBlockClear(BlockRef blockRef, unsigned long newSize)
{
XErr	(*p)(BlockRef blockRef, unsigned long newSize) = (void*)gXLibCallBacksRecPtr->ExpandBlockClear;

	return p(blockRef, newSize);
}

//===========================================================================================
Ptr				GetPtr(BlockRef blockRef)
{
Ptr	(*p)(BlockRef blockRef) = (void*)gXLibCallBacksRecPtr->GetPtr;

	return p(blockRef);
}

//===========================================================================================
long				GetAddress(BlockRef blockRef)
{
long	(*p)(BlockRef blockRef) = (void*)gXLibCallBacksRecPtr->GetAddress;

	return p(blockRef);
}

//===========================================================================================
XErr	DuplicateBlock(BlockRef source, BlockRef *destP)
{
XErr	(*p)(BlockRef source, BlockRef *destP) = (void*)gXLibCallBacksRecPtr->DuplicateBlock;

	return p(source, destP);
}

#ifdef __MAC_XLIB__
//===========================================================================================
XErr		LockBlock(BlockRef blockRef)
{
XErr	(*p)(BlockRef blockRef) = (void*)gXLibCallBacksRecPtr->LockBlock;

	if (p)
		return p(blockRef);
	else
		return XError(kXLibError, ErrNotImplementedInXLib);
}

//===========================================================================================
XErr		UnlockBlock(BlockRef blockRef)
{
XErr	(*p)(BlockRef blockRef) = (void*)gXLibCallBacksRecPtr->UnlockBlock;

	if (p)
		return p(blockRef);
	else
		return XError(kXLibError, ErrNotImplementedInXLib);
}

//===========================================================================================
Boolean		IsLocked(BlockRef blockRef)
{
Boolean	(*p)(BlockRef blockRef) = (void*)gXLibCallBacksRecPtr->IsLocked;

	if (p)
		return p(blockRef);
	else
		return true;
}
#endif

//===========================================================================================
char*	AllocString(long size, char *aCStr, BlockRef *refP, XErr *errP)
{
char*	(*p)(long size, char *aCStr, BlockRef *refP, XErr *errP) = (void*)gXLibCallBacksRecPtr->AllocString;

	return p(size, aCStr, refP, errP);
}

//===========================================================================================
XErr	DisposeString(BlockRef *refP)
{
XErr	(*p)(BlockRef *refP) = (void*)gXLibCallBacksRecPtr->DisposeString;

	return p(refP);
}
//===========================================================================================
/*XErr	XMemoryOptimize(void)
{
XErr	(*p)(void) = (void*)gXLibCallBacksRecPtr->XMemoryOptimize;

	return p();
}
*/
//===========================================================================================
Boolean	ResetLeaking(void)
{
Boolean	(*p)(void) = (void*)gXLibCallBacksRecPtr->ResetLeaking;

	return p();
}

//===========================================================================================
void	CheckLeaking(char *cStr, long *leakPtrsP, long *leakHandlesP)
{
void	(*p)(char *cStr, long *leakPtrsP, long *leakHandlesP) = (void*)gXLibCallBacksRecPtr->CheckLeaking;

	p(cStr, leakPtrsP, leakHandlesP);
}
#endif	// #ifndef __XLIB_CLIENT__
