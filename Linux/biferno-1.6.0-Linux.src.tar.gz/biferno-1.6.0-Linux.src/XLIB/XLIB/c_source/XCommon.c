/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XCommon.c,v 1.5 2005-11-14 17:11:16 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"
#include "SlotMgr.h"

#ifdef __WIN_XLIB__
	extern HANDLE				gMyHeap;
#endif

#if __UNIX_XLIB__
	#include <stdlib.h>
#endif

#ifdef __XLIB_CLIENT__
	// exported called by XLib Main App
	EXP XErr	RegisterXLibCallBacks(long callsBackPtr);
	EXP long	XLibVersion(long callerVersion, XErr *errP);
	
	long				gCallerXLibVersion;
	XLIB_CallBacksRec*	gXLibCallBacksRecPtr;

	//===========================================================================================
	static XErr	staticRegisterXLibCallBacks(long callsBackPtr)
	{
	XErr	err = noErr;
		
		if (callsBackPtr)
			gXLibCallBacksRecPtr = (XLIB_CallBacksRec*)callsBackPtr;
		
	return err;
	}
	//===========================================================================================
	static long	staticXLibVersion(long callerVersion, XErr *errP)
	{
		if (callerVersion)
			gCallerXLibVersion = callerVersion;
		// Here you can check if the caller's XLib version is satisfying and return error if not
		// Errors can be one of these: ErrXLibCallerTooOld, ErrXLibCallerTooNew
		if (errP)
			*errP = noErr;
		return CUR_XLIB_VERSION;
	}

	#if __MWERKS__
		#pragma export on
	#endif

//#ifdef __MACOSX__
	//===========================================================================================
	EXP XErr	_X_RegisterXLibCallBacks(long callsBackPtr)
	{
		return staticRegisterXLibCallBacks(callsBackPtr);
	}
	//===========================================================================================
	EXP long	_X_XLibVersion(long callerVersion, XErr *errP)
	{
		return staticXLibVersion(callerVersion, errP);
	}
/*#else
	//===========================================================================================
	EXP XErr	RegisterXLibCallBacks(long callsBackPtr)
	{
		return staticRegisterXLibCallBacks(callsBackPtr);
	}
	//===========================================================================================
	EXP long	XLibVersion(long callerVersion, XErr *errP)
	{
		return staticXLibVersion(callerVersion, errP);
	}
#endif*/
	#if __MWERKS__
	#pragma export off
	#endif
#else

	//#ifdef __XLIB_WITH_HELPERS__
	//	
	//#endif

	static XLIB_CallBacksRec*	xlibCallBacksRecPtr = nil;

	#ifdef __WIN_XLIB__
		extern HANDLE	gMyHeap;
	#endif

	#if __UNIX_XLIB__
		#include <errno.h>
	#endif

	//===========================================================================================
	static XErr	_InitXLibCallBacksAPI(void)
	{
	XErr				err = noErr;

	#if __MAC_XLIB__
		if NOT(xlibCallBacksRecPtr = (XLIB_CallBacksRec*)NewPtrClear(sizeof(XLIB_CallBacksRec)))
			err = XGetError();
	#elif __UNIX_XLIB__
		errno = 0;
		if NOT(xlibCallBacksRecPtr = (XLIB_CallBacksRec*)calloc(1, sizeof(XLIB_CallBacksRec)))
			err = errno;
	#else
		if NOT(xlibCallBacksRecPtr = (XLIB_CallBacksRec*)HeapAlloc(gMyHeap, HEAP_ZERO_MEMORY, sizeof(XLIB_CallBacksRec)))
			err = XWinGetLastError();
	#endif
		if NOT(err)
		{	
			XFiles_InitGlue(xlibCallBacksRecPtr);
			XMemory_InitGlue(xlibCallBacksRecPtr);
			XThreads_InitGlue(xlibCallBacksRecPtr);
			#if __UNIX_XLIB__
				XDateTime_InitGlue(xlibCallBacksRecPtr);
			#endif
			
	#ifdef __XLIB_WITH_HELPERS__
			Buffer_InitGlue(xlibCallBacksRecPtr);
			Cache_InitGlue(xlibCallBacksRecPtr);
			TextMgr_InitGlue(xlibCallBacksRecPtr);
			Pool_InitGlue(xlibCallBacksRecPtr);
	#endif

	#ifdef __MAC_XLIB__
			MacUtils_InitGlue(xlibCallBacksRecPtr);
	#endif
		}

	return err;
	}

	//===========================================================================================
	XErr	XCommonInit(void)
	{
	XErr				err = noErr;

		InitSlotManager();
		err = _InitXLibCallBacksAPI();

	return err;
	}

	//===========================================================================================
	XErr	XCommonEnd(void)
	{
	XErr				err = noErr;

	#if __MAC_XLIB__
		DisposePtr((Ptr)xlibCallBacksRecPtr);
	#elif __UNIX_XLIB__
		free((Ptr)xlibCallBacksRecPtr);
	#else
		HeapFree(gMyHeap, 0L, (Ptr)xlibCallBacksRecPtr);
	#endif
		TerminateSlotManager();
	return err;
	}
#endif

//===========================================================================================
XErr	RegisterDllXLib(long dllRef, char *errString, long *dllXLibVersionP, Boolean macosxBundle)
{
XErr		err = noErr;
XErr		(*_registerFunc)(long callsBackPtr);
long		(*_xlibVersionFunc)(long, XErr*);

#ifdef __XLIB_CLIENT__
	XLIB_CallBacksRec*	xlibCallBacksRecPtr = gXLibCallBacksRecPtr;
#endif

	CEquStr(errString, "RegisterXLibCallBacks");
	if NOT(err = XGetDLLSymbol(dllRef, "RegisterXLibCallBacks", (long*)&_registerFunc, macosxBundle))
	{	//printf("Biferno func: %d %d\n", xlibCallBacksRecPtr, xlibCallBacksRecPtr->XYield);
		if NOT(err = _registerFunc((long)xlibCallBacksRecPtr))
		{	CEquStr(errString, "XLibVersion");
			if NOT(err = XGetDLLSymbol(dllRef, "XLibVersion", (long*)&_xlibVersionFunc, macosxBundle))
			{	*dllXLibVersionP = _xlibVersionFunc(CUR_XLIB_VERSION, &err);
				// Here you can check if the XLib version is satisfying and return error if not
				// Errors can be one of these: ErrXLibTooOld, ErrXLibTooNew
				*errString = 0;
			}
		}
	}

return err;
}
