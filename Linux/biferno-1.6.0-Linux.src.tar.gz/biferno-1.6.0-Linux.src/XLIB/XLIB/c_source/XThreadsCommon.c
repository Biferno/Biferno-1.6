/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XThreadsCommon.c,v 1.9 2005-11-04 15:32:13 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

#ifndef __XLIB_CLIENT__

#include "XThreadsPrivate.h"
#include "XMemoryPrivate.h"

#define	TH_DATA_ALLOC_STEP		128
#define	TH_NULL_THREAD			0xFFFFFFFF

/*
#ifdef JAVA_ENABLED
	extern JavaVM				*g_jvm;
	extern JDK1_1InitArgs		g_vm_args;
#endif
*/
typedef struct
	{
	unsigned long	threadRef;
	long			thStackBase;
	long			thStackSize;
	long			thUserData;
//#ifdef JAVA_ENABLED
	long 			envPtr;
//#endif
	} TLSData, *TLSDataP;

typedef struct
	{
	long	dataAllocCnt;
	long	dataElemCnt;
	long	firstFreeSlot;
	long	unused;
	TLSData	tslData[1];
	} TLSSlot, *TLSSlotP;

// Static
static	BlockRef	gThDataBlk = nil;

// Volatile
static	volatile long		gThreads = 0;

// Extern
extern	long		gXLibNewThread;
extern Boolean		gAbortThreads;

//===========================================================================================
void	_MoreThread(void)
{
	XThreadsEnterCriticalSection();
	gThreads++;
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
void	_LessThread(void)
{
	XThreadsEnterCriticalSection();
	gThreads--;
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
long	_TotThreads(void)
{
	return gThreads;
}

//===========================================================================================
/*#ifdef __MAC_XLIB__
static void _XThreadsCloseAllOtherThreads(void)
{
XErr			err = noErr;
TLSSlotP		tlsSlotP;
TLSDataP		tlsDataP;
long			dataAllocCnt, dataElemCnt;
unsigned long	myThreadID, tempThread;

	if (gThDataBlk)
	{	XGetCurrentThread(&myThreadID);
		tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
		LockBlock(gThDataBlk);
		dataAllocCnt = tlsSlotP->dataAllocCnt;
		dataElemCnt = tlsSlotP->dataElemCnt;
		tlsDataP = tlsSlotP->tslData;
		do	{
			tempThread = tlsDataP->threadRef;
			if ((tempThread != TH_NULL_THREAD) && (tempThread != myThreadID))
			{	dataElemCnt--;
				err = DisposeThread(tempThread, (void*)0L, false);	
			}
			tlsDataP++;
		} while(--dataAllocCnt && dataElemCnt);
		UnlockBlock(gThDataBlk);
	}
}
#endif
*/
#ifndef __MAC_XLIB__
//===========================================================================================
XErr	XYield(unsigned long *lastTicksP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(lastTicksP)
#endif
	
	if (gAbortThreads)
		return XError(kXLibError, ErrThreadAborted);
	else
		return noErr;	//_XThreadsCheckForceQuit();
}
#endif
//===========================================================================================
/*
void	_XThreadeNoMoreThreads(void)
{
	gXForceShutDown = true;
}

//===========================================================================================
void	_XThreadeOkMoreThreads(void)
{
	gXForceShutDown = false;
}

//===========================================================================================
XErr	_XThreadsCheckForceQuit(void)
{
	if (gXForceShutDown)
		return XError(kXLibError, ErrApplicationQuitting);
	else
		return noErr;
}
*/
//===========================================================================================
/*XErr	_XThreadsQuitApplication(void)
{
	gXLibQuitApplication = true;
	
return noErr;
}*/

//===========================================================================================
/*
void	XThreadsForceQuit(unsigned long timeout, long threadsToRemain)
{
XErr			err = noErr;


unsigned long	startTicks;
Boolean			timOut;

	if (gThreads > threadsToRemain)
	{	//CDebugStrExt("XThreadsForceQuit: gThreads: ", gThreads, nil);
	
		startTicks = XGetTicks();
		timOut = false;
		while (gThreads > threadsToRemain)
		{	
		#ifdef __MAC_XLIB__
			YieldToAnyThread();
		#endif
			if ((XGetTicks() - startTicks) > timeout)
			{	timOut = true;
				break;
			}
		}
		if (timOut)
		{	gXForceShutDown = true;
			while (gThreads > threadsToRemain)
			{	
			#ifdef __MAC_XLIB__
				YieldToAnyThread();
			#endif
			}
		#ifdef __MAC_XLIB__
			//if (killThreads)
			//	_XThreadsCloseAllOtherThreads();
		#endif
			gXForceShutDown = false;
		}
	}

}*/

//===========================================================================================
void	XThreads_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{
	xlibCallBacksRecPtr->XYield = (long)XYield;

	xlibCallBacksRecPtr->XGetCurrentThread = (long)XGetCurrentThread;
	xlibCallBacksRecPtr->XThreadsEnterCriticalSection = (long)XThreadsEnterCriticalSection;
	xlibCallBacksRecPtr->XThreadsLeaveCriticalSection = (long)XThreadsLeaveCriticalSection;

	xlibCallBacksRecPtr->XNewThread = (long)XNewThread;
	xlibCallBacksRecPtr->XThreadsNewPool = (long)XThreadsNewPool;

	xlibCallBacksRecPtr->XThreadsCreateSemaphore = (long)XThreadsCreateSemaphore;
	xlibCallBacksRecPtr->XThreadsCloseSemaphore = (long)XThreadsCloseSemaphore;
	xlibCallBacksRecPtr->XThreadsSemaphoreGreen = (long)XThreadsSemaphoreGreen;
	xlibCallBacksRecPtr->XThreadsWaitSemaphore = (long)XThreadsWaitSemaphore;

	xlibCallBacksRecPtr->XThreadsSetTLS = (long)XThreadsSetTLS;
	xlibCallBacksRecPtr->XThreadsGetTLS = (long)XThreadsGetTLS;
	xlibCallBacksRecPtr->XThreadsGetThreadInfo = (long)XThreadsGetThreadInfo;
	xlibCallBacksRecPtr->XThreadsStopThreads = (long)XThreadsStopThreads;
	xlibCallBacksRecPtr->XThreadsResumeThreads = (long)XThreadsResumeThreads;
}

//===========================================================================================
static void _XThreadsClearTLS(TLSDataP tlsDataP, long slotCnt)
{

while (slotCnt--)
	{
	tlsDataP->threadRef = TH_NULL_THREAD;
	tlsDataP->thStackSize = tlsDataP->thStackBase = 0;
	tlsDataP++;
	}
}
//===========================================================================================
XErr _XThreadsCloseTLSSystem(void)
{
	if (gThDataBlk)
		DisposeBlock(&gThDataBlk);

return noErr;
}

//===========================================================================================
XErr _XThreadsNewTLS(unsigned long threadRef, long thStackBase, long thStackSize)
{
XErr			err = noErr;
TLSSlotP		tlsSlotP;
TLSDataP		tlsDataP;
long			dataAllocCnt, dataElemCnt;

XThreadsEnterCriticalSection();
if not(gThDataBlk)
	{
	dataAllocCnt = TH_DATA_ALLOC_STEP;
	if not(gThDataBlk = NewBlock((sizeof(TLSSlot) - sizeof(TLSData)) + (sizeof(TLSData) * dataAllocCnt), &err, (Ptr*)&tlsSlotP))
		goto out;
	//tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
	tlsSlotP->dataAllocCnt = dataAllocCnt;
	tlsSlotP->dataElemCnt = 0;
	tlsSlotP->firstFreeSlot = 0;			// not used now
	_XThreadsClearTLS(tlsSlotP->tslData, dataAllocCnt);
	}
else
	{
	tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
	dataAllocCnt = tlsSlotP->dataAllocCnt;
	if (tlsSlotP->dataElemCnt == dataAllocCnt)
		{
		dataAllocCnt += TH_DATA_ALLOC_STEP;
		if (err = SetBlockSize(gThDataBlk, (sizeof(TLSSlot) - sizeof(TLSData)) + (sizeof(TLSData) * dataAllocCnt)))
			goto out;
		tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
		_XThreadsClearTLS(&tlsSlotP->tslData[tlsSlotP->dataAllocCnt], TH_DATA_ALLOC_STEP);
		tlsSlotP->dataAllocCnt = dataAllocCnt;
		}
	}

tlsDataP = tlsSlotP->tslData;
dataElemCnt = tlsSlotP->dataElemCnt;
do	{
	if (tlsDataP->threadRef == TH_NULL_THREAD)
		break;
	tlsDataP++;
	} while(--dataAllocCnt);

if NOT(dataAllocCnt)
{	err = ErrXThreads_InternalErr;			// should never happen
	goto out;
}

tlsSlotP->dataElemCnt++;
tlsDataP->threadRef = threadRef;
tlsDataP->thStackBase = thStackBase;
tlsDataP->thStackSize = thStackSize;
tlsDataP->thUserData = nil;

#ifdef __XLIB_WITH_HELPERS__
	if (err = XLibAttachJVM_API((void**)&tlsDataP->envPtr))
		goto out;
#endif

out:
XThreadsLeaveCriticalSection();
return err;
}
//===========================================================================================
XErr _XThreadsDisposeTLS(unsigned long threadRef, long *thUserDataP)
{
TLSSlotP		tlsSlotP;
TLSDataP		tlsDataP;
long			dataAllocCnt;
XErr			err = noErr;

if NOT(gThDataBlk)
	return noErr;
	
XThreadsEnterCriticalSection();
tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
dataAllocCnt = tlsSlotP->dataAllocCnt;
tlsDataP = tlsSlotP->tslData;

if (dataAllocCnt)
	{
	do	{
		if (tlsDataP->threadRef == threadRef)
			break;
		tlsDataP++;
		} while (--dataAllocCnt);
	}

if (dataAllocCnt <= 0)
{	err = ErrXThreads_NotFound;			// couldn't find the thread
	goto out;
}

tlsSlotP->dataElemCnt--;
if (thUserDataP)
	*thUserDataP = tlsDataP->thUserData;
tlsDataP->threadRef = TH_NULL_THREAD;
#ifdef __XLIB_WITH_HELPERS__
	XLibDetachJVM_API();
#endif

out:
XThreadsLeaveCriticalSection();
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	XThreadsLeaveCriticalSectionExt(void)
{
	__XThreadsLeaveCriticalSection();
	#if CHECK_LEAKING
		_OneLessLockNoStackCheck();
	#endif
}

//===========================================================================================
XErr	XThreadsStopThreads(long threadsToRemain)
{
XErr				err = noErr;
unsigned long 		initMilliSecs, millisecs, lastTicks = 0;

	if NOT(err = XThreadsWaitSemaphore(&gXLibNewThread, kXLibStopThreadsTimeout))
	{	// Wait that users exit
		XGetMilliseconds(&initMilliSecs);
		while ((gThreads > threadsToRemain) && NOT(err))
		{
		#ifndef __MAC_XLIB__
			XDelay(60);
		#endif
			if NOT(err = XYield(&lastTicks))
			{	XGetMilliseconds(&millisecs);
				if ((millisecs - initMilliSecs) > kXLibStopThreadsTimeout)
					err = XError(kXLibError, ErrXThreads_Timeout);
			}
		}
		if (err == XError(kXLibError, ErrXThreads_Timeout))
		{	err = noErr;
			gAbortThreads = true;
			XGetMilliseconds(&initMilliSecs);
			while ((gThreads > threadsToRemain) && NOT(err))
			{
			#ifndef __MAC_XLIB__
				XDelay(60);
			#endif
				XYield(&lastTicks);		// don't check error
				XGetMilliseconds(&millisecs);
				if ((millisecs - initMilliSecs) > kXLibStopThreadsTimeout)
					err = XError(kXLibError, ErrXThreads_Timeout);
			}
			gAbortThreads = false;
		}
		if (err)
		{	// Sorry, we couldn't stop the terrible stream of requests
			XThreadsSemaphoreGreen(&gXLibNewThread);
		}
	}
	
return err;
}

//===========================================================================================
XErr	XThreadsResumeThreads(void)
{
XErr	err = noErr;

	err = XThreadsSemaphoreGreen(&gXLibNewThread);
	gAbortThreads = false;

return err;
}

//===========================================================================================
XErr XThreadsSetTLS(long thUserData)
{
XErr			err = noErr;
TLSSlotP		tlsSlotP;
TLSDataP		tlsDataP;
long			dataAllocCnt;
unsigned long 	threadRef;

if (err = XGetCurrentThread(&threadRef))
	return err;

XThreadsEnterCriticalSection();
tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
dataAllocCnt = tlsSlotP->dataAllocCnt;
err = ErrXThreads_NotFound;
if (dataAllocCnt)
	{
	tlsDataP = tlsSlotP->tslData;
	do	{
		if (tlsDataP->threadRef == threadRef)
			{
			tlsDataP->thUserData = thUserData;
			err = noErr;
			break;
			}
		tlsDataP++;
		} while (--dataAllocCnt);
	}
XThreadsLeaveCriticalSection();
return err;
}
//===========================================================================================
long XThreadsGetTLS(void)
{
TLSSlotP		tlsSlotP;
TLSDataP		tlsDataP;
long			dataAllocCnt, thUserData = nil;
unsigned long 	threadRef;

if (XGetCurrentThread(&threadRef))
	return nil;

XThreadsEnterCriticalSection();
tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
dataAllocCnt = tlsSlotP->dataAllocCnt;
if (dataAllocCnt)
	{
	tlsDataP = tlsSlotP->tslData;
	do	{
		if (tlsDataP->threadRef == threadRef)
			{
			thUserData = tlsDataP->thUserData;
			break;
			}
		tlsDataP++;
		} while (--dataAllocCnt);
	}
XThreadsLeaveCriticalSection();
return thUserData;
}
//===========================================================================================
long XThreadsGetThreadInfo (long *thStackSizeP, long *javaEnvP)
{
TLSSlotP		tlsSlotP;
TLSDataP		tlsDataP;
long			dataAllocCnt, stackBaseP = nil;
unsigned long 	threadRef;

if (javaEnvP)
	*javaEnvP = nil;
if (XGetCurrentThread(&threadRef))
	return nil;

tlsSlotP = (TLSSlotP)GetPtr(gThDataBlk);
dataAllocCnt = tlsSlotP->dataAllocCnt;

if (dataAllocCnt)
	{	
	tlsDataP = tlsSlotP->tslData;
	do	{
		if (tlsDataP->threadRef == threadRef)
			{
			stackBaseP = tlsDataP->thStackBase;
			if (thStackSizeP)
				*thStackSizeP = tlsDataP->thStackSize;
			if (javaEnvP)
				*javaEnvP = tlsDataP->envPtr;
			break;
			}
		tlsDataP++;
		} while (--dataAllocCnt);
	}

return stackBaseP;
}

#else
#if __MWERKS__
#pragma mark-
#endif

extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
//===========================================================================================
XErr	XYield(unsigned long *lastTicksP)
{
XErr	(*p)(unsigned long *lastTicksP) = (void*)gXLibCallBacksRecPtr->XYield;

	return p(lastTicksP);
}
//===========================================================================================
XErr	XGetCurrentThread(unsigned long *threadIDP)
{
XErr	(*p)(unsigned long *threadIDP) = (void*)gXLibCallBacksRecPtr->XGetCurrentThread;

	return p(threadIDP);
}

//===========================================================================================
void	XThreadsEnterCriticalSection(void)
{
void	(*p)(void) = (void*)gXLibCallBacksRecPtr->XThreadsEnterCriticalSection;

	p();
}

//===========================================================================================
void	XThreadsLeaveCriticalSection(void)
{
void	(*p)(void) = (void*)gXLibCallBacksRecPtr->XThreadsLeaveCriticalSection;

	p();
}

//===========================================================================================
XErr	XNewThread(unsigned long *threadID, long flags, void* (*func)(void*), unsigned long newThreadStackSize, void *args)
{
XErr	(*p)(unsigned long *threadID, long flags, void* (*func)(void*), unsigned long newThreadStackSize, void *args) = (void*)gXLibCallBacksRecPtr->XNewThread;

	return p(threadID, flags, func, newThreadStackSize, args);
}

//===========================================================================================
XErr	XThreadsNewPool(long maxThreads, unsigned long size)
{
XErr	(*p)(long maxThreads, unsigned long size) = (void*)gXLibCallBacksRecPtr->XThreadsNewPool;

	return p(maxThreads, size);
}

//===========================================================================================
long	XThreadsCreateSemaphore(long initialState, XErr *errP)
{
long	(*p)(long initialState, XErr *errP) = (void*)gXLibCallBacksRecPtr->XThreadsCreateSemaphore;

	return p(initialState, errP);
}

//===========================================================================================
XErr	XThreadsCloseSemaphore(long semaphore)
{
XErr	(*p)(long semaphore) = (void*)gXLibCallBacksRecPtr->XThreadsCloseSemaphore;

	return p(semaphore);
}

//===========================================================================================
XErr	XThreadsSemaphoreGreen(long *semaphore)
{
XErr	(*p)(long *semaphore) = (void*)gXLibCallBacksRecPtr->XThreadsSemaphoreGreen;

	return p(semaphore);
}

//===========================================================================================
XErr	XThreadsWaitSemaphore(volatile long *semaphore, long timeout)
{
XErr	(*p)(volatile long *semaphore, long timeout) = (void*)gXLibCallBacksRecPtr->XThreadsWaitSemaphore;

	return p(semaphore, timeout);
}

//===========================================================================================
XErr	XThreadsSetTLS(long thUserData)
{
XErr	(*p)(long thUserData) = (void*)gXLibCallBacksRecPtr->XThreadsSetTLS;

	return p(thUserData);
}

//===========================================================================================
long	XThreadsGetTLS(void)
{
long	(*p)(void) = (void*)gXLibCallBacksRecPtr->XThreadsGetTLS;

	return p();
}

//===========================================================================================
long	XThreadsGetThreadInfo(long *thStackSizeP, long *javaEnvP)
{
long	(*p)(long *thStackSizeP, long *javaEnvP) = (void*)gXLibCallBacksRecPtr->XThreadsGetThreadInfo;

	return p(thStackSizeP, javaEnvP);
}

//===========================================================================================
XErr	XThreadsStopThreads(long threadsToRemain)
{
XErr	(*p)(long threadsToRemain) = (void*)gXLibCallBacksRecPtr->XThreadsStopThreads;

	return p(threadsToRemain);
}

//===========================================================================================
XErr	XThreadsResumeThreads(void)
{
XErr	(*p)(void) = (void*)gXLibCallBacksRecPtr->XThreadsResumeThreads;

	return p();
}
#endif
