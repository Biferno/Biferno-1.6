/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMgr_ACGIMac.c,v 1.11 2006-01-04 11:29:42 valfer Exp $
	|______________________________________________________________________________
*/


// ======== CGI Controller Valerio Ferrucci 28/11/1997 ============
#include	"HTTPMgr.h"
#include 	"HTTPMrgNet.h"

#include	"XLibPrivate.h"
#include	"XFilesMacPrivate.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//
//#include 	"MacLog.h"
//#include 	"FLog.h"

#include 	"XThreadsPrivate.h"

#define	INDEX_FILE				"index.bfr"
#define	INDEX_FILE_LENGTH		9

typedef struct AEvents
	{
	AppleEvent		theAppleEvent;
	AppleEvent		theReply;
	Boolean			sendPartialFlag;
	Byte			pad1;
	short			pad2;
	BlockRef		sendPartialHandle;	
	long			totalSendSize;
	long			howManySend;
	long			sendNum;
	AEAddressDesc	webStarAddr;
	long			webStarConnID;
	} AEvents, *AEventsP;

//AEParam
#define kAEClassCGI			'WWW�'
#define kAEIDSearchDoc		'sdoc'
#define kpath_args			'----'
#define khttp_search_args	'kfor'
#define kusername			'user'
#define kpassword			'pass'
#define kfrom_user			'frmu'
#define kclient_address		'addr'
#define kpost_args			'post'
#define kmethod				'meth'
#define kserver_name		'svnm'
#define kserver_port		'svpt'
#define kscript_name		'scnm'
#define kcontent_type		'ctyp'
#define kreferer			'refr'
#define kuser_agent			'Agnt'
#define kaction				'Kact'
#define kaction_path		'Kapt'
#define kclient_ip			'Kcip'
#define kfull_request		'Kfrq'
#define kWebSTARFolder		'DIRE'

//MaxMem
#define		MinFreeBlock	16000L

//Menu
#define		TOTMENU			2

// send partial
#define kMyAESendPartial	'SPar'
#define	kAEFlags			kAECanInteract + kAECanSwitchLayer + kAENoReply
#define ONE_SENDPARBLOCK	(30L * 1024L)

// STATIC
static	HTTPControllerP	gHttpControllerP;
static	BlockRef		gHttpControllerBlock;
//static	MenuHandle		gMenuH[TOTMENU];
static	unsigned long 	theTicksToSleep = 0, last = 0;	//, gLastTicks = 0;
static	char			appName[255];
//static	long			gCGIParamList = 0;
static	unsigned long	gACGIUsers;

static char	errorMessage[] = "Error executing ACGI: (Err = ";
static char httpHeaderInit[] = "HTTP/1.0 200 OK\r\nMIME-Version: 1.0\r\nContent-type: text/html\r\n\r\n<HTML><BODY>";
//static char httpHeaderEnd[] = ")</BODY></HTML>";

static EventRecord		gEvent;
static long				gWinRef;
static XFileRef			gLogRef;

static Boolean				done, gRefusing;
static long					gACGIThreads;
static	Boolean				gPlaySounded = false, gsGenericThreadFinished;
static	Boolean				gExpulseDone = false, gsFileProcessing = false;
static	long				gACGIMaxUsers;

static	MenuHandle			gsMenuH;

static	Boolean				gsNewLineFound = false;
static	RGBColor			gsColor = {0, 0, 0};
static	unsigned long		gsYieldCnt = 0;

static LONGLONG 	gGlobalCount = 0;

CStr255		gsUpSinceStr;
XFileRef	gExtraLogRefNum = 0, gCurrentLogRefNum = 0;

//extern	CStr255			globalErrStr;
#ifdef __MAC_XLIB__
	extern	XYieldProc			gYieldProc;
#endif

/*typedef struct {
				long			id;
				Boolean			sendPartialFlag;
				BlockRef		sendPartialHandle;	
				long			totalSendSize;
				long			howManySend;
				long			sendNum;
				AEAddressDesc	webStarAddr;
				long			webStarConnID;
				} ThreadRec;*/

// static 		ThreadRec		*gThreadsRecP;

static Boolean gMonoThread = false;

static	Boolean					gsQuitting;

#ifdef __MACOSX__

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

//===========================================================================================
static XErr _MacOSX_FSSpecToUnixStylePath(FSSpec *specP, char *filePath)
{
FSRef 	newRef;
XErr	err = noErr;

	if NOT(err = FSpMakeFSRef(specP, &newRef))
		err = FSRefMakePath(&newRef, (unsigned char*)filePath, 255);	

return err;
}
#endif

//===========================================================================================
static XErr 	_HttpMgrGetCFullPath(FSSpecPtr fileSpecPtr, char *fullPath)
{
XErr	err = noErr;

	#ifdef __MACOSX__
		err = _MacOSX_FSSpecToUnixStylePath(fileSpecPtr, fullPath);
	#else
		err = _GetCFullPath(fileSpecPtr, fullPath);
	#endif
	
return err;
}
#pragma mark-

#if TARGET_API_MAC_CARBON

// Navigator
typedef Boolean (*NavigatorUpdateProc)(WindowPtr);

typedef struct {
				FSSpec		sfFile;
				Boolean		sfGood;
				Boolean		sfReplacing;
				} NavigatorFileReply, *NavigatorFileReplyP;

static	Boolean					gNavServicesExists;
static	OSType					gAppSignature;
static	Str255					gAppName;
static	NavigatorUpdateProc		UpdateProc;

#define kNavigationFlags		(kNavDontAutoTranslate+kNavDontAddTranslateItems+kNavAllowPreviews+kNavSelectDefaultLocation+kNavNoTypePopup)

extern	RGBColor		myWhite, myBlack, mymidGray, myltGray, mydkGray, myAvarage;

//===========================================================================================
static pascal Boolean myFilterProc(AEDesc* theItem, void* info, NavCallBackUserData callBackUD, NavFilterModes filterMode)
{
#pragma unused(filterMode, callBackUD)
NavTypeListPtr		navListP;
int					i, numTypes;
//XErr				err = noErr;
OSType				type;
NavFileOrFolderInfo	*theInfo = (NavFileOrFolderInfo*)info;

	//return true;
	if (theItem->descriptorType == typeFSS)
	{	if (theInfo->isFolder)
			return true;
		else
		{
			if (callBackUD)
			{	type = theInfo->fileAndFolder.fileInfo.finderInfo.fdType;
				navListP = *((NavTypeListHandle)callBackUD);
				numTypes = navListP->osTypeCount;
				if (numTypes == -1)
					return true;
				else
				{	for (i = 0; i < numTypes; i++)
					{	if (navListP->osType[i] == type)
							return true;
					}
				}
			}
			else
				return true;
		}	
	}
	else
		return true;
	
return false;
}

//===========================================================================================
static pascal void myEventProc(const NavEventCallbackMessage callBackSelector, 
						NavCBRecPtr callBackParms, 
						NavCallBackUserData callBackUD)
{
#pragma unused(callBackUD)
//XErr		theErr = noErr;

	switch (callBackSelector)
	{
		case kNavCBEvent:
			switch (callBackParms->eventData.eventDataParms.event->what)
			{
				case mouseDown:
					break;
					
				case updateEvt:
						if (UpdateProc)
							UpdateProc((WindowPtr)callBackParms->eventData.eventDataParms.event->message);
						break;

				default:
					break;
			}
			break;

		case kNavCBCustomize:
			break;
			
		case kNavCBStart:
			break;
			
		case kNavCBTerminate:
			break;
	}
}

//===========================================================================================
static XErr NAV_Get(short numTypes, OSType *typeList, Boolean *good, FSSpec *fileSpecP, void *filterProc, StringPtr actionLabel)
{	
#pragma unused(filterProc)
NavReplyRecord		theReply;
NavDialogOptions	dialogOptions;
XErr				err = noErr;
NavTypeListHandle	openListH = NULL;
long				i, index, count = 0;
NavObjectFilterUPP	filterUPP = nil;
NavEventUPP			eventUPP = nil;
FSSpec				finalFSSpec;	
AEDesc 				defaultAEDescFSS, resultDesc, *defaultSpecP;
	
	defaultAEDescFSS.dataHandle = 0;

	filterUPP = NewNavObjectFilterUPP(myFilterProc);
	eventUPP = NewNavEventUPP(myEventProc);
	//dialogOptions.location = gLoc_Point;
	
	// default behavior for browser and dialog:
	if (err = NavGetDefaultDialogOptions(&dialogOptions))
		goto out;

	PEquStr(dialogOptions.clientName, gAppName);
	PEquStr(dialogOptions.actionButtonLabel, actionLabel);
	//dialogOptions.dialogOptionFlags = kNavNativeOptionFlags;//kNavGenericOptionFlags;
	
	if (numTypes >= 0)
	{	if NOT(openListH = (NavTypeListHandle)NewHandle(sizeof(NavTypeList) + ((numTypes-1) * sizeof(OSType))))
		{	err = XGetError();
			goto out;
		}
		for (i = 0; i < numTypes; i++)
			(*openListH)->osType[i] = typeList[i];
		(*openListH)->osTypeCount = numTypes;
		(*openListH)->componentSignature = gAppSignature;
	}		
	else
		openListH = NULL;
	
	/*else
	{	if NOT(openListH = (NavTypeListHandle)NewHandleGlobE(sizeof(NavTypeList), &err))
			goto out;
	}*/
	
	
	dialogOptions.preferenceKey = 0;
	dialogOptions.dialogOptionFlags = kNavigationFlags;

	if (fileSpecP->name[0])
	{	if (err = AECreateDesc(typeFSS, fileSpecP, sizeof(FSSpec), &defaultAEDescFSS))
			goto out;
		defaultSpecP = &defaultAEDescFSS;
	}
	else
		defaultSpecP = nil;
	
	err = NavGetFile(defaultSpecP,
						&theReply,
						&dialogOptions,
						eventUPP,
						NULL,	// no custom previews
						filterUPP,
						openListH,
						nil);
						
out:
	if (defaultAEDescFSS.dataHandle)
		err = AEDisposeDesc(&defaultAEDescFSS);
	if (filterUPP)
		DisposeNavObjectFilterUPP(filterUPP);
	if (eventUPP)
		DisposeNavEventUPP(eventUPP);
	if (openListH)
		DisposeHandle((Handle)openListH);

	if (theReply.validRecord && NOT(err))
	{	err = AECountItems(&(theReply.selection), &count);
		for (index=1;index<=count; index++)
		{	resultDesc.dataHandle = 0L;
			if ((err = AEGetNthDesc(&(theReply.selection),index,typeFSS,NULL,&resultDesc)) == noErr)
			{	if NOT(err = AEGetDescData(&resultDesc,&finalFSSpec,sizeof(FSSpec)))
				{	// BlockMoveData(*resultDesc.dataHandle,&finalFSSpec,sizeof(FSSpec));
					err = AEDisposeDesc(&resultDesc);
				}
				break;	// prendo solo il primo file
			}
		}
	}
	*good = theReply.validRecord;
	*fileSpecP = finalFSSpec;
		
	err = NavDisposeReply(&theReply);	// clean up after ourselves	

return err;
}

//===========================================================================================
static XErr	Navigator_GetFile(short numTypes, OSType *typeList, NavigatorFileReplyP replyPtr)
{
XErr	err = noErr;

	if (gNavServicesExists)
		err = NAV_Get(numTypes, typeList, &replyPtr->sfGood, &replyPtr->sfFile, nil, "\pOpen");
	/*else	// old way
	{	StandardFileReply	reply;
		UniversalProcPtr 		fileFilterProcRecPtr = nil;
	
		//if (fileFilter)		
		//	fileFilterProcRecPtr = NewFileFilterYDProc(fileFilter);

		reply.sfFile = replyPtr->sfFile;
		StandardGetFile(nil, numTypes, typeList, &reply);

		if (fileFilterProcRecPtr)	
			DisposeRoutineDescriptor(fileFilterProcRecPtr);		
		replyPtr->sfFile = reply.sfFile;
		replyPtr->sfGood = reply.sfGood;
	}*/
		
return err;
}

//===========================================================================================
static XErr	Navigator_Init(OSType appSignature, StringPtr appName, NavigatorUpdateProc updateProc)
{
XErr	err = noErr;
	
	if (gNavServicesExists = NavServicesAvailable())
		err = NavLoad();
	gAppSignature = appSignature;
	PEquStr(gAppName, appName);
	UpdateProc = updateProc;
	
return err;
}

//===========================================================================================
static XErr	Navigator_End(void)
{
	if (gNavServicesExists)
		return 	NavUnload();
	else
		return noErr;
}
#endif	// TARGET_API_MAC_CARBON
#pragma mark-
//===========================================================================================
static void	_BegineSendPartial(BlockRef buffToSendH, AEventsP aeventP)
{
	aeventP->sendPartialFlag = true;
	aeventP->sendPartialHandle = buffToSendH;	
	aeventP->totalSendSize = GetBlockSize(buffToSendH, nil);
	aeventP->howManySend = (aeventP->totalSendSize / ONE_SENDPARBLOCK) + ((aeventP->totalSendSize % ONE_SENDPARBLOCK) != 0);
	aeventP->sendNum = 0;
}

//===========================================================================================
static	void	_CloseSendPartial(AEventsP aeventP)
{
	aeventP->sendPartialFlag = false;
	DisposeBlock(&aeventP->sendPartialHandle);
	aeventP->sendPartialHandle = nil;	
	aeventP->totalSendSize = 0;
	aeventP->howManySend = 0;
	aeventP->sendNum = 0;
	AEDisposeDesc(&aeventP->webStarAddr);
}

//===========================================================================================
static	Boolean	_HandleSendPartialAEvent(AEventsP aeventP)
{
AppleEvent		ourEvent, ourReply;
AEAddressDesc	wbAddrCopy;
XErr			err;
long			thisSendSize;
Boolean			moreFlag = true;
Ptr				sendPartialPtr;

aeventP->sendNum++;

if (aeventP->sendNum == aeventP->howManySend)
{	thisSendSize = (aeventP->totalSendSize % ONE_SENDPARBLOCK);
	moreFlag = false;
}
else
	thisSendSize = ONE_SENDPARBLOCK;
	
if (err = AEDuplicateDesc(&aeventP->webStarAddr, &wbAddrCopy))
	goto out2;

if (err = AECreateAppleEvent(kAEClassCGI, kMyAESendPartial, &wbAddrCopy, kAutoGenerateReturnID, kAnyTransactionID, &ourEvent))
	goto out1;

LockBlock(aeventP->sendPartialHandle);
sendPartialPtr = GetPtr(aeventP->sendPartialHandle);
sendPartialPtr += ((aeventP->sendNum-1) * ONE_SENDPARBLOCK);

if (err = AEPutParamPtr(&ourEvent, keyDirectObject, typeChar, sendPartialPtr, thisSendSize))
	goto out;
	
if (err = AEPutParamPtr(&ourEvent, 'Kcid', typeLongInteger, &aeventP->webStarConnID, sizeof(long)))
	goto out;

if (err = AEPutParamPtr(&ourEvent, 'Kmor', typeBoolean, &moreFlag, sizeof(moreFlag)))
	goto out;

if (err = AESend(&ourEvent, &ourReply, kAEFlags, kAENormalPriority, kAEDefaultTimeout, nil, nil))
	goto out;
UnlockBlock(aeventP->sendPartialHandle);

out:
AEDisposeDesc(&ourEvent);
out1:
AEDisposeDesc(&wbAddrCopy);
out2:
if (err)
	moreFlag = false;
if NOT(moreFlag)
	_CloseSendPartial(aeventP);
return moreFlag;
}
#pragma mark-
//===========================================================================================
static BlockRef	_HTTPPtrToHandle(Ptr cStr, long saveLen)
{
BlockRef	h;
XErr		err = noErr;
Ptr			p;

	if NOT(h = NewBlockLocked(saveLen, &err, &p))
		return 0;
	//LockBlock(h);
	CopyBlock(p, cStr, saveLen);
	if (err)
		h = nil;

return h;
}

//===========================================================================================
static XErr _LogError(void *taskID, XErr err)
{
CStr255		errStr, eNameStr, eMsg;
int			errLen;
char		cStr[255], httpStr[512];
BlockRef	h;
XErr		theErr = 0;
//CStr15		tStr;

	if (err)
	{	CNumToString(err, errStr);
		CEquStr(cStr, errorMessage);
		CAddStr(cStr, errStr);
		ErrorGetDescr(err, eNameStr, eMsg);
		CAddStr(cStr, " - ");
		CAddStr(cStr, eNameStr);
		if (CLen(eMsg))
		{	CAddStr(cStr, " ");
			CAddStr(cStr, eMsg);
		}
		CAddStr(cStr, ")");
		HTTPControllerLog(0, cStr);
		
		if (taskID)
		{	CEquStr(httpStr, httpHeaderInit);	
			CAddStr(httpStr, cStr);
			errLen = CLen(httpStr);	
			if (h = _HTTPPtrToHandle(httpStr, errLen))
				theErr = HTTPControllerSendReply(taskID, h, errLen);
		}
		//return theErr;
	}
	/*else
	{	CopyBlock(cStr, "OK (Err = 0)", 12);
		cStr[12] = 0;
		if ((gACGIThreads > 1) && NOT(gsQuitting))
		{	CNumToString(gACGIThreads, tStr);
			CAddStr(cStr, " threads: ");
			CAddStr(cStr, tStr);
			CNumToString(gACGIUsers, tStr);
			CAddStr(cStr, " users: ");
			CAddStr(cStr, tStr);
		}
		HTTPControllerLog(0, cStr);
		return 0;
	}*/

return theErr;
}

//===========================================================================================
static XErr	_InitThreads(long maxThreads)
{
	return XThreadsNewPool(maxThreads, HTTP_THREAD_STACK_SIZE);
	
/*
//Str31		maxThreadsStr;
//CStr255		aStr;
XErr		err = noErr;
//double		memUsed;
//Size		lFreeBytes, growBytes;
//CStr15		tStr;

	//lFreeBytes = MaxMem(&growBytes);
	// if NOT(err = CreateThreadPool(kCooperativeThread, maxThreads, (Size)THREAD_STACK_SIZE))
	{	//PNumToString(maxThreads, maxThreadsStr);
		//CEquStr(aStr, "MAX THREADS: ");
		//AddPascalToCStr(aStr, maxThreadsStr);
		//memUsed = ((double)THREAD_STACK_SIZE * (double)maxThreads) / (double)1024;
		
		/*
		CNumToString(THREAD_STACK_SIZE, tStr);
		CAddStr(aStr, " (* ");
		CAddStr(aStr, tStr);
		CAddStr(aStr, "K = ");
		PRealToStr(&memUsed, maxThreadsStr, 1);
		AddPascalToCStr(aStr, maxThreadsStr);
		CAddStr(aStr, " MB used)");
		HTTPControllerLog(0, " ");
		HTTPControllerLog(0, "===: QWScript Memory Allocation: ");
		HTTPControllerLog(0, aStr);
		
	}
	
return err;
*/
}				
				
//===========================================================================================
/*static ThreadRec	*_GetThisThreadRecP(void)
{
int					i;
unsigned long		ourID;
ThreadRec			*threadRecP;

	GetCurrentThread(&ourID);
	threadRecP = gThreadsRecP;
	for (i = 0; i < MAX_THREADS; i++, threadRecP++)
	{	if (threadRecP->id == ourID)
			return threadRecP;
	}

return nil;
}*/

//===========================================================================================
static void	_LogStart(void *taskid, char *ipaddr, char *host, LONGLONG *uniqueTagP, char *cookieSid)
{
BlockRef		fullReqBlock;
long			fullReqLen;
CStr255			request;
Ptr				fullReqP;

	HTTPControllerGetIPAddress(taskid, ipaddr);
	HTTPControllerGetServerName(taskid, host);
	XThreadsEnterCriticalSection();
	*uniqueTagP = ++gGlobalCount;
	XThreadsLeaveCriticalSection();
	HTTPControllerGetFullRequest(taskid, &fullReqBlock, &fullReqLen);
	fullReqP = GetPtr(fullReqBlock);
	FirstLine(fullReqP, fullReqLen, request);
	GetCookieSID(fullReqP, fullReqLen, cookieSid);
	LogInitRun(taskid, 0, ipaddr, host, request, *uniqueTagP, cookieSid);
	DisposeBlock(&fullReqBlock);
}

//===========================================================================================
static XErr	_RunMonothread(AEvents *thAEventsP)
{
XErr			err = noErr;
DescType		actualType;
long			actualSize;
CStr255			ipaddr, host, response, cookieSid;
LONGLONG		uniqueTag;

	// per un'eventuale SEND PARTIAL
	// 'Kcid' - ConnectionID from Webstar
	actualType = (DescType) 'char';
	if NOT(err = AEGetParamPtr (&thAEventsP->theAppleEvent, 'Kcid', typeLongInteger, &actualType, &thAEventsP->webStarConnID, 4, &actualSize))
	{	// 'from' - Address of Webstar (questo bisogner� disporlo in ogni caso)
		if NOT(err = AEGetAttributeDesc(&thAEventsP->theAppleEvent, 'from', '****', &thAEventsP->webStarAddr))
		{	_LogStart(thAEventsP, ipaddr, host, &uniqueTag, cookieSid);
			err = gHttpControllerP->Run(thAEventsP, false, uniqueTag, cookieSid, response);
			LogExitRun(thAEventsP, ipaddr, host, response, uniqueTag, cookieSid);
		}
	}
	_LogError(thAEventsP, err);
	while (thAEventsP->sendPartialFlag)
	{	thAEventsP->sendPartialFlag = _HandleSendPartialAEvent(thAEventsP);
		WaitNextEvent(everyEvent, &gEvent, 4, nil);
	}
	DisposePtr((Ptr)thAEventsP);

return err;
}

//===========================================================================================
/*static void	_WaitAllExit(long timeout)
{
XErr			err = noErr;
CStr15			gACGIUsersStr;
CStr63			aPStr;
unsigned long	startTicks;

	if (gACGIUsers)
	{	CNumToString(gACGIUsers, gACGIUsersStr);
		HTTPControllerLog(0, "before ----------------------------------");
		HTTPControllerLog(0, gACGIUsersStr);
		startTicks = XGetTicks();
		while (gACGIUsers)
		{	YieldToAnyThread();
			if ((XGetTicks() - startTicks) > timeout)
			{	HTTPControllerLog(0, "_WaitAllExit timeout");
				break;
			}
		}
	out:
		if (err)
		{	CNumToString(err, gACGIUsersStr);
			CEquStr(aPStr, "ERROR: ");
			CAddStr(aPStr, gACGIUsersStr);
			HTTPControllerLog(0, gACGIUsersStr);
		}
		CNumToString(gACGIUsers, gACGIUsersStr);
		HTTPControllerLog(0, "after ----------------------------------");
		HTTPControllerLog(0, gACGIUsersStr);
	}
}
*/
//===========================================================================================
static XErr	_GetParamFast(void *taskID, long which, char *result/*, long *lenP*/)
{
XErr		err = noErr;
DescType	actualType;
Size		actualSize;
//long		id, which;

	if NOT(taskID)
	{	//*lenP = 0;
		*result = 0;
		return noErr;
	}
	else// if (id = DLM_GetObjID(gCGIParamList, whichStr, nil, &which))
	{	if NOT(err = AEGetParamPtr(&((AEventsP)taskID)->theAppleEvent, (AEKeyword)which, typeChar, &actualType, (Ptr)result, 255, &actualSize))
		{	result[actualSize] = 0;
			//if (lenP)
			//	*lenP = actualSize;
		}
	}
	//else
	//	err = -1;
	
return err;
}

//===========================================================================================
static XErr	_EmptyBLock(BlockRef *blockP)
{	
Ptr		p;
XErr	err = noErr;
	
	if (*blockP = NewPtrBlock(1, &err, &p))
	{	//p  = GetPtr(*blockP);
		*p = 0;
	}

return err;
}

//===========================================================================================
static XErr	_GetParam(void *taskID, long which, BlockRef *blockP, long *lenP)
{
XErr		err = noErr;
DescType	actualType;
Size		actualSize;
Ptr			p, tBuffer;
//long		id;//, which;
BlockRef	tBlock, block;

	if NOT(taskID)
	{	*lenP = 0;
		return _EmptyBLock(blockP);
	}
		
	// id = DLM_GetObjID(gCGIParamList, whichStr, nil, &which);
	// if (id)
	{	if NOT(block = NewPtrBlock(32767, &err, &tBuffer))
			return err;
		//tBuffer = GetPtr(block);
		if NOT(err = AEGetParamPtr(&((AEventsP)taskID)->theAppleEvent, (AEKeyword)which, typeChar, &actualType, (Ptr)tBuffer, 32767, &actualSize ))
		{	if (tBlock = NewPtrBlock(actualSize + 1, &err, &p))
			{	//p = GetPtr(tBlock);
				CopyBlock(p, tBuffer, actualSize);
				p[actualSize] = 0;
				*blockP = tBlock;
				if (lenP)
					*lenP = actualSize;
			}
		}
		DisposeBlock(&block);
	}
	//else
	//	err = -1;
	
return err;
}

//===========================================================================================
static XErr 	_GetHostName(void *taskID, char *hostName)
{
	return _GetParamFast(taskID, kserver_name, hostName);
}

//===========================================================================================
static void	_LogFullRequest(void *taskID, long data)
{
#pragma unused(data)
XErr		err = noErr;
BlockRef	block;
long		len;
CStr255		aCStr;

	if NOT(err = _GetParam(taskID, kfull_request, &block, &len))
	{	LockBlock(block);
		FirstLine(GetPtr(block), len, aCStr);
		HTTPControllerLog(taskID, aCStr);
		DisposeBlock(&block);
	}
}

//===========================================================================================
static void*	_ThreadEntryPoint(void *param)
{
XErr			err = noErr;
AEvents			*thAEventsP;
DescType		actualType;
long			actualSize;
Boolean			isMonoThread;
CStr255			ipaddr, host, cookieSid, response;
void			*taskID = param;
LONGLONG		uniqueTag;

	if (gsQuitting)
		return (void*)XError(kXLibError, ErrThreadAborted);

	HTTPControllerGetIPAddress(taskID, ipaddr);
	_GetHostName(taskID, host);
	_LogStart(taskID, ipaddr, host, &uniqueTag, cookieSid);
	//LogInitRun(taskID, 0, ipaddr, host, _LogFullRequest, 0);
	
	isMonoThread = gMonoThread;
	gACGIUsers++;
	gACGIThreads++;
	thAEventsP = (AEvents*)param;
	// per un'eventuale SEND PARTIAL
	// 'Kcid' - ConnectionID from Webstar
	actualType = (DescType) 'char';
	if NOT(err = AEGetParamPtr (&thAEventsP->theAppleEvent, 'Kcid', typeLongInteger, &actualType, &thAEventsP->webStarConnID, 4, &actualSize))
	{	// 'from' - Address of Webstar (questo bisogner� disporlo in ogni caso)
		if NOT(err = AEGetAttributeDesc(&thAEventsP->theAppleEvent, 'from', '****', &thAEventsP->webStarAddr))
		{	if NOT(err = gHttpControllerP->Run(taskID, false, uniqueTag, cookieSid, response))
				;// lo faccio dopo // err = AEResumeTheCurrentEvent(&thAEventsP->theAppleEvent, &thAEventsP->theReply, (AEEventHandlerUPP)kAENoDispatch, 0);
		}
	}
	_LogError(thAEventsP, err);		

	while (thAEventsP->sendPartialFlag)
	{	thAEventsP->sendPartialFlag = _HandleSendPartialAEvent(thAEventsP);
		WaitNextEvent(everyEvent, &gEvent, 4, nil);
	}

	if (gMonoThread)
	{	if (NOT(isMonoThread) && NOT(gExpulseDone))	// just setted!
		{	gExpulseDone = true;
			HTTPControllerLog(0, "Going monothread: quitting threads");
			if NOT(err = XThreadsStopThreads(1))
			{	if NOT(gPlaySounded)
				{	
				#ifdef __MAC_XLIB__
					XPlaySound(128);
				#endif
					gPlaySounded = true;
				}
				XThreadsResumeThreads();
			}
		}
	}

	AEResumeTheCurrentEvent(&thAEventsP->theAppleEvent, &thAEventsP->theReply, (AEEventHandlerUPP)kAENoDispatch, 0);

	gACGIThreads--;
	gACGIUsers--;
	LogExitRun(thAEventsP, ipaddr, host, response, uniqueTag, cookieSid);
	
	DisposePtr((Ptr)thAEventsP);

	//sprintf(log, "\t%d -->", self);
	//HTTPControllerLog(0, log);

return (void*)err;
}

#define THREAD_REQUEST_STACK	(Size)(64L * 1024L)
#pragma mark-
//===========================================================================================
/*static inline XErr	_AddLongToList(long dlRef, char *name, long	value)	
{
XErr	err = noErr;

	DLM_NewObj(dlRef, name, "", 0, value, kFixedSize, &err);
	return err;
}

//===========================================================================================
static XErr	_InitCgiParamList(long *cgiParamListP)
{
XErr	err = noErr;
long	cgiParamList = 0;

	*cgiParamListP = 0;
	if NOT(err = DLM_Create(&cgiParamList, NAME_LIST, LOCAL_LIST))
	{
		if (err = _AddLongToList(cgiParamList, "username", kusername))
			goto out;
		if (err = _AddLongToList(cgiParamList, "password", kpassword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "clientaddress", 'addr'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "clientipaddress", 'Kcip'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "searchargs", 'kfor'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "postargs", 'post'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "pathargs", kpath_args))
			goto out;
		if (err = _AddLongToList(cgiParamList, "useragent", 'Agnt'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "fromuser", 'frmu'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "serverport", 'svpt'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "servername", 'svnm'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "contenttype", kcontent_type))
			goto out;
		if (err = _AddLongToList(cgiParamList, "actionpath", 'Kapt'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "action", 'Kact'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "referer", 'refr'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "fullrequest", kfull_request))
			goto out;
		if (err = _AddLongToList(cgiParamList, "scriptName", 'scnm'))
			goto out;
		if (err = _AddLongToList(cgiParamList, "method", kmethod))
			goto out;
	}
	
out:
if (err)
{	if (cgiParamList)
		DLM_Dispose(&cgiParamList, nil, 0);
}
else
	*cgiParamListP = cgiParamList;
return err;
}
*/
//===========================================================================================
/*static XErr _GetTheFileInfo(FSSpecPtr fileFspecPtr, HFileInfo *hFileInfoPtr)
{
	hFileInfoPtr->ioCompletion = nil;
	hFileInfoPtr->ioNamePtr = fileFspecPtr->name;
	hFileInfoPtr->ioVRefNum = fileFspecPtr->vRefNum;
	hFileInfoPtr->ioDirID = fileFspecPtr->parID;
	hFileInfoPtr->ioFDirIndex = 0;
	hFileInfoPtr->ioFRefNum = 0;

return PBGetCatInfoSync((CInfoPBPtr)hFileInfoPtr);
}

//===========================================================================================
static XErr _GetFolderFromFile(FSSpecPtr fileSpecPtr, FSSpecPtr dirSpecPtr)
{
CInfoPBRec			cInfo;
register DirInfo	*dirIPtr = &cInfo.dirInfo;
Str255				dirName;
XErr				err = 0;

	dirIPtr->ioNamePtr = dirName;								// Nome di ritorno
	dirIPtr->ioVRefNum = fileSpecPtr->vRefNum;					// Volume su cui operare
	dirIPtr->ioDrDirID = fileSpecPtr->parID;					// Directory di partenza
	dirIPtr->ioFDirIndex = -1;									// Info solo su Directories
	if NOT(err = PBGetCatInfoSync(&cInfo))
		err = FSMakeFSSpec(dirIPtr->ioVRefNum, dirIPtr->ioDrParID, dirIPtr->ioNamePtr, dirSpecPtr);

return err;
}
*/
//===========================================================================================
/*static XErr _GetFullPath(FSSpecPtr fileSpecPtr, StringPtr fullPath)
{
CInfoPBRec			cInfo;
register DirInfo	*dirIPtr = &cInfo.dirInfo;
Str255				dirName, swapStr;
XErr				err = 0;

if (fileSpecPtr->parID == fsRtParID)
	{
	PEquStr(fullPath, fileSpecPtr->name);
	PAddChar(fullPath, ':');	
	return noErr;
	}

*fullPath = 0;
dirIPtr->ioDrParID = fileSpecPtr->parID;					// Directory di partenza
dirIPtr->ioNamePtr = dirName;								// Nome di ritorno
dirIPtr->ioVRefNum = fileSpecPtr->vRefNum;					// Volume su cui operare
dirIPtr->ioDrDirID = 0;

while (dirIPtr->ioDrDirID != fsRtDirID)						// esce al raggiungimento della Root
	{
	dirIPtr->ioFDirIndex = -1;								// Info solo su Directories
	dirIPtr->ioDrDirID = dirIPtr->ioDrParID;				// non cadere nel PMSP
	if (err = PBGetCatInfoSync(&cInfo))
		break;
	PAddChar(dirName, ':');
	PEquStr(swapStr, dirName);
	if ((swapStr[0] + dirName[0]) > 255)
		{
		fullPath[0] = 0;
		err = bdNamErr;
		}
	PAddStr(swapStr, fullPath);								// swap prima dir ultima nel path
	PEquStr(fullPath, swapStr);
	}							

if NOT (err)
	{
	HFileInfo		hFileInfo;
	
	_GetTheFileInfo(fileSpecPtr, &hFileInfo);
	if (hFileInfo.ioFlAttrib & 0x010)
		{
		PAddStr(fullPath, fileSpecPtr->name);
		PAddChar(fullPath, ':');
		}
	#ifdef __MACOSX__
		// Patch to remove first part of path (unix style path)
		{	Byte 		*strP;
			Str255		tempStr;
			int			tLen;
			
			PEquStr(tempStr, fullPath);
			tempStr[tempStr[0]+1] = 0;
			if (strP = (Byte*)strchr((const char*)&tempStr[1], ':'))
			{	tLen = tempStr[0] - (strP - tempStr);
				CopyBlock(fullPath + 1, strP + 1, tLen);
				*fullPath = tLen;
			}
		}
	#endif
	}

return err;
}

//===========================================================================================
static XErr 	_GetCFullPath(FSSpecPtr fileSpecPtr, char *fullPath)
{
XErr	err = noErr;
Str255	pFullPath;

	if NOT(err = _GetFullPath(fileSpecPtr, pFullPath))
		PascalToC(pFullPath, fullPath);
	
return err;
}
*/
typedef struct {
				BlockRef	blockOfThisRec;
				XFilePath	filePath;
				MenuHandle	menuH;
				long		itemID;
				} ProcessProcRecord;

//===========================================================================================
static void*	_proc(void* arg)
{
XErr				err = noErr;
ProcessProcRecord	*procRecP = (ProcessProcRecord*)arg;
BlockRef			bl;

	err = gHttpControllerP->Process(0L, procRecP->filePath);
	SetMenuItemText(procRecP->menuH, procRecP->itemID, "\pProcess File...");
	bl = procRecP->blockOfThisRec;
	DisposeBlock(&bl);
	if (err)
		_LogError(0, err);
	gHttpControllerP->Resume(0L);
	gsFileProcessing = false;

return (void*)err;
}

//===========================================================================================
static XErr 	_LaunchLocalScript(char *filePath, MenuHandle menuH, long itemID, Boolean inThread)
{
unsigned long 		threadID;
BlockRef			bl;
ProcessProcRecord	*procRecP;
XErr				err = noErr;

	if (bl = NewBlockLocked(sizeof(ProcessProcRecord), &err, (Ptr*)&procRecP))
	{	CEquStr(procRecP->filePath, filePath);
		procRecP->blockOfThisRec = bl;
		procRecP->menuH = menuH;
		procRecP->itemID = itemID;
		if (inThread)
			XNewThread(&threadID, /*kWaitEndOfThread + */kCreateThreadIfNeeded, _proc, HTTP_THREAD_STACK_SIZE, (void*)procRecP);
		else
			err = (XErr)_proc((void*)procRecP);
	}

return err;
}

//===========================================================================================
static void 	_URLFromFullRequest(char **phisURLP, long *phisURLLenP)
{
register Ptr	tempP;	
int				realLen, phisURLLen;
char			*phisURL;
Boolean			foundCRLF = false;

phisURLLen = *phisURLLenP;
phisURL = *phisURLP;
	
	tempP = phisURL;
	if (phisURLLen)
	{	realLen = 0;
		do {
			if (*(short*)tempP == '\r\n')
			{	tempP++;
				foundCRLF = true;
				while((*(long*)tempP != 'HTTP') && realLen)
				{	tempP--;
					realLen--;
				}
				break;
			}
			else if ((*tempP =='$') || (*tempP =='\?'))
			{	tempP++;
				//if (foundCRLF)	// perch� c'era questa linea?
					break;
			}
			else
			{	tempP++;
				realLen++;
			}
		} while(--phisURLLen);
	}
	if (*(short*)phisURL == 'GE')
	{	phisURL += 4;
		realLen -= 4;
	}
	else if (*(long*)phisURL == 'POST')
	{	phisURL += 5;
		realLen -= 5;
	}
	//if (*tempP == ' ')
	//	realLen--;
	phisURL[realLen] = 0;

*phisURLLenP = realLen;
*phisURLP = phisURL;
}

//===========================================================================================
static XErr _LowGetGenericParamByHandle(void *taskID, OSType which, BlockRef *buffHP, long *sizeP, long max)
{
XErr		err = noErr;
DescType	actualType;
Size		actualSize;
BlockRef	block, buffBlock;
Ptr			tBuffer, p;

	if NOT(block = NewPtrBlock(32767, &err, &tBuffer))
		return err;
	//tBuffer = GetPtr(block);
	if NOT(err = AEGetParamPtr(&((AEventsP)taskID)->theAppleEvent, (AEKeyword)which, typeChar, &actualType, (Ptr)tBuffer, 32767, &actualSize ))
	{	if ((actualSize >= 32767) || (max && (actualSize > max)))
		{	if (buffHP)
				*buffHP = 0;
			if (sizeP)
				*sizeP = kInvalidPostLength;
		}
		else
		{	if (buffBlock = NewBlock(actualSize + 1, &err, &p))
			{	//p = GetPtr(buffBlock);
				CopyBlock(p, tBuffer, actualSize);
				p[actualSize] = 0;
				*buffHP = buffBlock;
				if (sizeP)
					*sizeP = actualSize;
			}
		}
	}
	DisposeBlock(&block);

return err;
}

//===========================================================================================
static XErr _GetGenericParamByHandle(void *taskID, OSType which, BlockRef *buffHP, long *sizeP)
{
	return _LowGetGenericParamByHandle(taskID, which, buffHP, sizeP, 0);
}

//===========================================================================================
static XErr _GetGenericParamByHandleExt(void *taskID, OSType which, BlockRef *buffHP, long *sizeP, long max)
{
	return _LowGetGenericParamByHandle(taskID, which, buffHP, sizeP, max);
}

//===========================================================================================
static short _ProcessEvent(EventRecord *theEventP)
{
short			part, err;
WindowPtr		whichWindow;
Point			theClick;
Boolean			someEvent;
long			sleep;
//unsigned long	nextWNE;

if (gACGIThreads > 0)
	sleep = 4;
else
	sleep = 0x7FFFFFFF;
	
// Se sto mandando in send_partial non devo processare altri eventi (almeno non AE)
/*if (sendPartialFlag)
{	sendPartialFlag = _HandleSendPartialAEvent();
	return WaitNextEvent(everyEvent, &gEvent, sleep, nil);
}*/

// Yield
//nextWNE = TickCount() + 8;
//do {
	YieldToAnyThread();
	//} while (TickCount() <= nextWNE);

// Idle
if (theTicksToSleep && gHttpControllerP->Idle)
{	if ((TickCount() - last) >= theTicksToSleep)
	{	if (err = gHttpControllerP->Idle(0))
			return err;
		theTicksToSleep = 0;
		last = TickCount();
	}
}

if (theEventP)
	{
	gEvent = *theEventP;
	someEvent = gEvent.what != 0;
	}
else
	someEvent = WaitNextEvent(everyEvent, &gEvent, 10, nil);

	
theClick = gEvent.where;
GlobalToLocal(&theClick);			

if (gWinRef)
{	if (IsLogWindowEvent(gWinRef, &gEvent, &done))
	{	//if (done)
		//	_XThreadeNoMoreThreads();
		return gEvent.what;
	}
}

if (someEvent)
	{
	switch (gEvent.what)
		{
		case mouseDown:
		part = FindWindow(gEvent.where, &whichWindow);
		switch (part)
			{
			case inDesk: 
				SysBeep(10);
				break;
			case inSysWindow:
				;//SystemClick( &gEvent, whichWindow );
				break;
			default:
				break;	
			}
			break;
		
		case kHighLevelEvent:
			if ((gEvent.message == kCoreEventClass) || (gEvent.message == kAEClassCGI))
				err = AEProcessAppleEvent(&gEvent);
			break;
		}
	}
return gEvent.what;
}

//===========================================================================================
#if TARGET_API_MAC_CARBON
	static short _yieldProc(void)
#else
	static pascal short _yieldProc(void)
#endif
{
	// 1 ProcessEvent every 32 YieldToAnyThread (if not local)
	if (gsFileProcessing || NOT(gsYieldCnt++ & 31))
		_ProcessEvent(nil);
	else
		YieldToAnyThread();

return 0;
}

//===========================================================================================
static short _MyGotReqParams(const AppleEvent *AEvent)
{
Size		ActSize;
DescType	ReturnType;
short			Err;

Err = AEGetAttributePtr(AEvent,keyMissedKeywordAttr,typeWildCard,&ReturnType,0L,0,&ActSize);
if(Err == errAEDescNotFound)
	return(noErr);
else
	{
	if(Err == noErr)
		return(errAEEventNotHandled);
	}

return(Err);
}

//===========================================================================================
static void	_HandleErr(XErr err, char *optStr, Boolean xInited)
{					
CStr31		errStr;
CStr255		eNameStr, eMsg;
XErr		tErr = noErr;
char		*cStr;
BlockRef	block;
Str255		pStr;
long		errValue;

	/*if (err)
	{	NumToString(err, aStr);
		DebugStr(aStr);
	}*/
	if (eMsg)
		*eMsg = 0;
	if (eNameStr)
		*eNameStr = 0;
	ErrorGetDescr(err, eNameStr, eMsg);
	XErrorGetTypeValue(err, &errValue, nil);
	CNumToString(errValue, errStr);

	if (xInited)
	{	if (block = NewPtrBlock(6 + errStr[0] + 1 + eMsg[0] + 1 + eNameStr[0] + 1 + optStr[0] + 1, &tErr, &cStr))
		{	//cStr = GetPtr(block);
			CEquStr(cStr, "Err = ");
			CAddStr(cStr, errStr);
			CAddStr(cStr, " ");
			CAddStr(cStr, eMsg);
			CAddStr(cStr, " ");
			CAddStr(cStr, eNameStr);
			CAddStr(cStr, " ");
			CAddStr(cStr, optStr);
			HTTPControllerLog(0, cStr);
			CToPascal(cStr, pStr);
			//CToPascal(globalErrStr, p2Str);
			ParamText(pStr, nil, nil, nil);
			StopAlert(301, nil);
		}
	}
	else
	{	CToPascal(errStr, pStr);
		if (optStr)
		{	AddCStrToPascal(pStr, "\r");
			AddCStrToPascal(pStr, optStr);
		}
		ParamText(pStr, nil, nil, nil);
		StopAlert(301, nil);
	}	
}

//===========================================================================================
/*static void 	_HeaderFromFullRequest(char **phisURLP, int *phisURLLenP)
{
int				phisURLLen;
char			*phisURL;

	phisURLLen = *phisURLLenP;
	phisURL = *phisURLP;
	while(*(short*)phisURL != '\r\n')
	{	phisURL++;
		phisURLLen--;
	}
	phisURL += 2;
	phisURLLen -= 2;
	
	*phisURLLenP = phisURLLen - 2;	// last \r\n
	*phisURLP = phisURL;
}
*/
//===========================================================================================
static XErr _GetServerDir(void *taskID, char *serverDir)
{
XErr		err = noErr;
FSSpec		spec;
DescType	actualType;
Size		actualSize;

	*serverDir = 0;
	if NOT(err = AEGetParamPtr(&((AEventsP)taskID)->theAppleEvent, (AEKeyword)'DIRE', typeFSS, &actualType, (Ptr)&spec, sizeof(FSSpec), &actualSize))
	{
	#ifdef __MACOSX__
		_MacOSX_FSSpecToUnixStylePath(&spec, serverDir);
		CAddChar(serverDir, '/');
	#else
	{
	//CStr255		aCStr;
	
		_GetCFullPath(&spec, serverDir);
		//CEquStr(serverDir, "/");
		//CAddStr(serverDir, aCStr);
	}
	#endif
	}
	
return err;
}

//===========================================================================================
/*static XErr 	_LaunchAdminProcThread(void* (*func)(void*), long param)
{	
unsigned long	threadID;
unsigned long	timOut, initTicks;
XErr			err = noErr;

	gsGenericThreadFinished = false;
	if NOT(err = _XNewThread(&threadID, 0, func, HTTP_THREAD_STACK_SIZE * 2, (void*)param))
	{	initTicks= XGetTicks();
		timOut = 60L * 180L;	// 180 secs = 3 min
		while NOT(gsGenericThreadFinished)
		{	if ((XGetTicks() - initTicks) > timOut)
				break;
			_ProcessEvent(nil);
		}
	}

return err;
}*/

//===========================================================================================
static void* _FlushEntryPoint(void* args) 
{
XErr	err = noErr;

	err = gHttpControllerP->ServerStateChanged(0, (long)args, nil);
	gsGenericThreadFinished = true;
	
return (void*)err;
}

//===========================================================================================
static void	_FlushFunc(MenuHandle menuH, long menuID, long itemID)
{
#pragma unused(menuH, menuID, itemID)

	_FlushEntryPoint((void*)kFlush); 
	// _LaunchAdminProcThread(_FlushEntryPoint, kFlush);
}

//===========================================================================================
static void	_FlushAllFunc(MenuHandle menuH, long menuID, long itemID)
{
#pragma unused(menuH, menuID, itemID)

	_FlushEntryPoint((void*)kReload); 
	//_LaunchAdminProcThread(_FlushEntryPoint, kReload);
}

//===========================================================================================
static void	_RefuseFunc(MenuHandle menuH, long menuID, long itemID)
{
#pragma unused(menuH)
	if (gRefusing)
	{	MacLogCheckItem(menuID, itemID, false);
		gRefusing = false;
	}
	else
	{	MacLogCheckItem(menuID, itemID, true);
		gRefusing = true;
	}
}

//===========================================================================================
static void	_ProcessFileFunc(MenuHandle menuH, long menuID, long itemID)
{
#pragma unused(menuID, itemID)
CStr255				filePath, aCStr;
OSType				typeList[4];
XErr				err = noErr;
Boolean				notABfr = false;
char				*strP;
#if TARGET_API_MAC_CARBON
NavigatorFileReply	reply;
#else
StandardFileReply	reply;
#endif
Boolean				executed = false;

	if (gsFileProcessing)
	{	gHttpControllerP->Suspend(0L);
		return;
	}
	else
		gsFileProcessing = true;
	typeList[0] = 'TEXT';
#if TARGET_API_MAC_CARBON
	err = Navigator_GetFile(1, typeList, &reply);
#else
	StandardGetFile(nil, 1, typeList, &reply);
#endif
	if (reply.sfGood)
	{	// Check if filename ends for ".bfr"
		PascalToC(reply.sfFile.name, aCStr);
		if (strP = strrchr(aCStr, '.'))
		{	if (CCompareStrings_cs(strP, ".bfr"))
				notABfr = true;
		}
		else
			notABfr = true;
		if (NOT(err) && NOT(notABfr))
		{	if (reply.sfGood)
			{	if NOT(err = _HttpMgrGetCFullPath(&reply.sfFile, filePath))
				{	//AddPascalToCStr(filePath, reply.sfFile.name);
					CSubstitute(filePath, ':', '/');
					SetMenuItemText(menuH, itemID, "\pStop process");
					if NOT(err = _LaunchLocalScript(filePath, menuH, itemID, true))
						executed = true;
					/*{
					unsigned long 		threadID;
					BlockRef			bl;
					ProcessProcRecord	*procRecP;
					
						if (bl = NewBlockLocked(sizeof(ProcessProcRecord), &err, (Ptr*)&procRecP))
						{	CEquStr(procRecP->filePath, filePath);
							procRecP->blockOfThisRec = bl;
							procRecP->menuH = menuH;
							procRecP->itemID = itemID;
							XNewThread(&threadID, kCreateThreadIfNeeded, _proc, HTTP_THREAD_STACK_SIZE, (void*)procRecP);
							//ex err = gHttpControllerP->Process(0L, filePath);
						}
					}*/
					//SetMenuItemText(menuH, itemID, "\pProcess File...");
				}
			}
			//if (err)
			//	_LogRun(0, err);
		}
		if (notABfr)
			CStringToLogWindow(gWinRef, "Error: not a .bfr file", false);
		//gHttpControllerP->Resume(0L);
	}
	if NOT(executed)
		gsFileProcessing = false;
}

#pragma mark-
//===========================================================================================
static pascal short _OpenDocsProc(const AppleEvent *AEvent, AppleEvent *AReply, long ARef)
{
#pragma unused(AReply, ARef)
FSSpec				FileDesc;
AEDescList			DocList;
short				err2, i,err;
long				NumOfItems;
Size				ActSize;
AEKeyword			KeyWd;
DescType			ReturnType;
#if TARGET_API_MAC_CARBON
	NavigatorFileReply	reply;
#else
	StandardFileReply	reply;
#endif
FInfo				FinderInfo;
CStr255				filePath;
char				*strP;
Boolean				notABfr = false, executed = false;

	if (gsFileProcessing)
		return noErr;
	else
		gsFileProcessing = true;
		
	if (err = AEGetParamDesc(AEvent,keyDirectObject,typeAEList,&DocList))
		goto out;
	
	if (err = _MyGotReqParams(AEvent))
		goto out;

	err = AECountItems(&DocList,&NumOfItems);
	// altrimenti problemi col multitask, in futuro si pu� rimuovere
	// ma allora va gestito gsFileProcessing nel loop
	if (NumOfItems > 1)
		NumOfItems = 1;
	for(i = 1;i <= (short)NumOfItems;i++)
	{	err = AEGetNthPtr(&DocList,(long)i,typeFSS,&KeyWd,&ReturnType, (Ptr)&FileDesc,sizeof(FileDesc),&ActSize);
		if (err == errAECoercionFail)	// from apple script
		{	if NOT(err = AEGetNthPtr(&DocList,(long)i,typeChar,&KeyWd,&ReturnType, filePath,255,&ActSize))
			{	CopyBlock(filePath+1,filePath,ActSize);
				*filePath = '/';
				filePath[ActSize+1] = 0;
			}
		}
		else
		{	if NOT(err = FSpGetFInfo(&FileDesc,&FinderInfo))
			{	if NOT(err = FSMakeFSSpec(FileDesc.vRefNum, FileDesc.parID, FileDesc.name, &reply.sfFile))
				{	err = _HttpMgrGetCFullPath(&reply.sfFile, filePath);
					//AddPascalToCStr(filePath, FileDesc.name);
				}
			}
		}
		if (strP = strrchr(filePath, '.'))
		{	if (CCompareStrings_cs(strP, ".bfr"))
				notABfr = true;
		}
		else
			notABfr = true;
		if (NOT(err) && NOT(notABfr))
		{	SetMenuItemText(gsMenuH, 1, "\pStop process");
			CSubstitute(filePath, ':', '/');
			if NOT(err = _LaunchLocalScript(filePath, gsMenuH, 1, false))
				executed = true;
			//err = gHttpControllerP->Process(0L, filePath);
			//SetMenuItemText(gsMenuH, 1, "\pProcess File...");
		}
		if (notABfr)
		{	CStringToLogWindow(gWinRef, "Error: not a .bfr file", false);
			notABfr = false;
		}
	}

out:

if (err)
	_LogError(0, err);
err2 = AEDisposeDesc(&DocList);
if NOT(executed)
	gsFileProcessing = false;
return(noErr);
}

//===========================================================================================
static pascal short _QuitProc(const AppleEvent *AEvent, AppleEvent *AReply, long ARef)
{
#pragma unused(AEvent, AReply, ARef)

	done = 1;
	
return(noErr);
}

//===========================================================================================
static pascal short	_CGIRunRole(const AppleEvent *theAppleEvent, AppleEvent *theReply, long Reference)
{
#pragma unused(Reference)
AEvents			*thAEventsP;
XErr			err = noErr;
//Size			newThreadStackSize = THREAD_REQUEST_STACK;
//ThreadID		homeMadeThreadID;
//ThreadEntryUPP	up;
CStr255			aCStr, host, ipaddr, cookieSid, response;
long			len;
void			*taskID;
LONGLONG		uniqueTag;

	if (gHttpControllerP->Run)
	{	
		if (thAEventsP = (AEvents*)NewPtrClear(sizeof(AEvents)))
		{	thAEventsP->theAppleEvent = *theAppleEvent;
			thAEventsP->theReply = *theReply;
			
			taskID = thAEventsP;
			if (gACGIThreads >= gACGIMaxUsers)
			{	BlockRef	h;
			
				HTTPControllerGetIPAddress(taskID, aCStr);
				_GetHostName(taskID, host);
				_LogStart(taskID, ipaddr, host, &uniqueTag, cookieSid);
				//LogInitRun(taskID, 0, aCStr, host, _LogFullRequest, 0);
				CEquStr(aCStr, httpHeaderInit);	
				CAddStr(aCStr, "<html><body>Biferno is Too busy, retry later</body></html>");
				len = CLen(aCStr);	
				if (h = _HTTPPtrToHandle(aCStr, len))
					err = HTTPControllerSendReply(taskID, h, len);
				DisposePtr((Ptr)thAEventsP);
				LogExitRun(taskID, ipaddr, host, response, uniqueTag, cookieSid);
			}
			else if (done || gRefusing)
			{	BlockRef	h;
			
				HTTPControllerGetIPAddress(taskID, aCStr);
				_GetHostName(taskID, host);
				//LogInitRun(taskID, 0, aCStr, host, _LogFullRequest, 0);
				_LogStart(taskID, ipaddr, host, &uniqueTag, cookieSid);
				CEquStr(aCStr, httpHeaderInit);	
				CAddStr(aCStr, "<html><body>Biferno is refusing connection, retry later</body></html>");
				len = CLen(aCStr);	
				if (h = _HTTPPtrToHandle(aCStr, len))
					err = HTTPControllerSendReply(taskID, h, len);
				DisposePtr((Ptr)thAEventsP);
				LogExitRun(taskID, ipaddr, host, response, uniqueTag, cookieSid);
			}
			else if (gMonoThread)
			{	HTTPControllerGetIPAddress(taskID, aCStr);
				_GetHostName(taskID, host);
				//LogInitRun(taskID, 0, aCStr, host, _LogFullRequest, 0);
				_LogStart(taskID, ipaddr, host, &uniqueTag, cookieSid);
				gACGIUsers++;
				err = _RunMonothread(thAEventsP);
				gACGIUsers--;
				LogExitRun(taskID, ipaddr, host, response, uniqueTag, cookieSid);
			}
			else
			{	if NOT(err = AESuspendTheCurrentEvent(theAppleEvent))
				{	if (err = XNewThread(nil, kExactMatch+kPremade+kCreateThreadIfNeeded, _ThreadEntryPoint, HTTP_THREAD_STACK_SIZE, (void*)thAEventsP))
						AEResumeTheCurrentEvent(theAppleEvent, theReply, (AEEventHandlerUPP)kAENoDispatch, 0);
				}
				if (err)
				{	_LogError(taskID, err);
					DisposePtr((Ptr)thAEventsP);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static void* _ShutDownEntryPoint(void* args) 
{
#pragma unused(args)
XErr	err = noErr;

	err = gHttpControllerP->ShutDown(0);
	gsGenericThreadFinished = true;
	
return (void*)err;
}

//===========================================================================================
static XErr _TerminateApp(void) 
{
XErr			err = noErr;

	if (gHttpControllerP->ShutDown)
	{	_ShutDownEntryPoint(nil); 
		// _LaunchAdminProcThread(_ShutDownEntryPoint, 0);
	}
	AERemoveEventHandler(kAEClassCGI, kAEIDSearchDoc, (void*)_CGIRunRole, false);
	AERemoveEventHandler(kCoreEventClass, kAEQuitApplication, (void*)_QuitProc, false);
	AERemoveEventHandler(kCoreEventClass, kAEOpenDocuments, (void*)_OpenDocsProc, false);
	DisposeBlock(&gHttpControllerBlock);

return err;
}

#pragma mark-
//===========================================================================================
/*XErr HTTPControllerGetFileMimeType(void *taskID, char *fileMimeType)
{
	*fileMimeType = 0;
	
return noErr;
}*/

//===========================================================================================
/*XErr HTTPControllerIfModifiedSince(void *taskID, Boolean *modifiedP)
{
	*modifiedP = false;
	
return noErr;
}*/

//===========================================================================================
/*static XErr 	_GetErrorFile(void *taskID, char *errFile)
{
#pragma unused(taskID, errFile)
XErr		err = noErr;
BlockRef	block;
long		len;
//DescType	actualType;
Size		actualSize = 0;

	return -1;
	//if NOT(err = AEGetParamPtr(&((AEventsP)taskID)->theAppleEvent, (AEKeyword)which, typeChar, &actualType, (Ptr)errFile, STR_MAXLEN, &actualSize))
	//	errFile[actualSize] = 0;
	
return err;

	return -1;
}*/


//===========================================================================================
XErr 	HTTPControllerGetServerParam(void *taskID, long which, char *cstr, long *numP)
{
#pragma unused(numP)
XErr	err = noErr;

	switch(which)
	{	case kServerDomain:
			err = _GetHostName(taskID, cstr);
			break;
		/*case kServerPort:
			break;
		case kServerDirectoryPath:
			break;
		case kServerVersionNumber:
			break;
		case kServerTotalConnections:
			break;
		case kServerCurrentUserLevel:
			break;
		case kServerHighestUserLevel:
			break;
		case kServerCurrentFreeMemory:
			break;
		case kServerMinimumFreeMemory:
			break;
		case kServerTotalConnTimeouts:
			break;
		case kServerTotalConBusies:
			break;
		case kServerTotalConDenied:
			break;
		case kServerTotalBytesSent:
			break;*/
		/*case kServerUpSinceDate:
			CEquStr(cstr, gsUpSinceStr);
			break;*/
		/*case kServerErrorFile:
			err = _GetErrorFile(taskID, cstr);
			break;*/
		default:
			return -1;
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetIPAddress(void *taskID, char *ipAddress)
{
	return _GetParamFast(taskID, kclient_ip, ipAddress);
/*XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "clientipaddress", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(ipAddress, GetPtr(block), len+1);
		else
			*ipAddress = 0;
		DisposeBlock(&block);
	}
	
return err;*/
}

//===========================================================================================
XErr HTTPControllerGetAddress(void *taskID, char *address)
{
	return _GetParamFast(taskID, kclient_address, address);
/*XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "clientaddress", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(address, GetPtr(block), len+1);
		else
			*address = 0;
		DisposeBlock(&block);
	}
	
return err;*/
}


//===========================================================================================
XErr HTTPControllerGetPathArgs(void *taskID, char *pathargs)
{
	return _GetParamFast(taskID, kpath_args, pathargs);
}

//===========================================================================================
XErr HTTPControllerGetServerName(void *taskID, char *serverName)
{
#pragma unused(taskID)
XErr		err = noErr;

	*serverName = 0;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetServerDir(void *taskID, char *serverDir)
{
XErr	err = noErr;

	if NOT(err = _GetServerDir(taskID, serverDir))
		CSubstitute(serverDir, ':', '/');
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetPhysURL(void *taskID, BlockRef *blockP, long *lenP)
{
char		*url;
BlockRef	saveBuffP, block;
XErr		err = noErr;
int			servLen;
long		size, urlLen;
Ptr			p, urlDecodedP;
CStr255		serverDir;
BlockRef	urlDecoded;
long		urlDecodedLength;

	if NOT(err = _GetServerDir(taskID, serverDir))
	{	servLen = CLen(serverDir);
		if (serverDir[servLen-1] == '/')		// per '/' finale
			servLen--;
		*blockP = nil;
		if NOT(err = _GetParam(taskID, kfull_request, &saveBuffP, &urlLen))
		{	url = GetPtr(saveBuffP);
			// urlLen = CLen(url);
			_URLFromFullRequest(&url, &urlLen);
			if NOT(err = DecodeURL((Byte*)url, urlLen, &urlDecoded, &urlDecodedLength, false, nil))
			{	LockBlock(urlDecoded);
				urlDecodedP = GetPtr(urlDecoded);
				urlLen = urlDecodedLength;
				size = urlLen + servLen;
				if (block = NewPtrBlock(size + INDEX_FILE_LENGTH + 1, &err, &p))
				{	//p  = GetPtr(block);
					CopyBlock(p, serverDir, servLen);
					CopyBlock(p + servLen, urlDecodedP, urlLen);
					p[size] = 0;
					*lenP = size;
					*blockP = block;
					CSubstitute(p, ':', '/');
					if (p[size-1] == '/')
					{	CAddStr(p, INDEX_FILE);
						*lenP += INDEX_FILE_LENGTH;
					}
					// CSubstitute(p, '/', ':');
				}
				DisposeBlock(&urlDecoded);
			}
			DisposeBlock(&saveBuffP);
		}
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetPostArgs(void *taskID, BlockRef *buffHP, long *postLen)
{
XErr			err;
CStr255			searchArgs;
unsigned long	postMAX;

	if NOT(err = _GetParamFast(taskID, khttp_search_args, searchArgs))
	{	postMAX = GetPOSTLimit(searchArgs);
		err = _GetGenericParamByHandleExt(taskID, kpost_args, buffHP, postLen, postMAX);
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetSearchArgs(void *taskID, BlockRef *buffHP, long *searchLen)
{
	return _GetGenericParamByHandle(taskID, khttp_search_args, buffHP, searchLen);
}

//===========================================================================================
/*XErr HTTPControllerGetSearchArgsString(void *taskID, char *searchArgs)
{
	return _GetParamFast(taskID, "searchargs", searchArgs);
}*/

#pragma mark-
//===========================================================================================
XErr HTTPControllerGetUsername(void *taskID, char *user)
{
	return _GetParamFast(taskID, kusername, user);
/*XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "username", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(user, GetPtr(block), len+1);
		else
			*user = 0;
		DisposeBlock(&block);
	}
	
return err;*/
}

//===========================================================================================
XErr HTTPControllerGetPassword(void *taskID, char *pass)
{
	return _GetParamFast(taskID, kpassword, pass);
/*XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "password", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(pass, GetPtr(block), len+1);
		else
			*pass = 0;
		DisposeBlock(&block);
	}
	
return err;*/
}

//===========================================================================================
XErr	HTTPControllerGetFullRequest(void *taskID, BlockRef *blockP, long *lenP)
{
	return	_GetParam(taskID, kfull_request, blockP, lenP);
}

//===========================================================================================
/*
XErr HTTPControllerGetHeader(void *taskID, BlockRef *blockP, long *headLenP)
{
#pragma unused(taskID)
char		*fullReqP;
BlockRef	fullRequestBlock, headerBlock;
XErr		err = noErr;
int			fullReqLen;
Ptr			p;

	if NOT(err = _GetParam(taskID, "fullrequest", &fullRequestBlock))
	{	fullReqP = GetPtr(fullRequestBlock); 
		fullReqLen = CLen(fullReqP);
		_HeaderFromFullRequest(&fullReqP, &fullReqLen);
		if (headerBlock = NewPtrBlock(fullReqLen + 1, &err))
		{	p = GetPtr(headerBlock);
			CopyBlock(p, fullReqP, fullReqLen);
			p[fullReqLen] = 0;
			*blockP = headerBlock;
			*headLenP = fullReqLen;
		}
		DisposeBlock(&fullRequestBlock);
	}


return err;
}
*/
#pragma mark-
//===========================================================================================
XErr HTTPControllerGetMethod(void *taskID, char *method)
{
	return _GetParamFast(taskID, kmethod, method);
/*XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "method", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(method, GetPtr(block), len+1);
		else
			*method = 0;
		DisposeBlock(&block);
	}
	
return err;*/
}

//===========================================================================================
/*XErr 	HTTPControllerGetContentLength(void *taskID, long *contentLengthP);
{
#pragma unused(taskID)
	
	*lenP = CLen(thePost);

return 0;
}*/

//===========================================================================================
XErr HTTPControllerGetContentType(void *taskID, char *contentType)
{
	return _GetParamFast(taskID, kcontent_type, contentType);
/*XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "contenttype", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(contentType, GetPtr(block), len+1);
		else
		{	*contentType = 0;
			err = -1;
		}
		DisposeBlock(&block);
	}
	
return err;*/
}

//===========================================================================================
/*XErr HTTPControllerGetIndexFile(void *taskID, char *indexFile)
{
	CEquStr(indexFile, "index.bfr");

return noErr;
}*/

//============================================================
/*Boolean HTTPControllerConnectionClosed(void *taskID)
{
	return false;
}
*/
//===========================================================================================
/*Boolean HTTPControllerConnectionClosed(void *taskID)
{
#pragma unused(taskID)

	return false;
}

//===========================================================================================
XErr HTTPControllerGetConnectionStatus(void *taskID, long *statusP)
{
#pragma unused(taskID)

	*statusP = STATUS_OPEN;

return noErr;
}*/

//===========================================================================================
/*XErr	HTTPControllerYield(void *taskID, long sleep)
{
#pragma unused(taskID,sleep)

	WaitNextEvent(everyEvent, &gEvent, 10, nil);

return 0;
}

//===========================================================================================
XErr	HTTPControllerRequestIdleTime(void *taskID, unsigned long ticksToSleep)
{
#pragma unused(taskID)
	
	theTicksToSleep = ticksToSleep;

return 0;
}*/

#pragma mark-
//===========================================================================================
/*XErr	HTTPControllerLogForThread(void *taskID, char *logStr, unsigned long threadID)
{
#pragma unused(taskID)
CStr255		cStr;

	if (gLogRef)
	{	CNumToString(threadID, cStr);
		CAddStr(cStr, ": ");
		CAddStr(cStr, logStr);
		CStringToLog(gLogRef, cStr);
	}
	
return 0;
}*/

//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *outPutStr)
{
#pragma unused(taskID)
CStr255		aCStr;
long		tLen;

	tLen = CLen(outPutStr);
	if (tLen > 250)
		tLen = 250;
	CopyBlock(aCStr, outPutStr, tLen);
	aCStr[tLen] = 0;
	CAddChar(aCStr, '\r');

/*#ifdef	ANSI_CONSOLE
	CStr255	aStr;

	CEquStr(aStr, outPutStr);	
	CAddStr(aStr, "\n");
	printf(aStr);
#else*/
	if (gWinRef)
		CStringToLogWindow(gWinRef, aCStr, false);
//#endif
	if (gLogRef)
		CStringToLog(gLogRef, aCStr, false);

return 0;
}

//===========================================================================================
void	HTTPControllerSetMonoThread(void *taskID)
{
#pragma unused(taskID)
CStr255		cStr;
CStr15		tStr;

	CNumToString(gACGIThreads, tStr);
	CEquStr(cStr, " threads: ");
	CAddStr(cStr, tStr);
	CNumToString(gACGIUsers, tStr);
	CAddStr(cStr, " users: ");
	CAddStr(cStr, tStr);
	CAddStr(cStr, " GOING TO MONOTHREAD!");
	HTTPControllerLog(0, cStr);
	gMonoThread = true;
}

//===========================================================================================
void	HTTPControllerSetMultiThread(void *taskID)
{
#pragma unused(taskID)
	gMonoThread = false;
}

//===========================================================================================
/*long	HTTPControllerGetVersion(void *taskID, long *versionP)
{
#pragma unused(taskID)

	if (versionP)
		*versionP = 0x00001000;
	return HTTP_CONT_ACGI;
}*/

//===========================================================================================
static void _LogOneLine(Ptr textP, long len, Boolean addToLast, RGBColor *color)
{
CStr255		aCStr;
long		max;

	max = MAC_LOG_MAX_LINE_SIZE - 3;
	if (len >= max)
	{	CopyBlock(aCStr, textP, max);
		aCStr[max] = 0;
		CAddStr(aCStr, "...");
	}
	else
	{	CopyBlock(aCStr, textP, len);
		aCStr[len] = 0;
	}
	CStringToLogWindowExt(gWinRef, aCStr, false, addToLast, color);
}

//===========================================================================================
XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
#pragma unused(taskID)
long		lastLen, nlsize;
Ptr			lastP;
XErr		err = noErr;

	lastP = textP;
	lastLen = len;
	while (len > 0)
	{	if (IsNewLine(textP, len, &nlsize))
		{	_LogOneLine(lastP, lastLen - len, NOT(gsNewLineFound), &gsColor);
			textP += nlsize;
			len -= nlsize;
			lastP = textP;
			lastLen = len;
			gsNewLineFound = true;
		}
		else
		{	textP++;
			len--;
		}
	}
	if (lastLen > len)
	{	_LogOneLine(lastP, lastLen - len, NOT(gsNewLineFound), &gsColor);
		gsNewLineFound = false;
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerWindowOutputExt(void *taskID, BlockRef bufferH, long len)
{
Ptr			textP;
RGBColor	black = {0, 0, 0}, red = {0xFFFF, 0, 0};

	LockBlock(bufferH);
	if (len)
	{	textP = GetPtr(bufferH);
		ZapNewLines((Byte*)textP, &len);
		if (len)
		{	gsColor = red;
			HTTPControllerWindowOutput(taskID, textP, len);
			gsColor = black;
		}
	}
	DisposeBlock(&bufferH);
	
return noErr;
}

//===========================================================================================
/*
ex XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
#pragma unused(taskID)
int			ch;
long		j;
long		returnSize = 0;
CStr255		aCStr;
Boolean		onlySpaces = true;
BlockRef	block;
XErr		err = noErr;

	j = 0;
	if (len)
	{	if (block = NewBlock(len, &err))
		{	CopyBlock(GetPtr(block), textP, len);
			if NOT(err = HTML2Txt(&block, &len))
			{	if (len)
				{	LockBlock(block);
					textP = GetPtr(block);
					do {
						if (IsNewLine(textP, len, &returnSize) || (j == 250))
						{	_AddOneLine(aCStr, &textP, &len, returnSize, &j, &onlySpaces, false, nil);
							gsAppendNext = false;
							*aCStr = 0;	// just added
							continue;
						}
						else if ((ch = *textP) != '\n')
						{	if (ch != ' ')
								onlySpaces = false;
							aCStr[j++] = ch;
						}
						textP++;
						len--;
					} while (len > 0);
					if ((j > 1) || (*aCStr && (*aCStr != '\t') && (*aCStr != '\r')))
					{	_AddOneLine(aCStr, nil, nil, 0, &j, &onlySpaces, gsAppendNext, nil);
						gsAppendNext = true;
					}
				}
			}
			DisposeBlock(&block);
		}
	}
	
return err;
}
*/
//===========================================================================================
XErr HTTPControllerSendReply(void *taskID, BlockRef bufferH, long len)
{
XErr		err = noErr;
AEvents		*thAEventsP = (AEvents*)taskID;
char		*p;

	if (len)
	{	//while (sendPartialFlag)
		//	_ProcessEvent(nil);
		//if (threadP = _GetThisThreadRecP())
		if (len > MACACGI_DIM_REQUIRES_SENDPARTIAL)
		{	if (bufferH)
			{	_BegineSendPartial(bufferH, thAEventsP);
				err = AEPutParamPtr(&((AEventsP)taskID)->theReply, keyDirectObject, typeChar, "<SEND_PARTIAL>", 14);
			}
		}
		else if (bufferH)
		{	AEDisposeDesc(&thAEventsP->webStarAddr);
			LockBlock(bufferH);
			p = GetPtr(bufferH);
			
		/*{
			BlockRef 	resultStringBlock;
			long		tLen, resultStringBlockLen;
			Ptr			textP;
			
			if NOT(err = SubstituteExt(p, len, &resultStringBlock, &resultStringBlockLen, "\r\n", "\r", 1, true, false))
			{	LockBlock(resultStringBlock);
				textP = GetPtr(resultStringBlock);
				tLen = resultStringBlock;
				while (tLen--)
				{	if (*(short*)textP++ == '\r\r')
						*textP = 0;
				}
				// textP[resultStringBlockLen] = 0;
				textP = GetPtr(resultStringBlock);
				resultStringBlockLen = CLen(textP);
				HTTPControllerWindowOutput(taskID, textP, resultStringBlockLen);
				DisposeBlock(&resultStringBlock);
			}
		}*/
			
			err = AEPutParamPtr(&((AEventsP)taskID)->theReply, keyDirectObject, typeChar, p, len);
			DisposeBlock(&bufferH);
		}
	}
	else if (bufferH)
		DisposeBlock(&bufferH);

return err;
}

//===========================================================================================
/*XErr	HTTPControllerExecStream(void *taskID, char *ip_addrStr, unsigned short ip_port,
								Ptr data, long dataLen, StringPtr refererPath, 
								long lenOfUserPass, BlockRef *returnDataHP, long *returnLenP)
{
#pragma unused(taskID,ip_addrStr,ip_port,data,dataLen,refererPath,lenOfUserPass,returnDataHP,returnLenP)
return noErr;
}
*/
#pragma mark-

#define	TOT_ITEMS	4
extern Boolean	gFatalMemErr;
//===========================================================================================
/*static pascal long	_growProc(unsigned long cbNeeded)
{
#pragma unused(cbNeeded)

	DebugStr("\p_growProc has been called");
	gFatalMemErr = true;
	gMonoThread = true;

return 0;
}*/


/*#include <TextEncodingConverter.h>
//#include <UnicodeConverter.h>
//=============================================
static OSErr	ConvertWithTEC(void)
{
TECObjectRef	isoConv;
ByteCount		totCharConverted, outputBufferLen;
OSErr			err = noErr, err2 = noErr;
short			theIsoChar;
Str255			aStr;
long			i;
//UnicodeToTextInfo 	uniTextInfo;
//UnicodeMapping   iUnicodeMapping;

	if (err = TECCreateConverter(&isoConv, kTextEncodingISOLatin1, kTextEncodingMacRoman))
		return err;
		
	//iUnicodeMapping.unicodeEncoding = kUnicode16BitFormat;
	//if NOT(err = CreateUnicodeToTextInfo(&iUnicodeMapping, &uniTextInfo)) 
	//{	
	for (i = 34; i <= 9830; i++)
	{	if (i < 256)
		{	*(Byte*)&theIsoChar = i;
			if NOT(err = TECConvertText(isoConv, (Byte*)&theIsoChar, 1, &totCharConverted, aStr, 255, &outputBufferLen))
				err = TECFlushText(isoConv, aStr, 255, &totCharConverted);
		}
		else
		{	*(short*)&theIsoChar = i;
			err = ConvertFromUnicodeToText (
					uniTextInfo, 
                 	2, 
                 	(ConstLogicalAddress)&theIsoChar, 
                 	kUnicodeUseFallbacksMask, 
                	0, 
                 	nil, 
                	nil, 
                	nil, 
                	255, 
                	&totCharConverted, 
                 	&outputBufferLen, 
                 	aStr); 
		}
	}
		//DisposeUnicodeToTextInfo (&uniTextInfo); 
	//}

	err2 = TECDisposeConverter(isoConv);
	if (err2 && NOT(err))
		err = err2;
	
return err;
}
*/

//===========================================================================================
/*XErr _GetDirInfo(short vRefNum, long dirID, StringPtr dirName, long *parIDP)
{
CInfoPBRec			cInfo;
register DirInfo	*dirIPtr = &cInfo.dirInfo;
XErr				err = 0;

dirIPtr->ioNamePtr = dirName;				// Nome di ritorno
dirIPtr->ioVRefNum = vRefNum;				// Volume su cui operare
dirIPtr->ioDrDirID = dirID;					// Directory di partenza
dirIPtr->ioFDirIndex = -1;					// Info solo su Directories
if NOT(err = PBGetCatInfoSync(&cInfo))
{	if (parIDP)
		*parIDP = dirIPtr->ioDrParID;
}

return err;
}*/

//===========================================================================================
int main(void) 
{
//Byte				theFld = 1;
long				aLong;	//, lastCheck = 0;
XErr				err = 0;
CStr255				optStr;
ProcessInfoRec		pInfoRec;
FSSpec				applSpec;
ProcessSerialNumber	PSN;
Str255				aPStr;
Boolean				/*isLocked, */xInited = false;
CStr63				processItemString[TOT_ITEMS];
MacLogProcessFunc 	processFunc[TOT_ITEMS];
char				*applPathP;

	optStr[0] = 0;
#ifdef __MAC_XLIB__
	if (Prof_START(3000,100))
		return 1;
	Prof_OFF;
#endif

#ifndef	ANSI_CONSOLE
	#if !TARGET_API_MAC_CARBON
		MaxApplZone();
	#endif
		for (aLong = 0; aLong < 30; aLong++)
			MoreMasters();
	#if !TARGET_API_MAC_CARBON
		InitGraf(&qd.thePort);
		InitFonts();
		InitWindows();
		InitMenus();
		TEInit();
		InitDialogs(0L);
	#endif
		InitCursor();
#endif

	//growProcRef = NewGrowZoneUPP(_growProc);
	//InitSound();
	//===
	/*{
	LONGLONG 	ll;
	CStr255		aCStr;
	
	PStringToLongNum("\p123412341234", &ll);
	CLongNumToString(ll, aCStr);
	CDebugStr(aCStr);
	}*/
	//===
	
	//TEST PER VEDERE COME SI COMPORTA L'IF
	/*{
	int	a = 1, b = 1;
	
		if (a == 1 && b == 1)
		{	SysBeep(2);
			SysBeep(2);
			SysBeep(2);
		}
	}*/

	if (GetCurrentProcess(&PSN))
		return 1;
	pInfoRec.processName = nil;
	pInfoRec.processAppSpec = &applSpec;
	pInfoRec.processInfoLength = sizeof(ProcessInfoRec);
	if (GetProcessInformation(&PSN, &pInfoRec))
		return 1;
	PascalToC(applSpec.name, appName);

#if TARGET_API_MAC_CARBON
{
//char	*strP;
//int		optStrLen;

	if (err = Navigator_Init('BFRN', applSpec.name, UpdateLogWindow))
	{	_HandleErr(err, "Navigator_Init", false);
		return 1;
	}    

    /*
	ex
	if NOT(err = _MacOSX_FSSpecToUnixStylePath(&applSpec, optStr))
    {	optStrLen = CLen(optStr);
		if (strP = strrchr(optStr, '/'))
        {	*strP = 0;
            if (strP = strrchr(optStr, '/'))
            {	*strP = 0;
                if (strP = strrchr(optStr, '/'))
                {   *strP = 0;
                    if (strP = strrchr(optStr, '/'))
                        *(strP+1) = 0;
                }
            }
        }
        if (strP)
            applPathP = optStr;
        else
            return;
    }*/
    if (err)
        goto out;
}
#else
	/*if NOT(GetBifernoHome(optStr))
	{	_HandleErr(err, optStr, false);
		return;
	}
	applPathP = nil;*/
#endif

	if NOT(GetBifernoHome(optStr))
	{	_HandleErr(1, optStr, false);
		return 1;
	}
	if (optStr[CLen(optStr)-1] != '/')
		CAddChar(optStr, '/');
	applPathP = optStr;

	xInited = false;
	if (err = XInit(applPathP))
		goto out;
	xInited = true;
	
	XCurrentDateTimeToString(gsUpSinceStr, kComplete);
	gACGIThreads = 0;
	gsQuitting = false;
#ifdef __MAC_XLIB__
	gYieldProc = _yieldProc;
#endif
	gACGIUsers = 0;
	/*helpersInited = false;
	if (err = InitHelpers())
		goto out;
	helpersInited = true;*/

	gHttpControllerBlock = 0;
	if NOT(gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err, (Ptr*)&gHttpControllerP))
		goto out;
	//gHttpControllerP = (HTTPControllerP)GetPtr(gHttpControllerBlock);
	
	ClearBlock(gHttpControllerP, sizeof(HTTPController));
	if (err = HTTPControllerRegister(gHttpControllerP))
		goto out;

	if (err = Gestalt(gestaltAppleEventsAttr, &aLong))
		goto out;

	// WebSTAR AE
	if (err	= AEInstallEventHandler(kAEClassCGI, kAEIDSearchDoc, NewAEEventHandlerUPP(_CGIRunRole), 0L, false ))
		goto out;

	// Quit AE
	if (err	= AEInstallEventHandler(kCoreEventClass, kAEQuitApplication, NewAEEventHandlerUPP(_QuitProc), 0, false))
		goto out;

	// Open Doc Proc AE
	if (err	= AEInstallEventHandler(kCoreEventClass,kAEOpenDocuments,NewAEEventHandlerUPP(_OpenDocsProc),0,false))
		goto out;

	if (MaxBlock() < MinFreeBlock)
	{	err = memFullErr;
		goto out;
	}

	InitCursor();
	FlushEvents(everyEvent, 0);

	gWinRef = 0;
#ifndef	ANSI_CONSOLE
	CToPascal(gHttpControllerP->aboutStr, aPStr);
	if (err = InitLogWindow(appName, &gWinRef, aPStr))
		return 1;
	CEquStr(processItemString[0], "Process File.../P");
	CEquStr(processItemString[1], "Flush/F");
	CEquStr(processItemString[2], "Reload/R");
	CEquStr(processItemString[3], "Refuse new connections");
	processFunc[0] = _ProcessFileFunc;
	processFunc[1] = _FlushFunc;
	processFunc[2] = _FlushAllFunc;
	processFunc[3] = _RefuseFunc;
	WindowLogAddMenuItem("Biferno", processItemString, processFunc, TOT_ITEMS);
	MacLogGetMenu(1, &gsMenuH);
#endif
	if NOT(err = XGetApplicationFolderPath(optStr))
	{	CAddStr(optStr, "BifernoACGI.log");
		gLogRef = 0;
		err = InitLog(optStr, &gLogRef);
		if (err)
			goto out;
		gExtraLogRefNum = gCurrentLogRefNum = gLogRef;	// log all together
	}
	if (err)
	{	if (err == XError(kXLibError, ErrXFiles_FileNotFound))
		{	gLogRef = 0;
			err = noErr;
		}
		else if (err)
			goto out;
	}
		
	SetCursor(*GetCursor(watchCursor));
	gACGIMaxUsers = 32;		// default
	if (gHttpControllerP->Init)
	{	if (err = gHttpControllerP->Init(0, &gACGIMaxUsers, false, optStr))
			goto out;
	}
	if (err = _InitThreads(gACGIMaxUsers))
		goto out;
			
	HTTPControllerLog(0, "=================");
	HTTPControllerLog(0, "ACGI Server Start");
	HTTPControllerLog(0, "=================");
	
	InitCursor();
	done = false;
	gRefusing = false;
	
#ifdef ANSI_CONSOLE
	while(1)
	{	
		gets(optStr);
	}
#else
	while NOT(done)
		_ProcessEvent(nil);
#endif
	
	gsQuitting = true;
	while (gACGIUsers && gACGIThreads)
		XYield(nil);

	err = _TerminateApp();

#if TARGET_API_MAC_CARBON
	Navigator_End();
#endif
out:
XThreadsStopThreads(0);
XThreadsResumeThreads();
if (err)
	_HandleErr(err, optStr, xInited);

// write norm stop on file
if (gLogRef)
{	aLong = CLen(NORM_STOP_STR);
	WriteXFile(gLogRef, NORM_STOP_STR, &aLong);
}

if (gHttpControllerBlock)
	DisposeBlock(&gHttpControllerBlock);
//if (gCGIParamList)
//	DLM_Dispose(&gCGIParamList, nil, 0);
if (gWinRef)
	EndLogWindow(gWinRef);
if (gLogRef)
	EndLog(&gLogRef);
if (xInited)
	XEnd(0);
	
	//EndSound();
	
#ifdef __MAC_XLIB__
	Prof_END;
#endif
return 0;
}

