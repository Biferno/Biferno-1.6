/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMgr_UnixCGI.c,v 1.1.1.1 2003-03-25 13:07:42 valfer Exp $
	|______________________________________________________________________________
*/
#include	"HTTPMgr.h"

#include 	<string.h>
#include 	<stdio.h>
#include 	<stdlib.h>
#include 	<signal.h>
#include 	<unistd.h>

#include 	"Helpers.h"
#include 	"XErrors.h"
#include 	"FLog.h"

static	HTTPControllerP		gHttpControllerP;
static 	long				gCGIParamList = 0;
static	BlockRef			gHttpControllerBlock;
static	XFileRef			gLogRefNum = 0;

#ifdef LITTLE_ENDIAN
	#define	HTTP_TAG			'PTTH'
	#define	GE_TAG				'EG'
	#define	POST_TAG			'TSOP'
#else
	#define	HTTP_TAG			'HTTP'
	#define	GE_TAG				'GE'
	#define	POST_TAG			'POST'
#endif

//===========================================================================================
static void	_HandleErr(XErr err)
{					
CStr31		errStr;
CStr255		eNameStr, eMsg;

	printf("Content-type: text/html\n\n");
	ErrorGetDescr(err, eNameStr, eMsg);	
	printf("ERROR: %d (%s) ", err, eNameStr);
	if (gLogRefNum)
	{	CStr255		logStr;
	
		sprintf(logStr, "ERROR: %d (%s) ", err, eNameStr);
		CStringToLog(gLogRefNum, logStr);
	}
	if (*eMsg)
		printf(eMsg);
}

//===========================================================================================
/*static XErr	_Register(void)
{
XErr	err = noErr;

	if NOT(gHttpControllerP = (HTTPControllerP)NewPtrBlock(sizeof(HTTPController), &err))
		return err;
	ClearBlock(gHttpControllerP, sizeof(HTTPController));
	err = HTTPControllerRegister(gHttpControllerP);
	
return err;
}*/
//===========================================================================================
static inline XErr	_AddStringToList(long dlRef, char *name, char *env_var)	
{
XErr	err = noErr;

	DLM_NewObj(dlRef, name, env_var, CLen(env_var) + 1, 0, kFixedSize, &err);	// also zero final
	return err;
}

//===========================================================================================
/*static void 	_URLFromFullRequest(char **phisURLP, int *phisURLLenP)
{
register Ptr	tempP;	
int				realLen, phisURLLen;
char			*phisURL;

phisURLLen = *phisURLLenP;
phisURL = *phisURLP;
	
	tempP = phisURL;
	if (phisURLLen)
	{	realLen = 0;
		do {
			if ((*tempP == '\r') && (*(tempP+1) == '\n'))
			{	tempP++;
				while((*(long*)tempP != HTTP_TAG) && realLen)
				{	tempP--;
					realLen--;
				}
				break;
			}
			else if ((*tempP =='$') || (*tempP =='\?'))
			{	tempP++;
				break;
			}
			else
			{	tempP++;
				realLen++;
			}
		} while(--phisURLLen);
	}
	if (*(short*)phisURL == GE_TAG)
	{	phisURL += 4;
		realLen -= 4;
	}
	else if (*(long*)phisURL == POST_TAG)
	{	phisURL += 5;
		realLen -= 5;
	}
	if (*tempP == ' ')
		realLen--;
	phisURL[realLen] = 0;

*phisURLLenP = realLen;
*phisURLP = phisURL;
}
*/
//===========================================================================================
static XErr	_EmptyBLock(BlockRef *blockP)
{	
Ptr		p;
XErr	err = noErr;
	
	if (*blockP = NewBlock(1, &err))
	{	p  = GetPtr(*blockP);
		*p = 0;
	}

return err;
}

//===========================================================================================
static XErr	_InitCgiParamList(long *cgiParamListP)
{
XErr			err = noErr;
long			cgiParamList;

	*cgiParamListP = 0;
	if NOT(err = DLM_Create(&cgiParamList, NAME_LIST, LOCAL_LIST))
	{
		if (err = _AddStringToList(cgiParamList, "username", ""))
			goto out;
		if (err = _AddStringToList(cgiParamList, "password", ""))
			goto out;
		if (err = _AddStringToList(cgiParamList, "clientaddress", "REMOTE_HOST"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "clientipaddress", "REMOTE_ADDR"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "searchargs", "QUERY_STRING"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "useragent", "HTTP_USER_AGENT"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "fromuser", ""))
			goto out;
		if (err = _AddStringToList(cgiParamList, "serverport", "SERVER_PORT"))
			goto out;
		//if (err = _AddStringToList(cgiParamList, "servername", "SERVER_SOFTWARE"))
		//	goto out;
		if (err = _AddStringToList(cgiParamList, "contenttype", "CONTENT_TYPE"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "actionpath", "SCRIPT_FILENAME"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "action", ""))
			goto out;
		if (err = _AddStringToList(cgiParamList, "referer", "HTTP_REFERER"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "fullrequest", "????"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "scriptName", ""))
			goto out;
		if (err = _AddStringToList(cgiParamList, "method", "REQUEST_METHOD"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "contentlength", "CONTENT_LENGTH"))
			goto out;
		if (err = _AddStringToList(cgiParamList, "serverroot", "DOCUMENT_ROOT"))
			goto out;
	}
	
out:
if (err)
{	if (cgiParamList)
		DLM_Dispose(&cgiParamList, nil, 0);
}
else
	*cgiParamListP = cgiParamList;
return err;
}

//===========================================================================================
static XErr _GetServerDir(long taskID, char *serverDir)
{
XErr	err = noErr;
char	*strP;

	*serverDir = 0;
	strP = getenv("DOCUMENT_ROOT");
	if NOT(strP)
		strP = getenv("BIFERNOHOME");
	if (strP)
	{	CopyBlock(serverDir, strP, CLen(strP) + 1);
		CAddChar(serverDir, '/');
	}
	else
		*serverDir = 0;
	
return err;
}

//===========================================================================================
static XErr	_GetParam(long taskID, char *whichStr, BlockRef *blockP, long *lenP)
{
XErr			err = noErr;
BlockRef		block = 0;
long			envLen, id, destLen;
CStr255			envStr;
char			*strP, *p;

	id = DLM_GetObjID(gCGIParamList, whichStr, nil, nil);
	if (id)
	{	envLen = 255;
		err = DLM_GetObj(gCGIParamList, id, envStr, &envLen, 0, nil);
		if (err == XERR(kXHelperError, DLM_Err_NoMoreDataInObject))
			err = noErr;
		if NOT(err)
		{	strP = getenv(envStr);
			if (strP)
			{	destLen = CLen(strP);
				if (block = NewBlock(destLen+1, &err))
				{	p = GetPtr(block);
					CopyBlock(p, strP, destLen+1);
				}
			}
			else
			{	destLen = 0;
				if (block = NewPtrBlock(1, &err))
				{	p  = GetPtr(block);
					*p = 0;
				}
			}
			if (lenP)
				*lenP = destLen;
		}
	}
	else
	{	if (block = NewPtrBlock(1, &err))
		{	p  = GetPtr(block);
			*p = 0;
		}
	}

if (err)
	*blockP = nil;
else
	*blockP = block;	
return err;
}

#pragma mark-
//===========================================================================================
/*XErr HTTPControllerIfModifiedSince(long taskID, Boolean *modifiedP)
{
	*modifiedP = false;
	
return noErr;
}*/

//===========================================================================================
/*XErr HTTPControllerGetFileMimeType(long taskID, char *fileMimeType)
{
	*fileMimeType = 0;
	
return noErr;
}*/

//===========================================================================================
XErr 	HTTPControllerGetServerParam(long taskID, long which, char *cstr, long *numP)
{
XErr	err = noErr;

	if (cstr)
		*cstr = 0;
	if (numP)
		*numP = 0;
		
return err;
}

//===========================================================================================
XErr HTTPControllerGetIPAddress(long taskID, char *ipAddress)
{
	*ipAddress = 0;
return noErr;
}

//===========================================================================================
XErr HTTPControllerGetAddress(long taskID, char *address)
{
	*address = 0;
return noErr;
}
//===========================================================================================
XErr HTTPControllerGetPathArgs(long taskID, char *pathArgs)
{
	*pathArgs = 0;
	
return noErr;
}

//===========================================================================================
XErr HTTPControllerGetPhysURL(long taskID, BlockRef *blockP, long *lenP)
{
BlockRef	saveBuffP, block;
XErr		err = noErr;
int			urlLen;
Ptr			p, strP;
CStr255		cStr;

	if NOT(err = _GetServerDir(taskID, cStr))
	{	strP = getenv("PAGE");
		if (strP)
			CAddStr(cStr, strP);
		else
			CAddStr(cStr, "index.bfr");
		urlLen = CLen(cStr);
		if (block = NewPtrBlock(urlLen + 1, &err))
		{	p  = GetPtr(block);
			CopyBlock(p, cStr, urlLen + 1);
			*blockP = block;
			*lenP = urlLen;
		}
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetPostArgs(long taskID, BlockRef *postHP, long *postLen, long maxDimensionAllowed)
{
BlockRef	block;
Ptr			p;
XErr		err = noErr;

	if (block = NewPtrBlock(1, &err))
	{	p  = GetPtr(block);
		*p = 0;
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetSearchArgs(long taskID, BlockRef *searchHP, long *searchLen)
{
XErr	err = noErr;

	err = _GetParam(taskID, "searchargs", searchHP, &searchLen);

return err;
}

//===========================================================================================
XErr	HTTPControllerGetServerDir(long taskID, char *serverDir)
{
	CEquStr(serverDir, "");
	
return noErr;
}

//===========================================================================================
XErr HTTPControllerGetServerName(long taskID, char *serverName)
{
XErr	err = noErr;
char	*strP;

	if (strP = getenv("SERVER_SOFTWARE"))
		CEquStr(serverName, strP);
	else
		*serverName = 0;

return err;
}

//===========================================================================================
XErr	HTTPControllerGetFullRequest(long taskID, BlockRef *blockP, long *lenP)
{
	return	_GetParam(taskID, "fullrequest", blockP, lenP);
}

//===========================================================================================
XErr HTTPControllerGetUsername(long taskID, char *user)
{
	*user = 0;
}

//===========================================================================================
XErr HTTPControllerGetPassword(long taskID, char *pass)
{
	*pass = 0;
}

//===========================================================================================
/*XErr HTTPControllerGetHeaderField(long taskID, char *index, BlockRef *blockP)
{	
XErr		err = noErr;

	return -1;

return err;
}

#pragma mark-*/
//===========================================================================================
XErr HTTPControllerGetMethod(long taskID, char *method)
{
XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "method", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(method, GetPtr(block), len);
		else
			*method = 0;
		DisposeBlock(&block);
	}
	
return err;
}

//===========================================================================================
/*XErr	HTTPControllerGetContentLength(long taskID, long *lenP, Ptr thePost)
{
	*lenP = CLen(thePost);
	return noErr;
}*/

//===========================================================================================
XErr HTTPControllerGetContentType(long taskID, char *contentType)
{
XErr		err = noErr;
BlockRef	block;
long		len;

	if NOT(err = _GetParam(taskID, "contenttype", &block, &len))
	{	if (len < STR_MAXLEN)
			CopyBlock(contentType, GetPtr(block), len);
		else
			*contentType = 0;
		DisposeBlock(&block);
	}
	
return err;
}

/*#pragma mark-
//===========================================================================================
XErr	HTTPControllerYield(long taskID, long sleep)
{	
#pragma unused(taskID,sleep)
return noErr;
}

//===========================================================================================
XErr	HTTPControllerRequestIdleTime(long taskID, unsigned long ticksToSleep)
{
#pragma unused(taskID,ticksToSleep)
return noErr;
}
#pragma mark-
//===========================================================================================
Boolean HTTPControllerConnectionClosed(long taskID)
{
#pragma unused(taskID)
return false;
}
//===========================================================================================
XErr HTTPControllerGetConnectionStatus(long taskID, long *statusP)
{
#pragma unused(taskID,statusP)
return noErr;
}
*/
#pragma mark-
//===========================================================================================
XErr	HTTPControllerLog(long taskID, char *outPutStr)
{
	if (gLogRefNum)
		CStringToLog(gLogRefNum, outPutStr);
	return noErr;
}

//===========================================================================================
/*long	HTTPControllerGetVersion(long taskID, long *versionP)
{
}*/

//===========================================================================================
XErr	HTTPControllerSendReply(long taskID, BlockRef bufferH, long len)
{
XErr		err = noErr;
char		*p;
BlockRef	resultStringBlock;
long		resultLen;

	if NOT(err = SetBlockSize(bufferH, len+1))
	{	p = GetPtr(bufferH);
		p[len] = 0;
		// parse p for % chars
		if NOT(err = SubstituteExt(p, len, &resultStringBlock, &resultLen, "%", "%%", 2, true))
		{	p = GetPtr(resultStringBlock);
			p[resultLen] = 0;
			printf(p);
			DisposeBlock(&resultStringBlock);
			DisposeBlock(&bufferH);
		}
	}

return err;
}

//===========================================================================================
/*XErr	HTTPControllerExecStream(long taskID, char *ip_addrStr, unsigned short ip_port,
								Ptr data, long dataLen, StringPtr refererPath, 
								long lenOfUserPass, BlockRef *returnDataHP, long *returnLenP)
{
#pragma unused(taskID,ip_addrStr,ip_port,data,dataLen,refererPath,lenOfUserPass,returnDataHP,returnLenP)
return noErr;
}*/

#pragma mark-
//===========================================================================================
static void	catch_segmentation_fault(int signo)
{
	printf("Content-type: text/html\n\n");
	printf("SEGMENTATION FAULT");
	exit(0);
}

//===========================================================================================
main(int argc, char *argv[]) 
{
Byte					theFld = 1;
long					aLong, lastCheck = 0;
short					err = 0, err2 = 0;
Str255					serverPath;
CStr255					logFilePath, serverPathCStr;
struct sigaction		sa_old;
struct sigaction		sa_new;

	sa_new.sa_handler = catch_segmentation_fault;
	sigfillset(&sa_new.sa_mask);
	sa_new.sa_flags = 0;
	sigaction(SIGSEGV, &sa_new, &sa_old);
	
	gLogRefNum = 0;
	if (err = XInit(getenv("BIFERNOHOME")))
		goto out;
	//if (err = InitHelpers())
	//	goto out;		

	if NOT(err = XGetApplicationFolderPath(logFilePath))
	{	CAddStr(logFilePath, "cgi_biferno.log");
		err = InitLog(logFilePath, &gLogRefNum);
	}
	if (err)
		goto out;

	gHttpControllerBlock = 0;
	GetXApplicationCurrentDir(serverPathCStr);

	if NOT(gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err))
		goto out;
	gHttpControllerP = (HTTPControllerP)GetPtr(gHttpControllerBlock);
	
	ClearBlock(gHttpControllerP, sizeof(HTTPController));
	if (err = HTTPControllerRegister(gHttpControllerP))
		goto out;

	if (err = _InitCgiParamList(&gCGIParamList))
		goto out;

	TRACE("Init");
	if (gHttpControllerP->Init)
	{	if (err = gHttpControllerP->Init(0, 32))
			goto out;
	}
	
	//CStringToLog(gLogRefNum, "Run");
	if (gHttpControllerP->Run)
		err = gHttpControllerP->Run(0);
	
	TRACE("ShutDown");
	if (gHttpControllerP->ShutDown)
		err2 = gHttpControllerP->ShutDown(0);
	if (err2 && NOT(err))
		err = err2;
	
	DisposeBlock(&gHttpControllerBlock);
	
out:
if (err)
	_HandleErr(err);

if (gLogRefNum)
	EndLog(&gLogRefNum);
if (gHttpControllerBlock)
	DisposeBlock(&gHttpControllerBlock);
DLM_Dispose(&gCGIParamList, nil, 0);
//EndHelpers();
XEnd();
TRACE("Unix CGI main exit");
}


