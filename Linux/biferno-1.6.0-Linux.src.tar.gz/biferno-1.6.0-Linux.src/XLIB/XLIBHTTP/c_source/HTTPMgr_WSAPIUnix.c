/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMgr_WSAPIUnix.c,v 1.9 2006-10-09 10:40:25 valfer Exp $
	|______________________________________________________________________________
*/
#include	"HTTPMgr.h"
#include 	<string.h>

//#include 	"Helpers.h"
#include 	"WSAPI.h"
//#include	"HTUU.h"
//#include 	"FLog.h"

#include 	"XLibPrivate.h"

#include 	"BfrVersion.h"

#include 	"XThreadsPrivate.h"

#include 	"HTTPMrgNet.h"

#define	NEW_REQUEST			"GET /pippo.bfr HTTP/1.0"
#define	NEW_REQUEST_LEN		23

// Waiting jaguar -> monothread
#ifndef CAN_USE_POSIX_THREADS
	#include <pthread.h>
	//static pthread_mutex_t		gWSAPIMutex = PTHREAD_MUTEX_INITIALIZER;
#endif

// STATIC
static	char	errorMessage[] = "Error executing Plugin: (Err = ";
static	char	httpHeaderInit[] = "HTTP/1.0 200 OK\r\nMIME-Version: 1.0\r\nContent-type: text/html\r\n\r\n<HTML><BODY>";
static	char	httpHeaderEnd[] = ")</BODY></HTML>";

static	BlockRef			gHttpController = nil;
//static 	long				gCGIParamList = 0;
static 	XFileRef			gLogRef = 0;
static	Boolean				gShutDownFlag;
static	Boolean				gInitPlug = false, gsDoInit = false, gsLogFileInited = false;
//static	Boolean				gNewThreads = false, gsThreadsAllocated = false;
static	short				gResourceRefnum = 0;
static	CStr255				gsServerRoot;
static	long				gsServerRootCLen;
//static	unsigned long		gWSAPIUsers = 0;
static	XErr				gInitErr = noErr;
//static	Boolean				gPlaySounded = false;

//long				gWSAPIThreads;
static Boolean		gExpluseDone;

//static short		gsMaxThreads = 0;

#ifdef __MACOSX__
	//static CStr255		gsWebstarVolumePath;
	//static int			gsWebstarVolumePathLen;
	CStr255					gStartupDateStr, gsBifernoHome;
#endif

static CStr255	gWSAPIErrorsStr[] = 
	{	
	"WSAPI_I_NoErr: normal completion code, synonymous with noErr",
	"WSAPI_E_MessageNotHandled: return value indicates the command message wasn't processed",
	"WSAPI_E_ParameterNotFound: requested parameter descriptor did not exist",
	"WSAPI_E_InsufficientMemory: not enough memory to perform requested operation",
	"WSAPI_E_Unimplemented: requested function is not yet implemented or isn't available for this version of WSAPI",
	"WSAPI_E_HTTPConnectionGone: the client connected to this thread has closed the connection",
	"WSAPI_E_BadCommandPtr: commandPtr that was passed was null or invalid",
	"WSAPI_E_CantOpenStream: TCP/IP stream couldn't be created or opened",
	"WSAPI_E_BufferTooBig: data buffer was too large for the callback to process",
	"WSAPI_E_NameLookupFailed: the domain name resolver failed to resolve the requested name",
	"WSAPI_E_NullDescriptor: 10, a null descriptor, or one with no data pointer was passed when real data was required",
	"WSAPI_E_UnspecifiedError: some unknown error happened",
	"WSAPI_E_BadArgument: one of the arguments (usually a pointer) passed to a callback was invalid",
	"WSAPI_E_CantModifyData: an attempt was made to modify read-only data",
	"WSAPI_E_DescriptorTooSmall: user-supplied storage for a descriptor is too small for the data being assigned to it",
	"WSAPI_E_HTTPConnectionErr: plug-in attempted to read from a closed or non-existent HTTP stream, or some other IP-related error occurred.",
	"WSAPI_E_WrongRoleForCall: plug-in tried to make a callback that is inappropriate for the current WSAPI_Command",
	"WSAPI_E_RequestFailed: whatever request the plug-in was making of the server failed to complete successfully",
	"WSAPI_E_IPCMsgPending: an attempt was made to send an IPC message while one was already in progress",
	"WSAPI_E_IPCNoMsgPending: an attempt was made to receive IPC message results when no message was in progress",
	"WSAPI_E_Timeout: 20, requested operation took too long and timed out before being completed",
	"WSAPI_I_NoPermission: current user doesn't have permissions for realm; other security violation",
	"WSAPI_E_ParameterIndexedOnly: the requested parameter can only be accessed as an indexed parameter",
	"WSAPI_E_IndexedValueNotFound: the item specified by the index was not present in the requested object",
	"WSAPI_E_TooManyRouters: 24, an attempt to register more then one routing module (WSAPI_RegisterRouter)",
	"WSAPI_E_SocketAlreadyOpen: 25 A call to WSAPI_ListenStream on a socket that is already open.",
	"WSAPI_E_SocketClosed: Attempt to read/write from a socket that the remote site has closed.",
	"WSAPI_E_LASTERROR"
	};

/*	typedef struct
		{
		Handle 				sndHandle;				// handle to an 'snd ' resource
		SndChannelPtr		sndChanPtr;				// pointer to a sound channel
		SndCommand			sndCommand;
		Boolean				channelAvaible;
		Boolean				sndIsPlayng;
		Boolean				canDisposeSound;
		Boolean				unused;
		} SoundStuff, *SndStuffPtr;

static 	SoundStuff			sndStuff;
static	SndCallBackUPP		sndProcRecPtr = nil;
*/
#define	WSAPI_LOG_MAX_LINE_SIZE	255

static	Boolean				gsNewLineFound = false;
//===========================================================================================
static XErr	_Register(WSAPI_CommandPBPtr commandPtr)
{
XErr			err = noErr;
HTTPControllerP	httContP;

	if NOT(gHttpController = NewPtrBlock(sizeof(HTTPController), &err, (Ptr*)&httContP))
		return err;
	//httContP = (HTTPControllerP)GetPtr(gHttpController);
	ClearBlock(httContP, sizeof(HTTPController));
	if NOT(err = HTTPControllerRegister(httContP))
	{	if NOT(err = WSAPI_RegisterAction (commandPtr, httContP->action, httContP->pluginName))
		{	if NOT(err = WSAPI_RegisterSuffix (commandPtr, httContP->action, httContP->suffix, '*   ', '*   ', httContP->mimeType))
			{	
			#ifdef __MACOSX__
				commandPtr->param.init.capabilities = capCGI|capPreemptive;
			#endif
				strcpy(commandPtr->param.init.pluginName, httContP->pluginName);
				strcpy (commandPtr->param.init.version, httContP->version);
				strcpy (commandPtr->param.init.adminURL, httContP->adminURL);
				/*if (httContP->AccessControl)
				{	if (err = WSAPI_RegisterAccessControl(commandPtr))
						HTTPControllerLog((long)commandPtr, 
													"Couldn't register as Access Control.");
				}*/
				//if (httContP->wantFilter)
				//	err = WSAPI_RegisterFilter(commandPtr);
			}	
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_RequestIdleTime(void *taskID, unsigned long ticksToSleep)
{
	return WSAPI_RequestIdleTime((WSAPI_CommandPBPtr)taskID, ticksToSleep);
}

//===========================================================================================
static XErr	_GetParamSlow(void *taskID, long which, BlockRef *blockP, long *lenP)
{
#pragma unused(whichStr)
WSAPI_DescPtr	descrP;
OSType			dtype;
XErr			err, err2;
unsigned long	descrSize;
Ptr				buffP;
//long			id, which;
BlockRef		block;

	//id = DLM_GetObjID(gCGIParamList, whichStr, nil, &which);
	//if (id)
	{	if NOT(err = WSAPI_GetParameter((WSAPI_CommandPBPtr)taskID, (WSAPI_ParamKeywords)which, &descrP))
		{	if NOT(err = WSAPI_GetDescriptor((WSAPI_CommandPBPtr)taskID, descrP, &dtype, nil, &descrSize))
			{	if (block = NewPtrBlock(descrSize + 1, &err, &buffP))
				{	//buffP = GetPtr(block);
					if NOT(err = WSAPI_GetDescriptor((WSAPI_CommandPBPtr)taskID, descrP, &dtype, buffP, &descrSize))
					{	if (dtype == typeChar)
							buffP[descrSize] = '\0';
						*blockP = block;
						if (lenP)
							*lenP = descrSize;
					}
					else
						DisposeBlock(&block);
				}
			}
			err2 = WSAPI_DisposeDescriptor((WSAPI_CommandPBPtr)taskID, &descrP);
		}
	}
	//else
	//	err = (WSAPI_ErrorCode)-1;
	
return err;
}

//===========================================================================================
static Boolean _ConnectionClosed(void *taskID)
{
XErr					err = noErr;
WSAPI_ConnectionStatus	status;

	if NOT(err = WSAPI_HTTPConnectionStatus((WSAPI_CommandPBPtr)taskID, &status))
		return (status == WSAPI_IP_Closed);
	else
		return true;
}

//===========================================================================================
static XErr _LogRun(void *taskID, XErr err)
{
CStr15	errStr;
CStr255	eNameStr, eMsg;
char	cStr[512];
XErr	theErr = 0;
//CStr15	tStr;

	if (err)
	{	CNumToString(err, errStr);
		CEquStr(cStr, errorMessage);
		CAddStr(cStr, errStr);
		CAddStr(cStr, ")");
		if ((err >= WSAPI_I_NoErr) && (err <= WSAPI_E_LASTERROR))
		{	CEquStr(eNameStr, gWSAPIErrorsStr[err]);
			*eMsg = 0;
		}
		else
			ErrorGetDescr(err, eNameStr, eMsg);
		CAddStr(cStr, " ");
		CAddStr(cStr, eNameStr);
		CAddStr(cStr, " ");
		CAddStr(cStr, eMsg);
		HTTPControllerLog(taskID, cStr);
		
		CEquStr(cStr, httpHeaderInit);
		CAddStr(cStr, errorMessage);
		CAddStr(cStr, errStr);
		CAddStr(cStr, httpHeaderEnd);
		CAddStr(cStr, " ");
		CAddStr(cStr, eNameStr);
		CAddStr(cStr, " ");
		CAddStr(cStr, eMsg);

		if NOT(_ConnectionClosed(taskID))
			theErr = WSAPI_SendHTTPData((WSAPI_CommandPBPtr)taskID, cStr, CLen(cStr));
	
		return theErr;
	}
	else
	{	/*if ((gWSAPIThreads > 1) && NOT(gShutDownFlag))
		{	CNumToString(gWSAPIThreads, tStr);
			CEquStr(cStr, "threads: ");
			CAddStr(cStr, tStr);
			CAddStr(cStr, " users: ");
			CNumToString(gWSAPIUsers, tStr);
			CAddStr(cStr, tStr);
			HTTPControllerLog(0, cStr);
		}*/
		return 0;
	}
}

//#define kStreamMaxReceive		(Size)(1024L * 1024L * 4L)	// 4MB

//===========================================================================================
static XErr _GetConnectionStatus(void *taskID, long *statusP)
{
XErr					err = noErr;
WSAPI_ConnectionStatus status;

	*statusP = 0;
	if NOT(err = WSAPI_HTTPConnectionStatus((WSAPI_CommandPBPtr)taskID, &status))
	{	*statusP = status;
		switch(status)
		{
			case WSAPI_IP_Data:
				*statusP = STATUS_DATA;
				break;
			case WSAPI_IP_Closed:
				*statusP = STATUS_CLOSED;
				break;
			case WSAPI_IP_Open:
				*statusP = STATUS_OPEN;
				break;
			case WSAPI_IP_Unknown:
			default:	
				*statusP = STATUS_UNKNOWN;
				break;
		}
	}

return err;
}

//===========================================================================================
/*static XErr	_AddLongToList(long dlRef, char *name, long	value)	
{
XErr	err = noErr;

	DLM_NewObj(dlRef, name, "", 0, value, kFixedSize, &err);
	return err;
}

//===========================================================================================
static XErr	_InitCgiParamList(long *cgiParamListP)
{
XErr	err = noErr;
long	cgiParamList = 0;

	*cgiParamListP = 0;
	if NOT(err = DLM_Create(&cgiParamList, NAME_LIST, LOCAL_LIST))
	{
		if (err = _AddLongToList(cgiParamList, "username", piUserKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "password", piPasswordKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "clientaddress", piAddressKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "clientipaddress", piClientIPAddress))
			goto out;
		if (err = _AddLongToList(cgiParamList, "searchargs", piSearchArgKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "postargs", piPostKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "pathargs", piPathArgKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "useragent", piUserAgentKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "fromuser", piFromUser))
			goto out;
		if (err = _AddLongToList(cgiParamList, "serverport", piServerPort))
			goto out;
		if (err = _AddLongToList(cgiParamList, "servername", piServerName))
			goto out;
		if (err = _AddLongToList(cgiParamList, "contenttype", piContentType))
			goto out;
		if (err = _AddLongToList(cgiParamList, "contentlength", piContentLength))
			goto out;
		if (err = _AddLongToList(cgiParamList, "actionpath", piActionPathKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "action", piActionKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "referer", piRefererKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "fullrequest", piFullRequestKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "scriptName", piScriptName))
			goto out;
		if (err = _AddLongToList(cgiParamList, "method", piMethodKeyword))
			goto out;
		if (err = _AddLongToList(cgiParamList, "mimeType", piFileMIMEType))
			goto out;
		if (err = _AddLongToList(cgiParamList, "server", piServerField))
			goto out;
		if (err = _AddLongToList(cgiParamList, "serverdirpath", piServerDirectoryPath))
			goto out;
		if (err = _AddLongToList(cgiParamList, "urlpath", piURLPhysicalPath))
			goto out;
		if (err = _AddLongToList(cgiParamList, "modifiedsince", piIfModifiedSince))
			goto out;
		if (err = _AddLongToList(cgiParamList, "modifieddate", piIfModifiedDate))
			goto out;
		if (err = _AddLongToList(cgiParamList, "curRealm", piCurrentRealm))
			goto out;
		if (err = _AddLongToList(cgiParamList, "totalconnections", piTotalConnections))
			goto out;
		if (err = _AddLongToList(cgiParamList, "currentuserlevel", piCurrentUserLevel))
			goto out;
		if (err = _AddLongToList(cgiParamList, "highestuserlevel", piHighestUserLevel))
			goto out;
		if (err = _AddLongToList(cgiParamList, "currentfreememory", piCurrentFreeMemory))
			goto out;
		if (err = _AddLongToList(cgiParamList, "minimumfreememory", piMinimumFreeMemory))
			goto out;
		if (err = _AddLongToList(cgiParamList, "totalcontimeouts", piTotalConTimeouts))
			goto out;
		if (err = _AddLongToList(cgiParamList, "totalconbusies", piTotalConBusies))
			goto out;
		if (err = _AddLongToList(cgiParamList, "totalcondenied", piTotalConDenied))
			goto out;
		if (err = _AddLongToList(cgiParamList, "totalbytessent", piTotalBytesSent))
			goto out;
		if (err = _AddLongToList(cgiParamList, "upsincedate", piUpSinceDate))
			goto out;
		if (err = _AddLongToList(cgiParamList, "fileinfocachesize", piFileInfoCacheSize))
			goto out;
		if (err = _AddLongToList(cgiParamList, "maxusers", piMaxUsers))
			goto out;
	}
	
out:
if (err)
{	if (cgiParamList)
		DLM_Dispose(&cgiParamList, nil, 0);
}
else
	*cgiParamListP = cgiParamList;
return err;
}
*/
//===========================================================================================
/*static Boolean	_CheckFreeInPool(char *str)
{
short		avail;
Boolean		res = false;
XErr		err;

	if NOT(err = GetSpecificFreeThreadCount(kCooperativeThread, HTTP_THREAD_STACK_SIZE, &avail))
	{	if (avail)// && (avail != 12))
		{	CDebugStrExt("Number of free threads -> ", avail, str);
			res = true;
		}
	}

return res;
}*/
			
//===========================================================================================
/*static XErr	_InitThreads(void)
{
XErr			err = noErr;

	err = XThreadsNewPool(gsMaxThreads, HTTP_THREAD_STACK_SIZE);
	
return err;
}*/			
				
//===========================================================================================
/*static void*	_ThreadEntryPoint(void *param)
{
HTTPControllerP	contrP = (HTTPControllerP)param;

	return (void*)contrP->Run(contrP->taskID, true);
}*/


//===========================================================================================
/*static XErr	_LaunchNewThread(long controlP, Boolean *exitNow)
{
XErr					err = noErr;

	//_MoreThread();
	err = XNewThread(nil, kWaitEndOfThread+kExactMatch+kPremade+kCreateThreadIfNeeded, _ThreadEntryPoint, HTTP_THREAD_STACK_SIZE, (void*)controlP);
	//_LessThread();
	
	*exitNow = false;
	
return err;
}*/

//===========================================================================================
/*static  void*	_ThreadEntryPoint_INIT(void *param)
{
HTTPControllerP	contrP = (HTTPControllerP)param;
CStr255			errMessage;

	return (void*)contrP->Init(contrP->taskID, &contrP->max_users, false, errMessage);
}*/

//===========================================================================================
/*static XErr	_LaunchNewThread_INIT(long controlP)
{
XErr					err = noErr;

#ifdef __MACOSX__
	err = (XErr)_ThreadEntryPoint_INIT((void*)controlP);
#else
	err = XNewThread(nil, kWaitEndOfThread, _ThreadEntryPoint_INIT, HTTP_THREAD_STACK_SIZE * 2, (void*)controlP);
#endif

return err;
}*/


//===========================================================================================
static XErr _ReadHTTPData(void *taskID, void *data, long *dataLen)
{
	return WSAPI_ReadHTTPData ((WSAPI_CommandPBPtr)taskID, data, dataLen);
}

//===========================================================================================
static XErr _LowGetGenericParamByHandle(void *taskID, OSType which, BlockRef *blockP, long *sizeP, long theContentLen, long max)
{
WSAPI_DescPtr	descrP;
OSType			dtype;
XErr			err, err2;
unsigned long	descrSize;
BlockRef		block;
Ptr				p;

	if NOT(err = WSAPI_GetParameter((WSAPI_CommandPBPtr)taskID, (WSAPI_ParamKeywords)which, &descrP))
	{	if NOT(err = WSAPI_GetDescriptor((WSAPI_CommandPBPtr)taskID, descrP, &dtype, nil, &descrSize))
		{	// patch
		/*
		#ifndef __MACOSX__
			// With WebSTAR V theContentLen is not correct and is always bigger than descrSize
			// the correct theContentLen is returned in *sizeP by this func
		*/
			if ((theContentLen > 0) && (descrSize < theContentLen))
			{	
				err2 = WSAPI_DisposeDescriptor((WSAPI_CommandPBPtr)taskID, &descrP);
				return WSAPI_E_RequestFailed;
			}
			else 
		// #endif
			if (max && (descrSize > max))
			{	if (blockP)
					*blockP = 0;
				if (sizeP)
					*sizeP = kInvalidPostLength;
			}
			else
			{	
			/*
			#ifndef __MACOSX__
				if (descrSize < theContentLen)
					theContentLen = descrSize;
			#endif
			*/
				if (block = NewBlockLocked(descrSize + 1, &err, &p))
				{	//LockBlock(block);
					//p = GetPtr(block);
					if NOT(err = WSAPI_GetDescriptor((WSAPI_CommandPBPtr)taskID, descrP, &dtype, p, &descrSize))
					{	if (dtype == typeChar)
							p[descrSize] = '\0';
						*blockP = block;
						if (sizeP)
							*sizeP = descrSize;
					}
					else
						DisposeBlock(&block);
				}
			}
		}
		err2 = WSAPI_DisposeDescriptor((WSAPI_CommandPBPtr)taskID, &descrP);
	}

return err;
}

//===========================================================================================
static XErr _GetGenericParamByHandle(void *taskID, OSType which, BlockRef *blockP, long *sizeP, long theContentLen)
{
	return  _LowGetGenericParamByHandle(taskID, which, blockP, sizeP, theContentLen, 0);
}

//===========================================================================================
static XErr _GetGenericParamByHandleExt(void *taskID, OSType which, BlockRef *blockP, long *sizeP, long theContentLen, long max)
{
	return  _LowGetGenericParamByHandle(taskID, which, blockP, sizeP, theContentLen, max);
}

//===========================================================================================
/*static XErr	_GetUserPassCoded(Ptr userPassP,long userPassLen,Ptr buffoutP,long *buffLenP)
{
int				rest;
XErr			err = noErr;
register Ptr	tP;
char			bufin[48];

	rest = 3 - (userPassLen % 3);
	if ((userPassLen + rest) > 48)
	{	err = -1;
		goto out;
	}
	CopyBlock(bufin, userPassP, userPassLen);
	if (rest)
	{	tP = bufin + userPassLen;
		do {
			*tP++ = 0;
			} while (--rest);
	}
	*buffLenP = HTUU_encode((Byte*)bufin, userPassLen, buffoutP);

out:
return err;
}
*/
//===========================================================================================
/*static Boolean 	_HeaderFieldFromFullRequest(char **phisURLP, int *phisURLLenP, char *index)
{
register Ptr	tempP;	
int				realLen, phisURLLen;
char			*phisURL;
Str255			indexPascalStr;
Boolean			found = false;
long			offset;

	phisURLLen = *phisURLLenP;
	phisURL = *phisURLP;
	CToPascal(index, indexPascalStr);
	PUp2LowerStr(indexPascalStr);
	if (found = FindStringInText((char*)&indexPascalStr[1], indexPascalStr[0], phisURL, phisURLLen, &offset, false, false))
	{
		phisURL += (offset-1);
		realLen = 0;
		tempP = phisURL;
		while(*(short*)tempP++ != '\r\n')
			realLen++;

		*phisURLLenP = realLen;
		*phisURLP = phisURL;
	}
	else
	{
		*phisURLLenP = 0;
	}

return found;
}*/

//===========================================================================================
static XErr	_HTTPReadPostArg(void *taskID, long maxDimensionAllowed, BlockRef *blockP, long *lenP)
{
BlockRef		block = nil;
XErr			err = noErr;
long			toRead, pending, maxStorage, finalLen, status, newBlockSize, totBlocks, receivedSize;
//unsigned long	time;
Ptr				buffP;
int				where = 0;

	if NOT(block = NewBlock(1, &err, nil))
		return err;
	totBlocks = 0;
	receivedSize = 0;
	//time = TickCount();
	finalLen = 0;
	pending = 0;
	while(NOT(err = _GetConnectionStatus(taskID, &status)) && (status != STATUS_CLOSED))
	{	if (err = WSAPI_YieldTime((WSAPI_CommandPBPtr)taskID, 3))
		{	where = 1;
			break;
		}
		
		if (status == STATUS_DATA)
		{	newBlockSize = receivedSize + _20K;
			if (pending && (pending < _20K))
			{	newBlockSize = receivedSize + pending;
				maxStorage = pending;
			}
			else
				maxStorage = _20K;
			if (err = SetBlockSize(block, newBlockSize))
				goto out;
			LockBlock(block);
			buffP = GetPtr(block);
			// _ReadHTTPData uses one more byte (it's a WSAPI bug?)!
			toRead = maxStorage - 1;
			if (err = _ReadHTTPData(taskID, buffP + receivedSize, &toRead))
			{	where = 2;
				goto out;
			}
			maxStorage = toRead;
			UnlockBlock(block);
			receivedSize += maxStorage;
			if (maxDimensionAllowed && (receivedSize > maxDimensionAllowed))
			{	err = kInvalidPostLength;
				break;
			}
		}
		else if (finalLen && (finalLen <= receivedSize) && NOT(pending))
		{	where = 5;
			break;
		}
		else
		{	if (err = HTTPControllerGetContentLength(taskID, &finalLen))
			{	where = 3;
				goto out;
			}
			if (finalLen)
			{	pending = finalLen - receivedSize;
				if (pending < 0)
				{	pending = 0;
					receivedSize = finalLen;
				}
			}
			if (err = WSAPI_YieldTime((WSAPI_CommandPBPtr)taskID, 3))
			{	where = 4;
				break;
			}
			if (finalLen && (finalLen == receivedSize))
				break;
		}
		/*if ((TickCount() - time) > kHTTPControllerTimeOut)
		{	err = -1;
			break;
		}*/
	}	
	if NOT(err)
	{	newBlockSize = receivedSize;
		if (err = SetBlockSize(block, newBlockSize))	// a diminuire
			goto out;
	
		if (pending)
			err = WSAPI_E_RequestFailed;
	}
	
out:
if (err)
{	DisposeBlock(&block);
	block = nil;
	if (err == kInvalidPostLength)
	{	newBlockSize = kInvalidPostLength;
		err = noErr;
	}
	else
		newBlockSize = 0;
}
*blockP = block;
*lenP = newBlockSize;
return err;
}

//===========================================================================================
static void	_HandleErr(void *taskID, XErr err, char *optStr, Boolean onlyOpt)
{					
CStr255		eNameStr, eMsg;
CStr15		errStr;
char		*cStr;
XErr		tErr = noErr;
BlockRef	block;
	
	
	ErrorGetDescr(err, eNameStr, eMsg);
	CNumToString(err, errStr);
	if (block = NewPtrBlock((int)(6 + errStr[0] + 1 + eMsg[0] + 1 + eNameStr[0] + 1 + optStr[0] + EOL_STRING + 1), &tErr, &cStr))
	{	//cStr = GetPtr(block);
		if (onlyOpt)
			CEquStr(cStr, optStr);
		else
		{	CEquStr(cStr, "Err = ");
			CAddStr(cStr, errStr);
			CAddStr(cStr, " ");
			CAddStr(cStr, eMsg);
			CAddStr(cStr, " ");
			CAddStr(cStr, eNameStr);
			CAddStr(cStr, " ");
			CAddStr(cStr, optStr);
		}
		HTTPControllerLog(taskID, cStr);
		if (gLogRef)
		{	CAddStr(cStr, EOL_STRING);
			CStringToLog(gLogRef, cStr, true);
		}
		HTTPControllerSendReply(taskID, block, CLen(cStr));
		//DisposeBlock(&block);
	}
}

//===========================================================================================
static	XErr _GetServerRoot(void *taskID, char *serverDir)
{
XErr		err = noErr;
BlockRef	block;
long		l;

	if NOT(err = _GetParamSlow(taskID, piServerDirectoryPath, &block, nil))
	{	
	#ifdef __MACOSX__
		l = GetBlockSize(block, &err);
		CopyBlock(serverDir, GetPtr(block), l);
		serverDir[l] = 0;
	#else
		*serverDir = ':';
		l = GetBlockSize(block, &err);
		CopyBlock(serverDir+1, GetPtr(block), l);
		serverDir[l+1] = 0;
	#endif
		DisposeBlock(&block);
	}

return err;
}

//===========================================================================================
static XErr _GetParamFast(WSAPI_CommandPBPtr pb, long which, char *resultStr, long maxStorage)
{
WSAPI_DescPtr	descrP;
XErr			err, err2;
unsigned long	size;
OSType			dtype;

	if NOT(err = WSAPI_GetParameter(pb, which, &descrP))
	{	size = maxStorage;
		if NOT(err = WSAPI_GetDescriptor(pb, descrP, &dtype, resultStr, &size))
			resultStr[size] = '\0';
		err2 = WSAPI_DisposeDescriptor(pb, &descrP);
	}
	//else
	//	err = (WSAPI_ErrorCode)-1;
	
return err;
}

//===========================================================================================
/*static XErr _GetParamFast_Number(WSAPI_CommandPBPtr pb, long which, long *number)
{
WSAPI_DescPtr	descrP;
XErr			err, err2;
unsigned long	size;
OSType			dtype;
long			aLong;

	if NOT(err = WSAPI_GetParameter(pb, which, &descrP))
	{	size = sizeof(long);
		if NOT(err = WSAPI_GetDescriptor(pb, descrP, &dtype, &aLong, &size))
		{	if (dtype == typeShortInteger)
				*number = *(short*)&aLong;
			else if (dtype == typeLongInteger)
				*number = *(long*)&aLong;
		}
		err2 = WSAPI_DisposeDescriptor(pb, &descrP);
	}
	else
		err = (WSAPI_ErrorCode)-1;
	
return err;
}*/

#pragma mark-
//===========================================================================================
/*XErr HTTPControllerGetFileMimeType(void *taskID, char *fileMimeType)
{
	return _GetParamFast((WSAPI_CommandPBPtr)taskID, piFileMIMEType, fileMimeType, STR_MAXLEN);
}*/

//===========================================================================================
/*XErr HTTPControllerIfModifiedSince(void *taskID, Boolean *modifiedP)
{
WSAPI_DescPtr		descrP;
XErr				err, err2;
unsigned long		size;
OSType				dtype;
short				aShort;
WSAPI_CommandPBPtr 	pb = (WSAPI_CommandPBPtr)taskID;

	if NOT(err = WSAPI_GetParameter(pb, piIfModifiedSince, &descrP))
	{	size = sizeof(short);
		if NOT(err = WSAPI_GetDescriptor(pb, descrP, &dtype, &aShort, &size))
			*modifiedP = (aShort != 0);
		err2 = WSAPI_DisposeDescriptor(pb, &descrP);
	}
	else
		err = (WSAPI_ErrorCode)-1;
	
return err;
}*/

//===========================================================================================
XErr 	HTTPControllerGetServerParam(void *taskID, long which, char *cstr, long *numP)
{
XErr	err = noErr;
//CStr255	tempStr;

	switch(which)
	{	case kServerDomain:
			err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piServerName, cstr, STR_MAXLEN);
			break;
		/*case kServerPort:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piServerPort, numP);
			break;
		case kServerDirectoryPath:
			err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piServerDirectoryPath, cstr, STR_MAXLEN);
			break;
		case kServerVersionNumber:
			err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piVersionNumber, cstr, STR_MAXLEN);
			break;
		case kServerTotalConnections:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piTotalConnections, numP);
			break;
		case kServerCurrentUserLevel:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piCurrentUserLevel, numP);
			break;
		case kServerHighestUserLevel:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piHighestUserLevel, numP);
			break;
		case kServerCurrentFreeMemory:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piCurrentFreeMemory, numP);
			break;
		case kServerMinimumFreeMemory:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piMinimumFreeMemory, numP);
			break;
		case kServerTotalConnTimeouts:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piTotalConTimeouts, numP);
			break;
		case kServerTotalConBusies:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piTotalConBusies, numP);
			break;
		case kServerTotalConDenied:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piTotalConDenied, numP);
			break;
		case kServerTotalBytesSent:
			err = _GetParamFast_Number((WSAPI_CommandPBPtr)taskID, piTotalBytesSent, numP);
			break;
		case kServerUpSinceDate:
		#ifdef __MACOSX__
			// With WebSTAR V piUpSinceDate doesn't work at all
			CEquStr(cstr, gStartupDateStr);
		#else
			err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piUpSinceDate, cstr, STR_MAXLEN);
		#endif
			break;
		case kServerIndexFile:
			err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piIndexFile, cstr, STR_MAXLEN);
			break;
		case kServerErrorFile:
			if NOT(err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piErrorFile, tempStr, STR_MAXLEN))
			{	CEquStr(cstr, gsServerRoot);
				CAddStr(cstr, tempStr);
				CSubstitute(cstr, ':', '/');
			}
			break;*/
		default:
			return -1;
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetIPAddress(void *taskID, char *ipAddress)
{
WSAPI_CommandPBPtr	pbPtr = (WSAPI_CommandPBPtr)taskID;
WSAPI_DescPtr		descrP;
XErr				err, err2;
unsigned long		size, ip;
OSType				dtype;
Byte				byte;
CStr15				byteStr;

	if NOT(err = WSAPI_GetParameter(pbPtr, piClientIPAddress, &descrP))
	{	size = sizeof(long);
		if NOT(err = WSAPI_GetDescriptor(pbPtr, descrP, &dtype, &ip, &size))
		{	byte = *(Byte*)&ip;
			CNumToString(byte, ipAddress);
			CAddChar(ipAddress, '.');
			
			byte = *(Byte*)((Ptr)&ip+1);
			CNumToString(byte, byteStr);
			CAddStr(ipAddress, byteStr);
			CAddChar(ipAddress, '.');

			byte = *(Byte*)((Ptr)&ip+2);
			CNumToString(byte, byteStr);
			CAddStr(ipAddress, byteStr);
			CAddChar(ipAddress, '.');

			byte = *(Byte*)((Ptr)&ip+3);
			CNumToString(byte, byteStr);
			CAddStr(ipAddress, byteStr);
		}
		err2 = WSAPI_DisposeDescriptor(pbPtr, &descrP);
	}
	else
		err = (WSAPI_ErrorCode)-1;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetAddress(void *taskID, char *address)
{
XErr	err = noErr;

	err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piAddressKeyword, address, STR_MAXLEN);
	if (err == WSAPI_E_NameLookupFailed)
		err = HTTPControllerGetIPAddress(taskID, address);	

return err;
}


//===========================================================================================
XErr HTTPControllerGetPathArgs(void *taskID, char *pathArgs)
{
	return _GetParamFast((WSAPI_CommandPBPtr)taskID, piPathArgKeyword, pathArgs, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetPhysURL(void *taskID, BlockRef *blockP, long *lenP)
{
BlockRef	urlblock;
XErr		err;
int			size, servLen, urlLen;
Ptr			url, final_p;
char		*servP;

	if NOT(err = _GetParamSlow(taskID, piURLPhysicalPath, &urlblock, nil))
	{	url = GetPtr(urlblock);
		urlLen = CLen(url);
	#ifdef __MACOSX__
		servLen = gsServerRootCLen;
		servP = gsServerRoot;
	#else
		if (*url == ':')
		{	servLen = gsServerRootCLen;
			servP = gsServerRoot;
		}
		else
		{	servLen = 1;
			servP = "/";
		}
	#endif
		size = urlLen + servLen;
		if (*blockP = NewPtrBlock(size + 1, &err, &final_p))
		{	//final_p = GetPtr(*blockP);
			CopyBlock(final_p, servP, servLen);
			CopyBlock(final_p + servLen, url, urlLen);
			final_p[size] = 0;
			*lenP = size;
			CSubstitute(final_p, ':', '/');
		}
		DisposeBlock(&urlblock);	
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetPostArgs(void *taskID, BlockRef *blockP, long *postLen)
{
long			len;
BlockRef		postBlock;
XErr			err;
CStr255			searchArgs;
unsigned long	postMAX;

	if (err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piSearchArgKeyword, searchArgs, STR_MAXLEN))
		return err;
	postMAX = GetPOSTLimit(searchArgs);
	if (err = HTTPControllerGetContentLength(taskID, &len))
		return err;
	if (postMAX && (len > postMAX))
	{	*blockP = 0;
		*postLen = kInvalidPostLength;
	}
	else
	{	if (len < _24K)
		{	if (postMAX && (len > postMAX))
			{	*blockP = 0;
				*postLen = kInvalidPostLength;
			}
			else
			{	err = _GetGenericParamByHandleExt(taskID, piPostKeyword, &postBlock, &len, len, postMAX);
				if (err)
				{	// try with ReadHTTPData
					if NOT(_HTTPReadPostArg(taskID, postMAX, &postBlock, &len))
						err = noErr;
				}
			}
		}
		else
			err = _HTTPReadPostArg(taskID, postMAX, &postBlock, &len);
		if NOT(err)
		{	*postLen = len;
			*blockP = postBlock;
		}
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetSearchArgs(void *taskID, BlockRef *searchBlockP, long *searchLen)
{
	return _GetGenericParamByHandle(taskID, piSearchArgKeyword, searchBlockP, searchLen, -1);
}

//===========================================================================================
/*XErr HTTPControllerGetSearchArgsString(void *taskID, char *searchArgs)
{
	return _GetParamFast((WSAPI_CommandPBPtr)taskID, piSearchArgKeyword, searchArgs, STR_MAXLEN);
}*/

//===========================================================================================
XErr	HTTPControllerGetFullRequest(void *taskID, BlockRef *blockP, long *lenP)
{
	return	_GetParamSlow(taskID, piFullRequestKeyword, blockP, lenP);
}

//===========================================================================================
XErr HTTPControllerGetServerName(void *taskID, char *serverName)
{
XErr		err = noErr;
long		len;
CStr255		tempServerName;
char		*strP;

	if NOT(err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piServerField, tempServerName, STR_MAXLEN))
	{	if (strP = strchr(tempServerName, ':'))
		{	len = CLen(tempServerName) - (strP - tempServerName);
			strP++;
			len--;
			if (len && (*strP == ' '))
			{	strP++;
				len--;
			}
			CopyBlock(serverName, strP, len);
			serverName[len] = 0;
		}
		else
			CEquStr(serverName, tempServerName);
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetServerDir(void *taskID, char *serverDir)
{
#pragma unused(taskID)
XErr	err = noErr;
long	serverLen;

	#ifdef 	__MACOSX__
	{
	CStr255	tempStr;
	
		if NOT(err = _GetServerRoot(taskID, tempStr))
		{	CEquStr(serverDir, gsServerRoot);
			CAddStr(serverDir, tempStr);
			serverLen = CLen(serverDir);
		}
	}
	#else
		if NOT(err = _GetServerRoot(taskID, serverDir))
		{	
			serverLen = CLen(serverDir);
			CSubstitute(serverDir, ':', '/');
		}
	#endif
	if NOT(err)
	{	if (serverDir[--serverLen] != '/')
			CAddChar(serverDir, '/');
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetUsername(void *taskID, char *user)
{
	return _GetParamFast((WSAPI_CommandPBPtr)taskID, piUserKeyword, user, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetPassword(void *taskID, char *pass)
{
	return _GetParamFast((WSAPI_CommandPBPtr)taskID, piPasswordKeyword, pass, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetMethod(void *taskID, char *method)
{
	return _GetParamFast((WSAPI_CommandPBPtr)taskID, piMethodKeyword, method, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetContentType(void *taskID, char *contentType)
{
XErr			err;

	err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piContentType, contentType, STR_MAXLEN);
	if (err == WSAPI_E_RequestFailed)
	{	*contentType = 0;
		err = noErr;
	}
	
return err;
}

//===========================================================================================
XErr 	HTTPControllerGetContentLength(void *taskID, long *contentLengthP)
{
WSAPI_DescPtr	descrP;
OSType			dtype;
XErr			err, err2;
unsigned long	descrSize;
//CStr255			contentStr;

	*contentLengthP = 0;
	/*
	err = WSAPI_GetIndexedParameter ((WSAPI_CommandPBPtr)taskID, piRequestHeaderField, "Content-length",  &descrP);
	if (err == WSAPI_E_IndexedValueNotFound)
		err = noErr;
	else
	{	descrSize = 255;
		if NOT(err = WSAPI_GetDescriptor((WSAPI_CommandPBPtr)taskID, descrP, &dtype, contentStr, &descrSize))
		{	contentStr[descrSize] = 0;
			CStringToNum(contentStr, contentLengthP);
			err2 = WSAPI_DisposeDescriptor((WSAPI_CommandPBPtr)taskID, &descrP);
		}
	}
	*/
	
	if NOT(err = WSAPI_GetParameter((WSAPI_CommandPBPtr)taskID, piContentLength, &descrP))
	{	descrSize = sizeof(long);
		if NOT(err = WSAPI_GetDescriptor((WSAPI_CommandPBPtr)taskID, descrP, &dtype, contentLengthP, &descrSize))
			err2 = WSAPI_DisposeDescriptor((WSAPI_CommandPBPtr)taskID, &descrP);
	}
	else
		err = (WSAPI_ErrorCode)-1;
	
return err;
}

//===========================================================================================
/*XErr HTTPControllerGetIndexFile(void *taskID, char *indexFile)
{
XErr			err = noErr;

	if NOT(err = _GetParamFast((WSAPI_CommandPBPtr)taskID, piIndexFile, indexFile, STR_MAXLEN))
	{	CSubstitute(indexFile, ':', '/');
		if (*indexFile == '/')
			CEquStr(indexFile, indexFile+1);
	}

return err;
}*/

//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *outPutStr)
{
int				len = strlen(outPutStr), actionLen;
XErr			err = noErr;
HTTPControllerP	httContP;

	if (len)
	{	BlockRef	block;
		Ptr			p;

		if (gHttpController)
		{	httContP = (HTTPControllerP)GetPtr(gHttpController);
			actionLen = CLen(httContP->action);
		}
		else
			actionLen = 0;
		if (block = NewPtrBlock(len + actionLen + 2 + 2, &err, &p))
		{	//p = GetPtr(block);
			if (actionLen)
				CopyBlock(p, httContP->action, actionLen);
			CopyBlock(p + actionLen, ": ", 2);
			CopyBlock(p + actionLen + 2, outPutStr, len);
		#ifdef __MACOSX__
			CopyBlock(p + actionLen + 2 + len, "\n", 1);
			*(p + actionLen + 2 + len + 1) = 0;
		#else
			*(p + actionLen + 2 + len) = 0;
		#endif
			err = WSAPI_DisplayMessage((WSAPI_CommandPBPtr)taskID, p);
			DisposeBlock(&block);
		}
		if (gLogRef)
		{	CAddChar(outPutStr, '\r');
			CStringToLog(gLogRef, outPutStr, false);
		}
	}

return err;
}

//===========================================================================================
/*static void	_WaitAllExit(void *taskID, long timeout)	// in ticks
{
XErr			err = noErr;
CStr15			gWSAPIUsersStr;
CStr63			aPStr;
unsigned long	startTicks;

	if (gWSAPIUsers)
	{	CNumToString(gWSAPIUsers, gWSAPIUsersStr);
		HTTPControllerLog(taskID, "before ----------------------------------");
		HTTPControllerLog(taskID, gWSAPIUsersStr);
		gInitPlug = false;
		startTicks = XGetTicks();
		while (gWSAPIUsers)
		{	if (err = (XErr)WSAPI_YieldTime((WSAPI_CommandPBPtr)taskID, 3))
				goto out;
			if ((XGetTicks() - startTicks) > timeout)
			{	HTTPControllerLog(taskID, "_WaitAllExit timeout");
				break;
			}
		}
	out:
		if (err)
		{	CNumToString(err, gWSAPIUsersStr);
			CEquStr(aPStr, "ERROR: ");
			CAddStr(aPStr, gWSAPIUsersStr);
			HTTPControllerLog(taskID, gWSAPIUsersStr);
		}
		CNumToString(gWSAPIUsers, gWSAPIUsersStr);
		HTTPControllerLog(taskID, "after ----------------------------------");
		HTTPControllerLog(taskID, gWSAPIUsersStr);
		gInitPlug = true;
	}
	_XThreadsCloseAllOtherThreads();
}
*/
//===========================================================================================
void	HTTPControllerSetMonoThread(void *taskID)
{
#pragma unused(taskID)
}

//===========================================================================================
void	HTTPControllerSetMultiThread(void *taskID)
{
#pragma unused(taskID)
}

//============================================================
/*Boolean HTTPControllerConnectionClosed(void *taskID)
{
XErr					err = noErr;
WSAPI_ConnectionStatus	status;

	if NOT(err = WSAPI_HTTPConnectionStatus((WSAPI_CommandPBPtr)taskID, &status))
		return (status == WSAPI_IP_Closed);
	else
		return true;
}*/

//===========================================================================================
/*XErr	HTTPControllerYield(void *taskID, long sleep)
{	
	return WSAPI_YieldTime((WSAPI_CommandPBPtr)taskID, sleep);
}
*/
#pragma mark-
//===========================================================================================
/*long	HTTPControllerGetVersion(void *taskID, long *versionP)
{
	if (versionP)
		*versionP = ((WSAPI_CommandPBPtr)taskID)->api_version;
	return HTTP_CONT_WSAPI;
}*/

//===========================================================================================
/*static void _AddOneLine(void *taskID, char *aCStr, Ptr *textPPtr, long *lenP, long returnSize, long *jP, Boolean *onlySpacesP)
{
int		j = *jP;

	(*textPPtr) += returnSize;
	(*lenP) -= returnSize;
	aCStr[j] = 0;
	if (j == 250)
	{	CAddStr(aCStr, "...");
		WSAPI_DisplayMessage((WSAPI_CommandPBPtr)taskID, aCStr);
		j = 0;
	}
	else
	{	if (j && NOT(*onlySpacesP))
			WSAPI_DisplayMessage((WSAPI_CommandPBPtr)taskID, aCStr);
		j = 0;
	}
	(*onlySpacesP) = true;
	*jP = j;
}

//===========================================================================================
XErr HTTPControllerLogReply(void *taskID, BlockRef bufferH, long len)
{
Ptr		textP;
int		ch;
long	j;
long	returnSize;
CStr255	aCStr;
Boolean	onlySpaces = true;

	LockBlock(bufferH);
	textP = GetPtr(bufferH);
	WSAPI_DisplayMessage((WSAPI_CommandPBPtr)taskID, "============= BEGIN BIFERNO SCRIPT OUTPUT");
	WSAPI_DisplayMessage((WSAPI_CommandPBPtr)taskID, "");
	if (len)
	{	j = 0;
		do {
			if (IsNewLine(textP, len, &returnSize) || (j == 250))
			{	_AddOneLine(taskID, aCStr, &textP, &len, returnSize, &j, &onlySpaces);
				continue;
			}
			else if ((ch = *textP) != '\n')
			{	if (ch != ' ')
					onlySpaces = false;
				aCStr[j++] = ch;
			}
			textP++;
			len--;
		} while (len > 0);
	}
	_AddOneLine(taskID, aCStr, &textP, &len, returnSize, &j, &onlySpaces);	// last
	DisposeBlock(&bufferH);
	WSAPI_DisplayMessage((WSAPI_CommandPBPtr)taskID, "============= END BIFERNO SCRIPT OUTPUT");
	
return noErr;
}

//===========================================================================================
XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
int			ch;
long		j;
long		returnSize = 0;
CStr255		aCStr;
Boolean		onlySpaces = true;
BlockRef	block;
XErr		err = noErr;

	j = 0;
	if (len)
	{	if (block = NewBlock(len, &err))
		{	CopyBlock(GetPtr(block), textP, len);
			if NOT(err = HTML2Txt(&block, &len))
			{	if (len)
				{	LockBlock(block);
					textP = GetPtr(block);
					do {
						if (IsNewLine(textP, len, &returnSize) || (j == 250))
						{	_AddOneLine(taskID, aCStr, &textP, &len, returnSize, &j, &onlySpaces);
							continue;
						}
						else if ((ch = *textP) != '\n')
						{	if (ch != ' ')
								onlySpaces = false;
							aCStr[j++] = ch;
						}
						textP++;
						len--;
					} while (len > 0);
					if ((j > 1) || ((*aCStr != '\t') && (*aCStr != '\r')))
						_AddOneLine(taskID, aCStr, nil, nil, 0, &j, &onlySpaces);
				}
			}
			DisposeBlock(&block);
		}
	}
	
return err;
}
*/
//===========================================================================================
static void _LogOneLine(void *taskID, Ptr textP, long len, Boolean addToLast)
{
#pragma unused(addToLast)	// in teoria andrebbe preso in considerazione per non loggare sempre
							// su nuove linee, ma appendere (se non c'� stato un newLine)
CStr255		aCStr;
long		max;

	max = WSAPI_LOG_MAX_LINE_SIZE - 3;
	if (len >= max)
	{	CopyBlock(aCStr, textP, max);
		aCStr[max] = 0;
		CAddStr(aCStr, "...");
	}
	else
	{	CopyBlock(aCStr, textP, len);
		aCStr[len] = 0;
	}
	WSAPI_DisplayMessage((WSAPI_CommandPBPtr)taskID, aCStr);
}

//===========================================================================================
XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
#pragma unused(taskID)
long		lastLen, nlsize;
Ptr			lastP;
XErr		err = noErr;

	lastP = textP;
	lastLen = len;
	while (len > 0)
	{	if (IsNewLine(textP, len, &nlsize))
		{	_LogOneLine(taskID, lastP, lastLen - len, NOT(gsNewLineFound));
			textP += nlsize;
			len -= nlsize;
			lastP = textP;
			lastLen = len;
			gsNewLineFound = true;
		}
		else
		{	textP++;
			len--;
		}
	}
	if (lastLen > len)
	{	_LogOneLine(taskID, lastP, lastLen - len, NOT(gsNewLineFound));
		gsNewLineFound = false;
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerWindowOutputExt(void *taskID, BlockRef bufferH, long len)
{
Ptr			textP;
//RGBColor	black = {0, 0, 0}, red = {0xFFFF, 0, 0};

	LockBlock(bufferH);
	if (len)
	{	textP = GetPtr(bufferH);
		ZapNewLines((Byte*)textP, &len);
		if (len)
			HTTPControllerWindowOutput(taskID, textP, len);
	}
	DisposeBlock(&bufferH);
	
return noErr;
}

//===========================================================================================
XErr HTTPControllerSendReply(void *taskID, BlockRef block, long len)
{
XErr	err = noErr;

	if (len && block)
	{	if NOT(_ConnectionClosed(taskID))
		{	LockBlock(block);
			err = WSAPI_SendHTTPData((WSAPI_CommandPBPtr)taskID, GetPtr(block), len);
		}
	}
	if (block)
		DisposeBlock(&block);
	
return err;
}

#pragma mark-

#ifndef MODULE_FULL
//===========================================================================================
XErr	HTTPControllerRegister(HTTPControllerP	httpControllerP)
{
XErr	err = noErr;
CStr255	versionStr;

	CEquStr (httpControllerP->action, "BIFERNO");
	CEquStr (httpControllerP->pluginName, "Tabasoft WSAPI Biferno plugin");
	CEquStr (httpControllerP->suffix, ".bfr");	// Biferno script
	CEquStr (httpControllerP->mimeType, "text/html");
	VersionToString(CUR_BIFERNO_VERSION, versionStr, DEVELOPMENT_VERS_STR);	
	CEquStr(httpControllerP->version, versionStr);
	CEquStr (httpControllerP->adminURL, "");
	CEquStr(httpControllerP->aboutStr, "Biferno - Tabasoft 2000");
	
return err;
}
#endif

#pragma mark-
//===========================================================================================
WSAPI_ErrorCode WSAPI_Dispatch (WSAPI_CommandPBPtr commandPtr)
{
XErr						err = noErr;
register HTTPControllerP	contP = nil;
short						oldres;
CStr255						aCStr;
//char						*strP;
Boolean						onlyOpt;

	/*
	{
	CStr15	str;
	
	CNumToString(commandPtr->command, str);
	_CheckFreeInPool(str);
	}*/
	//CDebugStrExt("WSAPI_Dispatch: ", commandPtr->command, nil);
	
	if (gHttpController)
		contP = (HTTPControllerP)GetPtr(gHttpController);
	
	if (gResourceRefnum)
	{	oldres = CurResFile();
		UseResFile(gResourceRefnum);
		if (err = ResError())
		{	oldres = 0;
			goto out;
		}
	}
	else
		oldres = 0;
	
	switch (commandPtr->command) 
	{	case WSAPI_Register:
			//if (strP = getenv("BIFERNOHOME"))
			//	CEquStr(gsBifernoHome, strP);
			//else
			if NOT(GetBifernoHome(gsBifernoHome))
				return -1;
			//if NOT(err = GetXApplicationCurrentDir(gsBifernoHome))
			{	//CAddStr(gsBifernoHome, "BifernoHome/");				
				err = XInit(gsBifernoHome);
			}
			gShutDownFlag = false;
			err = _Register(commandPtr);
			break;
			
		case WSAPI_AccessControl:
			if (contP->AccessControl)
				err = contP->AccessControl(commandPtr);
			break;
				
		case WSAPI_Init:
			//InitSound();
			XCurrentDateTimeToString(gStartupDateStr, kComplete);
			gExpluseDone = false;
			gResourceRefnum = commandPtr->param.init.resRef;
			gInitPlug = false;
			gShutDownFlag = false;
			if (err = _RequestIdleTime(commandPtr, 1L))
				break;
			//err = _InitCgiParamList(&gCGIParamList);			
			break;
			
		case WSAPI_Run:
			onlyOpt = false;
			if (gShutDownFlag)
			{	_LogRun(commandPtr, XError(kXLibError, ErrThreadAborted));
				break;
			}
			if (gInitErr)
				_LogRun(commandPtr, gInitErr);
			else
			{	while NOT(gInitPlug)
				{	if (err = (XErr)WSAPI_YieldTime(commandPtr, 3))
						goto out;
				}
				err = ClientRun(commandPtr, 0L, BIFERNO_UNIX_FILE, aCStr, CLIENT_RUN_TIMEOUT);
				if (err == ECONNREFUSED)
				{	BlockRef	serverResponse;
					long		tLen, serverResponseLen;
					XErr		err2 = noErr;
					BlockRef	block;
					//CStr15		tStr;
					Ptr			p;
					
					CEquStr(aCStr, "check biferno");
					tLen = CLen(aCStr);
					if (block = NewBlockLocked(4 + tLen, &err2, &p))
					{	*(long*)p = XHostToNetwork(tLen);
						CopyBlock(p + 4, aCStr, tLen);
						if (err2 = XClientCall("", 0, block, 4 + tLen, &serverResponse, &serverResponseLen, BIFERNOSENTINEL_UNIX_FILE, aCStr, nil, 0, CLIENT_RUN_TIMEOUT, EXPECT_PREFIXED))
							CEquStr(aCStr, " (connecting to bifernosentinel)");
						DisposeBlock(&serverResponse);
						DisposeBlock(&block);
						if NOT(err2)
						{	unsigned long 	t, lastTicks, startTicks, checkPeriod;
							
							startTicks = lastTicks = XGetTicks();
							checkPeriod = 60 * 4;	// 4 secs
							while (((t = XGetTicks()) - startTicks) < TOTAL_RETRY_TIME)
							{	if ((t - lastTicks) > checkPeriod)
								{	err2 = ClientRun(commandPtr, 0L, BIFERNO_UNIX_FILE, aCStr, CLIENT_RUN_TIMEOUT);
									lastTicks = XGetTicks();
									if NOT(err2)
									{	err = noErr;
										break;
									}
									else if (err2 == ECONNREFUSED)
										err2 = noErr;
									else
									{	err = err2;
										break;
									}
								}
							}
						}
						else
							err = err2;
					}	
				}
				else if (err == EWOULDBLOCK)
				{	sprintf(aCStr, "Biferno script still running after socket timed out (%d)", EWOULDBLOCK);
					onlyOpt = true;
				}
				if (err)
					_HandleErr(commandPtr, err, aCStr, onlyOpt);
				//_LogRun((long)commandPtr, err);
			}
			break;

		case WSAPI_Idle:
			if NOT(gInitPlug)
			{	
				XFilePath	logFilePath;
				
				///if (CheckPath(gsBifernoHome, false))
				//	err = CreateXFolder(gsBifernoHome);
				if NOT(err)
				{	//if NOT(err = XGetApplicationFolderPath(logFilePath))
					{	CEquStr(logFilePath, gsBifernoHome);
						CAddStr(logFilePath, "BifernoWSAPI.log");
						if NOT(err = InitLog(logFilePath, &gLogRef))
						{	//long		tlen;
							
							gsLogFileInited = true;
							err = _GetServerRoot(commandPtr, gsServerRoot);
							CAddChar(gsServerRoot, '/');
							gsServerRootCLen = CLen(gsServerRoot);
						}
						else
							HTTPControllerLog(commandPtr, logFilePath);
					}
					if NOT(err)
						gInitPlug = true;
					else
					{	gInitErr = err;
						_HandleErr(commandPtr, err, "(Init)", false);
						HTTPControllerLog(commandPtr, "================================");
						HTTPControllerLog(commandPtr, "BIFERNO ERROR! BIFERNO NOT INITIALIZED!!");
					}
				}
			#ifdef MODULE_FULL
				HTTPControllerLog((long)commandPtr, "================================");
			#endif
			}
			else
			{	if (contP->Idle)
					err = contP->Idle(commandPtr);
			}
			break;
						
		case WSAPI_Emergency:
			if (contP->Emergency)
				err = contP->Emergency(commandPtr);
			break;
			
		case WSAPI_ServerStateChanged:
			if (contP->ServerStateChanged)
			{	long	which;
			
				switch (commandPtr->param.stateChanged.whichParam)
				{	case piCacheFlush:
						which = kFlush;
						break;
						
					default:
						which = 0;
						break;
				}
				err = contP->ServerStateChanged(commandPtr, which, nil);
			}
			break;
			
		case WSAPI_Filter:
			break;

		case WSAPI_Shutdown:
			gShutDownFlag = true;
			gInitPlug = false;
			if (contP->ShutDown && gsDoInit)
				err = contP->ShutDown(commandPtr);
			if (gsLogFileInited)
				EndLog(&gLogRef);
		#ifdef __MACOSX__
			err = XEnd(0);
		#endif
			break;

		case WSAPI_UIActivate:
			if (contP->ServerStateChanged)
				err = contP->ServerStateChanged(commandPtr, kReload, nil);
			break;

		case WSAPI_Event:
			break;
		
		default:
			HTTPControllerLog(commandPtr, "HTTPController Received unknown WSAPI message");
			err = WSAPI_E_MessageNotHandled;
			break;
	}

out:
if (oldres)
	UseResFile(oldres);
	
return (WSAPI_ErrorCode)err;
}

