/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMrgNetClient.c,v 1.8 2006-10-09 10:40:25 valfer Exp $
	|______________________________________________________________________________
*/
#include	"XLib.h"
//#include	"Helpers.h"
#include 	"HTTPMgr.h"

#include 	"HTTPMrgNet.h"

/*
PROTOCOLLO DI TRASMISSIONE
schema:
	
	long	length of all subsequent data (for sockets)
	
	long	TOTELEMS (number of following struct)
	long	CLENGTH (content length)
	
	long	WHAT
	long	LENGTH
	..... DATA

	long	WHAT
	long	LENGTH
	..... DATA

	long	WHAT
	long	LENGTH
	..... DATA

====================================================
*/
#define	TOTELEMS	16
#ifdef __BIG_ENDIAN__
	static uint32_t	tags[TOTELEMS] = {'SDIR', 'PATH', 'PURL', 'POST', 'SRCH', 'USER', 'PASS', 'METH', 'CTYP', 'SNAM', 'HOST', 'FREQ', 'ADDR', 'IPAD', 'PROT', 'PORT'};
#else
	static uint32_t	tags[TOTELEMS] = {'RIDS', 'HTAP', 'LRUP', 'TSOP', 'HCRS', 'RESU', 'SSAP', 'HTEM', 'PYTC', 'MANS', 'TSOH', 'QERF', 'RDDA', 'DAPI', 'TORP', 'TROP'};
#endif
	
#define SERVER_PORT 8080

enum {
		kSDIR = 0,
		kPATH,
		kPURL,
		kPOST,
		kSRCH,
		kUSER,
		kPASS,
		kMETH,
		kCTYP,
		kSNAM,
		kHOST,
		kFREQ,
		kADDR,
		kIPAD,
		kPROT,
		kPORT
	};

//===========================================================================================
/*static long _GetPOSTMAX(char *pathArgs)
{
Str31	tStr;
long	postMax = 0, pathLen;

	pathLen=CLen(pathArgs);
	if (pathLen > 8)
	{	if NOT(CompareBlock(pathArgs+4, "MAX=", 4))
		{	pathLen -= 8;
			if (pathLen < 31)
			{	CopyBlock(&tStr[1], pathArgs+8, pathLen);
				tStr[0] = pathLen;
				PStringToNum(tStr, &postMax);
				if (postMax < 0) 
					postMax = 0;
			}
		}
	}
	
return postMax;
}
*/
//===========================================================================================
static char*	_GetHttpParam(void *taskID, long index, long *lenP, BlockRef *blockToDisposeP, char *aCStr, XErr *errP)
{
char		*strP;
XErr		err = noErr;
CStr15		tStr;
BlockRef	tempBlockRef;

	strP = nil;
	*lenP = 0;
	*blockToDisposeP = nil;
	*errP = noErr;
	CNumToString(index, tStr);
	switch(index)
	{	case kSDIR:
			if NOT(err = HTTPControllerGetServerDir(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kPATH:
			if NOT(err = HTTPControllerGetPathArgs(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kPURL:
			if NOT(err = HTTPControllerGetPhysURL(taskID, &tempBlockRef, lenP))
			{	strP = GetPtr(tempBlockRef);
				*blockToDisposeP = tempBlockRef;
			}
			break;
		case kPOST:
			if NOT(err = HTTPControllerGetMethod(taskID, aCStr))
			{	if NOT(CCompareStrings_cs(aCStr, "POST"))
				{	if NOT(err = HTTPControllerGetPostArgs(taskID, &tempBlockRef, lenP))	// N.B. *lenP can be kInvalidPostLength
					{	if (tempBlockRef)
						{	strP = GetPtr(tempBlockRef);
							*blockToDisposeP = tempBlockRef;
						}
					}
				}
			}
			break;
		case kSRCH:
			if NOT(err = HTTPControllerGetSearchArgs(taskID, &tempBlockRef, lenP))
			{	strP = GetPtr(tempBlockRef);
				*blockToDisposeP = tempBlockRef;
			}
			break;
		case kUSER:
			if NOT(err = HTTPControllerGetUsername(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kPASS:
			if NOT(err = HTTPControllerGetPassword(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kMETH:
			if NOT(err = HTTPControllerGetMethod(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kCTYP:
			if NOT(err = HTTPControllerGetContentType(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kSNAM:
			if NOT(err = HTTPControllerGetServerName(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kHOST:
			if NOT(err = HTTPControllerGetServerParam(taskID, kServerDomain, aCStr, nil))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kFREQ:
			if NOT(err = HTTPControllerGetFullRequest(taskID, &tempBlockRef, lenP))
			{	strP = GetPtr(tempBlockRef);
				*blockToDisposeP = tempBlockRef;
			}
			break;
		case kADDR:
			if NOT(err = HTTPControllerGetAddress(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kIPAD:
			if NOT(err = HTTPControllerGetIPAddress(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kPROT:
			if NOT(err = HTTPControllerGetProtocol(taskID, aCStr))
			{	strP = aCStr;
				*lenP = CLen(strP);
			}
			break;
		case kPORT:
			if NOT(err = HTTPControllerGetPort(taskID, (uint32_t*)aCStr))
			{	
				strP = aCStr;
				*lenP = sizeof(uint32_t);
			}
			break;
	}
	
	if (err)
		*errP = err;
	
return strP;
}
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	ClientRun(void *taskID, long serverPort, char *unixFile, char *errString, long timeout_secs)
{
XErr		err = noErr;
long		len, buffID, serverResponseLen;
BlockRef	blockToDispose;
char		*strP;
int			i;
BlockRef	serverResponse;
//CStr15	tStr;
CStr255		aCStr;
long		contentLength;

#if CHECK_LEAKING
CStr255		checkLeakingStr;

	ResetLeaking();
#endif
	
	if (err = HTTPControllerGetContentLength(taskID, &contentLength))
		return err;

	buffID = 0;
	if (buffID = BufferCreate(255, &err))
	{	if (err = BufferAddLong(buffID, 0))			// final length (fill it later)
			goto out;	
		if (err = BufferAddLong(buffID, TOTELEMS))
			goto out;	
		if (err = BufferAddLong(buffID, contentLength))
			goto out;	
		for (i = 0; (i < TOTELEMS) && NOT(err); i++)
		{	// What
			if (err = BufferAddLong(buffID, tags[i]))
				goto out;
			strP = _GetHttpParam(taskID, i, &len, &blockToDispose, aCStr, &err);
			if NOT(err)
			{	// Length
				if NOT(err = BufferAddLong(buffID, len))
				{	// Data
					if (strP)
						err = BufferAddBuffer(buffID, strP, len);
				}
				if (blockToDispose)
					DisposeBlock(&blockToDispose);
			}
		}
	}

	if NOT(err)
	{	long		dataToSendLen;
		BlockRef	block;
		Ptr			dataPtr;

		if NOT(err = BufferAddChar(buffID, 0))
		{	block = BufferGetBlockRefExtSize(buffID, &dataToSendLen, &dataPtr);
			// prefixed final length
			*(uint32_t*)dataPtr = XHostToNetwork(dataToSendLen - 4);
			SetBlockSize(block, dataToSendLen);
			if NOT(err = XClientCall("", serverPort, block, dataToSendLen, &serverResponse, &serverResponseLen, unixFile, errString, nil, 0, timeout_secs, EXPECT_PREFIXED))
			{	LockBlock(serverResponse);
				err = HTTPControllerSendReply(taskID, serverResponse, serverResponseLen);
			}
		}
	}

//if (err)
//	_HandleErr(reqP, err);
out:
if (buffID)
	BufferFree(buffID);

#if CHECK_LEAKING
	CheckLeaking(checkLeakingStr, nil, nil);
	if (*checkLeakingStr)
		CDebugStr(checkLeakingStr);
		// ap_rputs(checkLeakingStr, reqP);
#endif
return err;
}
