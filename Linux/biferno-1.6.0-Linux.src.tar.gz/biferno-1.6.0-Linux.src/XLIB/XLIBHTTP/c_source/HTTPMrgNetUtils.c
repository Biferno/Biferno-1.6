/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMrgNetUtils.c,v 1.20 2008-02-07 14:43:04 tabasoft Exp $
	|______________________________________________________________________________
*/
#include	"XLib.h"
#include 	"XThreadsPrivate.h"

#include 	"HTTPMgr.h"
#include 	"HTTPMrgNet.h"

#include 	<string.h>

#define	MAXLOG			251
//#define	NEW_APPENDED	"******************** New Log File Appended ********************"

extern unsigned long		gMainThreadID;

//===========================================================================================
static XErr _GetLastBytes(XFilePathPtr filePath, long lenFromEof, char *aStr)
{
XFileRef		fileRef;
long			eof;
XErr			err = noErr, err2 = noErr;

	if (lenFromEof > 255)
		return -1;
	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof > lenFromEof)
			{	if NOT(err = SetXFPos(fileRef, FROM_EOF, -lenFromEof))
				{	if NOT(err = ReadXFile(fileRef, aStr, &lenFromEof))
						aStr[lenFromEof] = 0;
				}
			}
			else
				err = -2;
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	
return err;
}

//===========================================================================================
unsigned long	GetPIDNumber(char *pidFilePath)
{
XFileRef		fileRef;
long			lenToRead, eof;
XErr			err = noErr, err2 = noErr;
CStr255			aStr;
unsigned long	pidNum = 0;

	if NOT(err = OpenXFile(pidFilePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof > 100)
				lenToRead = 100;
			else
				lenToRead = eof;
			if NOT(err = ReadXFile(fileRef, aStr, &lenToRead))
			{	aStr[lenToRead] = 0;
				CStringToNumExt(aStr, nil, &pidNum);
			}
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	
return pidNum;
}

//===========================================================================================
XErr	SentinelCheck(char* logFilePath, char* pidFilePath, SentinelCheckLogCallBack logcallBack, long loguserData, SentinelCheckKillCallBack killcallBack, long killuserData)
{
Boolean			isLocked;
XErr			err = noErr;
unsigned long	pid;
CStr255			aCStr, eNameStr, eMsg;

	logcallBack("biferno not responding...", loguserData);
	// Check if biferno is running
	CheckLogFile(logFilePath, &isLocked/*, true*/);
	if (isLocked)
	{	logcallBack("...biferno is running -> killing it", loguserData);
		if NOT(CheckPath(pidFilePath, false))
		{	if (pid = GetPIDNumber(pidFilePath))
			{
				killcallBack(pid, killuserData);
			}
		}
		else
			logcallBack("...couldn't find biferno pid file", loguserData);
	}
	else
		logcallBack("...biferno is down", loguserData);
		
	// Check if fBifernoServer.log ends with ==*NORMAL STOP*==
	err = _GetLastBytes(logFilePath, CLen(NORMAL_STOP_STRING), aCStr);
	if NOT(err)
	{	if (CCompareStrings(NORMAL_STOP_STRING, aCStr))
			logcallBack("BIFERNO QUITTED ABNORMALLY", loguserData);
	}
	else if (err == -2)
		logcallBack("BIFERNO QUITTED ABNORMALLY (log too short!)", loguserData);
	else
	{	XErrorGetDescr(err, eNameStr, eMsg);
		sprintf(aCStr, "Can't read BifernoServer.log (%d %s)", (int)err, eNameStr);
		logcallBack(aCStr, loguserData);
	}
	logcallBack("relaunching ...", loguserData);

return err;
}

//===========================================================================================
XErr	WritePID(char *appName, unsigned long pid)
{
XFileRef	xrefNum;
long		tLen;
CStr255		path, aCStr;
XErr		err = noErr;

	if NOT(err = XGetApplicationFolderPath(path))
	{	CAddStr(path, appName);
		CAddStr(path, ".pid");
		if NOT(err = OpenXFile(path, CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &xrefNum))
		{	CNumToString(pid, aCStr);
			tLen = CLen(aCStr);
			err = WriteXFile(xrefNum, aCStr, &tLen);
			SetXEOF(xrefNum, tLen);
			FlushXFile(xrefNum);
			CloseXFile(&xrefNum);
		}
	}

return err;
}

//===========================================================================================
XErr	DeletePID(char *appName)
{
//XFileRef	xrefNum;
//long		tLen;
CStr255		path;	//, aCStr;
XErr		err = noErr;
	
	if NOT(err = XGetApplicationFolderPath(path))
	{	CAddStr(path, appName);
		CAddStr(path, ".pid");
		DeleteXFile(path);
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __UNIX_XLIB__ || (__MAC_XLIB__ && __MACOSX__)
	#include <sys/stat.h>
#elif __WIN_XLIB__
	#include "BifernoWinRegistry.h"
#elif __MAC_XLIB__
	#include "XFilesMacPrivate.h"
#endif

//===========================================================================================
Boolean GetBifernoHome(char *aStr)
{
int		res;

#if __UNIX_XLIB__ || (__MAC_XLIB__ && __MACOSX__)
struct stat		theStat;

	res = stat(BIFERNO_HOME_PATH, &theStat);
	if (res < 0)
		sprintf(aStr, "\nError getting BifernoHome: can't read: %s\n\n", BIFERNO_HOME_PATH);
	else
		CEquStr(aStr, BIFERNO_HOME_PATH);
#elif __WIN_XLIB__
WIN32_FILE_ATTRIBUTE_DATA	attribData;
CStr255						tempStr;
XErr						err = noErr;

	GetStringKey(BIFERNO_HOME_KEYNAME, tempStr);
	if (*tempStr)
	{	if (GetFileAttributesEx(tempStr, GetFileExInfoStandard, &attribData))
		{	FilePathWin32ToXLib(tempStr);
			res = 1;
			CEquStr(aStr, tempStr);
		}
		else
		{	err =  GetLastError();
			sprintf(aStr, "Error getting BifernoHome: can't read: %s (err=%d)\r\n", tempStr, err);
			res = -1;
		}
	}
	else
	{	res = -1;
		sprintf(aStr, "Error getting BifernoHome (empty)\r\n");
	}
	
#elif __MAC_XLIB__
FSSpec	spec;
short	vRefNum;
long	dirID;
XErr	err = noErr;

	if NOT(err = FindFolder(kOnSystemDisk, kSystemFolderType, false, &vRefNum, &dirID))
    {	if (err = FSMakeFSSpec(vRefNum, kHFSRootFolderID, "\pBifernoHome", &spec))
    		res = -1;
    	else
    	{	if NOT(err = _GetCFullPath(&spec, aStr))
    			res = 1;
    		else
    			res = -1;
    	}
    	if (err)
    		sprintf(aStr, "\rError getting BifernoHome\r\r");
    }

#endif

return (res >= 0);
}

//===========================================================================================
// avoided --->	If doesn't find NORM_STOP_STR at end of log file (last time crashed)
// avoided --->	=> copy it in BifernoServer.crsh
// avoided because now Biferno log is never reset
void	CheckLogFile(char *filePath, Boolean *isLockedP)	//, Boolean checkOnlyLock)
{
//XFileRef		fileRef;
//long			diff, normLen, eof;
XErr			err = noErr;	//, err2 = noErr;
//Boolean			toMove = false;
//CStr255			aCStr;
//CStr255			crashPath;
//XFileRef 		crshRefNum, logFileRef;
//Boolean			doCheck = true;

	// If we can't obtain a lock -> file is open and biferno is running
	*isLockedP = false;
	if NOT(CheckPath(filePath, false))
	{	
	XFileRef	logRefNum;
	
		if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_WRITE_PERM, false, &logRefNum))
		{	if (err = LockXFile(logRefNum, 0, -1, false))
			{	//doCheck = false;
				*isLockedP = true;
			}
			else
				UnlockXFile(logRefNum, 0, -1);
			CloseXFile(&logRefNum);
		}
	}
	//if (checkOnlyLock || NOT(doCheck))
	//	return;
		
	// check if file ends with NORM_STOP_STR; if it does set toMove to true
	/*normLen = CLen(NORM_STOP_STR);
	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, true, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof)
			{	if ((diff = eof - normLen) < 0)
					toMove = true;
				else
				{	if NOT(err = SetXFPos(fileRef, FROM_START, diff))
					{	long	toRead = normLen;
						if NOT(err = ReadXFile(fileRef, aCStr, &toRead))
						{	if (CompareBlock(aCStr, NORM_STOP_STR, normLen))
								toMove = true;
						}
						err = SetXFPos(fileRef, FROM_START, 0);
					}
				}
			}
			else
				toMove = true;
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	if (NOT(err) && toMove)
	{	
	char	*strP;
	long	tLen;
	
		CEquStr(crashPath, filePath);
		if (strP = strrchr(crashPath, '.'))
		{	*(strP+1) = 0;
			CAddStr(crashPath, "crsh");
			if NOT(err = OpenXFile(crashPath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, true, &crshRefNum))
			{	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, true, &logFileRef))
				{	if NOT(err = SetXFPos(crshRefNum, FROM_EOF, 0))
					{	CEquStr(aCStr, EOL_STRING);
						CAddStr(aCStr, EOL_STRING);
						XCurrentDateTimeToString(crashPath, kComplete);
						CAddStr(aCStr, crashPath);
						CAddStr(aCStr, " - ");
						CAddStr(aCStr, NEW_APPENDED);
						CAddStr(aCStr, EOL_STRING);
						CAddStr(aCStr, EOL_STRING);
						tLen = CLen(aCStr);
						if NOT(err = WriteXFile(crshRefNum, aCStr, &tLen))
							err = TranferBytes(logFileRef, crshRefNum);
					}
					CloseXFile(&logFileRef);
				}
				CloseXFile(&crshRefNum);
			}
		}
	}*/
}

//===========================================================================================
// aCStr must be 255
void	FirstLine(char *textP, long len, char *aCStr)
{
Ptr		destP, sourceP;
int		i;

	destP = aCStr;
	sourceP = textP;
	i = 0;
	while (i++ < MAXLOG) 	//&& (*sourceP != '\n'))
	{	if (IsNewLine(sourceP, len, nil))
			break;
		else
		{	*destP++ = *sourceP++;
			len--;
		}
	}
	if (i >= MAXLOG)		//&& (*sourceP != '\n'))
	{	*destP++ = '.';
		*destP++ = '.';
		*destP++ = '.';
	}	
	*destP = 0;
}

//===========================================================================================
static void	GetOptionString(CmdType cmd, char *modeStr)
{
	switch(cmd)
	{
		case kFlush:
			CEquStr(modeStr, "flush");
			break;
		case kReload:
			CEquStr(modeStr, "reload");
			break;
		case kQuit:
			CEquStr(modeStr, "quit");
			break;
		case kGetVersion:
			CEquStr(modeStr, "getversion");
			break;
		case kCheck:
			CEquStr(modeStr, "check");
			break;
		case kRequest:
			CEquStr(modeStr, "r");
			break;
		case kStartup:
			CEquStr(modeStr, "startup");
			break;
		case kMessage:
			CEquStr(modeStr, "msg");
			break;
			
		default:
			CEquStr(modeStr, "??");
			break;
	}
}

//===========================================================================================
void	FormatLogString(char *logString, CmdType cmd, char dir, char *ip_addr, char *host, char *notes, LONGLONG uniqueTag, char *sid, char *appName)
{
CStr31			tempStr;
unsigned long	threadID;
int				totThreads, logLen, available, notesLen;

	// Date Time
	XCurrentDateTimeToString(logString, kWantDate+kWantHour+kWantSecs+kLeadingZeros);
	CAddChar(logString, '\t');
	// Command
	GetOptionString(cmd, tempStr);
	CAddStr(logString, tempStr);
	CAddChar(logString, '\t');
	// Unique tag
	CLongNumToString(uniqueTag, tempStr);
	CAddStr(logString, tempStr);
	CAddChar(logString, '\t');
	// Direction; i=in, o=out. -=processing
	CAddChar(logString, dir);
	CAddChar(logString, '\t');
	// ThreadID
	totThreads = _TotThreads();
	XGetCurrentThread(&threadID);
	if (threadID == gMainThreadID)
		threadID = 0;	// mani thread
	CNumToString(threadID, tempStr);
	CAddStr(logString, tempStr);
	CAddChar(logString, '\t');
	// Tot threads
	CNumToString(totThreads, tempStr);
	CAddStr(logString, tempStr);
	CAddChar(logString, '\t');
	// From
	if (ip_addr)
		CAddStr(logString, ip_addr);
	CAddChar(logString, '\t');
	// Host
	if (host)
		CAddStr(logString, host);
	CAddChar(logString, '\t');
	// Sid
	if (sid)
		CAddStr(logString, sid);
	CAddChar(logString, '\t');
	// appName
	if (appName)
	{	CSubstitute(appName, '\t', ' ');
		CSubstitute(appName, '\r', ' ');
		CSubstitute(appName, '\n', ' ');
		CAddStr(logString, appName);
	}
	CAddChar(logString, '\t');
	// Notes (this must be the last, can be truncated)
	if (notes)
	{	logLen = CLen(logString);
		available = MAX_LOG_STRING - logLen;
		notesLen = CLen(notes);
		if (notesLen > available)
		{	available -= 3;
			CopyBlock(&logString[logLen], notes, available);
			logString[logLen + available] = 0;
			CAddStr(logString, "...");
		}
		else
			CAddStr(logString, notes);
	}
}

//===========================================================================================
void	LogInitRun(void *taskID, long command, char *ip_addr, char *host, char *request, LONGLONG uniqueTag, char *sid)
{
char			logString[MAX_LOG_STRING+1];
//LogModeOptions	mode;

	XThreadsEnterCriticalSection();
	/*if (command)
	{	switch(command)
		{	case kFlush:
				mode = kFlushLogMode;
				break;
			case kReload:
				mode = kReloadLogMode;
				break;
			case kQuit:
				mode = kQuitLogMode;
				break;
			case kGetVersion:
				mode = kGetVersionLogMode;
				break;
			case kCheck:
				mode = kCheckLogMode;
				break;
			default:
				mode = kUnknownLogMode;
				break;
		}
	}
	else
		mode = kInLogMode;*/
	if NOT(command)
		command = kRequest;
	FormatLogString(logString, command, 'i', ip_addr, host, request, uniqueTag, sid, nil);
	HTTPControllerLog(taskID, logString);
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
/*void	LogInitRun(void *taskID, long command, char *ip_addr, char *host, LogFullRequestCallBack _logFullRequest, long logFullRequestData)
{
CStr255			aCStr, tempStr;
unsigned long	threadID;

	XThreadsEnterCriticalSection();	
	// task id
	XGetCurrentThread(&threadID);
	CNumToString(threadID, tempStr);
	CEquStr(aCStr, "Thread ");
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, " (out of ");
	CNumToString(_TotThreads(), tempStr);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, ") START at ");
	XCurrentDateTimeToString(tempStr, kWantDate);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, " ");
	XCurrentDateTimeToString(tempStr, kWantHour+kWantSecs+kLeadingZeros);
	CAddStr(aCStr, tempStr);
	HTTPControllerLog(taskID, aCStr);
	if (command)
	{	CEquStr(aCStr, "Command: ");
		switch(command)
		{	case kFlush:
				CAddStr(aCStr, "Flush");
				break;
			case kReload:
				CAddStr(aCStr, "Reload");
				break;
			case kQuit:
				CAddStr(aCStr, "Quit");
				break;
			case kGetVersion:
				CAddStr(aCStr, "GetVersion");
				break;
			case kCheck:
				CAddStr(aCStr, "Check");
				break;
			default:
				sprintf(aCStr, "Unknown (%d)", (int)command);
				break;
		}
		HTTPControllerLog(taskID, aCStr);
	}
	else
	{	//_GetHTTPString(&httpRecordP->ip_addr, httpRecordP->startP, tempStr);
		CEquStr(aCStr, "From ");
		CAddStr(aCStr, ip_addr);
		//_GetHTTPString(&httpRecordP->host, httpRecordP->startP, tempStr);
		CAddStr(aCStr, " to ");
		CAddStr(aCStr, host);
		HTTPControllerLog(taskID, aCStr);
		_logFullRequest(taskID, logFullRequestData);
		//_LogElem(taskID, httpRecordP, &httpRecordP->full_request);
	}
	HTTPControllerLog(taskID, "");
	XThreadsLeaveCriticalSection();
}*/

//===========================================================================================
void 	LogExitRun(void *taskID, char *ip_addr, char *host, char *response, LONGLONG uniqueTag, char *sid, char *appName)
{
char			logString[MAX_LOG_STRING+1];

	XThreadsEnterCriticalSection();	
	FormatLogString(logString, kRequest, 'o', ip_addr, host, response, uniqueTag, sid, appName);
	HTTPControllerLog(taskID, logString);
	XThreadsLeaveCriticalSection();	
}

//===========================================================================================
XErr	LogFormatted(void *taskID, LONGLONG uID, char *sid, char *strLog, char *appName)
{
XErr		err = noErr;
char		logString[MAX_LOG_STRING+1];
char		message[MAX_LOG_STRING+1];

	XThreadsEnterCriticalSection();
	CEquStrCK(message, strLog, MAX_LOG_STRING);
	CSubstitute(message, '\r', ' ');
	CSubstitute(message, '\n', ' ');
	FormatLogString(logString, kMessage, '-', "", "", message, uID, sid, appName);
	err = HTTPControllerLog(taskID, logString);
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
/*void 	LogExitRun(void *taskID)
{
CStr255			aCStr, tempStr;
unsigned long	threadID;

	XThreadsEnterCriticalSection();	
	// task id
	XGetCurrentThread(&threadID);
	CNumToString(threadID, tempStr);
	CEquStr(aCStr, "Thread ");
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, " (out of ");
	CNumToString(_TotThreads(), tempStr);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, ") END at ");
	// date time "FINISHED"
	XCurrentDateTimeToString(tempStr, kWantDate);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, " ");
	XCurrentDateTimeToString(tempStr, kWantHour+kWantSecs+kLeadingZeros);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, "");
	HTTPControllerLog(taskID, aCStr);
	
	HTTPControllerLog(taskID, "");
	XThreadsLeaveCriticalSection();	
}*/

//===========================================================================================
static	Boolean _IsCookieHead(char **headerPPtr, long *headerLenP)
{
Boolean		res = false;
int			ch;
char		*headerP;
long		headerLen;

	if (headerLen = *headerLenP)
	{	headerP = *headerPPtr;
		SkipSpaceAndTab(&headerP, &headerLen);
		if ((headerLen > 7) && 
				(((ch = *headerP++) == 'C') || (ch == 'c')) && 
				(((ch = *headerP++) == 'O') || (ch == 'o')) && 
				(((ch = *headerP++) == 'O') || (ch == 'o')) &&
				(((ch = *headerP++) == 'K') || (ch == 'k')) && 
				(((ch = *headerP++) == 'I') || (ch == 'i')) && 
				(((ch = *headerP++) == 'E') || (ch == 'e')) && 
				(*headerP++ == ':'))
			{
				headerLen -= 7;
				SkipSpaceAndTab(&headerP, &headerLen);
				res = true;
			}
			else
			{	headerLen -= (headerP - *headerPPtr);
				// Skip until CR
				while (headerLen && NOT(IsNewLineExt(&headerP, &headerLen, nil)))
				{	headerP++;
					headerLen--;
				}
			}
		*headerLenP = headerLen;
		*headerPPtr = headerP;
	}

return res;
}

//===========================================================================================
static Boolean	_GetCookieValue(char *dataP, long dataLen, char *cookieValue)
{
XErr		err = noErr;
long		len;
char		*saveP;
Boolean		found = true;

	SkipSpaceAndTab(&dataP, &dataLen);
	if (dataLen)
	{	do {
			saveP = dataP;
			if ((dataLen > 12) && 
					(*dataP++ == 'B') && 
					(*dataP++ == 'I') && 
					(*dataP++ == 'F') &&
					(*dataP++ == 'E') && 
					(*dataP++ == 'R') && 
					(*dataP++ == 'N') && 
					(*dataP++ == 'O') && 
					(*dataP++ == '_') && 
					(*dataP++ == 'S') && 
					(*dataP++ == 'I') && 
					(*dataP++ == 'D') && 
					(*dataP++ == '='))
				{
					dataLen -= 12;
					SkipSpaceAndTab(&dataP, &dataLen);
					saveP = dataP;
					while ((dataLen > 0) && NOT(IsNewLine(dataP, dataLen, nil)) && (*dataP != ';'))
					{	dataP++;
						dataLen--;
					}
					len = dataP - saveP;
					if (len > 255)
						len = 255;
					CopyBlock(cookieValue, saveP, len);
					cookieValue[len] = 0;
					break;
				}
				else
				{	dataLen -= (dataP - saveP);
					// Skip until next cookie
					do {	
						if (IsNewLineExt(&dataP, &dataLen, nil))
						{	found = false;
							break;
						}
						else if (*dataP == ';')
						{	dataP++;
							dataLen--;
							SkipSpaceAndTab(&dataP, &dataLen);
							break;
						}
						else
						{	dataP++;
							dataLen--;
						}
					} while (dataLen > 0);
				}
			} while (found && (dataLen > 0) && NOT(err));
	}

return found;
}

//===========================================================================================
void GetCookieSID(char *headerP, long headerLen, char *cookieSID)
{
XErr		err = noErr;

	*cookieSID = 0;
	if (headerLen)
	{	do {
			if (_IsCookieHead(&headerP, &headerLen))
			{	if (_GetCookieValue(headerP, headerLen, cookieSID))		// found!
					break;
			}
		} while ((headerLen > 0) && NOT(err));
	}
}
