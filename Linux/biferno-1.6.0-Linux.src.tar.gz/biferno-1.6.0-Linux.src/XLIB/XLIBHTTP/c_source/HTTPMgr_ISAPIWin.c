/*	
 |
 |	Biferno Web Script Language
 |
 |______________________________________________________________________________
 |	Biferno is a new generation, Cross Platform Web Scripting Language 
 |	that allows developers the rapid implementation of dynamic Web applications 
 |	and of Web sites that offer a high degree of user interactivity. 
 |	
 |	Copyright (C) 2002  Tabasoft Sas 
 |	
 |	This program is free software; you can redistribute it and/or modify 
 |	it under the terms of the GNU General Public License as published by 
 |	the Free Software Foundation; either version 2 of the License, or 
 |	(at your option) any later version. 
 |	
 |	This program is distributed in the hope that it will be useful, 
 |	but WITHOUT ANY WARRANTY; without even the implied warranty of 
 |	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 |	GNU General Public License for more details. 
 |	
 |	You should have received a copy of the GNU General Public License 
 |	along with this program; if not, write to the Free Software 
 |	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 |______________________________________________________________________________
 |
 |	$Id: HTTPMgr_ISAPIWin.c,v 1.12 2008-09-19 13:29:07 tabasoft Exp $
 |______________________________________________________________________________
 */
/*
 Biferno ISAPI
 Tabasoft 2002
 */
#include <windows.h>
#include <httpext.h>

#include "HTTPMgr.h"
#include "HTTPMrgNet.h"
#include "XLib.h"
#include "XLibPrivate.h"
//#include "Helpers.h"
//#include "FLog.h"
#include "XThreadsPrivate.h"
#include "BifernoWinRegistry.h"

#include 	<stdio.h>

static	HTTPControllerP		gHttpControllerP;
static	BlockRef			gHttpControllerBlock;
static	XFileRef			gLogRef = 0;
static	CStr255				gServerDirPath;
static	long				gMaxUsers;
//static	unsigned long		gTotThreads = 0;
static	long				gsBifernoPort, gsBifernoCtlPort;
static	CStr255				gsBifernoHome;

BOOL	WINAPI	DllMain(IN HINSTANCE hinstDll, IN DWORD fdwReason, IN LPVOID lpvContext OPTIONAL);
BOOL	WINAPI	GetExtensionVersion (HSE_VERSION_INFO * pver);
DWORD	WINAPI	HttpExtensionProc(EXTENSION_CONTROL_BLOCK * pecb);

#ifdef MODULE_FULL
//===========================================================================================
static XErr	_Register(void)
{
	XErr				err = noErr;
	
	if NOT(gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err))
		return err;
	gHttpControllerP = (HTTPControllerP)GetPtr(gHttpControllerBlock);
	ClearBlock(gHttpControllerP, sizeof(HTTPController));
	err = HTTPControllerRegister(gHttpControllerP);
	
	return err;
}
#endif

//===========================================================================================
static XErr	_Initialize(void)
{
	XErr		err, saveErr;
	char 		pszCurDir[256];
	CStr255		logFilePath;
	char		*strP;
	
	gsBifernoPort = gsBifernoCtlPort = *gsBifernoHome = 0;
	GetLongKey(BIFERNO_PORT_KEYNAME, &gsBifernoPort);
	// Biferno port
	if NOT(gsBifernoPort)
		gsBifernoPort = BIFERNO_WIN_PORT;
	// Biferno Ctl Sentinel port
	GetLongKey(BIFERNO_CTL_PORT_KEYNAME, &gsBifernoCtlPort);
	if NOT(gsBifernoCtlPort)
		gsBifernoCtlPort = BIFERNO_SENTINEL_WIN_PORT;
	// Biferno Home
	//GetStringKey(BIFERNO_HOME_KEYNAME, gsBifernoHome);
	
	//if (*gsBifernoHome)
	if (GetBifernoHome(gsBifernoHome))
		CEquStr(logFilePath, gsBifernoHome);
	else
	{	// get the location of the DLL
		GetModuleFileName(GetModuleHandle("BifernoISAPI.dll"), pszCurDir, 255);
		FilePathWin32ToXLib(pszCurDir);
		CEquStr(logFilePath, pszCurDir);
		if (strP = strrchr(logFilePath, '/'))
			*strP = 0;
	}
	if NOT(err = XInit(logFilePath))
	{	
#ifdef MODULE_FULL
		err = _Register();
#endif
		if NOT(err)
		{	CAddStr(logFilePath, "/bifernoISAPI.log");
			if (err = InitLog(logFilePath, &gLogRef))
			{	saveErr = err;
				CEquStr(logFilePath, "/C/bifernoISAPI.log");	// folder protect?
				if (err = InitLog(logFilePath, &gLogRef))
				{	// if err don't log (but continue)
					gLogRef = 0;
					err = noErr;
				}
				else
				{	sprintf(logFilePath, "Log in BifernoHome failed: %d\r\n", saveErr);
					CStringToLog(gLogRef, logFilePath, true);
				}	
			}
#ifdef MODULE_FULL
			if NOT(err)
			{	CStr255		errMessage;
				
				gMaxUsers = 32;
				if (gHttpControllerP->Init)
					err = gHttpControllerP->Init(0, &gMaxUsers, false, errMessage);
			}
#endif
		}
	}
	
	return err;
}

//===========================================================================================
static void	_Terminate(void)
{
	XErr	err = noErr, err2 = noErr;
	
#ifdef MODULE_FULL
	if (gHttpControllerP->ShutDown)
		err = gHttpControllerP->ShutDown(0);
#endif
	
	if (gLogRef)
		err2 = EndLog(&gLogRef);
	if (NOT(err) && err2)
		err = err2;
	
	err2 = XEnd(0);
	if (NOT(err) && err2)
		err = err2;
}

//===========================================================================================
static XErr	_GetBlockParam(void *taskID, char *whichStr, BlockRef *blockP, long *lenP)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	HCONN						hConn = theECBP->ConnID;
	unsigned long				descrSize;
	XErr						err = noErr;
	Ptr							buffP = nil;
	BlockRef					block = 0;
	
	descrSize = 2048;
	if (block = NewPtrBlock(descrSize + 1, &err, &buffP))
	{	//buffP = GetPtr(block);
		if NOT(theECBP->GetServerVariable(hConn, whichStr, buffP, &descrSize))
		{	err = XWinGetLastError();
			if (err == ERROR_INSUFFICIENT_BUFFER)
			{	if NOT(err = SetBlockSize(block, descrSize))
			{	buffP = GetPtr(block);
				if NOT(theECBP->GetServerVariable(hConn, whichStr, buffP, &descrSize))
					err = XWinGetLastError();
			}
			}
		}
	}
	if (err)
	{	if (block)
		DisposeBlock(&block);
		*blockP = nil;
	}	
	else
	{	if (lenP)
		*lenP = descrSize - 1;	// has the 0-final
		*blockP = block;
	}
	
	return err;
}

//===========================================================================================
static XErr	_GetStringParam(void *taskID, char *whichStr, char *string, long maxStorage)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	HCONN						hConn = theECBP->ConnID;
	XErr						err = noErr;
	unsigned long				uLong = maxStorage;
	
	if (theECBP->GetServerVariable(hConn, whichStr, string, &uLong))
	{	string[uLong] = 0;
		err = noErr;
	}
	else
		err = XWinGetLastError();
	
	if (err == ERROR_INVALID_INDEX)
	{	*string = 0;
		err = noErr;
	}
	
	return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
BOOL WINAPI DllMain(IN HINSTANCE hinstDll, IN DWORD fdwReason, IN LPVOID lpvContext OPTIONAL)
{
#if __MWERKS__
#pragma unused(hinstDll, lpvContext)
#endif
	BOOL	fReturn = TRUE;
	
	switch(fdwReason)
	{
		case DLL_PROCESS_ATTACH:
			if (_Initialize())
				fReturn = false;
			break;
			
			case DLL_PROCESS_DETACH:
			_Terminate();
			break;
			
			default:
			break;
    }
	
    return ( fReturn);
}

//===========================================================================================
BOOL WINAPI	GetExtensionVersion(HSE_VERSION_INFO * pver)
{
    pver->dwExtensionVersion = MAKELONG(HSE_VERSION_MINOR, HSE_VERSION_MAJOR);
    strcpy(pver->lpszExtensionDesc, "Biferno ISAPI" );
    return TRUE;
}

// #define	SIMPLE_MESSAGE	"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\nProva di Valerio 4"

//====================================================================
static long 	_FilterFunc(DWORD dwExceptionCode)
{
	long	lRet;
	
	switch(dwExceptionCode)
	{	
		case STATUS_STACK_OVERFLOW:
			lRet = EXCEPTION_EXECUTE_HANDLER;
			break;
			
		default:
			lRet = EXCEPTION_CONTINUE_SEARCH;
			break;
	}
	
	return(lRet);
}

#define	SIMPLE_HEADER	"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n"
//===========================================================================================
static void	_HandleErr(void *taskID, XErr err, char *optString, Boolean optOnly)
{					
	//CStr31						errStr;
	CStr255						eNameStr, eMsg;
	char						cLogStr[512];
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	long						errValue, eType;
	unsigned long				theSize;
	HCONN						hConn = theECBP->ConnID;
	
	if (optOnly)
		CEquStr(cLogStr, optString);
	else
	{	
		ErrorGetDescr(err, eNameStr, eMsg);	
		XErrorGetTypeValue(err, &errValue, &eType);
		sprintf(cLogStr, "%sERROR: %d (%s) %s", SIMPLE_HEADER, errValue, eNameStr, eMsg);
		if (optString && *optString)
		{	CAddStr(cLogStr, "<br>");
			CAddStr(cLogStr, optString);
		}
		//if (err == WSAECONNREFUSED)
		//	CAddStr(cLogStr, "<br>(Biferno.exe is down?)");
	}
	theSize = CLen(cLogStr);
	theECBP->WriteClient(hConn, cLogStr, &theSize, 0);
	if (gLogRef)
		CStringToLog(gLogRef, cLogStr, true);
}

//===========================================================================================
static XErr	_RunEvent(HTTPControllerP contP, void *taskID)
{
	XErr		err;
	CStr255		errString;
	Boolean		onlyOpt = false;
	
#ifdef MODULE_FULL
	unsigned long		ourID;
	
	XGetCurrentThread(&ourID);
	if NOT(err = _XThreadsNewTLS(ourID, (long)&err, (1024L * 1024L * 1L)))	// 1MB is correct? Boh?
	{	
		err = contP->Run(taskID, true);
		_XThreadsDisposeTLS(ourID, nil);
	}
#else
#if __MWERKS__
#pragma unused(contP)
#endif
	
	err = ClientRun(taskID, gsBifernoPort, nil, errString, CLIENT_RUN_TIMEOUT);
	if ((err == WSAECONNREFUSED) || (err == WSAETIMEDOUT))
	{	
		BlockRef	block, serverResponse = 0;
		long		tLen, serverResponseLen;
		XErr		err2 = noErr;
		CStr255		aCStr;
		Ptr			p;
		
		CEquStr(aCStr, "check biferno");
		tLen = CLen(aCStr);
		if (block = NewBlockLocked(sizeof(long) + tLen, &err2, &p))
		{	// prefix length
			*(long*)p = XHostToNetwork(tLen);
			CopyBlock(p + sizeof(long), aCStr, tLen);
			if (err2 = XClientCall("", gsBifernoCtlPort, block, 4 + tLen, &serverResponse, &serverResponseLen, nil, aCStr, nil, 0, CLIENT_RUN_TIMEOUT, EXPECT_PREFIXED))
				;//CEquStr(errString, " (and no BifernoCtl)");
			if (serverResponse)
				DisposeBlock(&serverResponse);
			DisposeBlock(&block);
			if (err == WSAECONNREFUSED)
			{	if NOT(err2)
			{	unsigned long 	t, lastTicks, startTicks, checkPeriod;
				
				startTicks = lastTicks = XGetTicks();
				checkPeriod = 60 * 4;	// 4 secs
				while (((t = XGetTicks()) - startTicks) < TOTAL_RETRY_TIME)
				{	if ((t - lastTicks) > checkPeriod)
				{	err2 = ClientRun(taskID, gsBifernoPort, nil, errString, CLIENT_RUN_TIMEOUT);
					lastTicks = XGetTicks();
					if NOT(err2)
					{	err = noErr;
						break;
					}
					else if (err2 == WSAECONNREFUSED)
						err2 = noErr;
					else
					{	err = err2;
						break;
					}
				}
				}
			}
			}
			else if (err == WSAETIMEDOUT)
			{	sprintf(errString, "Biferno script still running after socket timed out (%d)", WSAETIMEDOUT);
				onlyOpt = true;
			}
		}	
	}
	
	
#endif
	
	if (err)
		_HandleErr(taskID, err, errString, onlyOpt);
	return err;
}

//===========================================================================================
DWORD WINAPI HttpExtensionProc(EXTENSION_CONTROL_BLOCK * pecb)
{
	HCONN			hConn = pecb->ConnID;
	XErr			err;
	HTTPControllerP	contP = gHttpControllerP;
	CStr255			aCStr;
	unsigned long	threadID;
	
	XGetCurrentThread(&threadID);
	
	sprintf(aCStr, "Entering thread: %d%s", threadID, EOL_STRING);
	HTTPControllerLog(pecb, aCStr);
	
#ifdef __VISUALCPP__
	__try
	{
		err = _RunEvent(contP, pecb);
	}
	__except(_FilterFunc(GetExceptionCode()))
	{
		HTTPControllerLog(pecb, "Exception catched!");
		err = -1;
	}
#else
	err = _RunEvent(contP, (long)pecb);
#endif
    
	sprintf(aCStr, "Exiting thread: %d (err=%d)%s", threadID, err, EOL_STRING);
	HTTPControllerLog(pecb, aCStr);
	
	return HSE_STATUS_SUCCESS;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr 	HTTPControllerGetServerParam(void *taskID, long which, char *cstr, long *numP)
{
#if __MWERKS__
#pragma unused(numP)
#endif
	XErr		err = noErr;
	//CStr255		aStr;
	
	switch(which)
	{	case kServerDomain:
			err = _GetStringParam(taskID, "SERVER_NAME", cstr, STR_MAXLEN);
			break;
			/*case kServerPort:
			 if NOT(err = _GetStringParam(taskID, "SERVER_PORT", aStr, STR_MAXLEN))
			 CStringToNum(aStr, numP);
			 break;
			 case kServerDirectoryPath:
			 break;
			 case kServerVersionNumber:
			 break;
			 case kServerTotalConnections:
			 break;
			 case kServerCurrentUserLevel:
			 break;
			 case kServerHighestUserLevel:
			 break;
			 case kServerCurrentFreeMemory:
			 break;
			 case kServerMinimumFreeMemory:
			 break;
			 case kServerTotalConnTimeouts:
			 break;
			 case kServerTotalConBusies:
			 break;
			 case kServerTotalConDenied:
			 break;
			 case kServerTotalBytesSent:
			 break;
			 case kServerUpSinceDate:
			 break;
			 case kServerErrorFile:
			 break;*/
		default:
			return -1;
	}
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetIPAddress(void *taskID, char *ipAddress)
{	
	return _GetStringParam(taskID, "REMOTE_HOST", ipAddress, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetAddress(void *taskID, char *address)
{	
	return _GetStringParam(taskID, "REMOTE_ADDR", address, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetPathArgs(void *taskID, char *pathargs)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	XErr						err = noErr;
	
	if (CLen(theECBP->lpszPathInfo) < STR_MAXLEN)
		CEquStr(pathargs, theECBP->lpszPathInfo);
	else
		err = -1;
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetPhysURL(void *taskID, BlockRef *blockP, long *lenP)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	XErr						err = noErr;
	Ptr							buffP;
	
	*lenP = CLen(theECBP->lpszPathTranslated);
	if (*blockP = NewPtrBlock(*lenP + 1 + 4, &err, &buffP))
	{	//buffP = GetPtr(*blockP);
		CEquStr(buffP, theECBP->lpszPathTranslated);
		FilePathWin32ToXLib(buffP);
	}
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetPostArgs(void *taskID, BlockRef *postHP, long *postLen)
{
	unsigned long				bytesRead, descrSize, sizeOfBuffP, remaining;
	XErr						err = noErr;
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	HCONN						hConn = theECBP->ConnID;
	Ptr							saveBuffP, buffP = nil;
	BlockRef					block = 0;
	
	descrSize = theECBP->cbTotalBytes;
	sizeOfBuffP = descrSize + 1;
	if (block = NewPtrBlock(sizeOfBuffP, &err, &saveBuffP))
	{	buffP = saveBuffP;// = GetPtr(block);
		ClearBlock(buffP, sizeOfBuffP);
		CopyBlock(buffP, theECBP->lpbData, theECBP->cbAvailable);
		buffP += theECBP->cbAvailable;
		if (remaining = (theECBP->cbTotalBytes - theECBP->cbAvailable))
		{	sizeOfBuffP -= theECBP->cbAvailable;
			while ((remaining > 0) && NOT(err))
			{	bytesRead = remaining;
				if (theECBP->ReadClient(hConn, buffP, &bytesRead))
				{	buffP += bytesRead;
					remaining -= bytesRead;
					sizeOfBuffP -= bytesRead;
				}
				else
					err = XWinGetLastError();
			}
		}
		*buffP = 0;
	}
	
	if (err)
	{	if (block)
		DisposeBlock(&block);
		*postHP = nil;
		*postLen = 0;
	}	
	else
	{	*postHP = block;
		*postLen = theECBP->cbTotalBytes;
	}	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetSearchArgs(void *taskID, BlockRef *searchHP, long *searchLen)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	XErr						err = noErr;
	Ptr							buffP;
	
	*searchLen = CLen(theECBP->lpszQueryString);
	if (*searchHP = NewPtrBlock(*searchLen + 1, &err, &buffP))
	{	//buffP = GetPtr(*searchHP);
		CEquStr(buffP, theECBP->lpszQueryString);
	}
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetServerDir(void *taskID, char *serverDir)
{
	CStr255		url;
	int			urlLen, serverDirLen;
	XErr		err = noErr;
	
	if NOT(err = _GetStringParam(taskID, "URL", url, STR_MAXLEN))
	{	if NOT(err = _GetStringParam(taskID, "PATH_TRANSLATED", serverDir, STR_MAXLEN))
	{	FilePathWin32ToXLib(serverDir);
		serverDirLen = CLen(serverDir);
		urlLen = CLen(url);
		serverDir[serverDirLen-urlLen+1] = 0;
	}
	}
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetServerName(void *taskID, char *serverName)
{	
	return _GetStringParam(taskID, "SERVER_SOFTWARE", serverName, STR_MAXLEN);
}

//===========================================================================================
static	XErr	_EncodeSpecial(char *textP, long *textLenP, BlockRef *urlEncodedP)
{
	XErr		err = noErr;
	
	return _EncodeESA((Byte*)textP, *textLenP, urlEncodedP, textLenP, false, nil, LIGHT_ENCODE);
	
	return err;
}

//===========================================================================================
// Must compose something like: "GET /bfr/index.bfr HTTP/1.1\r\n" + [ALL_RAW]
XErr	HTTPControllerGetFullRequest(void *taskID, BlockRef *blockP, long *lenP)
{
	unsigned long				methLen, urlLen = 255, protocolLen = 255;
	long						aLong;
	CStr255						theURL, protocol;
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	HCONN						hConn = theECBP->ConnID;
	unsigned long				firstLineLen, descrSize;
	XErr						err = noErr;
	Ptr							buffP = nil;
	BlockRef					urlEncoded = 0, block = 0;
	long						searchLen;
	char						*theURLPtr;
	int							pointSize;
	
	// Method
	methLen = CLen(theECBP->lpszMethod);
	// URL
	if (theECBP->GetServerVariable(hConn, "URL", theURL, &urlLen))
		theURL[--urlLen] = 0;
	else
	{	err = XWinGetLastError();
		goto out;
	}
	aLong = urlLen;
	if (err = _EncodeSpecial(theURL, &aLong, &urlEncoded))
		goto out;
	urlLen = aLong;
	theURLPtr = GetPtr(urlEncoded);
	// Search args
	searchLen = CLen(theECBP->lpszQueryString);
	if (searchLen)
		pointSize = 1;
	else
		pointSize = 0;
	// Protocol
	if (theECBP->GetServerVariable(hConn, "SERVER_PROTOCOL", protocol, &protocolLen))
		protocol[--protocolLen] = 0;
	else
	{	err = XWinGetLastError();
		goto out;
	}
	descrSize = 2048;	// for ALL_RAW
	firstLineLen = methLen + 1 + urlLen + pointSize + searchLen + 1 + protocolLen + 2;
	if (block = NewPtrBlock(firstLineLen + descrSize + 1, &err, &buffP))
	{	
		//buffP = GetPtr(block);
		CopyBlock(buffP, theECBP->lpszMethod, methLen);
		buffP += methLen;
		*buffP++ = ' ';
		CopyBlock(buffP, theURLPtr, urlLen);
		buffP += urlLen;
		if (searchLen)
		{	*buffP++ = '?';
			CopyBlock(buffP, theECBP->lpszQueryString, searchLen);
			buffP += searchLen;
		}
		*buffP++ = ' ';
		CopyBlock(buffP, protocol, protocolLen);
		buffP += protocolLen;
		*buffP++ = '\r';
		*buffP++ = '\n';
		if NOT(theECBP->GetServerVariable(hConn, "ALL_RAW", buffP, &descrSize))
		{	
			err = XWinGetLastError();
			if (err == ERROR_INSUFFICIENT_BUFFER)
			{	
				if NOT(err = SetBlockSize(block, firstLineLen + descrSize + 1))
				{	
					buffP = GetPtr(block) + firstLineLen;
					if NOT(theECBP->GetServerVariable(hConn, "ALL_RAW", buffP, &descrSize))
						err = XWinGetLastError();
				}
			}
		}
	}
	
out:
	if (urlEncoded)
		DisposeBlock(&urlEncoded);
	if (err)
	{	if (block)
		DisposeBlock(&block);
		*blockP = nil;
	}	
	else
	{	
		if (lenP)
			*lenP = firstLineLen + descrSize - 1;	// descrSize has the 0-final
		*blockP = block;
	}
	return err;
}

//===========================================================================================
XErr HTTPControllerGetProtocol(void *taskID, char *protocol)
{
	CEquStr(protocol, "http");	// unimpl.
	return noErr;
}

//===========================================================================================
XErr HTTPControllerGetPort(void *taskID, uint32_t *portP)
{
	XErr		err = noErr;
	CStr255		aStr;
	
	if NOT(err = _GetStringParam(taskID, "SERVER_PORT", aStr, STR_MAXLEN))
		CStringToNum(aStr, portP);
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetUsername(void *taskID, char *user)
{	
	return _GetStringParam(taskID, "REMOTE_USER", user, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetPassword(void *taskID,char *pass)
{	
	return _GetStringParam(taskID, "AUTH_PASS", pass, STR_MAXLEN);
}

//===========================================================================================
XErr HTTPControllerGetMethod(void *taskID, char *method)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	XErr						err = noErr;
	
	if (CLen(theECBP->lpszMethod) < STR_MAXLEN)
		CEquStr(method, theECBP->lpszMethod);
	else
		err = -1;
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetContentType(void *taskID, char *contentType)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	XErr						err = noErr;
	
	if (CLen(theECBP->lpszContentType) < STR_MAXLEN)
		CEquStr(contentType, theECBP->lpszContentType);
	else
		err = -1;
	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetContentLength(void *taskID, long *contentLengthP)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	XErr						err = noErr;
	
	*contentLengthP = theECBP->cbTotalBytes;
	
	return err;
}

//===========================================================================================
XErr HTTPControllerLogReply(void *taskID, BlockRef bufferH, long len)
{
#if __MWERKS__
#pragma unused(taskID, bufferH, len)
#endif
	return noErr;
}

//===========================================================================================
XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
#if __MWERKS__
#pragma unused(taskID, textP, len)
#endif
	return noErr;
}

//===========================================================================================
void	HTTPControllerSetMonoThread(void *taskID)
{
#if __MWERKS__
#pragma unused(taskID)
#endif
}

//===========================================================================================
void	HTTPControllerSetMultiThread(void *taskID)
{
#if __MWERKS__
#pragma unused(taskID)
#endif
}

//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *outPutStr)
{
	int							len = strlen(outPutStr);
	XErr						err = noErr;
	//LPEXTENSION_CONTROL_BLOCK	theECBP;
	
	if (len)
	{	
		/*if (taskID)
	 {	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	 CEquStr(theECBP->lpszLogData, gHttpControllerP->action);
	 CAddStr(theECBP->lpszLogData, ": ");
	 CAddStr(theECBP->lpszLogData, outPutStr);
	 }*/
		if (gLogRef)
			CStringToLog(gLogRef, outPutStr, true);
	}
	
	return err;
}


//===========================================================================================
static void	skipHeader(void *taskID, Ptr *textPPtr, long *lenP, char *firstLine, long *firstLineLenP)
{
	Ptr			bufferP = *textPPtr;
	long		firstLineLen, bufferLen = *lenP;
	Boolean		first = true;
	
	*firstLine = 0;
	*firstLineLenP = 0;
	if (bufferLen)
	{	
		do {
			if (bufferLen > 1 && *(short*)bufferP == '\r\n')
			{	
				if (first)
				{
					firstLineLen = *lenP - bufferLen;
					if (firstLineLen < 255 && firstLineLen > 0)
					{
						CopyBlock(firstLine, *textPPtr, firstLineLen);
						firstLine[firstLineLen] = 0;
						*firstLineLenP = firstLineLen;
					}
					first = false;
				}
				bufferP += 2;
				bufferLen -= 2;
				if (bufferLen > 1 && *(short*)bufferP == '\r\n')
				{	
					bufferP += 2;
					bufferLen -= 2;
					break;
				}
			}
			else
			{
				bufferP++;
				bufferLen--;
			}
		} while (bufferLen > 0);
	}
	*textPPtr = bufferP;
	*lenP = bufferLen;
}

//===========================================================================================
XErr	HTTPControllerSendReply(void *taskID, BlockRef bufferH, long len)
{
	LPEXTENSION_CONTROL_BLOCK	theECBP = (LPEXTENSION_CONTROL_BLOCK)taskID;
	HCONN						hConn = theECBP->ConnID;
	XErr						err = noErr, err2 = noErr;
	unsigned long				bufferLen, headerLen;
	Ptr							headerP, bufferP;
	HSE_SEND_HEADER_EX_INFO		sendHeaderExInfo;
	CStr255						firstLine;
	long						firstLineLen;
	DWORD						sizeofBuffer;
	int							saveChar;
	char						*statusLineP;

	sizeofBuffer = sizeof(HSE_SEND_HEADER_EX_INFO);
	bufferLen = len;
	bufferP = GetPtr(bufferH);
	
	// send headers
	headerP = bufferP;
	skipHeader(theECBP, &bufferP, &bufferLen, firstLine, &firstLineLen);
	headerP += firstLineLen + 2;
	headerLen = len - bufferLen - firstLineLen - 2;
	saveChar = headerP[headerLen];
	headerP[headerLen] = 0;

	// get status skipping HTTP... protocol
	statusLineP = strchr(firstLine, ' ');
	// statusLineP = firstLine + 9;
	if (statusLineP)
	{
		statusLineP++;	// the space
		sendHeaderExInfo.pszStatus = statusLineP;		// The NULL-terminated string containing the status of the current request.
		sendHeaderExInfo.pszHeader = headerP;			// The NULL-terminated string containing the header to return.
		sendHeaderExInfo.cchStatus = firstLineLen - (statusLineP-firstLine);			// The number of characters in the status code.
		sendHeaderExInfo.cchHeader = headerLen;			// The number of characters in the header.
		if not(CCompareStrings(statusLineP, "200 OK"))
			sendHeaderExInfo.fKeepConn = TRUE;
		else
			sendHeaderExInfo.fKeepConn = FALSE;
		if (theECBP->ServerSupportFunction(hConn, HSE_REQ_SEND_RESPONSE_HEADER_EX, &sendHeaderExInfo, &sizeofBuffer, NULL))
		{	
			// send body
			headerP[headerLen] = saveChar;
			if NOT(theECBP->WriteClient(hConn, bufferP, &bufferLen, 0))
			{
				err = XWinGetLastError();
				if (err == WSAECONNRESET)	// The Client closed connection!
					err = noErr;
			}
		}
		else
			err = XWinGetLastError();
		
		err2 = DisposeBlock(&bufferH);
		if (err2 && NOT(err))
			err = err2;
	}
		
	return err;
}


