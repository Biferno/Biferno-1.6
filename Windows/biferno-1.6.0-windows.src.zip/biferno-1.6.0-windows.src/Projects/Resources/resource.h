//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BifernoCtl.rc
//
#define IDC_MYICON                      2
#define IDD_BIFERNOCTL_DIALOG           102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_BIFERNOCTL                  107
#define IDI_SMALL                       108
#define IDC_BIFERNOCTL                  109

#define IDR_MAINFRAME                   128

#define IDM_BSTART                      32771
#define IDM_BSTOP                       32773
#define IDM_BFLUSH                      32774
#define IDM_BRELOAD                     32775
#define IDM_BVERSION                    32776
#define IDM_CTL_INFO                    32778
#define ID_BIFERNO                      32777
#define IDC_STATIC                      -1

#define IDM_BSTART_BKG                  32780
#define IDM_BREMOVE_BKG                 32781



// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
