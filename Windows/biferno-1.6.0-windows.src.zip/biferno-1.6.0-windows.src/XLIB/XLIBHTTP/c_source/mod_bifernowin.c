/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: mod_bifernowin.c,v 1.1.1.1 2003-03-25 13:07:42 valfer Exp $
	|______________________________________________________________________________
*/
//#include <unistd.h>

#include	"XLib.h"
#include 	"Helpers.h"

#include	"HTTPMgr.h"
#include	"HTTPMrgNet.h"

static	HTTPControllerP		gHttpControllerP;
static	BlockRef			gHttpControllerBlock;
static	XFileRef			gLogRefNum = 0;

#define _4GIGA		(unsigned long)0xFFFFFFFF

#include "httpd.h"
#include "http_config.h"
#include "http_log.h"

static void	module_init(server_rec *s, pool *p);

static int	module_run(request_rec *r);
static int	module_translate(request_rec *r);

static handler_rec	moduleHandlers[] = 
		{
			{"biferno-handler", module_run},
			{NULL}
		};

module MODULE_VAR_EXPORT	biferno_module = 
		{
			STANDARD_MODULE_STUFF,
			module_init,		// initialization
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			moduleHandlers,		// run
			module_translate,	// URI to filename
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL
		};

enum {
		CONTENT_TYPE = 1,
		USERNAME,
		PASSWORD,
		METHOD,
		PATH_INFO,
		ARGS,
		URI,
		REMOTE_IP,
		HOST_IP,
		AUTH_TYPE,
		FULL_REQUEST
		};


//===========================================================================================
static void	_HandleErr(request_rec *reqP, XErr err)
{					
CStr31		errStr;
CStr255		eNameStr, eMsg;
CStr255		cLogStr;

	reqP->content_type = "text/html";
	ap_send_http_header(reqP);
	ErrorGetDescr(err, eNameStr, eMsg);	
	sprintf(cLogStr, "ERROR: %d (%s) %s", err, eNameStr, eMsg);
	ap_rputs(cLogStr, reqP);
}

//===========================================================================================
static void	_DoLog(char *outPutStr)
{
#ifdef __LOG__
	if (gLogRefNum)
		CStringToLog(gLogRefNum, outPutStr);
#endif
}

//===========================================================================================
static int _table_callback(void *data, const char *key, const char *val)
{
long	id = (long)data;
XErr	err;

	if NOT(err = BufferAddCString(id, key, NO_ENC, 0))
	{	if NOT(err = BufferAddCString(id, ": ", NO_ENC, 0))
		{	if NOT(err = BufferAddCString(id, val, NO_ENC, 0))
				err = BufferAddCString(id, "\r\n", NO_ENC, 0);
		}
	}

if (err)
	return false;
else
	return true;
}

//===========================================================================================
static XErr	_FullRequest(request_rec *reqP, BlockRef *blockRefP, long *sizeP)
{
XErr	err;
long	id;

	*blockRefP = nil;
	if (id = BufferCreate(255, &err))
	{	if NOT(err = BufferAddCString(id, reqP->the_request, NO_ENC, 0))
		{	if NOT(err = BufferAddCString(id, "\r\n", NO_ENC, 0))
			{	ap_table_do(_table_callback, (void*)id, reqP->headers_in, NULL);
				if NOT(err = BufferAddCString(id, "\r\n", NO_ENC, 0))
					err = BufferAddChar(id, 0);
				if (err)
					BufferFree(id);
				else
				{	*blockRefP = BufferGetBlockRef(id, sizeP);
					(*sizeP)--;	// 0-final
					BufferClose(id);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr _GetPostArgs(request_rec *r, BlockRef *postHP, long *postLen)
{
XErr			err = noErr;
int				rc;

	*postHP = nil;
	*postLen = 0;
	_DoLog("REQUEST_CHUNKED_ERROR");
	if ((rc = ap_setup_client_block(r, REQUEST_CHUNKED_ERROR)) != OK)
	{	_DoLog("ap_setup_client_block failed");
		return rc;
	}
	
	_DoLog("ap_should_client_block");
	if (ap_should_client_block(r))
	{	char	argsbuffer[HUGE_STRING_LEN];
		int		rsize, len_read, rpos = 0;
		long	length = r->remaining;
		
		_DoLog("_GetPostArgs: NewBlock");
		if (*postHP = NewBlock(length + 1, &err))
		{	char	*rbuf = GetPtr(*postHP);
			
			ap_hard_timeout("_GetPostArgs", r);
			while ((len_read = ap_get_client_block(r, argsbuffer, sizeof(argsbuffer))) > 0)
			{	ap_reset_timeout(r);
				if ((rpos + len_read) > length)
					rsize = length - rpos;
				else
					rsize = len_read;
				_DoLog("_GetPostArgs: CopyBlock");
				CopyBlock(rbuf + rpos, argsbuffer, rsize);
				rpos += rsize;
			}
			ap_kill_timeout(r);
			if NOT(err)
				*postLen = length;
		}
	}

_DoLog("_GetPostArgs ok");
return err;
}

//===========================================================================================
static XErr	_AddIntToList(long dlRef, char *name, long index)	
{
XErr	err = noErr;

	DLM_NewObj(dlRef, name, nil, 0, index, kFixedSize, &err);
	return err;
}

//===========================================================================================
/*static XErr	_InitCgiParamList(long *cgiParamListP)
{
XErr			err = noErr;
long			cgiParamList;

	*cgiParamListP = 0;
	if NOT(err = DLM_Create(&cgiParamList, NAME_LIST, false))
	{
		//if (err = _AddIntToList(cgiParamList, "\pusername", REMOTE_USER))
		//	goto out;
		//if (err = _AddIntToList(cgiParamList, "password", AUTH_PASS))
		//	goto out;
		//if (err = _AddIntToList(cgiParamList, "searchargs", QUERY_STRING))
		//	goto out;
		if (err = _AddIntToList(cgiParamList, "contenttype", CONTENT_TYPE))
			goto out;
		if (err = _AddIntToList(cgiParamList, "fullrequest", FULL_REQUEST))
			goto out;
	}
	
out:
if (err)
{	if (cgiParamList)
		DLM_Dispose(&cgiParamList, nil, 0);
}
else
	*cgiParamListP = cgiParamList;
return err;
}*/

//===========================================================================================
static XErr	_EmptyBLock(BlockRef *blockP)
{	
Ptr		p;
XErr	err = noErr;
	
	if (*blockP = NewBlock(1, &err))
	{	p  = GetPtr(*blockP);
		*p = 0;
	}

return err;
}

//===========================================================================================
/*static int _table_callback(void *data, const char *key, const char *val)
{
long	id = (long)data;
XErr	err;

	if NOT(err = BufferAddCString(id, key, NO_ENC, 0))
	{	if NOT(err = BufferAddCString(id, ": ", NO_ENC, 0))
		{	if NOT(err = BufferAddCString(id, val, NO_ENC, 0))
				err = BufferAddCString(id, "\r\n", NO_ENC, 0);
		}
	}

if (err)
	return false;
else
	return true;
}

//===========================================================================================
static XErr	_FullRequest(request_rec *reqP, BlockRef *blockRefP, long *sizeP)
{
XErr	err;
long	id;

	*blockRefP = nil;
	if (id = BufferCreate(255, &err))
	{	if NOT(err = BufferAddCString(id, reqP->the_request, NO_ENC, 0))
		{	if NOT(err = BufferAddCString(id, "\r\n", NO_ENC, 0))
			{	ap_table_do(_table_callback, (void*)id, reqP->headers_in, NULL);
				if NOT(err = BufferAddCString(id, "\r\n", NO_ENC, 0))
					err = BufferAddChar(id, 0);
				if (err)
					BufferFree(id);
				else
				{	*blockRefP = BufferGetBlockRef(id, sizeP);
					(*sizeP)--;	// 0-final
					BufferClose(id);
				}
			}
		}
	}
	
return err;
}*/

//===========================================================================================
static XErr	_StrFromIndex(request_rec *reqP, long index, BlockRef *blockP, long *lenP)
{
const char	*strP = nil;
long		len;
XErr		err = noErr;

	switch(index)
	{
		case CONTENT_TYPE:
			strP = ap_table_get(reqP->headers_in, "Content-Type");
			// ex: strP = reqP->content_type;
			break;
		case USERNAME:
			strP = reqP->connection->user;
			break;
		case PASSWORD:
			// xx
			break;
		case METHOD:
			strP = reqP->method;
			break;
		case PATH_INFO:
			strP = reqP->path_info;
			break;
		case ARGS:
			strP = reqP->args;
			break;
		case URI:
			strP = reqP->uri;
			break;
		case REMOTE_IP:
			strP = reqP->connection->remote_ip;
			break;
		case HOST_IP:
			strP = reqP->connection->remote_host;
			break;
		case AUTH_TYPE:
			// strP = reqP->connection->auth_type;
			break;
		case FULL_REQUEST:
			return _FullRequest(reqP, blockP, &len);
			break;
	}
	
	if (strP)
	{	len = CLen(strP);
		if (*blockP = NewBlock(len + 1, &err))
		{	CEquStr(GetPtr(*blockP), (char*)strP);
			if (lenP)
				*lenP = len;
		}
	}
	else
	{	if NOT(err = _EmptyBLock(blockP))
		{	if (lenP)
				*lenP = 0;
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	_Register(void)
{
XErr	err = noErr;

	if NOT(gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err))
		return err;
	gHttpControllerP = (HTTPControllerP)GetPtr(gHttpControllerBlock);
	ClearBlock(gHttpControllerP, sizeof(HTTPController));
	err = HTTPControllerRegister(gHttpControllerP);
	
return err;
}*/

//===========================================================================================
/*static XErr	_GetParam(long taskID, char *whichStr, BlockRef *blockP, long *lenP)
{
request_rec		*req = (request_rec*)taskID;
XErr			err = noErr;
long			descrSize;
long			index, id;

	id = DLM_GetObjID(gCGIParamList, whichStr, nil, &index);
	if (id)
	{	
		err = _StrFromIndex((request_rec*)taskID, index, blockP, lenP);
	}
	else
		err = -1;

if (err)
	*blockP = nil;
return err;
}*/

#pragma mark-
//===========================================================================================
static void	module_cleanup(void *data)
{
XErr		err = noErr, err2 = noErr;
CStr255		serverPathCStr, errStr, eMsg;

	if (gHttpControllerP->ShutDown)
		err2 = gHttpControllerP->ShutDown(0);
	if (err2 && NOT(err))
		err = err2;
	
	DisposeBlock(&gHttpControllerBlock);

	if (gHttpControllerBlock)
		DisposeBlock(&gHttpControllerBlock);
	//DLM_Dispose(&gCGIParamList, nil, 0);
	//EndHelpers();
	XEnd();

	if (err)
	{	err2 = ErrorGetDescr(err, errStr, eMsg);
		printf("mod_biferno.so Error in child_end: %s (%s).\n", errStr, eMsg);
		// ap_log_error(APLOG_MARK, APLOG_ERR, s, "mod_biferno.so Error in child_end: %s (%s).", errStr, eMsg);
		exit(0);
	}
}

//===========================================================================================
// it works only when you run httpd -X
static void	catch_segmentation_fault(int signo)
{
	printf("Content-type: text/html\n\n");
	printf("SEGMENTATION FAULT");
	exit(0);
}

#pragma mark-
#define	BIFERNO_ADMIN		"bifernoadmin"
#define	BIFERNO_ADMIN_LEN	12

//===========================================================================================
static int	module_translate(request_rec *r)
{
char		*strP, *uriP;
long		tLen, offset;
Boolean		found;

	if (found = FindStringInText(BIFERNO_ADMIN, BIFERNO_ADMIN_LEN, r->uri, CLen(r->uri), &offset, true, false))
	{	if (strP = getenv("BIFERNOHOME"))
		{	uriP = r->uri + offset - 1;
			tLen = CLen(strP) + 1 + CLen(uriP);
			if (r->filename = ap_palloc(r->pool, tLen))
			{	CEquStr(r->filename, strP);
				CAddChar(r->filename, '/');
				CAddStr(r->filename, uriP);
			}
		}
	}
	else
		return DECLINED;
	
return OK;
}

//===========================================================================================
static int	module_run(request_rec *r)
{
XErr		err = noErr, err2 = noErr;
CStr255		str;
CStr255		errStr, eMsg;

	gHttpControllerP->taskID = (long)r;
	// Qui andrebbe lanciato un thread
	if (gHttpControllerP->Run)
		err = gHttpControllerP->Run((long)r);
	
return OK;
}

//===========================================================================================
static void	module_init(server_rec *s, pool *p)
{
XErr				err = noErr, err2 = noErr;
CStr255				serverPathCStr, errStr, eMsg, logFilePath;
long				maxUsers;

	ap_add_version_component("mod_biferno/1.0");
	if NOT(err = XInit(getenv("BIFERNOHOME")))
	{	if NOT(err = XGetApplicationFolderPath(logFilePath))
		{	CAddStr(logFilePath, "mod_biferno.log");
			if NOT(err = InitLog(logFilePath, &gLogRefNum))
			{	gHttpControllerBlock = 0;			
				gHttpControllerP = (HTTPControllerP)-1L;
				GetXApplicationCurrentDir(serverPathCStr);
				if (gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err))
				{	gHttpControllerP = (HTTPControllerP)GetPtr(gHttpControllerBlock);
					ClearBlock(gHttpControllerP, sizeof(HTTPController));
					if NOT(err = HTTPControllerRegister(gHttpControllerP))
					{	if (gHttpControllerP->Init)
						{	maxUsers= 32;		
							err = gHttpControllerP->Init(0, &maxUsers, serverPathCStr);
						}
					}
				}
			}
		}
	}
	
	if (err)
	{	err2 = ErrorGetDescr(err, errStr, eMsg);
		ap_log_error(APLOG_MARK, APLOG_ERR, s, "mod_biferno.so Error: %s (%s).", errStr, eMsg);
		exit(1);
	}
}

#pragma mark-
//===========================================================================================
/*XErr HTTPControllerGetFileMimeType(long taskID, char *fileMimeType)
{
	*fileMimeType = 0;
	
return noErr;
}*/

//===========================================================================================
/*XErr HTTPControllerIfModifiedSince(long taskID, Boolean *modifiedP)
{
	*modifiedP = false;
	
return noErr;
}*/

//===========================================================================================
XErr 	HTTPControllerGetServerParam(long taskID, long which, char *cstr, long *numP)
{
XErr			err = noErr;
request_rec		*reqP = (request_rec*)taskID;

	if (cstr)
		*cstr = 0;
	if (numP)
		*numP = 0;
	switch(which)
	{	case kServerDomain:
			CEquStr(cstr, ap_get_server_name(reqP));
			break;
		case kServerPort:
			break;
		case kServerDirectoryPath:
			break;
		case kServerVersionNumber:
			break;
		case kServerTotalConnections:
			break;
		case kServerCurrentUserLevel:
			break;
		case kServerHighestUserLevel:
			break;
		case kServerCurrentFreeMemory:
			break;
		case kServerMinimumFreeMemory:
			break;
		case kServerTotalConnTimeouts:
			break;
		case kServerTotalConBusies:
			break;
		case kServerTotalConDenied:
			break;
		case kServerTotalBytesSent:
			break;
		case kServerUpSinceDate:
			break;
		case kServerErrorFile:
			break;
		default:
			return -1;
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetIPAddress(long taskID, char *ipAddress)
{
request_rec	*reqP = (request_rec*)taskID;
char		*strP;

	if (strP = reqP->connection->remote_ip)
		CEquStr(ipAddress, strP);
	else
		*ipAddress = 0;
	
return noErr;
}

//===========================================================================================
XErr HTTPControllerGetAddress(long taskID, char *address)
{
request_rec	*reqP = (request_rec*)taskID;
char		*strP;

	if (strP = reqP->connection->remote_host)
		CEquStr(address, strP);
	else
		*address = 0;

return noErr;
}
//===========================================================================================
XErr HTTPControllerGetPathArgs(long taskID, char *pathArgs)
{
char		*strP;
XErr		err = noErr;
request_rec	*reqP = (request_rec*)taskID;

	if (strP = reqP->path_info)
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(pathArgs, strP);
		else
			err = -1;
	}
	else
		*strP = 0;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetPhysURL(long taskID, BlockRef *blockP, long *lenP)
{
long	len;
char	*strP;
XErr	err = noErr;

	if (strP = ((request_rec*)taskID)->filename)
	{	len = CLen(strP);
		if (*blockP = NewBlock(len + 1, &err))
		{	CEquStr(GetPtr(*blockP), strP);
			*lenP = len;
		}
	}
	else
	{	err = _EmptyBLock(blockP);
		*lenP = 0;
	}
		
return err;
}

#define	DEFAULT_ENC_TYPE	"application/x-www-form-urlencoded"

//===========================================================================================
XErr HTTPControllerGetPostArgs(long taskID, BlockRef *postHP, long *postLen)
{
XErr			err = noErr;
request_rec		*r = (request_rec*)taskID;
int				rc;
unsigned long	postMAX;
unsigned long	clength;

	postMAX = GetPOSTLimit(r->args);
	clength = r->clength;
	if (clength && postMAX && (clength > postMAX))
	{	*postHP = 0;
		*postLen = kInvalidPostLength;
	}
	else
	{	if ((rc = ap_setup_client_block(r, REQUEST_CHUNKED_ERROR)) != OK)
			return rc;
		if (ap_should_client_block(r))
		{	char	argsbuffer[HUGE_STRING_LEN];
			int		rsize, len_read, rpos = 0;
			long	length = r->remaining;
			
			if (*postHP = NewBlock(length + 1, &err))
			{	char	*rbuf = GetPtr(*postHP);
				
				ap_hard_timeout("HTTPControllerGetPostArgs", r);
				while ((len_read = ap_get_client_block(r, argsbuffer, sizeof(argsbuffer))) > 0)
				{	ap_reset_timeout(r);
					if ((rpos + len_read) > length)
						rsize = length - rpos;
					else
						rsize = len_read;
					CopyBlock(rbuf + rpos, argsbuffer, rsize);
					rpos += rsize;
					if (postMAX && (rpos > postMAX))
					{	DisposeBlock(postHP);
						*postHP = 0;
						length = kInvalidPostLength;
						break;
					}
				}
				ap_kill_timeout(r);
				if NOT(err)
					*postLen = length;
				else
				{	DisposeBlock(postHP);
					*postLen = *postHP = 0;
				}
			}
		}
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetSearchArgs(long taskID, BlockRef *searchHP, long *searchLen)
{
XErr	err = noErr;

	err = _StrFromIndex((request_rec*)taskID, ARGS, searchHP, searchLen);

return err;
}

//===========================================================================================
/*XErr HTTPControllerGetSearchArgsString(long taskID, char *searchArgs)
{
request_rec		*reqP = (request_rec*)taskID;
XErr			err = noErr;

	len = CLen(reqP->args);
	if (len > 255)
		len = 255;
	CopyBlock(searchArgs, reqP->args, len);
	searchArgs[len] = 0;

return err;
}*/

//===========================================================================================
XErr	HTTPControllerGetServerDir(long taskID, char *serverDir)
{
//XErr			err = noErr;
//request_rec		*r = (request_rec*)taskID;
//int				dif;
//char			*fileNameP, *uriP;
int		serverDirLen;

	CEquStr(serverDir, ap_document_root((request_rec*)taskID));
	serverDirLen = CLen(serverDir);
	if (serverDir[serverDirLen-1] != '\/')
		CAddChar(serverDir, '\/');
	// CEquStr(serverDir, ap_get_server_name(r));
	
	// CEquStr(serverDir, ap_server_root_relative(r->pool, ""));
	
	/*fileNameP = ((request_rec*)taskID)->filename;
	uriP = ((request_rec*)taskID)->uri;
	dif = CLen(fileNameP) - CLen(uriP);
	if (dif > 0)
	{	CopyBlock(serverDir, fileNameP, dif);
		serverDir[dif] = 0;
	}
	else
		serverDir[0] = 0;*/
	
return noErr;
}

//===========================================================================================
XErr HTTPControllerGetServerName(long taskID, char *serverName)
{
XErr	err = noErr;
char	*strP;

	if (strP = ap_get_server_version())
		CEquStr(serverName, strP);
	else
		*serverName = 0;

return err;
}

//===========================================================================================
XErr	HTTPControllerGetFullRequest(long taskID, BlockRef *blockP, long *lenP)
{
	return _FullRequest((request_rec*)taskID, blockP, lenP);
}


//extern  char ap_server_root[];
//===========================================================================================
XErr HTTPControllerGetUsername(long taskID, char *user)
{
char		*strP;
XErr		err = noErr;
request_rec	*reqP = (request_rec*)taskID;

	if (strP = reqP->connection->user)
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(user, strP);
		else
			*user = 0;
	}
	else
		*user = 0;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetPassword(long taskID, char *pass)
{

char		*strP;
XErr		err = noErr;
request_rec	*reqP = (request_rec*)taskID;

	*pass = 0;
	if NOT(err = ap_get_basic_auth_pw(reqP, &strP))
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(pass, strP);
		else
			*pass = 0;
	}
	else
	{	err = noErr;
		*pass = 0;
	}
	
return err;
}

//===========================================================================================
/*XErr HTTPControllerGetHeaderField(long taskID, char *index, BlockRef *blockP)
{	
char		*headersP;
BlockRef	block;
XErr		err = noErr;


return err;
}*/

//===========================================================================================
XErr HTTPControllerGetMethod(long taskID, char *method)
{
char		*strP;
XErr		err = noErr;
request_rec	*reqP = (request_rec*)taskID;

	if (strP = reqP->method)
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(method, strP);
		else
			err = -1;
	}
	else
		*method = 0;
	
return err;
}

//===========================================================================================
/*XErr	HTTPControllerGetContentLength(long taskID, long *lenP, Ptr thePost)
{
request_rec	*reqP = (request_rec*)taskID;

	*lenP = reqP->clength;

return noErr;
}*/

//===========================================================================================
XErr HTTPControllerGetContentType(long taskID, char *contentType)
{
request_rec	*reqP = (request_rec*)taskID;
XErr		err = noErr;
char		*strP;

	if (strP = ap_table_get(reqP->headers_in, "Content-Type"))
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(contentType, strP);
		else
			*contentType = 0;
	}
	else
		*contentType = 0;
	
return err;
}

//===========================================================================================
XErr 	HTTPControllerGetContentLength(long taskID, long *contentLengthP)
{
request_rec	*reqP = (request_rec*)taskID;

	*contentLengthP = reqP->clength;
	
return noErr;
}

/*//===========================================================================================
XErr	HTTPControllerYield(long taskID, long sleep)
{	
#pragma unused(taskID,sleep)
return noErr;
}

//===========================================================================================
XErr	HTTPControllerRequestIdleTime(long taskID, unsigned long ticksToSleep)
{
#pragma unused(taskID,ticksToSleep)
return noErr;
}
#pragma mark-
//===========================================================================================
Boolean HTTPControllerConnectionClosed(long taskID)
{
#pragma unused(taskID)
return false;
}
//===========================================================================================
XErr HTTPControllerGetConnectionStatus(long taskID, long *statusP)
{
#pragma unused(taskID,statusP)
return noErr;
}
*/
#pragma mark-
//===========================================================================================
XErr	HTTPControllerLog(long taskID, char *outPutStr)
{
	if (gLogRefNum)
		CStringToLog(gLogRefNum, outPutStr);

return noErr;
}
/*//===========================================================================================
long	HTTPControllerGetVersion(long taskID, long *versionP)
{

return noErr;
}
*/
//===========================================================================================
XErr	HTTPControllerLogReply(long taskID, BlockRef bufferBlock, long len)
{
XErr	err = noErr;

return err;
}

//===========================================================================================
XErr	HTTPControllerSendReply(long taskID, BlockRef bufferBlock, long len)
{
XErr		err = noErr;
char		*p;

	if NOT(err = SetBlockSize(bufferBlock, len+1))
	{	if (len)
		{	p = GetPtr(bufferBlock);
			ap_rwrite(p, len, (request_rec*)taskID);
		}
		else
			ap_rputs(" ", (request_rec*)taskID);	// no "Document contains no data", please
		DisposeBlock(&bufferBlock);
	}

return err;
}
