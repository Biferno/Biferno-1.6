/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: mod_biferno.c,v 1.26 2006-10-16 14:25:29 valfer Exp $
	|______________________________________________________________________________
*/
#include	"XLib.h"
#include	"XLibPrivate.h"

#include	"HTTPMgr.h"
#include	"HTTPMrgNet.h"

#include <httpd.h>
#include <http_request.h>
#include <http_config.h>
#include <http_core.h>
#include <http_log.h>
#include <http_main.h>
#include <http_protocol.h>

#if __WIN_XLIB__
	#include "BifernoWinRegistry.h"
#endif

static	XFileRef			gLogRefNum = 0;

#define	BIFERNO_ADMIN		"bifernoadmin"
#define	BIFERNO_ADMIN_LEN	12

//#if AP_MODULE_MAGIC_AT_LEAST(20010224,0)	// * 20010224 (2.0.13-dev) MODULE_MAGIC_COOKIE reset to "AP20"
#if (MODULE_MAGIC_NUMBER_MAJOR >= 20010224)
	#define	API2	1
#else
	#undef 	API2
#endif

#ifdef API2
	#include <ap_compat.h>
	#include <apr.h>
	#include <apr_strings.h>
	static int	module_init(apr_pool_t *pconf, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s);
	static void register_hooks(apr_pool_t *p);
#else
	static void	module_init(server_rec *s, pool *p);
#endif
static int	module_run(request_rec *r);
static int	module_translate(request_rec *r);

#ifdef API2
module MODULE_VAR_EXPORT biferno_module =
{
    STANDARD20_MODULE_STUFF,
    NULL,			/* create per-directory config structures */
    NULL,			/* merge per-directory config structures  */
    NULL,			/* create per-server config structures    */
    NULL,			/* merge per-server config structures     */
    NULL,			/* command handlers */
    register_hooks	/* handlers */
};
#else
static handler_rec	moduleHandlers[] = 
		{
			{"biferno-handler", module_run},
			{NULL}
		};

module MODULE_VAR_EXPORT	biferno_module = 
		{
			STANDARD_MODULE_STUFF,
			module_init,		// initialization
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			moduleHandlers,		// run
			module_translate,	// URI to filename
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL
		};
#endif

enum {
		CONTENT_TYPE = 1,
		USERNAME,
		PASSWORD,
		METHOD,
		PATH_INFO,
		ARGS,
		URI,
		REMOTE_IP,
		HOST_IP,
		AUTH_TYPE,
		FULL_REQUEST
		};

CStr255			gBifernoHomeString;
#if __WIN_XLIB__
	static	long	gsBifernoPort, gsBifernoCtlPort;
#endif

#ifdef API2
enum {
		kSet = 1,
		kAdd,
		kMerge
		};

//===========================================================================================
static int	_getMod(char *hname)
{
int		mode;

	if NOT(CCompareStrings_cs(hname, "Set-Cookie"))
		mode = kAdd;
	else
		mode = kSet;

return mode;
}

//===========================================================================================
static XErr	_filt_one(request_rec* reqP, Ptr headerP, Ptr *itemPPtr, long *itemLenP, Boolean *firstP)
{
Boolean		first = *firstP;
long 		nameLen, itemLen = *itemLenP;
Ptr			itemP = *itemPPtr;
CStr255		name;
XErr		err = noErr;
char		*nameStr, *strP;
int			mod;

	if (first)
	{	first = false;
		CopyBlock(name, itemP, itemLen);
		name[itemLen] = 0;
		strP = strchr(name, ' ');
		reqP->status_line = (const char *)apr_pstrdup(reqP->pool, (const char*)&strP[1]);
		reqP->status = atoi(&strP[1]);
		itemP = headerP;
		itemLen = 0;
	}
	else
	{	if (itemLen)
		{	nameStr = name;
			nameLen = 0;
			do {
				if (itemLen && (*itemP == ':'))
				{	itemP++;
					itemLen--;
					if (itemLen && (*itemP == ' '))
					{	itemP++;
						itemLen--;
					}
					break;
				}
				else if (nameLen < 255)
				{	*nameStr++ = *itemP;
					nameLen++;
				}
				else
					err = -1;
				itemP++;
				itemLen--;
			} while ((itemLen > 0) && NOT(err));
			if NOT(err)
			{	name[nameLen] = 0;
				itemP[itemLen] = 0;
				if NOT(CCompareStrings(name, "Content-Type"))
					reqP->content_type = (char*)apr_pstrdup(reqP->pool, itemP);
				else
				{	mod = _getMod(name);
					switch(mod)
					{
						case kAdd:
							apr_table_add(reqP->headers_out, name, itemP);
							break;
						case kSet:
							apr_table_set(reqP->headers_out, name, itemP);
							break;
						case kMerge:
							apr_table_merge(reqP->headers_out, name, itemP);
							break;
					}
				}
				itemP = headerP;
				itemLen = 0;
			}
		}
	}
	*itemLenP = itemLen;
	*itemPPtr = itemP;
	*firstP = first;

return err;
}

//===========================================================================================
static void	_filter_headers(request_rec* reqP, Ptr *textPPtr, long *lenP)
{
Ptr			headerP = *textPPtr;
long		headerLen = *lenP;
Ptr			itemP;
long		advance, itemLen;
Boolean		first;
XErr		err = noErr;

	if (headerLen)
	{	itemP = headerP;
		itemLen = 0;
		first = true;
		do {
			if (IsNewLine(headerP, headerLen, &advance))
			{	headerP += advance;
				headerLen -= advance;
				if NOT(err = _filt_one(reqP, headerP, &itemP, &itemLen, &first))
				{	if (IsNewLine(headerP, headerLen, &advance))
					{	headerP += advance;
						headerLen -= advance;
						break;
					}
				}
			}
			else
			{	headerP++;
				headerLen--;
				itemLen++;
			}
		} while ((headerLen > 0) && NOT(err));
	}
	
*textPPtr = headerP;
*lenP = headerLen;
}

//===========================================================================================
static void register_hooks(apr_pool_t *p)
{
static const char * const aszPre[]={ "http_core.c", NULL};

	ap_hook_post_config(module_init, NULL, NULL, APR_HOOK_MIDDLE);
	ap_hook_translate_name(module_translate, aszPre, NULL, APR_HOOK_LAST);
	ap_hook_handler(module_run, NULL, NULL, APR_HOOK_MIDDLE);
}
#endif

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static void	_HandleErr(request_rec *reqP, XErr err, char *optString, Boolean onlyOpt)
{					
//CStr31		errStr;
CStr255		eNameStr, eMsg;
char		cLogStr[512];
long		eNum, eType;

	reqP->content_type = "text/html";
	ap_send_http_header(reqP);
	if (onlyOpt)
		CEquStr(cLogStr, optString);
	else
	{	ErrorGetDescr(err, eNameStr, eMsg);	
		XErrorGetTypeValue(err, &eNum, &eType);
		sprintf(cLogStr, "ERROR: %ld (%s) %s", eNum, eNameStr, eMsg);
		if (optString && *optString)
		{	CAddStr(cLogStr, "<br>");
			CAddStr(cLogStr, optString);
		}
	}
	ap_rputs(cLogStr, reqP);
	if (gLogRefNum)
	{	CAddStr(cLogStr, EOL_STRING);
		CStringToLog(gLogRefNum, cLogStr, true);
	}
}

//#define	__LOG__	1
//===========================================================================================
static void	_DoLog(char *outPutStr)
{
#ifdef __LOG__
	if (gLogRefNum)
		CStringToLog(gLogRefNum, outPutStr, true);
#endif
}

//===========================================================================================
static int _table_callback(void *data, const char *key, const char *val)
{
long	id = (long)data;
XErr	err;

	if NOT(err = BufferAddCString(id, (char*)key, NO_ENC, 0))
	{	if NOT(err = BufferAddCString(id, ": ", NO_ENC, 0))
		{	if NOT(err = BufferAddCString(id, (char*)val, NO_ENC, 0))
				err = BufferAddCString(id, "\r\n", NO_ENC, 0);
		}
	}

if (err)
	return false;
else
	return true;
}

//===========================================================================================
static XErr	_FullRequest(request_rec *reqP, BlockRef *blockRefP, long *sizeP)
{
XErr	err;
long	id;

	*blockRefP = nil;
	if (id = BufferCreate(255, &err))
	{	
		if NOT(err = BufferAddCString(id, reqP->the_request, NO_ENC, 0))
		{	if NOT(err = BufferAddCString(id, "\r\n", NO_ENC, 0))
			{	
			#ifdef API2
				apr_table_do(_table_callback, (void*)id, reqP->headers_in, NULL);
			#else
				ap_table_do(_table_callback, (void*)id, reqP->headers_in, NULL);
			#endif
				if NOT(err = BufferAddCString(id, "\r\n", NO_ENC, 0))
					err = BufferAddChar(id, 0);
				if (err)
					BufferFree(id);
				else
				{	*blockRefP = BufferGetBlockRef(id, sizeP);
					(*sizeP)--;	// 0-final
					BufferClose(id);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
/*static inline XErr	_AddIntToList(long dlRef, char *name, long index)	
{
XErr	err = noErr;

	DLM_NewObj(dlRef, name, nil, 0, index, kFixedSize, &err);
	return err;
}

*/
//===========================================================================================
static XErr	_EmptyBLock(BlockRef *blockP)
{	
Ptr		p;
XErr	err = noErr;
	
	if (*blockP = NewBlock(1, &err, &p))
		*p = 0;

return err;
}

//===========================================================================================
static XErr	_StrFromIndex(request_rec *reqP, long index, BlockRef *blockP, long *lenP)
{
const char	*strP = nil;
long		len;
XErr		err = noErr;

	switch(index)
	{
		case CONTENT_TYPE:
		#ifdef API2
			strP = apr_table_get(reqP->headers_in, "Content-Type");
		#else
			strP = ap_table_get(reqP->headers_in, "Content-Type");
		#endif
			break;
		case USERNAME:
		#ifndef API2
			strP = reqP->connection->user;
		#endif
			break;
		case PASSWORD:
			// xx
			break;
		case METHOD:
			strP = reqP->method;
			break;
		case PATH_INFO:
			strP = reqP->path_info;
			break;
		case ARGS:
			strP = reqP->args;
			break;
		case URI:
			strP = reqP->uri;
			break;
		case REMOTE_IP:
			strP = reqP->connection->remote_ip;
			break;
		case HOST_IP:
			strP = reqP->connection->remote_host;
			break;
		case AUTH_TYPE:
			// strP = reqP->connection->auth_type;
			break;
		case FULL_REQUEST:
			return _FullRequest(reqP, blockP, &len);
			break;
	}
	
	if (strP)
	{	Ptr		p;
	
		len = CLen(strP);
		if (*blockP = NewBlock(len + 1, &err, &p))
		{	CEquStr(p, (char*)strP);
			if (lenP)
				*lenP = len;
		}
	}
	else
	{	if NOT(err = _EmptyBLock(blockP))
		{	if (lenP)
				*lenP = 0;
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static int	module_translate(request_rec *r)
{
char		*strP, *uriP;
long		tLen, offset;
Boolean		found;

	strP = gBifernoHomeString;
	if (*strP && (found = FindStringInText(BIFERNO_ADMIN, BIFERNO_ADMIN_LEN, r->uri, CLen(r->uri), &offset, true, false)))
	{	uriP = r->uri + offset - 1;
		tLen = CLen(strP) + 1 + CLen(uriP) + 1;
	#ifdef API2
		r->filename = apr_palloc(r->pool, tLen);
	#else
		r->filename = ap_palloc(r->pool, tLen);
	#endif
		if (r->filename)
		{	CEquStr(r->filename, strP);
			CAddChar(r->filename, '/');
			CAddStr(r->filename, uriP);
		#if __WIN_XLIB__
			FilePathXLibToWin32(r->filename);
		#endif
		}
	}
	else
		return DECLINED;
	
return OK;
}

//===========================================================================================
static int	module_run(request_rec *reqP)
{
XErr		err = noErr;
CStr255		aCStr;
Boolean		onlyOpt = false;

#ifdef API2
	if (CCompareStrings_cs((char*)reqP->handler, "biferno-handler"))
		return DECLINED;
#endif
	
#if __WIN_XLIB__
if (*gBifernoHomeString)
{	
CStr255	errString;

	err = ClientRun((void*)reqP, gsBifernoPort, nil, errString, CLIENT_RUN_TIMEOUT);
	if ((err == WSAECONNREFUSED) || (err == WSAETIMEDOUT))
	{	BlockRef	block, serverResponse = 0;
		long		tLen, serverResponseLen;
		XErr		err2 = noErr;
		CStr255		aCStr;
		Ptr			p;

		CEquStr(aCStr, "check biferno");
		tLen = CLen(aCStr);
		if (block = NewBlockLocked(sizeof(long) + tLen, &err2, &p))
		{	// prefix length
			*(long*)p = XHostToNetwork(tLen);
			CopyBlock(p + sizeof(long), aCStr, tLen);
			if (err2 = XClientCall("", gsBifernoCtlPort, block, 4 + tLen, &serverResponse, &serverResponseLen, nil, aCStr, nil, 0, CLIENT_RUN_TIMEOUT, EXPECT_PREFIXED))
				;//CEquStr(errString, " (and no BifernoCtl)");
			if (serverResponse)
				DisposeBlock(&serverResponse);
			DisposeBlock(&block);
			if (err == WSAECONNREFUSED)
			{	if NOT(err2)
				{	unsigned long 	t, lastTicks, startTicks, checkPeriod;
				
					startTicks = lastTicks = XGetTicks();
					checkPeriod = 60 * 4;	// 4 secs
					while (((t = XGetTicks()) - startTicks) < TOTAL_RETRY_TIME)
					{	if ((t - lastTicks) > checkPeriod)
						{	err2 = ClientRun(reqP, gsBifernoPort, nil, errString, CLIENT_RUN_TIMEOUT);
							lastTicks = XGetTicks();
							if NOT(err2)
							{	err = noErr;
								break;
							}
							else if (err2 == WSAECONNREFUSED)
								err2 = noErr;
							else
							{	err = err2;
								break;
							}
						}
					}
				}
			}
			else if (err == WSAETIMEDOUT)
			{	sprintf(errString, "Biferno script still running after socket timed out (%d)", WSAETIMEDOUT);
				onlyOpt = true;
			}
		}	
	}	
	if (err)
	{	reqP->content_type = "text/html";
		ap_send_http_header(reqP);
		CEquStr(aCStr, errString);
		ap_rputs(aCStr, reqP);
	}
}
else
{	reqP->content_type = "text/html";
	ap_send_http_header(reqP);
	CEquStr(aCStr, "Error: Initialization failed");
	ap_rputs(aCStr, reqP);
}
#else
	if (*gBifernoHomeString)
	{	err = ClientRun((void*)reqP, 0, BIFERNO_UNIX_FILE, aCStr, CLIENT_RUN_TIMEOUT);
		// ENOENT happens when the pipe file doesn't exists (/tmp/biferno.str)
		if ((err == ECONNREFUSED) || (err == EWOULDBLOCK) || (err == ENOENT))
		{	BlockRef	block, serverResponse;
			long		tLen, serverResponseLen;
			XErr		err2 = noErr;
			Ptr			p;
			
			CEquStr(aCStr, "check biferno");
			tLen = CLen(aCStr);
			if (block = NewBlockLocked(sizeof(long) + tLen, &err2, &p))
			{	// prefix length
				*(long*)p = XHostToNetwork(tLen);
				CopyBlock(p + sizeof(long), aCStr, tLen);
				if (err2 = XClientCall("", 0, block, 4 + tLen, &serverResponse, &serverResponseLen, BIFERNOSENTINEL_UNIX_FILE, aCStr, nil, 0, CLIENT_RUN_TIMEOUT, EXPECT_PREFIXED))
					;//CEquStr(aCStr, " (connecting to bifernosentinel)");
				if (serverResponse)
					DisposeBlock(&serverResponse);
				DisposeBlock(&block);
				if ((err == ECONNREFUSED) || (err == ENOENT))
				{	if NOT(err2)
					{	unsigned long 	t, lastTicks, startTicks, checkPeriod;
						
						startTicks = lastTicks = XGetTicks();
						checkPeriod = 60 * 4;	// 4 secs
						while (((t = XGetTicks()) - startTicks) < TOTAL_RETRY_TIME)
						{	if ((t - lastTicks) > checkPeriod)
							{	err2 = ClientRun((void*)reqP, 0L, BIFERNO_UNIX_FILE, aCStr, CLIENT_RUN_TIMEOUT);
								lastTicks = XGetTicks();
								if NOT(err2)
								{	err = noErr;
									break;
								}
								else if ((err2 == ECONNREFUSED) || (err == ENOENT))
									err2 = noErr;
								else
								{	err = err2;
									break;
								}
							}
						}
					}
				}
				else if (err == EWOULDBLOCK)
				{	sprintf(aCStr, "Biferno script still running after socket timed out (%d)", EWOULDBLOCK);
					onlyOpt = true;
				}
			}	
		}
	}
	else
	{	reqP->content_type = "text/html";
		ap_send_http_header(reqP);
		sprintf(aCStr, "Error getting BifernoHome: can't read: %s\n", BIFERNO_HOME_PATH);
		//CEquStr(aCStr, "Error: BifernoHome undefined");
		ap_rputs(aCStr, reqP);
	}
#endif

if (err)
{	if (err == ENOENT)
		sprintf(aCStr, "Biferno is down (file /tmp/biferno.str not found)");
	_HandleErr(reqP, err, aCStr, onlyOpt);
}
return OK;
}

//===========================================================================================
#ifdef API2
	static int	module_init(apr_pool_t *pconf, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s)
#else
	static void	module_init(server_rec *s, pool *p)
#endif
{
XErr		err = noErr, err2 = noErr;
CStr255		serverPathCStr, errStr, eMsg, logFilePath;
char		*strP = nil;

#if __WIN_XLIB__
{
char 		pszCurDir[256];
	
	gsBifernoPort = gsBifernoCtlPort = *gBifernoHomeString = 0;
	GetLongKey(BIFERNO_PORT_KEYNAME, &gsBifernoPort);
	// Biferno port
	if NOT(gsBifernoPort)
		gsBifernoPort = BIFERNO_WIN_PORT;
	// Biferno Ctl Sentinel port
	GetLongKey(BIFERNO_CTL_PORT_KEYNAME, &gsBifernoCtlPort);
	if NOT(gsBifernoCtlPort)
		gsBifernoCtlPort = BIFERNO_SENTINEL_WIN_PORT;
	// Biferno Home
	//GetStringKey(BIFERNO_HOME_KEYNAME, gBifernoHomeString);
	//if NOT(*gBifernoHomeString)
	if NOT(GetBifernoHome(gBifernoHomeString))
	{	// get the location of the DLL
		GetModuleFileName(GetModuleHandle("mod_biferno.so"), pszCurDir, 255);
		FilePathWin32ToXLib(pszCurDir);
		CEquStr(gBifernoHomeString, pszCurDir);
		if (strP = strrchr(gBifernoHomeString, '/'))
			*strP = 0;
	}
	strP = gBifernoHomeString;
}
#else
	if (GetBifernoHome(gBifernoHomeString))
		strP = gBifernoHomeString;
	else
		strP = nil;
	//ex: strP = getenv("BIFERNOHOME");
#endif

	if (strP)
	{	CEquStr(gBifernoHomeString, strP);
		if NOT(err = XInit(gBifernoHomeString))
		{	if NOT(err = XGetApplicationFolderPath(logFilePath))
			{	CAddStr(logFilePath, "mod_biferno.log");
				if (err = InitLog(logFilePath, &gLogRefNum))
				{
				#ifdef API2
					ap_log_error(APLOG_MARK, APLOG_ERR, 0, s, "mod_biferno.so path: %s.", logFilePath);
				#else
					ap_log_error(APLOG_MARK, APLOG_ERR, s, "mod_biferno.so path: %s.", logFilePath);
				#endif	
					err = noErr;
				}	
				_DoLog("InitLog ok");
			}
		}
		sprintf(serverPathCStr, "MODULE_MAGIC_COOKIE:%ld\n", MODULE_MAGIC_COOKIE);	
		_DoLog(serverPathCStr);

		sprintf(serverPathCStr, "err: %d", err);
		_DoLog(serverPathCStr);
		
		if (err)
		{	err2 = ErrorGetDescr(err, errStr, eMsg);
		#ifdef API2
			ap_log_error(APLOG_MARK, APLOG_ERR, 0, s, "mod_biferno.so Error: %s (%s).", errStr, eMsg);
		#else
			ap_log_error(APLOG_MARK, APLOG_ERR, s, "mod_biferno.so Error: %s (%s).", errStr, eMsg);
		#endif	
			exit(1);
		}
		_DoLog("OK XInit");
	}
	else
		*gBifernoHomeString = 0;

#ifdef API2
return APR_SUCCESS;
#endif
}
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr 	HTTPControllerGetServerParam(void *taskID, long which, char *cstr, long *numP)
{
XErr			err = noErr;
request_rec		*reqP = (request_rec*)taskID;

	if (cstr)
		*cstr = 0;
	if (numP)
		*numP = 0;
	switch(which)
	{	case kServerDomain:
			CEquStr(cstr, (char*)ap_get_server_name(reqP));
			break;
		/*case kServerPort:
			break;
		case kServerDirectoryPath:
			break;
		case kServerVersionNumber:
			break;
		case kServerTotalConnections:
			break;
		case kServerCurrentUserLevel:
			break;
		case kServerHighestUserLevel:
			break;
		case kServerCurrentFreeMemory:
			break;
		case kServerMinimumFreeMemory:
			break;
		case kServerTotalConnTimeouts:
			break;
		case kServerTotalConBusies:
			break;
		case kServerTotalConDenied:
			break;
		case kServerTotalBytesSent:
			break;
		case kServerUpSinceDate:
			break;
		case kServerErrorFile:
			break;*/
		default:
			return -1;
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetIPAddress(void *taskID, char *ipAddress)
{
request_rec	*reqP = (request_rec*)taskID;
char		*strP;

	if (strP = reqP->connection->remote_ip)
		CEquStr(ipAddress, strP);
	else
		*ipAddress = 0;
	
return noErr;
}

//===========================================================================================
XErr HTTPControllerGetAddress(void *taskID, char *address)
{
request_rec	*reqP = (request_rec*)taskID;
char		*strP;

	if (strP = reqP->connection->remote_host)
		CEquStr(address, strP);
	else
		*address = 0;

return noErr;
}
//===========================================================================================
XErr HTTPControllerGetPathArgs(void *taskID, char *pathArgs)
{
char		*strP;
XErr		err = noErr;
request_rec	*reqP = (request_rec*)taskID;

	if (strP = reqP->path_info)
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(pathArgs, strP);
		else
			err = -1;
	}
	else
		*pathArgs = 0;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetPhysURL(void *taskID, BlockRef *blockP, long *lenP)
{
long	allocSize, len;
char	*strP;
XErr	err = noErr;
Ptr		p;

	if (strP = ((request_rec*)taskID)->filename)
	{	len = CLen(strP);
		#if __WIN_XLIB__
			allocSize = len + 1 + 32;
		#else
			allocSize = len + 1;
		#endif
		if (*blockP = NewBlock(allocSize, &err, &p))
		{	CEquStr(p, strP);
		#if __WIN_XLIB__
			FilePathWin32ToXLib(p);
			*lenP = CLen(p);
		#else
			*lenP = len;
		#endif
		}
	}
	else
	{	err = _EmptyBLock(blockP);
		*lenP = 0;
	}

return err;
}

#define	DEFAULT_ENC_TYPE	"application/x-www-form-urlencoded"

//===========================================================================================
XErr HTTPControllerGetPostArgs(void *taskID, BlockRef *postHP, long *postLen)
{
XErr			err = noErr;
request_rec		*r = (request_rec*)taskID;
int				rc;
unsigned long	postMAX;
#if __WIN_XLIB__
	__int64		clength;
#else
	unsigned long	clength;
#endif
	postMAX = GetPOSTLimit(r->args);
	clength = r->clength;
	if (clength && postMAX && (clength > postMAX))
	{	*postHP = 0;
		*postLen = kInvalidPostLength;
	}
	else
	{	if ((rc = ap_setup_client_block(r, REQUEST_CHUNKED_ERROR)) != OK)
			return rc;
		if (ap_should_client_block(r))
		{	char	argsbuffer[HUGE_STRING_LEN];
		#if __WIN_XLIB__
			__int64		length, rsize, rpos, len_read;
		#else
			long		length, rsize, rpos, len_read;
		#endif
			char	*rbuf;
			
			length = r->remaining;
			rpos = 0;
			if (*postHP = NewBlock((long)length + 1, &err, &rbuf))
			{	
			#ifndef API2
				ap_hard_timeout("HTTPControllerGetPostArgs", r);
			#endif
				while ((len_read = ap_get_client_block(r, argsbuffer, sizeof(argsbuffer))) > 0)
				{
				#ifndef API2
					ap_reset_timeout(r);
				#endif
					if ((rpos + len_read) > length)
						rsize = length - rpos;
					else
						rsize = len_read;
					CopyBlock(rbuf + rpos, argsbuffer, (long)rsize);
					rpos += rsize;
					if (postMAX && (rpos > postMAX))
					{	DisposeBlock(postHP);
						*postHP = 0;
						length = kInvalidPostLength;
						break;
					}
				}
			#ifndef API2
				ap_kill_timeout(r);
			#endif
				if NOT(err)
					*postLen = (long)length;
				else
				{	DisposeBlock(postHP);
					*postLen = *postHP = 0;
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetSearchArgs(void *taskID, BlockRef *searchHP, long *searchLen)
{
XErr	err = noErr;

	err = _StrFromIndex((request_rec*)taskID, ARGS, searchHP, searchLen);

return err;
}

#if __MACOSX__ || __UNIX_XLIB__
	#define	__SLASH		'/'	
#else
	#define	__SLASH		'/'
#endif

//===========================================================================================
XErr	HTTPControllerGetServerDir(void *taskID, char *serverDir)
{
int			serverDirLen;
request_rec *reqP = (request_rec*)taskID;

	CEquStr(serverDir, (char*)ap_document_root(reqP));
	serverDirLen = CLen(serverDir);
	if (serverDir[serverDirLen-1] != __SLASH)
	{	CAddChar(serverDir, __SLASH);
	#if __WIN_XLIB__
		FilePathWin32ToXLib(serverDir);
	#endif
	}

return noErr;
}

//===========================================================================================
XErr HTTPControllerGetServerName(void *taskID, char *serverName)
{
XErr	err = noErr;
char	*strP;

	if (strP = (char*)ap_get_server_version())
		CEquStr(serverName, strP);
	else
		*serverName = 0;

return err;
}

//===========================================================================================
XErr	HTTPControllerGetFullRequest(void *taskID, BlockRef *blockP, long *lenP)
{
	return _FullRequest((request_rec*)taskID, blockP, lenP);
}


//===========================================================================================
XErr	HTTPControllerGetUsername(void *taskID, char *user)
{
XErr		err = noErr;

#ifndef API2
request_rec	*reqP = (request_rec*)taskID;
char		*strP;

	if (strP = reqP->connection->user)
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(user, strP);
		else
			*user = 0;
	}
	else
#endif
		*user = 0;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetPassword(void *taskID, char *pass)
{
const char	*strP;
XErr		err = noErr;
request_rec	*reqP = (request_rec*)taskID;

	*pass = 0;
	if NOT(err = ap_get_basic_auth_pw(reqP, &strP))
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(pass, (char*)strP);
		else
			*pass = 0;
	}
	else
	{	err = noErr;
		*pass = 0;
	}
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetMethod(void *taskID, char *method)
{
char		*strP;
XErr		err = noErr;
request_rec	*reqP = (request_rec*)taskID;

	if (strP = (char*)reqP->method)
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(method, strP);
		else
			err = -1;
	}
	else
		*method = 0;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetProtocol(void *taskID, char *protocol)
{
	XErr		err = noErr;
	request_rec	*reqP = (request_rec*)taskID;
	
#if (MODULE_MAGIC_NUMBER_MAJOR >= 20051115)		// apache 2.2
	CEquStr(protocol, ap_http_scheme(reqP));
#else
	CEquStr(protocol, (char*)ap_http_method(reqP));
#endif	
	return err;
}

//===========================================================================================
XErr HTTPControllerGetPort(void *taskID, uint32_t *portP)
{
	XErr		err = noErr;
	request_rec	*reqP = (request_rec*)taskID;
	
	*portP = ap_default_port(reqP);

	return err;
}

//===========================================================================================
XErr HTTPControllerGetContentType(void *taskID, char *contentType)
{
request_rec	*reqP = (request_rec*)taskID;
XErr		err = noErr;
char		*strP;

#ifdef API2
	strP = (char*)apr_table_get(reqP->headers_in, "Content-Type");
#else
	strP = (char*)ap_table_get(reqP->headers_in, "Content-Type");
#endif
	if (strP)
	{	if (CLen(strP) < STR_MAXLEN)
			CEquStr(contentType, strP);
		else
			*contentType = 0;
	}
	else
		*contentType = 0;
	
return err;
}

//===========================================================================================
XErr 	HTTPControllerGetContentLength(void *taskID, long *contentLengthP)
{
request_rec	*reqP = (request_rec*)taskID;

	*contentLengthP = (long)reqP->clength;
	
return noErr;
}

//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *outPutStr)
{
	if (gLogRefNum)
		CStringToLog(gLogRefNum, outPutStr, true);

return noErr;
}

//===========================================================================================
XErr	HTTPControllerLogReply(void *taskID, BlockRef bufferBlock, long len)
{
XErr	err = noErr;

return err;
}

//===========================================================================================
XErr	HTTPControllerSendReply(void *taskID, BlockRef bufferBlock, long len)
{
XErr		err = noErr;
char		*p;

	if NOT(err = SetBlockSize(bufferBlock, len+1))
	{	if (len)
		{	p = GetPtr(bufferBlock);
		#ifdef API2
			_filter_headers((request_rec*)taskID, &p, &len);
			if (len)
				ap_rwrite(p, len, (request_rec*)taskID);
		#else
			ap_rwrite(p, len, (request_rec*)taskID);
		#endif
		}
		else
			ap_rputs(" ", (request_rec*)taskID);	// no "Document contains no data", please
		DisposeBlock(&bufferBlock);
	}

return err;
}
