/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMrgNetServer.c,v 1.15 2006-06-19 13:17:13 valfer Exp $
	|______________________________________________________________________________
*/
#include	"XLib.h"
//#include	"Helpers.h"
#include 	"HTTPMgr.h"

#include 	"HTTPMrgNet.h"

#include	<stdio.h>
#include	<signal.h>

//static	Boolean		gsAppendNext = false;

extern	CStr255		gsUpSinceStr;

static LONGLONG gGlobalCount = 0;

/*====================================================
PROTOCOLLO DI TRASMISSIONE
schema:
	
	long	length of all subsequent data (for sockets)

	long	TOTELEMS (number of following struct)
	long	CLENGTH (content length)
	
	long	WHAT
	long	LENGTH
	..... DATA

	long	WHAT
	long	LENGTH
	..... DATA

	long	WHAT
	long	LENGTH
	..... DATA

====================================================*/

#define	CHECK_4LENGTH(len, msg)	if (len<4){HTTPControllerLog(taskID, msg);err=-1;goto out;}

//===========================================================================================
// HTTPElem *elemP, char *startP, BlockRef *blockP, long *lenP
static XErr 	_GetHTTPString(HTTPElem *elemP, char *startP, char *string)
{
XErr		err = noErr;
long		len;
Ptr			p;

	len = elemP->length;
	if (len > 255)
		len = 255;
	p = startP + elemP->offset;
	CopyBlock(string, p, len);
	string[len] = 0;
	
return err;
}

//===========================================================================================
static XErr	_GetHTTPBlock(HTTPElem *elemP, char *startP, BlockRef *blockP, long *lenP)
{
XErr		err = noErr;
long		len;
Ptr			p, tP;

	len = elemP->length;
	p = startP + elemP->offset;
	if (*blockP = NewBlock(len + 1, &err, &tP))
	{	//tP = GetPtr(*blockP);
		if (len)
			CopyBlock(tP, p, len);
		*(tP + len) = 0;
		if (lenP)
			*lenP = len;
	}		
	
return err;
}

/*
mettere su unix
//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *outPutStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
//CStr255		aCStr;

	if (gLogRefNum)
		CStringToLog(gLogRefNum, outPutStr);
	return noErr;
}

//===========================================================================================
static void	_LogToWindowStatus(char *logStr)
{
	if NOT(gDemon)
		printf(logStr);
}

*/
// #define	BIFERNO_SERVER_DEBUG	1
//===========================================================================================
static XErr	_FillElem(void *taskID, HTTPElemP elemP, Ptr *thePPtr, long *lenP, long *offsetP)
{
long		aLong, len, offset;
Ptr			tempP;
XErr		err = noErr;
CStr15		aCStr;
char		*elemStringP, *tBuffP, *aCStrP;

	//TRACEN("_FillElem: ", 0, 0);
	tempP = *thePPtr;
	len = *lenP;
	offset = *offsetP;
	
	// Tag Name
	aCStrP = aCStr;
	tBuffP = tempP;
	*aCStrP++ = *tBuffP++;
	*aCStrP++ = *tBuffP++;
	*aCStrP++ = *tBuffP++;
	*aCStrP++ = *tBuffP;
	*aCStrP = 0;
	//TRACE(aCStr);
	len -= sizeof(long);
	tempP += sizeof(long);

	// length
	CHECK_4LENGTH(len, "_FillElem: elemP->length < 4");
	aLong = elemP->length = *(long*)tempP;
	if (aLong < 0)		// for POST -1
		aLong = 0;
	//TRACEN("length", aLong, 0);
	tempP += sizeof(long);
	len -= sizeof(long);
	if (aLong > len)
	{	HTTPControllerLog(taskID, "_FillElem: elemP->length > totLen");
		return -1;
	}
	offset += 8;
	elemP->offset = offset;
	
	elemStringP = tempP;
	
	tempP += aLong;
	len -= aLong;
	offset += aLong;

	#ifdef BIFERNO_SERVER_DEBUG
	{	CStr255		aCStr;
		XErr		err2;
		BlockRef	b;
		Ptr			p;
		
		CopyBlock(aCStr, *thePPtr, 4);
		aCStr[4] = 0;
		CAddStr(aCStr, ":\t");
		HTTPControllerLog(taskID, aCStr);
		if (b = NewBlock(elemP->length + 1, &err2, &p))
		{	//p = GetPtr(b);
			CopyBlock(p, elemStringP, elemP->length);
			p[elemP->length] = 0;
			HTTPControllerLog(taskID, p);
			DisposeBlock(&b);
		}
		else
			HTTPControllerLog(taskID, "can't log!");
		HTTPControllerLog(taskID, "\n");
	}
	#endif

out:
*thePPtr = tempP;
*lenP = len;
*offsetP = offset;
return err;
}

//#define	MAXALLOC	256
//#define	MAXLOG		251

//===========================================================================================
// si deve loggare di pi� (altri elementi)
static void _LogElem(void *taskID, HTTPRecord *httpRecordP, HTTPElem	*elemP)
{
CStr255		aCStr;
long		tLen;
char		*startP;

	startP = (char*)httpRecordP->startP;
	tLen = elemP->length;
	FirstLine(startP + elemP->offset, tLen, aCStr);
	
	/*destP = aCStr;
	sourceP = startP + elemP->offset;
	i = 0;
	while (i++ < MAXLOG) 	//&& (*sourceP != '\n'))
	{	if (IsNewLine(sourceP, tLen, nil))
			break;
		else
		{	*destP++ = *sourceP++;
			tLen--;
		}
	}
	if (i >= MAXLOG)		//&& (*sourceP != '\n'))
	{	*destP++ = '.';
		*destP++ = '.';
		*destP++ = '.';
	}	
	*destP = 0;
	*/
	/*if (tLen < 511)
	{	CopyBlock(aCStr, startP + elemP->offset, tLen);
		aCStr[tLen] = 0;
	}
	else
	{	tLen = 511;
		CopyBlock(aCStr, startP + elemP->offset, tLen);
		aCStr[tLen] = 0;
		CAddStr(aCStr, "...");
	}
	CAddStr(aCStr, "\t");*/
	HTTPControllerLog(taskID, aCStr);
}

//===========================================================================================
static void	_LogFullRequestCallBack(void *taskID, long data)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)data;

	_LogElem(taskID, httpRecordP, &httpRecordP->full_request);
}

//===========================================================================================
// si deve loggare di pi� (altri elementi)
/*static void _Log(void *taskID, HTTPRecord *httpRecordP, long totLen)
{
#if __MWERKS__
	#pragma unused (totLen)

	//if NOT(gDemon)
	{	
	XErr		err = noErr;
	CStr255		aCStr;
	//CStr15		tStr;

		XCurrentDateTimeToString(aCStr, kComplete);
		
		
		HTTPControllerLog(taskID, aCStr);
		
		_LogElem(taskID, httpRecordP, &httpRecordP->full_request);
		//_LogElem(httpRecordP, &httpRecordP->phys_url);
		//_LogElem(httpRecordP, &httpRecordP->path_args);
		//_LogElem(httpRecordP, &httpRecordP->method);
		HTTPControllerLog(taskID, "\n");
	}
}
*/
//===========================================================================================
static XErr	_EmptyBLock(BlockRef *blockP)
{	
Ptr		p;
XErr	err = noErr;
	
	if (*blockP = NewBlock(1, &err, &p))
	{	//p  = GetPtr(*blockP);
		*p = 0;
	}

return err;
}

//===========================================================================================
/*static void	_Str2Terminal(char *logStr)
{
CStr255	aCStr;

	CEquStr(aCStr, logStr);
	CAddChar(aCStr, '\n');
	printf(aCStr);
}*/

#if __MWERKS__
#pragma mark-
#endif

//============================================================
/*Boolean HTTPControllerConnectionClosed(void *taskID)
{
	return true;
}
*/
//===========================================================================================
static XErr _GetHost(void *taskID, char *host)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->host, (char*)httpRecordP->startP, host);
	else
		*host = 0;
	
return err;
}

//===========================================================================================
XErr 	HTTPControllerGetServerParam(void *taskID, long which, char *cstr, long *numP)
{
XErr			err = noErr;

	if (cstr)
		*cstr = 0;
	if (numP)
		*numP = 0;
	switch(which)
	{	case kServerDomain:
			err = _GetHost(taskID, cstr);
			break;
		/*case kServerPort:
			break;
		case kServerDirectoryPath:
			break;
		case kServerVersionNumber:
			break;
		case kServerTotalConnections:
			break;
		case kServerCurrentUserLevel:
			break;
		case kServerHighestUserLevel:
			break;
		case kServerCurrentFreeMemory:
			break;
		case kServerMinimumFreeMemory:
			break;
		case kServerTotalConnTimeouts:
			break;
		case kServerTotalConBusies:
			break;
		case kServerTotalConDenied:
			break;
		case kServerTotalBytesSent:
			break;*/
		/*case kServerUpSinceDate:
			CEquStr(cstr, gsUpSinceStr);
			break;*/
		/*case kServerIndexFile:
			break;
		case kServerErrorFile:
			break;*/
		default:
			return -1;
	}

return err;
}

//===========================================================================================
XErr HTTPControllerGetIPAddress(void *taskID, char *ipAddress)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->ip_addr, (char*)httpRecordP->startP, ipAddress);
	else
		*ipAddress = 0;
	
return err;
}

//===========================================================================================
XErr HTTPControllerGetAddress(void *taskID, char *address)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->addr, (char*)httpRecordP->startP, address);
	else
		*address = 0;

return err;
}

//===========================================================================================
XErr	HTTPControllerGetServerDir(void *taskID, char *serverDir)
{
HTTPRecord	*httpRecordP;
HTTPElem	*elemP;
long		len;
Ptr			p;

	if (taskID)
	{	httpRecordP = (HTTPRecord*)taskID;
		elemP = &httpRecordP->serverDir;
		len = elemP->length;
		if (len < 255)
		{	p = (char*)httpRecordP->startP + elemP->offset;
			CopyBlock(serverDir, p, len);
			serverDir[len] = 0;
		}
		else
			*serverDir = 0;
	}
	else
		*serverDir = 0;

return noErr;
}

//===========================================================================================
XErr	HTTPControllerGetPathArgs(void *taskID, char *pathArgs)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->path_args, (char*)httpRecordP->startP, pathArgs);
	else
		*pathArgs = 0;

return err;
}

//===========================================================================================
XErr 	HTTPControllerGetPhysURL(void *taskID, BlockRef *blockP, long *lenP)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPBlock(&httpRecordP->phys_url, (char*)httpRecordP->startP, blockP, lenP);
	else
	{	*lenP = 0;
		return _EmptyBLock(blockP);
	}

return err;
}

//===========================================================================================
XErr 	HTTPControllerGetPostArgs(void *taskID, BlockRef *postBlockP, long *postLen)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;
long		len;

	if (httpRecordP)
	{	len = httpRecordP->post_args.length;
		if (len == kInvalidPostLength)
		{	*postBlockP = 0;
			*postLen = kInvalidPostLength;
		}
		else
			err = _GetHTTPBlock(&httpRecordP->post_args, (char*)httpRecordP->startP, postBlockP, postLen);
	}
	else
	{	*postLen = 0;
		err = _EmptyBLock(postBlockP);
	}
	
return err;
}

//===========================================================================================
XErr 	HTTPControllerGetSearchArgs(void *taskID, BlockRef *searchBlockP, long *searchLen)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;

	if (httpRecordP)
		return _GetHTTPBlock(&httpRecordP->search_args, (char*)httpRecordP->startP, searchBlockP, searchLen);
	else
	{	*searchLen = 0;
		return _EmptyBLock(searchBlockP);
	}
}

//===========================================================================================
/*XErr HTTPControllerGetSearchArgsString(void *taskID, char *searchArgs)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->search_args, httpRecordP->startP, searchArgs);
	else
		*searchArgs = 0;

return err;
}*/

//===========================================================================================
/*XErr	HTTPControllerGetParam(void *taskID, char *which, BlockRef *blockP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID, which, blockP)
	
	// fare full request
	
	return -1;
}*/

//===========================================================================================
XErr	HTTPControllerGetFullRequest(void *taskID, BlockRef *blockP, long *lenP)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;

	if (httpRecordP)
		return _GetHTTPBlock(&httpRecordP->full_request, (char*)httpRecordP->startP, blockP, lenP);
	else
	{	*lenP = 0;
		return _EmptyBLock(blockP);
	}
}

//===========================================================================================
XErr	HTTPControllerGetUsername(void *taskID, char *user)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->user, (char*)httpRecordP->startP, user);
	else
		*user = 0;

return err;
}

//===========================================================================================
XErr 	HTTPControllerGetPassword(void *taskID, char *pass)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->pass, (char*)httpRecordP->startP, pass);
	else
		*pass = 0;

return err;
}

//===========================================================================================
XErr 	HTTPControllerGetMethod(void *taskID, char *method)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->method, (char*)httpRecordP->startP, method);
	else
		*method = 0;

return err;
}

//===========================================================================================
XErr 	HTTPControllerGetProtocol(void *taskID, char *protocol)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->protocol, (char*)httpRecordP->startP, protocol);
	else
		*protocol = 0;

return err;
}

//===========================================================================================
XErr 	HTTPControllerGetPort(void *taskID, uint32_t *portNumber)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		*portNumber = *(uint32_t*)(httpRecordP->startP + httpRecordP->port.offset);
	else
		*portNumber = 0;

return err;
}

//===========================================================================================
// HTTPElem *elemP, char *startP, BlockRef *blockP, long *lenP
XErr 	HTTPControllerGetContentType(void *taskID, char *contentType)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;

	if (httpRecordP)
		return _GetHTTPString(&httpRecordP->content_type, (char*)httpRecordP->startP, contentType);
	else
		*contentType = 0;

return err;
}

//===========================================================================================
XErr HTTPControllerGetServerName(void *taskID, char *serverName)
{
HTTPRecord	*httpRecordP;
XErr		err = noErr;
long		len;
Ptr			p;
HTTPElem 	*elemP;

	if (taskID)
	{	httpRecordP = (HTTPRecord*)taskID;
		elemP = &httpRecordP->server_name;
		len = elemP->length;
		p = (char*)httpRecordP->startP + elemP->offset;
		CopyBlock(serverName, p, len);
		serverName[len] = 0;
	}
	else
		*serverName = 0;
	
return err;
}

//===========================================================================================
/*XErr	HTTPControllerYield(void *taskID, long sleep)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID, sleep)
	XYield(&gLastTicks);

return noErr;
}

//===========================================================================================
XErr	HTTPControllerRequestIdleTime(void *taskID, unsigned long ticksToSleep)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID, ticksToSleep)
	return noErr;
}*/

// Other Utilities
//===========================================================================================
XErr	HTTPControllerSendReply(void *taskID, BlockRef block, long len)
{
HTTPRecord	*httpRecordP = (HTTPRecord*)taskID;
XErr		err = noErr;
CStr255		logStr, timeStr;

	if (len && block)
	{	LockBlock(block);
		
		XCurrentDateTimeToString(timeStr, kComplete);
		sprintf(logStr, "%s (=>%d)\n", timeStr, len);
		err = XServerSendToClient(httpRecordP->socketRef, block, len);
	}
	
	//TRACE("DisposeBlock");
	if (block)
		DisposeBlock(&block);
	//TRACE("DisposeBlock ok");
	
return err;
}

//===========================================================================================
/*static void _AddOneLine(void *taskID, char *aCStr, Ptr *textPPtr, long *lenP, long returnSize, long *jP, Boolean *onlySpacesP, Boolean addToLast)
{
int			j = *jP;
CStr255		logStr;

	if (textPPtr)
		(*textPPtr) += returnSize;
	if (lenP)
		(*lenP) -= returnSize;
	aCStr[j] = 0;
	if (j == 250)
	{	CAddStr(aCStr, "...");
		HTTPControllerLog(taskID, aCStr);
		j = 0;
	}
	else
	{	if (j && NOT(*onlySpacesP))
		{	if (NOT(addToLast) && NOT(IsNewLine(aCStr, j, nil)))
			{	CEquStr(logStr, "\r\n");
				CAddStr(logStr, aCStr);
				HTTPControllerLog(taskID, logStr);
			}
			else
				HTTPControllerLog(taskID, aCStr);
		}
		j = 0;
	}
	(*onlySpacesP) = true;
	*jP = j;
}

//===========================================================================================
XErr HTTPControllerLogReply(void *taskID, BlockRef bufferH, long len)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
Ptr			textP;
int			ch;
long		j;
long		returnSize;
CStr255		aCStr;
Boolean		onlySpaces = true;
BlockRef	resultStringBlock;
long		resultLen;
XErr		err = noErr;

	LockBlock(bufferH);
	if NOT(err = SubstituteExt(GetPtr(bufferH), len, &resultStringBlock, &resultLen, "%", "%%", 2, true, false))
	{	DisposeBlock(&bufferH);
		LockBlock(resultStringBlock);
		textP = GetPtr(resultStringBlock);
		len = resultLen;
		//HTTPControllerLog(taskID, "============= BEGIN BIFERNO SCRIPT OUTPUT");
		//HTTPControllerLog(taskID, "");
		if (len)
		{	j = 0;
			do {
				if (IsNewLine(textP, len, &returnSize) || (j == 250))
				{	_AddOneLine(taskID, aCStr, &textP, &len, returnSize, &j, &onlySpaces, false);
					continue;
				}
				else if ((ch = *textP) != '\n')
				{	if (ch != ' ')
						onlySpaces = false;
					aCStr[j++] = ch;
				}
				textP++;
				len--;
			} while (len > 0);
		}
		_AddOneLine(taskID, aCStr, &textP, &len, returnSize, &j, &onlySpaces, false);	// last
		//HTTPControllerLog(taskID, "============= END BIFERNO SCRIPT OUTPUT");
		DisposeBlock(&resultStringBlock);
	}
	else
		DisposeBlock(&bufferH);
	
return err;
}

//===========================================================================================
XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
int			ch;
long		j;
long		returnSize = 0;
CStr255		aCStr;
Boolean		onlySpaces = true;
BlockRef	block;
XErr		err = noErr;

	j = 0;
	if (len)
	{	if (block = NewBlock(len, &err))
		{	CopyBlock(GetPtr(block), textP, len);
			if NOT(err = HTML2Txt(&block, &len))
			{	if (len)
				{	LockBlock(block);
					textP = GetPtr(block);
					do {
						if (IsNewLine(textP, len, &returnSize) || (j == 250))
						{	_AddOneLine(taskID, aCStr, &textP, &len, returnSize, &j, &onlySpaces, false);
							gsAppendNext = false;
							*aCStr = 0;	// just added
							continue;
						}
						else if ((ch = *textP) != '\n')
						{	if (ch != ' ')
								onlySpaces = false;
							aCStr[j++] = ch;
						}
						textP++;
						len--;
					} while (len > 0);
					if ((j > 1) || (*aCStr && (*aCStr != '\t') && (*aCStr != '\r')))
					{	_AddOneLine(taskID, aCStr, nil, nil, 0, &j, &onlySpaces, gsAppendNext);
						gsAppendNext = true;
					}
				}
			}
			DisposeBlock(&block);
		}
	}
	
return err;
}
*/
//===========================================================================================
void	HTTPControllerSetMonoThread(void *taskID)
{
// nothing to do (on Linux)
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif
}

//===========================================================================================
void	HTTPControllerSetMultiThread(void *taskID)
{
// nothing to do (on Linux)
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif
}

//===========================================================================================
/*XErr HTTPControllerGetIndexFile(void *taskID, char *indexFile)
{
	CEquStr(indexFile, "index.bfr");

return noErr;
}*/

//===========================================================================================
/*XErr	HTTPControllerGetHeaderField(void *taskID, char *index, BlockRef *blockP)
{
	return noErr;
}
//===========================================================================================
XErr 	HTTPControllerGetConnectionStatus(void *taskID, long *statusP)
{
	*statusP = 0;
	return noErr;
}
//===========================================================================================
Boolean HTTPControllerConnectionClosed(void *taskID)
{
	return false;
}*/
/*//===========================================================================================
XErr	HTTPControllerExecStream(void *taskID, char *ip_addrStr, unsigned short ip_port, Ptr data, long dataLen, StringPtr refererPath, long passwordOff, BlockRef *returnDataBlockP, long *returnLenP)
{
	return noErr;
}
//===========================================================================================
long	HTTPControllerGetVersion(void *taskID, long *versionP)
{
	*versionP = 0;
	return 0;
}
*/
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	GetClientRequest(void *taskID, long socketRef, BlockRef block, long totLen, long userData, HTTPRecord *httpRecordP, LONGLONG *uniqueTagP, char *ip_addr, char *host)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(userData)
#endif
long		saveTotLen, offset, totElems;
Ptr			buffP;
XErr		err = noErr;
int			i;
CStr255		request, cookieSid;

	XThreadsEnterCriticalSection();
	*uniqueTagP = ++gGlobalCount;
	XThreadsLeaveCriticalSection();

	if NOT(block)
	{	err = totLen;
		goto out;
	}
	
	saveTotLen = totLen;
	buffP = GetPtr(block);
	ClearBlock(httpRecordP, sizeof(HTTPRecord));
	httpRecordP->socketRef = socketRef;
		
	LockBlock(block);
	httpRecordP->startP = (uint32_t)buffP;
	
	
	//TRACEN("totLen", totLen, 0);
	CHECK_4LENGTH(totLen, "_ProcessClientRequest: no totElems");
	totElems = httpRecordP->totElems = *(long*)buffP;
	if (totElems < 0)
	{	HTTPControllerLog(taskID, "_ProcessClientRequest: totElems <= 0");
		err = -1;
		goto out;
	}
	else if (totElems == 0)
	{	buffP += sizeof(long);
		totLen -= sizeof(long);
		CHECK_4LENGTH(totLen, "_ProcessClientRequest: no command");
		httpRecordP->command = *(long*)buffP;
	}
	
	if (totElems)
	{	//TRACEN("totElems: ", totElems, 0);
		buffP += sizeof(long);
		totLen -= sizeof(long);

		CHECK_4LENGTH(totLen, "_ProcessClientRequest: no cLength");
		httpRecordP->cLength = *(long*)buffP;
		if (httpRecordP->cLength < 0)
		{	HTTPControllerLog(taskID, "_ProcessClientRequest: cLength <= 0");
			err = -1;
			goto out;
		}
		//TRACEN("cLength: ", httpRecordP->cLength, err);
		buffP += sizeof(long);
		totLen -= sizeof(long);

		offset = 8;	
		for (i = 0; (i < totElems) && NOT(err) && (totLen > 0); i++)
		{	CHECK_4LENGTH(totLen, "_ProcessClientRequest: item in loop < 4");
			switch (*(long*)buffP)
			{	
				case 'SDIR':
				case 'RIDS':
					err = _FillElem(taskID, &httpRecordP->serverDir, &buffP, &totLen, &offset);
					break;
				case 'PATH':
				case 'HTAP':
					err = _FillElem(taskID, &httpRecordP->path_args, &buffP, &totLen, &offset);
					break;
				case 'PURL':
				case 'LRUP':
					err = _FillElem(taskID, &httpRecordP->phys_url, &buffP, &totLen, &offset);
					break;
				case 'POST':
				case 'TSOP':
					err = _FillElem(taskID, &httpRecordP->post_args, &buffP, &totLen, &offset);
					break;
				case 'SRCH':
				case 'HCRS':
					err = _FillElem(taskID, &httpRecordP->search_args, &buffP, &totLen, &offset);
					break;
				case 'USER':
				case 'RESU':
					err = _FillElem(taskID, &httpRecordP->user, &buffP, &totLen, &offset);
					break;
				case 'PASS':
				case 'SSAP':
					err = _FillElem(taskID, &httpRecordP->pass, &buffP, &totLen, &offset);
					break;
				case 'METH':
				case 'HTEM':
					err = _FillElem(taskID, &httpRecordP->method, &buffP, &totLen, &offset);
					break;
				case 'CTYP':
				case 'PYTC':
					err = _FillElem(taskID, &httpRecordP->content_type, &buffP, &totLen, &offset);
					break;
				case 'SNAM':
				case 'MANS':
					err = _FillElem(taskID, &httpRecordP->server_name, &buffP, &totLen, &offset);
					break;
				case 'HOST':
				case 'TSOH':
					err = _FillElem(taskID, &httpRecordP->host, &buffP, &totLen, &offset);
					break;
				case 'FREQ':
				case 'QERF':
					err = _FillElem(taskID, &httpRecordP->full_request, &buffP, &totLen, &offset);
					break;
				case 'IPAD':
				case 'DAPI':
					err = _FillElem(taskID, &httpRecordP->ip_addr, &buffP, &totLen, &offset);
					break;
				case 'ADDR':
				case 'RDDA':
					err = _FillElem(taskID, &httpRecordP->addr, &buffP, &totLen, &offset);
					break;
				case 'PROT':
				case 'TORP':
					err = _FillElem(taskID, &httpRecordP->protocol, &buffP, &totLen, &offset);
					break;
				case 'PORT':
				case 'TROP':
					err = _FillElem(taskID, &httpRecordP->port, &buffP, &totLen, &offset);
					break;
				default:
					//TRACEN("unknown tag: ", i, 0);
					break;
			}
		}
		_GetHTTPString(&httpRecordP->ip_addr, (char*)httpRecordP->startP, ip_addr);
		_GetHTTPString(&httpRecordP->host, (char*)httpRecordP->startP, host);	
		FirstLine((char*)httpRecordP->startP + httpRecordP->full_request.offset, httpRecordP->full_request.length, request);
		GetCookieSID((char*)httpRecordP->startP + httpRecordP->full_request.offset, httpRecordP->full_request.length, cookieSid);
	}
	else
	{	*ip_addr = 0;
		*host = 0;
		*request = 0;
		*cookieSid = 0;
	}
	LogInitRun(taskID, httpRecordP->command, ip_addr, host, request, *uniqueTagP, cookieSid);
	
out:
return err;
}
