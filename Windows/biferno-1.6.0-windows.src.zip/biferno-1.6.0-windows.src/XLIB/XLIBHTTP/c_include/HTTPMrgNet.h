/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMrgNet.h,v 1.18 2006-07-19 10:23:10 valfer Exp $
	|______________________________________________________________________________
*/
#ifndef	__BIFERNO_NET__
	#define __BIFERNO_NET__

#include 	"HTTPMgr.h"

#define	TOTAL_RETRY_TIME	(60 * 60 * 2)	// 2 minutes

#define	NORM_STOP_STR	"==*NORMAL STOP*=="

typedef struct HTTPElem
{
	uint32_t	offset;
	uint32_t	length;
} HTTPElem, *HTTPElemP;

typedef struct
{
	uint32_t		command;	// 0, kFlush, kReload
	uint32_t		param;		// for users
	uint32_t		socketRef;
	uint32_t		totElems;
	uint32_t		cLength;
	uint32_t		startP;		// used only in Biferno (Server) side
	HTTPElem		serverDir;
	HTTPElem		path_args;
	HTTPElem		phys_url;
	HTTPElem		post_args;
	HTTPElem		search_args;
	HTTPElem		user;
	HTTPElem		pass;
	HTTPElem		method;
	HTTPElem		content_type;
	HTTPElem		server_name;
	HTTPElem		host;
	HTTPElem		full_request;
	HTTPElem		ip_addr;
	HTTPElem		addr;
	HTTPElem		protocol;
	HTTPElem		port;
} HTTPRecord, *HTTPRecordP;

#define	BIFERNO_WIN_PORT					4999
#define	BIFERNO_SENTINEL_WIN_PORT			4998
#define	BIFERNO_MONITOR_PORT				4996

#define	BIFERNO_UNIX_FILE					"/tmp/biferno.str"
#define	BIFERNOSENTINEL_UNIX_FILE			"/tmp/bifernosent.str"
#define	BIFERNO_PID_FILE					"bifernod.pid"

#define	CLIENT_RUN_TIMEOUT			(60L * 15L)		// 15 minutes
#define	SENTINEL_BFR_TIMEOUT		(60L * 2L)		// 2 minute
#define	NO_TIMEOUT					0

#define	NORMAL_STOP_STRING	"==*NORMAL STOP*=="

#define	BIFERNO_CONSOLE_PATH_KEYNAME		"ConsolePath"
#define	BIFERNO_SERVICE_PATH_KEYNAME		"ServicePath"
#define	BIFERNO_WHICH_KEYNAME				"ExeMode"

#define	BIFERNO_PORT_KEYNAME		"Port"
#define	BIFERNO_CTL_PORT_KEYNAME	"CtlPort"
#define	BIFERNO_HOME_KEYNAME		"BifernoHome"

#define	MAX_LOG_STRING				511

XErr	GetClientRequest(void *taskID, long socketRef, BlockRef block, long totLen, long userData, HTTPRecord *httpRecordP, LONGLONG *uniqueTagP, char *ip_addr, char *host);
XErr	ClientRun(void *taskID, long serverPort, char *unixFile, char *errString, long timeout_secs);

typedef void	(*LogFullRequestCallBack)(void *taskID, long data);
typedef void	(*SentinelCheckLogCallBack)(char *logString, long data);
typedef void	(*SentinelCheckKillCallBack)(unsigned long pid, long data);

/*typedef enum {
		kUnknownLogMode = 0,
		kInLogMode,
		kOutLogMode,
		kFlushLogMode,
		kReloadLogMode,
		kQuitLogMode,
		kGetVersionLogMode,
		kCheckLogMode,
		kGenMessageMode,
		kStartupMode,
		kStopMode,
		kGracefulStopMode,
		kDebugMode,
		kCmdOutMode,
		kBifernoStop
		} Command;*/

void	LogInitRun(void *taskID, long command, char *ip_addr, char *host, char *request, LONGLONG uniqueTag, char *sid);
void 	LogExitRun(void *taskID, char *ip_addr, char *host, char *response, LONGLONG uniqueTag, char *sid, char *appName);
void	FirstLine(char *textP, long len, char *aCStr);
void	FormatLogString(char *logString, CmdType cmd, char dir, char *ip_addr, char *host, char *notes, LONGLONG uniqueTag, char *sid, char *appName);
XErr	LogFormatted(void *taskID, LONGLONG uID, char *sid, char *strLog, char *appName);

void	CheckLogFile(char *filePath, Boolean *isLockedP);

XErr	SentinelCheck(char* logFilePath, char* pidFilePath, SentinelCheckLogCallBack logcallBack, long loguserData, SentinelCheckKillCallBack killcallBack, long killuserData);

#if __UNIX_XLIB__ || (__MAC_XLIB__ && __MACOSX__)
	#ifdef __MACOSX__
		#define	BIFERNO_HOME_PATH	"/Users/BifernoHome"
	#else
		#define	BIFERNO_HOME_PATH	"/home/BifernoHome"
	#endif
#endif
Boolean 		GetBifernoHome(char *aStr);

XErr			WritePID(char *appName, unsigned long pid);
XErr			DeletePID(char *appName);
unsigned long	GetPIDNumber(char *pidFilePath);
void 			GetCookieSID(char *headerP, long headerLen, char *cookieSID);

#endif
