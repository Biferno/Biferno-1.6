/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HTTPMgr.h,v 1.13 2006-07-19 10:23:10 valfer Exp $
	|______________________________________________________________________________
*/
#ifndef	HTTP_CONTROLLER
	#define HTTP_CONTROLLER

#include 	"XLib.h"

// length requires send partial in mac Acgi
#define MACACGI_DIM_REQUIRES_SENDPARTIAL		(32L * 1024L)

// modules supported
#define HTTP_CONT_WSAPI		1
#define HTTP_CONT_ACGI		2
#define HTTP_CONT_ISAPI		3
#define HTTP_CONT_APACHE	4

// status of a stream
#define STATUS_DATA			1
#define STATUS_CLOSED		2
#define STATUS_OPEN			3
#define STATUS_UNKNOWN		4

// length of some memory blocks
#define	_20K		(unsigned long)(1024L * 20L)
#define _24K		(unsigned long)(1024L * 24L)

// Threads Stack Size
#define HTTP_THREAD_STACK_SIZE		(unsigned long)(64L * 1024L)

#define	EXPULSE_THREADS_TIMEOUT	10L * 60L	// 10 secs

#define kInvalidPostLength	-1

// timeout (ticks)
//#define kHTTPControllerTimeOut		(long)(60L * 10L)

#define STR_MAXLEN		255

typedef struct HTTPController
	{
	CStr255		aboutStr;
	void		*taskID;
	char		action[64];
	char		pluginName[64];
	char		suffix[64];
	char		mimeType[64];
	char		version[64];
	char		adminURL[64];
	XErr		(*Init)(void*, long*, Boolean, char*);
	XErr		(*Run)(void*, Boolean, LONGLONG, char*, char*, char*);
	XErr		(*Process)(void*, char*);
	XErr		(*Idle)(void*);
	XErr		(*ShutDown)(void*);
	XErr		(*Emergency)(void*);
	XErr		(*ServerStateChanged)(void*, long, char*);
	XErr		(*AccessControl)(void*);
	void		(*Suspend)(void*);
	void		(*Resume)(void*);
	/*Boolean	wantFilter;
	Byte		pad1;
	short		pad2;*/
	long		max_users;
	} HTTPController, *HTTPControllerP, **HTTPControllerH;

// possible type of requests
typedef enum {
	kFlush = 1,
	kReload,
	kQuit,
	kGetVersion,
	kCheck,
	kRequest,
	kStartup,
	kMessage
	} CmdType;
	
// Server parameters
enum {
		kServerDomain = 1
		//kServerPort,
		//kServerDirectoryPath,
		//kServerVersionNumber,
		//kServerTotalConnections,
		//kServerCurrentUserLevel,
		//kServerHighestUserLevel,
		//kServerCurrentFreeMemory,
		//kServerMinimumFreeMemory,
		//kServerTotalConnTimeouts,
		//kServerTotalConBusies,
		//kServerTotalConDenied,
		//kServerTotalBytesSent,
		//kServerUpSinceDate
		//kServerIndexFile,
		//kServerErrorFile
	};

// HTTP Parameters
XErr	HTTPControllerGetIPAddress(void *taskID, char *ipAddress);
XErr	HTTPControllerGetAddress(void *taskID, char *address);
XErr 	HTTPControllerGetPathArgs(void *taskID, char *pathArgs);
XErr	HTTPControllerGetPhysURL(void *taskID, BlockRef *blockP, long *lenP);
XErr 	HTTPControllerGetPostArgs(void *taskID, BlockRef *postBlockP, long *postLen);
XErr 	HTTPControllerGetSearchArgs(void *taskID, BlockRef *searchBlockP, long *searchLen);
XErr	HTTPControllerGetFullRequest(void *taskID, BlockRef *blockP, long *lenP);
XErr	HTTPControllerGetMethod(void *taskID, char *method);
XErr	HTTPControllerGetContentType(void *taskID, char *contentType);
XErr	HTTPControllerGetServerName(void *taskID, char *serverName);
XErr	HTTPControllerGetServerDir(void *taskID, char *serverDir);
XErr	HTTPControllerGetUsername(void *taskID, char *user);
XErr 	HTTPControllerGetPassword(void *taskID, char *password);
XErr 	HTTPControllerGetContentLength(void *taskID, long *contentLengthP);
XErr 	HTTPControllerGetProtocol(void *taskID, char *protocol);
XErr	HTTPControllerGetPort(void *taskID, uint32_t *portNumber);

// Server parameters
XErr 	HTTPControllerGetServerParam(void *taskID, long which, char *cstr, long *numP);

// Other
XErr	HTTPControllerSendReply(void *taskID, BlockRef block, long len);
XErr	HTTPControllerRegister(HTTPControllerP	httpControllerP);
XErr	HTTPControllerLog(void *taskID, char *outPutStr);
XErr 	HTTPControllerWindowOutput(void *taskID, Ptr textP, long len);
XErr 	HTTPControllerWindowOutputExt(void *taskID, BlockRef bufferH, long len);
XErr	HTTPControllerLogReply(void *taskID, BlockRef bufferBlock, long len);

void	HTTPControllerSetMonoThread(void *taskID);
void	HTTPControllerSetMultiThread(void *taskID);

#endif
