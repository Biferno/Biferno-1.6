/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XDateTimeWin.c,v 1.2 2003-06-24 08:55:27 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

#include <time.h>

//===========================================================================================
void	NativeDateTime2XDateTime(Ptr osRecP, XDateTimeRecP xTimeP)
{
SYSTEMTIME	*sysTimeP = (SYSTEMTIME*)osRecP;

	xTimeP->year = sysTimeP->wYear;
	xTimeP->month = sysTimeP->wMonth;
	xTimeP->day = sysTimeP->wDay;
	xTimeP->hour = sysTimeP->wHour;
	xTimeP->minute = sysTimeP->wMinute;
	xTimeP->second = sysTimeP->wSecond;
	xTimeP->dayOfWeek = sysTimeP->wDayOfWeek;
}

//===========================================================================================
void	XDateTime2NativeDateTime(XDateTimeRecP xTimeP, Ptr osRecP)
{
SYSTEMTIME	*sysTimeP = (SYSTEMTIME*)osRecP;

	sysTimeP->wYear = (unsigned short)xTimeP->year;
	sysTimeP->wMonth = (unsigned short)xTimeP->month;
	sysTimeP->wDay = (unsigned short)xTimeP->day;
	sysTimeP->wHour = (unsigned short)xTimeP->hour;
	sysTimeP->wMinute = (unsigned short)xTimeP->minute;
	sysTimeP->wSecond = (unsigned short)xTimeP->second;
	sysTimeP->wDayOfWeek = (unsigned short)xTimeP->dayOfWeek;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// milliseconds from system startup
void	XGetMilliseconds(unsigned long *milliSecondsP)
{
	*milliSecondsP = GetTickCount();
}

//===========================================================================================
/*
The GetTickCount function retrieves the number of 
milliseconds that have elapsed since the system was started
*/
unsigned long	XGetTicks(void)
{
unsigned long	millisecs, ticks;

	millisecs = GetTickCount();
	ticks = millisecs * 60 / 1000;

return ticks;
}

//===========================================================================================
void	XDelay(unsigned long ticks)
{
DWORD	dwMilliseconds;

	dwMilliseconds = ticks * 1000 / 60;
	Sleep(dwMilliseconds);   // sleep time
}

