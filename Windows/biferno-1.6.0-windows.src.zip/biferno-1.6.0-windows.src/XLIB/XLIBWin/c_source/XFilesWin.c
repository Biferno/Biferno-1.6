/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XFilesWin.c,v 1.12 2005-05-24 14:58:08 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"
#include "XFilesWinPrivate.h"

#define INVALID_SET_FILE_POINTER	((DWORD)-1)

//#ifdef __VISUALCPP__
	#include "XWinCreateAlias.h"
//#endif

// type cast of: typedef unsigned LONGLONG	XFileRef;
typedef struct {
				HANDLE			fileHandle;
				Boolean			dontUseCache;
				Byte			reserved1;
				short			reserved2;
				} WinFRef;

typedef struct {
				BOOL				fRecurse;     	// Set to TRUE to list subdirectories.
				BOOL				fOk;          	// Loop control flag
				BOOL				fIsDir;      	// Loop control flag
				BOOL				pad;
				WIN32_FIND_DATA		FindData; 		// File information
				XFilePath			strMask;
				WalkXFolderCallBack	callBack;
				long				userData;
			} DIRWALKDATA, *LPDIRWALKDATA;

//extern long	gCreateAliasEntryPoint;

/*
For alias:
http://msdn.microsoft.com/library/en-us/shellcc/platform/shell/programmersguide/shell_int/shell_int_programming/shortcuts/shortcut.asp?frame=true 

http://www.microsoft.com/intlkb/italy/articles/I14/4/05.htm

Because CreateLink calls the CoCreateInstance function, it is assumed that the CoInitialize function has already been called. CreateLink uses the IPersistFile interface to save the shortcut and the IShellLink interface to store the file name and description. 

// CreateLink - uses the Shell's IShellLink and IPersistFile interfaces 
//   to create and store a shortcut to the specified object. 
// Returns the result of calling the member functions of the interfaces. 
// lpszPathObj - address of a buffer containing the path of the object. 
// lpszPathLink - address of a buffer containing the path where the 
//   Shell link is to be stored. 
// lpszDesc - address of a buffer containing the description of the 
//   Shell link. 

HRESULT CreateLink(LPCSTR lpszPathObj, 
    LPCSTR lpszPathLink, LPCSTR lpszDesc) 
{ 
    HRESULT hres; 
    IShellLink* psl; 
 
    // Get a pointer to the IShellLink interface. 
    hres = CoCreateInstance(CLSID_ShellLink, NULL, 
        CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID *) &psl); 
    if (SUCCEEDED(hres)) { 
        IPersistFile* ppf; 
 
        // Set the path to the shortcut target and add the 
        // description. 
        psl->SetPath(lpszPathObj); 
        psl->SetDescription(lpszDesc); 
 
       // Query IShellLink for the IPersistFile interface for saving the 
       // shortcut in persistent storage. 
        hres = psl->QueryInterface(&IID_IPersistFile, 
            (LPVOID*)&ppf); 
 
        if (SUCCEEDED(hres)) { 
            WCHAR wsz[MAX_PATH]; 
 
            // Ensure that the string is Unicode. 
            MultiByteToWideChar(CP_ACP, 0, lpszPathLink, -1, 
                wsz, MAX_PATH); 
 
            // Save the link by calling IPersistFile::Save. 
            hres = ppf->Save(wsz, TRUE); 
            ppf->Release(); 
        } 
        psl->Release(); 
   } 
    return hres; 
} 

Resolving a Shortcut

An application may need to access and manipulate a shortcut that was previously created. This operation is referred to as resolving the shortcut. 

The application-defined ResolveIt function in the following example resolves a shortcut. Its parameters include a window handle, a pointer to the path of the shortcut, and the address of a buffer that receives the new path to the object. The window handle identifies the parent window for any message boxes that the Shell may need to display. For example, the Shell can display a message box if the link is on unshared media, if network problems occur, if the user needs to insert a floppy disk, and so on. 

The ResolveIt function calls the CoCreateInstance function and assumes that the CoInitialize function has already been called. Note that ResolveIt needs to use the IPersistFile interface to store the link information. IPersistFile is implemented by the IShellLink object. The link information must be loaded before the path information is retrieved, which is shown later in the example. Failing to load the link information causes the calls to the GetPath and GetDescription member functions to fail. 

HRESULT ResolveIt(HWND hwnd, LPCSTR lpszLinkFile, LPSTR lpszPath) 
{ 
    HRESULT hres; 
    IShellLink* psl; 
    char szGotPath[MAX_PATH]; 
    char szDescription[MAX_PATH]; 
    WIN32_FIND_DATA wfd; 
 
    *lpszPath = 0; // assume failure 
 
    // Get a pointer to the IShellLink interface. 
    hres = CoCreateInstance(CLSID_ShellLink, NULL, 
        CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID *) &psl); 
    if (SUCCEEDED(hres)) { 
        IPersistFile* ppf; 
 
        // Get a pointer to the IPersistFile interface. 
        hres = psl->QueryInterface(IID_IPersistFile, (void**)&ppf); 
        if (SUCCEEDED(hres)) { 
            WCHAR wsz[MAX_PATH]; 
 
            // Ensure that the string is Unicode. 
            MultiByteToWideChar(CP_ACP, 0, lpszLinkFile, -1, wsz, 
                MAX_PATH); 
 
            // Load the shortcut. 
            hres = ppf->Load(wsz, STGM_READ); 
            if (SUCCEEDED(hres)) { 
 
                // Resolve the link. 
                hres = psl->Resolve(hwnd, 0); 
                if (SUCCEEDED(hres)) { 
 
                    // Get the path to the link target. 
                    hres = psl->GetPath(szGotPath, 
                        MAX_PATH, (WIN32_FIND_DATA *)&wfd, 
                        SLGP_SHORTPATH ); 
                    if (FAILED(hres)) 
                        HandleErr(hres); // application-defined function 
 
                    // Get the description of the target. 
                    hres = psl->GetDescription(szDescription, MAX_PATH); 
                    if (FAILED(hres)) 
                        HandleErr(hres); 
                    lstrcpy(lpszPath, szGotPath); 
                } 
            } 
        // Release the pointer to the IPersistFile interface. 
        ppf->Release(); 
        } 
    // Release the pointer to the IShellLink interface. 
    psl->Release(); 
    } 
    return hres; 
}

*/

//===========================================================================================
XErr	_GetWinFullPath(XFilePathPtr filePath, XFilePathPtr fullPath)
{
	CEquStr(fullPath, filePath);
	FilePathXLibToWin32(fullPath);

return noErr;
}

//===========================================================================================
static XErr	_GetSearchTextPath(/*XFilePathPtr suffix, */char *searchText)
{
//int		suffLen;
XErr	err = noErr;
long	searchTextLen;

	if (searchTextLen = CLen(searchText))
	{	/*if (searchText[searchTextLen-1] == '\\')
		{	searchText[searchTextLen-1] = 0;
			searchTextLen--;
		}
		if (suffix && NOT(recursive))
		{	suffLen = CLen(suffix);
			if (searchTextLen < (long)(sizeof(XFilePath) - 1 - 3 - suffLen))
			{	CAddStr(searchText, "\\*.");
				if (suffLen)
				{	if (*suffix == '.')
						CAddStr(searchText, suffix + 1);
					else
						CAddStr(searchText, suffix);
				}
				else
					CAddStr(searchText, "*");
			}
			else
				return XError(kXLibError, ErrXFiles_PathTooLong);
		}
		else */
		if (searchText[searchTextLen-1] == '\\')
		{	if (searchTextLen < (sizeof(XFilePath) - 1 - 3))
				CAddStr(searchText, "*.*");
			else
				return XError(kXLibError, ErrXFiles_PathTooLong);
		}
		else
		{	if (searchTextLen < (sizeof(XFilePath) - 1 - 4))
				CAddStr(searchText, "\\*.*");
			else
				return XError(kXLibError, ErrXFiles_PathTooLong);
		}
	}
	else
		return XError(kXLibError, ErrXFiles_FolderNotFound);
	
return noErr;
}

//===========================================================================================
/*static Boolean	_IsRightSuffix(XFilePathPtr fileName, char *theSuffix)
{
int		fileNameLen, suffLen, ch1, ch2;
Byte	*chPtr, *suffPtr;

	fileNameLen = CLen(fileName);
	chPtr = (Byte*)&fileName[fileNameLen-1];
	if (theSuffix && (*theSuffix == 0))
	{	do {
			if (*chPtr-- == '.')
				return false;
		} while (--fileNameLen);
		return true;
	}
	else if (theSuffix)
	{	suffLen = CLen(theSuffix);
		if ((suffLen == 1) && (*theSuffix == '*'))
			return true;
		else if NOT(CCompareStrings(theSuffix, "*.*"))
		{	if (strchr(fileName, '.'))
				return true;
			else
				return false;
		}
		else
		{	suffPtr = (Byte*)&theSuffix[suffLen-1];
			if (suffLen && (fileNameLen >= suffLen))
			{	do {
					ch1 = *chPtr--;
					ch2 = *suffPtr--;
					LOW_CHAR(ch1);
					LOW_CHAR(ch2);
					if (ch1 != ch2)
						return false;
				} while (--suffLen);
			}
		}
	}
	else
		return true;

if (suffLen)
	return false;
else
	return true;
}*/

//===========================================================================================
static XErr	_FolderWalkRecurse(LPDIRWALKDATA dirWDataP, char *folderPath, char *suffix) 
{
HANDLE		hFind = 0L;
XErr		err = noErr;
char		*cFileName;
int			cFileNameLen;
XFilePath	thePath;
Boolean		isAlias, isDir;
long		variant;

	hFind = FindFirstFile(__TEXT(dirWDataP->strMask), &dirWDataP->FindData);
	if (dirWDataP->fOk = (hFind != INVALID_HANDLE_VALUE))
	{	while (dirWDataP->fOk && NOT(err))
		{	dirWDataP->fIsDir = (dirWDataP->FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY);
			if (isDir = dirWDataP->fIsDir)
				variant = kPathIsFolder;
			else
				variant = 0;
			cFileName = dirWDataP->FindData.cFileName;
			cFileNameLen = CLen(cFileName);
			if (((cFileNameLen != 1) || (*cFileName != '.')) && ((cFileNameLen != 2) || (*cFileName != '.') || (*(cFileName+1) != '.')))
			{	CEquStr(thePath, folderPath);
				CAddStr(thePath, cFileName);
				if NOT(err = XIsAlias(thePath, &isAlias))
				{	if (isAlias)
						variant |= kPathIsAlias;
					if (isDir)
						CAddChar(thePath, '/');
					if (isDir || WFFilter(cFileName, suffix))
						err = dirWDataP->callBack(thePath, variant, dirWDataP->userData);
					if (NOT(err) && isDir && dirWDataP->fRecurse)
					{	CEquStr(dirWDataP->strMask, thePath);
						FilePathXLibToWin32(dirWDataP->strMask);
						if NOT(err = _GetSearchTextPath(dirWDataP->strMask))
							err = _FolderWalkRecurse(dirWDataP, thePath, suffix);
					}
				}
			}
			if NOT(err)
			{	if NOT(dirWDataP->fOk = FindNextFile(hFind, &dirWDataP->FindData))
				{	err = XWinGetLastError();
					if (err == ERROR_NO_MORE_FILES)
					{	err = noErr;
						SetLastError(noErr);
					}
				}
			}
		}
	}
	else
	{	err = XWinGetLastError();
		if (err == ERROR_FILE_NOT_FOUND)
		{	err = noErr;
			SetLastError(noErr);
		}
	}
	if (hFind != INVALID_HANDLE_VALUE)
		FindClose(hFind);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	OpenXFile(XFilePathPtr filePath, short mode, long permission, Boolean dontUseCache, XFileRef *xrefNumP)
{
XErr		err = noErr;
HANDLE		fileHandle;
XFilePath	fullPath;
DWORD		dwFlags;
WinFRef		*winFRefP = (WinFRef*)xrefNumP;
Boolean		resetErr = false;

	if NOT(err = _GetWinFullPath(filePath, fullPath))
	{	if (permission == READ_PERM)
			permission = GENERIC_READ;
		else
			permission = (GENERIC_READ | GENERIC_WRITE);
		
		switch(mode)
		{	case CREATE_FILE_NEW:
				mode = CREATE_NEW;
				break;
			case CREATE_FILE_ALWAYS:
				mode = CREATE_ALWAYS;
				resetErr = true;
				break;
			case OPEN_FILE_EXISTING:
				mode = OPEN_EXISTING;
				break;
			case OPEN_FILE_ALWAYS:
				mode = OPEN_ALWAYS;
				resetErr = true;
				break;
		}
		
		if (dontUseCache)
		{	dwFlags = FILE_FLAG_WRITE_THROUGH;
			winFRefP->dontUseCache = true;
		}
		else
		{	dwFlags = 0;
			winFRefP->dontUseCache = false;
		}
		
		fileHandle = CreateFile(fullPath, permission, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, mode, dwFlags, NULL);
		if (fileHandle == INVALID_HANDLE_VALUE)
		{	winFRefP->fileHandle = 0L;
			err = XWinGetLastError();
		}
		else
		{	if (resetErr)
			{	err = XWinGetLastError();
				if (err == ERROR_ALREADY_EXISTS)
				{	err = noErr;
					SetLastError(noErr);
				}
			}
			winFRefP->fileHandle = fileHandle;
		}
	}

	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}
	
return err;
}

//===========================================================================================
XErr	CloseXFile(XFileRef *xrefNumP)
{
WinFRef	*winFRefP = (WinFRef*)xrefNumP;
XErr	err = noErr;

	if (winFRefP && (winFRefP->fileHandle != INVALID_HANDLE_VALUE))
	{	if NOT(CloseHandle((HANDLE)winFRefP->fileHandle))
			err = XWinGetLastError();
		else
			winFRefP->fileHandle = INVALID_HANDLE_VALUE;
	}
	else
		err = XError(kXLibError, ErrXFiles_BadFileRef);

return err;
}

//===========================================================================================
XErr	ReadXFile(XFileRef xrefNum, Ptr bufferP, long *bufferLenP)
{
XErr	err = noErr;
DWORD	bytesRead;
WinFRef	*winFRefP = (WinFRef*)&xrefNum;

	if (ReadFile(winFRefP->fileHandle, bufferP, *bufferLenP, &bytesRead, NULL))
	{	if (bytesRead < (DWORD)*bufferLenP)
		{	err = XError(kXLibError, ErrXFiles_EndOfFile);
			*bufferLenP = bytesRead;
		}
	}
	else
		err = XWinGetLastError();
	
return err;
}

//===========================================================================================
XErr	WriteXFile(XFileRef xrefNum, Ptr bufferP, long *bufferLenP)
{
XErr	err = noErr;
WinFRef	*winFRefP = (WinFRef*)&xrefNum;
DWORD	bytesWritten;

	if (WriteFile(winFRefP->fileHandle, bufferP, *bufferLenP, &bytesWritten, NULL))
		*bufferLenP = bytesWritten;
	else
		err = XWinGetLastError();
	
return err;
}

//===========================================================================================
XErr	FlushXFile(XFileRef xrefNum)
{
XErr	err = noErr;
WinFRef	*winFRefP = (WinFRef*)&xrefNum;

	if NOT(winFRefP->dontUseCache)
	{	if NOT(FlushFileBuffers(winFRefP->fileHandle))
			err = XWinGetLastError();
	}

return err;
}

//===========================================================================================
XErr	DeleteXFile(XFilePathPtr filePath)
{
XErr		err = noErr;
XFilePath	fullPath;

	if NOT(err = _GetWinFullPath(filePath, fullPath))
	{	if NOT(DeleteFile(fullPath))
			err = XWinGetLastError();
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

#define	MAX_TRANSFER_BLOCK	(50L * 1024L)	// 50K
//===========================================================================================
XErr	TranferBytes(XFileRef sourceRef, XFileRef destRef)
{	
XErr		err = noErr, readErr = noErr;
long		inCount, eof;
long		totCount;
BlockRef	block;
char		*p;

	if NOT(err = GetXEOF(sourceRef, &eof))
	{	if (eof)
		{	if (block = NewBlockLocked(eof, &err, &p))
			{	//LockBlock(block);
				//p = GetPtr(block);
				if NOT(err = ReadXFile(sourceRef, p, &eof))
					err = WriteXFile(destRef, p, &eof);
				DisposeBlock(&block);
			}
			else	// a pezzi
			{	if (block = NewBlockLocked(MAX_TRANSFER_BLOCK, &err, &p))
				{	//LockBlock(block);
					//p = GetPtr(block);
					totCount = 0;
					do{
							inCount = MAX_TRANSFER_BLOCK;
							readErr = ReadXFile(sourceRef, p, &inCount);
							if (readErr && (readErr != XError(kXLibError, ErrXFiles_EndOfFile)))
								err = readErr;
							else
							{	if ((totCount + inCount) >= eof)
								{	inCount = (eof - totCount);
									readErr = XError(kXLibError, ErrXFiles_EndOfFile);
								}
								err = WriteXFile(destRef, p, &inCount);
								totCount += inCount;
							}
						} while ((readErr == noErr) && (err == noErr));
					DisposeBlock(&block);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_CheckIfFolder(char *newPath, char *oldPath)
{
XErr		err = noErr;
Boolean		isDir;
char		*strP;
long		newPathLen;
Boolean		finalSlash;

	newPathLen = CLen(newPath);
	if (finalSlash = (newPath[newPathLen-1] == '/'))
		isDir = true;
	else
		err = XIsFolder(newPath, &isDir);
	if NOT(err)
	{	if (isDir)
		{	if (strP = strrchr(oldPath, '/'))
			{	if (*(strP+1))
				{	if NOT(finalSlash)
						CAddChar(newPath, '/');
					CAddStr(newPath, strP+1);
				}
			}
		}
	}
	else if (err == XError(kXLibError, ErrXFiles_FileNotFound))
	{	err = noErr;
		SetLastError(noErr);
	}

return err;
}

//===========================================================================================
XErr	MoveXFile(XFilePathPtr oldPath, XFilePathPtr newPath, Boolean replaceExisting)
{
XErr		err = noErr;
XFilePath	oldFullPath, newFullPath;
DWORD		dwFlags;

	if NOT(err = _CheckIfFolder(newPath, oldPath))
	{	if NOT(err = _GetWinFullPath(oldPath, oldFullPath))
		{	if NOT(err = _GetWinFullPath(newPath, newFullPath))
			{	dwFlags = MOVEFILE_COPY_ALLOWED;
				if (replaceExisting)
					dwFlags += MOVEFILE_REPLACE_EXISTING;
				if NOT(MoveFileEx(oldFullPath, newFullPath, dwFlags))
					err = XWinGetLastError();
			}
		}
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

//===========================================================================================
XErr	CopyXFile(XFilePathPtr oldPath, XFilePathPtr newPath, Boolean replaceExisting)
{
XErr		err = noErr;
XFilePath	oldFullPath, newFullPath;
//long		newPathLen;

	if NOT(err = _CheckIfFolder(newPath, oldPath))
	{	if NOT(err = _GetWinFullPath(oldPath, oldFullPath))
		{	if NOT(err = _GetWinFullPath(newPath, newFullPath))
			{	if NOT(CopyFile(oldFullPath, newFullPath, NOT(replaceExisting)))	// NOT(failIfExist)
					err = XWinGetLastError();
			}
		}
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

//===========================================================================================
XErr	RenameXFile(XFilePathPtr oldPath, XFilePathPtr newPath)
{
XErr	err = noErr;

	err = MoveXFile(oldPath, newPath, true);
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}


//===========================================================================================
XErr	GetXEOF(XFileRef xrefNum, long *eofP)
{
WinFRef	*winFRefP = (WinFRef*)&xrefNum;
XErr	err = noErr;
DWORD	len;

	len = GetFileSize(winFRefP->fileHandle, NULL);
	if (len == INVALID_FILE_SIZE)
		err = XWinGetLastError();
	else
		*eofP = len;
	
return err;
}

//===========================================================================================
XErr	SetXEOF(XFileRef xrefNum, long newEOF)
{
WinFRef	*winFRefP = (WinFRef*)&xrefNum;
XErr	err = noErr;

	if (SetFilePointer(winFRefP->fileHandle, newEOF, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER)
		err = XWinGetLastError();
	if NOT(err)
	{	SetEndOfFile(winFRefP->fileHandle);
		err = XWinGetLastError();
	}
	
return err;
}

//===========================================================================================
XErr	GetXResForkSize(XFilePathPtr filePath, long *eofP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(filePath)
#endif

	*eofP = 0;

return noErr;
}

//===========================================================================================
XErr	GetXFileInfo(XFilePathPtr filePath, XFileInfoP xFileInfoP)
{
XFilePath		fullPath;
XErr			err = noErr;
FILETIME		localFileTime;
SYSTEMTIME		sysTime;
char			*filePathP;
int				filePathLen;
WIN32_FILE_ATTRIBUTE_DATA	attribData;

	if NOT(err = _GetWinFullPath(filePath, fullPath))
	{	if (GetFileAttributesEx(fullPath, GetFileExInfoStandard, &attribData))
		{	
			ClearBlock(xFileInfoP, sizeof(XFileInfo));
			FileTimeToLocalFileTime(&attribData.ftCreationTime, &localFileTime);
			FileTimeToSystemTime(&localFileTime, &sysTime);
			NativeDateTime2XDateTime((Ptr)&sysTime, &xFileInfoP->creatDate);

			FileTimeToLocalFileTime(&attribData.ftLastWriteTime, &localFileTime);
			FileTimeToSystemTime(&localFileTime, &sysTime);
			NativeDateTime2XDateTime((Ptr)&sysTime, &xFileInfoP->modifDate);
			
			filePathLen = CLen(fullPath);
			xFileInfoP->isDLL = ((filePathLen > 3) && (
								(*(long*)(filePathP = &fullPath[filePathLen-4]) == 'lld.') || 
								(*(long*)filePathP == 'DLL.') || 
								(*(long*)filePathP == 'Dll.')));
		}
		else
			err = XWinGetLastError();
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

//===========================================================================================
XErr	SetXFileInfo(XFilePathPtr filePath, XFileInfoP xFileInfoP)
{
XFilePath		fullPath;
HANDLE			fileHandle;
XErr			err = noErr;
FILETIME		creatTime, modifTime, fileTime;
SYSTEMTIME		sysTime;

	XDateTime2NativeDateTime(&xFileInfoP->creatDate, (Ptr)&sysTime);
	SystemTimeToFileTime(&sysTime, &fileTime);
	LocalFileTimeToFileTime(&fileTime, &creatTime);

	XDateTime2NativeDateTime(&xFileInfoP->modifDate, (Ptr)&sysTime);
	SystemTimeToFileTime(&sysTime, &fileTime);
	LocalFileTimeToFileTime(&fileTime, &modifTime);
	
	if NOT(err = _GetWinFullPath(filePath, fullPath))
	{	fileHandle = CreateFile(fullPath, GENERIC_READ, FILE_SHARE_READ, 
								NULL, OPEN_EXISTING, FILE_FLAG_NO_BUFFERING, NULL);
		if (fileHandle == INVALID_HANDLE_VALUE)
			err = XWinGetLastError();
		else
		{	SetFileTime(fileHandle, &creatTime, NULL, &modifTime);
			CloseHandle(fileHandle);
			err = XWinGetLastError();
		}
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}
	
return err;
}

//===========================================================================================
XErr	SetXFPos(XFileRef xrefNum, long mode, long offset)
{
WinFRef	*winFRefP = (WinFRef*)&xrefNum;
XErr	err = noErr;

	if (mode == FROM_START)
		mode = FILE_BEGIN;
	else if (mode == FROM_MARK)
		mode = FILE_CURRENT;
	else if (mode == FROM_EOF)
		mode = FILE_END;
	
	if (SetFilePointer(winFRefP->fileHandle, offset, NULL, mode) == INVALID_SET_FILE_POINTER)
		err = XWinGetLastError();

return err;
}

//===========================================================================================
XErr	GetXFPos(XFileRef xrefNum, long *offsetP)
{
WinFRef	*winFRefP = (WinFRef*)&xrefNum;
XErr	err = noErr;
	
	if ((*offsetP = SetFilePointer(winFRefP->fileHandle, 0, NULL, FILE_CURRENT)) == INVALID_SET_FILE_POINTER)
		err = XWinGetLastError();

return err;
}


//===========================================================================================
XErr	GetFileMode(XFileRef xrefNum, XFilePathPtr filePath, long *modeP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(xrefNum, filePath)
#endif

	*modeP = 0xFFFFFFFF;

return noErr;
}
	
//===========================================================================================
XErr	ChangeFileMode(XFileRef xrefNum, XFilePathPtr filePath, long modeFlags)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(xrefNum, filePath, modeFlags)
#endif
return noErr;
}

//===========================================================================================
XErr	XIsFolder(XFilePathPtr path, Boolean *isDirectoryP)
{
XErr						err = noErr;
XFilePath					fullPath;
WIN32_FILE_ATTRIBUTE_DATA	attribData;

	if NOT(err = _GetWinFullPath(path, fullPath))
	{	if (GetFileAttributesEx(fullPath, GetFileExInfoStandard, &attribData))
  			*isDirectoryP = (attribData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
		else
			err = XWinGetLastError();
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

//===========================================================================================
XErr	XIsAlias(XFilePathPtr filePath, Boolean *isAliasP)
{
XErr		err = noErr;
int			filePathLen;
char		*filePathP;

	filePathLen = CLen(filePath);
	*isAliasP = ((filePathLen > 3) && ((*(long*)(filePathP = &filePath[filePathLen-4]) == 'knl.') || (*(long*)filePathP == 'KNL.')));

return err;
}

//===========================================================================================
/* 
nFileSizeHigh:
	Specifies the high-order DWORD of the file size. 
nFileSizeLow:
	Specifies the low-order DWORD of the file size
*/
XErr	GetXEOFFromPath(XFilePathPtr filePath, long *eofP)
{
XErr						err = noErr;
XFilePath					fullPath;
WIN32_FILE_ATTRIBUTE_DATA	attribData;

	if NOT(err = _GetWinFullPath(filePath, fullPath))
	{	if (GetFileAttributesEx(fullPath, GetFileExInfoStandard, &attribData))
			*eofP = attribData.nFileSizeLow;
		else
			err = XWinGetLastError();
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

//===========================================================================================
XErr	RenameXFolder(XFilePathPtr folderPath, char *newName)
{
XErr		err = noErr;
char		*strP;
XFilePath	finalPath;
int			cLen;

	CEquStr(finalPath, folderPath);
	cLen = CLen(finalPath);
	if (finalPath[cLen-1] == '/')
		finalPath[cLen-1] = 0;
	if (strP = strrchr(finalPath, '/'))
	{	*(strP+1) = 0;
		CAddStr(finalPath, newName);
		err = RenameXFile(folderPath, finalPath);
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

/*
//===========================================================================================
XErr	LockXFile(XFileRef xrefNum, long start, long length, Boolean wait)
{
WinFRef	*winFRefP = (WinFRef*)&xrefNum;
XErr	err = noErr;
	
	if NOT(LockFile(winFRefP->fileHandle, start, 0, length, 0))
		err = XWinGetLastError();

return err;
}

//===========================================================================================
XErr	UnlockXFile(XFileRef xrefNum, long start, long length)
{
WinFRef	*winFRefP = (WinFRef*)&xrefNum;
XErr	err = noErr;
	
	if NOT(UnlockFile(winFRefP->fileHandle, start, 0, length, 0))
		err = XWinGetLastError();

return err;
}
*/

//===========================================================================================
XErr	LockXFile(XFileRef xrefNum, long start, long length, Boolean wait)
{
WinFRef			*winFRefP = (WinFRef*)&xrefNum;
XErr			err = noErr;
long			flags;
OVERLAPPED		ov = {0, 0, 0, 0, NULL};

	ov.Offset = start;
	if (wait)
		flags = LOCKFILE_EXCLUSIVE_LOCK;
	else
		flags = LOCKFILE_EXCLUSIVE_LOCK + LOCKFILE_FAIL_IMMEDIATELY;
	if NOT(LockFileEx(winFRefP->fileHandle, flags, 0, length, 0, &ov))
		err = XWinGetLastError();

return err;
}

//===========================================================================================
XErr	UnlockXFile(XFileRef xrefNum, long start, long length)
{
WinFRef			*winFRefP = (WinFRef*)&xrefNum;
XErr			err = noErr;
OVERLAPPED		ov = {0, 0, 0, 0, NULL};
	
	ov.Offset = start;
	if NOT(UnlockFileEx(winFRefP->fileHandle, 0, length, 0, &ov))
		err = XWinGetLastError();

return err;
}
//===========================================================================================
XErr	IsXFileOpen(XFilePathPtr filePath, Boolean *isOpenP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(filePath, isOpenP)
#endif
XErr			err = noErr;

	err = XError(kXLibError, ErrNotImplementedInXLib);

return err;
}

#include <Shellapi.h>
//===========================================================================================
XErr	XMakeAlias(XFilePathPtr filePath, XFilePathPtr aliasPath)
{
XErr		err = noErr;

/*#ifdef __VISUALCPP__
	if NOT(err = _GetWinFullPath(filePath, fullFilePath))
	{	if NOT(err = _GetWinFullPath(aliasPath, fullAliasPathPath))
			err = CreateLink(fullFilePath, fullAliasPathPath, "");
	}
#else*/
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(filePath, aliasPath)
#endif
	err = XError(kXLibError, ErrNotImplementedInXLib);
//#endif

return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	CreateXFolder(XFilePathPtr folderPath)
{
XErr		err = noErr;
XFilePath	fullFolderPath;

	if NOT(err = _GetWinFullPath(folderPath, fullFolderPath))
	{	if NOT(CreateDirectory(fullFolderPath, 0L))
			err = XWinGetLastError();
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

//===========================================================================================
XErr	DeleteXFolder(XFilePathPtr folderPath)
{
XErr		err = noErr;
XFilePath	fullFolderPath;

	if NOT(err = _GetWinFullPath(folderPath, fullFolderPath))
	{	if NOT(RemoveDirectory(fullFolderPath))
			err = XWinGetLastError();
	}
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}
	
return err;
}

//===========================================================================================
XErr	WalkXFolder(XFilePathPtr folderPath, char *suffix, Boolean recursive, 
											WalkXFolderCallBack callBack, long userData)
{
DIRWALKDATA		dirWalkData;
XErr			err = noErr;
CStr31			thesuffix;

	dirWalkData.fRecurse = recursive;
	dirWalkData.callBack = callBack;
	dirWalkData.userData = userData;
	if (folderPath[CLen(folderPath)-1] != '/')
		CAddChar(folderPath, '/');
	if NOT(err = _GetWinFullPath(folderPath, dirWalkData.strMask))
	{	if NOT(err = _GetSearchTextPath(dirWalkData.strMask))	
		{	WFPrepareFilter(suffix, thesuffix);
			err = _FolderWalkRecurse(&dirWalkData, folderPath, thesuffix);
		}
	}
	if (err == XError(kXLibError, ErrXFiles_WalkFolderAbort))
		err = noErr;
	if (err)
	{	if (err == ERROR_FILE_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FileNotFound);
		else if (err == ERROR_PATH_NOT_FOUND)
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
	}

return err;
}

//===========================================================================================
XErr	GetXApplicationCurrentDir(XFilePathPtr xAppCurrentDir)
{
int		res;
XErr	err = noErr;

	res = GetCurrentDirectory(255, xAppCurrentDir);
	if (NOT(res) || (res > 255))
		err = XWinGetLastError();
	else
	{	FilePathWin32ToXLib(xAppCurrentDir);
		if (xAppCurrentDir[CLen(xAppCurrentDir)-1] != '/')
			CAddChar(xAppCurrentDir, '/');
	}
	
return err;
}

//===========================================================================================
XErr	CheckPath(XFilePathPtr path, Boolean resolveAlias)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(resolveAlias)
#endif
XErr		err = noErr;
//XFileInfo	fileInfo;
DWORD		fileAttr;
XFilePath	fullPath;

	if NOT(err = _GetWinFullPath(path, fullPath))
	{	fileAttr = GetFileAttributes(fullPath);
		if (fileAttr == 0xFFFFFFFF)
			err = XWinGetLastError();
		/*
		if NOT(err)
		{	if (resolveAlias)
			{
		#ifdef __VISUALCPP__
				CStr255		tempPath;
			
				CEquStr(tempPath, fullPath);
				err = ResolveIt(tempPath, fullPath);
		#else
			err = XError(kXLibError, ErrNotImplementedInXLib);
		#endif
			}
		}
		*/
	}
	if (err == ERROR_FILE_NOT_FOUND)
	{	if (path[CLen(path) - 1] == '/')
			err = XError(kXLibError, ErrXFiles_FolderNotFound);
		else
			err = XError(kXLibError, ErrXFiles_FileNotFound);
	}
	else if (err == ERROR_PATH_NOT_FOUND)
		err = XError(kXLibError, ErrXFiles_FolderNotFound);
	if (err)
		SetLastError(noErr);

return err;
}

//===========================================================================================
// per ora questa � usata per sapere dove sta BisJava.dll (la dll con 
// le native di BisJava.jar) che su Mac deve
// stare nella cartella estensioni.
XErr	XGetExtensionsFolderPath(XFilePathPtr extensionsPath)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(extensionsPath)
#endif

	CDebugStr("Win32 has no Extension Folder");

return noErr;
}
