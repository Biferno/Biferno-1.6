/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XStringsWin.c,v 1.2 2003-06-24 08:55:27 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

#include <stdio.h>

//===========================================================================================
int		GetSeparators(Byte *theDecSep, Byte *theThousSep, char *sepDate, char *sepTime)
{
char 	cName[] = "intl";
UINT	dateOrder;
char	str[2];

	if (theDecSep)
	{	GetProfileString(cName, "sDecimal",  ",", str, 2);
		*theDecSep = *str;
	}
	if (theThousSep)
	{	GetProfileString(cName, "sThousand",  ".", str, 2);
		*theThousSep = *str;
	}
	if (sepDate)
		GetProfileString(cName, "sDate",  "/", sepDate, 2);
	if (sepTime)
		GetProfileString(cName, "sTime",  ":", sepTime, 2);
	
	/*
	Note: on Windows possible values of dateOrder seems to be only:
		_MDY
		_DMY
		_YMD
	(see Petzold page 345)
	*/
	dateOrder = GetProfileInt(cName, "iDate", 0);
	
return dateOrder;
}
#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
void		PNumToString(long num, StringPtr str)
{
CStr255		cStr;
	
	sprintf(cStr, "%ld", num);
	CToPascal(cStr, str);
}

//===========================================================================================
void		PStringToNum(StringPtr str, long *numP)
{
CStr255		cStr;

	PascalToC(str, cStr);
	*numP = atoi(cStr);
}

//===========================================================================================
void 		PRealToStr(double *d, StringPtr sP, short digits)
{
CStr255		cStr;
CStr15		formatStr;
Str15		digStr;
	
	CEquStr(formatStr, "%.");
	PNumToString(digits, digStr);
	AddPascalToCStr(formatStr, digStr);
	CAddStr(formatStr, "f");
	sprintf(cStr, formatStr, d);
	CToPascal(cStr, sP);
}

//===========================================================================================
/*double 		PStrToReal(const StringPtr sP)
{
CStr255		cStr;

	PascalToC(sP, cStr);
	return atof(cStr);
}*/
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void		CNumToString(long num, char *str)
{
	sprintf(str, "%ld", num);
}

//===========================================================================================
void		CStringToNum(char *str, long *numP)
{
	*numP = atoi(str);
}

//===========================================================================================
void 		CRealToStr(double *d, char *sP, short digits)
{
CStr15		formatStr;
Str15		digStr;
	
	CEquStr(formatStr, "%.");
	PNumToString(digits, digStr);
	AddPascalToCStr(formatStr, digStr);
	CAddStr(formatStr, "f");
	sprintf(sP, formatStr, *d);
}

//===========================================================================================
/*double 		CStrToReal(const char *sP)
{
double		res;

	res = atof(sP);

return res;
}*/

#if __MWERKS__
#pragma mark-
#endif

//============================================================
void	PDebugStr(StringPtr	stringMessage)
{
CStr255	cStr;

	PascalToC(stringMessage, cStr);
	OutputDebugString(cStr);
	DebugBreak();
	/*printf(cStr);
	DebugBreak();*/
}

//============================================================
void	CDebugStr(char	*stringMessage)
{
	OutputDebugString(stringMessage);
	DebugBreak();
	/*
	printf(stringMessage);
	// exit(0);
	DebugBreak();
	*/
}

