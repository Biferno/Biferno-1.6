/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XDLLWin.c,v 1.5 2008-02-12 14:20:46 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

#include "XFilesWinPrivate.h"

//===========================================================================================
// Note that if name ends with ".DLL" Win32 looks for the dll in the
// "registry" (see Richter pag. 534-535).
// dwFlags tell to the system not to resolve DllMain
/*
This standard strategy searches for a file in the following sequence:

1.	The directory from which the application loaded.

2.	The current directory. 
	Windows XP: If HKLM\System\CurrentControlSet\Control\SessionManager\SafeDllSearchMode 
	is 1, the current directory is searched after the system and Windows directories, but before 
	the directories in the PATH environment variable. The default value is 0 
	(current directory is searched before the system and Windows directories).

3.	The system directory. Use the GetSystemDirectory function to get the path of this 
	directory. 
	Windows NT/2000/XP: The name of this directory is System32.

4.	Windows NT/2000/XP: The 16-bit system directory. There is no function that obtains the 
	path of this directory, but it is searched. The name of this directory is System.

5.	The Windows directory. Use the GetWindowsDirectory function to get the path of this 
	directory.

6.	The directories that are listed in the PATH environment variable.
*/
XErr	XLoadDLL(XFilePathPtr dllPath, long *dllRef, char *errString, long *xlibVersion, Boolean macosxBundle)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(macosxBundle)
#endif
HANDLE		hLibrary;
DWORD		dwFlags = LOAD_WITH_ALTERED_SEARCH_PATH;
XErr		err = noErr;
XFilePath	dllFullPath;
CStr255		tempStr;
int			avail;

	if (errString)
		*errString = 0;
	if (strchr(dllPath, '/'))
	{	if (err = _GetWinFullPath(dllPath, dllFullPath))
			return err;
	}
	else
		CEquStr(dllFullPath, dllPath);
	if (hLibrary = LoadLibraryEx(dllFullPath, NULL, dwFlags))
	{	*dllRef = (long)hLibrary;
		if (xlibVersion)
			err = RegisterDllXLib((long)hLibrary, errString, xlibVersion, false);
	}
	else
		err = XWinGetLastError();
	
if (err && errString)
{
	if (*errString)
	{
		CEquStr(tempStr, errString);
		XErrorGetDescr(err, errString, nil);
		avail = 255 - 2 - CLen(errString);
		if (CLen(tempStr) > avail)
			tempStr[avail] = 0;
		CAddChar(errString, '(');
		CAddStr(errString, tempStr);
		CAddChar(errString, ')');
	}
	else
		XErrorGetDescr(err, errString, nil);
}
return err;
}

//===========================================================================================
XErr	XGetDLLSymbol(long dllRef, char *entryPointSymbol, long *entryPointP, Boolean macosxBundle)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(macosxBundle)
#endif
HANDLE	hLibrary = (HANDLE)dllRef;
XErr	err = noErr;
CStr255	debugString;

	if (entryPointP)
	{	*entryPointP = (long)GetProcAddress(hLibrary, entryPointSymbol);
		if NOT(*entryPointP)
			err = XWinGetLastError();
	}
	
if (err)
	XErrorGetDescr(err, debugString, nil);
return err;
}

//===========================================================================================
XErr	XFreeDLL(long *dllRef, Boolean macosxBundle)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(macosxBundle)
#endif
XErr	err = noErr;

	if NOT(FreeLibrary((HANDLE)(*dllRef)))
		err = XWinGetLastError();
	else
		*dllRef = 0;
		
return err;
}




