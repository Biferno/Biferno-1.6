/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XSocketsWin.c,v 1.12 2008-11-14 11:20:43 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"
//#if WIN_SERVICE
//	#include 	"XLibServices.h"
//#endif

#ifdef __XLIB_WITH_HELPERS__

#include <signal.h>
#include <stdio.h>

#ifdef USE_WIN_DNS
	#ifdef __VISUALCPP__
		/*
		VisualC (6) has not windns.h.
		*/
		#ifndef DNS_INFO_NO_RECORDS
			#define DNS_INFO_NO_RECORDS              9501L	// mmh...
		#endif
	#endif
	#include <Windns.h>
#endif

typedef struct {
				long						userData;
				long						socket;
				ProcessClientRequest_Func	func;
				} SocketParamData, *SocketParamDataP;

static 	long		gNConnection = 0;
static	Boolean		gPrefixed, gsStopServer = false;
static	int			gServerSocket = 0;

extern	Boolean		gExitForced;

struct sockaddr_un 
{
	short	sun_family;
	char	sun_path[104];
};

#define	kYieldTimeout		(unsigned long)(1000L * 30L)	// milliseconds (= 30 secs)

#ifdef USE_WIN_DNS

typedef DNS_STATUS (WINAPI *DnsQuery_A_Func)(
    IN      LPSTR           pszName,
    IN      WORD            wType,
    IN      DWORD           Options,
    IN      PIP4_ARRAY      aipServers            OPTIONAL,
    IN OUT  PDNS_RECORD *   ppQueryResults        OPTIONAL,
    IN OUT  PVOID *         pReserved             OPTIONAL
    );

typedef VOID (WINAPI *DnsRecordListFree_Func)(
    IN OUT  PDNS_RECORD     pRecordList,
    IN      DNS_FREE_TYPE   FreeType
    );

static DnsQuery_A_Func			DnsQuery_A_EP = nil;
static DnsRecordListFree_Func	DnsRecordListFree_EP = nil;
static long						g_LibDNS = 0;

//===========================================================================================
void	_UnloadDNS_EPs(void)
{
	if (g_LibDNS)
		XFreeDLL(&g_LibDNS, false);
}

//===========================================================================================
static XErr	_LoadDNS_EPs(void)
{
CStr255		errString;
XErr		err = noErr;

	if NOT(g_LibDNS)
	{	if NOT(err = XLoadDLL("dnsapi.dll", &g_LibDNS, errString, nil, false))
		{	if NOT(err = XGetDLLSymbol(g_LibDNS, "DnsQuery_A", (long*)&DnsQuery_A_EP, false))
				err = XGetDLLSymbol(g_LibDNS, "DnsRecordListFree", (long*)&DnsRecordListFree_EP, false);
		}
	}

return err;
}

//===========================================================================================
XErr	GetMXRecords(CStr255 domain, MXRecord *mxRecordP, long *mxtot)
{
XErr			err = noErr;
PDNS_RECORD		dnsRecordP = nil, saveDnsRecordP;
int				i, max;
PDNS_MX_DATA	dns_mx_dataP;
MXRecord		*saveMxRecordP;

	if (err = _LoadDNS_EPs())
		return err;
		
	err = DnsQuery_A_EP(domain, DNS_TYPE_MX, DNS_QUERY_STANDARD, NULL, &dnsRecordP, NULL);
	if (err == ERROR_SUCCESS)
	{	saveDnsRecordP = dnsRecordP;
		max = *mxtot;
		i = 0;
		saveMxRecordP = mxRecordP;
		do
		{	if (dnsRecordP->wType == DNS_TYPE_MX)
			{	dns_mx_dataP = &dnsRecordP->Data.MX;
				CEquStr(mxRecordP->name, dns_mx_dataP->pNameExchange);
				mxRecordP->preference = dns_mx_dataP->wPreference;
				mxRecordP++;
				i++;
			}
		} while ((i < max) && (dnsRecordP = dnsRecordP->pNext));
		*mxtot = i;
		DnsRecordListFree_EP(saveDnsRecordP, DnsFreeRecordListDeep);
	}
	else if (err == DNS_INFO_NO_RECORDS)
	{	*mxtot = i = 0;
		err = noErr;
	}
	if (err)
		*mxtot = 0;
	else if (i)
		SortMXRecords(saveMxRecordP, i);

return err;
}
#endif
#if __MWERKS__
#pragma mark-
#endif

//extern CStr255		globalErrStr;

//extern	int	(*pthread_detach_EP)(pthread_t thread);

// se def PER_THREAD_ACCEPT c'� un baco (bomba dopo un po' se NetSplatti!)
//#define	PER_THREAD_ACCEPT	1
//===========================================================================================
// la prima long � la lunghezza da mandare (la prima long esclusa)
static void	_dump(char *p, long len, long id)
{
CStr255		path, tStr;
XFileRef	refNum;
XErr		err = noErr;

	CEquStr(path, "/home/valerio/BifernoHome/MyDump");
	//CAddStr(path, "/MyDump");
	CNumToString(id, tStr);
	CAddStr(path, tStr);
	CAddStr(path, ".txt");
	if (len)
	{	if NOT(err = OpenXFile(path, CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &refNum))
		{	err = WriteXFile(refNum, p, &len);
			CloseXFile(&refNum);
		}
	}
}

//===========================================================================================
/*static void	sock_ntop(const struct sockaddr *sa, socklen_t salen, char *str)
{
	// da fare
	*str = 0;
	switch(sa->sa_family)
	{
		case AF_INET:
			{
			struct sockaddr_in	*sin = (struct sockaddr_in	*)sa;
				
				inet_ntop(AF_INET, &sin->sin_addr, str, 255);
			}
			break;
	}

}*/

#ifdef PER_THREAD_ACCEPT
//===========================================================================================
static void*	_processClientRequest(void* param_dataP)
{
SocketParamDataP	sockParamP = param_dataP;
BlockRef			block;
long				totLen;
XErr				err = noErr;
int					clilen, addrlen, c_socket;
struct sockaddr		caddr;
	
	addrlen = sizeof(struct sockaddr);
	for (;NOT(err);)
	{	clilen = addrlen;
		//pthread_mutex_lock(&gsSocketAcceptMutex);
		c_socket = accept(sockParamP->socket, &caddr, &clilen);
		if (gsStopServer)
			break;
		gNConnection++;
		//pthread_mutex_unlock(&gsSocketAcceptMutex);
		err = XSocketsReceive(c_socket, &block, &totLen, gPrefixed, nil);
		if NOT(err)
		{	
			/*
			BlockRef	bl;
			long		tLen;
			CStr255		aCStr;
			
			CEquStr(aCStr, "bella giornata");
			tLen = CLen(aCStr);
			if (bl = NewBlock(tLen, &err))
			{	CopyBlock(GetPtr(bl), aCStr, tLen);
				XServerSendToClient(c_socket, bl, tLen);
				DisposeBlock(&bl);
			*/
			sockParamP->func(c_socket, block, totLen, sockParamP->userData);
			DisposeBlock(&block);
			XThreadsEnterCriticalSection();
			shutdown(c_socket, 2);
			closesocket(c_socket);
			gNConnection--;
			XThreadsLeaveCriticalSection();
			//}
		}	
	}
	System_EnterCS();
	free(param_dataP);
	System_LeaveCS();

return (void*)err;
}
#else
//===========================================================================================
static void*	_processClientRequest(void* param_dataP)
{
SocketParamDataP	sockParamP = param_dataP;
BlockRef			block;
long				totLen;
XErr				err = noErr;

	if NOT(err = XSocketsReceive(sockParamP->socket, &block, &totLen, gPrefixed, nil, 0))
	{	sockParamP->func(sockParamP->socket, block, totLen, sockParamP->userData);
		DisposeBlock(&block);
		XThreadsEnterCriticalSection();
		shutdown(sockParamP->socket, 2);
		closesocket(sockParamP->socket);
		free(param_dataP);
		gNConnection--;
		XThreadsLeaveCriticalSection();
	}	

return (void*)err;
}
#endif

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*
static void	io_handler(int signo)
{
}

#if __MWERKS__
#pragma mark-
#endif

*/

//===========================================================================================
XErr	XStopServer(void)
{
	gsStopServer = true;
	//WSACleanup();
	
return noErr;
}

//===========================================================================================
// Client request must 0 terminated
// server_port == 0 => Unix Protocol (only local)
XErr	XServerLoop(long server_port, long listen_queue, ProcessClientRequest_Func proc_func, long userData, Boolean prefixed, Boolean onlyLocal, char *unixfile, char *errString)
{
XErr				err = noErr;
int					s_socket = -1;
int					opt = 1;
unsigned long		threadID, lastTicks = 0, initMilliSecs, millisecs;
SocketParamDataP	sockParamP;
CStr255				localAddr, remoteAddr;
struct sockaddr_in	saddr;
struct sockaddr		caddr;
int					c_socket;
int					addrlen;
//#if WIN_SERVICE
//	unsigned long lastSCMUpdate = 0;
//#endif

	if (errString)
		*errString = 0;
	// first, we get a socket to play with
	if (server_port)
		s_socket = socket(PF_INET, SOCK_STREAM, 0);
	else
		s_socket = socket(AF_UNIX, SOCK_STREAM, 0);
	if (s_socket < 0)
	{	err = XWinGetLastError();
		return err;
	}
	
	gServerSocket = s_socket;
	gPrefixed = prefixed;
	// asyncronous
	/*
	signal(SIGIO, io_handler);
	errno = 0;
	if (fcntl(s_socket, F_SETOWN, getpid()) < 0)
		return errno;
	errno = 0;
	if (fileFlags = fcntl(s_socket, F_GETFL) == -1)
		return errno;
	errno = 0;
	if (fcntl(s_socket, F_SETFL, fileFlags | FNDELAY | FASYNC) == -1)
		return errno;
	*/

	// now we set the members of the sockaddr_in struct
	if (server_port)
	{	saddr.sin_family = AF_INET;
		saddr.sin_addr.s_addr = INADDR_ANY;
		saddr.sin_port = htons((unsigned short)server_port);
		// we need to set some socket options too
		if ((setsockopt(s_socket, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(int))) < 0)
			return XWinGetLastError();
		
		// now we bind to the address and port from above */
		if ((bind(s_socket, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in))) < 0)
			return XWinGetLastError();
	}
	else
	{
	struct sockaddr_un	un_saddr;
	
		_unlink(unixfile);
		ClearBlock(&un_saddr, sizeof(un_saddr));
		un_saddr.sun_family = AF_UNIX;
		strcpy(un_saddr.sun_path, unixfile);
		if ((bind(s_socket, (struct sockaddr*)&un_saddr, sizeof(un_saddr))) < 0)
			 XWinGetLastError();
		/*if (chmod(unixfile, S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IWGRP|S_IXGRP|S_IROTH|S_IWOTH|S_IXOTH) == -1)
		{	if (errString)
				CEquStr(errString, "chmod on Unix AF_LOCAL file failed");
			err = XWinGetLastError();
		}*/
	}
	
	// we are the server so we must listen on this socket
	if ((listen(s_socket, listen_queue)) < 0)
		return XWinGetLastError();

#ifdef	PER_THREAD_ACCEPT
	{
	int		i;
	
		for (i = 0; i < listen_queue; i++)
		{	if (sockParamP = (SocketParamDataP)malloc(sizeof(SocketParamData)))
			{	sockParamP->userData = userData;
				sockParamP->socket = (long)s_socket;
				sockParamP->func = proc_func;
				err = XNewThread(&threadID, nil, _processClientRequest, 1024L * 256L, (void*)sockParamP);
			}
		}	
		if NOT(err)
		{	for (;;)
				;//pause();
		}
	}
#else
{	
	addrlen = sizeof(struct sockaddr_in);
	// we want buffer space
	//gServerInLoop = true;
	for(;NOT(err);)
	{	
	/*#if WIN_SERVICE
		if ((GetTickCount() - lastSCMUpdate) >= CS_TIMEOUT)
		{	UpdateStatus (-1, -1);  // Increment the checkpoint
			lastSCMUpdate = GetTickCount();
		}
	#endif*/

		// accept returns a "copy" of the socket to work with
		c_socket = accept(s_socket, &caddr, &addrlen);
		if (c_socket == INVALID_SOCKET)
		{	err = WSAGetLastError();
			if (err == WSAEINTR)	// used to stop the server
			{	err = noErr;
				break;
			}
		}
		if NOT(err)
		{	if NOT(err = XLocalAddress(c_socket, localAddr))
			{	if NOT(err = XRemoteAddress(c_socket, remoteAddr))
				{	if (onlyLocal && CCompareStrings_cs(remoteAddr, localAddr))
					{	if (send(c_socket, "Forbidden", 9, 0) < 0)
							err = XWinGetLastError();
					}
					else
					{	if (sockParamP = (SocketParamDataP)malloc(sizeof(SocketParamData)))
						{	sockParamP->userData = userData;
							sockParamP->socket = (long)c_socket;
							sockParamP->func = proc_func;
							gNConnection++;
							if (gsStopServer)
								_processClientRequest((void*)sockParamP);
							else
								err = XNewThread(&threadID, nil, _processClientRequest, 1024L * 256L, (void*)sockParamP);
							if (err)
								;//TRACEN("err", err, 0)
						}
						else
							err = -1;
					}
				}
			}
		}
		if (err)
		{
			proc_func((long)c_socket, 0, err, userData);
			err = noErr;	// continue
		}
		if (gsStopServer)
			break;
	}
	XGetMilliseconds(&initMilliSecs);
	while ((gNConnection > 0) && NOT(gExitForced))
	{	XYield(&lastTicks);
		XGetMilliseconds(&millisecs);
		if ((millisecs - initMilliSecs) > kYieldTimeout)
			break;
	}
	//gServerInLoop = false;
}       
#endif

return err;
}

//===========================================================================================
XErr	XServerSendToClient(long socketRef, BlockRef buffToSend, long buffToSendLength)
{
int		c_socket = (int)socketRef;
XErr	err = noErr;
	
	err = XSocketsSend(socketRef, buffToSend, buffToSendLength);
		
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// server_port == 0 => Unix Protocol (only local)
XErr	XClientCall(char *serverAddr, long server_port, BlockRef dataToSend, long dataToSendLen, BlockRef *serverResponseP, long *serverResponseLenP, char *unixfile, char *errString, ReceiveCompleteCallBack completeCallBack, long completeCallBackParam, long timeout_secs, Boolean expectPrefixed)
{
int					c_socket = INVALID_SOCKET;
//struct				hostent *shost=NULL;
XSafeHostent		shost;
CStr255				thisServerAddr;
char				*servP;
XErr				err = noErr;
struct sockaddr_in 	saddr;
unsigned long		start_ms, timeout_ms, diff;

	if (errString)
		*errString = 0;
	*serverResponseP = 0;
	*serverResponseLenP = 0;
	
	// Server address
	if (server_port)
	{	if (serverAddr && *serverAddr)
			servP = serverAddr;
		else
		{	System_EnterCS();
			if (gethostname(thisServerAddr, 255) < 0)
				err = XWinGetLastError();
			else
				servP = thisServerAddr;
			System_LeaveCS();
		}
	}
	
	if NOT(err)
	{
		// Let's create a new client socket
		System_EnterCS();
		if (server_port)
			c_socket = socket(PF_INET, SOCK_STREAM, 0);
		else
			c_socket = socket(AF_UNIX, SOCK_STREAM, 0);
		if (c_socket == INVALID_SOCKET)
			err = XWinGetLastError();
		System_LeaveCS();
		if NOT(err)
		{	// we need the client to know about the server
			System_EnterCS();
			err = GetHostByNameSafe(servP, &shost);
			
			//if ((shost = gethostbyname(servP)) == NULL)
			//	err = XWinGetLastError();
			
			/*if (err)
			{	CEquStr(globalErrStr, "Can't resolve host by name: ");
				CAddStr(globalErrStr, servP);
			}*/
			System_LeaveCS();
			if NOT(err)
			{	if (server_port)
				{	System_EnterCS();
					saddr.sin_family = AF_INET;
					memcpy(&saddr.sin_addr, shost.h_addr_list0, shost.h_length);
					saddr.sin_port = htons((unsigned short)server_port);
					// now we connect to the server
					if ((connect(c_socket, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in))) < 0)
					{	if (timeout_secs)
						{	start_ms = GetTickCount();
							timeout_ms = timeout_secs * 1000;
							do
							{	if ((connect(c_socket, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in))) < 0)
								{	diff = GetTickCount() - start_ms;
									if (diff > timeout_ms)
										err = XWinGetLastError();
									else
										SetLastError(noErr);
								}
								else
									break;
							} while NOT(err);
						}
						else
							err = XWinGetLastError();
					}
					System_LeaveCS();
				}
				else
				{
				struct sockaddr_un un_saddr;
				
					System_EnterCS();
					ClearBlock(&un_saddr, sizeof(un_saddr));
					un_saddr.sun_family = AF_UNIX;
					strcpy(un_saddr.sun_path, unixfile);
					if ((connect(c_socket, (struct sockaddr*)&un_saddr, sizeof(un_saddr))) < 0)
						err = XWinGetLastError();
					System_LeaveCS();
				}
			}
			if NOT(err)
			{	if (timeout_secs)
				{
				struct timeval tv;
				
					tv.tv_sec = timeout_secs * 1000;	// Win uses milliseconds
					tv.tv_usec = 0;
					if (setsockopt(c_socket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv)) < 0)
						err = XWinGetLastError();
				}
				// send
				if NOT(err = XSocketsSend(c_socket, dataToSend, dataToSendLen))
				{	// receive
					err = XSocketsReceive(c_socket, serverResponseP, serverResponseLenP, expectPrefixed, completeCallBack, completeCallBackParam);
				}
			}
		}
	}

//out:
if (c_socket != INVALID_SOCKET)
	closesocket(c_socket);
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	XLocalAddress(long socketRef, char *addr)
{
XErr			err = noErr;
struct sockaddr	*clientAddr;
int				len;

	clientAddr = malloc(255);
	len = 255;
	if (getsockname(socketRef, clientAddr, &len) == SOCKET_ERROR)
		err = WSAGetLastError();
	CopyBlock(addr, clientAddr, len);
	free(clientAddr);
	
return err;
}

//===========================================================================================
XErr	XRemoteAddress(long socketRef, char *addr)
{
XErr			err = noErr;
struct sockaddr	*clientAddr;
int				len;

	clientAddr = malloc(255);
	len = 255;
	if (getpeername(socketRef, clientAddr, &len) < 0)
		err = WSAGetLastError();
	CopyBlock(addr, clientAddr, len);
	free(clientAddr);
	
return err;
}

#endif // __XLIB_WITH_HELPERS__

