/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XUtilsWin.c,v 1.12 2004-05-20 11:27:06 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

/*#include <io.h>
#include <stdio.h>
#include <iostream.h>
#include <fstream.h>
#include <fcntl.h>*/

//===========================================================================================
// timeout in milliseconds
XErr	XLaunchProcess(char *executablePath, char *commandLineString, Boolean waitEnd, unsigned long timeout_ms)
{
XErr					err = noErr;
STARTUPINFO				si;
PROCESS_INFORMATION		piProcessB;
DWORD					result;
int						executablePathLen, commandLineStringLen, totLen;
Ptr						saveP, textP;
BlockRef				block;

	FilePathXLibToWin32(executablePath);
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	// Copy executablePath on commandLineString
	executablePathLen = CLen(executablePath);
	commandLineStringLen = CLen(commandLineString);
	totLen = 1 + executablePathLen + 1 + 1 + commandLineStringLen + 1;
	if (block = NewBlock(totLen, &err, &textP))
	{	saveP = textP;
		*textP++ = '\"';
		CopyBlock(textP, executablePath, executablePathLen);
		textP += executablePathLen;
		*textP++ = '\"';
		*textP++ = ' ';
		CopyBlock(textP, commandLineString, commandLineStringLen);
		textP += commandLineStringLen;
		*textP = 0;
		if NOT(CreateProcess(executablePath, saveP, NULL, NULL, false, 0L, NULL, NULL, &si, &piProcessB))
			err = GetLastError();
		else
		{	if (waitEnd)
			{	result = WaitForSingleObject(piProcessB.hProcess, timeout_ms);
				if (result == WAIT_FAILED)
					err = XWinGetLastError();
				else if (result == WAIT_TIMEOUT)
					err = XError(kXLibError, ErrXThreads_Timeout);
			}
		}
		DisposeBlock(&block);
	}
	/*
		{
		if (waitEnd)
			{
			DWORD lpExitCode;
			int		cnt = 0;
			unsigned long tempo	= 0;
			do	{
				if ((GetTickCount() - tempo) > 100)
					{
					tempo	= GetTickCount();
					if not(GetExitCodeProcess(piProcessB.hProcess, &lpExitCode))
						{
						err = GetLastError();
						break;
						}
					cnt++;
					}
				} while(lpExitCode == STILL_ACTIVE);
			}
		if (not(CloseHandle(piProcessB.hProcess)) && not(err))
			err = GetLastError();
		if (not(CloseHandle(piProcessB.hThread)) && not(err))
			err = GetLastError();
		}
	*/

return err;
}

//===========================================================================================
void	XGetSysInfo(char *sysStr)
{
OSVERSIONINFO 		versionInfo;
DWORD				dwMajorVersion, dwMinorVersion;
CStr255				aCStr;

	*sysStr = 0;
	versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if (GetVersionEx(&versionInfo))
	{	dwMajorVersion = versionInfo.dwMajorVersion;
		dwMinorVersion = versionInfo.dwMinorVersion;
		switch(dwMajorVersion)
		{
			case 3:
				if (dwMinorVersion == 51)
					CEquStr(sysStr, "Windows NT 3.51 - ");
				break;
			case 4:
				if (dwMinorVersion == 0)
				{	if (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
						CEquStr(sysStr, "Windows 95 - ");
					else if (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
						CEquStr(sysStr, "Windows NT 4.0 - ");
				}
				else if (dwMinorVersion == 10)
					CEquStr(sysStr, "Windows 98 - ");
				else if (dwMinorVersion == 90)
					CEquStr(sysStr, "Windows ME - ");
				else
					CEquStr(sysStr, "Windows > ME - ");	
				break;
			case 5:
				if (dwMinorVersion == 0)
					CEquStr(sysStr, "Windows 2000 - ");
				else if (dwMinorVersion == 1)
					CEquStr(sysStr, "Windows XP/.NET Server - ");
				else if (dwMinorVersion == 2)
					CEquStr(sysStr, "Windows 2003 - ");
				else
					CEquStr(sysStr, "Windows > 2003 - ");	
				break;
			default:
				CEquStr(sysStr, "Windows [Unknown] - ");
				break;
		}
		CNumToString(versionInfo.dwBuildNumber, aCStr);
		CAddStr(sysStr, "Build Number: ");
		CAddStr(sysStr, aCStr);
		CAddStr(sysStr, " - PlatformID: ");
		CNumToString(versionInfo.dwPlatformId, aCStr);
		CAddStr(sysStr, aCStr);

		CAddStr(sysStr, " (");
		CNumToString(dwMajorVersion, aCStr);
		CAddStr(sysStr, aCStr);
		CAddStr(sysStr, "-");
		CNumToString(dwMinorVersion, aCStr);
		CAddStr(sysStr, aCStr);
		CAddStr(sysStr, ")");

		/*switch(versionInfo.dwPlatformId)
		{
			case VER_PLATFORM_WIN32s:
				CAddStr(sysStr, "Win32s on Windows 3.1");
				break;
			case VER_PLATFORM_WIN32_WINDOWS:
				CAddStr(sysStr, "Windows 95, Windows 98, or Windows Me");
				break;
			case VER_PLATFORM_WIN32_NT:
				CAddStr(sysStr, "Windows NT 3.51, Windows NT 4.0, Windows 2000, Windows XP, or Windows .NET Server");
				break;
			default:
				CAddStr(sysStr, "Unknown");
				break;
		}*/
	}
}

/*//===========================================================================================
// note that must be: args[totArgs] = nil;
static XErr	_read_from_file(HANDLE fileH, BlockRef *resBlockP, long *resLenP)
{
XErr		err = noErr;
int			offset = 0;
Ptr			textP;
BlockRef	resBlock;
DWORD		tCount, res, bytesReaded, dwAvail = 0;

	if (resBlock = NewBlock(READ_STEP, &err, &textP))
	{	while(1)
		{	//printf("PeekNamedPipe\r\n");
			if NOT(PeekNamedPipe(fileH, NULL, 0, NULL, &dwAvail, NULL))
			{	err = XWinGetLastError();
				break;
			}
        	//printf("after PeekNamedPipe\r\n");
        	if NOT(dwAvail)           // no data available, break
            	break;
			else if (dwAvail < READ_STEP)
				tCount = dwAvail;
			else
				tCount = READ_STEP;
			//printf("ReadFile\r\n");
			if NOT(res = ReadFile(fileH, textP + offset, tCount, &bytesReaded, NULL))
				break;
			//printf("after ReadFile\r\n");
			offset += bytesReaded;
			if (err = SetBlockSize(resBlock, offset + READ_STEP))
				break;
			else
				textP = GetPtr(resBlock);
			if (bytesReaded < tCount)
				break;
		}
		//printf("finished");
		if NOT(res)
			err = XWinGetLastError();
		if NOT(err)
		{	if NOT(err = SetBlockSize(resBlock, offset + 1))
			{	textP = GetPtr(resBlock);
				textP[offset] = 0;
				*resBlockP = resBlock;
				*resLenP = offset;
			}
		}
		if (err)
			DisposeBlock(&resBlock);
	}
	printf("----_read_from_file length is %d\r\n", offset);

return err;
}
*/
//===========================================================================================
/*XErr	xxRedirOutput(XErr (*_Func)(long userData), long userData, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP)
{
XErr					err = noErr;


HANDLE 					hReadPipeOut, hWritePipeOut, hReadPipeErr, hWritePipeErr;
HANDLE					hSaveErr = NULL, hSaveOut = NULL;
SECURITY_ATTRIBUTES		PipeSA = {sizeof (SECURITY_ATTRIBUTES), NULL, false};

	hReadPipeOut = hWritePipeOut = hReadPipeErr = hWritePipeErr = NULL;
	XThreadsEnterCriticalSection();
	if (stdOutP)
	{	if NOT(hSaveOut = GetStdHandle (STD_OUTPUT_HANDLE))
			err = XWinGetLastError();
		else if NOT(CreatePipe(&hReadPipeOut, &hWritePipeOut, &PipeSA, 0))
			err = XWinGetLastError();
		else if NOT(SetStdHandle (STD_OUTPUT_HANDLE, hWritePipeOut))
			err = XWinGetLastError();
		else
		{	int		hHand = _open_osfhandle((long)hWritePipeOut, _O_TEXT);
			FILE*	fp = _fdopen(hHand, "w");
			setvbuf(fp, NULL, _IONBF, 0);
		}
	}
	if (err)
		goto out;
	if (stdErrP)
	{	if NOT(hSaveErr = GetStdHandle (STD_ERROR_HANDLE))
			err = XWinGetLastError();
		else if NOT(CreatePipe(&hReadPipeErr, &hWritePipeErr, &PipeSA, 0))
			err = XWinGetLastError();
		else if NOT(SetStdHandle (STD_ERROR_HANDLE, hWritePipeErr))
			err = XWinGetLastError();
		else
		{	int		hHand = _open_osfhandle((long)hWritePipeErr, _O_TEXT);
			FILE*	fp = _fdopen(hHand, "w");
			setvbuf(fp, NULL, _IONBF, 0);
		}
	}
	if (err)
		goto out;
	printf("REDIRECTED\r\n");
	printf("pippo printf\r\n");
	{
	int	len = 15;
	WriteConsole(GetStdHandle(STD_OUTPUT_HANDLE), "pippo console\r\n", len, &len, NULL);
	}
	if NOT(err = _Func(userData))
	{	if (stdOutP)
			err = _read_from_file(hReadPipeOut, stdOutP, stdOutLenP);
		if (err)
			goto out;
		if (stdErrP)
			err = _read_from_file(hReadPipeErr, stdErrP, stdErrLenP);
	}

out:
// std out
if (hSaveOut)
	SetStdHandle (STD_OUTPUT_HANDLE, hSaveOut);
if (hReadPipeOut)
	CloseHandle(hReadPipeOut);
if (hWritePipeOut)
	CloseHandle(hWritePipeOut);
// std err
if (hSaveErr)
	SetStdHandle (STD_ERROR_HANDLE, hSaveErr);
if (hReadPipeErr)
	CloseHandle(hReadPipeErr);
if (hWritePipeErr)
	CloseHandle(hWritePipeErr);
XThreadsLeaveCriticalSection();

return err;
}*/
//===========================================================================================
/*XErr	xxxRedirOutput(XErr (*_Func)(long userData), long userData, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP)
{
XErr					err = noErr;

	// temporaneous
	if NOT(err = _Func(userData))
	{	if (stdOutP)
			*stdOutP = NewBlock(1, &err, nil);
		if (stdOutLenP)
			*stdOutLenP = 0;
		if (stdErrP)
			*stdErrP = NewBlock(1, &err, nil);
		if (stdErrLenP)
			*stdErrLenP = 0;

	}

HANDLE 					hReadPipeOut, hWritePipeOut, hReadPipeErr, hWritePipeErr;
HANDLE					hSaveErr = NULL, hSaveOut = NULL;
SECURITY_ATTRIBUTES		PipeSA = {sizeof (SECURITY_ATTRIBUTES), NULL, false};

	hReadPipeOut = hWritePipeOut = hReadPipeErr = hWritePipeErr = NULL;
	XThreadsEnterCriticalSection();
	if (stdOutP)
	{	if NOT(hSaveOut = GetStdHandle (STD_OUTPUT_HANDLE))
			err = XWinGetLastError();
		else if NOT(CreatePipe(&hReadPipeOut, &hWritePipeOut, &PipeSA, 0))
			err = XWinGetLastError();
		else if NOT(SetStdHandle (STD_OUTPUT_HANDLE, hWritePipeOut))
			err = XWinGetLastError();
	}
	if (err)
		goto out;
	if (stdErrP)
	{	if NOT(hSaveErr = GetStdHandle (STD_ERROR_HANDLE))
			err = XWinGetLastError();
		else if NOT(CreatePipe(&hReadPipeErr, &hWritePipeErr, &PipeSA, 0))
			err = XWinGetLastError();
		else if NOT(SetStdHandle (STD_ERROR_HANDLE, hWritePipeErr))
			err = XWinGetLastError();
	}
	if (err)
		goto out;
	printf("REDIRECTED\r\n"); 
	printf("pippo printf\r\n");
	//fflush(NULL); 
	{
	int	len = 15;
	WriteConsole(GetStdHandle(STD_OUTPUT_HANDLE), "pippo console\r\n", len, &len, NULL);
	//fflush(NULL);
	}
	if NOT(err = _Func(userData))
	{	if (stdOutP)
			err = _read_from_file(hReadPipeOut, stdOutP, stdOutLenP);
		if (err)
			goto out;
		if (stdErrP)
			err = _read_from_file(hReadPipeErr, stdErrP, stdErrLenP);
	}

out:
// std out
if (hSaveOut)
	SetStdHandle (STD_OUTPUT_HANDLE, hSaveOut);
if (hReadPipeOut)
	CloseHandle(hReadPipeOut);
if (hWritePipeOut)
	CloseHandle(hWritePipeOut);
// std err
if (hSaveErr)
	SetStdHandle (STD_ERROR_HANDLE, hSaveErr);
if (hReadPipeErr)
	CloseHandle(hReadPipeErr);
if (hWritePipeErr)
	CloseHandle(hWritePipeErr);
XThreadsLeaveCriticalSection();

return err;
}*/

/*#define	READ_STEP	1024
//===========================================================================================
static XErr	_read_from_file(FILE *f, BlockRef *resBlockP, long *resLenP)
{
XErr		err = noErr;
int			offset = 0;
Ptr			textP;
BlockRef	resBlock;
char		*strP;

	if (resBlock = NewBlock(READ_STEP, &err, &textP))
	{	while (strP = fgets(textP + offset, READ_STEP, f))
		{	offset += CLen(strP);
			if (err = SetBlockSize(resBlock, offset + READ_STEP))
				break;
			else
				textP = GetPtr(resBlock);
		}
		if NOT(err)
		{	if NOT(err = SetBlockSize(resBlock, offset + 1))
			{	textP = GetPtr(resBlock);
				textP[offset] = 0;
				*resBlockP = resBlock;
				*resLenP = offset;
			}
		}
		if (err)
			DisposeBlock(&resBlock);
	}
		
return err;
}
*/
//===========================================================================================
/*XErr	RedirOutput(XErr (*_Func)(long userData), long userData, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP)
{
XErr	err = noErr;
	
	// temporaneous
	if NOT(err = _Func(userData))
	{	if (stdOutP)
			*stdOutP = NewBlock(1, &err, nil);
		if (stdOutLenP)
			*stdOutLenP = 0;
		if (stdErrP)
			*stdErrP = NewBlock(1, &err, nil);
		if (stdErrLenP)
			*stdErrLenP = 0;

	}
*/
/*FILE	*fdout, *fderr;
FILE	saveStdOut, saveStdErr;

	XThreadsEnterCriticalSection();
	if (stdOutP)
	{	fdout = fopen("out.txt", "wb");
		saveStdOut = *stdout;
		*stdout = *fdout;
		//setvbuf(stdout, NULL, _IONBF, 0);
	}
	if (stdErrP)
	{	fderr = fopen("err.txt", "wb");
		saveStdErr = *stderr;
		*stderr = *fderr;
		//setvbuf(stderr, NULL, _IONBF, 0);
	}
	if NOT(err = _Func(userData))
	{	if (stdOutP)
			err = _read_from_file(fdout, stdOutP, stdOutLenP);
		if NOT(err)
		{	if (stdErrP)
				err = _read_from_file(fderr, stdErrP, stdErrLenP);
		}
	}
	if (stdOutP)
		*stdout = saveStdOut;
	if (stdErrP)
		*stderr = saveStdErr;
	XThreadsLeaveCriticalSection();
*/
/*return err;
}*/

