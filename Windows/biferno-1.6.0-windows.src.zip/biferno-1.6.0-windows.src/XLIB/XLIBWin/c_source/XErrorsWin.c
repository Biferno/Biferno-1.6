/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XErrorsWin.c,v 1.1.1.1 2003-03-25 13:07:42 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

//===========================================================================================
XErr	XErrorGetDescr(XErr theError, char *eNameStr, char *eMsg)
{
LPTSTR	lpMsgBuf;
long	errValue, errType;

	if NOT(_XErrorString(theError, eNameStr))
	{	XErrorGetTypeValue(theError, &errValue, &errType);
		FormatMessage( 
    		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
    		FORMAT_MESSAGE_FROM_SYSTEM | 
    		FORMAT_MESSAGE_IGNORE_INSERTS,
    		NULL,
    		errValue,
   			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    		(LPTSTR)&lpMsgBuf,
    		0,
    		NULL);
    	if (lpMsgBuf)	
		{	if (eNameStr)
			{	if (CLen(lpMsgBuf) < 255)
					CEquStr(eNameStr, lpMsgBuf);
				else
					*eNameStr = 0;
			}
			LocalFree(lpMsgBuf);
		}
	}
	if (eMsg)
		*eMsg = 0;
	
return noErr;
}

//===========================================================================================
/*XErr	XGetError(void)
{
	// Da fare (XWinGetLastError()?)
}*/

