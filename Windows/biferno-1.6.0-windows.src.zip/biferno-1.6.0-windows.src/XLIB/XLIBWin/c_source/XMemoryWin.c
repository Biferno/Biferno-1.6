/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XMemoryWin.c,v 1.3 2004-05-04 13:21:57 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"
#include "XMemoryPrivate.h"

extern HANDLE	gMyHeap;

#define	WIN_INVALID_SIZE	0xFFFFFFFF

//===========================================================================================
static long	_NewHeapBlockP_low(long size, Boolean cleared, XErr *errPtr)
{
Ptr		thePtr = 0L;
DWORD	dwFlags;
XErr	err = noErr;

	#ifdef MEM_DEBUG
		size += 16;		// space for page guardians
	#endif

	if (cleared)
		dwFlags = HEAP_ZERO_MEMORY;
	else
		dwFlags = 0L;
	if NOT(thePtr = HeapAlloc(gMyHeap, dwFlags, size))
	{	err = XWinGetLastError();
		if (errPtr)
			*errPtr = err;
	}

	#ifdef MEM_DEBUG
		if (thePtr && NOT(err))
		{	long action;
			
			//OneMorePtr();
			if (cleared)
				action = CLEAR;
			else
				action = FILL;
			_WritePageGuardians(thePtr, size, (short)action);
			return (long)thePtr;
		}
		else
			return nil;
	#else
		return (long)thePtr;	
	#endif
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
long	NewBlock_low(long size, XErr *errPtr)
{
	return _NewHeapBlockP_low(size, false, errPtr);
}

//===========================================================================================
long	NewBlockClear_low(long size, XErr *errPtr)
{
	return _NewHeapBlockP_low(size, true, errPtr);
}

//===========================================================================================
long	NewPtrBlock_low(long size, XErr *errPtr)
{
	return _NewHeapBlockP_low(size, false, errPtr);
}

//===========================================================================================
XErr	DisposeBlock_low(long *addressP, unsigned long size)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(size)
#endif
XErr			err = noErr;
Ptr				p;

	if (addressP && *addressP)
	{	p = (Ptr)*addressP;
		#ifdef MEM_DEBUG
			{
			unsigned long	i;
			long			*longP;
			
			i = HeapSize(gMyHeap, 0L, p);
			if (i == WIN_INVALID_SIZE)
				err = ErrXMemory_BadBlockSize;
			if (err)
				CDebugStr("XMemoryWin.c (DisposeBlock): Err after HeapSize");

			if (i > 0)
			{	_CheckPageGuardians(p, i, "DisposeBlock");
				i = i / sizeof(long);
				longP = (long*)p;
				do	{
					*longP++ = 0xDEADBEEF;
					} while (--i);
			}
			else if (i < 0)
				CDebugStr("XMemoryWin.c (DisposeBlock): Size negative after HeapSize");
			}
		#endif

		if NOT(HeapFree(gMyHeap, 0L, p))	// return false if err
			err = XWinGetLastError();
		
		//if NOT(err)
		//	OneLessPtr();
		*addressP = 0;
	}
	else
		err = XError(kXLibError, ErrXMemory_BadRef);

return err;
}

//===========================================================================================
Ptr		GetPtr_low(long address)
{	
	if (address)
	{	
		#ifdef MEM_DEBUG
			return (Ptr)(address + 8);
		#else
			return (Ptr)address;
		#endif
	}

return nil;
}

//===========================================================================================
unsigned long	GetBlockSize_low(long address, XErr *errP)
{
unsigned long	size;
XErr			err = noErr;
Ptr				p;

	if (address)
	{	p = (Ptr)address;
		size = HeapSize(gMyHeap, 0L, p);
		if (size == WIN_INVALID_SIZE)
			err = ErrXMemory_BadBlockSize;
		if (errP)
			*errP = err;

		#ifdef MEM_DEBUG
			if NOT(err)
			{	_CheckPageGuardians(p, size, "GetBlockSize");
				size -= 16;
			}
		#endif
	}
	else
		*errP = XError(kXLibError, ErrXMemory_BadRef);

return size;
}

//===========================================================================================
XErr SetBlockSize_low(long *addressP, unsigned long oldSize, unsigned long newSize)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(oldSize)
#endif
XErr			err = noErr;

	if NOT(newSize)
		return XError(kXLibError, ErrXMemory_NullSize);

	if (addressP && *addressP)
	{	
		Ptr		p;

		p = (Ptr)*addressP;	
		#ifdef MEM_DEBUG		
			{
			unsigned long	oldSize;
			
			oldSize = HeapSize(gMyHeap, 0L, p);
			if (oldSize == WIN_INVALID_SIZE)
				err = ErrXMemory_BadBlockSize;
			if (err)
				CDebugStr("XMemoryWin.c (SetBlockSize): Err after HeapSize");
			_CheckPageGuardians(p, oldSize, "SetBlockSize");
			newSize += 16;
			}
		#endif
		if NOT(p = HeapReAlloc(gMyHeap, 0L, p, newSize))
			err = XWinGetLastError();
		else
			*addressP = (long)p;
		#ifdef MEM_DEBUG
			if NOT(err)
				_WritePageGuardians(p, newSize, (short)NOACTION);
		#endif
	}
	else
		err = XError(kXLibError, ErrXMemory_BadRef);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	CopyBlock(void *dest, void *source, long len)
{
	MoveMemory(dest, source, len);	// memmove + can overlap
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*Boolean		CheckStackSpace(void)
{
return false;

dafare
unsigned long sp = MIN_STACK_SPACE;

	if (sp < MIN_STACK_SPACE)
		return true;
	else
		return false;

}*/

