/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XThreadsWin.c,v 1.9 2008-09-19 13:31:42 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __XLIB_CLIENT__

#include "XLib.h"
#include "XLibPrivate.h"
#include "XThreadsPrivate.h"
#include "XMemoryPrivate.h"

extern CRITICAL_SECTION		gCriticalSection;
extern HANDLE				gMyHeap;
extern long					gXLibNewThread;

//===========================================================================================
XErr	XGetCurrentThread(unsigned long *threadIDP)
{
	*threadIDP = GetCurrentThreadId();
	return noErr;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static void	_EnterCriticalSection(Boolean checkLocks)
{
	// E' recursive safe come su Linux????
	EnterCriticalSection(&gCriticalSection);
	#if CHECK_LEAKING
		if (checkLocks)
			_OneMoreLock();
	#else
		#if __MWERKS__
			#pragma unused(checkLocks)
		#endif
	#endif
}

//===========================================================================================
static void	_LeaveCriticalSection(Boolean checkLocks)
{
	// E' recursive safe come su Linux????
	LeaveCriticalSection(&gCriticalSection);
	#if CHECK_LEAKING
		if (checkLocks)
			_OneLessLock();
	#else
		#if __MWERKS__
			#pragma unused(checkLocks)
		#endif
	#endif
}

//===========================================================================================
void	XThreadsEnterCriticalSection(void)
{
	_EnterCriticalSection(true);
}

//===========================================================================================
void	XThreadsLeaveCriticalSection(void)
{
	_LeaveCriticalSection(true);
}

//===========================================================================================
void	__XThreadsEnterCriticalSection(void)
{
	_EnterCriticalSection(false);
}

//===========================================================================================
void	__XThreadsLeaveCriticalSection(void)
{
	_LeaveCriticalSection(false);
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	XNewCS(BlockRef *csBlockRefP)
{
	CRITICAL_SECTION		*criticalSectionP;
	BlockRef				theCSBlock;
	XErr					err = noErr;
	
	if (theCSBlock = NewBlock(sizeof(CRITICAL_SECTION), &err, (Ptr*)&criticalSectionP))
	{	InitializeCriticalSection(criticalSectionP);
		*csBlockRefP = theCSBlock;
	}
	return err;
}

//===========================================================================================
void	XDeleteCS(BlockRef *csBlockRefP)
{
	CRITICAL_SECTION	*criticalSectionP = (CRITICAL_SECTION*)GetPtr(*csBlockRefP);
	DeleteCriticalSection(criticalSectionP);
	DisposeBlock(csBlockRefP);
}

//===========================================================================================
void	XEnterCS(BlockRef csBlockRef)
{	
	CRITICAL_SECTION	*criticalSectionP = (CRITICAL_SECTION*)GetPtr(csBlockRef);
	EnterCriticalSection(criticalSectionP);
}

//===========================================================================================
void	XExitCS(BlockRef csBlockRef)
{
	CRITICAL_SECTION	*criticalSectionP = (CRITICAL_SECTION*)GetPtr(csBlockRef);
	LeaveCriticalSection(criticalSectionP);
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	XThreadsSemaphoreGreen(long *semaphore)
{
XErr	err = noErr;

	if NOT(ReleaseSemaphore((HANDLE)*semaphore, 1, NULL))
		err = XWinGetLastError();

return err;
}

//===========================================================================================
// timeout in milliseconds
XErr	XThreadsWaitSemaphore(volatile long *semaphore, long timeout)
{
XErr	err = noErr;
long	result;
	
	result = WaitForSingleObject((HANDLE)*semaphore, timeout);
	switch(result)
	{	case WAIT_OBJECT_0:
			break;
		case WAIT_TIMEOUT:
			err = XError(kXLibError, ErrXThreads_Timeout);
			break;
		case WAIT_FAILED:
			err = XWinGetLastError();
			break;
	}

return err;
}

//===========================================================================================
long	XThreadsCreateSemaphore(long initialState, XErr *errP)
{
HANDLE	semH;
long	initialCount;
	
	if (initialState == _GREEN)
		initialCount = 1;		// 1 resource
	else
		initialCount = 0;		// 0 resource
	
	if NOT(semH = CreateSemaphore(NULL, initialCount, 1, NULL))
	{	if (errP)
			*errP = XWinGetLastError();
	}

return (long)semH;
}

//===========================================================================================
XErr	XThreadsCloseSemaphore(long semaphore)
{
XErr	err = noErr;

	if NOT(CloseHandle((HANDLE)semaphore))
		err = XWinGetLastError();

return err;
}

//===========================================================================================
XErr	XThreadsNewPool(long maxThreads, unsigned long size)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(maxThreads, size)
#endif
XErr	err = noErr;
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

/*#ifdef __VISUALCPP__
unsigned long _beginthreadex(void *security, unsigned stack_size,
							unsigned ( _stdcall *start_address ) ( void * ),
							void *arglist, 
							unsigned initflag, 
							unsigned *thrdaddr);
#endif*/

typedef unsigned (__stdcall *PTHREAD_START) (void *);

#include <process.h>			// For _beginthreadex

#define chBEGINTHREADEX(lpsa, cbStack, lpStartAddr, \
   lpvThreadParm, fdwCreate, lpIDThread)            \
      ((HANDLE)_beginthreadex(                      \
         (void *) (lpsa),                           \
         (unsigned) (cbStack),                      \
         (PTHREAD_START) (lpStartAddr),             \
         (void *) (lpvThreadParm),                  \
         (unsigned) (fdwCreate),                    \
         (unsigned *) (lpIDThread)))

typedef struct {
				void* 		(*func)(void*);
				void		*args;
				long		threadStackSize;
				} ThreadRec;

//====================================================================
static DWORD WINAPI _ThreadProc(LPVOID param)
{
ThreadRec		*threadrecP = (ThreadRec*)param;
DWORD			ourID;
Boolean			TLSAdded = false;
unsigned long	currentStackSize;
DWORD			threadResultErr = noErr;
XErr			err = noErr;

	ourID = GetCurrentThreadId();
	_MoreThread();
	// XThreadsSemaphoreGreen(&gXLibNewThread);	 // spostato fuori (in XNewThread)
	currentStackSize = threadrecP->threadStackSize;		// circa
	if (err = _XThreadsNewTLS(ourID, (long)&threadrecP, currentStackSize))
	{	_LessThread();
		return err;
	}
	TLSAdded = true;
	threadResultErr = (XErr)threadrecP->func(threadrecP->args);
	if (TLSAdded)
		_XThreadsDisposeTLS(ourID, nil);
	
	// this must be before DisposeThread
	HeapFree(gMyHeap, 0L, threadrecP);
	_LessThread();
	
return threadResultErr;
}

//===========================================================================================
XErr	XNewThread(unsigned long *threadID, long flags, void* (*func)(void*), unsigned long newThreadStackSize, void *args)
{
HANDLE			hThread, currentThread;
XErr			err = noErr, err2 = noErr;
ThreadRec		*threadRecP;
DWORD 			homeMadeThreadID, ourID;
long			aLong;
Boolean			waitEnd, disposeThreadRec;

	disposeThreadRec = false;
	ourID = GetCurrentThreadId();
	currentThread = GetCurrentThread();
	//if NOT(err = _XThreadsCheckForceQuit())
	{	// Can't use NewPtrBlock because of Check Leaking (if NOT waitEnd check leaking get confused)
		if (threadRecP = (ThreadRec*)HeapAlloc(gMyHeap, HEAP_ZERO_MEMORY, sizeof(ThreadRec)))
		{	
			disposeThreadRec = true;
			threadRecP->args = args;
			threadRecP->func = func;
			threadRecP->threadStackSize = newThreadStackSize;
			waitEnd = flags & kWaitEndOfThread;
			if NOT(err = XThreadsWaitSemaphore(&gXLibNewThread, kXLibStopThreadsTimeout))
			{	
				if NOT(hThread = chBEGINTHREADEX(NULL, newThreadStackSize, _ThreadProc, (LPVOID)threadRecP, 0L, &homeMadeThreadID))
					err = XWinGetLastError();
				XThreadsSemaphoreGreen(&gXLibNewThread);
				if not(err)
					disposeThreadRec = false;
			}
			if NOT(err)
			{	if (waitEnd)
				{	
				#ifdef CHECK_LEAKING
					CheckLeakingMoreThread(ourID, homeMadeThreadID);
				#endif
					err2 = WaitForSingleObject(hThread, INFINITE);
				#ifdef CHECK_LEAKING
					CheckLeakingLessThread();
				#endif
				}
				if (threadID)
					*threadID = homeMadeThreadID;
				if (waitEnd)
				{	GetExitCodeThread(hThread, (PDWORD)&aLong);
					err = aLong;
				}
				if (err2 && NOT(err))
					err = err2;
				CloseHandle(hThread);
			}			
		}
		else
			err = XWinGetLastError();
	}
	if (disposeThreadRec)
		HeapFree(gMyHeap, 0L, threadRecP);
		
return err;
}

//===========================================================================================
/*XErr	XNewThread(unsigned long *threadID, long flags, void* (*func)(void*), unsigned long newThreadStackSize, void *args)
{
	return __XNewThread(threadID, flags, func, newThreadStackSize, args, false);
}

//===========================================================================================
XErr	_XNewThread(unsigned long *threadID, long flags, void* (*func)(void*), unsigned long newThreadStackSize, void *args)
{
	return __XNewThread(threadID, flags, func, newThreadStackSize, args, true);
}*/

#endif
