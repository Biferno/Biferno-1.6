/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XWin.c,v 1.9 2006-01-02 11:32:25 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"
#include "XMemoryPrivate.h"
#include "XFilesWinPrivate.h"
#include "XThreadsPrivate.h"

/*#ifdef JAVA_ENABLED
	#include	"JNIUtils.h"
#endif*/

CRITICAL_SECTION	gCriticalSection;
//Boolean				gBusy;
//HANDLE				gThreadWhoLocked;
HANDLE				gMyHeap;
CStr255				gFragLocator_u_onDisk_path;
//Boolean				gJavaOK;
unsigned long		gTotalApplicationMemory;
//long				gNConnection;//, gCreateAliasDLL, gCreateAliasEntryPoint;
//Boolean				gXLibQuitApplication;
long				gXLibNewThread;
Boolean				gAbortThreads, gExitForced;
unsigned long		gMainThreadID;

#ifdef XLIB_WIN_DEBUG
HANDLE		gDebugFileHandle;

//============================================================
void	_DebugCreate(void)
{
	gDebugFileHandle = CreateFile("C:\\xlib.debug.c", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_FILE_ALWAYS, 0, NULL);
}

//============================================================
void	_DebugWrite(char *cStr)
{
XErr	err = noErr;
DWORD	bytesWritten;

	err = WriteFile(gDebugFileHandle, cStr, CLen(cStr), &bytesWritten, NULL);
	err = WriteFile(gDebugFileHandle, "\r\n", 2, &bytesWritten, NULL);
}
#endif

//============================================================
XErr	XWinGetLastError(void)
{
XErr	err = noErr;

	err = GetLastError();
	//if (err)
	//	err = GetLastError();

return err;
}

//============================================================
XErr	XInit(XFilePathPtr applicationPath)
{
//char 				cName[] = "intl";
XErr				err = noErr;
int					pLen;
//CStr255				aStr;

	gAbortThreads = false;
	gExitForced = false;
	
#ifdef _WIN32_NEW_HEAP_
	gMyHeap = HeapCreate(0L, 32L * 1024L, 0L);
#else
	gMyHeap = GetProcessHeap();
#endif
	if (gMyHeap == INVALID_HANDLE_VALUE)
		return XWinGetLastError();

	// Threads
	//gBusy = false;
	InitializeCriticalSection(&gCriticalSection);
	/*
		To adjust spin count use:
		
		InitializeCriticalSectionAndSpinCount(&gCriticalSection, 2);
			
			or:
			
		InitializeCriticalSection(&gCriticalSection);
		SetCriticalSectionSpinCount(&gCriticalSection, 2);
		
		Per� (almeno su CodeWarrior) devi definire _WIN32_WINNT >= 0x0403
	*/
		
	//gThreadWhoLocked = NULL;

#ifndef __XLIB_CLIENT__
	if (err = XCommonInit())
		return err;
#endif

	gTotalApplicationMemory = 0;
	//gNConnection = 0;

/*#ifdef JAVA_ENABLED
	err = Init_JVM();
	if NOT(err)
		gJavaOK = true;
	else
	{	gJavaOK = false;
		err = noErr;
	}
#endif*/

	if (err = XMemoryInit())
		return err;

#if CHECK_LEAKING
	InitMemoryLeakingMgr();
#endif

	if (applicationPath)
	{	CEquStr(gFragLocator_u_onDisk_path, applicationPath);
		if (strchr(gFragLocator_u_onDisk_path, ':'))	// is native
			FilePathWin32ToXLib(gFragLocator_u_onDisk_path);
		pLen = CLen(gFragLocator_u_onDisk_path);
		if (gFragLocator_u_onDisk_path[pLen-1] != '/')
			CAddChar(gFragLocator_u_onDisk_path, '/');
	}
	else
	{	GetCurrentDirectory(255, gFragLocator_u_onDisk_path);
		pLen = CLen(gFragLocator_u_onDisk_path);
		if (gFragLocator_u_onDisk_path[pLen-1] != '\\')
			CAddChar(gFragLocator_u_onDisk_path, '\\');
		FilePathWin32ToXLib(gFragLocator_u_onDisk_path);
	}

#ifdef __XLIB_WITH_HELPERS__
	if NOT(err)
	{
		err = InitHelpers();
	}
#endif

	if NOT(err)
	{	
	WSADATA		WSAData	;
	
	#ifndef __XLIB_CLIENT__
	unsigned long		ourID;

		XGetCurrentThread(&ourID);
		gMainThreadID = ourID;
		if NOT(ourID)
			CDebugStr("Thread id in XInit is 0!");
		if (err = _XThreadsNewTLS(ourID, (long)&err, (1024L * 1024L * 1L)))	// 1MB is correct? Boh?
			return err;
	#endif
	
		// Per i sockets
		if (WSAStartup (MAKEWORD(1,1), &WSAData) != 0) 
		{
  			err = -1;
		}
	}
	/*
	gCreateAliasEntryPoint = 0;
	CEquStr(aStr, gFragLocator_u_onDisk_path);
	CAddStr(aStr, "xl_alias.dll");
	XLoadDLL(aStr, &gCreateAliasDLL, nil, false);
	XGetDLLSymbol(gCreateAliasDLL, "CreateLink", &gCreateAliasEntryPoint);
	*/

#ifdef __VISUALCPP__
	//CoInitialize(NULL);
#endif

	gXLibNewThread = XThreadsCreateSemaphore(_GREEN, &err);

return err;
}

//============================================================
XErr	XEnd(long threadsToRemain)
{
XErr			err = noErr;
	
	XThreadsStopThreads(threadsToRemain);

#ifdef __VISUALCPP__
	//CoUninitialize(NULL);
#endif

	//XFreeDLL(&gCreateAliasDLL);
	
	// sockets
	WSACleanup();
	
#ifndef __XLIB_CLIENT__
{
unsigned long	ourID;

	XGetCurrentThread(&ourID);
	_XThreadsDisposeTLS(ourID, nil);
	_XThreadsCloseTLSSystem();
}
#endif

	// don't dispose XThreadsCloseSemaphore(gXLibNewThread);
	
#ifdef __XLIB_WITH_HELPERS__
	err = EndHelpers();
#endif

	err = XMemoryEnd();

/*#ifdef JAVA_ENABLED
	if (gJavaOK)
	{	if (err = End_JVM())
			return err;
	}
#endif*/		

#ifdef _WIN32_NEW_HEAP_
	if NOT(HeapDestroy(gMyHeap))
		err = XWinGetLastError();
#endif

#ifndef __XLIB_CLIENT__
	err = XCommonEnd();
#endif

//#ifdef JAVA_ENABLED
	XLibEnd_JVM_API();
//#endif

	// Threads
	DeleteCriticalSection(&gCriticalSection);	

#ifdef USE_WIN_DNS
	// DNS API Lib
	_UnloadDNS_EPs();
#endif

return err;
}

