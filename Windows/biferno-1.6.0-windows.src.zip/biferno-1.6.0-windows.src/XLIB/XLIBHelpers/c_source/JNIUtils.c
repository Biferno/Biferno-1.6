/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: JNIUtils.c,v 1.14 2005-11-04 15:31:20 valfer Exp $
	|______________________________________________________________________________
*/

#include 	"XLib.h"

static Boolean	gsJavaHelperEntryPointsAreValid = false;
static Ptr		gsJvmHelperP = nil;
static XErr		(*XLibInit_JVM_EP)(LogCallBack logCallBack, void *userData, Ptr *jvmHelperPPtr);
static XErr		(*XLibEnd_JVM_EP)(Ptr jvmHelperP);
static XErr		(*XLibAttachJVM_EP)(Ptr jvmHelperP, void **envPPtr);
static XErr		(*XLibDetachJVM_EP)(Ptr jvmHelperP);
static XErr		(*XLibGetMainJVM_EP)(Ptr jvmHelperP, void **jvmEnvP);

//===========================================================================================
void	XLibReset_JVM_API(void)
{
	gsJavaHelperEntryPointsAreValid = false;
}

//===========================================================================================
XErr	XLibInit_JVM_API(LogCallBack logCallBack, void *userData, long helperDllRef)
{
XErr		err = noErr;

	if NOT(helperDllRef)
		return XError(kXHelperError, ErrJavaHelperJVMLoadFailed);
	
	if (err = XGetDLLSymbol(helperDllRef, "XLibInit_JVM", (long*)&XLibInit_JVM_EP, false))
		goto out;
	if (err = XGetDLLSymbol(helperDllRef, "XLibEnd_JVM", (long*)&XLibEnd_JVM_EP, false))
		goto out;
	if (err = XGetDLLSymbol(helperDllRef, "XLibAttachJVM", (long*)&XLibAttachJVM_EP, false))
		goto out;
	if (err = XGetDLLSymbol(helperDllRef, "XLibDetachJVM", (long*)&XLibDetachJVM_EP, false))
		goto out;
	if (err = XGetDLLSymbol(helperDllRef, "XLibGetMainJVM", (long*)&XLibGetMainJVM_EP, false))
		goto out;
	if NOT(gsJvmHelperP)
		err = XLibInit_JVM_EP(logCallBack, userData, &gsJvmHelperP);
	if NOT(err)
		gsJavaHelperEntryPointsAreValid = true;

out:
return err;
}

//===========================================================================================
XErr	XLibEnd_JVM_API(void)
{
XErr	err = noErr;

	if (gsJavaHelperEntryPointsAreValid)
		err = XLibEnd_JVM_EP(gsJvmHelperP);
	
return err;
}
//===========================================================================================
XErr	XLibAttachJVM_API(void **envPPtr)
{
XErr	err = noErr;

	if (gsJavaHelperEntryPointsAreValid)
		err = XLibAttachJVM_EP(gsJvmHelperP, envPPtr);
	else
		*envPPtr = 0;
	
return err;
}

//===========================================================================================
XErr	XLibDetachJVM_API(void)
{
XErr	err = noErr;

	if (gsJavaHelperEntryPointsAreValid)
		err = XLibDetachJVM_EP(gsJvmHelperP);
	
return err;
}

//===========================================================================================
XErr	XLibGetMainJVM_API(void **jvmEnvP)
{
XErr	err = noErr;

	if (gsJavaHelperEntryPointsAreValid)
		err = XLibGetMainJVM_EP(gsJvmHelperP, jvmEnvP);
	else
		*jvmEnvP = nil;
	
return err;
}



