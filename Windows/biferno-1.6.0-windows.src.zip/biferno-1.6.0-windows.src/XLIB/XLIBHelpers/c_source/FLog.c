/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: FLog.c,v 1.4 2003-07-24 08:04:06 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

//#include "FLog.h"

//===========================================================================================
static XErr	_AddTimeString(XFileRef logRefNum)
{
CStr255		ctStr;
XErr		err = noErr;
long		lenToWrite;

	XCurrentDateTimeToString(ctStr, kComplete);
	//CAddStr(ctStr, "\t");
	//XCurrentTimeToString(tempStr, true, true);
	//CAddStr(ctStr, tempStr);
	CAddStr(ctStr, "\t");
	lenToWrite = CLen(ctStr);
	err = WriteXFile(logRefNum, ctStr, &lenToWrite);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*XErr	PStringToLog(XFileRef logRefNum, const StringPtr strP, Boolean time)
{
long			len;
register int	i;
XErr			err;
Byte			str[256];
register Byte	*s, *d;
Str255			str2;

	if NOT(logRefNum)
		return 0;
		
	XThreadsEnterCriticalSection();
	PEquStr(str2, strP);
	if (time)
		err = _AddTimeString(logRefNum);
	if NOT(err)
	{	s = (Byte*)&str2[1];
	 	d = str;
		// add CR
		if (i = len = str2[0])
			{
			do {
				*d++ = *s++;
				} while (--i);
			}
		*d++ = '\r';
		len++;
		*d++ = '\n';
		len++;
		err = WriteXFile(logRefNum, (Ptr)str, &len);
	}
	XThreadsLeaveCriticalSection();
	
return err;
}
*/

//===========================================================================================
XErr	CStringToLog(XFileRef logRefNum, char *stringCP, Boolean time)
{
long			len = 0;
XErr			err = noErr;
//register char	*temp = stringCP;

	if NOT(logRefNum)
		return 0;
	XThreadsEnterCriticalSection();
	if (time)
		err = _AddTimeString(logRefNum);
	if NOT(err)
	{	len = CLen(stringCP);
		if NOT(err = WriteXFile(logRefNum, stringCP, &len))
		{	//len = CLen(EOL_STRING);
			//err = WriteXFile(logRefNum, EOL_STRING, &len);
		}
	}
	else
	{	CStr255	str, errStr;
	
		XErrorGetDescr(err, errStr, nil);
		sprintf(str, "error: %d (%s)", (int)err, errStr);
		CAddStr(str, EOL_STRING);
		len = CLen(str);
		err = WriteXFile(logRefNum, (Ptr)str, &len);
	}	
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr InitLog(XFilePathPtr filePath, XFileRef *logRefNumP)
{
XErr		err;
//long		eof = 0;
XFileRef	refNum;
	
	XThreadsEnterCriticalSection();
	if NOT(err = OpenXFile(filePath, OPEN_FILE_ALWAYS/*CREATE_FILE_ALWAYS*//*OPEN_FILE_EXISTING*/, READ_WRITE_PERM, false, &refNum))
	{	if (err = SetXFPos(refNum, FROM_EOF, 0))
			CloseXFile(&refNum);
	}
	if NOT(err)
		*logRefNumP = refNum;
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	EndLog(XFileRef	*logRefNumP)
{
XErr	err = noErr;

	XThreadsEnterCriticalSection();
	if (*logRefNumP)
	{	err = CloseXFile(logRefNumP);
		*logRefNumP = 0;
	}
	XThreadsLeaveCriticalSection();

return err;
}

