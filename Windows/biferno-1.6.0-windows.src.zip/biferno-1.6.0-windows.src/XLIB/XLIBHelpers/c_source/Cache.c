/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Cache.c,v 1.5 2005-11-04 14:15:19 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

//#include	"Helpers.h"

#ifndef __XLIB_CLIENT__

#include <string.h>

#ifndef __XLIB_CLIENT__
/*	#include "XAsSharedLib.h"
	extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
#else
*/

	// A single cache Item
	typedef struct CacheItem
		{		
			XFilePath		filePath;
			Byte			userDatas[CACHE_MAX_USER_DATA];
			unsigned long	sum;			// ms
			unsigned long	hits;
			unsigned long	min;
			unsigned long	max;
			unsigned long	last;
			BlockRef		text;
			long			textSize;
			long			currentUsers;
			long			flags;
			unsigned long	lastAccess;		// secs
		} CacheItem, *CacheItemP;

	// the cache main block
	typedef struct CacheStruct
		{
			unsigned long	initSecs;
			Boolean			needReload;
			Boolean			deferredMode;
			Boolean			active;
			Boolean			wantStat;
			long			logicSlots;
			long			physSlots;
			BlockRef		sortIndBlock;
			CacheItem		cacheIt[1];
		} CacheStruct, *CacheStructP;

	// Flags
	#define	kToReload	1L

	#define	BASE_CACHE_FILE		64

	#define	kCacheTimeout		(unsigned long)(1000L * 30L)	// milliseconds (= 30 secs)

	static long			gsCurrentUsers = 0;
	static BlockRef		gsCacheRefBlock = nil;

	// Semaphores
	static long			gsFlushStop;

	#define	CACHE_PTR	((CacheStructP)GetPtr(gsCacheRefBlock))

	// DeferredRec
	typedef struct DeferredRec
		{
			BlockRef		block;
			Boolean			toDispose;
			Byte			padByte;
			short			padShort;
			long			cacheIndex;
		} DeferredRec;

//#include	"HTTPMgr.h"
//===========================================================================================
static XErr _CFGetFileData(XFilePathPtr filePath, BlockRef *textBlockP, long *fileSizeP)
{
XFileRef		fileRef;
long			eof;
BlockRef		block = nil;
XErr			err = noErr, err2 = noErr;
Ptr				p;

	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof)
			{	if (block = NewBlock(eof, &err, &p))
					err = ReadXFile(fileRef, p, &eof);
			}
			else
				block = NewBlock(1, &err, nil);
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	
	
if NOT(err)
{	*textBlockP = block;
	*fileSizeP = eof;
}
else
{	*textBlockP = nil;
	*fileSizeP = 0;
	if (block)
		DisposeBlock(&block);
}

return err;
}

//===========================================================================================
/*
returns:
	0		found
	!=0		not found
*/
static int _CFGetWordPosArray(CacheStructP cacheStrP, long *sortIndP, XFilePathPtr name, long tot, 
																			long *wordPosP)
{
register long	min, max, thePos = 0;
int				res = 1;
register char	*wordP;
	
	if NOT(tot)
	{	*wordPosP = -1;
		return 1;
	}
	max = tot;
	min = 1;
	while(max >= min)
	{	thePos = (max + min) >> 1;
		wordP = cacheStrP->cacheIt[sortIndP[thePos-1]].filePath;
		res = CCompareStrings_cs(name, wordP);
		if (res < 0)			// name > wordP
			min = thePos + 1;
		else if (res > 0)		// name < wordP
			max = thePos - 1;
		else 					// res == 0
		{	max = thePos;
			break;
		}
	}

*wordPosP = thePos - 1;
return res;
}

//===========================================================================================
/* 	look for filePath requested in array. 
	Returns:
	cacheRecP	if the file exists
	nil			it isn't in cache
*/
static CacheItemP _CFGetCacheRec(XFilePathPtr filePath, long *posP)
{
CacheStructP	cacheStrP;
long			pos, totSlot;
long			*sortIndP;
CacheItemP		cacheItP;

	cacheStrP = CACHE_PTR;
	sortIndP = (long*)GetPtr(cacheStrP->sortIndBlock);
	totSlot = cacheStrP->logicSlots;
	if (_CFGetWordPosArray(cacheStrP, sortIndP, filePath, totSlot, &pos))
	{	if (posP)
			*posP = -1;
		return nil;
	}
	else
	{	if (posP)
			*posP = sortIndP[pos];
		cacheItP = &cacheStrP->cacheIt[sortIndP[pos]];
		/*if (cacheItP->flags & kToReload)
		{	LockBlock(gsCacheRefBlock);
			DisposeBlock(&cacheItP->text);
			_CFGetFileData(cacheItP->filePath, &cacheItP->text, &cacheItP->textSize);
			*cacheItP->userDataStr = 0;
			cacheItP->flags &= (0xFFFFFFFF ^ kToReload);
			UnlockBlock(gsCacheRefBlock);
		}*/
		return cacheItP;
	}
}

//===========================================================================================
static XErr	_CFCheckCacheSize(void)
{
XErr			err;
long			i, stop, start, len, *indP;
CacheStructP	cacheStrP;
BlockRef		sortIndBlock;

	cacheStrP = CACHE_PTR;
	if (cacheStrP->logicSlots == cacheStrP->physSlots)
	{	cacheStrP->physSlots += BASE_CACHE_FILE;
		sortIndBlock = cacheStrP->sortIndBlock;
		len = sizeof(long) * cacheStrP->physSlots;
		if (err = SetBlockSize(sortIndBlock, len))
			return err;
		#ifdef __MEM_CANMOVE__
			cacheStrP = CACHE_PTR;
		#endif
		start = cacheStrP->logicSlots;
		stop = cacheStrP->physSlots;
		indP = ((long*)GetPtr(sortIndBlock)) + start;
		for (i = start; i < stop; i++, indP++)
			*indP = i;
		len = sizeof(CacheStruct) + (sizeof(CacheItem) * cacheStrP->physSlots);
		if (err = SetBlockSize(gsCacheRefBlock, len))
			return err;
	}
	
return 0;
}

//===========================================================================================
static void	_CFSortCacheIndexes(CacheStructP cacheStrP)
{
register int 	i, j;
long			tempItem;
CacheItemP		cacheItP;
long			*sortIndP;

	cacheItP = &cacheStrP->cacheIt[0];
	sortIndP = (long*)GetPtr(cacheStrP->sortIndBlock);
	j = cacheStrP->logicSlots;
	if (--j <= 0)
		return;
	do
	{	for (i=0; i<j; i++)
		{	if (CCompareStrings_cs(cacheItP[sortIndP[i]].filePath, cacheItP[sortIndP[i+1]].filePath) == -1)
			{	tempItem = sortIndP[i+1];
				sortIndP[i+1] = sortIndP[i];
				sortIndP[i] = tempItem;
			}
		}
	} while(--j);
}

//===========================================================================================
static XErr	_CFCacheThisFile(XFilePathPtr filePath, BlockRef textBlock, long *posInCacheP, unsigned long howMuch, Byte *userData)
{
CacheStructP		cacheStrP;
register CacheItemP	cacheItP;
XErr				err = noErr;

	if (err = _CFCheckCacheSize())
		return err;
	LockBlock(gsCacheRefBlock);
	cacheStrP = CACHE_PTR;
	*posInCacheP = cacheStrP->logicSlots;
	cacheItP = &cacheStrP->cacheIt[cacheStrP->logicSlots++];
	CEquStr(cacheItP->filePath, filePath);
	cacheItP->text = textBlock;
	cacheItP->textSize = GetBlockSize(textBlock, &err);
	cacheItP->flags = 0;
	if (err)
	{	cacheStrP->logicSlots--;
		UnlockBlock(gsCacheRefBlock);
		return err;
	}

	cacheItP->currentUsers = 0;			// it's just released
	// cacheItP->userData = userData;
	CopyBlock(cacheItP->userDatas, userData, CACHE_MAX_USER_DATA);
	if (cacheStrP->wantStat)
	{	cacheItP->sum = howMuch;
		cacheItP->hits = 1;
		cacheItP->min = howMuch;
		cacheItP->max = howMuch;
		cacheItP->last = howMuch;
		XGetSeconds(&cacheItP->lastAccess);
	}
	_CFSortCacheIndexes(cacheStrP);
	UnlockBlock(gsCacheRefBlock);

return err;
}

//===========================================================================================
static Boolean	_CFIsNotInDeferredList(long deferredID, BlockRef blToCmp)
{
long					size;
BlockRef				bl;
register DeferredRec 	*tempP;
register int			count;
	
	if (deferredID)
	{	bl = BufferGetBlockRef(deferredID, &size);
		LockBlock(bl);
		tempP = (DeferredRec*)GetPtr(bl);
		if (count = (size / sizeof(DeferredRec)))
		{	do {	
				if (tempP->block == blToCmp)
					return true;
				tempP++;
				} while(--count);
		}
		UnlockBlock(bl);
	}

return false;
}

#define	TO_DISPOSE	true
#define	ONLY_UNLOCK	false

//===========================================================================================
static XErr	_CFReleaseMemoryBlock(long deferredID, BlockRef *theBlockP, long cacheIndex, Boolean toDispose)
{
register CacheStructP	cacheStrP = CACHE_PTR;
XErr					err = noErr;

	if (cacheStrP->deferredMode && deferredID)
	{	if NOT(_CFIsNotInDeferredList(deferredID, *theBlockP))
		{	DeferredRec		defRec;
	
			defRec.block = *theBlockP;
			defRec.toDispose = toDispose;
			defRec.cacheIndex = cacheIndex;
			err = BufferAddBuffer(deferredID, (Ptr)&defRec, sizeof(DeferredRec));
			if (toDispose)
				*theBlockP = 0;
		}
	}
	else
	{	if (toDispose)
		{	/*CStr15	tStr;
			CStr63	logStr;
			
			CEquStr(logStr, "Disposing file: ");
			CNumToString(*theBlockP, tStr);
			CAddStr(logStr, tStr);
			HTTPControllerLog(0, logStr);*/
			err = DisposeBlock(theBlockP);
		}
		else
			UnlockBlock(*theBlockP);
	}

return err;
}
#endif // __XLIB_CLIENT__
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	Cache_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{
		xlibCallBacksRecPtr->CFDeferredRun = (long)CFDeferredRun;
		xlibCallBacksRecPtr->CFDeferredExit = (long)CFDeferredExit;
		xlibCallBacksRecPtr->CFGetFile = (long)CFGetFile;
		xlibCallBacksRecPtr->CFGetFileSpecial = (long)CFGetFileSpecial;
		xlibCallBacksRecPtr->CFGetFileInfo = (long)CFGetFileInfo;
		xlibCallBacksRecPtr->CFReleaseFile = (long)CFReleaseFile;
		xlibCallBacksRecPtr->CFFlushFile = (long)CFFlushFile;
		xlibCallBacksRecPtr->CFFlushFilesMatching = (long)CFFlushFilesMatching;
		xlibCallBacksRecPtr->CFFlush = (long)CFFlush;
		xlibCallBacksRecPtr->CFReload = (long)CFReload;
		xlibCallBacksRecPtr->CFNeedReload = (long)CFNeedReload;
		xlibCallBacksRecPtr->CFLoop = (long)CFLoop;
		xlibCallBacksRecPtr->CFGetCacheInfo = (long)CFGetCacheInfo;
		//xlibCallBacksRecPtr->CFGetCacheFileInfo = (long)CFGetCacheFileInfo;
}

//===========================================================================================
XErr	CFInit(Boolean wantCache, Boolean wantStat, Boolean deferredMode)
{
long			i, physSlots, len, *indP;
XErr			err = noErr;
CacheStructP	cacheStrP;
BlockRef		sortIndBlock = nil;

	XThreadsEnterCriticalSection();	
	gsCacheRefBlock = nil;	
	if (wantCache)
	{	physSlots = BASE_CACHE_FILE;
		len = sizeof(CacheStruct) + (sizeof(CacheItem) * (physSlots-1));
		if (gsCacheRefBlock = NewBlock(len, &err, (Ptr*)&cacheStrP))
		{	//cacheStrP = CACHE_PTR;
			ClearBlock(cacheStrP, len);
			cacheStrP->active = true;
		}
	}
	else 
	{	physSlots = 0;
		len = sizeof(CacheStruct) - sizeof(CacheItem);
		if (gsCacheRefBlock = NewBlock(len, &err, (Ptr*)&cacheStrP))
		{	//cacheStrP = CACHE_PTR;
			ClearBlock(cacheStrP, len);
			cacheStrP->active = false;
		}
	}

	if NOT(err)
	{	if (sortIndBlock = NewBlock(sizeof(long) * BASE_CACHE_FILE, &err, (Ptr*)&indP))
		{
		#ifdef __MEM_CANMOVE__
			cacheStrP = CACHE_PTR;
		#endif
			cacheStrP->sortIndBlock = sortIndBlock;
			//indP = (long*)GetPtr(sortIndBlock);
			for (i = 0; i < BASE_CACHE_FILE; i++, indP++)
				*indP = i;
			cacheStrP->wantStat = wantStat;
			cacheStrP->physSlots = physSlots;
			cacheStrP->logicSlots = 0;
			cacheStrP->needReload = false;
			cacheStrP->deferredMode = deferredMode;
			XGetSeconds(&cacheStrP->initSecs);
			gsFlushStop = XThreadsCreateSemaphore(_GREEN, &err);
		}
	}
	gsCurrentUsers = 0;
	XThreadsLeaveCriticalSection();

if (err)
{	if (gsCacheRefBlock)
		DisposeBlock(&gsCacheRefBlock);
	if (sortIndBlock)
		DisposeBlock(&sortIndBlock);
}	
return err;
}

//===========================================================================================
XErr	CFEnd(void)
{
int				i, numFiles = 0;
CacheStructP	cacheStrP;
CacheItemP		cacheItP;
XErr			err = noErr;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);

	XThreadsEnterCriticalSection();	
	LockBlock(gsCacheRefBlock);
	cacheStrP = CACHE_PTR;
	numFiles = cacheStrP->logicSlots;
	for (i = 0; i < numFiles; i++)
	{	cacheItP = &cacheStrP->cacheIt[i];
		if (cacheItP->text)
			DisposeBlock(&cacheItP->text);
	}	
	DisposeBlock(&cacheStrP->sortIndBlock);
	DisposeBlock(&gsCacheRefBlock);
	err = XThreadsCloseSemaphore(gsFlushStop);
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	CFGetFileSpecial(XFilePathPtr filePath, CacheResult *cacheResP, char *fileDataP)
{
XErr		err = noErr;
long		redirFileTextLen;
Ptr			textP;

	CEquStr(cacheResP->filePath, filePath);
	XGetMilliseconds(&cacheResP->getTime);
	cacheResP->posInCache = 0;
	redirFileTextLen = CLen(fileDataP);
	if (cacheResP->fileData = NewBlockLocked(redirFileTextLen, &err, &textP))
	{	//textP = GetPtr(cacheResP->fileData);
		CopyBlock(textP, fileDataP, redirFileTextLen);
		cacheResP->fileSize = redirFileTextLen;
		cacheResP->wasInCache = false;
		//LockBlock(cacheResP->fileData);
		gsCurrentUsers++;
	}

return err;
}

//===========================================================================================
XErr	CFGetFile(XFilePathPtr filePath, CacheResult *cacheResP)
{
XErr				err = noErr;
register CacheItemP	cacheItP = nil;
CacheStructP		cacheStrP;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);
	if (CLen(filePath) > 255)
		return XError(kXHelperError, Cache_Err_PathTooLong);
	
	if NOT(err = XThreadsWaitSemaphore(&gsFlushStop, kCacheTimeout))
	{	// Enter critical section
		XThreadsEnterCriticalSection();
		// Begin...
		cacheStrP = CACHE_PTR;
		// check if the file is in cache
		if (cacheStrP->active && (cacheItP = _CFGetCacheRec(filePath, &cacheResP->posInCache)))
		{	if NOT(cacheItP->currentUsers++)
				LockBlock(cacheItP->text);
			cacheResP->fileData = cacheItP->text;
			cacheResP->fileSize = cacheItP->textSize;
			cacheResP->wasInCache = true;
			cacheResP->dontCache = false;
			CopyBlock(cacheResP->userDatas, cacheItP->userDatas, CACHE_MAX_USER_DATA);
			//cacheResP->userData = cacheItP->userData;
			gsCurrentUsers++;
		}
		else
		{	// Read the file (also if the cache is inactive)
			if NOT(err = _CFGetFileData(filePath, &cacheResP->fileData, &cacheResP->fileSize))
			{
				#ifdef __MEM_CANMOVE__
					cacheStrP = CACHE_PTR;		// reload
				#endif
				cacheResP->wasInCache = false;
				cacheResP->dontCache = false;
				ClearBlock(cacheResP->userDatas, CACHE_MAX_USER_DATA);
				//cacheResP->userData = 0;
				LockBlock(cacheResP->fileData);
				gsCurrentUsers++;
			}
		}
		if NOT(err)
		{	CEquStr(cacheResP->filePath, filePath);
			if (cacheStrP->wantStat)
			{	XGetMilliseconds(&cacheResP->getTime);
				if (cacheItP)
					XGetSeconds(&cacheItP->lastAccess);
			}
			else
				cacheResP->getTime = 0;
		}
		// ...End
		// Leave critical section
		XThreadsLeaveCriticalSection();
		XThreadsSemaphoreGreen(&gsFlushStop);
	}
	
return err;
}

//===========================================================================================
XErr	CFGetFileInfo(XFilePathPtr filePath, CacheItemInfoP itemInfoP)
{
XErr				err = noErr;
register CacheItemP	cacheItP;
CacheStructP		cacheStrP;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);
	if (CLen(filePath) > 255)
		return XError(kXHelperError, Cache_Err_PathTooLong);
	
	// Enter critical section
	XThreadsEnterCriticalSection();
	// Begin...
	cacheStrP = CACHE_PTR;
	
	// is the file in cache?
	if (cacheStrP->active && (cacheItP = _CFGetCacheRec(filePath, nil)))
	{	CEquStr(itemInfoP->path, cacheItP->filePath);
		itemInfoP->sum = cacheItP->sum;
		itemInfoP->min = cacheItP->min;
		itemInfoP->max = cacheItP->max;
		itemInfoP->hits = cacheItP->hits;
		itemInfoP->last = cacheItP->last;
		itemInfoP->fileSize = cacheItP->textSize;
		itemInfoP->currentUsers = cacheItP->currentUsers;
		itemInfoP->lastAccess = cacheItP->lastAccess;
	}
	else
		*itemInfoP->path = 0;

	// ...End
	// Leave critical section
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	CFDeferredRun(long *deferredIDP)
{
XErr	err = noErr;

	XThreadsEnterCriticalSection();	
	gsCurrentUsers++;
	*deferredIDP = 0;
	*deferredIDP = BufferCreateClear(sizeof(DeferredRec) * 20, &err);
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	CFDeferredExit(long deferredID)
{
	if (deferredID)
	{	long					size;
		BlockRef				bl;
		register DeferredRec 	*tempP;
		register int			count;
		register CacheStructP	cacheStrP;
		register CacheItemP		cItemP;
		
		XThreadsEnterCriticalSection();	
		bl = BufferGetBlockRef(deferredID, &size);
		LockBlock(bl);
		tempP = (DeferredRec*)GetPtr(bl);	
		if (count = (size / sizeof(DeferredRec)))
		{	cacheStrP = CACHE_PTR;
			do {	
				if (tempP->block)
				{	if (tempP->toDispose)
					{	DisposeBlock(&tempP->block);
						#ifdef __MEM_CANMOVE__
							cacheStrP = CACHE_PTR;
						#endif
					}
					else
					{	cItemP = &cacheStrP->cacheIt[tempP->cacheIndex];
						// IncrementLockCount(&cItemP->text);	// was decremented
						if NOT(cItemP->currentUsers)
							UnlockBlock(cItemP->text);
					}
				}
				tempP++;
				} while(--count);
		}
		BufferFree(deferredID);
		gsCurrentUsers--;
		XThreadsLeaveCriticalSection();
	}

return noErr;
}

//===========================================================================================
XErr	CFReleaseFile(CacheResult *cacheResP, long deferredID)
{
unsigned long			howMuch = 0;
register CacheStructP	cacheStrP;
register CacheItemP		cacheItP;
XErr					err = noErr;
unsigned long			myEndTime;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);

	XThreadsEnterCriticalSection();
	cacheStrP = CACHE_PTR;
	if (cacheStrP->active)
	{	if (cacheResP->wasInCache)
		{	cacheItP = &cacheStrP->cacheIt[cacheResP->posInCache];
			if NOT(--cacheItP->currentUsers)
				err = _CFReleaseMemoryBlock(deferredID, &cacheItP->text, cacheResP->posInCache, ONLY_UNLOCK);
			if (NOT(CACHE_USER_SIGNIFICANT(cacheItP->userDatas)) && CACHE_USER_SIGNIFICANT(cacheResP->userDatas) && NOT(cacheResP->dontCache))
				CopyBlock(cacheItP->userDatas, cacheResP->userDatas, CACHE_MAX_USER_DATA);
			if (cacheStrP->wantStat)
			{	XGetMilliseconds(&myEndTime);
				howMuch = (myEndTime - cacheResP->getTime);
				cacheItP->hits++;
				cacheItP->last = howMuch;
				if (howMuch > cacheItP->max)
					cacheItP->max = howMuch;			
				if (howMuch < cacheItP->min)
					cacheItP->min = howMuch;
				cacheItP->sum += howMuch;					// in ms
			}
		}
		else
		{	if (cacheResP->dontCache)
				err = _CFReleaseMemoryBlock(deferredID, &cacheResP->fileData, -1, TO_DISPOSE);
			else
			{	if (cacheStrP->wantStat)
				{	XGetMilliseconds(&myEndTime);
					howMuch = (myEndTime - cacheResP->getTime);
				}				
				if (cacheItP = _CFGetCacheRec(cacheResP->filePath, nil))
				{	if (GetPtr(cacheResP->fileData) == GetPtr(cacheItP->text))		// same user ask to dispose twice
						CDebugStr("Cache: Same file disposed twice");
					else															// another thread already cached it?
						err = _CFReleaseMemoryBlock(deferredID, &cacheResP->fileData, -1, TO_DISPOSE);
				}
				else
				{	if NOT(err = _CFCacheThisFile(cacheResP->filePath, cacheResP->fileData, &cacheResP->posInCache, howMuch, cacheResP->userDatas))
						err = _CFReleaseMemoryBlock(deferredID, &cacheResP->fileData, cacheResP->posInCache, ONLY_UNLOCK);	// 0 users
				}
			}
		}
		--gsCurrentUsers;
	}
	else
	{	err = _CFReleaseMemoryBlock(deferredID, &cacheResP->fileData, -1, TO_DISPOSE);
		--gsCurrentUsers;
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr	CFFlushFile(XFilePathPtr filePath)
{
XErr				err = noErr;
register CacheItemP	cacheItP;
CacheStructP		cacheStrP;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);
	if (CLen(filePath) > 255)
		return XError(kXHelperError, Cache_Err_PathTooLong);
	
	// If someone is flushing, wait
	XThreadsEnterCriticalSection();	
	cacheStrP = CACHE_PTR;
	if (cacheStrP->active)
	{	if (cacheItP = _CFGetCacheRec(filePath, nil))
		{	cacheItP->flags |= kToReload;
			cacheStrP->needReload = true;
		}
	}
	XThreadsLeaveCriticalSection();	
		
return err;
}

//===========================================================================================
XErr	CFFlushFilesMatching(long userData)
{
XErr				err = noErr;
register CacheItemP	cacheItP;
CacheStructP		cacheStrP;
int					totFiles, i;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);
	
	// If someone is flushing, wait
	XThreadsEnterCriticalSection();	
	// Begin...
	cacheStrP = CACHE_PTR;
	if (totFiles = cacheStrP->logicSlots)
	{	cacheItP = &cacheStrP->cacheIt[0];
		for (i = 0; i < totFiles; i++, cacheItP++)
		{	//if NOT(CCompareStrings_cs(userDataStr, cacheItP->userDataStr))
			if (userData == CACHE_USER_SIGNIFICANT(cacheItP->userDatas))
				cacheItP->flags |= kToReload;
		}
		cacheStrP->needReload = true;
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	CFFlush(Boolean toActivate)
{
int						logicSlots, i;
register CacheStructP	cacheStrP;
register CacheItemP		cacheItP;
long					*indP, len;
XErr					err = noErr;
unsigned long 			initMilliSecs, millisecs, lastTicks = 0;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);

	if NOT(err = XThreadsWaitSemaphore(&gsFlushStop, kCacheTimeout))
	{	// Wait that users exit
		XGetMilliseconds(&initMilliSecs);
		while ((gsCurrentUsers > 0) && NOT(err))
		{	if NOT(err = XYield(&lastTicks))
			{	XGetMilliseconds(&millisecs);
				if ((millisecs - initMilliSecs) > kCacheTimeout)
					err = XError(kXLibError, ErrXThreads_Timeout);
			}
		}
		if NOT(err)
		{	XThreadsEnterCriticalSection();
			// Begin Flush
			cacheStrP = CACHE_PTR;
			logicSlots = cacheStrP->logicSlots;
			if (cacheStrP->active)
			{	LockBlock(gsCacheRefBlock);
				if (logicSlots)
				{	for (i = 0; (i < logicSlots) && NOT(err); i++)
					{	cacheItP = &cacheStrP->cacheIt[i];
						if (cacheItP->text)
							err = DisposeBlock(&cacheItP->text);
					}
					if NOT(err)
					{	len = sizeof(CacheItem) * logicSlots;
						cacheStrP->logicSlots = 0;
						ClearBlock(&cacheStrP->cacheIt[0], len);
					}
				}
				UnlockBlock(gsCacheRefBlock);
				#ifdef __MEM_CANMOVE__
					cacheStrP = CACHE_PTR;
				#endif
				if NOT(toActivate)
					cacheStrP->active = false;
			}
			else if (toActivate)
				cacheStrP->active = true;
			indP = (long*)GetPtr(cacheStrP->sortIndBlock);
			ClearBlock(indP, logicSlots * sizeof(long));
			for (i = 0; i < BASE_CACHE_FILE; i++, indP++)
				*indP = i;
			XGetSeconds(&cacheStrP->initSecs);
			// End Flush
			XThreadsLeaveCriticalSection();
		}
		XThreadsSemaphoreGreen(&gsFlushStop);
	}
	
return err;
}

//===========================================================================================
Boolean	CFNeedReload(void)
{
	return CACHE_PTR->needReload;
}

//===========================================================================================
XErr	CFLoop(CFLoopCallBack CallBack, long param)
{
int						logicSlots, i;
register CacheStructP	cacheStrP;
register CacheItemP		cacheItP;
XErr					err = noErr;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);

	// Begin Loop
	cacheStrP = CACHE_PTR;
	logicSlots = cacheStrP->logicSlots;
	if (cacheStrP->active)
	{	LockBlock(gsCacheRefBlock);
		if (logicSlots)
		{	for (i = 0; (i < logicSlots) && NOT(err); i++)
			{	cacheItP = &cacheStrP->cacheIt[i];
				CallBack(cacheItP->userDatas, param);
			}
		}
		UnlockBlock(gsCacheRefBlock);
	}
	// End Loop
	
return err;
}

//===========================================================================================
XErr	CFReload(void)
{
int						logicSlots, i;
register CacheStructP	cacheStrP;
register CacheItemP		cacheItP;
XErr					err = noErr;
unsigned long 			initMilliSecs, millisecs, lastTicks = 0;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);

	if NOT(err = XThreadsWaitSemaphore(&gsFlushStop, kCacheTimeout))
	{	// Wait that users exit
		XGetMilliseconds(&initMilliSecs);
		while ((gsCurrentUsers > 0) && NOT(err))
		{	if NOT(err = XYield(&lastTicks))
			{	XGetMilliseconds(&millisecs);
				if ((millisecs - initMilliSecs) > kCacheTimeout)
					err = XError(kXLibError, ErrXThreads_Timeout);
			}
		}
		if NOT(err)
		{	XThreadsEnterCriticalSection();
			// Begin Reload
			cacheStrP = CACHE_PTR;
			logicSlots = cacheStrP->logicSlots;
			if (cacheStrP->active && cacheStrP->needReload)
			{	LockBlock(gsCacheRefBlock);
				if (logicSlots)
				{	for (i = 0; (i < logicSlots) && NOT(err); i++)
					{	cacheItP = &cacheStrP->cacheIt[i];
						if (cacheItP->text && (cacheItP->flags & kToReload))
						{	DisposeBlock(&cacheItP->text);
							_CFGetFileData(cacheItP->filePath, &cacheItP->text, &cacheItP->textSize);
							ClearBlock(cacheItP->userDatas, CACHE_MAX_USER_DATA);
							cacheItP->flags &= (0xFFFFFFFF ^ kToReload);
						}
					}
				}
				UnlockBlock(gsCacheRefBlock);
			}
			cacheStrP->needReload = false;
			// End Reload
			XThreadsLeaveCriticalSection();
		}
		XThreadsSemaphoreGreen(&gsFlushStop);
	}
	
return err;
}

//===========================================================================================
XErr	CFGetCacheInfo(BlockRef *cacheItemInfoP, long *totItemsP, unsigned long *totalSizeP, long userData)
{
CacheItemP		cItemP;
CacheStructP	cacheStrP;
BlockRef		infos = nil;
unsigned long	size, totalSize = 0;
CacheItemInfoP	infosP = nil;
int				i, totFiles;
XErr			err = noErr;
Boolean			allocated = false;
int				realTotFiles = 0;

	if NOT(gsCacheRefBlock)
		return XError(kXHelperError, Cache_Err_NotInitialized);

	XThreadsEnterCriticalSection();
	cacheStrP = CACHE_PTR;
	if (cacheStrP->active)
	{	totFiles = cacheStrP->logicSlots;
		size = totFiles * sizeof(CacheItemInfo);
		if NOT(size)
			size = sizeof(CacheItemInfo);
		if (cacheItemInfoP)
		{	if (*cacheItemInfoP)
			{	infos = *cacheItemInfoP;
				if NOT(err = SetBlockSize(infos, size))
					infosP = (CacheItemInfoP)GetPtr(infos);
			}
			else
			{	if (infos = NewBlock(size, &err, (Ptr*)&infosP))
					allocated = true;
			}
			if NOT(err)
			{
			#ifdef __MEM_CANMOVE__
				cacheStrP = CACHE_PTR;
			#endif
				if (infos && NOT(err))
				{	cItemP = &cacheStrP->cacheIt[0];
					realTotFiles = 0;
					for (i = 0; i <= totFiles; i++, cItemP++)
					{	//if (NOT(userDataStr) || NOT(CCompareStrings_cs(userDataStr, cItemP->userDataStr)))
						if (NOT(userData) || (userData == CACHE_USER_SIGNIFICANT(cItemP->userDatas)))
						{	if NOT(cItemP->flags & kToReload)
							{	CEquStr(infosP->path, cItemP->filePath);
								infosP->sum = cItemP->sum;
								infosP->min = cItemP->min;
								infosP->max = cItemP->max;
								infosP->hits = cItemP->hits;
								infosP->last = cItemP->last;
								infosP->fileSize = cItemP->textSize;
								infosP->currentUsers = cItemP->currentUsers;
								infosP->lastAccess = cItemP->lastAccess;
								totalSize += cItemP->textSize;
								realTotFiles++;
								infosP++;
							}
						}
					}
				}
			}
		}
	}
	else
		totFiles = 0;
	XThreadsLeaveCriticalSection();
		
if (err)
{	if (allocated)
		DisposeBlock(&infos);
}
else
{	if (totItemsP)
		*totItemsP = realTotFiles;
	if (cacheItemInfoP)
		*cacheItemInfoP = infos;
	if (totalSizeP)
		*totalSizeP = totalSize;
}
return err;
}

#else
#if __MWERKS__
#pragma mark-
#endif

extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
//===========================================================================================
XErr	CFInit(Boolean wantCache, Boolean wantStat, Boolean deferredMode)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(wantCache, wantStat, deferredMode)
#endif
	return noErr;
}

//===========================================================================================
XErr	CFEnd(void)
{
	return noErr;
}

//===========================================================================================
XErr	CFGetFile(XFilePathPtr filePath, CacheResult *cacheResP)
{
XErr	(*p)(XFilePathPtr filePath, CacheResult *cacheResP) = (void*)gXLibCallBacksRecPtr->CFGetFile;

	return p(filePath, cacheResP);
}

//===========================================================================================
XErr	CFGetFileSpecial(XFilePathPtr filePath, CacheResult *cacheResP, char *fileDataP)
{
XErr	(*p)(XFilePathPtr filePath, CacheResult *cacheResP, char *fileDataP) = (void*)gXLibCallBacksRecPtr->CFGetFileSpecial;

	return p(filePath, cacheResP, fileDataP);
}

//===========================================================================================
XErr	CFGetFileInfo(XFilePathPtr filePath, CacheItemInfoP itemInfoP)
{
XErr	(*p)(XFilePathPtr filePath, CacheItemInfoP itemInfoP) = (void*)gXLibCallBacksRecPtr->CFGetFileInfo;

	return p(filePath, itemInfoP);
}

//===========================================================================================
XErr	CFDeferredRun(long *deferredIDP)
{
XErr	(*p)(long *deferredIDP) = (void*)gXLibCallBacksRecPtr->CFDeferredRun;

	return p(deferredIDP);
}

//===========================================================================================
XErr	CFDeferredExit(long deferredID)
{
XErr	(*p)(long deferredID) = (void*)gXLibCallBacksRecPtr->CFDeferredExit;

	return p(deferredID);
}

//===========================================================================================
XErr	CFReleaseFile(CacheResult *cacheResP, long deferredID)
{
XErr	(*p)(CacheResult *cacheResP, long deferredID) = (void*)gXLibCallBacksRecPtr->CFReleaseFile;

	return p(cacheResP, deferredID);
}

//===========================================================================================
XErr	CFFlushFile(XFilePathPtr filePath)
{
XErr	(*p)(XFilePathPtr filePath) = (void*)gXLibCallBacksRecPtr->CFFlushFile;

	return p(filePath);
}

//===========================================================================================
XErr	CFFlushFilesMatching(long userData)
{
XErr	(*p)(long userData) = (void*)gXLibCallBacksRecPtr->CFFlushFilesMatching;

	return p(userData);
}

//===========================================================================================
XErr	CFFlush(Boolean toActivate)
{
XErr	(*p)(Boolean toActivate) = (void*)gXLibCallBacksRecPtr->CFFlush;

	return p(toActivate);
}

//===========================================================================================
XErr	CFReload(void)
{
XErr	(*p)(void) = (void*)gXLibCallBacksRecPtr->CFReload;

	return p();
}

//===========================================================================================
Boolean	CFNeedReload(void)
{
Boolean	(*p)(void) = (void*)gXLibCallBacksRecPtr->CFNeedReload;

	return p();
}

//===========================================================================================
XErr	CFLoop(CFLoopCallBack CallBack, long param)
{
XErr	(*p)(CFLoopCallBack CallBack, long param) = (void*)gXLibCallBacksRecPtr->CFLoop;

	return p(CallBack, param);
}

//===========================================================================================
XErr	CFGetCacheInfo(BlockRef *cacheItemInfoP, long *totItemsP, unsigned long *totalSizeP, long userData)
{
XErr	(*p)(BlockRef *cacheItemInfoP, long *totItemsP, unsigned long *totalSizeP, long userData) = (void*)gXLibCallBacksRecPtr->CFGetCacheInfo;

	return p(cacheItemInfoP, totItemsP, totalSizeP, userData);
}

//===========================================================================================
/*XErr	CFGetCacheFileInfo(char *filePath, CacheItemInfoP infosP)
{
XErr	(*p)(char *filePath, CacheItemInfoP infosP) = (void*)gXLibCallBacksRecPtr->CFGetCacheFileInfo;

	return p(filePath, infosP);
}*/
#endif	// __XLIB_CLIENT__


