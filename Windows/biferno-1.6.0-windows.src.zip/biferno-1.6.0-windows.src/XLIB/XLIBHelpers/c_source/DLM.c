/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: DLM.c,v 1.31 2008-04-18 11:57:51 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "SlotMgr.h"

#if __UNIX_XLIB__
	#include <errno.h>
#endif

/*
		DICOTO MIC LIST MANAGER
*/

#define DLM_VERSION				2
#define DLM_LITTLE_ENDIAN		X_LITTLE_ENDIAN
#define DLM_BIG_ENDIAN			X_BIG_ENDIAN

#define ITEM_MIN_SIZE		32

//#define	NULL_STRING	""
//#define MAX_NUM_ITEMS			0xFFFFFFFF

#define _2K						(long)(2L * 1024L)		// Main Block Buffer expand step
#define _512B					(long)(512L)			// Offset's and Index's Block Buffer expand step

#define	DLM_MINIMAL_FILE_LENGTH		8					// DLM on disk: 1 (Byte order) + 3 (pad) + 4 (version)

// Array internal structure
typedef struct {
				DLMRef	arDLRef;	// must be always at first pos
				long	arMaxDim;
				} ArrayRec, *ArrayRecP;

/* DLMItem struct describing single object:
logicLen is a long if the object is single, or if the object is matrix
with fixedSize (for matrixs physicLen is always "dinamically" fixed. */

#define	NAME_MAX_LENGTH	255
typedef struct {
				long	userData;					// user data
				long	valueLogicLen;				// logicLen of the object
				long	valuePhysicLen;				// physicLen of the object
				long	superID;
		unsigned short	flags;						// flags (fixedSize etc...)
				Byte	namePaddedLen;				// if name is empty 0 else _PadLong(nameLen)
				char	name[1];					// if name is empty 0 else first char of the name (is always 1 byte)
				char	value[ITEM_MIN_SIZE];		// name (nameLen+1) + value (content) of the object (will expand)
				} DLMItem, *DLMItemP;

// names	->	CmpName(obj1->name, obj2->name);
// value	->	obj1->value + obj1->namePaddedLen;
#define	VALUE(itemP)	(((DLMItemP)itemP)->value + ((DLMItemP)itemP)->namePaddedLen)
				
/* DLMItem struct describing the whole list*/
typedef struct {
				long		listType;			// list type
	   			long		totItems;			// total numbers of objects
	   			long		totArrays;			// total arrays in list
				long		totPhysLen;			// phisical total length of the list
				long		offsets;			// offset array buffer ID
				BlockRef	offsetsBL;			// offset array blockRef (to go faster)
				long		indexs;				// index array buffer ID
				BlockRef	indexsBL;			// index array blockRef (to go faster)
				long		arrayUserData;
				Boolean		pad1;
				Boolean		dirty;
				Boolean		acceptDuplicates;
				Boolean		locked;
				Byte		listUserData[LIST_USER_DATA_DIM];
				XFileRef	fileRef;
				DLMRef		superList;
				DLMItem		item[1];
				} DLMRec, *DLMRecP;

#define	GET_LIST_BLOCK(listID, listP)					BufferGetBlockRefExt(listID, (Ptr*)&listP)

/*
#define	GET_LIST_BLOCK(listID)			BufferGetBlockRef(listID, nil)
#define	GET_LIST_PTR(listBlock)			((DLMRecP)GetPtr(listBlock))

#define	GET_OFFSETS(listBlock)			((DLMRecP)GetPtr(listBlock))->offsetsBL
#define	GET_INDEXS(listBlock)			((DLMRecP)GetPtr(listBlock))->indexsBL

#define	GET_ITEM_PTR(listBlock, offsetP, objID)						(DLMItemP)((Ptr)GetPtr(listBlock) + ((long*)offsetP)[objID])

*/
//#define	GET_ITEM_PTR_SORTED(listBlock, offsetP, indexP, itemIDX)	(DLMItemP)((Ptr)GetPtr(listBlock) + ((long*)offsetP)[indexP[itemIDX]])


//#define	DEBUG_ALLOW_SWAP_BYTE_ORDER	1

static unsigned long	gThreadLocking = 0;
static Boolean			gsOkGlobalDispose = false;

//===========================================================================================
static XErr	_DebugErrListLocked(char *funcName, XErr xerror)
{
CStr255		msg;

	sprintf(msg, "DLM DEBUG - %s: DLM_Err_ListIsLocked (%d is locking)\n", funcName, (int)gThreadLocking);
//#ifdef _AVOID_DLM_LOG_
	printf(msg);
/*#else
	LogFormatted(0, 0, nil, msg);
#endif*/

return xerror;
}

//===========================================================================================
static void	_EnterCS(void)
{
	XThreadsEnterCriticalSection();
}

//===========================================================================================
static void	_LeaveCS(void)
{
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
/*static unsigned long Pthread_self(void)
{
unsigned long threadID;

	XGetCurrentThread(&threadID);

return threadID;
}*/

//===========================================================================================
/*static void	_DLM_Debug(char *opt, DLMRef ref)
{
CStr255			aCStr;
long			tot, tLen;
static XFileRef	debugRefNum = 0;
DLMRecP			listP;

	_EnterCS();
	if NOT(debugRefNum)
	{	XGetApplicationFolderPath(aCStr);
		CAddStr(aCStr, "DLMDebug");
		OpenXFile(aCStr, CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &debugRefNum);
	}
	if (ref)
	{	GET_LIST_BLOCK(ref, listP);
		if (listP)
			tot = listP->totItems;
		else
			tot = -1;
	}
	else
		tot = -1;
	sprintf(aCStr, "%d: %s %d (%d)\n", Pthread_self(), opt, ref, tot);
	tLen = CLen(aCStr);
	if (WriteXFile(debugRefNum, aCStr, &tLen))
	{	
	Ptr	p = 0;
	
		*p = 0;	// stop please!
	}
	_LeaveCS();
}
*/
typedef struct {
				long	 	flagToToggle;
				long 		turnFlag;
				} TurnFlagParamRec;

//===========================================================================================
static XErr	_TurnOnFlagCallBack(DLMRef dlRef, long objID, unsigned short flags, long userData, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags, userData)
#endif
TurnFlagParamRec	*paramP = (TurnFlagParamRec*)param;

	return DLM_TurnOnFlag(dlRef, objID, paramP->flagToToggle, paramP->turnFlag);
}

//===========================================================================================
static XErr	_TurnOffFlagCallBack(DLMRef dlRef, long objID, unsigned short flags, long userData, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags, userData)
#endif
TurnFlagParamRec	*paramP = (TurnFlagParamRec*)param;

	return DLM_TurnOffFlag(dlRef, objID, paramP->flagToToggle, paramP->turnFlag);
}

//===========================================================================================
static unsigned short _FilterFlags(DLMRef dlRef, long objId, unsigned short originalFlags)
{
	XErr			err = noErr;
	unsigned short	objFlags, newFlags;
	
	newFlags = originalFlags;
	if NOT(err = DLM_GetInfo(dlRef, objId, &objFlags, nil, nil))
	{
		if (objFlags & kFixedSize)
			newFlags |= kFixedSize;
		else
			newFlags &= (0xFFFF ^ kFixedSize);		
		
		if (objFlags & kIsDlm)
			newFlags |= kIsDlm;
		else
			newFlags &= (0xFFFF ^ kIsDlm);		
	}
	return newFlags;
}
//===========================================================================================
/*static void	x_DeleteOneOffset(long offsetBufferBlock, long *offsetP, long tot, long pos, long physicLength)
{
int		i;
long	toMove, *tOffP, n;

	tOffP = offsetP + pos + 1;
	n = tot - (pos + 1);
	for (i = 0; i < n; i++, tOffP++)
		*tOffP -= physicLength;
	if ((toMove = n - pos - 1) > 0)
		CopyBlock(offsetP + pos, offsetP + pos + 1, toMove * sizeof(long));
	if (tot > 1)
	{	if (BufferSetLength(offsetBufferBlock, (tot-1) * sizeof(long)))
			CDebugStr("_DeleteOneOffset: BufferSetLength (shrinking) failed");
	}
}
*/
//===========================================================================================
static void	_DeleteOneOffset(long offsetBufferBlock, long *offsetP, long tot, long pos, long physicLength)
{
long	*tOffP, n, saveN;

	#ifdef MEM_DEBUG
		BufferSetLength(offsetBufferBlock, tot * sizeof(long));
		BufferGetBlockRefExt(offsetBufferBlock, (Ptr*)&offsetP);
	#endif

	tOffP = offsetP + pos + 1;
	n = saveN = tot - (pos + 1);
	if (n > 0)
	{	do	{
			*tOffP++ -= physicLength;
			} while (--n);
		CopyBlock(offsetP + pos, offsetP + pos + 1, saveN * sizeof(long));
	}
	if (tot > 1)
	{	if (BufferSetLength(offsetBufferBlock, (tot-1) * sizeof(long)))
			CDebugStr("_DeleteOneOffset: BufferSetLength (shrinking) failed");
	}
}

//===========================================================================================
/*static void	x_DeleteOneIndex(long indexBufferBlock, long *indexP, long tot, long pos)
{
	if (indexBufferBlock)
	{	
	int		i;
	long	toMove, deletePos, *tIndP, n;

		deletePos = 0;
		tIndP = indexP;
		n = tot;
		for (i = 0; i < n; i++, tIndP++)
		{	if (*tIndP > pos)
				(*tIndP)--;
			else if (*tIndP == pos)
				deletePos = i;
		}
		if ((toMove = n - deletePos - 1) > 0)
			CopyBlock(indexP + deletePos, indexP + deletePos + 1, toMove * sizeof(long));
		if (tot > 1)
		{	if (BufferSetLength(indexBufferBlock, (tot-1) * sizeof(long)))
				CDebugStr("_DeleteOneIndex: BufferSetLength (shrinking) failed");
		}
	}
}
*/
//===========================================================================================
static void	_DeleteOneIndex(long indexBufferBlock, long *indexP, long tot, long pos)
{
long	idx, deletePos, *tIndP, n;

if (indexBufferBlock && tot)
	{	
	#ifdef MEM_DEBUG
		BufferSetLength(indexBufferBlock, tot * sizeof(long));
		BufferGetBlockRefExt(indexBufferBlock, (Ptr*)&indexP);
	#endif

	deletePos = -1;
	tIndP = indexP;
	n = tot;
	do	{
		idx = *tIndP;
		if (idx > pos)
			*tIndP = idx - 1;
		else if (idx == pos)
			deletePos = tot - n;
		tIndP++;
		} while (--n);
	
	if (deletePos < 0)
		CDebugStr("_DeleteOneIndex: no index to del found");
	if ((n = tot - deletePos - 1) > 0)
		CopyBlock(indexP + deletePos, indexP + deletePos + 1, n * sizeof(long));

	if (tot > 1)
		{	if (BufferSetLength(indexBufferBlock, (tot-1) * sizeof(long)))
				CDebugStr("_DeleteOneIndex: BufferSetLength (shrinking) failed");
		}
	}
}

//===========================================================================================
static XErr	_CreateDLMList(DLMRef *dlRefP, long listType, long global, Boolean acceptDuplicates)
{
XErr		err = noErr;
long		dlRef, offsets = 0;//, indexs = 0;
DLMRecP		listP;
BlockRef	listBlock;

	if (global)
		_EnterCS();
	*dlRefP = 0L;
	if (dlRef = BufferCreateExt(_2K, (Boolean)global, &err))
	{	// in teoria qui: if NOT(err = BufferCheck(dlRef, sizeof(DLMRec) - sizeof(DLMItem), nil))
		// ma � sempre vero (se _2K > sizeof(DLMRec) - sizeof(DLMItem))
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		listP->totPhysLen = sizeof(DLMRec) - sizeof(DLMItem);	// 0 objects at creation time		
		listP->totItems = 0;
		//_DLM_Debug("Creating", dlRef);
		listP->fileRef = 0;
		listP->listType = listType;
		listP->totArrays = 0;
		listP->arrayUserData = DLM_USERDATA_DEFAULT;
		//listP->global = global;
		listP->dirty = true;
		listP->locked = false;
		listP->acceptDuplicates = acceptDuplicates;
		ClearBlock(listP->listUserData, LIST_USER_DATA_DIM);
		if (offsets = BufferCreate(_512B, &err))				// offset array block
		{	if NOT(err)
			{	
			#ifdef __MEM_CANMOVE__
				listP = ((DLMRecP)GetPtr(listBlock));
			#endif
				listP->offsets = offsets;
				listP->offsetsBL = BufferGetBlockRef(offsets, nil);
				listP->indexs = 0;
				listP->indexsBL = 0;
				listP->superList = 0;
				*dlRefP = dlRef;
			}
		}	
	}
	if (err)
	{	if (dlRef)
			BufferFree(dlRef);
		if (offsets)
			BufferFree(offsets);
	}
	#ifdef MEM_DEBUG
	else
	{
		DLM_CheckList(dlRef);
	}
	#endif

	//_DLM_Debug("Just Created", dlRef);
	if (global)
		_LeaveCS();
	
return err;
}

#ifdef DEBUG_ALLOW_SWAP_BYTE_ORDER
//===========================================================================================
static void	_CheckItemPByteOrder(DLMItemP itemP, Byte byteOrder)
{
	itemP->userData = SwapLong(itemP->userData, byteOrder);
	itemP->valueLogicLen = SwapLong(itemP->valueLogicLen, byteOrder);
	itemP->valuePhysicLen = SwapLong(itemP->valuePhysicLen, byteOrder);
	itemP->superID = SwapLong(itemP->superID, byteOrder);
	itemP->flags = SwapShort(itemP->flags, byteOrder);
}

//===========================================================================================
static void	_CheckByteOrders(DLMRecP listP, Byte byteOrder)
{
	listP->listType = SwapLong(listP->listType, byteOrder);
	listP->totItems = SwapLong(listP->totItems, byteOrder);
	listP->totArrays = SwapLong(listP->totArrays, byteOrder);
	listP->totPhysLen = SwapLong(listP->totPhysLen, byteOrder);
	listP->arrayUserData = SwapLong(listP->arrayUserData, byteOrder);
	listP->superList = SwapLong((long)listP->superList, byteOrder);
}
#endif

//===========================================================================================
static XErr	_LoadRecurse(Ptr *filePPtr, long *eofP, Byte byteOrder, long *indexs_P, long *offsets_P, Boolean global, DLMRef	*dlRefP)
{
long		totItems, tot1KBlocks, tot8KBlocks, indexsLength, offsetLength, listLen;
DLMRef		dlRef;
XErr		err = noErr;
DLMRecP		listP;
BlockRef	listBlock;
long		*indexsP, *offsetP;
long 		totArr, listType;
long		eof, offsets, indexs;
Ptr			fileP;

	fileP = *filePPtr;
	eof = *eofP;
#ifdef DEBUG_ALLOW_SWAP_BYTE_ORDER
	listLen = SwapLong(*(long*)fileP, byteOrder);
#else
	listLen = *(long*)fileP;
#endif
	fileP += sizeof(long);
	eof -= sizeof(long);
	if (eof < listLen)
		err = XError(kXHelperError, DLM_Err_InvalidFile);
	else
	{	tot8KBlocks = listLen / _2K + ((listLen % _2K) != 0);
		if (dlRef = BufferCreateExt(_2K, global, &err))
		{	if (tot8KBlocks > 1)
				err = BufferCheck(dlRef, tot8KBlocks * _2K, nil);
			if NOT(err)
			{	listBlock = GET_LIST_BLOCK(dlRef, listP);
				// listP = GET_LIST_PTR(listBlock);						// get the ptr
				LockBlock(listBlock);
				CopyBlock(listP, fileP, listLen);						// copy the list
			#ifdef DEBUG_ALLOW_SWAP_BYTE_ORDER
				_CheckByteOrders(listP, byteOrder);
			#endif
				listType = listP->listType;
				totItems = listP->totItems;
				fileP += listLen;
				eof -= listLen;		
				offsetLength = totItems * sizeof(long);
				if (eof < offsetLength)
					err = XError(kXHelperError, DLM_Err_InvalidFile);
				else
				{	tot1KBlocks = offsetLength / _512B + ((offsetLength % _512B) != 0);
					if (offsets = BufferCreate(_512B, &err))					// offset array block
					{	listP->offsetsBL = BufferGetBlockRef(offsets, nil);
						if (tot1KBlocks > 1)
							err = BufferCheck(offsets, tot1KBlocks * _512B, nil);
						if NOT(err)
						{	BlockRef	offsetBlockRef = BufferGetBlockRef(offsets, nil);
						#ifdef DEBUG_ALLOW_SWAP_BYTE_ORDER
							long		*tLongP, i;
						#endif
							DLMItemP	itemP;
							
							offsetP = (long*)GetPtr(offsetBlockRef);
							LockBlock(offsetBlockRef);
							CopyBlock(offsetP, fileP, offsetLength);
						#ifdef DEBUG_ALLOW_SWAP_BYTE_ORDER
							tLongP = offsetP;
							for (i = 0; i < totItems; i++, tLongP++)
							{	*tLongP = SwapLong(*tLongP, byteOrder);
								itemP = (DLMItemP)((Ptr)listP + *tLongP);
								_CheckItemPByteOrder(itemP, byteOrder);
							}
						#endif
							fileP += offsetLength;
							eof -= offsetLength;
							if (listType == ID_LIST)
								indexs = 0L;									// only ID list
							else
							{	indexsLength = totItems * sizeof(long);
								if (eof < indexsLength)
									err = XError(kXHelperError, DLM_Err_InvalidFile);
								else
								{	tot1KBlocks = indexsLength / _512B + ((indexsLength % _512B) != 0);
									if (indexs = BufferCreate(_512B, &err))		// index array block
									{	listP->indexsBL = BufferGetBlockRef(indexs, nil);
										if (tot1KBlocks > 1)
											err = BufferCheck(indexs, tot1KBlocks * _512B, nil);
										if NOT(err)
										{	indexsP = (long*)GetPtr(BufferGetBlockRef(indexs, nil));
											CopyBlock(indexsP, fileP, indexsLength);
										#ifdef DEBUG_ALLOW_SWAP_BYTE_ORDER
											tLongP = indexsP;
											for (i = 0; i < totItems; i++, tLongP++)
												*tLongP = SwapLong(*tLongP, byteOrder);
										#endif
											fileP += indexsLength;
											eof -= indexsLength;
											// arrays
											if (totArr = listP->totArrays)
											{	long		arrIndexs, arrOffsets;
												DLMRef		arrDLRef;
												int			i;
												DLMRecP		arListP;
												
												for (i = 0; (i < totItems) && totArr && NOT(err); i++, offsetP++)
												{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
													if (itemP->flags & kIsArray)
													{	if NOT(err = _LoadRecurse(&fileP, &eof, byteOrder, &arrIndexs, &arrOffsets, global, &arrDLRef))
														{	CopyBlock(VALUE(itemP), &arrDLRef, sizeof(DLMRef));
															GET_LIST_BLOCK(arrDLRef, arListP);
															arListP->indexs = arrIndexs;
															arListP->offsets = arrOffsets;
															arListP->offsetsBL = BufferGetBlockRef(arrOffsets, nil);
															if (arrIndexs)
																arListP->indexsBL = BufferGetBlockRef(arrIndexs, nil);
														}
														totArr--;
													}
												}
											}
											if NOT(err)
											{	*indexs_P = indexs;
												*offsets_P = offsets;
												*dlRefP = dlRef;
											}
										}
										if (err)
											BufferFree(indexs);
									}
								}
							}
							if NOT(err)
								LockBlock(offsetBlockRef);
						}
						if (err)
							BufferFree(offsets);
					}
				}
				if NOT(err)
					UnlockBlock(listBlock);
			}
			if (err)
				BufferFree(dlRef);
		}
		if NOT(err)
		{	*filePPtr = fileP;
			*eofP = eof;
		}
	}

return err;
}

//===========================================================================================
static XErr	_SaveRecurse(DLMRecP listP, XFileRef fileRef)
{
long		totItems, i, totArr, *indexP, *offsetP, aLong, count;
XErr		err = noErr;
BlockRef	arrayDLBlock;
DLMRef		arrayDLRef;
DLMRecP		arrayDLListP;

	listP->dirty = false;
	totItems = listP->totItems;
	aLong = listP->totPhysLen;
	count = sizeof(long);
	// list phys len
	if NOT(err = WriteXFile(fileRef, (Ptr)&aLong, &count))
	{	count = listP->totPhysLen;
		// list body
		if NOT(err = WriteXFile(fileRef, (Ptr)listP, &count))
		{	// offsets
			offsetP = (long*)GetPtr(listP->offsetsBL);
			count = sizeof(long) * totItems;
			if NOT(err = WriteXFile(fileRef, (Ptr)offsetP, &count))
			{	// indexs
				if (listP->listType != ID_LIST)
				{	indexP = (long*)GetPtr(listP->indexsBL);
					count = sizeof(long) * totItems;
					err = WriteXFile(fileRef, (Ptr)indexP, &count);
				}
				if NOT(err)
				{	DLMItemP	itemP;
				
					// arrays
					totArr = listP->totArrays;
					for (i = 0; (i < totItems) && totArr && NOT(err); i++, offsetP++)
					{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
						if (itemP->flags & kIsArray)
						{	arrayDLRef = *(DLMRef*)VALUE(itemP);
							arrayDLBlock = GET_LIST_BLOCK(arrayDLRef, arrayDLListP);
							LockBlock(arrayDLBlock);
							err = _SaveRecurse(arrayDLListP, fileRef);
							UnlockBlock(arrayDLBlock);
							totArr--;
						}
					}
					if (listP->superList)
					{	BlockRef	superBlock;
						DLMRecP		superListP;
					
						superBlock = GET_LIST_BLOCK(listP->superList, superListP);
						LockBlock(arrayDLBlock);
						err = _SaveRecurse(superListP, fileRef);
						UnlockBlock(arrayDLBlock);
					}
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static Boolean	_IsDirty(DLMRecP listP)
{
long		totItems, totArr, *offsetP;
DLMRef		arrayDLRef;
DLMItemP	itemP;
int			i;
DLMRecP		arListP;

	if (listP->dirty)
		return true;
	else
	{	totItems = listP->totItems;
		if (totArr = listP->totArrays)
		{	offsetP = (long*)GetPtr(listP->offsetsBL);
			for (i = 0; (i < totItems) && totArr; i++, offsetP++)
			{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
				if (itemP->flags & kIsArray)
				{	arrayDLRef = *(DLMRef*)VALUE(itemP);
					GET_LIST_BLOCK(arrayDLRef, arListP);
					if (_IsDirty(arListP))
						return true;
					totArr--;
				}
			}
		}
	}

return false;
}

//===========================================================================================
static Boolean _IndexsAreToSwap(DLMRecP listP, long *offsetP, long index1, long index2, CompareFunc cFunc)
{
DLMItemP	item1P, item2P;
short		res;

	item1P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[index1]);
	item2P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[index2]);
	res = cFunc(item1P->name, item2P->name);
	return (res == -1);
}

//===========================================================================================
static XErr	_SortLong(long *longP, long totItems, Boolean (*_swap)(long, long, long, XErr*), long userData, long alg)
{
XErr		err = noErr;
long		tempLong;
Boolean		res;
int			j, i;
int			jump, totLoops; 
Boolean		alldone;

	if ((alg != kBubble) && (alg != kShell))
	{	if (totItems < 20)
			alg = kBubble;
		else
			alg = kShell;
	}
	
	if (alg == kBubble)
	{	// Bubble
		j = totItems;
		if (--j <= 0)
			goto out;
		do
		{	for (i = 0; i < j; i++)
			{	res = _swap(i, i+1, userData, &err);
				if (err)
					goto out;
				if (res)
				{	tempLong = longP[i+1];
					longP[i+1] = longP[i];
					longP[i] = tempLong;
				}
			}
		} while(--j);
	}
	else
	{	// shell
		jump = totItems;
		while (jump > 1)
		{ 	jump /= 2;
			do { 
				alldone = true; 
				totLoops = totItems - jump;
				for (j = 0; j < totLoops; j++)
				{ 
					i = j + jump; 
					res = _swap(j, i, userData, &err);
					if (err)
						goto out;
					if (res)
					{	tempLong = longP[i];
						longP[i] = longP[j];
						longP[j] = tempLong;
						alldone = false; 
					}
				}
			} while (!alldone); 
		}
	}
	
out:
return err;
}

typedef struct
	{
	DLMRecP			listP;
	long			*offsetP;
	long			*indexsP;
	CompareFunc 	cFunc;
	} ReorderSwapRec;

//===========================================================================================
static Boolean _ReorderSwap(long i, long j, long userData, XErr *errP)
{
Boolean			res;
ReorderSwapRec	*reorderSwapRecP = (ReorderSwapRec*)userData;

	res = _IndexsAreToSwap(reorderSwapRecP->listP, reorderSwapRecP->offsetP, reorderSwapRecP->indexsP[i], reorderSwapRecP->indexsP[j], reorderSwapRecP->cFunc);
	*errP = noErr;
	
return res;
}

//===========================================================================================
static void _ReorderIndexs(DLMRecP listP, long *offsetP, long *indexsP, Boolean caseSense)
{
//register int 	i, j;
//long			tempIndex;
//CompareFunc 	cFunc;
ReorderSwapRec	reorderSwapRec;

	reorderSwapRec.listP = listP;
	reorderSwapRec.offsetP = offsetP;
	reorderSwapRec.indexsP = indexsP;
	if (caseSense)
		reorderSwapRec.cFunc = CCompareStrings_cs;
	else
		reorderSwapRec.cFunc = CCompareStrings;
	_SortLong(indexsP, listP->totItems, _ReorderSwap, (long)&reorderSwapRec, 0);

/*
		
	j = listP->totItems;
	if (--j <= 0)
	{	
		return;
	}
	do
	{	for (i=0; i<j; i++)
		{	if (_IndexsAreToSwap(listP, offsetP, indexsP[i], indexsP[i+1], cFunc))
			{	tempIndex = indexsP[i+1];
				indexsP[i+1] = indexsP[i];
				indexsP[i] = tempIndex;
			}
		}
	} while(--j);
*/
}

// ===========================================================================
/*static void	_buggedCompactList(long *listPtr, long totElemCnt, long firstToRemove, long lastToRemove)
{
long	val, *runElemP, range = lastToRemove - firstToRemove + 1;

do	{					// skip to first elem to remove
	val = *listPtr;
	if (val >= firstToRemove)
		{
		if (val <= lastToRemove)
			break;
		else
			*listPtr = val - range;
		}
	listPtr++;
	} while(--totElemCnt);

if (--totElemCnt > 0)
	{
	runElemP = listPtr;
	do	{
		val = *listPtr++;
		if (val <= firstToRemove)
			*runElemP++ = val;
		else if (val > lastToRemove)
			*runElemP++ = val - range;
		} while(--totElemCnt);
	}
}*/

// ===========================================================================
static void	_CompactList(long *listPtr, long totElemCnt, long firstToRemove, long lastToRemove)
{
long	val, *runElemP, range = lastToRemove - firstToRemove + 1;

	if (totElemCnt > 1)
	{	do	{					// skip to first elem to remove
			val = *listPtr;
			if (val > lastToRemove)
				*listPtr = val - range;
			else if (val >= firstToRemove)
				break;
			listPtr++;
		} while(--totElemCnt);
		if (totElemCnt)
		{	runElemP = listPtr;
			do	{					// skip to first elem to remove
				val = *listPtr++;
				if (val >= firstToRemove)
					{
					if (val > lastToRemove)
						*runElemP++ = val - range;
					}
				else
					*runElemP++ = val;
			} while(--totElemCnt);
		}
	}
}

//===========================================================================================
static XErr	_RemoveItems(DLMRef listRef, long firstToRemove, long lastToRemove, DLMLoopCallBack callBack, long param, Boolean destruct)
{	
long			totItems;
DLMRecP			listP;
int				arrayToDelete, i;
XErr			err = noErr, tErr = noErr;
long			totToRemove, diffSize, *offsetP, *indexsP;
DLMItem			*itemP, *firstItemP, *firstGoodItemP;
DLMRef			arrayDLRef;
BlockRef		listBlock;
long			total, *offP, tLen, *startOffsetP, *firstOffsetP, *lastOffsetP;

	listBlock = GET_LIST_BLOCK(listRef, listP);
	if (listP->locked)
		return _DebugErrListLocked("_RemoveItems", XError(kXHelperError, DLM_Err_ListIsLocked));
	if ((firstToRemove <= 0) || (firstToRemove > listP->totItems))
		return XError(kXHelperError, DLM_Err_OutOfBoundary);
	else if ((lastToRemove <= 0) || (lastToRemove > listP->totItems) || (lastToRemove < firstToRemove))
		return XError(kXHelperError, DLM_Err_OutOfBoundary);
		
	LockBlock(listBlock);
	LockBlock(listP->offsetsBL);
	totItems = listP->totItems;
	diffSize = 0;
	arrayToDelete = 0;
	startOffsetP = ((long*)GetPtr(listP->offsetsBL));
	offsetP = startOffsetP + (firstToRemove-1);
	totToRemove = lastToRemove - firstToRemove + 1;
	for (i = 0; i < totToRemove; i++, offsetP++)
	{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
		if (itemP->flags & kIsArray)
		{	if (destruct)
			{	arrayDLRef = *(DLMRef*)VALUE(itemP);
				if (itemP->flags & kNoDestructor)
					err = DLM_Dispose(&arrayDLRef, nil, 0);
				else
					err = DLM_Dispose(&arrayDLRef, callBack, param);
			}
			if (err)
				break;
			else
				arrayToDelete++;
		}
		else if (destruct && callBack && NOT(itemP->flags & kNoDestructor))
		{	tErr = callBack(listRef, firstToRemove + i, itemP->flags, itemP->userData, param);
			if (tErr && NOT(err))
				err = tErr;
		}
		diffSize += sizeof(DLMItem) - ITEM_MIN_SIZE + itemP->valuePhysicLen + itemP->namePaddedLen;
	}

	if not(err)
	{
		// block
		if (lastToRemove < totItems)
		{	firstItemP = (DLMItem*)((Ptr)listP + *(startOffsetP + (firstToRemove-1)));
			firstOffsetP = startOffsetP + (firstToRemove-1);
			
			firstGoodItemP = (DLMItem*)((Ptr)listP + *(startOffsetP + lastToRemove));
			lastOffsetP = startOffsetP + lastToRemove;
			tLen = listP->totPhysLen - *lastOffsetP;
			if (tLen)
				CopyBlock(firstItemP, firstGoodItemP, tLen);

			// offsets
			tLen = (listP->totItems - lastToRemove) * sizeof(long);
			if (tLen)
				CopyBlock(firstOffsetP, lastOffsetP, tLen);
			offP = firstOffsetP;
			total = totItems - lastToRemove;
			for (i = 0; i < total; i++, offP++)
			{	
				*offP -= diffSize;
			}
		}

		// indexs
		if (listP->indexs)
		{	indexsP = ((long*)GetPtr(listP->indexsBL));
			_CompactList(indexsP, listP->totItems, firstToRemove-1, lastToRemove-1);
			BufferSetLength(listP->indexs, sizeof(long) * (listP->totItems - totToRemove));
		}

		listP->totItems -= totToRemove;
		listP->totArrays -= arrayToDelete;
		listP->totPhysLen -= diffSize;
		listP->dirty = true;
		// Set lengths (must be here)
		BufferSetLength(listP->offsets, sizeof(long) * listP->totItems);
		BufferSetLength(listRef, listP->totPhysLen);
	}
	
	GET_LIST_BLOCK(listRef, listP);
	UnlockBlock(listP->offsetsBL);
	UnlockBlock(listBlock);

	#ifdef MEM_DEBUG
		DLM_CheckList(listRef);
	#endif
		
return err;
}

//===========================================================================================
// Updates the dimension of the array (arMaxDim) depending on totItems of the DLM array list
static void	_SyncArray(DLMItemP itemP)
{	
DLMRef			arDLRef;
DLMRecP			listP;
ArrayRecP		arrRecP;

	arrRecP = (ArrayRecP)VALUE(itemP);
	arDLRef = arrRecP->arDLRef;
	GET_LIST_BLOCK(arDLRef, listP);
	arrRecP->arMaxDim = listP->totItems;
}

//===========================================================================================
/*
Expand the array until newDim.
Add (newDim - oldDim) intermediate array objects
*/
static XErr	_UpgradeArray(DLMItemP itemP, long newDim, long arrayUserData)
{	
DLMRef			arDLRef;
long			oldDim;
int				i;
XErr			err = noErr;
unsigned short	flags;
ArrayRecP		arrRecP;

	arrRecP = (ArrayRecP)VALUE(itemP);
	oldDim = arrRecP->arMaxDim;
	if (oldDim < newDim)
	{	if (itemP->flags & kCostant)
			flags = kCostant;
		else
			flags = 0;
		arDLRef = arrRecP->arDLRef;
		for (i = oldDim; (i < newDim) && NOT(err); i++)
			DLM_NewArray(arDLRef, "", arrayUserData, flags, /*0, */0, nil, &err);
		if NOT(err)
			arrRecP->arMaxDim = newDim;
	}

return err;
}

//===========================================================================================
/*
Expand the array until newDim.
if (elemToAddList && elemToAddID) || dlmbufferP
	Add also an object in last position
*/
static XErr	_ExpandArray(DLMItemP itemP, long newDim, DLMRef elemToAddList, long elemToAddID, DLMBuffer *dlmbufferP)
{	
DLMRef			arDLRef;
long			oldDim;
DLMRecP			listP, newElementListP;
int				i;
XErr			err = noErr;
long			totLoops, len;
unsigned short	flags = 0;
ArrayRecP		arrRecP;
long			arrayElemClass, /*userData, */*offsetP;
DLMItemP		tItemP;

	arrRecP = (ArrayRecP)VALUE(itemP);
	oldDim = arrRecP->arMaxDim;
	if (oldDim < newDim)
	{	arDLRef = arrRecP->arDLRef;
		len = 0;
		GET_LIST_BLOCK(arDLRef, listP);
		arrayElemClass = listP->arrayUserData;
		if (elemToAddList)
		{	GET_LIST_BLOCK(elemToAddList, newElementListP);
			offsetP = (long*)GetPtr(newElementListP->offsetsBL);
			tItemP = (DLMItemP)((Ptr)newElementListP + ((long*)offsetP)[elemToAddID-1]);
			flags = tItemP->flags;
			if (flags & kFixedSize)
				len = tItemP->valueLogicLen;
			if NOT(arrayElemClass)
				arrayElemClass = tItemP->userData;
		}
		else if (dlmbufferP)
		{	flags = dlmbufferP->flags;
			if (flags & kFixedSize)
				len = dlmbufferP->bufferLen;
			if NOT(arrayElemClass)
				arrayElemClass = dlmbufferP->userData;
		}
		else if (listP->totItems)
		{	offsetP = (long*)GetPtr(listP->offsetsBL);
			tItemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[0]);		// get the first item
			flags = tItemP->flags;
			if (flags & kFixedSize)
				len = tItemP->valueLogicLen;
			if NOT(arrayElemClass)
				arrayElemClass = tItemP->userData;
		}
		if (itemP->flags & kCostant)
			flags |= kCostant;
		else
			flags &= (0xFFFF ^ kCostant);
		totLoops = newDim - 1;
		// Add intermediate objects
		for (i = oldDim; (i < totLoops) && NOT(err); i++)
			DLM_NewObj(arDLRef, "", nil, 0/*len*/, arrayElemClass, flags, &err);
		// Add last
		if (elemToAddList)
			err = DLM_CopyObj(elemToAddList, elemToAddID, arDLRef, "", flags, nil);
		else if (dlmbufferP)
			DLM_NewObj(arDLRef, "", dlmbufferP->bufferP, dlmbufferP->bufferLen, dlmbufferP->userData, flags, &err);
		else
			DLM_NewObj(arDLRef, "", nil, 0/*len*/, arrayElemClass, flags, &err);
		if NOT(err)
			arrRecP->arMaxDim = newDim;
	}

return err;
}

//===========================================================================================
static XErr	_Save(DLMRef dlRef, BlockRef listBlock, DLMRecP	listP)
{
#ifndef __MAC_XLIB__
	#if __C_HAS_PRAGMA_UNUSED__
		#pragma unused(listBlock)
	#endif
#endif
//BlockRef	block = nil;
XErr		err = noErr;
XFileRef	fileRef;
Byte		byteOrder;
long		aLong, count;

	if (dlRef)
	{	if (_IsDirty(listP))
		{	fileRef = listP->fileRef;
			LockXFile(fileRef, 0, -1, true);
			if NOT(err = SetXFPos(fileRef, FROM_START, 0))
			{
			#ifdef __LITTLE_ENDIAN__
				byteOrder = DLM_LITTLE_ENDIAN;
			#else
				byteOrder = DLM_BIG_ENDIAN;
			#endif
				count = 1;
				if NOT(err = WriteXFile(fileRef, (Ptr)&byteOrder, &count))
				{	count = 3;
					aLong = 0;	// 3 bytes for future use
					if NOT(err = WriteXFile(fileRef, (Ptr)&aLong, &count))
					{	aLong = DLM_VERSION;
						count = sizeof(long);
						if NOT(err = WriteXFile(fileRef, (Ptr)&aLong, &count))
						{	LockBlock(listBlock);
							err = _SaveRecurse(listP, fileRef);
							UnlockBlock(listBlock);
						}
					}
				}
			}
			UnlockXFile(fileRef, 0, -1);
		}
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// indexs are 0-based
static XErr	_CreateIndexs(DLMRecP listP, long totItems)
{
long	i, indexs, *indPtr;
XErr	err = noErr;
	
	if (indexs = BufferCreate(_512B, &err))
	{	if NOT(err = BufferCheck(indexs, totItems * sizeof(long), nil))
		{	listP->indexs = indexs;
			listP->indexsBL = BufferGetBlockRefExt(indexs, (Ptr*)&indPtr);
			for (i = 0; i < totItems; i++, indPtr++)
				*indPtr = i;
		}
		else
			BufferFree(indexs);
	}

return err;
}

//===========================================================================================
// indexs are 0-based
static XErr	_AddOneOffsetIndex(DLMRecP listP, long newOffset, long pos, long dir, long atPos, long addedLen, Boolean nameExists)
{
XErr	err = noErr;
long	toShift, totItems, *offsetP;
long	*indexPtr, *indPtr;

	if (nameExists && NOT(listP->indexs))
		err = _CreateIndexs(listP, listP->totItems);
	if NOT(err)
	{	totItems = listP->totItems + 1;
		if NOT(err = BufferCheck(listP->offsets, sizeof(long) * totItems, nil))
		{	offsetP = (long*)GetPtr(listP->offsetsBL);
			if (atPos)
			{	long	n, i, *tOffP, *tLastOffP;
			
				tOffP = offsetP + totItems - 1;
				tLastOffP = offsetP + totItems - 2;
				n = totItems - atPos;
				for (i = 0; i < n; i++, tOffP--, tLastOffP--)
				{	
					*tOffP = *tLastOffP + addedLen;
				}
				// *tOffP = listP->totPhysLen + addedLen;	// last
			}
			else
				offsetP[listP->totItems] = newOffset;							// last offset
			if (listP->indexsBL)									// indexs
			{	if NOT(err = BufferCheck(listP->indexs, sizeof(long) * totItems, nil))
				{	indexPtr = (long*)GetPtr(listP->indexsBL);
					if (listP->totItems)
					{	if (dir > 0)	// put before pos
						{	indPtr = &indexPtr[pos];
							toShift = (listP->totItems - pos);
						}
						else			// put after pos
						{	indPtr = &indexPtr[pos+1];
							toShift = (listP->totItems - (pos+1));
						}
						// Shift all subsequent objects
						if (toShift)
							ShiftDownLongArray(indPtr, toShift);
					}
					else
						indPtr = indexPtr;
					if (atPos)
					{	long	lim, i, *tIndP;
					
						tIndP = indexPtr;
						lim = atPos - 1;
						for (i = 0; i < totItems; i++, tIndP++)
						{	if (*tIndP >= lim)
								(*tIndP)++;
						}
						*indPtr = lim;
					}
					else
						*indPtr = listP->totItems;								// obj ID
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static long	_PadLong(long aLong)
{
long	a;

	if (a = (aLong & 3))
		aLong += (sizeof(long) - a);

return aLong;
}

static XErr	_Dispose(DLMRef dlRef, BlockRef listBlock, DLMRecP listP, long from, DLMLoopCallBack callBack, long param, Boolean ignoreGlobal);
//===========================================================================================
static XErr	_NoDisposeOnGlobals(void)
{	
XErr	err;

	if (gsOkGlobalDispose)
		err = noErr;
	else
		err = XError(kXHelperError, DLM_Err_CantDisposeRef);
	
return	err;
}

//===========================================================================================
static XErr	_DisposeList(DLMRef *dlRefP, DLMLoopCallBack callBack, long param, Boolean ignoreGlobal)
{
	long		dlRef = *dlRefP, indexs, offsets;
	BlockRef	listBlock;
	DLMRecP		listP;
	Boolean		global;
	XErr		err = noErr;
	DLMRef		superList;
	
	if (dlRef)
	{
		if (global = BufferGetUserBit(dlRef))
		{
			if (ignoreGlobal || gsOkGlobalDispose)
				_EnterCS();
			else
			{
				err = XError(kXHelperError, DLM_Err_CantDisposeRef);
				goto out;
			}
		}
		
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_Dispose", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	if (listP->superList)
			superList = listP->superList;
		else
			superList = 0L;
			if NOT(listBlock)
			{	*dlRefP = 0;
				CDebugStr("Non doveva mai succedere");
				err = -1;
			}
			else
			{	LockBlock(listBlock);
				offsets = listP->offsets;
				indexs = listP->indexs;
				err = _Dispose(*dlRefP, listBlock, listP, 0, callBack, param, ignoreGlobal);
				if (offsets)
					BufferFree(offsets);
				if (indexs)
					BufferFree(indexs);
				BufferFree(dlRef);
				*dlRefP = 0;	
				if (superList)
				{
					XErr	err2;
					
					err2 = DLM_Dispose(&superList, callBack, param);	// this destruct the supers
					if (err2 && NOT(err))
						err = err2;
				}
			}
		}
		if (global)
			_LeaveCS();
	}
	else
		CDebugStr("DLM is null");
	
out:
	return err;
}

//===========================================================================================
// Must update also totArrays
static XErr	_Dispose(DLMRef dlRef, BlockRef listBlock, DLMRecP listP, long from, DLMLoopCallBack callBack, long param, Boolean ignoreGlobal)
{
#ifndef __MAC_XLIB__
	#if __C_HAS_PRAGMA_UNUSED__
		#pragma unused(listBlock)
	#endif
#endif
register int	i, totItems;
long			totArr, *offsetP;
DLMItemP 		itemP;
DLMRef			arrayDLRef;
XErr			err = noErr, tErr = noErr;
BlockRef		offsetBlock;

	LockBlock(listBlock);
	offsetBlock = listP->offsetsBL;	
	LockBlock(offsetBlock);
	offsetP = (long*)(((long*)GetPtr(offsetBlock)) + from);
	totItems = listP->totItems;
	if (callBack)
	{	for (i = from; (i < totItems); i++, offsetP++)
		{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
			if (itemP->flags & kIsArray)
			{	arrayDLRef = *(DLMRef*)VALUE(itemP);
				if NOT(itemP->flags & kNoDestructor)
				{	tErr = _DisposeList(&arrayDLRef, callBack, param, ignoreGlobal);
					if (tErr && NOT(err))
						err = tErr;
				}
				listP->totArrays--;
			}
			else if NOT(itemP->flags & kNoDestructor)
			{	tErr = callBack(dlRef, i+1, itemP->flags, itemP->userData, param);
				if (tErr && NOT(err))
					err = tErr;
			}
		}
	}
	else
	{	totArr = listP->totArrays;
		for (i = from; (i < totItems) && totArr; i++, offsetP++)
		{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
			if (itemP->flags & kIsArray)
			{	arrayDLRef = *(DLMRef*)VALUE(itemP);
				tErr = _DisposeList(&arrayDLRef, callBack, param, ignoreGlobal);
				if (tErr && NOT(err))
					err = tErr;
				totArr--;
			}
		}
		listP->totArrays = totArr;
	}
	UnlockBlock(offsetBlock);
	UnlockBlock(listBlock);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// Moves memory (lock bufferP if comes from Handles)
static XErr	_NewObject(long dlRefID, char *bufferName, char *bufferP, long bufferLen, 
															long userData, unsigned short flags, 
															long *objIDP, long pos, long dir,
															DLMRef s_listRef, long s_objIDToClone, long atPos)
{
DLMRecP			s_listP, listP;
DLMItemP		itemP;
long			newOffset, addedLen, physicLen;
XErr			err = noErr;
Boolean			moved;
BlockRef		listBlock;
BlockRef 		s_listBlock;
long			nameLen, namePaddedLen;

	// Check
	listBlock = GET_LIST_BLOCK(dlRefID, listP);
	if (atPos)
	{	if (atPos < 0)
			return XError(kXHelperError, DLM_Err_InvalidPos);
		else if (atPos > listP->totItems)
			atPos = 0;		// just append
	}

	if (listP->arrayUserData != DLM_USERDATA_DEFAULT)
	{	if NOT(listP->arrayUserData)
		{	if (userData)
				listP->arrayUserData = userData;
		}
		else if (listP->arrayUserData != userData)
		{	if (userData)
				return XError(kXHelperError, DLM_Err_ArrayElemWrongType);
			//else
			//	itemP->userData = listP->arrayUserData;
		}
	}

	// Calculate physicLen of one item
	if ((flags & kFixedSize) || (bufferLen > ITEM_MIN_SIZE))
		physicLen = _PadLong(bufferLen);
	else
		physicLen = ITEM_MIN_SIZE;
	if (bufferName)
	{	nameLen = CLen(bufferName);
		if (nameLen && (listP->listType == ID_LIST))
			return XError(kXHelperError, DLM_Err_ListDontAcceptNames);
		if (nameLen > NAME_MAX_LENGTH)
			return XError(kXHelperError, DLM_Err_NameTooLong);
	}
	else
		nameLen = 0;
	if (nameLen)
		namePaddedLen = _PadLong(nameLen);
	else
		namePaddedLen = 0;
	listP->dirty = true;
	addedLen = sizeof(DLMItem) - ITEM_MIN_SIZE + namePaddedLen + physicLen;					// header + value
	if NOT(err = BufferCheck(dlRefID, listP->totPhysLen + addedLen, &moved))
	{	listP = ((DLMRecP)GetPtr(listBlock));
		
		if (atPos)
		{	long 	off, length, *offsetP = (long*)GetPtr(listP->offsetsBL);
			Ptr		sourceP, destP;

			off = offsetP[atPos-1];
			sourceP = ((Ptr)listP + off);
			destP = sourceP + addedLen;
			length = listP->totPhysLen - off;
			CopyBlock(destP, sourceP, length);
			itemP = (DLMItemP)sourceP;
			// ClearBlock(itemP, addedLen);	// temp
			newOffset = off;
		}
		else
		{	itemP = (DLMItemP)((Ptr)listP + listP->totPhysLen);		// totPhysLen is not yet updated!
			newOffset = listP->totPhysLen;
		}
		// fill item's header
		if (bufferName)
		{	CopyBlock(itemP->name, bufferName, nameLen);
			*(itemP->name + nameLen) = 0;
			FillBlock(itemP->name + nameLen + 1, namePaddedLen - nameLen, 'x');
		}
		else
			itemP->name[0] = 0;
		itemP->namePaddedLen = (Byte)namePaddedLen;
		itemP->userData = userData;
		if (flags & kNoDestructor)
			flags &= (0xFFFFFFFF ^ kNoDestructor);	// spengo il bit kNoDestructor
		itemP->flags = flags;
		itemP->valueLogicLen = bufferLen;
		itemP->superID = 0;
		if (flags & kIsArray)
			listP->totArrays++;

		if (s_listRef)
			s_listBlock = GET_LIST_BLOCK(s_listRef, s_listP);
		else
			s_listBlock = 0;
		if (NOT(bufferP) && s_objIDToClone && s_listBlock)
		{	long 		*s_offsetP;
			DLMItemP	s_itemP;
			
			s_offsetP = (long*)GetPtr(s_listP->offsetsBL);
			s_itemP = (DLMItemP)((Ptr)s_listP + ((long*)s_offsetP)[s_objIDToClone-1]);
			bufferP = VALUE(s_itemP);
		}
		if (bufferP)
		{	CopyBlock(VALUE(itemP), bufferP, bufferLen);
			if ((flags & kIsArray) && BufferGetUserBit(dlRefID))
			{
			ArrayRecP	arrRecP = (ArrayRecP)VALUE(itemP);
			
				BufferOnUserBit(arrRecP->arDLRef);
				// ex bugged *VALUE(itemP) = BufferOnUserBit(*VALUE(itemP));
			}
		}
		itemP->valuePhysicLen = physicLen;
		if NOT(err)
		{	LockBlock(listBlock);
			err = _AddOneOffsetIndex(listP, newOffset, pos, dir, atPos, addedLen, (Boolean)(nameLen != 0));
			UnlockBlock(listBlock);
			if NOT(err)
			{	listP->totPhysLen += addedLen;
				if (objIDP)
				{	if (atPos)
						*objIDP = atPos;
					else
						*objIDP = listP->totItems;
				}
				listP->totItems++;
				/*if (listP->arrayUserData != DLM_USERDATA_DEFAULT)
				{	if NOT(listP->arrayUserData)
					{	if (userData)
							listP->arrayUserData = userData;
					}
					else if (listP->arrayUserData != userData)
					{	if (userData)
							err = XError(kXHelperError, DLM_Err_ArrayElemWrongType);
						//else
						//	itemP->userData = listP->arrayUserData;
					}
				}*/
			}
		}
	}	

	// for debug
	//if (atPos)
	//	DLM_CheckList(dlRefID);

	#ifdef MEM_DEBUG
		DLM_CheckList(dlRefID);
	#endif

return err;
}

//===========================================================================================
// Moves memory (lock bufferP if comes from Handles)
static XErr	_NewArray(long dlRefID, char *arrayName, long userData, unsigned short flags, long pos, long dir, /*long maxDim, */Boolean global, long arrayUserData, long *objIDP, DLMRef *arrayDLRefP)
{
XErr			err = noErr;
DLMRef			newDLMListRef;
ArrayRec		arRec;
BlockRef		newDLMListBlock;
DLMRecP			newDLMListP;
unsigned short	arFlags;

	//if (maxDim < 0)	// ex (maxDim <= 0)
	//	return XError(kXHelperError, DLM_Err_BadArrayDimension);
	if NOT(err = DLM_Create(&newDLMListRef, NAMECS_LIST, global))
	{	newDLMListBlock = GET_LIST_BLOCK(newDLMListRef, newDLMListP);
		newDLMListP->arrayUserData = arrayUserData;
		arFlags = flags;
		arFlags |= kIsArray + kFixedSize;					// always 8-bytes in length
		arRec.arDLRef = newDLMListRef;
		arRec.arMaxDim = 0;	//maxDim;
		if NOT(err = _NewObject(dlRefID, arrayName, (Ptr)&arRec, sizeof(ArrayRec), userData, arFlags, objIDP, pos, dir, 0, 0, 0))
		{	(*objIDP)++;
			if (arrayDLRefP)
				*arrayDLRefP = newDLMListRef;
		}
		if (err)
			DLM_DisposeGlobal(&newDLMListRef, nil, 0);
	}

return err;
}

//===========================================================================================
static XErr	_CloneAllArrays(DLMRef listRef)
{
register int	i, totItems;
DLMRecP			listP;
long			totArr, *offsetP;
DLMItemP 		itemP;
DLMRef			arrayDLRef, newArrayDLRef;
XErr			err = noErr;
BlockRef		block, offsetBlock;

	block = GET_LIST_BLOCK(listRef, listP);
	LockBlock(block);
	offsetBlock = listP->offsetsBL;
	LockBlock(offsetBlock);
	offsetP = (long*)GetPtr(offsetBlock);
	totItems = listP->totItems;
	totArr = listP->totArrays;
	for (i = 0; (i < totItems) && totArr && NOT(err); i++, offsetP++)
	{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
		if (itemP->flags & kIsArray)
		{	arrayDLRef = *(DLMRef*)VALUE(itemP);
			if NOT(err = DLM_CloneList(arrayDLRef, &newArrayDLRef))
				CopyBlock(VALUE(itemP), &newArrayDLRef, sizeof(DLMRef));
			totArr--;
		}
	}
	UnlockBlock(offsetBlock);
	UnlockBlock(block);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

// =================================================================================
static void _PosIndexed(DLMRecP listP, DLMItemP itemP, CompareFunc cFunc, long tot, long *thePosP, long index, long *posP, long *resP, long *offsetP, long *indexP)
{
long		lastElem, totUp, totDown, thePos;
DLMItemP	item1P, item2P;

	totUp = 0;
	totDown = 0;
	// how many up
	if (index != -1)
	{	if ((thePos = *thePosP) > 1)
		{	item1P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos-2]]);
			item2P = itemP;
			while NOT(cFunc(item1P->name, item2P->name) && (thePos > 1))
			{	thePos--;
				item1P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos-1]]);
				item2P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos-2]]);
				totUp++;
			}
		}
	}
	// how many down
	if ((thePos = *thePosP) < tot)
	{	item1P = itemP;
		item2P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos]]);
		lastElem = tot - 1;
		while (NOT(cFunc(item1P->name, item2P->name)) && (++thePos < lastElem))
		{	// thePos++;
			item1P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos-1]]);
			item2P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos]]);
			/*if (thePos < lastElem)
				item2P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos]]);
			else
				break;*/
			totDown++;
		}
	}
	if (index != -1)
	{	if (totUp || totDown)
		{	thePos = *thePosP;
			if (index > (totUp + totDown + 1))
				index = (totUp + totDown + 1);
			thePos = thePos - totUp + (index - 1);
		}
	}
	if (posP)
		*posP = thePos - 1;
	if (resP)	
		*resP = -1;	// after pos

	*thePosP = thePos;
}
			
// =================================================================================
int	_BeginCompare(register char *str1, register char *str2)
{
	return NOT(CBegins(str1, str2, true));
}

// =================================================================================
// return -1 if item no found, otherwise the pos (0-based)
static long _FindItemPos(DLMRecP listP, char *name, long index, long *posP, long *resP, CompareFunc cFunc)
{
register long	min, max, thePos = 0, *offsetP, *indexP;
register int	res = -1;
long 			tot;
DLMItemP		itemP = nil;
long			listType = listP->listType;
Boolean			isCS;

	if ((isCS = listType == NAMECS_LIST) || (listType == NAME_LIST))
	{	if (NOT(name) || NOT(*name))
		{	// put before first
			if (posP)
				*posP = 0;
			if (resP)	
				*resP = +1;
			return -1;
		}
		else if NOT(listP->indexs)
		{	// put after totItems (at last pos)
			if (posP)
				*posP = listP->totItems - 1;
			if (resP)	
				*resP = -1;
			return -1;
		}	
		if NOT(cFunc)
		{	if (isCS)
				cFunc = CCompareStrings_cs;
			else
				cFunc = CCompareStrings;
		}
	}
	else
	{	if (posP)
			*posP = -1;
		if (resP)	
			*resP = +1;
		return -1;
	}
	
	if (tot = listP->totItems)
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		indexP = (long*)GetPtr(listP->indexsBL);
		max = tot;
		min = 1;
		while (max >= min)
		{	thePos = (max + min) >> 1;			
			itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexP[thePos-1]]);
			res = -cFunc(itemP->name, name);
			if (res < 0)			// itemP->name < name
				min = thePos + 1;
			else if (res > 0)		// itemP->name > name
				max = thePos - 1;
			else 					// res == 0
			{	max = thePos;
				break;
			}
		}
		if (res)
		{	if (posP)
				*posP = thePos - 1;
			if (resP)	
				*resP = res;
			return -1;
		}
		else	// found!
		{	if (index)
			{	long	aPos = thePos;	// to use register
				_PosIndexed(listP, itemP, cFunc, tot, &aPos, index, posP, resP, offsetP, indexP);
				thePos = aPos;
			}
			return (thePos-1);
		}
	}
	else
	{	if (posP)
			*posP = 0;
		if (resP)	
			*resP = +1;
		return -1;
	}
}

//===========================================================================================
static XErr	_SetSuperID(DLMRef dlRef, long objID, long superID)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))	// = listP->global)
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
		itemP->superID = superID;
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();

return err;
}

//===========================================================================================
static XErr	_CopyArrays(DLMRef destList, DLMItemP itemP, char *destName, unsigned short destObjectFinalFlags, long pos, long dir, long atPos, long *destId)
{
ArrayRec	arRec;
ArrayRecP	arrRecP;
DLMRef		arrayListRef, newListRef;
long		maxDim, userData = itemP->userData;
XErr		err = noErr;
	
	arrRecP = (ArrayRecP)VALUE(itemP);
	arrayListRef = arrRecP->arDLRef;
	maxDim = arrRecP->arMaxDim;
	if NOT(err = DLM_CloneList(arrayListRef, &newListRef))
	{	arRec.arDLRef = newListRef;
		arRec.arMaxDim = maxDim;
		err = _NewObject(destList, destName, (Ptr)&arRec, sizeof(ArrayRec), userData, destObjectFinalFlags, destId, pos, dir, 0, 0, atPos);
		/*if NOT(err)
		{	if (destId)
				(*destId)++;
		}*/
	}

return err;
}

static XErr	_CopyObject(DLMRef sourceList, long sourceObjID, DLMRef destList, char *destName, unsigned short destObjectFinalFlags, long *destId, Boolean cloneArrays, long atPos);

//===========================================================================================
/* Add:
	itself=true:		the object (sourceList, sourceObjID) to super of (destList, destID)
	itself=false:		the super of object (sourceList, sourceObjID) (if exists) to super of (destList, destID)
*/
static XErr	_AddSuperObj(DLMRef sourceList, long sourceObjID, DLMRef destList, long destID, unsigned short flags, Boolean cloneArrays, Boolean itself, DLMRef *newList, long *newSuperIDP)
{	
DLMRecP		listP, destListP;
DLMItemP	itemP;
BlockRef	sourceListBlock, destListBlock;
XErr		err = noErr;
long		superList = 0, *offsetP;
Boolean		toCopy, justCreated = false;
long		superDestID, superID = 0, superDestList;

	sourceListBlock = GET_LIST_BLOCK(sourceList, listP);
	offsetP = (long*)GetPtr(listP->offsetsBL);
	itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[sourceObjID-1]);	// reload
	if (itself)
		toCopy = true;
	else
	{	if (toCopy = (itemP->superID != 0))
		{	superID = itemP->superID;
			superList = listP->superList;
		}
	}
	if (toCopy)
	{	
		destListBlock = GET_LIST_BLOCK(destList, destListP);
		if (destListP->superList)
			superDestList = destListP->superList;
		else
		{	if NOT(err = DLM_Create(&superDestList, ID_LIST, BufferGetUserBit(destList)))
			{	GET_LIST_BLOCK(destList, destListP);
				destListP->superList = superDestList;
				justCreated = true;
			}
		}
		if (itself)
			err = _CopyObject(sourceList, sourceObjID, superDestList, nil, _FilterFlags(sourceList, sourceObjID, flags), &superDestID, cloneArrays, 0);
		else
			err = _CopyObject(superList, superID, superDestList, nil, _FilterFlags(superList, superID, flags), &superDestID, cloneArrays, 0);
		if NOT(err)
			err = _SetSuperID(destList, destID, superDestID);
		if (err && justCreated)
		{	GET_LIST_BLOCK(destList, destListP);						// reload
			destListP->superList = 0L;
			DLM_DisposeGlobal(&superDestList, nil, 0);
		}
		else
		{	if (newSuperIDP)
				*newSuperIDP = superDestID;
			if (newList)
				*newList = superDestList;
		}
	}
	
return err;
}

//===========================================================================================
long	_GetObjID(DLMRef dlRef, char *name, long index, long *flagsP, long *userDataP, CompareFunc cFunc, long *lengthP)
{
DLMRecP		listP;
long		*offsetP, objID, itemIDX, pos = -1, res;
BlockRef	listBlock;
DLMItemP	itemP;
Boolean		global;

	objID = -1;
	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))	// = listP->global)
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (name && *name && ((itemIDX = _FindItemPos(listP, name, index, &pos, &res, cFunc)) >= 0))
		{	objID = ((long*)GetPtr(listP->indexsBL))[itemIDX];
			offsetP = (long*)GetPtr(listP->offsetsBL);
			itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID]);
			if (userDataP)
				*userDataP = itemP->userData;
			if (flagsP)
				*flagsP = itemP->flags;
			if (lengthP)
				*lengthP = itemP->valueLogicLen;
			if (cFunc == _BeginCompare)
				CEquStr(name, itemP->name);
		}
		if (global)
			_LeaveCS();
	}
	
return (objID + 1);
}

//===========================================================================================
/*static BlockRef	_AtomicGetListP(DLMRef dlRef, DLMRecP *listPPtr, Boolean *globalP)
{
BlockRef	block;
DLMRecP		listp;

	_EnterCS();
	block = GET_LIST_BLOCK(dlRef, listp);
	*listPPtr = listp;
	if NOT(*globalP = listp->global)
		_LeaveCS();
	
return block;
}*/

//===========================================================================================
static XErr	_GetObj(DLMRef dlRef, long objID, Ptr dataP, long *dataLenP, long offset, long *userDataP, char *name, long *objIDP, Boolean sorted, Boolean filterUserData)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		returnDataLen = 0, *offsetP, *indexsP, sourceLen, requestedDataLen;
Ptr			sourceP;
XErr		err = noErr;
long		maxStorage;
Boolean		global;

	if (dataLenP)
	{	requestedDataLen = *dataLenP;
		maxStorage = requestedDataLen;
	}
	else if (dataP)
		return XError(kXHelperError, DLM_Err_InvalidLength);
	else
		requestedDataLen = maxStorage = 0;
	
	if (global = BufferGetUserBit(dlRef))	// = listP->global)
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	//listBlock = _AtomicGetListP(dlRef, &listP, &global);
	
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		if ((listP->listType != NAME_LIST) && (listP->listType != NAMECS_LIST))
			sorted = false;
		if (filterUserData)
		{	long	index, elemID, elemCnt;
			
			if (sorted && listP->indexsBL)
				indexsP = (long*)GetPtr(listP->indexsBL);
			else
				indexsP = nil;
			if (indexsP)
			{	elemID = objID - 1;
				elemCnt = listP->totItems;
				do	{
					index = *indexsP;
					itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[index]);
					if (itemP->userData)
					{	if not(elemID--)
							break;
					}
					indexsP++;
				} while (--elemCnt);
				if (elemCnt)
				{	if (objIDP)
						*objIDP = *indexsP + 1;
				}
				else
					err = XError(kXHelperError, DLM_Err_ObjectNotFound);
			}
			else
			{	elemID = objID - 1;
				elemCnt = listP->totItems;
				index = 0;
				do	{
					itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[index]);
					if (itemP->userData)
					{	if not(elemID--)
							break;
					}
					index++;
				} while (--elemCnt);
				if (elemCnt)
				{	if (objIDP)
						*objIDP = index + 1;
				}
				else
					err = XError(kXHelperError, DLM_Err_ObjectNotFound);
			}
		}
		else
		{	if (sorted && listP->indexsBL)
			{	indexsP = (long*)GetPtr(listP->indexsBL);
				itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[indexsP[--objID]]);
				if (objIDP)
					*objIDP = indexsP[objID] + 1;
			}
			else
			{	itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
				if (objIDP)
					*objIDP = objID + 1;
			}
		}
		if NOT(err)
		{	sourceP = VALUE(itemP);
			sourceLen = itemP->valueLogicLen;		
			if (name)
			{	if ((listP->listType == NAME_LIST) || (listP->listType == NAMECS_LIST))
					CEquStr(name, itemP->name);
				else
					*name = 0;
			}
			if (dataLenP)
				*dataLenP = sourceLen;	// total length of object
			if (userDataP)
				*userDataP = itemP->userData;
			if (dataP)
			{	if (requestedDataLen)
				{	if (requestedDataLen > sourceLen)
					{	*dataLenP = sourceLen;
						CopyBlock(dataP, sourceP, sourceLen);
						err = XError(kXHelperError, DLM_Err_NoMoreDataInObject);
					}
					else
						returnDataLen = requestedDataLen;
				}
				else
				{	returnDataLen = sourceLen;
					*dataLenP = sourceLen;
				}
				
				if NOT(err)
				{	if (returnDataLen > maxStorage)
					{	returnDataLen = maxStorage;
						err = XError(kXHelperError, DLM_Err_BufferToSmall);
					}
					if (offset--)
					{	if (offset < sourceLen)
							sourceP += offset;
						else
							err = XError(kXHelperError, DLM_Err_OutOfBoundary);
					}
					CopyBlock(dataP, sourceP, returnDataLen);
				}
			}
		}
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);

	if (global)
		_LeaveCS();

return err;
}

//===========================================================================================
static XErr	_SetBufferUserBitForChildren(DLMRef dlRef, long objID, unsigned short flags, long userData, long param)
{
	XErr			err = noErr;
	unsigned short	cFlags;
	DLMRef			curDLRef;
	long			cUserData, dataLen;
	
	if not(err = DLM_GetInfo(dlRef, objID, &cFlags, nil, nil))
	{
		if (cFlags & kIsArray)
		{
			if not(err = DLM_GetArrayInfo(dlRef, objID, nil, &curDLRef, nil, nil))
			{
				BufferOnUserBit(curDLRef);
				if not(err = DLM_UpdateArrayDLRef(dlRef, objID, curDLRef))
					err = _DMLLoop(curDLRef, _SetBufferUserBitForChildren, 0L, false, false, nil);
			}
		}
		else if (cFlags & kIsDlm)
		{
			dataLen = sizeof(DLMRef);
			if not(err = _GetObj(dlRef, objID, (Ptr)&curDLRef, &dataLen, 0, &cUserData, nil, nil, false, false))
			{
				BufferOnUserBit(curDLRef);
				if not(DLM_ModifyObj(dlRef, objID, (Ptr)&curDLRef, sizeof(curDLRef), cUserData, nil, 0, nil))
					err = _DMLLoop(curDLRef, _SetBufferUserBitForChildren, 0L, false, false, nil);
			}
		}
	}
	
	return err;
}

//===========================================================================================
static XErr	_CopyObject(DLMRef sourceList, long sourceObjID, DLMRef destList, char *destName, unsigned short destObjectFinalFlags, long *destId, Boolean cloneArrays, long atPos)
{
	DLMRecP		listP, destListP;
	BlockRef	sourceListBlock, destListBlock;
	DLMItemP	itemP;
	XErr		err = noErr;
	long		theDestId, pos, dir, *offsetP;
	Boolean		found, sglobal, dglobal, global;
	
	if (sourceList && destList)
	{	
		// e se destCoordsP != 0?
		if ((sglobal = BufferGetUserBit(sourceList)) || (dglobal = BufferGetUserBit(destList)))
		{	global = true;
			_EnterCS();
		}
		else
			global = false;
		sourceListBlock = GET_LIST_BLOCK(sourceList, listP);
		destListBlock = GET_LIST_BLOCK(destList, destListP);
		if (destListP->locked)
			return _DebugErrListLocked("_CopyObject", XError(kXHelperError, DLM_Err_ListIsLocked));
		if (sourceObjID && (sourceObjID <= listP->totItems))
		{	long	superID;
			
			offsetP = (long*)GetPtr(listP->offsetsBL);
			itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[sourceObjID-1]);
			superID = itemP->superID;
			if (destObjectFinalFlags == (unsigned short)-1)
				destObjectFinalFlags = itemP->flags;
			if (listP->acceptDuplicates)
				found = (_FindItemPos(destListP, destName, -1, &pos, &dir, nil)) >= 0;
			else
			{
				found = (_FindItemPos(destListP, destName, 0, &pos, &dir, nil)) >= 0;
				if (found)
					err = XError(kXHelperError, DLM_Err_DuplicatedObject);
			}
			if NOT(err)
			{	
				if (cloneArrays && (destObjectFinalFlags & kIsArray))
					err = _CopyArrays(destList, itemP, destName, destObjectFinalFlags, pos, dir, atPos, &theDestId);
				else
					err = _NewObject(destList, destName, nil, itemP->valueLogicLen, itemP->userData, destObjectFinalFlags, &theDestId, pos, dir, sourceList, sourceObjID, atPos);
				if NOT(err)
				{	
					theDestId++;
					if (superID)
						err = _AddSuperObj(sourceList, sourceObjID, destList, theDestId, destObjectFinalFlags, cloneArrays, false, nil, nil);
					if NOT(err)
					{	
						if (destId)
							*destId = theDestId;
					}
				}
			}
		}
		else
			err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		if (global)
		{
			if not(err)
				err = _SetBufferUserBitForChildren(destList, theDestId, 0, 0, 0);
			_LeaveCS();
		}
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
	
	return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	DLM_SetGlobalOk(Boolean okGlobal)
{
	gsOkGlobalDispose = okGlobal;
}

//===========================================================================================
XErr	DLM_Load(XFilePathPtr filePath, long listType, Boolean global, DLMRef *dlRefP)
{
XFileRef	fileRef = 0;
BlockRef	block = nil;
XErr		err = noErr, err2 = noErr;
Ptr			fileP;
long		eof;
DLMRecP		listP;
BlockRef	listBlock;
long		version, offsets = 0, indexs = 0;
DLMRef		dlRef = 0;
Byte		byteOrder;
Boolean		fileIsEmpty = false;

	if (global)
		_EnterCS();
	if NOT(err = OpenXFile(filePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof > DLM_MINIMAL_FILE_LENGTH)
			{	if (block = NewBlockLocked(eof, &err, &fileP))
				{	//LockBlock(block);
					//fileP = GetPtr(block);
					if NOT(err = ReadXFile(fileRef, fileP, &eof))
					{	byteOrder = *(Byte*)fileP++;
						eof--;
				#ifndef DEBUG_ALLOW_SWAP_BYTE_ORDER
					#ifdef __LITTLE_ENDIAN__
						if (byteOrder == DLM_BIG_ENDIAN)
							err = XError(kXHelperError, DLM_Err_InvalidFile);
					#else
						if (byteOrder == DLM_LITTLE_ENDIAN)
							err = XError(kXHelperError, DLM_Err_InvalidFile);
					#endif
				#endif
						if NOT(err)
						{	fileP += 3;
							eof -= 3;
						#ifdef DEBUG_ALLOW_SWAP_BYTE_ORDER
							version = SwapLong(*(long*)fileP, byteOrder);
						#else	
							version = *(long*)fileP;
						#endif
							fileP += sizeof(long);
							eof -= sizeof(long);
							// Here check version of file to see if it is satisfying
							if (version < DLM_VERSION)
								err = XError(kXHelperError, DLM_Err_InvalidFile);
							if NOT(err)	
							{	if NOT(err = _LoadRecurse(&fileP, &eof, byteOrder, &indexs, &offsets, global, &dlRef))
								{	listBlock = GET_LIST_BLOCK(dlRef, listP);
									listP->indexs = indexs;
									listP->offsets = offsets;
									listP->offsetsBL = BufferGetBlockRef(offsets, nil);
									if (indexs)
										listP->indexsBL = BufferGetBlockRef(indexs, nil);
									else
										listP->indexsBL = 0;
									listP->fileRef = fileRef;
									if (listP->superList)
									{	DLMRef	superList;
									
										if NOT(err = _LoadRecurse(&fileP, &eof, byteOrder, &indexs, &offsets, global, &superList))
										{	listP->superList = superList;
											listBlock = GET_LIST_BLOCK(superList, listP);
											listP->indexs = indexs;
											listP->offsets = offsets;
											listP->offsetsBL = BufferGetBlockRef(offsets, nil);
											if (indexs)
												listP->indexsBL = BufferGetBlockRef(indexs, nil);
											else
												listP->indexsBL = 0;
											listP->fileRef = 0;
										}
									}
									*dlRefP = dlRef;
								}
							}
						}
					}
					DisposeBlock(&block);
				}
			}
			else
				fileIsEmpty = true;
			if (fileIsEmpty || (err == XError(kXHelperError, DLM_Err_InvalidFile)))
			{	if NOT(err2 = DLM_Create(dlRefP, listType, global))
				{	listBlock = GET_LIST_BLOCK(*dlRefP, listP);
					listP->fileRef = fileRef;
					SetXEOF(fileRef, 0);
				}
				else if NOT(err)
					err = err2;
			}
		}
	}
	
	if (err)
	{	if (offsets)
			BufferFree(offsets);
		if (indexs)
			BufferFree(indexs);
		if (dlRef)
			BufferFree(dlRef);
		if (fileRef)
			err2 = CloseXFile(&fileRef);
	}
#ifdef MEM_DEBUG
	else
	{
		DLM_CheckList(dlRef);	
	}
#endif

	//_DLM_Debug("Just Loaded", dlRef);	
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
XErr	DLM_SaveList(DLMRef dlRef)
{
XErr		err = noErr;
Boolean		global;
DLMRecP		listP;
BlockRef	listBlock;

	if (global = BufferGetUserBit(dlRef))	// = listP->global)
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	err = _Save(dlRef, listBlock, listP);
	if (global)
		_LeaveCS();

return err;
}

typedef struct
	{
	DLMRef 				dlRef;
	DLMRecP				listP;
	long				*tempP;
	long				*offsetP;
	DLMSortCallBack 	callback;
	DLMSortCallBackFast	callbackFast;
	long				param;
	} SortSwapRec;

//===========================================================================================
static Boolean _SortSwap(long i, long j, long userData, XErr *errP)
{
long			id1, id2;
Boolean			res;
DLMItemP 		item1P, item2P;
SortSwapRec		*sortSwapRecP = (SortSwapRec*)userData;

	id1 = sortSwapRecP->tempP[i];
	id2 = sortSwapRecP->tempP[j];
	item1P = (DLMItemP)((Ptr)sortSwapRecP->listP + sortSwapRecP->offsetP[id1]);
	item2P = (DLMItemP)((Ptr)sortSwapRecP->listP + sortSwapRecP->offsetP[id2]);
	res = sortSwapRecP->callback(sortSwapRecP->dlRef, id1+1, item1P->userData, id2+1, item2P->userData, sortSwapRecP->param, errP);
	
return res;
}

//===========================================================================================
static Boolean _SortSwapFast(long i, long j, long userData, XErr *errP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(errP)
#endif
long			*offsetP, id1, id2;
Boolean			res;
DLMItemP 		item1P, item2P;
SortSwapRec		*sortSwapRecP = (SortSwapRec*)userData;
Ptr				listP;

	id1 = sortSwapRecP->tempP[i];
	id2 = sortSwapRecP->tempP[j];
	listP = (Ptr)sortSwapRecP->listP;
	offsetP = sortSwapRecP->offsetP;
	item1P = (DLMItemP)(listP + offsetP[id1]);
	item2P = (DLMItemP)(listP + offsetP[id2]);
	res = sortSwapRecP->callbackFast(VALUE(item1P), item1P->valueLogicLen, VALUE(item2P), item2P->valueLogicLen, sortSwapRecP->param);
	
return res;
}

//===========================================================================================
XErr	DLM_SortList(DLMRef *dlRefP, DLMSortCallBack callback, DLMSortCallBackFast callbackFast, long param, long alg)
{
register int 	i, j;
register int	totItems;
XErr			err = noErr;
BlockRef		listBlock, offsetBlock;
DLMRecP			listP;
Boolean			global;
BlockRef		tempBlock;
long			*tempP, *offsetP;
DLMItemP 		item1P;
DLMRecP			newListP;
DLMRef			newDLMRef, dlRef = *dlRefP;
SortSwapRec		sortSwapRec;

	if (global = BufferGetUserBit(dlRef))
	{
		if (err = _NoDisposeOnGlobals())
			return err;
		_EnterCS();
	}
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (listP->totItems > 1)
	{	if (listP->locked)
			return _DebugErrListLocked("DLM_SortList", XError(kXHelperError, DLM_Err_ListIsLocked));
		LockBlock(listBlock);
		offsetBlock = listP->offsetsBL;	
		LockBlock(offsetBlock);
		offsetP = (long*)GetPtr(offsetBlock);
		totItems = listP->totItems;
		if (tempBlock = NewBlockLocked(sizeof(long) * totItems, &err, (Ptr*)&tempP))
		{	
			for (i = 0; i < totItems; i++)
				tempP[i] = i;
			sortSwapRec.tempP = tempP;
			sortSwapRec.listP = listP;
			sortSwapRec.dlRef = dlRef;
			sortSwapRec.offsetP = offsetP;
			sortSwapRec.param = param;
			sortSwapRec.callback = callback;
			sortSwapRec.callbackFast = callbackFast;
			if (callbackFast)
				err = _SortLong(tempP, totItems, _SortSwapFast, (long)&sortSwapRec, alg);
			else
				err = _SortLong(tempP, totItems, _SortSwap, (long)&sortSwapRec, alg);
			if NOT(err)
			{	
				// Now rebuild the list in the same order of tempP
				if (listP->acceptDuplicates)
					err = DLM_CreateAcceptDupl(&newDLMRef, listP->listType, global/*listP->global*/);
				else
					err = DLM_Create(&newDLMRef, listP->listType, global/*listP->global*/);
				if NOT(err)
				{	long	tempID, idToCopy;
				
					GET_LIST_BLOCK(newDLMRef, newListP);
					newListP->arrayUserData = listP->arrayUserData;
					for (i = 0; (i < totItems) && NOT(err); i++)
					{	tempID = tempP[i];
						idToCopy = tempID + 1;
						GET_LIST_BLOCK(dlRef, listP);
						offsetP = (long*)GetPtr(offsetBlock);
						item1P = (DLMItemP)((Ptr)listP + offsetP[tempID]);
						if NOT(err = _CopyObject(dlRef, idToCopy, newDLMRef, item1P->name, item1P->flags, nil, false, 0))
						{	if NOT(err = _RemoveItems(dlRef, idToCopy, idToCopy, nil, 0, false))
							{	for (j = i+1; j < totItems; j++)
								{	if (tempP[j] > tempID)
										tempP[j]--;
								}
							}
						}
					}
					if not(err)
					{	
						if not(err = DLM_Dispose(&dlRef, nil, 0))
							*dlRefP = newDLMRef;
					}
					if (err)
						DLM_DisposeGlobal(&newDLMRef, nil, 0);
					
				}
			}
			DisposeBlock(&tempBlock);
		}
		UnlockBlock(offsetBlock);
		UnlockBlock(listBlock);
	}
	if (global)
		_LeaveCS();

return err;
}

//===========================================================================================
XErr	DLM_ReverseList(DLMRef *dlRefP)
{
register int	i, totItems;
long			*offsetP;
DLMItemP 		itemP;
XErr			err = noErr;
BlockRef		listBlock, offsetBlock;
DLMRecP			newListP, listP;
DLMRef			newDLMRef, dlRef = *dlRefP;
Boolean			global;

	if (global = BufferGetUserBit(dlRef))
	{	
		if (err = _NoDisposeOnGlobals())
			return err;
		_EnterCS();
	}
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (listP->totItems > 1)
	{	if (listP->locked)
			return _DebugErrListLocked("DLM_ReverseList", XError(kXHelperError, DLM_Err_ListIsLocked));
		LockBlock(listBlock);
		offsetBlock = listP->offsetsBL;	
		LockBlock(offsetBlock);
		totItems = listP->totItems;
		if (listP->acceptDuplicates)
			err = DLM_CreateAcceptDupl(&newDLMRef, listP->listType, global);
		else
			err = DLM_Create(&newDLMRef, listP->listType, global);
		if NOT(err)
		{	GET_LIST_BLOCK(newDLMRef, newListP);
			newListP->arrayUserData = listP->arrayUserData;
			for (i = totItems; ((i > 0) && NOT(err)); i--)
			{	GET_LIST_BLOCK(dlRef, listP);
				offsetP = (long*)GetPtr(offsetBlock);
				itemP = (DLMItemP)((Ptr)listP + offsetP[i-1]);
				if NOT(err = _CopyObject(dlRef, i, newDLMRef, itemP->name, itemP->flags, nil, false, 0))
					err = _RemoveItems(dlRef, i, i, nil, 0, false);
			}
			if not(err)
			{	
				if not(err = DLM_Dispose(&dlRef, nil, 0))
					*dlRefP = newDLMRef;
			}
			if (err)
				DLM_DisposeGlobal(&newDLMRef, nil, 0);
		}
		UnlockBlock(offsetBlock);
		UnlockBlock(listBlock);
	}
	if (global)
		_LeaveCS();
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	DLM_ListInfo(DLMRef dlRef, long *listTypeP, Byte *listUserDataP, Boolean *globalP, long *totalSizeP)
{
DLMRecP		listP;
XErr		err = noErr;
BlockRef	bl;
Boolean		global;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		bl = BufferGetBlockRefExt(dlRef, (Ptr*)&listP);
		if (listTypeP)
			*listTypeP = listP->listType;
		if (globalP)
			*globalP = global;	//listP->global;
		if (listUserDataP)
			CopyBlock(listUserDataP, listP->listUserData, LIST_USER_DATA_DIM);
		if (totalSizeP)
		{	if (listP->indexs)
				*totalSizeP = listP->totPhysLen + (listP->totItems * sizeof(LONGLONG));
			else
				*totalSizeP = listP->totPhysLen + (listP->totItems * sizeof(long));
		}
		if (global)
			_LeaveCS();
	}
	
return err;
}

//===========================================================================================
XErr	DLM_Create(DLMRef *dlRefP, long listType, long global)
{
	return _CreateDLMList(dlRefP, listType, global, false);
}

//===========================================================================================
XErr	DLM_CreateAcceptDupl(DLMRef *dlRefP, long listType, long global)
{
	return _CreateDLMList(dlRefP, listType, global, true);
}

#ifdef MEM_DEBUG
	//===========================================================================================
	void	DLM_CheckList(DLMRef dlRef)
	{
	DLMRecP		listP;
	BlockRef	listBlock, listIndBL, listOffBL;
	long		*indexP, *offsetP, *startOffsetP;
	int			i, totItems;
	DLMItemP	item1P, item2P;
	CStr63		lastName;
	CompareFunc cFunc;
	Boolean		global;

		if (dlRef)
		{	if (global = BufferGetUserBit(dlRef))
				_EnterCS();
			listBlock = BufferGetBlockRef(dlRef, nil);
			GetBlockSize(listBlock, nil);		// to check page guardians
			listP = (DLMRecP)GetPtr(listBlock);
			listOffBL = BufferGetBlockRef(listP->offsets, nil);
			if (listP->offsetsBL == listOffBL)
				startOffsetP = offsetP = (long*)GetPtr(listP->offsetsBL);
			else
				CDebugStr("DLM Check List: bad offsets");
			GetBlockSize(listOffBL, nil);		// to check page guardians
			totItems = listP->totItems;
			if (listP->indexs)
			{	listIndBL = BufferGetBlockRef(listP->indexs, nil);
				if (listP->indexsBL == listIndBL)
					indexP = (long*)GetPtr(listP->indexsBL);
				else
					CDebugStr("DLM Check List: bad indexs");
				GetBlockSize(listIndBL, nil);		// to check page guardians
				*lastName = 0;
				for (i = 0; i < totItems; i++, offsetP++)
				{	item1P = (DLMItemP)((Ptr)listP + *offsetP);
					if (indexP)
					{	item2P = (DLMItemP)((Ptr)listP + ((long*)startOffsetP)[indexP[i]]);
						if (listP->listType == NAME_LIST)
							cFunc = CCompareStrings;
						else if (listP->listType == NAMECS_LIST)
							cFunc = CCompareStrings_cs;
						if (*lastName && (cFunc(lastName, item2P->name) < 0))
							CDebugStr("DLM Check List: list is not ordered");
						CEquStr(lastName, item2P->name);
					}
					if (item1P->flags & kIsArray)
						DLM_CheckList(*(DLMRef*)VALUE(item1P));
				}
			}
			else
			{	for (i = 0; i < totItems; i++, offsetP++)
				{	item1P = (DLMItemP)((Ptr)listP + *offsetP);
					if (item1P->flags & kIsArray)
						DLM_CheckList(*(DLMRef*)VALUE(item1P));
				}
			}
			if (global)
				_LeaveCS();
		}	
	}
#endif
//===========================================================================================
XErr	DLM_Dispose(DLMRef *dlRefP, DLMLoopCallBack callBack, long param)
{
	return _DisposeList(dlRefP, callBack, param, false);
}

//===========================================================================================
XErr	DLM_DisposeGlobal(DLMRef *dlRefP, DLMLoopCallBack callBack, long param)
{
	return _DisposeList(dlRefP, callBack, param, true);
}

//===========================================================================================
XErr	DLM_Close(DLMRef *dlRefP, DLMLoopCallBack callBack, long param, Boolean ignoreGlobal)
{
	XErr		err = noErr;
	DLMRecP		listP;
	BlockRef	listBlock;
	XFileRef	fileRef;
	DLMRef		dlRef = *dlRefP;
	Boolean		global;
	
	if (global = BufferGetUserBit(dlRef))	// = listP->global)
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	fileRef = listP->fileRef;
	_DisposeList(dlRefP, callBack, param, ignoreGlobal);
	err = CloseXFile(&fileRef);
	if (global)
		_LeaveCS();
	
	return err;
}

//===========================================================================================
void	DLM_ResetList(DLMRef dlRef, DLMLoopCallBack callBack, long param, long level, Boolean resizeBlocks)
{
XErr		err = noErr;
DLMRecP		listP;
BlockRef	listBlock;
Boolean		global;
DLMRef		superList;
long		supID, i, totItems, newTotPhysLen, *offsetP, *indexsP, *tOffP;
long		superLevel;
DLMItemP	itemP;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))	// = listP->global)
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if NOT(listP->locked)
		{	totItems = listP->totItems;
			if ((level < 0) || (level >= totItems))
				;
			else
			{	if (listP->superList)
					superList = listP->superList;
				else
					superList = 0L;
				LockBlock(listBlock);
				_Dispose(dlRef, listBlock, listP, level, callBack, param, false);					// From level to the end
				offsetP = (long*)GetPtr(listP->offsetsBL);
				superLevel = 0;
				if (level)
				{	newTotPhysLen = offsetP[level];
					if (superList)
					{	long	lastGoodSupID;
					
						lastGoodSupID = 0;
						tOffP = offsetP;
						for (i = 0; i < level; i++, tOffP++)
						{	itemP = (DLMItemP)((Ptr)listP + *tOffP);
							if ((supID = itemP->superID) && (supID > lastGoodSupID))
								lastGoodSupID = supID;
						}
						if (lastGoodSupID)
							superLevel = lastGoodSupID + 1;
					}
				}
				else
					newTotPhysLen = sizeof(DLMRec) - sizeof(DLMItem);						// 0 objects
				ClearBlock(offsetP + level, sizeof(long) * (totItems - level));
				if (listP->indexs)
				{	indexsP = (long*)GetPtr(listP->indexsBL);
					if (level)
						_CompactList(indexsP, totItems, level, totItems-1);
					ClearBlock(indexsP + level, sizeof(long) * (totItems - level));
				}
				listP->totPhysLen = newTotPhysLen;
				listP->totItems = level;
				// listP->totArrays is updated by _Dispose
				listP->dirty = true;
				if (listP->fileRef)
					err = _Save(dlRef, listBlock, listP);
				if NOT(err)
				{	if (resizeBlocks)
					{	if (listP->indexs)
							BufferSetLength(listP->indexs, listP->totItems * sizeof(long));
						if (listP->offsets)
							BufferSetLength(listP->offsets, listP->totItems * sizeof(long));
						BufferSetLength(dlRef, newTotPhysLen);
					}
					if (superList)
						DLM_ResetList(superList, callBack, param, superLevel, resizeBlocks);
				}
				UnlockBlock(listBlock);
			}
		}
		//_DLM_Debug("Resetted", dlRef);
		if (global)
			_LeaveCS();
		
	}
	else
		CDebugStr("DLM is null");
}

//===========================================================================================
XErr	DLM_CloneList(DLMRef sourceList, DLMRef *destListP)
{
XErr		err = noErr;
DLMRecP		newListP, listP;
long		totItems, lengthToClone, oldOffsets, oldIndexs, offsets, indexs;
Boolean		global;
BlockRef	destListBlock, sourceListBlock;
DLMRef		superList;

	*destListP = 0;
	if (sourceList)
	{	if (global = BufferGetUserBit(sourceList))	// = listP->global)
			_EnterCS();
		sourceListBlock = GET_LIST_BLOCK(sourceList, listP);
		lengthToClone = listP->totPhysLen;
		if NOT(err = BufferClone(sourceList, destListP, lengthToClone))
		{	//_DLM_Debug("Created (cloned)", *destListP);
			if (global)
				BufferOnUserBit(*destListP);
			destListBlock = GET_LIST_BLOCK(*destListP, newListP);
			GET_LIST_BLOCK(sourceList, listP);
			totItems = listP->totItems;
			oldOffsets = listP->offsets;
			oldIndexs = listP->indexs;
			superList = listP->superList; 
			if (oldOffsets)
				err = BufferClone(oldOffsets, &offsets, sizeof(long) * totItems);
			else
				offsets = 0;
			if NOT(err)
			{	if (oldIndexs)
					err = BufferClone(oldIndexs, &indexs, sizeof(long) * totItems);
				else
					indexs = 0;
				if NOT(err)
				{	newListP = ((DLMRecP)GetPtr(destListBlock));	// reload
					newListP->offsets = offsets;
					if (offsets)
						newListP->offsetsBL = BufferGetBlockRef(offsets, nil);
					newListP->indexs = indexs;
					if (indexs)
						newListP->indexsBL = BufferGetBlockRef(indexs, nil);
					newListP->dirty = true;
					err = _CloneAllArrays(*destListP);
					if (superList)
					{	DLMRef	newSuper;
					
						if NOT(err = DLM_CloneList(superList, &newSuper))
						{	newListP = ((DLMRecP)GetPtr(destListBlock));	// reload
							newListP->superList = newSuper;
						}
					}
				}
			}
		}	
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);

return err;
}

//===========================================================================================
XErr	DLM_ConcatLists(DLMRef list1, DLMRef list2, char *nameError)
{
register int	i, totItems;
long			destId, *offsetP;
DLMItemP 		itemP;
XErr			err = noErr;
BlockRef		listBlock, offsetBlock;
DLMRecP			listP;

	listBlock = GET_LIST_BLOCK(list2, listP);
	LockBlock(listBlock);
	offsetBlock = listP->offsetsBL;
	LockBlock(offsetBlock);
	offsetP = (long*)GetPtr(offsetBlock);
	totItems = listP->totItems;
	if (nameError)
		*nameError = 0;
	for (i = 1; ((i <= totItems) && NOT(err)); i++, offsetP++)
	{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
		if (err = DLM_CopyObj(list2, i, list1, itemP->name, itemP->flags, &destId))
		{	if ((err == XError(kXHelperError, DLM_Err_DuplicatedObject)) && nameError)
				CEquStr(nameError, itemP->name);
		}
	}

	if (listP->superList)
	{	DLMRecP		list1P;
	
		listBlock = GET_LIST_BLOCK(list1, list1P);
		DLM_ConcatLists(list1P->superList, listP->superList, nameError);
	}
	UnlockBlock(offsetBlock);
	UnlockBlock(listBlock);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	DLM_SetObjFlag(DLMRef dlRef, long objID, unsigned short flags)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
	
	if (dlRef)
	{	listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			return _DebugErrListLocked("DLM_SetObjFlag", XError(kXHelperError, DLM_Err_ListIsLocked));
		if (objID && (objID <= listP->totItems))
		{	offsetP = (long*)GetPtr(listP->offsetsBL);
			itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);
			if (NOT(itemP->flags & kIsArray) && (flags & kIsArray))
				listP->totArrays++;
			itemP->flags = flags;
		}
		else
			err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
	
return err;
}

//===========================================================================================
long	DLM_NewObjAtPos(DLMRef dlRef, char *name, Ptr dataP, long dataLen, long userData, unsigned short flags, long atPos, XErr *errP)
{
XErr		err = noErr;
long		objID = 0, pos = 0, dir = 1;
Boolean		found, global;
DLMRecP 	listP;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))	// = listP->global)
			_EnterCS();
		GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_NewObjAtPos", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	if (listP->acceptDuplicates)
				found = (_FindItemPos(listP, name, -1, &pos, &dir, nil)) >= 0;
			else
			{	found = (_FindItemPos(listP, name, 0, &pos, &dir, nil)) >= 0;
				if (found)
					err = XError(kXHelperError, DLM_Err_DuplicatedObject);
			}
			if NOT(err)
				err = _NewObject(dlRef, name, dataP, dataLen, userData, flags, &objID, pos, dir, 0, 0, atPos);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
	if (err)	
	{	if (errP)
			*errP = err;
		objID = 0;
	}
	else
	{	if (errP)
			*errP = noErr;
		objID++;
	}

return objID;
}

//===========================================================================================
long	DLM_NewObjWithSuper(DLMRef dlRef, char *name, Ptr dataP, long dataLen, long userData, unsigned short flags, long superList, long superID, XErr *errP)
{
XErr		err = noErr;
Boolean		justCreated = false, global;
long		objID, newSuperID;
DLMRecP		listP;
DLMRef		destList;
	
	if (objID = DLM_NewObj(dlRef, name, dataP, dataLen, userData, flags, &err))
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		GET_LIST_BLOCK(dlRef, listP);
		if (listP->superList)
			destList = listP->superList;
		else
		{	if NOT(err = DLM_Create(&destList, ID_LIST, global/*listP->global*/))
			{	GET_LIST_BLOCK(dlRef, listP);
				listP->superList = destList;
				justCreated = true;
			}
		}
		if NOT(err)
		{	
			if NOT(err = DLM_CopyObj(superList, superID, destList, nil, _FilterFlags(superList, superID, flags), &newSuperID))
				err = _SetSuperID(dlRef, objID, newSuperID);
		}
		if (err && justCreated)
		{	GET_LIST_BLOCK(dlRef, listP);	// reload
			listP->superList = 0L;
			DLM_DisposeGlobal(&destList, nil, 0);
		}
		if (global)
			_LeaveCS();
	}
	if (errP)
		*errP = err;
	
return objID;
}

//===========================================================================================
XErr	DLM_NewSuperObj(DLMRef dlRef, long objID, long superList, long superID, DLMRef *newList, long *newSuperID)
{
XErr			err = noErr;
unsigned short	flags;

	if NOT(err = DLM_GetInfo(dlRef, objID, &flags, nil, nil))
		err = _AddSuperObj(superList, superID, dlRef, objID, _FilterFlags(superList, superID, flags), true, true, newList, newSuperID);

return err;
}

//===========================================================================================
long	DLM_GetSuperObjID(DLMRef dlRef, long objID, DLMRef *superList)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		superID, *offsetP;
Boolean		global;

	superID = 0;
	if (global = BufferGetUserBit(dlRef))	// = listP->global)
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
		if (listP->superList && itemP->superID)
		{	*superList = listP->superList;
			//*flagsP = itemP->flags;
			//*userDataP = itemP->userData;
			superID = itemP->superID;
		}
	}
	if (global)
		_LeaveCS();

return superID;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// buffer must be 256 bytes in length
// allocates always 1-byte more for zero termination
XErr	DLM_GetObjBlock(DLMRef dlRef, long objID, Ptr buffer, Ptr *resultP, long *resultLenP, BlockRef *refP)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP, sourceLen;
Ptr			sourceP;
XErr		err = noErr;
Boolean		global;
Ptr			dataP;
BlockRef	dataBlock = 0;

	if (global = BufferGetUserBit(dlRef))	// = listP->global)
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);	
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
		sourceP = VALUE(itemP);
		sourceLen = itemP->valueLogicLen;		
		if (buffer && (sourceLen <= 255))
		{	dataP = buffer;
			*refP = 0;
		}
		else
		{	if (dataBlock = NewBlockLocked(sourceLen + 1, &err, &dataP))
				*refP = dataBlock;
		}
		if NOT(err)
		{	CopyBlock(dataP, sourceP, sourceLen);
			*resultLenP = sourceLen;
			dataP[sourceLen] = 0;	// zero termination
			*resultP = dataP;
			
		}
	}
	if (global)
		_LeaveCS();

return err;
}

//===========================================================================================
XErr	DLM_GetObj(DLMRef dlRef, long objID, Ptr dataP, long *dataLenP, long offset, long *userDataP)
{
	return _GetObj(dlRef, objID, dataP, dataLenP, offset, userDataP, nil, nil, false, false);
}

//===========================================================================================
/*long	DLM_GetObjID(DLMRef dlRef, char *name, long *flagsP, long *userDataP)
{
	return _GetObjID(dlRef, name, 0, flagsP, userDataP, nil);
}

//===========================================================================================
long	DLM_GetIndexObjID(DLMRef dlRef, char *name, long index, long *flagsP, long *userDataP)
{
	return _GetObjID(dlRef, name, index, flagsP, userDataP, nil);
}

//===========================================================================================
long	DLM_GetObjID_Begins(DLMRef dlRef, char *name, long index, long *flagsP, long *userDataP)
{
	return _GetObjID(dlRef, name, index, flagsP, userDataP, _BeginCompare);
}
*/
//===========================================================================================
XErr	DLM_GetInfo(DLMRef dlRef, long objID, unsigned short *flagsP, long *userDataP, char *name)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))	// = listP->global)
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID <= listP->totItems)
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);		// internally is 0-based
		if (userDataP)
			*userDataP = itemP->userData;
		if (flagsP)
			*flagsP = itemP->flags;
		if (name && itemP->name)
			CEquStr(name, itemP->name);
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
XErr	DLM_SetName(DLMRef dlRef, long objID, char *name)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*indexs, *offsetP;
XErr		err = noErr;
Boolean		moved, global, doNothing;
long		namePaddedLen, totItems, diff, nameLen;

	if (name)
	{	doNothing = false;
		nameLen = CLen(name);
		if (nameLen > NAME_MAX_LENGTH)
			return XError(kXHelperError, DLM_Err_NameTooLong);
		if (global = BufferGetUserBit(dlRef))	// = listP->global)
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_SetName", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	listP->dirty = true;
			if (listP->listType == ID_LIST)
				err = XError(kXHelperError, DLM_Err_ListDontAcceptNames);
			else
			{	if NOT(listP->acceptDuplicates)
				{	long	dupObjID;
				
					if ((dupObjID = _FindItemPos(listP, name, 0, nil, nil, nil)) >= 0)
					{	if (listP->indexs)
						{	dupObjID = ((long*)GetPtr(listP->indexsBL))[dupObjID] + 1;
							if (dupObjID == objID)
								doNothing = true;
							else
								err = XError(kXHelperError, DLM_Err_DuplicatedObject);
						}
						else
							err = XError(kXHelperError, DLM_Err_ListDontAcceptNames);
					}
				}
				if (NOT(err) && NOT(doNothing))
				{	offsetP = (long*)GetPtr(listP->offsetsBL);
					itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);	// internally is 0-based
					if (nameLen)
						namePaddedLen = _PadLong(nameLen);
					else
						namePaddedLen = 0;
					diff = namePaddedLen - itemP->namePaddedLen;
					if NOT(err = BufferCheck(dlRef, listP->totPhysLen + diff, &moved))
					{	Ptr		sourceP, destP;
						long	thisOffset, off, nextItemOff, lenToMove, i;
						
						if (moved)
						{	// reload all
							listP = ((DLMRecP)GetPtr(listBlock));
							offsetP = (long*)GetPtr(listP->offsetsBL);
							itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID]);
						}
						totItems = listP->totItems;
						if (objID < (totItems-1))
						{	nextItemOff = offsetP[objID+1];
							sourceP = (Ptr)listP + nextItemOff - itemP->valuePhysicLen;			// Move also the value
							destP = sourceP + diff;
							lenToMove = listP->totPhysLen - nextItemOff + itemP->valuePhysicLen; // Move also the value
							CopyBlock(destP, sourceP, lenToMove);
							thisOffset = offsetP[objID];
							for (i = objID+1, offsetP = &offsetP[objID+1]; i < totItems; i++, offsetP++)		// aggiorno tutti gli offsets successivi
							{	if ((off = *offsetP) > thisOffset)
									*offsetP = off + diff;
							}
						}
						else
						{	sourceP = VALUE(itemP);			// Move also the value
							destP = sourceP + diff;
							lenToMove = itemP->valuePhysicLen; // Move also the value
							CopyBlock(destP, sourceP, lenToMove);
						}	
						listP->totPhysLen += diff;
						itemP->namePaddedLen = (Byte)namePaddedLen;
						if (nameLen)
						{	CopyBlock(itemP->name, name, nameLen);
							*(itemP->name + nameLen) = 0;
							FillBlock(itemP->name + nameLen + 1, namePaddedLen - nameLen, 'x');
						}
						else
							itemP->name[0] = 0;
						if (nameLen && NOT(listP->indexs))
							err = _CreateIndexs(listP, listP->totItems);
						if NOT(err)
						{	listP = ((DLMRecP)GetPtr(listBlock));	// reload
							indexs = (long*)GetPtr(listP->indexsBL);
							offsetP = (long*)GetPtr(listP->offsetsBL);
							_ReorderIndexs(listP, offsetP, indexs, (Boolean)(listP->listType == NAMECS_LIST));
						}
					}
				}
			}
		}
		if (global)
			_LeaveCS();

		#ifdef MEM_DEBUG
			DLM_CheckList(dlRef);
		#endif
	}
	
return err;
}

//===========================================================================================
XErr	DLM_SetUserData(DLMRef dlRef, long objID, long newUserData)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (listP->locked)
		err = _DebugErrListLocked("DLM_SetUserData", XError(kXHelperError, DLM_Err_ListIsLocked));
	else
	{	listP->dirty = true;
		offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);		// internally is 0-based
		itemP->userData = newUserData;
	}
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
XErr	DLM_TurnOnFlag(DLMRef dlRef, long objID, long flagToOn, long turnFlag)
{
DLMRecP				listP;
BlockRef			listBlock;
DLMItemP			itemP;
long				*offsetP;
Boolean				global;
XErr				err = noErr;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	listP->dirty = true;
	if (listP->locked)
		err = _DebugErrListLocked("DLM_TurnOnFlag", XError(kXHelperError, DLM_Err_ListIsLocked));
	else
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);	// internally is 0-based	
		if (itemP->flags & kIsArray)
		{	TurnFlagParamRec	param;
		
			if (turnFlag & kDLMElements)
			{	param.flagToToggle = flagToOn;
				param.turnFlag = turnFlag;
				err = DLM_Loop(((ArrayRecP)VALUE(itemP))->arDLRef, _TurnOnFlagCallBack, (long)&param, false, false);
			}
			if (turnFlag & kDLMMain)
				itemP->flags |= flagToOn;
		}
		else
			itemP->flags |= flagToOn;
		if NOT(err)
		{	if (itemP->superID)
				err = DLM_TurnOnFlag(listP->superList, itemP->superID, flagToOn, turnFlag);
		}
	}
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
XErr	DLM_TurnOffFlag(DLMRef dlRef, long objID, long flagToOff, long turnFlag)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
Boolean		global;
XErr		err = noErr;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	listP->dirty = true;
	if (listP->locked)
		err = _DebugErrListLocked("DLM_TurnOffFlag", XError(kXHelperError, DLM_Err_ListIsLocked));
	else
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);		// internally is 0-based
		if (itemP->flags & kIsArray)
		{	TurnFlagParamRec	param;
		
			if (turnFlag & kDLMElements)
			{	param.flagToToggle = flagToOff;
				param.turnFlag = turnFlag;
				err = DLM_Loop(((ArrayRecP)VALUE(itemP))->arDLRef, _TurnOffFlagCallBack, (long)&param, false, false);
			}
			if (turnFlag & kDLMMain)
				itemP->flags &= (0xFFFFFFFF ^ flagToOff);				// turn off the bit
		}
		else
			itemP->flags &= (0xFFFFFFFF ^ flagToOff);				// turn off the bit

		if NOT(err)
		{	if (itemP->superID)
				err = DLM_TurnOffFlag(listP->superList, itemP->superID, flagToOff, turnFlag);
		}
		/*if ((itemP->flags & kIsArray) && (arrayAlsoMain != -1))
			err = DLM_Loop(((ArrayRecP)itemP->value)->arDLRef, _TurnOffFlagCallBack, flagToOff, false, false);
		else
			arrayAlsoMain = 1;
		if (arrayAlsoMain)
			itemP->flags &= (0xFFFFFFFF ^ flagToOff);				// turn off the bit*/
	}	
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
/*XErr	DLM_SetObjChar(DLMRef dlRef, long objID, long index, Byte theChar)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
XErr		err = noErr;
long		*offsetP;
Boolean		global;

	if (dlRef)
	{	listBlock = GET_LIST_BLOCK(dlRef, listP);
		listP->dirty = true;
		if (global = listP->global)
			_EnterCS();
		if (objID && (objID <= listP->totItems))
		{	offsetP = (long*)GetPtr(listP->offsetsBL);
			itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);
			if (itemP->flags & kIsArray)
				err = XError(kXHelperError, DLM_Err_InvalidArrayIndex);
			else if (itemP->flags & kCostant)
				err = XError(kXHelperError, DLM_Err_ObjectIsConstant);
			else if ((index > 0) && (index <= itemP->valueLogicLen))
				*(VALUE(itemP) + --index) = theChar;
			else
				err = XError(kXHelperError, DLM_Err_OutOfBoundary);
		}
		else
			err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);

return err;
}
*/
//===========================================================================================
// userData DLM_USERDATA_DEFAULT => non modificare userData
XErr	DLM_ModifyObj(DLMRef dlRef, long objID, Ptr dataP, long dataLen, long userData, DLMLoopCallBack callBack, long param, DLMLoopCallBack notifyProc)
{
DLMRecP			listP;
BlockRef		listBlock;
DLMItemP		itemP;
long			toClear, off, thisOffset, lenToMove, totItems, nextItemOff, diff, newPhysicLen, i, *offsetP;
Ptr				sourceP, destP;
XErr			err = noErr;
Boolean			moved, global;
DLMRef			dlRefToDispose = 0;
Boolean			fixedSize;
unsigned short	itemFlags;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_ModifyObj", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	listP->dirty = true;
			if (objID && (objID <= listP->totItems))
			{	offsetP = (long*)GetPtr(listP->offsetsBL);
				itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
				itemFlags = itemP->flags;
				fixedSize = (itemFlags & kFixedSize) != 0;
				if (itemFlags & kCostant)
					err = XError(kXHelperError, DLM_Err_ObjectIsConstant);
				else if (itemFlags & kLocked)
					err = XError(kXHelperError, DLM_Err_ObjectIsLocked);
				else if (fixedSize && itemP->valueLogicLen && (dataLen != itemP->valueLogicLen))
					err = XError(kXHelperError, DLM_Err_CantModifyLength);
				else
				{	if (listP->arrayUserData != DLM_USERDATA_DEFAULT)		// dlref that are arrays
					{	if NOT(listP->arrayUserData)
						{	if (userData != DLM_USERDATA_DEFAULT)
								listP->arrayUserData = userData;
						}
						else if (listP->arrayUserData != userData)
						{	if (userData == DLM_USERDATA_DEFAULT)
								itemP->userData = listP->arrayUserData;
							else
								err = XError(kXHelperError, DLM_Err_ArrayElemWrongType);
						}
					}
					if NOT(err)
					{	// Destructor if Array
						if (itemFlags & kIsArray)
						{	
							if (global)
								err = _NoDisposeOnGlobals();
							if not(err)
								dlRefToDispose = ((ArrayRecP)VALUE(itemP))->arDLRef;
						}
						if not(err)
						{
							// Calcolo la nuova physSize del singolo elemento
							if (fixedSize)
							{	if (itemP->valuePhysicLen)
									newPhysicLen = itemP->valuePhysicLen;
								else
									newPhysicLen =  _PadLong(dataLen);
							}
							else if (dataLen > itemP->valuePhysicLen)
								newPhysicLen = _PadLong(dataLen);
							else
								newPhysicLen = itemP->valuePhysicLen;	// never shrink the object
							diff = newPhysicLen - itemP->valuePhysicLen;
							_EnterCS();
							XGetCurrentThread(&gThreadLocking);
							listP->locked = true;
							if NOT(err = BufferCheck(dlRef, listP->totPhysLen + diff, &moved))
							{	// If got here, modify will be successfull, so now notify if needed
								// Note that notifyProc shouldn't modify this dlref, otherwise can arise big problems!!
								// But the list is locked, so no problems
								// Nevertheless it can move memory
								if (notifyProc)
									err = notifyProc(dlRef, objID+1, itemFlags, userData, param);
								if NOT(err)
								{
								#ifdef __MEM_CANMOVE__ 
									if (moved || notifyProc)	// notifyProc can move memory
								#else
									if (moved)
								#endif
									{	// reload all
										listP = ((DLMRecP)GetPtr(listBlock));
										offsetP = (long*)GetPtr(listP->offsetsBL);
										itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID]);	// nota --objID � gi� stato fatto righe pi� su
									}
									totItems = listP->totItems;
									if (objID < (totItems-1))
									{	nextItemOff = offsetP[objID+1];
										sourceP = (Ptr)listP + nextItemOff;
										destP = sourceP + diff;
										lenToMove = listP->totPhysLen - nextItemOff;
										CopyBlock(destP, sourceP, lenToMove);
										thisOffset = offsetP[objID];
										for (i = objID+1, offsetP = &offsetP[objID+1]; i < totItems; i++, offsetP++)		// aggiorno tutti gli offsets successivi
										{	if ((off = *offsetP) > thisOffset)
												*offsetP = off + diff;
										}
									}
									if (dataP)
										CopyBlock(VALUE(itemP), dataP, dataLen);
									else if ((toClear = (dataLen - itemP->valueLogicLen)) > 0)
										FillBlock(VALUE(itemP) + itemP->valueLogicLen, toClear, ' ');
									listP->totPhysLen += diff;
									itemP->valueLogicLen = dataLen;
									itemP->valuePhysicLen = newPhysicLen;
									if (userData != DLM_USERDATA_DEFAULT)
										itemP->userData = userData;
									if (dlRefToDispose && NOT(err))
										err = DLM_Dispose(&dlRefToDispose, callBack, param);
								}
							}
							listP->locked = false;
							gThreadLocking = 0;
							_LeaveCS();
						}
					}
				}
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
	
return err;
}

//===========================================================================================
XErr	DLM_WriteObj(DLMRef dlRef, long objID, Ptr dataP, long dataLen, long atOffset)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
XErr		err = noErr;
long		*offsetP;
Boolean		global;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_WriteObj", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	listP->dirty = true;
			if (objID && (objID <= listP->totItems))
			{	offsetP = (long*)GetPtr(listP->offsetsBL);
				itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);
				if (itemP->flags & kIsArray)
					err = XError(kXHelperError, DLM_Err_IllegalOperation);
				else if (itemP->flags & kCostant)
					err = XError(kXHelperError, DLM_Err_ObjectIsConstant);
				else if (itemP->flags & kLocked)
					err = XError(kXHelperError, DLM_Err_ObjectIsLocked);
				else if ((atOffset > 0) && ((--atOffset + dataLen) <= itemP->valueLogicLen))
				{	
					CopyBlock(VALUE(itemP) + atOffset, dataP, dataLen);
				}
				else
					err = XError(kXHelperError, DLM_Err_OutOfBoundary);
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);

return err;
}

//===========================================================================================
XErr	DLM_ResetObj(DLMRef dlRef, long objID, DLMLoopCallBack callBack, long param)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global;
DLMRef		dlRefToDispose = 0;
	
	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_ResetObj", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	if (objID && (objID <= listP->totItems))
			{	offsetP = (long*)GetPtr(listP->offsetsBL);
				itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
				if (itemP->flags & kLocked)
					err = XError(kXHelperError, DLM_Err_ObjectIsLocked);
				else if (itemP->flags & kIsArray)
				{	dlRefToDispose = ((ArrayRecP)VALUE(itemP))->arDLRef;
					if (global)
						err = _NoDisposeOnGlobals();
					if not(err)
						listP->totArrays--;
				}
				if NOT(err)
				{	
					listP->dirty = true;
					ClearBlock(VALUE(itemP), itemP->valuePhysicLen);
					itemP->valueLogicLen = 0L;
					itemP->userData = 0;
					itemP->flags = 0;
					if (itemP->superID)
						err = DLM_ResetObj(listP->superList, itemP->superID, callBack, param);
					if not(err)
					{
						itemP->superID = 0;
						if (dlRefToDispose)
							err = DLM_Dispose(&dlRefToDispose, callBack, param);
					}
				}
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
		
	
return err;
}

//===========================================================================================
XErr	DLM_ModifyObjExt(DLMRef destList, long destObjID, DLMRef valueList, long valueID, DLMLoopCallBack callBack, long param, DLMLoopCallBack notifyProc)
{
DLMRecP		destListP, valueListP;
BlockRef	destListBlock, valueListBlock;
DLMItemP	itemP;
XErr		err = noErr;
long		superID, *offsetP;
Boolean		saveGlobal, global;
DLMRef		superList;

	if (destList && valueList)
	{	
		if (BufferGetUserBit(valueList) || BufferGetUserBit(destList))
		{	
			global = true;
			_EnterCS();
		}
		else
			global = false;
		saveGlobal = global;
		valueListBlock = GET_LIST_BLOCK(valueList, valueListP);
		destListBlock = GET_LIST_BLOCK(destList, destListP);
		if (destListP->locked)
			err = _DebugErrListLocked("DLM_ModifyObjExt", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	if (valueID && (valueID <= valueListP->totItems))
			{	offsetP = (long*)GetPtr(valueListP->offsetsBL);
				itemP = (DLMItemP)((Ptr)valueListP + ((long*)offsetP)[valueID-1]);
				superList = valueListP->superList;
				superID = itemP->superID;
				LockBlock(valueListBlock);
				if NOT(err = DLM_ModifyObj(destList, destObjID, VALUE(itemP), itemP->valueLogicLen, itemP->userData, callBack, param, notifyProc))
				{	if (itemP->flags & kIsArray)
						DLM_SetObjFlag(destList, destObjID, kIsArray);
					if (superID)
					{	destListBlock = GET_LIST_BLOCK(destList, destListP);
						offsetP = (long*)GetPtr(destListP->offsetsBL);
						itemP = (DLMItemP)((Ptr)destListP + ((long*)offsetP)[destObjID-1]);
						if (itemP->superID)
							err = DLM_TurnOnFlag(destListP->superList, itemP->superID, kNoDestructor, kDLMWhole);
						if NOT(err)
							err = DLM_NewSuperObj(destList, destObjID, superList, superID, nil, nil);
					}
				}
				UnlockBlock(valueListBlock);
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);

return err;
}

//===========================================================================================
XErr	DLM_DeleteObjects(DLMRef listRef, long firstToRemove, long lastToRemove, DLMLoopCallBack callBack, long param)
{
	return _RemoveItems(listRef, firstToRemove, lastToRemove, callBack, param, true);
}

//===========================================================================================
XErr	DLM_SwapObjects(DLMRef dlRef, long objID1, long objID2)
{
DLMRecP		listP;
BlockRef	listBlock;
XErr		err = noErr;
long		*offsetP;
Boolean		global;
//DLMRef		arrayDLRef = 0;
DLMItemP	item1P, tempP;
long		sizeOfItem1;
BlockRef	tempBlock;

	if (dlRef)
	{	
	#ifdef MEM_DEBUG
		DLM_CheckList(dlRef);
	#endif
		if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_SwapObjects", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	offsetP = (long*)GetPtr(listP->offsetsBL);
			if (objID1 && (objID1 <= listP->totItems))
			{	item1P = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID1]);
				sizeOfItem1 = sizeof(DLMItem) - ITEM_MIN_SIZE + item1P->valuePhysicLen;
				// Copy item1 on item2
				if (tempBlock = NewBlockLocked(sizeOfItem1, &err, (Ptr*)&tempP))
				{	CopyBlock(tempP, item1P, sizeOfItem1);		// save item1
					if NOT(err = DLM_ModifyObjExt(dlRef, objID1, dlRef, objID2, nil, 0, nil))
						err = DLM_ModifyObj(dlRef, objID2, VALUE(tempP), tempP->valueLogicLen, tempP->userData, nil, 0, nil);
					DisposeBlock(&tempBlock);
				}
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	#ifdef MEM_DEBUG
		DLM_CheckList(dlRef);
	#endif
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);

return err;
}

//===========================================================================================
XErr	DLM_DeleteObj(DLMRef dlRef, long objID, DLMLoopCallBack callBack, long param)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
XErr		err = noErr;
long		physicLength, newSize, *offsetP;
Boolean		global;
DLMRef		arrayDLRef = 0;

	if (dlRef)
	{	
	#ifdef MEM_DEBUG
		DLM_CheckList(dlRef);
	#endif
		if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_DeleteObj", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	offsetP = (long*)GetPtr(listP->offsetsBL);
			if (objID && (objID <= listP->totItems))
			{	itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
				if (itemP->flags & kLocked)
					err = XError(kXHelperError, DLM_Err_ObjectIsLocked);
				else
				{	if (itemP->flags & kIsArray)
					{	
						if (global)
							err = _NoDisposeOnGlobals();
						if not(err)
						{
							arrayDLRef = *(DLMRef*)VALUE(itemP);
							if (itemP->flags & kNoDestructor)
								err = DLM_Dispose(&arrayDLRef, nil, 0);
							else
								err = DLM_Dispose(&arrayDLRef, callBack, param);
						}
					}
					else if (NOT(itemP->flags & kNoDestructor) && callBack)
						err = callBack(dlRef, objID+1, itemP->flags, itemP->userData, param);
					if not(err)
					{
						physicLength = sizeof(DLMItem) - ITEM_MIN_SIZE + itemP->valuePhysicLen + itemP->namePaddedLen;
						CopyBlock(itemP, (Ptr)itemP + physicLength, listP->totPhysLen - (offsetP[objID] + physicLength));
						newSize = listP->totPhysLen - physicLength;
						if NOT(err = BufferSetLength(dlRef, newSize))
						{	listP = ((DLMRecP)GetPtr(listBlock));
							offsetP = (long*)GetPtr(listP->offsetsBL);
							LockBlock(listBlock);
							_DeleteOneOffset(listP->offsets, offsetP, listP->totItems, objID, physicLength);
							_DeleteOneIndex(listP->indexs, (long*)GetPtr(listP->indexsBL), listP->totItems, objID);
							UnlockBlock(listBlock);
							listP->totItems--;
							if (arrayDLRef)
								listP->totArrays--;
							listP->totPhysLen = newSize;
						}
						else
							CDebugStr("DLM_DeleteObj: BufferSetLength (shrinking) failed");
					}
				}
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	#ifdef MEM_DEBUG
		DLM_CheckList(dlRef);
	#endif
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
long	DLM_NewArray(DLMRef dlRef, char *name, long userData, unsigned short flags, /*unsigned long maxDim, */long arrayUserData, DLMRef *arrayDLRefP, XErr *errP)
{
XErr		err = noErr;
long		objID = -1, pos = 0, dir = 1;
Boolean		found, global;
DLMRecP		listP;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_NewArray", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	if (listP->acceptDuplicates)
				found = (_FindItemPos(listP, name, -1, &pos, &dir, nil)) >= 0;
			else
			{	found = (_FindItemPos(listP, name, 0, &pos, &dir, nil)) >= 0;
				if (found)
					err = XError(kXHelperError, DLM_Err_DuplicatedObject);
			}
			if NOT(err)
				err = _NewArray(dlRef, name, userData, flags, pos, dir, /*maxDim, */global, arrayUserData, &objID, arrayDLRefP);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
																					
if (errP)
	*errP = err;	
return objID;								
}

//===========================================================================================
XErr	DLM_SetArrayDim(DLMRef dlRef, long objID, long newDim, Boolean syncOnly, DLMLoopCallBack callBack, long param)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		oldDim, *offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	LockBlock(listBlock);
	offsetP = (long*)GetPtr(listP->offsetsBL);
	itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
	if NOT(itemP->flags & kIsArray)
		err = XError(kXHelperError, DLM_Err_ObjectIsNotArray);
	else
	{	if (syncOnly)
			_SyncArray(itemP);		//ex: err = _ExpandArray(itemP, newDim, true, 0, 0, nil, false, 0);
		else
		{	ArrayRecP	arrRecP = (ArrayRecP)VALUE(itemP);
		
			oldDim = arrRecP->arMaxDim;
			if (newDim < oldDim)
			{	if NOT(err = _RemoveItems(arrRecP->arDLRef, newDim+1, oldDim, callBack, param, true))
					arrRecP->arMaxDim = newDim;
			}
			else
			{	if (syncOnly)
					_SyncArray(itemP);
				else
					err = _ExpandArray(itemP, newDim, 0, 0, nil);
			}
		}
	}
	UnlockBlock(listBlock);
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
XErr	DLM_ResolveArrayElem(DLMRef dlRef, long objID, DLM_ArrayIndexRec *coords, short numCoords, short *lastResolvedP, Boolean toExpand, Boolean *expandedP, DLMRef *resultDlRefP, long *resultObjIDP, long *resultUserDataP, DLMRef elemToAddList, long elemToAddID, DLMBuffer *dlmbufferP, long arrayUserData, long *arrayElementClassIDP)
{
DLMRecP				listP;
BlockRef			blockToLock, listBlock;
DLMItemP			itemP;
long				maxDim, *indexP, *offsetP;
long				destObjID = 0;
unsigned short		flags;
XErr				err = noErr;
int					i;
Boolean				global;
DLMRef				destDLRef = 0;
ArrayRecP			arrRecP;

	if (expandedP)
		*expandedP = false;
	if (lastResolvedP)
		*lastResolvedP = 0;
	if NOT(err = DLM_GetInfo(dlRef, objID, &flags, nil, nil))
	{	i = 0;
		while ((flags & kIsArray) && (i++ < numCoords) && NOT(err))
		{	if (global = BufferGetUserBit(dlRef))
				_EnterCS();
			listBlock = GET_LIST_BLOCK(dlRef, listP);
			blockToLock = listBlock;
			offsetP = (long*)GetPtr(listP->offsetsBL);
			itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
			arrRecP = (ArrayRecP)VALUE(itemP);
			destDLRef = arrRecP->arDLRef;
			maxDim = arrRecP->arMaxDim;
			listBlock = GET_LIST_BLOCK(destDLRef, listP);
			if (resultUserDataP && (listP->arrayUserData > 0))
				*resultUserDataP = listP->arrayUserData;	// arrayUserData is the user data of all elements
			if (arrayElementClassIDP)
				*arrayElementClassIDP = listP->arrayUserData;
			destObjID = coords->ind;
			if NOT(destObjID)
			{	if (*coords->ind_name)
				{	long	res;
				
					// N.B. qui non si fila index, quindi gli array non possono avere "acceptDuplicates"
					if (listP->acceptDuplicates)
						err = XError(kXHelperError, DLM_Err_NoResolveOnDupList);
					else
					{	indexP = (long*)GetPtr(listP->indexsBL);
						if ((res = _FindItemPos(listP, coords->ind_name, 0, nil, nil, nil)) >= 0)
							destObjID = 1 + indexP[res];
						else
							err = XError(kXHelperError, DLM_Err_ObjectNotFound);
					}
				}
				else
					err = XError(kXHelperError, DLM_Err_InvalidArrayIndex);
			}
			if NOT(err)
			{	if (destObjID > maxDim)
				{	//Boolean		addArrays = false;
				
					if (toExpand)
					{	//addArrays = (i < numCoords);
						if (expandedP)
							*expandedP = true;
						LockBlock(blockToLock);
						if (i < numCoords)
							err = _UpgradeArray(itemP, destObjID, arrayUserData);
						else
							err = _ExpandArray(itemP, destObjID, elemToAddList, elemToAddID, dlmbufferP);
						UnlockBlock(blockToLock);
						if NOT(err)
							goto ok;
					}
					else
						err = XError(kXHelperError, DLM_Err_OutOfBoundary);
				}
				else if (destObjID <= 0)
					err = XError(kXHelperError, DLM_Err_ObjectNotFound);
				else
				{	
				ok:
					//coords->ind = 0;
					//*coords->ind_name = 0;
					coords++;		// aggiunto 10/11/2000 (ore 0:18) altrimenti non funziona nulla!!
					if (resultUserDataP)// ex (levato il 1/8/2001): && (listP->arrayUserData <= 0))
						err = DLM_GetInfo(destDLRef, destObjID, &flags, resultUserDataP, nil);
					else
						err = DLM_GetInfo(destDLRef, destObjID, &flags, nil, nil);
				}
				objID = destObjID;
				dlRef = destDLRef;
				if (NOT(err) && lastResolvedP)
					*lastResolvedP = i;
			}
			LockBlock(listBlock);
			if (global)
				_LeaveCS();
		}
		if (NOT(err) && (i < numCoords))
			err = XError(kXHelperError, DLM_Err_ObjectIsNotArray);

		if NOT(err)
		{	*resultDlRefP = destDLRef;
			*resultObjIDP = destObjID;
		}
	}
	
//out:
return err;
}

//===========================================================================================
Boolean	DLM_IsArray(DLMRef dlRef, long objID)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global, result = false;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID <= listP->totItems)
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);		// internally is 0-based
		result = (itemP->flags & kIsArray) != 0;
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();
	
return result;
}

//===========================================================================================
XErr	DLM_GetArrayInfo(DLMRef dlRef, long objID, unsigned short *flagsP, DLMRef *arrayDLRefP, long *arrayDimP, long *arrayUserDataP)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	offsetP = (long*)GetPtr(listP->offsetsBL);
	itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);
	if NOT(itemP->flags & kIsArray)
		err = XError(kXHelperError, DLM_Err_ObjectIsNotArray);
	else
	{	ArrayRecP arrRecP = (ArrayRecP)VALUE(itemP);

		if (flagsP)
			*flagsP = itemP->flags;
		if (arrayDLRefP)
			*arrayDLRefP = arrRecP->arDLRef;
		if (arrayDimP)
			*arrayDimP = arrRecP->arMaxDim;
		if (arrayUserDataP)
		{	listBlock = GET_LIST_BLOCK(arrRecP->arDLRef, listP);
			*arrayUserDataP = listP->arrayUserData;
		}
	}
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
XErr	DLM_SetArrayElemClass(DLMRef dlRef, long objID, long arrayUserData)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	offsetP = (long*)GetPtr(listP->offsetsBL);
	if (objID && (objID <= listP->totItems))
	{	itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);
		if NOT(itemP->flags & kIsArray)
			err = XError(kXHelperError, DLM_Err_ObjectIsNotArray);
		else
		{	ArrayRecP arrRecP = (ArrayRecP)VALUE(itemP);

			listBlock = GET_LIST_BLOCK(arrRecP->arDLRef, listP);
			if (listP->totItems)
				err = XError(kXHelperError, DLM_Err_IllegalOperation);
			else
				listP->arrayUserData = arrayUserData;
		}
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();
	
return err;
}

//===========================================================================================
XErr	DLM_UpdateArrayDLRef(DLMRef dlRef, long objID, DLMRef newArDlRef)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		*offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	offsetP = (long*)GetPtr(listP->offsetsBL);
	itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1]);
	if NOT(itemP->flags & kIsArray)
		err = XError(kXHelperError, DLM_Err_ObjectIsNotArray);
	else
		((ArrayRecP)VALUE(itemP))->arDLRef = newArDlRef;
	if (global)
		_LeaveCS();
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	DLM_AddToObj(DLMRef dlRef, long objID, Ptr pToAdd, long pToAddLen)
{
DLMRecP		listP;
BlockRef	listBlock;
DLMItemP	itemP;
long		dataLen, off, thisOffset, lenToMove, totItems, nextItemOff, diff, newPhysicLen, i, *offsetP;
Ptr			sourceP, destP;
XErr		err = noErr;
Boolean		moved, global;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_AddToObj", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	listP->dirty = true;
			if (objID && (objID <= listP->totItems))
			{	offsetP = (long*)GetPtr(listP->offsetsBL);
				itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
				if (itemP->flags & kIsArray)
					err = XError(kXHelperError, DLM_Err_InvalidArrayIndex);
				else if (itemP->flags & kCostant)
					err = XError(kXHelperError, DLM_Err_ObjectIsConstant);
				else if (itemP->flags & kLocked)
					err = XError(kXHelperError, DLM_Err_ObjectIsLocked);
				else
				{	dataLen = itemP->valueLogicLen + pToAddLen;
					if ((dataLen != itemP->valueLogicLen) && (itemP->flags & kFixedSize))
						err = XError(kXHelperError, DLM_Err_CantModifyLength);
					else
					{	// Calcolo la nuova physSize del singolo elemento
						if NOT(dataLen)
							newPhysicLen = ITEM_MIN_SIZE;			// diminuisco solo se len = 0
						else if (dataLen > itemP->valuePhysicLen)
							newPhysicLen = _PadLong(dataLen);
						else
							newPhysicLen = itemP->valuePhysicLen;
						diff = newPhysicLen - itemP->valuePhysicLen;
						if NOT(err = BufferCheck(dlRef, listP->totPhysLen + diff, &moved))
						{	if (moved)
							{	// reload all
								listP = ((DLMRecP)GetPtr(listBlock));
								offsetP = (long*)GetPtr(listP->offsetsBL);
								itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID]);
							}
							totItems = listP->totItems;
							if (objID < (totItems-1))
							{	offsetP = (long*)GetPtr(listP->offsetsBL);
								nextItemOff = offsetP[objID+1];
								sourceP = (Ptr)listP + nextItemOff;
								destP = sourceP + diff;
								lenToMove = listP->totPhysLen - nextItemOff;
								CopyBlock(destP, sourceP, lenToMove);
								thisOffset = offsetP[objID];
								for (i = objID+1, offsetP = &offsetP[objID+1]; i < totItems; i++, offsetP++)		// aggiorno tutti gli offsets successivi
								{	if ((off = *offsetP) > thisOffset)
										*offsetP = off + diff;
								}
							}
							CopyBlock(VALUE(itemP) + itemP->valueLogicLen, pToAdd, pToAddLen);
							listP->totPhysLen += diff;
							itemP->valueLogicLen = dataLen;
							itemP->valuePhysicLen = newPhysicLen;
						}
					}
				}
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
		
	
return err;
}

//===========================================================================================
XErr	DLM_ConcatObjs(DLMRef dlRef, long objID, DLMRef dlRef2, long objID2)
{
DLMRecP		listP, s_listP;
BlockRef	listBlock, s_listBlock;
DLMItemP	itemP, s_itemP;
long		*s_offsetP, dataLen, off, thisOffset, lenToMove, totItems, nextItemOff, diff, newPhysicLen, i, *offsetP;
Ptr			sourceP, destP;
XErr		err = noErr;
Boolean		moved, global;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_ConcatObjs", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
		{	listP->dirty = true;
			if (objID && (objID <= listP->totItems))
			{	offsetP = (long*)GetPtr(listP->offsetsBL);
				itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[--objID]);
				if (itemP->flags & kIsArray)
					err = XError(kXHelperError, DLM_Err_InvalidArrayIndex);
				else if (itemP->flags & kCostant)
					err = XError(kXHelperError, DLM_Err_ObjectIsConstant);
				else if (itemP->flags & kLocked)
					err = XError(kXHelperError, DLM_Err_ObjectIsLocked);
				else
				{	s_listBlock = GET_LIST_BLOCK(dlRef2, s_listP);
					s_offsetP = (long*)GetPtr(s_listP->offsetsBL);
					s_itemP = (DLMItemP)((Ptr)s_listP + ((long*)s_offsetP)[--objID2]);
					if (s_itemP->flags & kIsArray)
						err = XError(kXHelperError, DLM_Err_InvalidArrayIndex);
					else
					{	dataLen = itemP->valueLogicLen + s_itemP->valueLogicLen;
						if ((dataLen != itemP->valueLogicLen) && (itemP->flags & kFixedSize))
							err = XError(kXHelperError, DLM_Err_CantModifyLength);
						else
						{	// Calcolo la nuova physSize del singolo elemento
							if NOT(dataLen)
								newPhysicLen = ITEM_MIN_SIZE;			// diminuisco solo se len = 0
							else if (dataLen > itemP->valuePhysicLen)
								newPhysicLen = _PadLong(dataLen);
							else
								newPhysicLen = itemP->valuePhysicLen;
							diff = newPhysicLen - itemP->valuePhysicLen;
							if NOT(err = BufferCheck(dlRef, listP->totPhysLen + diff, &moved))
							{	if (moved)
								{	// reload all
									listP = ((DLMRecP)GetPtr(listBlock));
									offsetP = (long*)GetPtr(listP->offsetsBL);
									itemP = (DLMItemP)((Ptr)listP + ((long*)offsetP)[objID]);
								}
								totItems = listP->totItems;
								if (objID < (totItems-1))
								{	offsetP = (long*)GetPtr(listP->offsetsBL);
									nextItemOff = offsetP[objID+1];
									sourceP = (Ptr)listP + nextItemOff;
									destP = sourceP + diff;
									lenToMove = listP->totPhysLen - nextItemOff;
									CopyBlock(destP, sourceP, lenToMove);
									thisOffset = offsetP[objID];
									for (i = objID+1, offsetP = &offsetP[objID+1]; i < totItems; i++, offsetP++)		// aggiorno tutti gli offsets successivi
									{	if ((off = *offsetP) > thisOffset)
											*offsetP = off + diff;
									}
								}
							
							// s_itemP is moved? On Unix and Win can Move if come from the same list
							#ifndef __MEM_CANMOVE__
								if (dlRef == dlRef2);
							#endif
								{	s_listP = ((DLMRecP)GetPtr(s_listBlock));
									s_offsetP = (long*)GetPtr(s_listP->offsetsBL);
									s_itemP = (DLMItemP)((Ptr)s_listP + ((long*)s_offsetP)[objID2]);
								}
								CopyBlock(VALUE(itemP) + itemP->valueLogicLen, VALUE(s_itemP), s_itemP->valueLogicLen);
								listP->totPhysLen += diff;
								itemP->valueLogicLen = dataLen;
								itemP->valuePhysicLen = newPhysicLen;
							}
						}
					}
				}
			}
			else
				err = XError(kXHelperError, DLM_Err_ObjectNotFound);
		}
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
		
	
return err;
}															

//===========================================================================================
XErr	DLM_CopyObj(DLMRef sourceList, long sourceObjID, DLMRef destList, char *destName, unsigned short destObjectFinalFlags, long *destId)
{
	return _CopyObject(sourceList, sourceObjID, destList, destName, destObjectFinalFlags, destId, true, 0);
}

//===========================================================================================
XErr	DLM_InsertObj(DLMRef sourceList, long sourceObjID, DLMRef destList, char *destName, unsigned short destObjectFinalFlags, long *destId, long pos)
{
	return _CopyObject(sourceList, sourceObjID, destList, destName, destObjectFinalFlags, destId, true, pos);
}

//===========================================================================================
XErr	DLM_GetTotObjs(DLMRef dlRef, long *totObjsP, Boolean filterUserData)
{
DLMRecP		listP;
BlockRef	offsetBlock, listBlock;
XErr		err = noErr;
Boolean		global;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		listBlock = GET_LIST_BLOCK(dlRef, listP);
		if (filterUserData)
		{	long		i, noUserData, totObjs, *offsetP;
			DLMItemP	itemP;
			
			totObjs = listP->totItems;
			offsetBlock = listP->offsetsBL;	
			offsetP = (long*)GetPtr(offsetBlock);
			noUserData = 0;
			for (i = 0; (i < totObjs); i++, offsetP++)
			{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
				if NOT(itemP->userData)
					noUserData++;
			}
			*totObjsP = totObjs - noUserData;
		}
		else
			*totObjsP = listP->totItems;
		if (global)
			_LeaveCS();
	}
	else
		err = XError(kXHelperError, DLM_Err_InvalidListRef);
	
return err;
}

//===========================================================================================
XErr	DLM_GetIndObj(DLMRef dlRef, long index, Ptr	dataP, long *dataLenP, long offset, long *userDataP, 
											long *objIDP, char *name, Boolean sorted, Boolean filterUserData)
{
XErr	err = noErr;

	err = _GetObj(dlRef, index, dataP, dataLenP, offset, userDataP, name, objIDP, sorted, filterUserData);

return err;
}

//===========================================================================================
XErr	DLM_SetListUserData(DLMRef dlRef, Byte *listUserData)
{
DLMRecP		listP;
XErr		err = noErr;
Boolean		global;

	if (dlRef)
	{	if (global = BufferGetUserBit(dlRef))
			_EnterCS();
		GET_LIST_BLOCK(dlRef, listP);
		if (listP->locked)
			err = _DebugErrListLocked("DLM_SetListUserData", XError(kXHelperError, DLM_Err_ListIsLocked));
		else
			CopyBlock(listP->listUserData, listUserData, LIST_USER_DATA_DIM);
		if (global)
			_LeaveCS();
	}

return err;
}
/*
//===========================================================================================
XErr	DLM_SetListByteUserData(DLMRef dlRef, Boolean byte_userData)
{
DLMRecP		listP;
XErr		err = noErr;
Boolean		global;

	if (dlRef)
	{	GET_LIST_BLOCK(dlRef, listP);
		if (global = listP->global)
			_EnterCS();
		listP->byte_userData = byte_userData;
		if (global)
			_LeaveCS();
	}

return err;
}

//===========================================================================================
XErr	DLM_GetListUserData(DLMRef dlRef, unsigned long *luDataP, Boolean *byte_userDataP)
{
DLMRecP		listP;
XErr		err = noErr;
Boolean		global;

	if (dlRef)
	{	GET_LIST_BLOCK(dlRef, listP);
		if (global = listP->global)
			_EnterCS();
		if (luDataP)
			*luDataP = listP->luData;
		if (byte_userDataP)
			*byte_userDataP = listP->byte_userData;
		if (global)
			_LeaveCS();
	}

return err;
}
*/

//===========================================================================================
XErr	_DMLLoop(DLMRef dlRef, DLMLoopCallBack callBack, long param, Boolean insideArrays, Boolean checkNoDestructor, long *idErrP)
{
register int	i, totItems;
long			*offsetP;
DLMItemP 		itemP;
DLMRef			arrayDLRef;
XErr			err = noErr;	//, tErr = noErr;
BlockRef		listBlock, offsetBlock;
DLMRecP			listP;
Boolean			global;

	if (dlRef)
	{	//_DLM_Debug("Looping", dlRef);
		if (callBack)
		{	if (global = BufferGetUserBit(dlRef))
				_EnterCS();
			listBlock = GET_LIST_BLOCK(dlRef, listP);
			LockBlock(listBlock);
			offsetBlock = listP->offsetsBL;	
			LockBlock(offsetBlock);
			offsetP = (long*)GetPtr(offsetBlock);
			totItems = listP->totItems;
			for (i = 0; ((i < totItems) && NOT(err)); i++, offsetP++)
			{	itemP = (DLMItemP)((Ptr)listP + *offsetP);
				if ((itemP->flags & kIsArray) && insideArrays && (callBack && (NOT(checkNoDestructor) || NOT(itemP->flags & kNoDestructor))))
				{	arrayDLRef = *(DLMRef*)VALUE(itemP);
					err = DLM_Loop(arrayDLRef, callBack, param, insideArrays, checkNoDestructor);
				}
				else if (callBack && (NOT(checkNoDestructor) || NOT(itemP->flags & kNoDestructor)))
					err = callBack(dlRef, i+1, itemP->flags, itemP->userData, param);
				//if (tErr && NOT(err))
				//	err = tErr;
			}
			if (err && idErrP)
				*idErrP = i;
			/*if NOT(err)
			{	if (alsoOnSuper && listP->superList)
					err = DLM_Loop(listP->superList, callBack, param, insideArrays, checkNoDestructor, alsoOnSuper);
			}*/
			UnlockBlock(offsetBlock);
			UnlockBlock(listBlock);
			if (global)
				_LeaveCS();
		}
	}
	else
		CDebugStr("DLM is null");

return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	DLM_IncrementLong(DLMRef dlRef, long objID, Boolean toDecr)
{
DLMRecP		listP;
BlockRef	listBlock;
long		*longP, *offsetP;
XErr		err = noErr;
Boolean		global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		longP = (long*)VALUE(((DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1])));
		if (toDecr)
			(*longP)--;
		else
			(*longP)++;
		listP->dirty = true;
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();

return err;
}

//===========================================================================================
XErr	DLM_IncrementUnsigned(DLMRef dlRef, long objID, Boolean toDecr)
{
DLMRecP			listP;
BlockRef		listBlock;
unsigned long	*ulongP;
long			*offsetP;
XErr			err = noErr;
Boolean			global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		ulongP = (unsigned long*)VALUE(((DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1])));
		if (toDecr)
			(*ulongP)--;
		else
			(*ulongP)++;
		listP->dirty = true;
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();

return err;
}

//===========================================================================================
XErr	DLM_IncrementDouble(DLMRef dlRef, long objID, Boolean toDecr)
{
DLMRecP			listP;
BlockRef		listBlock;
double			*doubleP;
long			*offsetP;
XErr			err = noErr;
Boolean			global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		doubleP = (double*)VALUE(((DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1])));
		if (toDecr)
			(*doubleP)--;
		else
			(*doubleP)++;
		listP->dirty = true;
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();

return err;
}

//===========================================================================================
XErr	DLM_IncrementLongLong(DLMRef dlRef, long objID, Boolean toDecr)
{
DLMRecP			listP;
BlockRef		listBlock;
LONGLONG		*llongP;
long			*offsetP;
XErr			err = noErr;
Boolean			global;

	if (global = BufferGetUserBit(dlRef))
		_EnterCS();
	listBlock = GET_LIST_BLOCK(dlRef, listP);
	if (objID && (objID <= listP->totItems))
	{	offsetP = (long*)GetPtr(listP->offsetsBL);
		llongP = (LONGLONG*)VALUE(((DLMItemP)((Ptr)listP + ((long*)offsetP)[objID-1])));
		if (toDecr)
			(*llongP)--;
		else
			(*llongP)++;
		listP->dirty = true;
	}
	else
		err = XError(kXHelperError, DLM_Err_ObjectNotFound);
	if (global)
		_LeaveCS();

return err;
}
