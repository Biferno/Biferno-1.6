/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Pool.c,v 1.5 2005-11-07 16:10:31 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"
//#include	"Helpers.h"

#include "SlotMgr.h"

#ifndef __XLIB_CLIENT__

#ifdef __XLIB_CLIENT__
	#include "XAsSharedLib.h"
	extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
#else
	/*typedef struct {
					BlockRef		theBlock;				// this is a pointer (always locked)
					Ptr				theBasePointer;
					Boolean			*slotControllerP;
					BlockRef		slotControllerBlock;
					unsigned long	slotCnt;
					unsigned long	usedSlotCnt;
					unsigned long	slotSize;
					unsigned long	firstFreeSlot;
					BlockRef		refOfThisBlock;
					} PoolRecord, *PoolRecordP;

	#define	UNDEFINED_SLOT	0xFFFFFFFF
	*/
#endif

//#define	WHILE_DEBUGGING_NO_POOL	1

#define	BIFERNO_POOL_FULL	"BIFERNO_POOL_IS_FULL"

//static	Boolean		gPoolFullFileCreated = false;

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*static	void	_CheckPoolFullFile(void)	
{
XFilePath	filePath;
XErr		err = noErr;

	XGetApplicationFolderPath(filePath);
	CAddStr(filePath, BIFERNO_POOL_FULL);
	if NOT(CheckPath(filePath, false))
		DeleteXFile(filePath);
}

//===========================================================================================
static	void	_PoolFullFile(void)	
{
XFilePath	filePath;
XFileRef	xrefNum;
XErr		err = noErr;

	if NOT(gPoolFullFileCreated)
	{	XGetApplicationFolderPath(filePath);
		CAddStr(filePath, BIFERNO_POOL_FULL);
		if NOT(err = OpenXFile(filePath, CREATE_FILE_ALWAYS, READ_PERM, false, &xrefNum))
			CloseXFile(&xrefNum);
		gPoolFullFileCreated = true;
	}
}
*/
//===========================================================================================
void	Pool_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{
		xlibCallBacksRecPtr->NewPool = (long)NewPool;
		xlibCallBacksRecPtr->DeletePool = (long)DeletePool;
		xlibCallBacksRecPtr->PoolNewPtr = (long)PoolNewPtr;
		xlibCallBacksRecPtr->PoolDisposePtr = (long)PoolDisposePtr;
}

//===========================================================================================
XErr	NewPool(unsigned long slotSize, unsigned long slotCount, PoolRef *poolRef)
{
XErr			err = noErr;
//BlockRef		pullBlock;
//PoolRecordP		pullPtr;

	err = NewSlotMgrBlock(slotSize, slotCount, poolRef);
	
	/*XThreadsEnterCriticalSection();
	_CheckPoolFullFile();
	if (pullBlock = NewBlock(sizeof(PoolRecord), &err))
	{	LockBlock(pullBlock);
		pullPtr = (PoolRecordP)GetPtr(pullBlock);
		if (pullPtr->theBlock = NewPtrBlock(slotSize * slotCount, &err))
		{	pullPtr->theBasePointer = GetPtr(pullPtr->theBlock);
			pullPtr->slotCnt = slotCount;
			pullPtr->usedSlotCnt = 0;
			pullPtr->slotSize = slotSize;
			pullPtr->firstFreeSlot = 0;
			pullPtr->refOfThisBlock = pullBlock;
			if (pullPtr->slotControllerBlock = NewPtrBlock(sizeof(Boolean) * slotCount, &err))
			{	pullPtr->slotControllerP = (Boolean*)GetPtr(pullPtr->slotControllerBlock);
				ClearBlock(pullPtr->slotControllerP, sizeof(Boolean) * slotCount);
				*poolRef = (long)pullPtr;
			}
			else
			{	DisposeBlock(&pullPtr->theBlock);
				DisposeBlock(&pullBlock);
			}
		}
		else
			DisposeBlock(&pullBlock);
	}
	XThreadsLeaveCriticalSection();*/

return err;
}

//===========================================================================================
XErr	DeletePool(PoolRef poolRef)
{
XErr			err = noErr;

	err = DisposeSlotMgrBlock(&poolRef);
	
/*
PoolRecordP		pullPtr;
BlockRef		blockToDispose;

	XThreadsEnterCriticalSection();
	pullPtr = (PoolRecordP)poolRef;
	LockBlock(pullPtr->refOfThisBlock);
	LockBlock(pullPtr->slotControllerBlock);
	DisposeBlock(&pullPtr->theBlock);
	DisposeBlock(&pullPtr->slotControllerBlock);
	blockToDispose = pullPtr->refOfThisBlock;
	pullPtr->refOfThisBlock = 0;
	DisposeBlock(&blockToDispose);
	XThreadsLeaveCriticalSection();
*/

return err;
}

//===========================================================================================
XErr	PoolNewPtr(PoolRef poolRef, Ptr *resultPtrP, uint32_t *slotP)
{
XErr			err = noErr;
//PoolRecordP		pullPtr;
//Ptr				resultP = nil;
//long			slotSize, slot, i;
//Boolean			*slotControllerP;
	
	err = NewSlotElem(poolRef, slotP, (Ptr*)resultPtrP, 0);
/*
	XThreadsEnterCriticalSection();
	pullPtr = (PoolRecordP)poolRef;
	if (pullPtr->usedSlotCnt == pullPtr->slotCnt)				// sorry, not enough space!
	{	_PoolFullFile();
		slotSize = pullPtr->slotSize;
		*slotP = -1;
		if (*blockP = NewPtrBlock(slotSize, &err))
			resultP = GetPtr(*blockP);
	}
	else
	{	
	#ifdef WHILE_DEBUGGING_NO_POOL		
		slotControllerP = &pullPtr->slotControllerP[0];
		i = 0;
		while (*slotControllerP)
		{	slotControllerP++;
			i++;
		}
		*slotP = slot = i;
	#else
		*slotP = slot = pullPtr->firstFreeSlot;
		slotControllerP = &pullPtr->slotControllerP[slot];
	#endif
		resultP = pullPtr->theBasePointer + (slot * pullPtr->slotSize);
		*blockP = 0;
		pullPtr->usedSlotCnt++;
		*slotControllerP = true;
	#ifndef WHILE_DEBUGGING_NO_POOL
		slotControllerP = &pullPtr->slotControllerP[slot];
		if (pullPtr->usedSlotCnt < pullPtr->slotCnt)
			{
			i = slot;
			do	{
				slotControllerP++;
				i++;
				} while (*slotControllerP);
			pullPtr->firstFreeSlot = i;
			}
		else
			{
			pullPtr->firstFreeSlot = UNDEFINED_SLOT;
			}
	#endif
	}
	XThreadsLeaveCriticalSection();

if NOT(err)
	*resultPtrP = resultP;
*/
return err;
}

//===========================================================================================
void	PoolDisposePtr(PoolRef poolRef, uint32_t slot)
{
//PoolRecordP		pullPtr;
XErr	err = noErr;

	err = FreeSlotElem(poolRef, &slot, nil, 0);
	
	/*
	XThreadsEnterCriticalSection();
	pullPtr = (PoolRecordP)poolRef;
	if (block)
		DisposeBlock(&block);
	else
	{	Boolean	*boolP;
	
		boolP = &pullPtr->slotControllerP[slot];
		if (*boolP)
		{	*boolP = false;				// free
		#ifndef WHILE_DEBUGGING_NO_POOL
			if (slot < pullPtr->firstFreeSlot)
				pullPtr->firstFreeSlot = slot;
		#endif
			pullPtr->usedSlotCnt--;
		}
		else
			CDebugStr("PoolDisposePtr: AttemptToFreeTwice");
	}
	XThreadsLeaveCriticalSection();
	*/
}
#else
#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif
extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
//===========================================================================================
XErr	NewPool(unsigned long slotSize, unsigned long slotCount, PoolRef *poolRef)
{
XErr	(*p)(unsigned long slotSize, unsigned long slotCount, PoolRef *poolRef) = (void*)gXLibCallBacksRecPtr->NewPool;

	return p(slotSize, slotCount, poolRef);
}

//===========================================================================================
XErr	DeletePool(PoolRef poolRef)
{
XErr	(*p)(PoolRef poolRef) = (void*)gXLibCallBacksRecPtr->DeletePool;

	return p(poolRef);
}

//===========================================================================================
XErr	PoolNewPtr(PoolRef poolRef, Ptr *resultPtrP, uint32_t *slotP)
{
XErr	(*p)(PoolRef poolRef, Ptr *resultPtrP, uint32_t *slotP) = (void*)gXLibCallBacksRecPtr->PoolNewPtr;

	return p(poolRef, resultPtrP, slotP);
}

//===========================================================================================
void	PoolDisposePtr(PoolRef poolRef, uint32_t slot)
{
void	(*p)(PoolRef poolRef, uint32_t slot) = (void*)gXLibCallBacksRecPtr->PoolDisposePtr;

	p(poolRef, slot);
}
#if __MWERKS__
#pragma export off
#endif
#endif


