/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: MacLog.c,v 1.2 2003-06-23 12:39:44 valfer Exp $
	|______________________________________________________________________________
*/
/*
	File:		Log.c

	Contains:	Sistema di log

	Written by:	Valerio Ferrucci

	Copyright:	Copyright � Tabasoft 1998
	
*/

#include "XLib.h"
//#include "MacLog.h"

#if !TARGET_API_MAC_CARBON
	#include <ControlDefinitions.h>
#endif

static	WindowPtr 	gStatusWindow;
static	RgnHandle	clipRgn;
static	Rect		gPicRect;
static	RGBColor	gsBlack = {0, 0, 0};

#define	MAX_MENU		12
#define	MAX_MENU_ITEMS	12

typedef struct {
				MenuHandle			menuH;
				long				totProcessFunc;
				MacLogProcessFunc 	processFunc[MAX_MENU_ITEMS];
				Boolean				toCheck[MAX_MENU_ITEMS];
				} MenuRec, *MenuRecP;


static	MenuRec		gMenuH[MAX_MENU];
static	long		gTotMenus = 0;

#define TOOLBAR_HEIGHT		52
#define SCROLLBAR_WITDH		15
#define	MAX_STR_LOG		512
#define	LINE_HEIGHT		14
#define	BOTTOM_MARGIN		4
#define	MONACO_WIDTH		6	// larghezza in pix di un carattere in monaco
#define POST_PICT		72
#define	pageStep		10	// 10 linee
#define	clickStep		1	// 1 linea

typedef struct {
				Str255				str;
				RGBColor			color;
				} StringLine;
				
typedef struct {
				long				strCount;			// stringhe totali
				long				strIdx;				// la stringa numero uno (nel loop)
				long				strTop;				// la prima stringa nella window (0 - based)
				long				horCharPos;			// primo carattere visibile (in hor)
				WindowPtr			wind;
				ControlHandle		statusVScroll;
				ControlHandle		statusHScroll;
				RgnHandle			dummyRgn;
				RgnHandle			statusDummyRgn;
				Str255				statusOptionalStr;
				PicHandle			hPic;
				BlockRef			block;
				StringLine			strLine[MAX_STR_LOG];
				} StatusRef, *StatusRefP;

static	RGBColor	mymidGray, myBlack;

//===========================================================================================
static void	CSetColor(RGBColor *colorP, long red, long green, long blue)
{
	colorP->red = red;
	colorP->green = green;
	colorP->blue = blue;
}

//===========================================================================================
static long	CCreateWindow(long hInstance, long iCmdShow, Rect *rectP)
{
#pragma unused(hInstance,iCmdShow)
WindowPtr  	win;
//Rect		rBounds = {44, 8, 266+44, 445+4};

	win = NewCWindow(nil, rectP, "\p", true, 0, (WindowPtr)-1L, true, 0);

return (long)win;
}

//===========================================================================================
static void	CGetPortRect(WindowPtr wind, Rect *rectP)
{
#if TARGET_API_MAC_CARBON
	GetPortBounds(GetWindowPort(wind), rectP);
	// GetWindowPortBounds(wind, rectP);//wind->portRect;
#else
	*rectP = wind->portRect;
#endif
}

//===========================================================================================
static Boolean	CIsWindowVisible(WindowPtr wind)
{
	return IsWindowVisible(wind);//((WindowPeek)wind)->visible;
}

//===========================================================================================
static void	DrawAbout(WindowPtr wind)
{
RGBColor	saveColor;
Rect		tRect;

	CGetPortRect(wind, &tRect);
	GetBackColor(&saveColor);
	RGBBackColor(&mymidGray);
	tRect.bottom = tRect.top + TOOLBAR_HEIGHT;
	tRect.right = POST_PICT;
	EraseRect(&tRect);
	RGBBackColor(&saveColor);
}

//===========================================================================================
static void DrawClippedGrowIcon(WindowPtr Wind, Rect *portRectP)
{
Rect		TempRect;
StatusRefP	refPtr;

	TempRect.bottom = portRectP->bottom;
	TempRect.right = portRectP->right;
	TempRect.top = TempRect.bottom - SCROLLBAR_WITDH;
	TempRect.left = TempRect.right - SCROLLBAR_WITDH;

	refPtr = (StatusRefP)GetWRefCon(Wind);
	GetClip(refPtr->dummyRgn);
	ClipRect(&TempRect);
	DrawGrowIcon(Wind);
	SetClip(refPtr->dummyRgn);
}

//===========================================================================================
static void	SetPortExt(WindowPtr theWind)
{
	#if TARGET_API_MAC_CARBON
		SetPort(GetWindowPort(theWind));
	#else
		SetPort(theWind);
	#endif
}	

//===========================================================================================
static void	GetPortExt(WindowPtr *theWindP)
{
	#if TARGET_API_MAC_CARBON
	{
        WindowPtr	front;
        
                front = FrontWindow();
                // *theWindP = GetWindowPort(front);
				*theWindP = front;
	}
	#else
		GetPort(theWindP);
	#endif
}	

//===========================================================================================
/*static void	TheActiveStatusWindow(WindowPtr theWind, Boolean toActivate)
{
	if (theWind == gStatusWindow)
	{	if (toActivate)
			SetPortExt(theWind);
	}
}*/

//===========================================================================================
static void GetStatusDrawableRect(WindowPtr statusWindow, Rect *drawRectP)
{
Rect	portRect;

	CGetPortRect(statusWindow, &portRect);
	drawRectP->top = TOOLBAR_HEIGHT + 2;

	drawRectP->bottom = portRect.bottom - SCROLLBAR_WITDH;

	drawRectP->left = 0;
	drawRectP->right = portRect.right - SCROLLBAR_WITDH;
}

//===========================================================================================
static void DrawStatusWind(WindowPtr statusWindow, RgnHandle clipRgnH)
{
register StatusRefP		refPtr;
register int			k, pos, bottomLimit, i, lineCnt;
Rect					clipR;
Rect					portRect;
RGBColor				saveColor;
StringLine				*strLineP;

	CGetPortRect(statusWindow, &portRect);

	refPtr = (StatusRefP)GetWRefCon(statusWindow);
	lineCnt = refPtr->strCount;
	pos = TOOLBAR_HEIGHT;
	bottomLimit = portRect.bottom - BOTTOM_MARGIN - LINE_HEIGHT - SCROLLBAR_WITDH;

	GetStatusDrawableRect(statusWindow, &clipR);
	GetClip(refPtr->dummyRgn);
	if (clipRgnH)
		SetClip(clipRgnH);
	else
		ClipRect(&clipR);

	EraseRect(&clipR);

	i = refPtr->strIdx + refPtr->strTop;
	if (i >= MAX_STR_LOG)
		i = i - MAX_STR_LOG;
	
	for (k = 0; k < (lineCnt - refPtr->strTop); k++, strLineP++)
	{	strLineP = &refPtr->strLine[i];
		pos += LINE_HEIGHT;
		MoveTo(4, pos);
		
		GetForeColor(&saveColor);
		RGBForeColor(&strLineP->color);
		if (refPtr->horCharPos)
		{	Str255	tStr;
			Byte	len;
		
			len = strLineP->str[0];
			if (len > refPtr->horCharPos)
			{	tStr[0] = len - refPtr->horCharPos;
				CopyBlock(&tStr[1], &strLineP->str[refPtr->horCharPos+1], tStr[0]);
				DrawString(tStr);
			}
		}
		else
			DrawString(strLineP->str);
		RGBForeColor(&saveColor);
		if (i < (MAX_STR_LOG-1))
			i++;
		else
			i=0;
		if (pos > bottomLimit)
			break;
	}
		
	SetClip(refPtr->dummyRgn);
}

//===========================================================================================
static void	DrawToolBar(Rect *portRectP)
{
RGBColor		saveColor;

	GetBackColor(&saveColor);
	RGBBackColor(&mymidGray);
	portRectP->bottom = portRectP->top + TOOLBAR_HEIGHT;
	RGBForeColor(&myBlack);
	PenSize(2,2);
	MoveTo(portRectP->left, TOOLBAR_HEIGHT);
	LineTo(portRectP->right, TOOLBAR_HEIGHT);
	portRectP->left = POST_PICT;
	EraseRect(portRectP);
	RGBBackColor(&saveColor);
	PenSize(1,1);
}

//===========================================================================================
static void	DrawOptionalString(StringPtr optString)
{
	MoveTo(POST_PICT, LINE_HEIGHT);
	TextFace(bold);
	DrawString(optString);
	TextFace(normal);
}

//===========================================================================================
static void	DrawCString(char *str)
{
Str255 pStr;

	CToPascal(str, pStr);
	DrawString(pStr);
}

//===========================================================================================
static void	DrawInfo(void)
{
CStr255		str;
Str255		aStr;
long		freeAppMem, freeTmpMem;

#define bNeeded	0x7FFFFFFF

	PurgeMem(bNeeded);
	CompactMem(bNeeded);
	freeAppMem = FreeMem();
	freeTmpMem = TempFreeMem();
	freeAppMem = freeAppMem / 1024;
	freeTmpMem = freeTmpMem / 1024;
	
	//AppMem
	NumToString(freeAppMem, aStr);
	CEquStr(str, "Application Mem: ");
	AddPascalToCStr(str, aStr);
	CAddStr(str, " K");
	MoveTo(POST_PICT, (LINE_HEIGHT * 2));
	DrawCString(str);
	
	//TempMem
	NumToString(freeTmpMem, aStr);
	CEquStr(str, "Temp Mem: ");
	AddPascalToCStr(str, aStr);
	CAddStr(str, " K");
	MoveTo(POST_PICT, (LINE_HEIGHT * 3));
	DrawCString(str);
}


//===========================================================================================
static void TheUpdateStatusWindow(WindowPtr wind, long unused, long unused2)
{
#pragma unused(unused, unused2)
Rect					portRect;
register StatusRefP		refPtr;
RgnHandle				winRgn;

	if (wind == gStatusWindow)
	{	CGetPortRect(wind, &portRect);
		ClipRect(&portRect);
		EraseRect(&portRect);
		refPtr = (StatusRefP)GetWRefCon(wind);
		DrawClippedGrowIcon(wind, &portRect);
	#if TARGET_API_MAC_CARBON	
		winRgn = NewRgn();
		GetWindowRegion(wind, kWindowContentRgn, winRgn);
	#else
		winRgn = wind->visRgn;
	#endif
		UpdateControls(wind, winRgn);
	#if TARGET_API_MAC_CARBON	
		DisposeRgn(winRgn);
	#endif
		DrawToolBar(&portRect);
		DrawStatusWind(wind, nil);
		DrawAbout(wind);
		if (refPtr->statusOptionalStr[0])
			DrawOptionalString(refPtr->statusOptionalStr);
		if (refPtr->hPic)
			DrawPicture(refPtr->hPic, &gPicRect);
		DrawInfo();
		
	}
}

//===========================================================================================
static void StatusAutoScroll(WindowPtr statusWindow, StatusRefP refPtr)
{
register int	strInWindow, diff, actTop, lastAdded;
Rect			portRect;

	CGetPortRect(statusWindow, &portRect);
	actTop = refPtr->strTop;
	lastAdded = refPtr->strCount;
	// -1 otherwise you don't see the last row (bug fixed)
	strInWindow = ((portRect.bottom - TOOLBAR_HEIGHT - 1 - SCROLLBAR_WITDH) / LINE_HEIGHT) - 1;
	diff = (lastAdded - actTop) - strInWindow;
	if (diff > 0)
	{	Rect aRect;
	
		refPtr->strTop += diff;
		GetStatusDrawableRect(statusWindow, &aRect);
	#if TARGET_API_MAC_CARBON
		InvalWindowRect(statusWindow, &aRect);
	#else
		InvalRect(&aRect);
	#endif
	}
}
//===========================================================================================
static void	AdjustStatusScroll(WindowPtr statusWindow, StatusRefP refPtr)
{
register int	vLines, lineCnt, 
				windDim, toScroll;
Rect			portRect;

	CGetPortRect(statusWindow, &portRect);

lineCnt = refPtr->strCount;

windDim = (portRect.bottom - TOOLBAR_HEIGHT - BOTTOM_MARGIN - SCROLLBAR_WITDH) / LINE_HEIGHT;
vLines = lineCnt;

	// Setto i massimi a quanto c'� ancora da scrollare ...	
	toScroll = vLines - windDim;
	if (toScroll <= 0) 
		toScroll = 0;
	SetControlMaximum(refPtr->statusVScroll, toScroll);
	
	// ... e i valori all'attuale firstLine
	SetControlValue(refPtr->statusVScroll, refPtr->strTop);
	
	//Barra orizzontale
	windDim = (portRect.right - SCROLLBAR_WITDH) / MONACO_WIDTH;
	toScroll = 255 - windDim;
	if (toScroll <= 0) 
		toScroll = 0;
	SetControlMaximum(refPtr->statusHScroll, toScroll);
	SetControlValue(refPtr->statusHScroll, refPtr->horCharPos);
}

#define	TAB_SPACE	4

//===========================================================================================
static XErr AddStatusMessage(WindowPtr statusWindow, StringPtr str, Boolean addToLast, RGBColor *color)
{
register StatusRefP	refPtr;
register int		pos, lineCnt, len;
//XErr				err = 0;
WindowPtr			oldPort;
Str255				finalStr;
Byte				*finalP, *strP = str, *finalStrP = finalStr+1;
int					j, finLen = 0, mod, i;

if (len = *strP++)
{	i = 0;
	finLen = len;
	do {
		if (*strP == '\t')
		{	mod = TAB_SPACE - (i % TAB_SPACE);
			for (j = 0; j < mod; j++)
				*finalStrP++ = ' ';
			finLen += mod-1;
			strP++;
			len--;
			i += mod;
		}
		else
		{	*finalStrP++ = *strP++;
			len--;
			i++;
		}
	} while (len > 0);
}

if (finLen < MAC_LOG_MAX_LINE_SIZE)
{	*finalStr = finLen;
	finalP = finalStr;
}
else
	finalP = str;
	
refPtr = (StatusRefP)GetWRefCon(statusWindow);
lineCnt = refPtr->strCount;
if (addToLast)
{
Byte	*strP;
int		aLong, totLen;

	if (refPtr->strIdx)
		pos = refPtr->strIdx - 1;
	else
		pos = lineCnt - 1;
	strP = refPtr->strLine[pos].str;
	totLen = *strP + *finalP;
	if (totLen < MAC_LOG_MAX_LINE_SIZE)
		PAddStr(strP, finalP);
	else
	{	aLong = MAC_LOG_MAX_LINE_SIZE - *strP - 4;
		if (aLong > 0)
		{	*finalP = aLong;
			PAddStr(strP, finalP);
			PAddStr(strP, "\p...");
		}
	}
}
else
{
	if (lineCnt == MAX_STR_LOG)
	{	if (refPtr->strIdx < (MAX_STR_LOG-1))
			refPtr->strIdx++;
		else
			refPtr->strIdx = 0;
	}
	else
		refPtr->strCount++;

	if (refPtr->strIdx)
		pos = refPtr->strIdx - 1;
	else
	{	if (lineCnt < MAX_STR_LOG)
			pos = lineCnt;
		else
			pos = lineCnt - 1;
	}
	PEquStr(refPtr->strLine[pos].str, finalP);
	if (color)
		refPtr->strLine[pos].color = *color;
	else
		refPtr->strLine[pos].color = gsBlack;
}

if (CIsWindowVisible(statusWindow))
{	GetPortExt(&oldPort);
	SetPortExt(statusWindow);
	StatusAutoScroll(statusWindow, refPtr);
	AdjustStatusScroll(statusWindow, refPtr);
	DrawStatusWind(statusWindow, nil);
	SetPortExt(oldPort);
}

return 0;
}

//===========================================================================================
static pascal void ScrollStrings(ControlHandle CHand, short pCode)
{
register short	Val, Max;
int				initVal, dx, dy;
Rect			scrlRect, updtRect;
Boolean			isVertBar = false;
short			textWidth, textHeight, windowHigh;
StatusRefP		refPtr;
Rect			clipR, portRect;

if NOT(pCode)
	return;
	
refPtr = (StatusRefP)GetControlReference(CHand);

// Dimensioni immagine e window
textWidth = 0;
textHeight = refPtr->strCount; 

CGetPortRect(refPtr->wind, &portRect);
windowHigh  = (portRect.bottom - BOTTOM_MARGIN - SCROLLBAR_WITDH - TOOLBAR_HEIGHT) / LINE_HEIGHT; 	

// verticale o orizzontale?
if (refPtr->statusVScroll == CHand) 
	isVertBar = true;

// se non c'� da scrollare nulla
if (isVertBar && (textHeight < windowHigh))
	return;


// il valore iniziale � quello a cui avevo settato hPos (o vPos)
Max = GetControlMaximum(CHand);
if (isVertBar)
	Val = refPtr->strTop; 
else
	Val = refPtr->horCharPos;
initVal = Val;

// incremento Val a seconda di dove l'utente ha clickato (pCode)
switch(pCode)
{	case kControlUpButtonPart:
		if (Val <= 0) 
			return;
		else 
		{	Val -= clickStep;
			if(Val < 0) Val = 0;
		}
		break;
		
	case kControlDownButtonPart:
		if (Val >= Max)
			return;
		else
		{	Val += clickStep;
			if(Val > Max) Val = Max;
		}
		break;
		
	case kControlPageUpPart:
		if (Val <= 0) 
			return;
		else
		{	Val -= pageStep;
			if(Val < 0) Val = 0;
		}
		break;
		
	case kControlPageDownPart:
		if (Val >= Max) 
			return;
		else
		{	Val += pageStep;
			if(Val > Max) Val = Max;
		}
		break;
}

// setto Control e Pos al nuovo valore di Val
SetControlValue(CHand, Val);
if (isVertBar)
	refPtr->strTop = Val;
else
	refPtr->horCharPos = Val;

// calcolo il rettangolo da scrollare
scrlRect = portRect;
scrlRect.top += TOOLBAR_HEIGHT + 2;
scrlRect.bottom -= (SCROLLBAR_WITDH + BOTTOM_MARGIN); 
scrlRect.right -= SCROLLBAR_WITDH;

// Eseguo lo scroll del rettangolo (ora scrlRect � tutto il portRect)
if (isVertBar)
{	dx = 0;
	dy = (initVal - Val) * LINE_HEIGHT;
}
else
{	dx = (initVal - Val) * MONACO_WIDTH;
	dy = 0;
}

GetClip(refPtr->dummyRgn);
GetStatusDrawableRect(refPtr->wind, &clipR);
ClipRect(&clipR);
ScrollRect(&scrlRect, dx, dy, 0L);	
SetClip(refPtr->dummyRgn);

if (isVertBar)
{	updtRect = clipR;
	if (dy > 0)
		updtRect.bottom = updtRect.top + (dy + LINE_HEIGHT);
	else
		updtRect.top = updtRect.bottom + (dy - LINE_HEIGHT);
}
else
{	updtRect = clipR;
	if (dx > 0)
		updtRect.right = updtRect.left + (dx + MONACO_WIDTH);
	else
		updtRect.left = updtRect.right + (dx - MONACO_WIDTH);
}

	
RectRgn(refPtr->statusDummyRgn, &updtRect);
DrawStatusWind(refPtr->wind, refPtr->statusDummyRgn);
}

//===========================================================================================
static void DoContentClick(WindowPtr wind, Point thePt)
{
//WindowPtr			tempPort;
ControlHandle		theControlH;
long				partCode = 0;
ControlActionUPP	trackActionProc = nil;
WindowPtr			front;

	/*
	GetPortExt(&tempPort);
	if (tempPort != wind)
	{	SelectWindow(wind);
		SetPortExt(wind);
		return;
	}
	*/
	front = FrontWindow();
	if (wind != front)
	{	SelectWindow(wind);
		SetPortExt(wind);
		return;
	}

	partCode = FindControl(thePt, wind, &theControlH);
	if (partCode)
	{	if (partCode == kControlIndicatorPart)
		{	short			dx, i, j;
			StatusRefP		refPtr;
			
			dx = 0;
			refPtr = (StatusRefP)GetControlReference(theControlH);
			j = GetControlValue(theControlH);
			partCode = TrackControl(theControlH, thePt, (void*)0L);	//sposta la memoria
			i = GetControlValue(theControlH);
			dx = i - j;
			if (dx)
			{	if (refPtr->statusVScroll == theControlH)
					refPtr->strTop = i;
				else
					refPtr->horCharPos = i;
				DrawStatusWind(wind, nil);
			}
		}
		else if (trackActionProc = NewControlActionUPP(ScrollStrings))
		{	partCode = TrackControl(theControlH, thePt, trackActionProc);
			#if TARGET_API_MAC_CARBON
				DisposeControlActionUPP(trackActionProc);
			#else
				DisposeRoutineDescriptor(trackActionProc);
			#endif
		}
	}
}

#if TARGET_API_MAC_CARBON
//===========================================================================================
static OSStatus _Scroll(EventHandlerCallRef myHandler, EventRef theEvent, void* userData, ControlHandle theControlH)
{
StatusRefP			refPtr = (StatusRefP)userData;
short				i;
OSStatus			res = eventNotHandledErr;
//WindowPtr			oldPort;
//Rect				portRect;
WindowPtr			wind = gStatusWindow;
//Rect				rectNull = {0, 0, 0, 0};

    i = GetControl32BitValue(theControlH);
	if (refPtr->statusVScroll == theControlH)
		refPtr->strTop = i;
	else
		refPtr->horCharPos = i;
	//ClipRect(&rectNull);
	DrawStatusWind(wind, nil);
	
return res;
}

//===========================================================================================
static pascal OSStatus HorizontalScroll(EventHandlerCallRef myHandler, EventRef theEvent, void* userData)		//3
{
StatusRefP			refPtr = (StatusRefP)userData;

	return _Scroll(myHandler, theEvent, userData, refPtr->statusHScroll);
}

//===========================================================================================
static pascal OSStatus VerticalScroll(EventHandlerCallRef myHandler, EventRef theEvent, void* userData)		//3
{
StatusRefP			refPtr = (StatusRefP)userData;

	return _Scroll(myHandler, theEvent, userData, refPtr->statusVScroll);
}
#endif

#if TARGET_API_MAC_CARBON && PRJBUILDER
	#define	 	topLeft(r)		(((Point*)&(r))[0])	
	#define 	botRight(r)		(((Point*)&(r))[1])	
#endif

//===========================================================================================
static void	AdjustStatusAfterGrow(WindowPtr windP)
{
Rect					portRect;
register StatusRefP 	refPtr;
register int			diff, windHeigh;

	refPtr = (StatusRefP)GetWRefCon(windP);
	HideControl(refPtr->statusHScroll);
	HideControl(refPtr->statusVScroll);
	CGetPortRect(windP, &portRect);
	
	SizeControl(refPtr->statusVScroll, 16, portRect.bottom - SCROLLBAR_WITDH - TOOLBAR_HEIGHT);
	MoveControl(refPtr->statusVScroll, portRect.right - SCROLLBAR_WITDH, TOOLBAR_HEIGHT + 1);					
	SizeControl(refPtr->statusHScroll, portRect.right - 14, 16);
	MoveControl(refPtr->statusHScroll, 0, portRect.bottom - SCROLLBAR_WITDH);

	windHeigh = (portRect.bottom - BOTTOM_MARGIN - TOOLBAR_HEIGHT - SCROLLBAR_WITDH)/LINE_HEIGHT;
	diff = windHeigh - (refPtr->strCount - refPtr->strTop);
	if (diff > 0)
	{	if (refPtr->strTop >= diff)
			refPtr->strTop -= (diff);
		else
			refPtr->strTop = 0;
	}
	
	AdjustStatusScroll(windP, (StatusRefP)GetWRefCon(windP));
	
	ShowControl(refPtr->statusHScroll);
	ShowControl(refPtr->statusVScroll);

	#if TARGET_API_MAC_CARBON
		portRect.right -= SCROLLBAR_WITDH;
		portRect.bottom -= TOOLBAR_HEIGHT + SCROLLBAR_WITDH;
		InvalWindowRect(windP, &portRect);
	#else
		InvalRect(&portRect);
	#endif
}

//===========================================================================================
static void	DoGrowStatus(WindowPtr windP, Point where)
{
Rect		limits = {200, 438, 32000, 32000};	
long		size;
WindowPtr	oldPort;
	
	GetPortExt(&oldPort);
	SetPortExt(windP);
	size = GrowWindow(windP, where, &limits);
	SizeWindow(windP, LowWrd(size), UpWrd(size), true );
	AdjustStatusAfterGrow(windP);
	SetPortExt(oldPort);
}

//===========================================================================================
static Boolean	ActiveWindow(WindowPtr theWind, Boolean toActivate)
{
	if (theWind == gStatusWindow)
	{	if (toActivate)
			SetPortExt(theWind);
		return true;
	}
	else
		return false;
}

//===========================================================================================
/*static WindowPtr	GetLogWindow(long winRef)
{
StatusRefP	refPtr;
	
	refPtr = (StatusRefP)winRef;
	return refPtr->wind;
}*/

//===========================================================================================
/*static Boolean	IsLogWindowVisible(long winRef)
{
WindowPtr	wind = ((StatusRefP)winRef)->wind;
	
	return CIsWindowVisible(wind);
}*/
//===========================================================================================
/*static void	TheZoomWindow(WindowPtr wind, long part)
{	
	ZoomWindow(wind, part, false);
	AdjustStatusAfterGrow(wind);

}*/

static Rect	dragRect = { 0, 0, 2048, 2048 };
//===========================================================================================
static void DoMenu(long logWinRef, long mScelta, Boolean *quitProgramP, Boolean *isMyEventP)
{
short				mID, mItem;
Str255				name;
MacLogProcessFunc	pFunc;

	mItem = *(short*)((Ptr)(&mScelta)+2);
	mID = *(short*)(&mScelta);
	
	if (mID)
	{	switch(mID)
		{
		case 1:
			if (mItem == 1)
				;
			else
				{
				GetMenuItemText(gMenuH[0].menuH, mItem, name);
				;//OpenDeskAcc(name);
				*isMyEventP = true;
				}
			break;

		case 2:
			if ((mItem == 1) && logWinRef)
				ShowLogWindow(logWinRef);
			else if ((mItem == 2) && logWinRef)
				HideLogWindow(logWinRef);
			else 
			{	/*processFunc = ((StatusRefP)logWinRef)->processFunc;
				if (processFunc && (mItem == 4))
					processFunc();
				else*/
				*quitProgramP = true;
			}
			*isMyEventP = true;
			break;
			
		default:
			if (mID <= gTotMenus)
			{	pFunc = gMenuH[mID-1].processFunc[mItem-1];
				//DisableMenuItem(gMenuH[mID-1].menuH, mItem);
				if (pFunc)
					pFunc(gMenuH[mID-1].menuH, mID, mItem);
				//EnableMenuItem(gMenuH[mID-1].menuH, mItem);
			}
			break;
		}
	}	
HiliteMenu(0);
}

//===========================================================================================
static void SetUpMenus(void)
{
MenuHandle		appleMenu, fileMenu;
Str255			aPStr;

	appleMenu = NewMenu( 1, "\p\024" );		// create "Apple" menu ()

	AppendMenu( appleMenu, "\pAbout...");
	AppendMenu( appleMenu, "\p(-" );	/* dotted line */
	AppendResMenu(appleMenu, 'DRVR' );
	InsertMenu( appleMenu, 0 );			/* install in menu bar */

	fileMenu = NewMenu( 2,"\pFile" );
	PEquStr(aPStr, "\pOpen Window/O;Close Window/S;(-;Quit/Q");
	AppendMenu( fileMenu, aPStr);
	InsertMenu( fileMenu, 0 );

	DrawMenuBar();	/* display:    File   Options  */
	gMenuH[0].menuH = appleMenu;
	gMenuH[1].menuH = fileMenu;
	
	gTotMenus = 2;
}

#pragma mark-
//===========================================================================================
void	MacLogGetMenu(long menuIndex, MenuHandle *menuH)
{
int		idx;

	if (menuH)
	{	idx = menuIndex + 1;
		if ((idx >= 0) && (idx < gTotMenus))	
			*menuH = gMenuH[idx].menuH;
		else
			*menuH = nil;
	}
}

//===========================================================================================
void	MacLogCheckItem(long menuID, long itemID, Boolean checkIt)
{
	CheckMenuItem(gMenuH[menuID-1].menuH, itemID, checkIt);
}

//===========================================================================================
void WindowLogAddMenuItem(char *menuName, CStr63 *processItemString, MacLogProcessFunc *processFunc, long totItems)
{
MenuHandle			theMenu;
Str255				aPStr;
int					i;
MacLogProcessFunc	*tp;

	if (gTotMenus < MAX_MENU)
	{	CToPascal(menuName, aPStr);
		theMenu = NewMenu(gTotMenus+1, aPStr);
		
		if (totItems > MAX_MENU_ITEMS)
			totItems = MAX_MENU_ITEMS;

		tp = &gMenuH[gTotMenus].processFunc[0];
		for (i = 0; i < totItems; i++, tp++)
		{	CToPascal(processItemString[i], aPStr);
			AppendMenu(theMenu, aPStr);
			*tp = processFunc[i];
		}
		InsertMenu(theMenu, 0 );
		gMenuH[gTotMenus].menuH = theMenu;
		gMenuH[gTotMenus].totProcessFunc = totItems;
		gTotMenus++;
		DrawMenuBar();
	}
}

//===========================================================================================
XErr	InitLogWindow(char* appName, long *winRefP, StringPtr optString)
{
Rect		cRect;
StatusRefP	refPtr;
XErr		err = noErr;
WindowPtr	statusWindow;
Str255		name;
Rect		portRect;
BlockRef	block;

SetUpMenus();

if NOT(block = NewPtrBlock(sizeof(StatusRef), &err, (Ptr*)&refPtr))
	return err;

//refPtr = (StatusRefP)GetPtr(block);
refPtr->block = block;

if(optString)
	PEquStr(refPtr->statusOptionalStr, optString);
else
	refPtr->statusOptionalStr[0] = 0;

refPtr->strCount = 0;
refPtr->strTop = 0;
refPtr->strIdx = 0;
refPtr->horCharPos = 0;

//refPtr->hPic = nil;
if (refPtr->hPic = GetPicture(128))
{
	gPicRect.top = 10;
	gPicRect.left = 18;
	gPicRect.right = gPicRect.left + 32;
	gPicRect.bottom = gPicRect.top + 32;
}

portRect.top = 44;
portRect.left = 8;
portRect.bottom = 266+44;
portRect.right = 445+4;

statusWindow = (WindowPtr)CCreateWindow(0, 0, &portRect);
if NOT(statusWindow)
	return XGetError();

gStatusWindow = statusWindow;
CGetPortRect(statusWindow, &portRect);

SetWRefCon(statusWindow, (long)refPtr);
SetPortExt(statusWindow);
CToPascal(appName, name);
SetWTitle(statusWindow, name);
TextFont(kFontIDMonaco);
TextSize(9);
MoveWindow(statusWindow, 6, 42, false);

refPtr->wind = statusWindow;
cRect.top = portRect.top + TOOLBAR_HEIGHT + 1;
cRect.bottom = portRect.bottom - 14;
cRect.right = portRect.right + 1;
cRect.left = cRect.right - 16;
refPtr->statusVScroll = NewControl(statusWindow, &cRect, 0L, TRUE, 0, 0, 0, 16, 0L);
SetControlReference(refPtr->statusVScroll, (long)refPtr);

cRect.top = cRect.bottom - 1; 
cRect.bottom += 15;
cRect.right -= 15; cRect.left = 0;
refPtr->statusHScroll = NewControl(statusWindow, &cRect, 0L, TRUE, 0, 0, 0, 16, 0L);
SetControlReference(refPtr->statusHScroll, (long)refPtr);

#if TARGET_API_MAC_CARBON
{
EventTypeSpec eventList = {kEventClassControl, kEventControlTrack};   

	InstallControlEventHandler(refPtr->statusHScroll, NewEventHandlerUPP(HorizontalScroll), 1, &eventList, refPtr, NULL);
	InstallControlEventHandler(refPtr->statusVScroll, NewEventHandlerUPP(VerticalScroll), 1, &eventList, refPtr, NULL);
}
#endif

refPtr->dummyRgn = NewRgn();
refPtr->statusDummyRgn = NewRgn();
clipRgn = NewRgn();
*winRefP = (long)refPtr;

CSetColor(&mymidGray, 0xC000, 0xC000, 0xC000);
CSetColor(&myBlack, 0, 0, 0);

TheUpdateStatusWindow(statusWindow, 0, 0);
return err;
}

//===========================================================================================
void EndLogWindow(long winRef)
{
StatusRefP	refPtr;
BlockRef	block;

	refPtr = (StatusRefP)winRef;
	DisposeRgn(refPtr->dummyRgn);
	DisposeRgn(refPtr->statusDummyRgn);
	DisposeControl(refPtr->statusVScroll);
	DisposeControl(refPtr->statusHScroll);
	DisposeWindow(refPtr->wind);
	if (refPtr->hPic)
		ReleaseResource((Handle)refPtr->hPic);
	block = refPtr->block;
	DisposeBlock(&block);
	DisposeRgn(clipRgn);
}

//===========================================================================================
Boolean UpdateLogWindow(WindowPtr wind)
{
WindowPtr	oldPort;

	if (wind == gStatusWindow)
	{	GetPortExt(&oldPort);
		SetPortExt(gStatusWindow);
		BeginUpdate(gStatusWindow);	
		TheUpdateStatusWindow(gStatusWindow, 0, 0);
		EndUpdate(gStatusWindow);
		SetPortExt(oldPort);
		return true;
	}
	else
		return false;
}

//===========================================================================================
static XErr	__CStringToLogWindow(long winRef, char *cString, Boolean time, Boolean addToLast, RGBColor *color)
{
CStr255		tStr;
Str255		finStr;
WindowPtr	wind = ((StatusRefP)winRef)->wind;
XErr		err = noErr;

	XThreadsEnterCriticalSection();
	if (CIsWindowVisible(wind))
	{	if (time)
		{	XCurrentDateTimeToString(tStr, kComplete);
			CAddStr(tStr, "\t");
			CToPascal(tStr, finStr);
			AddCStrToPascal(finStr, cString);
		}
		else
			CToPascal(cString, finStr);
		err = AddStatusMessage(wind, finStr, addToLast, color);
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	__StringToLogWindow(long winRef, const StringPtr strP, Boolean addToLast, RGBColor *color)
{
CStr255		tStr;
Str255		finStr;
WindowPtr	wind = ((StatusRefP)winRef)->wind;
XErr		err = noErr;

	XThreadsEnterCriticalSection();	
	if (CIsWindowVisible(wind))
	{	XCurrentDateTimeToString(tStr, kComplete);
		CAddStr(tStr, "\t");
		CToPascal(tStr, finStr);
		PAddStr(finStr, strP);
		err = AddStatusMessage(wind, finStr, addToLast, color);
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	CStringToLogWindow(long winRef, char *cString, Boolean time)
{
	return __CStringToLogWindow(winRef, cString, time, false, &gsBlack);
}

//===========================================================================================
XErr	CStringToLogWindowExt(long winRef, char *cString, Boolean time, Boolean addToLast, RGBColor *color)
{
	return __CStringToLogWindow(winRef, cString, time, addToLast, color);
}

//===========================================================================================
XErr	StringToLogWindow(long winRef, const StringPtr strP)
{
	return __StringToLogWindow(winRef, strP, false, &gsBlack);
}

//===========================================================================================
XErr	StringToLogWindowExt(long winRef, const StringPtr strP, Boolean addToLast, RGBColor *color)
{
	return __StringToLogWindow(winRef, strP, addToLast, color);
}

//===========================================================================================
Boolean	IsLogWindowEvent(long winRef, EventRecord *theEventP, Boolean *quitProgramP)
{
short		part;
WindowPtr	whichWindow;
Boolean		isMyEvent = false;
Point		theClick = theEventP->where;
StatusRefP	refPtr;
WindowPtr	oldPort;
	
	refPtr = (StatusRefP)winRef;
	GlobalToLocal(&theClick);
	switch (theEventP->what)
	{	case mouseDown:
			part = FindWindow(theEventP->where, &whichWindow);
			switch (part)
			{	case inContent:
					if (whichWindow == refPtr->wind)
					{	DoContentClick(whichWindow, theClick);
						isMyEvent = true;
					}
					else
						isMyEvent = false;
					break;
				case inDrag:
					if (whichWindow == refPtr->wind)
					{	DragWindow(whichWindow, theEventP->where, &dragRect);
						isMyEvent = true;
					}
					else
						isMyEvent = false;
					break;
				case inMenuBar:
					DoMenu(winRef, MenuSelect(theEventP->where), quitProgramP, &isMyEvent);
					break;
				case inGrow:
					if (whichWindow == refPtr->wind)
					{	DoGrowStatus(whichWindow, theEventP->where);
						isMyEvent = true;
					}
					else
						isMyEvent = false;
					break;
				case inGoAway:
					if (whichWindow == refPtr->wind)
					{	if (TrackGoAway(whichWindow, theClick))
							HideWindow(whichWindow);
						isMyEvent = true;
					}
					else
						isMyEvent = false;
					break;
				case inZoomOut:
				case inZoomIn:
					if (whichWindow == refPtr->wind)
					{	ZoomWindow(whichWindow, part, false);
						AdjustStatusAfterGrow(whichWindow);
						isMyEvent = true;
					}
					else
						isMyEvent = false;
					break;
				default:
					break;	
			}
			break;
		case keyDown :
		case autoKey :
			if (theEventP->modifiers & cmdKey)
				DoMenu(winRef, MenuKey(theEventP->message & charCodeMask), quitProgramP, &isMyEvent);
			else
				SysBeep(3);
			break;		
		case activateEvt:
			isMyEvent = ActiveWindow((WindowPtr)theEventP->message, (Boolean)(theEventP->modifiers & activeFlag));
			break;
		case updateEvt:
			if (((WindowPtr)theEventP->message == gStatusWindow) && ((WindowPtr)theEventP->message == refPtr->wind))
			{	
				GetPortExt(&oldPort);
				SetPortExt(gStatusWindow);
				BeginUpdate(gStatusWindow);	
				TheUpdateStatusWindow(gStatusWindow, 0, 0);
				EndUpdate(gStatusWindow);
				SetPortExt(oldPort);
				isMyEvent = true;
			}
			else
				isMyEvent = false;
			break;
		case osEvt:
			isMyEvent = false;
			break;
		}
return isMyEvent;
}

//===========================================================================================
void	ShowLogWindow(long winRef)
{
StatusRefP	refPtr;
	
	refPtr = (StatusRefP)winRef;
	ShowWindow(refPtr->wind);
	TheUpdateStatusWindow(refPtr->wind, 0, 0);
}

//===========================================================================================
void	HideLogWindow(long winRef)
{
StatusRefP	refPtr;
	
	refPtr = (StatusRefP)winRef;
	HideWindow(refPtr->wind);
}


