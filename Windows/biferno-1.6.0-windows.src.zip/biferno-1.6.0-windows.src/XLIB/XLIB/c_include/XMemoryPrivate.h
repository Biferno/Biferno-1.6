/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XMemoryPrivate.h,v 1.3 2008-04-16 14:31:01 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef	__XMEMORYPRIVATE__
	#define __XMEMORYPRIVATE__

#define	SLOTS_ALLOC_STEP	256

typedef struct {
				long			address;
				long			size;
			#ifdef __MAC_XLIB__
				long			isHandle:	1;
				long			lockCount: 	31;
			#endif
				} MemSlot;

#ifdef MEM_DEBUG
	#define	MEMORY_MGR_DEFAULT_SLOTS	128
#else
	#define	MEMORY_MGR_DEFAULT_SLOTS	4096
#endif
/*typedef struct {
				unsigned long	slotCnt;
				unsigned long	usedSlotCnt;
				unsigned long	firstFreeSlot;
				unsigned long	max;
				unsigned long	maxLastMove;
				MemSlot			memSlot[SLOTS_ALLOC_STEP];
				} MemArraySlot, *MemArraySlotP;


#ifdef __MAC_XLIB__
	#ifdef MEM_DEBUG
		#define	GET_MEM_ARRAY()			((MemArraySlotP)((*(Ptr*)gsMainMemBlock)+8))
	#else
		#define	GET_MEM_ARRAY()			(*(MemArraySlotP*)gsMainMemBlock)
	#endif
#else
	#ifdef MEM_DEBUG
		#define	GET_MEM_ARRAY()			((MemArraySlotP)((Ptr)gsMainMemBlock+8))
	#else
		#define	GET_MEM_ARRAY()			((MemArraySlotP)((Ptr)gsMainMemBlock))
	#endif
#endif

#define	GET_MEM_SLOT(id)		(&GET_MEM_ARRAY()->memSlot[id-1])

#define	RESET_TIME		(60L * 5L)	// 5 minutes

#define	UNDEFINED_SLOT	0xFFFFFFFF
*/

// Init - End
XErr			XMemoryInit(void);
XErr			XMemoryEnd(void);

// low
long			NewBlock_low(long size, XErr *errPtr);
long			NewBlockClear_low(long size, XErr *errPtr);
long			NewPtrBlock_low(long size, XErr *errPtr);
#if __MAC_XLIB__
	XErr			DisposeBlock_low(long *addressP, Boolean isHandle, unsigned long size);
	Ptr				GetPtr_low(long address, Boolean isHandle);
	unsigned long	GetBlockSize_low(long address, Boolean isHandle, XErr *errP);
	XErr 			SetBlockSize_low(long *addressP, Boolean isHandle, unsigned long oldSize, unsigned long newSize);
#else
	XErr			DisposeBlock_low(long *addressP, unsigned long size);
	Ptr				GetPtr_low(long address);
	unsigned long	GetBlockSize_low(long address, XErr *errP);
	XErr 			SetBlockSize_low(long *addressP, unsigned long oldSize, unsigned long newSize);
#endif
#ifdef __MAC_XLIB__
	void		LockBlock_low(long address);
	void		UnlockBlock_low(long address);
	Boolean		IsLocked_low(long address);
#else
	#define		UnlockBlock_low(x)				0
	#define		LockBlock_low(x)				0
#endif

// Memory Debug (Internal)
#ifdef MEM_DEBUG
	#define		NOACTION	0
	#define		FILL		1
	#define		CLEAR		2
	
	void		_WritePageGuardians(Ptr p, unsigned long size, short action);
	void		_CheckPageGuardians(Ptr p, unsigned long size, char *funcName);
#endif

// Check leaking
#ifdef CHECK_LEAKING
	void		InitMemoryLeakingMgr(void);
	void		CheckLeakingMoreThread(unsigned long parent, unsigned long newThreadID);
	void		CheckLeakingLessThread(void);
	void		_OneMoreLock(void);
	Boolean		_Locking(void);
	void		_OneLessLock(void);
	void		_OneLessLockNoStackCheck(void);
	void		_OneMoreHandle(BlockRef b);
	void		_OneMorePtr(BlockRef b);
	void		_OneLessHandle(BlockRef b);
	void		_OneLessPtr(BlockRef b);
#endif


#endif
