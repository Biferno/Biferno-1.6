/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XLib.h,v 1.44 2008-09-19 13:44:51 tabasoft Exp $
	|______________________________________________________________________________
*/

#ifndef	__XLIB__
	#define __XLIB__

#if __MACOSX__
	#include <stdlib.h>
	#include <string.h>
#endif

#if __MACOSX__ && __USE_CARBON_FRAMEWORK__
	#define __DONT_DEFINE_MAC_STUFF__	1
	
	#include <Carbon/Carbon.h>
	#include <CoreFoundation/CoreFoundation.h>
	#include <CoreServices/CoreServices.h>	
#endif

//===========================================================================================
/*
	Tabasoft 2001
	
	XLib

	Version:	1.0.1
		
	Index:
			- X Generic
			- X Errors
			- X Init & End
			- X Memory
			- X Strings
			- X Date Time
			- X DLL
			- X Files
			- X Threads
			- X Sockets
			- X Debug

Note:
define
		__[System]_XLIB__
		__[ByteOrder]ENDIAN__

before include XLib.h.	
*/
//===========================================================================================
//
//---------------------------------- X Generic ----------------------------------------------
//
//===========================================================================================
#include <stddef.h>
#include <stdio.h>
#ifdef __WIN_XLIB__
	#include<WTYPES.H>
	typedef DWORD uint32_t;
#else
	#include <stdint.h>
#endif

// The current version of XLib
#define CUR_XLIB_VERSION	(unsigned long) 0x00010002	// Do NOT modify this value

// Generic definitions
#define 	NOT(x)							(!(x))

#ifndef __cplusplus
	#undef not
	#define 	not(x)							(!(x))
#endif

#define		LowWrd(longa)					(*((short*)(&longa) + 1))
#define		UpWrd(longa)					(*((short*)(&longa)))
#define 	LOW_CHAR(ch)					if (ch <= 'Z' && ch >= 'A') {ch += ('a'-'A');}
#define 	UPR_CHAR(ch)					if (ch >= 'a' && ch <= 'z') {ch -= ('a'-'A');}
#define		TESTBIT(varToTest, bitToTest)	((varToTest & (1<<bitToTest)) != 0)
#define		SETBIT(varToSet, bitToSet)		( varToSet  |= (1<<bitToSet) )
#define		LowWrd(longa)					(*((short*)(&longa) + 1))
#define		UpWrd(longa)					(*((short*)(&longa)))

#define		PAD_LONG(x)					((x + 3) & ~3)
#define		PAD_BOUND_SIZE(x, _siz)		((x + (_siz - 1)) & ~(_siz - 1))	// WARNING: _siz MUST be a power of 2 (2, 4, 8, 16 etc...)

#define	IS_ALNUM(x)	(((x <= 'z') && (x >= 'a')) || ((x <= 'Z') && (x >= 'A')) || ((x <= '9') && (x >= '0')))

// Types
#ifndef __MAC_XLIB__
	#ifdef __DONT_DEFINE_MAC_STUFF__
		#if !__MACOSX__
			#include "MacTypes.h"	// (usually) quicktime on Win32
			#include "Files.h"	// (usually) quicktime on Win32
		#endif
	#else
		typedef	char*			Ptr;
		typedef unsigned char 		Boolean;
		typedef	unsigned char*		StringPtr;
		typedef unsigned char 		Byte;
		typedef	unsigned char		Str15[16];
		typedef	unsigned char		Str31[32];
		typedef	unsigned char		Str63[64];
		typedef	unsigned char		Str255[256];
		typedef	void*				ProcPtr;
		typedef	double				real;
	#ifndef __cplusplus
		enum {false = 0, true = 1};
	#endif
		#define	nil		0L
		#define	noErr	(short)0
		/*#ifdef __UNIX_XLIB__
			#define offsetof(type, member)	((long)&(((type *) 0)->member))
		#endif*/
	#endif
#endif

#if (__MWERKS__ && __MAC_XLIB__) || __UNIX_XLIB__ || TARGET_API_MAC_CARBON
	typedef long long			LONGLONG;
	typedef unsigned long long		ULONGLONG;
        //#if TARGET_API_MAC_CARBON && PRJBUILDER
            //#define LLONG_MAX	__LONG_MAX__
            //#define LLONG_MIN	~__LONG_MAX__
        //#endif
#else
	/*#ifdef __VISUALCPP__
		#define LLONG_MAX	MAXLONGLONG
		#define LLONG_MIN	~MAXLONGLONG
	#endif*/
#endif


//===========================================================================================
//
//-------------------------------------- X Errors -------------------------------------------
//
//===========================================================================================
#ifdef __MAC_XLIB__
	#define		kOSError	-1
	#define		kOSError2	0		// For Unix MacOSX errors
#else
	#define		kOSError	0
#endif

#define	kXLibError	1

typedef	uint32_t	XErr;
#ifdef __LITTLE_ENDIAN__		// INTEL
	typedef struct {
				long	value:	24;
				long	type:	8;
				} XErrStruct, *XErrStructP;
#else
	typedef struct {
				long	type:	8;
				long	value:	24;
				} XErrStruct, *XErrStructP;
#endif

/*#ifdef __LITTLE_ENDIAN__		// INTEL
	// #define	XERR(t, v)				((XErr)(t | (v << 8)))
#else
	// #define	XERR(t, v)				((XErr)((t << 24) | v))
#endif

//#define	ETYPE(e)	((XErrStructP)&e)->type
//#define	EVALUE(e)	((XErrStructP)&e)->value
*/

#define	XLIB_BASE_ERROR	10000
enum {
		ErrXFiles_FileNotFound = XLIB_BASE_ERROR,
		ErrXFiles_FolderNotFound,
		ErrXFiles_PathTooLong,
		ErrXFiles_LockNotSupported,
		ErrXFiles_FolderIsNotEmpty,
		ErrXFiles_EndOfFile,
		ErrXFiles_WalkFolderAbort,
		ErrXFiles_DuplicatedFile,
		ErrXFiles_UnknownUser,
		ErrXFiles_UnknownGroup,
		ErrXFiles_BadFileRef,

		ErrXMemory_BadRef,
		ErrXMemory_NullSize,
		ErrXMemory_BadBlockSize,
		ErrXMemory_Full,
		ErrXMemory_AttemptToDisposeTwice,
				
		ErrXThreads_Timeout,
		ErrXThreads_InternalErr,
		ErrXThreads_NotFound,

		ErrXDateTimeFormatError,
		
		ErrXDLLCantLoadObject,
		ErrXDLLCantFindSymbol,
		ErrXDLLCantCloseObject,
		
		ErrXConvertingStringToLong,
		ErrXConversion,
		ErrXLibNumOverFlow,

		ErrNotImplementedInXLib,

		ErrConnectionBroken,
		
		ErrXLibTooOld,
		ErrXLibTooNew,
		ErrXLibCallerTooOld,
		ErrXLibCallerTooNew,
		
		ErrThreadAborted,
		
		// >= 1.0.1
		ErrXMemory_SlotsFull,
		ErrXMemory_SlotMgrUninitialized,

		ErrXLibLastError		// before 1.0.1 was not declared (bug!)
		};

XErr	XErrorGetDescr(XErr theError, char *eNameStr, char *eMsg);
XErr 	XError(long eType, long eNum);
void 	XErrorGetTypeValue(XErr theError, long *eNumP, long *eTypeP);
XErr	XGetError(void);

// LogCallBack
typedef	XErr	(*LogCallBack)(void *userParam, char *string);

//===========================================================================================
//
//---------------------------------- X Memory -----------------------------------------------
//
//===========================================================================================

// BlockRef
typedef	uint32_t BlockRef;

// Functions
BlockRef		NewBlock(long size, XErr *errPtr, Ptr *thePtrP);
BlockRef		NewBlockClear(long size, XErr *errPtr, Ptr *thePtrP);
BlockRef		NewPtrBlock(long size, XErr *errPtr, Ptr *thePtrP);
XErr			DisposeBlock(BlockRef *blockRefP);
unsigned long	GetBlockSize(BlockRef blockRef, XErr *errP);
XErr			SetBlockSize(BlockRef blockRef, unsigned long newSize);
Ptr				GetPtr(BlockRef blockRef);
long			GetAddress(BlockRef blockRef);
XErr			DuplicateBlock(BlockRef source, BlockRef *destP);

char*			AllocString(long size, char *aCStr, BlockRef *refP, XErr *errP);
XErr			DisposeString(BlockRef *refP);
//XErr			XMemoryOptimize(void);

void			CopyBlock(void *destP, void *sourceP, long len);
Boolean			CompareBlock( void *aPtr, void *bPtr, long size );
Boolean			Begins(void *aPtr_p, long aPtr_pLen, void *bPtr_p, long size);
void 			ClearBlock(void* blockPtr, long thSize);
void			FillBlock(void* blockP, long thSize, char fillVal);
void			ShiftDownLongArray(long* srcP, long longCnt);
XErr			ExpandBlockClear(BlockRef blockRef, unsigned long newSize);

#ifdef __MAC_XLIB__
	XErr		LockBlock(BlockRef blockRef);
	XErr		UnlockBlock(BlockRef blockRef);
	Boolean		IsLocked(BlockRef blockRef);
	BlockRef	NewBlockLocked(long size, XErr *errPtr, Ptr *thePtrP);
#else
	#define		LockBlock(x)				((void)0)
	#define		UnlockBlock(x)				((void)0)
	#define		IsLocked(x)					((void)0)
	#define		NewBlockLocked(x,y,z)		NewBlock(x,y,z)
#endif

// Check leaking
Boolean		ResetLeaking(void);
void		CheckLeaking(char *cStr, long *leakPtrsP, long *leakHandlesP);

//===========================================================================================
//
//-------------------------------------- X Utils --------------------------------------------
//
//===========================================================================================

// OS Infos
void	XGetSysInfo(char *sysStr);
void	XIdle(void);
#if	__UNIX_XLIB__ || __MACOSX__
	//void	Command(char *command, char *resultStr);

	#if !LLONG_MIN
		#define	LLONG_MIN	LONG_LONG_MIN
	#endif
	
	#if !LLONG_MAX
		#define	LLONG_MAX	LONG_LONG_MAX
	#endif
#endif

int		LongLongAdd(LONGLONG * x, LONGLONG y);
int		LongLongMul(LONGLONG * x, LONGLONG y);
int		LongAdd(long * x, long y);
int		LongMul(long * x, long y);

// HTTP String utils
long GetPOSTLimit(char *searchArgs);

// Byte Order Utils
#define X_LITTLE_ENDIAN		0
#define X_BIG_ENDIAN		1

long 	SwapLong(long aLong, Byte byteOrder);
short	SwapShort(short aLong, Byte byteOrder);

XErr	XLaunchProcess(char *executablePath, char *commandLineString, Boolean waitEnd, unsigned long timeout_ms);
// >= 0x00010001
//XErr	RedirOutput(XErr (*_Func)(long userData), long userData, BlockRef *stdOutP, long *stdOutLenP, BlockRef *stdErrP, long *stdErrLenP);

//===========================================================================================
//
//---------------------------------- X Strings ----------------------------------------------
//
//===========================================================================================

#ifdef __LITTLE_ENDIAN__
	#define	ZERO_FOR		'x0'
#else
	#define	ZERO_FOR		'0x'
#endif

#if __MAC_XLIB__
	#define	EOL_STRING	"\r"
#elif __UNIX_XLIB__
	#define	EOL_STRING	"\n"
#else
	#define	EOL_STRING	"\r\n"
#endif

// CStr typedefs
typedef char			CStr255[256];
typedef char			CStr63[64];
typedef char			CStr32[33];
typedef char			CStr31[32];
typedef char			CStr27[28];
typedef char			CStr15[16];
typedef char			CStr7[8];
typedef	unsigned char	Str7[8];

// Isolatin encode
/*typedef struct {
	short		value;
	char		ent[4];
} Entity;*/

// Pascal
int		 	PCompareStrings(register StringPtr str1, register StringPtr str2);
int		 	PCompareStrings_cs(register StringPtr str1, register StringPtr str2);
void 		PAddChar(StringPtr DestStr, Byte ch);
void 		PAddStr(register StringPtr destStr, register StringPtr strToAdd);
void		PEquStr(register StringPtr destStr, register StringPtr sourStr);
StringPtr 	PSubstitute(StringPtr aStr, Byte oldChar, Byte newChar);
void 		PCutRightZeroDec(StringPtr theStr, int decDigit);

// Pascal (to nums)
double 		PStrToReal(const StringPtr sP);
void 		PRealToStr(double *d, StringPtr sP, short digits);
void		PNumToString(long num, StringPtr str);
void		PStringToNum(StringPtr str, long *numP);
XErr		PStringToNumExt(StringPtr str, long *numP, unsigned long *uLongP);
void		PUnsignedToString(unsigned long num, StringPtr str);

// C (to nums)
double 		CStrToReal(const char *sP);
void 		CRealToStr(double *d, char *sP, short digits);
void		CNumToString(long num, char *str);
void		CStringToNum(char *str, long *numP);
XErr		CStringToNumExt(char *str, long *numP, unsigned long *uLongP);
void		CUnsignedToString(unsigned long num, char *str);

void		CLongNumToString(LONGLONG num, char *str);
XErr		CStringToLongNum(char *str, long strLen, LONGLONG *numP);

// C
int 		CCompareStrings(register char *str1, register char *str2);
int 		CCompareStrings_cs(register char *str1, register char *str2);
int			CLen(const char *string);
int 		CAddStr(register char *destStr, register char *strToAdd);
int 		CAddChar(register char * DestStr, Byte ch);
int			CEquStr(register char *destStr, register char *sourStr);
int		 	CSubstitute(char *str, Byte oldChar, Byte newChar);
Boolean		CBegins(register char *str1, register char *str2, Boolean cs);
Boolean		IsSeparChar(Ptr tempP, long len, long *returnSizeP);
int			CAddStrX(register char *destStr, register char *strToAdd, int destLen);
int 		CAddCharX(register char* s, Byte ch, int sLen);
int			CEquStrCK(register char *destStr, register char *sourStr, int maxChars);
Boolean		IsIntNumber(char *cStr, long *result);

int 		CCompareStringsExt(register char *str1, long len1, register char *str2, long len2);
XErr		PStringToLongNum(StringPtr str, LONGLONG *lP);

// Conversions
StringPtr	CToPascal(char *cStr, StringPtr string);
char*		PascalToC(StringPtr string, char *cStr);
void		AddPascalToCStr(char *cStr, StringPtr name);
void		AddCStrToPascal(StringPtr name, char *cStr);

// Utils
Boolean		SkipSpaceAndTab(Ptr *oldFilePP, long *lenP);
void		SkipSpaceAndTabCRLF(Ptr *oldFilePP, long *lenP, long *lineP);
void		SkipNums(Ptr *oldFilePP, long *lenP);
void		SkipUntilChar(Ptr *oldFilePP, long *lenP, int ch, long *lineP);
int			SpecialChar(int ch);
long		ZapText(register Byte *ptrText, long textLen);
void		CutRightZeroDec(char *theStr, int decimals);
void		PadString(register Byte *ptrText, short textLen, int totChars, int padChar, Boolean before);

Boolean		IsNewLine(Ptr theP, long len, long *returnSizeP);
void		IsNewLine2(Ptr theP, long len, long *returnSizeP);
Boolean 	IsNewLineExt(Ptr *thePPtr, long *lenP, long *lineP);
void		IsNewLineExt2(Ptr *thePPtr, long *lenP, long *lineP);

void 		URLFromFullRequest(char **phisURLP, long *phisURLLenP);
void 		ProtocolFromFullRequest(char **phisURLP, long *phisURLLenP);
void 		ZapNewLines(Byte *textP, long *lenP);
void		WFPrepareFilter(char *suffix, char *newSuffix);
Boolean		WFFilter(char *fileName, char *suffix);
Boolean		_IsEMail(char *strP);

void		VersionToString(long version, char *versionStr, char *devVersion);

// Debug
void		PDebugStr(StringPtr	stringMessage);
void		CDebugStr(char	*stringMessage);
void		CDebugStrExt(char *preMessage, long num, char *postMessage);

// Numbers Format Utils
int			GetSeparators(Byte *theDecSep, Byte *theThousSep, char *sepDate, char *sepTime);
void 		FormatNumber(char *inStr, char *outStr, int decimSep, int thousSep);
int 		ComparePaths(register char *path1, register char *path2);

XErr		StringEscaped(Ptr *strPPtr, long *strLenP, BlockRef *refP);
Boolean		StringInText(char *str, long strLen, char *text, long textLen, Byte sepChar);
int			Hex2Num(char *strP);								// 2 chars string (0 terminate is optional)
long		HexStringToNum(StringPtr hexStr, XErr *errP);		// <= 8 chars pascal string
LONGLONG	HexStringToNumLong(StringPtr hexStr, XErr *errP);	// <= 16 chars pascal string
void 		NumToHexString(long num, char *strP);
void 		NumLongToHexString(LONGLONG num, char *strP);

//===========================================================================================
//
//---------------------------------- X Date Time --------------------------------------------
//
//===========================================================================================
#include <time.h>

#define		BASE_YEAR		1970
#define		MAX_YEAR		2036

#define		kWantHour		1
#define		kWantDate		2
#define		kLeadingZeros	4
#define		kWantSecs		8
#define		kComplete		(kWantHour + kWantDate + kLeadingZeros + kWantSecs)

typedef struct {
				long	year;
				long	month;
				long	day;
				long	hour;
				long	minute;
				long	second;
				long	dayOfWeek;
				} XDateTimeRec, *XDateTimeRecP;

/*typedef struct {
				LONGLONG	year;
				LONGLONG	month;
				LONGLONG	day;
				LONGLONG	hour;
				LONGLONG	minute;
				LONGLONG	second;
				long		dayOfWeek;
				} XDateTimeRecExt, *XDateTimeRecExtP;
*/

// Day Month Year  Order
enum {
		_MDY = 0,
		_DMY,
		_YMD,
		_MYD,
		_DYM,
		_YDM
	};

void	ANSI2XDateTime(Ptr timeP, XDateTimeRecP xTimeP);
void	XDateTime2ANSI(XDateTimeRecP xTimeP, Ptr timeP);

void	NativeDateTime2XDateTime(Ptr osRecP, XDateTimeRecP xTimeP);
void	XDateTime2NativeDateTime(XDateTimeRecP xTimeP, Ptr osRecP);

XErr	XStringToDateTime(char *dateStr, XDateTimeRecP dateRecP, char *opt_formatStr);
XErr	XDateTimeToString(XDateTimeRecP dateRecP, char *dateStr, long flags, char *opt_formatStr);
void	XCurrentDateTimeToString(char *dateStr, long flags);

void	XDateTimeToSeconds(XDateTimeRecP xdtRecP, time_t *secsP);
void	SecondsToXDateTime(time_t secs, XDateTimeRecP xdtRecP);

void	XValidDateTime(XDateTimeRecP xdtRecP);
//void	XValidDateTimeExt(XDateTimeRecExtP xdtRecP);

short	XCompareDateTime(XDateTimeRecP dateRec1, XDateTimeRecP dateRec2);
void	XDateTimeToGMT(XDateTimeRecP xdtRecP);
void	GetUString(XDateTimeRecP xdtRecP, char *date);

void			XDelay(unsigned long ticks);
unsigned long	XGetTicks(void);
//#include <sys/time.h>
//#include <sys/timeb.h>
//unsigned long	XGetTicksExt(struct timeval *curTimeVal, struct timeb *curTimeB);
void			XGetMilliseconds(unsigned long *microTickCountP);
void			XGetSeconds(unsigned long *secsP);

//===========================================================================================
//
//-------------------------------------- X Files --------------------------------------------
//
//===========================================================================================

#ifdef	__UNIX_XLIB__
	#include <sys/stat.h>
	#include <sys/types.h>
#endif

#if __UNIX_XLIB__ || PRJBUILDER
	#define EXP
#else
	#define EXP __declspec(dllexport)
#endif

// XLib Path Separator
#define		PATH_SEP	'/'

// COSTANTS
#define	CREATE_FILE_NEW		1
#define	CREATE_FILE_ALWAYS	2
#define	OPEN_FILE_EXISTING	3
#define	OPEN_FILE_ALWAYS	4

#define	READ_WRITE_PERM		10
#define	READ_PERM			11

#define	FROM_START	0
#define	FROM_EOF	1
#define	FROM_MARK	2

// CACHE
#define	NO_CACHE	true
#define	USE_CACHE	false

//#define	MAX_PATH_LENGTH	255

// variant
#define	kPathIsFolder	1
#define	kPathIsAlias	2

typedef char	XFilePath[256], *XFilePathPtr;

typedef XErr	(*WalkXFolderCallBack)(XFilePathPtr filePath, long variant, long userData);

typedef ULONGLONG	XFileRef;

typedef struct {
				XDateTimeRec	modifDate;
				XDateTimeRec	creatDate;
				long			macosType;
				long			macosCreator;
				Boolean			isDLL;
				Byte			padByte;
				short			padShort;
			#if	__UNIX_XLIB__ || __MACOSX__
				CStr63			user;
				CStr63			group;
				//mode_t			st_mode;
			#endif
				} XFileInfo, *XFileInfoP;

#ifdef	__UNIX_XLIB__
	#define	kS_IRUSR		S_IRUSR
	#define	kS_IWUSR		S_IWUSR
	#define	kS_IXUSR		S_IXUSR

	#define	kS_IRGRP		S_IRGRP
	#define	kS_IWGRP		S_IWGRP
	#define	kS_IXGRP		S_IXGRP

	#define	kS_IROTH		S_IROTH
	#define	kS_IWOTH		S_IWOTH
	#define	kS_IXOTH		S_IXOTH
#else
	#define	kS_IRUSR		0
	#define	kS_IWUSR		0
	#define	kS_IXUSR		0

	#define	kS_IRGRP		0
	#define	kS_IWGRP		0
	#define	kS_IXGRP		0

	#define	kS_IROTH		0
	#define	kS_IWOTH		0
	#define	kS_IXOTH		0
#endif

XErr	OpenXFile(XFilePathPtr filePath, short mode, long permission, Boolean dontUseCache, XFileRef *xrefNumP);
XErr 	OpenNewXFile(XFilePathPtr filePathP, int fPerm, long fType, long fCreat, XFileRef *xFileRefP);

XErr	CloseXFile(XFileRef *xrefNumP);
XErr	ReadXFile(XFileRef xrefNum, Ptr bufferP, long *bufferLenP);
XErr	WriteXFile(XFileRef xrefNum, Ptr bufferP, long *bufferLenP);

void	XGetFileNameFromPath(XFilePath filePath, Ptr fileName);
//XErr 	CreateOpenXFile(XFilePathPtr filePathP, int fPerm, long fType, long fCreat, XFileRef *xFileRefP);

XErr	FlushXFile(XFileRef xrefNum);
XErr	DeleteXFile(XFilePathPtr filePath);
XErr	MoveXFile(XFilePathPtr oldPath, XFilePathPtr newPath, Boolean replaceExisting);
XErr	CopyXFile(XFilePathPtr oldPath, XFilePathPtr newPath, Boolean replaceExisting);
XErr	RenameXFile(XFilePathPtr oldPath, XFilePathPtr newPath);
XErr	TranferBytes(XFileRef sourceRef, XFileRef destRef);

XErr	GetXEOF(XFileRef xrefNum, long *eofP);
XErr	GetXEOFFromPath(XFilePathPtr path, long *eofP);
XErr	GetXResForkSize(XFilePathPtr filePath, long *eofP);
XErr	SetXEOF(XFileRef xrefNum, long newEOF);
XErr	GetXFileInfo(XFilePathPtr filePath, XFileInfoP xFileInfoP);
XErr	SetXFileInfo(XFilePathPtr filePath, XFileInfoP xFileInfoP);
XErr	SetXFPos(XFileRef xrefNum, long mode, long offset);
XErr	GetXFPos(XFileRef xrefNum, long *offsetP);
XErr	LockXFile(XFileRef xrefNum, long start, long length, Boolean wait);
XErr	UnlockXFile(XFileRef xrefNum, long start, long length);
XErr	IsXFileOpen(XFilePathPtr filePath, Boolean *isOpenP);

XErr	XMakeAlias(XFilePathPtr filePath, XFilePathPtr aliasPath);

XErr	CheckPath(XFilePathPtr path, Boolean resolveAlias);

XErr	CreateXFolder(XFilePathPtr folderPath);
XErr	DeleteXFolder(XFilePathPtr folderPath);
XErr	RenameXFolder(XFilePathPtr folderPath, char *newName);
XErr	WalkXFolder(XFilePathPtr folderPath, char *suffix, Boolean recursive, WalkXFolderCallBack callBack, long userData);
XErr	GetXApplicationCurrentDir(XFilePathPtr xAppCurrentDir);

XErr	XGetApplicationFolderPath(XFilePathPtr path);
XErr	XGetExtensionsFolderPath(XFilePathPtr extensionsPath);

XErr	XIsAlias(XFilePathPtr path, Boolean *isAliasP);
XErr	XIsFolder(XFilePathPtr path, Boolean *isDirectoryP);
XErr	XResolveAlias(XFilePathPtr filePath);

XErr	GetFileMode(XFileRef xrefNum, XFilePathPtr filePath, long *modeP);
XErr	ChangeFileMode(XFileRef xrefNum, XFilePathPtr filePath, long modeFlags);	// unix

void	FilePathXLibToWin32(XFilePathPtr filePath);
int		FilePathWin32ToXLib(XFilePathPtr filePath);

#if __MAC_XLIB__ || __QTWIN32__
	XErr GetMacOSSpecExt(XFilePathPtr filePath, FSSpec *fileSpecP, Boolean noFnfErr, Boolean resolveAlias);
#endif

//===========================================================================================
//
//-------------------------------------- X DLL ----------------------------------------------
//
//===========================================================================================

XErr	XLoadDLL(XFilePathPtr dllPath, long *dllRef, char *errString, long *xlibVersion, Boolean macosxBundle);
XErr	XFreeDLL(long *dllRef, Boolean macosxBundle);
XErr	XGetDLLSymbol(long dllRef, char *entryPointSymbol, long *entryPointP, Boolean macosxBundle);

#if __MACOSX__ && __USE_CARBON_FRAMEWORK__
	XErr		LoadBundles(XFilePathPtr folderPath, WalkXFolderCallBack _LoadDynamicClass, long userData);
	XErr		Bundle_Load(long myBundle);
	XErr		Bundle_Unload(long myBundle);
	XErr		Bundle_GetSymbol(long myBundle, char *symbolName, long *symbolEntryPointP);
#endif

//===========================================================================================
//
//-------------------------------------- X Threads ------------------------------------------
//
//===========================================================================================

XErr	XYield(unsigned long *lastTicksP);

XErr	XGetCurrentThread(unsigned long *threadIDP);

void	XThreadsEnterCriticalSection(void);
void	XThreadsLeaveCriticalSection(void);
void	XThreadsLeaveCriticalSectionExt(void);

// peculiar critical section
XErr	XNewCS(BlockRef *csBlockRefP);
void	XDeleteCS(BlockRef *csBlockRefP);
void	XEnterCS(BlockRef csBlockRef);
void	XExitCS(BlockRef csBlockRef);

// SEMAPHORE
#define	_GREEN	1
#define	_RED	0

// Flags of XNewThread
#define	kWaitEndOfThread		1
#define	kPremade				2
#define	kStopped				4
#define	kCreateThreadIfNeeded	8
#define	kExactMatch				16

#define	System_EnterCS()	((void)0)
#define	System_LeaveCS()	((void)0)

XErr	XNewThread(unsigned long *threadID, long flags, void* (*func)(void*), unsigned long newThreadStackSize, void *args);
XErr	XThreadsNewPool(long maxThreads, unsigned long size);

long	XThreadsCreateSemaphore(long initialState, XErr *errP);
XErr	XThreadsCloseSemaphore(long semaphore);
XErr	XThreadsSemaphoreGreen(long *semaphore);
XErr	XThreadsWaitSemaphore(volatile long *semaphore, long timeout);

//void	XThreadsForceQuit(unsigned long timeout, long threadsToRemain);

// Thread Local Storage
XErr	XThreadsSetTLS(long thUserData);
long	XThreadsGetTLS(void);
long	XThreadsGetThreadInfo(long *thStackSizeP, long *javaEnvP);	// return stack base address

// Suspend threads
XErr	XThreadsStopThreads(long threadsToRemain);
// Resume threads
XErr	XThreadsResumeThreads(void);

#ifdef __MAC_XLIB__
	#if TARGET_API_MAC_CARBON
		typedef short	(*XYieldProc)(void);
	#else
		typedef pascal short	(*XYieldProc)(void);
	#endif
#endif

//===========================================================================================
//
//-------------------------------------- X Sockets ------------------------------------------
//
//===========================================================================================


#define	CACHE_MAX_USER_DATA					16	// per ora utilizzati solo 4

typedef struct
	{
	XFilePath		filePath;					// file rel path
	Byte			userDatas[CACHE_MAX_USER_DATA];	// config file path
	unsigned long	getTime;					// time when file is asked (don't modify)
	long 			posInCache;					// position in cache (don't modify)
	BlockRef		fileData;					// block to the data of file
	long			fileSize;					// length of data
	Boolean			pad1;
	Boolean			pad2;
	Boolean			wasInCache;					// the file was in cache?
	Boolean			dontCache;					// pad
	} CacheResult;

#ifdef __XLIB_WITH_HELPERS__
	typedef	void	(*ProcessClientRequest_Func)(long socketRef, BlockRef buff, long buffLen, long userData);
	typedef Boolean	(*ReceiveCompleteCallBack)(long bufferID, long bufferLen, long completeCallBackParam);
	typedef XErr	(*XServerOnceHook)(long uData);

	XErr	XServerLoop(long server_port, long listen_queue, ProcessClientRequest_Func proc_func, long userData, Boolean prefixed, Boolean onlyLocal, char *unixfile, char *errString);
	XErr	XServerSetOnceHook(XServerOnceHook hook, long uData);
	XErr	XStopServer(void);
	XErr	XServerSendToClient(long socketRef, BlockRef buffToSend, long buffToSendLength);
	//XErr	XServerNotifyQuit(void);
	
	XErr	XClientCall(char *serverAddr, long server_port, BlockRef dataToSend, long dataToSendLen, BlockRef *serverResponseP, long *serverResponseLenP, char *unixfile, char *errString, ReceiveCompleteCallBack completeCallBack, long completeCallBackParam, long timeout_secs, Boolean expectPrefixed);

	XErr	XRemoteAddress(long socketRef, char *addr);
	XErr	XLocalAddress(long socketRef, char *addr);

	typedef struct {
					CStr255		name;
					long		preference;		// 0 is more important
					} MXRecord;
					
	#if __UNIX_XLIB__ || __WIN_XLIB__
		#if __UNIX_XLIB__
			#include <unistd.h>
			#include <sys/socket.h>
			#include <sys/socketvar.h>
			#include <sys/types.h>
			#include <sys/file.h>
			#include <sys/un.h>
			#include <netdb.h>
			#include <pthread.h>
			#include <netinet/in.h>
		#endif
		
		#define	XSAFE_HOSTENT_LENGTH	128
		typedef struct {
						CStr255	h_name;
						char	h_addr_list0[XSAFE_HOSTENT_LENGTH];
						long	h_length;
					//struct hostent*	host_ent;						// hostent
					//char			buffer[XSAFE_HOSTENT_LENGTH];	// buffer to store stuff hostent points to
					} XSafeHostent;
		XErr	GetHostByNameSafe(const char* name, XSafeHostent* shostentP);
	#endif
					
	XErr	GetMXRecords(CStr255 domain, MXRecord *mxRecordP, long *mxtot);
	void	SortMXRecords(MXRecord *mxRecordP, long mxtot);

	// Sockets (Win & Unix) utils
	#define	PACK_SIZE	(1024L * 4L * sizeof(char))
	
	#define EXPECT_PREFIXED				true
	#define	DONT_EXPECT_PREFIXED		false

	XErr	XSocketsReceive(long socketRef, BlockRef *buffReceivedBlockP, long *buffReceivedLengthP, Boolean expectPrefixed, ReceiveCompleteCallBack _completeFunc, long completeCallBackParam);
	XErr	XSocketsSend(long socketRef, BlockRef buffToSendBlock, long buffToSendLength);
	long	XHostToNetwork(long n);
	long	XNetworkToHost(long n);

	//===========================================================================================
	//
	//-------------------------------------- Helpers definitions----------------------------------------------
	//
	//===========================================================================================
	/*
	*
	*	Helpers definitions
	*
	*/
	#define	kXHelperError	2
	#define HELPERS_BASE_ERROR		11000
	enum{
			Buffers_Err_NotInitialized = HELPERS_BASE_ERROR,
			Buffers_Err_BadID,
			Buffers_Err_AttemptToFreeTwice,
			Buffers_Err_AttemptToCloseTwice,
			
			Cache_Err_NotInitialized,
			Cache_Err_PathTooLong,
			//Cache_Err_UserDataTooLong,

			DLM_Err_InvalidListRef,
			DLM_Err_ListDontAcceptNames,
			DLM_Err_DuplicatedObject,
			DLM_Err_OutOfBoundary,
			DLM_Err_BufferToSmall,
			DLM_Err_ObjectNotFound,
			DLM_Err_CantModifyLength,
			DLM_Err_ObjectIsConstant,
			DLM_Err_ObjectIsLocked,
			DLM_Err_ListIsLocked,
			DLM_Err_ObjectIsNotArray,
			//DLM_Err_BadArrayDimension,
			DLM_Err_ArrayElemWrongType,
			DLM_Err_InvalidArrayIndex,
			DLM_Err_InvalidPos,
			DLM_Err_InvalidLength,
			DLM_Err_NoMoreDataInObject,
			DLM_Err_NoResolveOnDupList,
			DLM_Err_NameTooLong,
			DLM_Err_InvalidListType,
			DLM_Err_IllegalOperation,
			DLM_Err_CantDisposeRef,
			DLM_Err_InvalidFile,
			
			TextUtils_Err_NotInitialized,
			
			// XLib >= 0x00010001
			/*
			Note:
			JavaError, JNIUtils_JavaError, JNIUtils_StringTooLong, JNIUtils_FieldNotFound
			don't exist anymore in 1.0.1
			*/
			ErrJavaHelperJVMLoadFailed,					// used by external java helper dll
			ErrJavaHelperAttachCurrentThreadException,	// used by external java helper dll
			
			ErrXLibHelperLastError						// before 1.0.1 was not declared (bug!)
			};

	XErr	InitHelpers(void);
	XErr	EndHelpers(void);
	XErr	ErrorGetDescr(XErr theError, char *eNameStr, char *eMsg);
	
	/*
	*	Buffers
	*/
	/*
		Name:		Buffers
		Version:	1.0
		Date:		1/3/2000
		Author:		Valerio Ferrucci - Tabasoft
		Revision:	16/3/2000

		Comments:	Initializes a block of memory ("a buffer"). Then you can append blocks to
					this buffer without thinking about setting block size etc...
					Expands to optimized steps.
	*/
	typedef	long BufferID;

	// Initialize and End "Buffers"
	XErr	BufferInit(void);
	XErr	BufferEnd(void);

	// Create a new buffer (return -1 if fail)
	long	BufferCreate(long expandStep, XErr *errP);
	long	BufferCreateExt(long expandStep, Boolean userBit, XErr *errP);
	long	BufferCreateClear(long expandStep, XErr *errP);

	// You can destroy a buffer calling BufferFree...
	XErr	BufferFree(long id);

	//...otherwise you can call BufferGetHandle  and THEN dispose of "buffHand". In this case
	// you MUST call BufferClose to notify "Buffers" you disposed of it (don't forget it!)
	XErr	BufferClose(long id);

	// Clone a Buffer?
	XErr	BufferClone(long sourceId, long *destIDP, long lenToClone);

	// Set the size of the buffer
	XErr	BufferSetLength(long id, long newSize);

	// Reset the buffer (the same of: BufferSetLength(id, 0))
	XErr	BufferReset(long id);

	// Get the Block ref and the Len of the buffer (sizeP nil no size returned)
	BlockRef	BufferGetBlockRef(long id, long *sizeP);
	BlockRef	BufferGetBlockRefExt(long id, Ptr *thePPtr);
	BlockRef	BufferGetBlockRefExtSize(long id, long *sizeP, Ptr *thePPtr);

	#define		BufferGetUserBit(ref)	SLOT_MGR_GET_USER_BIT(ref)
	#define		BufferOnUserBit(ref)	SLOT_MGR_ON_USER_BIT(ref)
	
	// Add Strings (strings can also be encoded as "encodeType", see enum)
	XErr	BufferAddLongString(long id, Byte *fieldStrP, long encodeType, long variant);
	XErr	BufferAddPString(long id, StringPtr fieldStr, long encodeType, long variant);
	XErr	BufferAddCString(long id, char *fieldStr, long encodeType, long variant);
	XErr	BufferAddText(long id, char *textP, long size, long encodeType, long variant);

	// "variant"
	#define	kAlsoCR			1
	#define	kTagsVisible	2
	#define	kSpaceToPlus	4

	// "encodeType"
	enum{
			NO_ENC = 0,
			URL_ENC,
			ISOLATIN_ENC
			};

	// Add blocks
	XErr	BufferAddChar(long id, Byte ch);
	XErr	BufferAddBuffer(long id, Ptr buff, long sizeofBuf);
	XErr	BufferAddLong(long id, uint32_t theLong);

	// Expand a buffer to newSize
	XErr 	BufferCheck(long id, long newSize, Boolean *movedP);
	XErr	BufferOptimize(void);

	// Debug
	void	DumpBufferInfo(long id, XErr (*logFunc)(long userData, char *string), long userData);
	
	/*
	*	Text Manager
	*/
	/*
		Name:		TextUtils
		Version:	1.0
		Date:		7/3/2000
		Author:		Valerio Ferrucci - Tabasoft
		Revision:	17/3/2000

		Comments:	Encodes strings to and from Isolatin-8859 (&#n;) and URLEncode (%n).
					For MacOS adds TEC (Text Encoding Conversion) capabilities.
					And Others Text utilities
	*/
	#define	kTotEntities	152

	// Initialize and end the System
	Byte	HexStringToChar(short hexCh, Boolean isoLatin);

	// Initialize and end the System
	XErr	InitTextUtils(void);
	XErr	EndTextUtils(void);

	// Character set global (unix o mac)
	enum{
		CHARSET_UNIX = 1,
		CHARSET_MAC
	};
	void	SetCharacterSetGlobal(int charset);
	int		GetCharacterSetGlobal(int charset);


	// Encode and Decode in Isolatin-8859, allocates a new block and returns it in resultStringH
	XErr	EncodeIsolatin(Byte *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP, Boolean alsoCR, Boolean tagsVisible, Boolean useNames, Boolean extTags, long userTagList);
	XErr	DecodeIsolatin(Byte *stringP, long stringLen, 	BlockRef *resultStringP, long *resultLenP, Boolean alsoCR);
	XErr	DecodeIsolatinFast(char *readP, Boolean alsoCR, long *resultLenP);

	// Encode and Decode in URL-encode, allocates a new block and returns it in resultStringH
	XErr	EncodeURL(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean spaceToPlus, char *preStr);
	XErr	DecodeURL(Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean plusToSpace, char *preStr);
	XErr	DecodeURLFast(char *readP, Boolean plusToSpace, char *preStr, long *resultLenP);
	//XErr	EncodeEsa(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr);
	//XErr	DecodeEsa(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, char *preStr);

	//XErr	GetIsoChars(BlockRef *resultStringHP, long *resultLenP);

	XErr	OffsetsInText(char *textP, long textLen, char *stringToHilite, Boolean cs, long *offsets, long *end_offsets, long *totOffsetP, long maxOffsets, Boolean skipHTML);
	XErr	HiliteInText(char *textP, long textLen, BlockRef *textResultBlockP, long *textResultLenP, long *offsets, long *end_offsets, long totOffset, char *preStr, char *postStr);
	XErr	SubstituteExt(Ptr textP, long textLen, BlockRef *resultStringBlockP, long *resultLenP, char *oldString, long oldStringLen, Ptr newString, long newStringLen, Boolean cs, Boolean skipHTML);
	Boolean FindStringInText(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML);
	Boolean FindStringInTextSkipInside(char* stringP, int stringLen, char *textP, int textLen, long *offsetP, Boolean cs, Boolean skipHTML, int skipInsideChar);

	XErr	Encode_UTF(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP);
	XErr	Decode_UTF(const char *stringP, long stringLen, BlockRef *resultStringHP, long *resultLenP);

	XErr	HTML2Txt(BlockRef *textBlockP, long *lenP, Boolean skipHeader);
	XErr	IsoToNative(Ptr textP, long len);	// before 1.0.1 returned void
	XErr	NativeToIso(Ptr textP, long len);	// XLib >= 0x00010001

	void 	Capitalize(Byte *stringP, long stringLen);
	void	CUp2LowerStr(register char *strPtr, long subLen);
	void	CLow2UpperStr(register char *strPtr, long subLen);
	void	PUp2LowerStr(register StringPtr strPtr);
	void	PLow2UpperStr(register StringPtr strPtr);

	Byte	CharToLower(Byte ch);
	Byte	CharToUpper(Byte ch);

	// Options for _EncodeESA
	#define	LIGHT_ENCODE	1	// dont encode '.', '/', '_'

	XErr	_EncodeESA(Byte *stringP, long stringLen, BlockRef *resultStringHP,long *resultLenP, Boolean spaceToPlus, char *preStr, long options);

	/*
	*	Cache
	*/
	/*
		Name:		Cache
		Version:	1.0
		Date:		16/3/2000
		Author:		Valerio Ferrucci - Tabasoft
		Revision:	29/3/2000

		Comments:	Get files for you and, optionally, puts it in a memory cache (in case of
					multiple requests). Perfom statistics.
	*/

	// Cache file info
	typedef struct CacheItemInfo
		{		
		XFilePath		path;
		unsigned long	sum;			// ms
		unsigned long	min;			// ms
		unsigned long	max;			// ms
		unsigned long	last;
		unsigned long	hits;
		long			currentUsers;
		long			fileSize;
		unsigned long	lastAccess;		// secs
		} CacheItemInfo, *CacheItemInfoP;

	#define	CACHE_USER_SIGNIFICANT(userdata)	(*(long*)userdata)

	// This is the struct the user receives back when asks for a file
	/*
	spostata fuori da XLIB_WITH_HELPERS
	
	typedef struct
		{
		XFilePath		filePath;					// file rel path
		Byte			userDatas[CACHE_MAX_USER_DATA];	// config file path
		unsigned long	getTime;					// time when file is asked (don't modify)
		long 			posInCache;					// position in cache (don't modify)
		BlockRef		fileData;					// block to the data of file
		long			fileSize;					// length of data
		Boolean			stupid1;
		Boolean			stupid2;
		Boolean			wasInCache;					// the file was in cache?
		Boolean			dontCache;					// pad
		} CacheResult;
	*/

	// Init and End the cache system
	XErr	CFInit(Boolean wantCache, Boolean wantStat, Boolean deferredMode);
	XErr	CFEnd(void);

	// Deferred mode calls
	XErr	CFDeferredRun(long *deferredIDP);
	XErr	CFDeferredExit(long deferredID);

	// Get a file from the cache
	XErr	CFGetFile(XFilePathPtr filePath, CacheResult *cacheResP);
	XErr	CFGetFileInfo(XFilePathPtr filePath, CacheItemInfoP itemInfoP);

	// Get file having the text (just to increment gsCurrentUsers)
	XErr	CFGetFileSpecial(XFilePathPtr filePath, CacheResult *cacheResP, char *textP);
	//XErr	CFGetIndFile(long cacheID, CacheResult *cacheResP);

	// Release the file
	XErr	CFReleaseFile(CacheResult *cacheResP, long deferredID);

	// Flushing
	XErr	CFFlushFile(XFilePathPtr filePath);
	XErr	CFFlushFilesMatching(long userData);

	// Empties the cache
	XErr	CFFlush(Boolean toActivate);

	// Checks if must reload some files
	Boolean	CFNeedReload(void);
	XErr	CFReload(void);
	
	typedef	void	(*CFLoopCallBack)(Byte *userData, long param);
	
	XErr	CFLoop(CFLoopCallBack CallBack, long param);

	// Get Info on files, returns N (totItemsP) CacheItemInfo
	// If you want cacheItemInfoH allocated for you set it to 0 before calling CFGetCacheInfo
	XErr	CFGetCacheInfo(BlockRef *cacheItemInfoP, long *totItemsP, unsigned long *totalSizeP, long userData);
	XErr	CFGetCacheFileInfo(char *filePath, CacheItemInfoP infosP);

	#ifdef __MAC_XLIB__
		/*
		*	Mac Window Log
		*/
		#define	MAC_LOG_MAX_LINE_SIZE		255

		typedef	void	(*MacLogProcessFunc)(MenuHandle menuH, long menuID, long itemID);

		// Log su Window
		XErr		InitLogWindow(char* appName, long *winRefP, StringPtr optString);
		void		EndLogWindow(long winRef);

		void 		WindowLogAddMenuItem(char *menuName, CStr63 *processItemString, MacLogProcessFunc *processFunc, long totItems);
		void		MacLogGetMenu(long menuIndex, MenuHandle *menuH);
		void 		MacLogCheckItem(long menuID, long itemID, Boolean checkIt);

		Boolean 	UpdateLogWindow(WindowPtr wind);

		XErr		CStringToLogWindow(long winRef, char *cString, Boolean time);
		XErr		StringToLogWindow(long winRef, const StringPtr cString);
		XErr		CStringToLogWindowExt(long winRef, char *cString, Boolean time, Boolean addToLast, RGBColor *color);
		XErr		StringToLogWindowExt(long winRef, const StringPtr strP, Boolean addToLast, RGBColor *color);

		void		ShowLogWindow(long winRef);
		void		HideLogWindow(long winRef);

		// call this in your event loop
		Boolean		IsLogWindowEvent(long winRef, EventRecord *theEventP, Boolean *quitProgramP);
	#endif
	
	/*
	*	FLog
	*/
	// Log on File
	XErr	InitLog(XFilePathPtr filePath, XFileRef *logRefNumP);
	XErr	EndLog(XFileRef	*logRefNumP);
	XErr	CStringToLog(XFileRef logRefNum, char *cString, Boolean time);

	/*
	*	Dicotomic List Manager
	*/
	#define	GLOBAL_LIST		true
	#define	LOCAL_LIST		false

	enum{
			ID_LIST = 1,
			NAME_LIST,
			NAMECS_LIST
			};

	// Sort
	enum{
			kChoose = 0,
			kBubble,
			kShell
			};



	// ListRef (é una long)
	typedef	long DLMRef;

	// Flags
	#define	kFixedSize				1L
	#define	kCostant				2L
	#define	kIsArray				4L
	#define	kNoDestructor			8L
	#define	kLocked					16L
	#define	kHidden					32L
	#define	kPublished				64L
	#define	kIsDlm					128L

	// Turn Flags (if array)
	#define	kDLMMain					1L
	#define	kDLMElements				2L
	#define	kDLMWhole					kDLMMain + kDLMElements
		
	// Array definitions
	typedef struct {
					long	ind;
					CStr63	ind_name;
					} DLM_ArrayIndexRec;

	// DLMBuffer
	typedef struct {
					Ptr		bufferP;
					long	bufferLen;
					long	userData;
			unsigned short	flags;
					short	pad;
					} DLMBuffer;

	// undefined user data
	#define	DLM_USERDATA_DEFAULT	0x7FFFFFFF

	#define	LIST_USER_DATA_DIM	12

	typedef XErr	(*DLMLoopCallBack)(DLMRef dlRef, long objID, unsigned short flags, long userData, long param);
	// must return true if are to swap
	typedef Boolean	(*DLMSortCallBack)(DLMRef dlRef, long objID1, long userData1, long objID2, long userData2, long param, XErr *errP);
	typedef Boolean	(*DLMSortCallBackFast)(Ptr value1, long len1, Ptr value2, long len2, long param);

	void	DLM_CheckList(DLMRef dlRef);

	XErr	DLM_Create(DLMRef *dlRefP, long listType, long global);
	XErr	DLM_CreateAcceptDupl(DLMRef *dlRefP, long listType, long global);

	XErr	DLM_ListInfo(DLMRef dlRef, long *listTypeP, Byte *listUserDataP, Boolean *globalP, long *totalSizeP);
	XErr	DLM_SetListUserData(DLMRef dlRef, Byte *listUserData);

	XErr	DLM_Dispose(DLMRef *dlRefP, DLMLoopCallBack callBack, long param);
	XErr	DLM_DisposeGlobal(DLMRef *dlRefP, DLMLoopCallBack callBack, long param);
	void	DLM_ResetList(DLMRef dlRef, DLMLoopCallBack callBack, long param, long level, Boolean resizeBlocks);
	XErr	DLM_CloneList(DLMRef sourceList, DLMRef *destListP);
	XErr	DLM_ConcatLists(DLMRef list1, DLMRef list2, char *nameError);

	XErr	DLM_Load(XFilePathPtr filePath, long listType, Boolean global, DLMRef *dlRefP);
	XErr	DLM_Close(DLMRef *dlRefP, DLMLoopCallBack callBack, long param, Boolean ignoreGlobal);
	XErr	DLM_SaveList(DLMRef dlRef);

	XErr	DLM_ReverseList(DLMRef *dlRefP);
	XErr	DLM_SortList(DLMRef *dlRefP, DLMSortCallBack callback, DLMSortCallBackFast callbackFast, long param, long alg);

	long	DLM_NewObjAtPos(DLMRef dlRef, char *name, Ptr dataP, long dataLen, long userData, unsigned short flags, long atPos, XErr *errP);
	#define	DLM_NewObj(dlRef, name, dataP, dataLen, userData, flags, errP)		DLM_NewObjAtPos(dlRef, name, dataP, dataLen, userData, flags, 0, errP)

	XErr	DLM_SetObjFlag(DLMRef dlRef, long objID, unsigned short flags);

	XErr	DLM_GetObj(DLMRef dlRef, long objID, Ptr dataP, long *dataLenP, long offset, long *userDataP);
	XErr	DLM_GetObjBlock(DLMRef dlRef, long objID, Ptr buffer, Ptr *resultP, long *resultLenP, BlockRef *refP);


	// Private
	typedef int 	(*CompareFunc)(register char *str1, register char *str2);

	long	_GetObjID(DLMRef dlRef, char *name, long index, long *flagsP, long *userDataP, CompareFunc cFunc, long *lengthP);
	int		_BeginCompare(register char *str1, register char *str2);

	#define	DLM_GetObjID(dlRef, name, flagsP, userDataP)				_GetObjID(dlRef, name, 0, flagsP, userDataP, nil, nil)
	#define	DLM_GetObjIDExt(dlRef, name, flagsP, userDataP, lengthP)	_GetObjID(dlRef, name, 0, flagsP, userDataP, nil, lengthP)
	#define	DLM_GetIndexObjID(dlRef, name, index, flagsP, userDataP)	_GetObjID(dlRef, name, index, flagsP, userDataP, nil, nil)
	#define	DLM_GetObjID_Begins(dlRef, name, index, flagsP, userDataP)	_GetObjID(dlRef, name, index, flagsP, userDataP, _BeginCompare, nil)

	XErr	DLM_GetArrayInfo(DLMRef dlRef, long objID, unsigned short *flagsP, DLMRef *arrayDLRefP, long *arrayDimP, long *arrayUserDataP);
	XErr	DLM_SetArrayElemClass(DLMRef dlRef, long objID, long arrayUserData);
	XErr	DLM_GetInfo(DLMRef dlRef, long objID, unsigned short *flagsP, long *userDataP, char *name);
	XErr	DLM_TurnOnFlag(DLMRef dlRef, long objID, long flagToOn, long turnFlag);
	XErr	DLM_TurnOffFlag(DLMRef dlRef, long objID, long flagToOff, long turnFlag);

	XErr	DLM_ResolveArrayElem(DLMRef dlRef, long objID, DLM_ArrayIndexRec *coords, short numCoords, short *lastResolvedP, Boolean toExpand, Boolean *expandedP, DLMRef *resultDlRefP, long *resultObjIDP, long *resultUserDataP, DLMRef elemToAddList, long elemToAddID, DLMBuffer *dlmbufferP, long arrayUserData, long *arrayElementClassIDP);
	long	DLM_NewArray(DLMRef dlRef, char *name, long userData, unsigned short flags, /*unsigned long maxDim, */long arrayUserData, DLMRef *arrayDLRefP, XErr *errP);
	//XErr	DLM_NewArrayInObject(DLMRef dlRef, long objID, long userData, long flags, unsigned long maxDim, long arrayUserData, DLMRef *arrayDLRefP, DLMLoopCallBack callBack, long param);
	XErr	DLM_SetArrayDim(DLMRef dlRef, long objID, long newDim, Boolean syncOnly, DLMLoopCallBack callBack, long param);
	Boolean	DLM_IsArray(DLMRef dlRef, long objID);
	XErr	DLM_UpdateArrayDLRef(DLMRef dlRef, long objID, DLMRef newArDlRef);

	XErr	DLM_ModifyObj(DLMRef dlRef, long objID, Ptr dataP, long dataLen, long userData, DLMLoopCallBack callBack, long param, DLMLoopCallBack notifyProc);
	XErr	DLM_WriteObj(DLMRef dlRef, long objID, Ptr dataP, long dataLen, long atOffset);
	XErr	DLM_ModifyObjExt(DLMRef dlRef, long objID, DLMRef valueList, long valueID, DLMLoopCallBack callBack, long param, DLMLoopCallBack notifyProc);
	XErr	DLM_AddToObj(DLMRef dlRef, long objID, Ptr pToAdd, long pToAddLen);
	XErr	DLM_ConcatObjs(DLMRef dlRef, long objID, DLMRef dlRef2, long objID2);
	XErr	DLM_CopyObj(DLMRef sourceList, long sourceObjID, DLMRef destList, char *destName, unsigned short destObjectFinalFlags, long *destId);
	XErr	DLM_InsertObj(DLMRef sourceList, long sourceObjID, DLMRef destList, char *destName, unsigned short destObjectFinalFlags, long *destId, long pos);
	//XErr	DLM_SetObjChar(DLMRef dlRef, long objID, long index, Byte theChar);
	XErr	DLM_SetName(DLMRef dlRef, long objID, char *name);
	XErr	DLM_SetUserData(DLMRef dlRef, long objID, long newUserData);
	XErr	DLM_ResetObj(DLMRef dlRef, long objID, DLMLoopCallBack callBack, long param);

	XErr	DLM_GetTotObjs(DLMRef dlRef, long *totObjsP, Boolean filterUserData);
	XErr	DLM_GetIndObj(DLMRef dlRef, long index, Ptr	dataP, long *dataLenP, long offset, long *userDataP, 
												long *objIDP, char *name, Boolean sorted, Boolean filterUserData);

	XErr	DLM_DeleteObj(DLMRef dlRef, long objID, DLMLoopCallBack callBack, long param);
	XErr	DLM_DeleteObjects(DLMRef listRef, long firstToRemove, long lastToRemove, DLMLoopCallBack callBack, long param);
	XErr	DLM_SwapObjects(DLMRef dlRef, long objID1, long objID2);

	//XErr	DLM_SetListByteUserData(DLMRef dlRef, Byte byte_userData);
	//XErr	DLM_GetListUserData(DLMRef dlRef, unsigned long *luDataP, Byte *byte_userDataP);

	XErr	_DMLLoop(DLMRef dlRef, DLMLoopCallBack callBack, long param, Boolean insideArrays, Boolean checkNoDestructor, long *idErrP);
	
	#define	DLM_Loop(dlRef, callBack, param, insideArrays, checkNoDestructor)				_DMLLoop(dlRef, callBack, param, insideArrays, checkNoDestructor, nil)
	#define	DLM_LoopExt(dlRef, callBack, param, insideArrays, checkNoDestructor, idErrP)	_DMLLoop(dlRef, callBack, param, insideArrays, checkNoDestructor, idErrP)

	long	DLM_NewObjWithSuper(DLMRef dlRef, char *name, Ptr dataP, long dataLen, long userData, unsigned short flags, long superList, long superID, XErr *errP);
	XErr	DLM_NewSuperObj(DLMRef dlRef, long objID, long superList, long superID, DLMRef *newList, long *newSuperID);
	long	DLM_GetSuperObjID(DLMRef dlRef, long objID, DLMRef *superList);

	// Fast Operations
	XErr	DLM_IncrementLong(DLMRef dlRef, long objID, Boolean toDecr);
	XErr	DLM_IncrementUnsigned(DLMRef dlRef, long objID, Boolean toDecr);
	XErr	DLM_IncrementDouble(DLMRef dlRef, long objID, Boolean toDecr);
	XErr	DLM_IncrementLongLong(DLMRef dlRef, long objID, Boolean toDecr);

	void	DLM_SetGlobalOk(Boolean okGlobal);

	// Debug
	void	DLM_CheckList(DLMRef dlRef);

	/*
	*	HTUU
	*/
	/*                              ENCODING TO PRINTABLE CHARACTERS
	                                             
	   File module provides functions HTUU_encode() and HTUU_decode() which convert a buffer
	   of bytes to/from RFC 1113 printable encoding format. This technique is similar to the
	   familiar Unix uuencode format in that it maps 6 binary bits to one ASCII character (or
	   more aptly, 3 binary bytes to 4 ASCII characters).  However, RFC 1113 does not use the
	   same mapping to printable characters as uuencode.
	   
	 */
	/*

	Macros for declarations

	 */
	#define PUBLIC                  /* Accessible outside this module     */
	#define PRIVATE static          /* Accessible only within this module */

	#ifdef __STDC__
	#define CONST const             /* "const" only exists in STDC */
	#define NOPARAMS (void)
	#define PARAMS(parameter_list) parameter_list
	#define NOARGS (void)
	#define ARGS1(t,a) \
	                (t a)
	#define ARGS2(t,a,u,b) \
	                (t a, u b)
	#define ARGS3(t,a,u,b,v,c) \
	                (t a, u b, v c)
	#define ARGS4(t,a,u,b,v,c,w,d) \
	                (t a, u b, v c, w d)
	#define ARGS5(t,a,u,b,v,c,w,d,x,e) \
	                (t a, u b, v c, w d, x e)
	#define ARGS6(t,a,u,b,v,c,w,d,x,e,y,f) \
	                (t a, u b, v c, w d, x e, y f)
	#define ARGS7(t,a,u,b,v,c,w,d,x,e,y,f,z,g) \
	                (t a, u b, v c, w d, x e, y f, z g)
	#define ARGS8(t,a,u,b,v,c,w,d,x,e,y,f,z,g,s,h) \
	                (t a, u b, v c, w d, x e, y f, z g, s h)
	#define ARGS9(t,a,u,b,v,c,w,d,x,e,y,f,z,g,s,h,r,i) \
	                (t a, u b, v c, w d, x e, y f, z g, s h, r i)
	#define ARGS10(t,a,u,b,v,c,w,d,x,e,y,f,z,g,s,h,r,i,q,j) \
	                (t a, u b, v c, w d, x e, y f, z g, s h, r i, q j)

	#else  /* not ANSI */
	#ifdef __WIN_XLIB__
		#ifndef _WINDOWS
			#define	_WINDOWS
		#endif
	#endif

	#ifndef _WINDOWS
	#define CONST
	#endif
	#define NOPARAMS ()
	#define PARAMS(parameter_list) ()
	#define NOARGS ()
	#define ARGS1(t,a) (a) \
	                t a;
	#define ARGS2(t,a,u,b) (a,b) \
	                t a; u b;
	#define ARGS3(t,a,u,b,v,c) (a,b,c) \
	                t a; u b; v c;
	#define ARGS4(t,a,u,b,v,c,w,d) (a,b,c,d) \
	                t a; u b; v c; w d;
	#define ARGS5(t,a,u,b,v,c,w,d,x,e) (a,b,c,d,e) \
	                t a; u b; v c; w d; x e;
	#define ARGS6(t,a,u,b,v,c,w,d,x,e,y,f) (a,b,c,d,e,f) \
	                t a; u b; v c; w d; x e; y f;
	#define ARGS7(t,a,u,b,v,c,w,d,x,e,y,f,z,g) (a,b,c,d,e,f,g) \
	                t a; u b; v c; w d; x e; y f; z g;
	#define ARGS8(t,a,u,b,v,c,w,d,x,e,y,f,z,g,s,h) (a,b,c,d,e,f,g,h) \
	                t a; u b; v c; w d; x e; y f; z g; s h;
	#define ARGS9(t,a,u,b,v,c,w,d,x,e,y,f,z,g,s,h,r,i) (a,b,c,d,e,f,g,h,i) \
	                t a; u b; v c; w d; x e; y f; z g; s h; r i;
	#define ARGS10(t,a,u,b,v,c,w,d,x,e,y,f,z,g,s,h,r,i,q,j) (a,b,c,d,e,f,g,h,i,j) \
	                t a; u b; v c; w d; x e; y f; z g; s h; r i; q j;
	                
	        
	#endif /* __STDC__ (ANSI) */

	#ifndef NULL
	#define NULL ((void *)0)
	#endif

	/*

	Booleans

	 */
	/* Note: GOOD and BAD are already defined (differently) on RS6000 aix */
	/* #define GOOD(status) ((status)38;1)   VMS style status: test bit 0         */
	/* #define BAD(status)  (!GOOD(status))  Bit 0 set if OK, otherwise clear   */

	#ifndef _WINDOWS
	#ifndef __INTEL__
		#ifndef BOOLEAN_DEFINED
	        typedef char    BOOLEAN;                /* Logical value */
		#ifndef CURSES
	#endif
	#ifndef TRUE
	#define TRUE    (BOOLEAN)1
	#define FALSE   (BOOLEAN)0
	#endif
	#endif   /*  CURSES  */
	#endif   /* _WINDOWS */
	#define BOOLEAN_DEFINED
	#endif

	//#ifndef BOOL
	//#define BOOL BOOLEAN
	//#endif
	#ifndef YES
	#define YES             (BOOL)1
	#define NO              (BOOL)0
	#endif

	#ifndef HTMIN
	#define HTMIN(a,b) ((a) <= (b) ? (a) : (b))
	#define HTMAX(a,b) ((a) >= (b) ? (a) : (b))
	#endif

	XErr HTUU_encodeExt(Ptr htextPtr, long lentext, BlockRef *h64BlockPtr, long *h64LengthPtr, short linelength);
	PUBLIC int HTUU_encode PARAMS((unsigned char *bufin,
	                               unsigned int nbytes,
	                               char *bufcoded));

	PUBLIC int HTUU_decode PARAMS((char *bufcoded,
	                               unsigned char *bufplain,
	                               int outbufsize));

	/*
	*	Pool
	*/
	/*
		Name:		Pool
		Version:	1.0
		Date:		31/7/2001
		Author:		Valerio Ferrucci - Tabasoft
		Revision:	-

		Comments:	Pool manager
	*/
	#define		PoolRef			char*

	XErr	NewPool(unsigned long slotSize, unsigned long slotCount, PoolRef *poolRef);
	XErr	DeletePool(PoolRef poolRef);
	XErr	PoolNewPtr(PoolRef poolRef, Ptr *resultPtrP, uint32_t *slotP);
	void	PoolDisposePtr(PoolRef poolRef, uint32_t slot);

	//#ifdef JAVA_ENABLED
	/*
	*	Java
	*/
	/*#if __MACOSX__
		#include <JavaVM/jni.h>
	#else
		#include "jni.h"
	#endif*/


	XErr	XLibGetMainJVM_API(void **jvmEnvP);		// >= 1.0.1
	XErr	XLibInit_JVM_API(LogCallBack logCallBack, void *userData, long helperDllRef);		// >= 1.0.1
	XErr	XLibEnd_JVM_API(void);					// >= 1.0.1
	XErr	XLibAttachJVM_API(void **envPPtr);		// >= 1.0.1
	XErr	XLibDetachJVM_API(void);				// >= 1.0.1
	void	XLibReset_JVM_API(void);				// >= 1.0.1

	/*
	XErr	Init_JVM(void);
	XErr	End_JVM(void);

	XErr	CString2jstring(JNIEnv *env, char *stringP, jstring *theStringP, char *strError);
	XErr	jstring2CString(JNIEnv *env, jstring jObject, char *str, long maxLength, char *strError);
	XErr	jstring2CStringExt(JNIEnv *env, jstring jObject, BlockRef *resultBlockRefP, long *resultLenP, char *strError);

	XErr	GetStringField(JNIEnv *envP, jclass theClass, char *fieldName, char *fieldStr, long maxStorage, char *strError);
	XErr	GetIntField(JNIEnv	*envP, jclass theClass, char *fieldName, long *fieldValue, char *strError);
	XErr	GetObjectField(JNIEnv *envP, jclass theClass, char *fieldName, char *fieldSignature, jobject *resultObjectP, char *strError);
	*/
	//#endif

#endif

//===========================================================================================
//
//-------------------------------------- X Sound (MacOS) ------------------------------------
//
//===========================================================================================

#ifdef __MAC_XLIB__
	XErr	XPlaySound(long sndID);
	//Boolean	GetFSSpecFromPOSIXPath(const char *path, FSSpec *spec);
#endif

/*
* private
*/
EXP XErr	_X_RegisterXLibCallBacks(long callsBackPtr);
EXP long	_X_XLibVersion(long callerVersion, XErr *errP);
#endif	// END __XLIB__
