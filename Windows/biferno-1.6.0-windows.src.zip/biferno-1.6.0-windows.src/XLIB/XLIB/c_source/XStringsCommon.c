/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XStringsCommon.c,v 1.20 2008-09-19 13:40:07 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// for LONGLONG transformation
static LONGLONG	powers[19] = {	
									1,
									10, 
									100, 
									1000, 
									10000, 
									100000, 
									1000000, 
									10000000, 
									100000000, 
									1000000000, 
								#ifdef __VISUALCPP__
									10000000000,
									100000000000,
									1000000000000,
									10000000000000,
									100000000000000,
									1000000000000000,
									10000000000000000,
									100000000000000000,
									1000000000000000000};
								#else
									10000000000LL,
									100000000000LL,
									1000000000000LL,
									10000000000000LL,
									100000000000000LL,
									1000000000000000LL,
									10000000000000000LL,
									100000000000000000LL,
									1000000000000000000LL};
								#endif

//extern Byte	isoChar[];		// is in XStrings[OS].c

#ifdef __LITTLE_ENDIAN__
	#define	CRLF		0x0a0d	//'\\n\\r'
#else
	#define	CRLF		'\r\n'
#endif
// Common
//===========================================================================================
/*static int cmpStr(Ptr ptr1, Ptr ptr2, long count, long fLen1, long fLen2, Boolean cs)
{
register Byte		ch1, ch2;

	if (cs)
	{	do	{
			ch1 = *(Byte*)ptr1++;
			ch2 = *(Byte*)ptr2++;
			} while( (ch1 == ch2) && --count);
	}
	else
	{	do	{
			ch1 = *(Byte*)ptr1++;
			ch2 = *(Byte*)ptr2++;
		#ifdef __XLIB_WITH_HELPERS__
			ch1 = CharToLower(ch1);
			ch2 = CharToLower(ch2);
		#else
			LOW_CHAR(ch1);
			LOW_CHAR(ch2);
		#endif
			} while( (ch1 == ch2) && --count);
	}

	if NOT(count)
		{
		if (fLen1 == fLen2)
			return 0;			// parole identiche
		else if (fLen1 > fLen2)
			return -1;			// ptr1 > ptr2					
		else
			return 1;			// ptr1 < ptr2
		}
	else
		{
		if (ch1 > ch2)
			return -1;		// ptr1 > ptr2					
		else
			return 1;		// ptr1 < ptr2
		}
}
*/
#if __MWERKS__
#pragma mark-
#endif

// Pascal
//===========================================================================================
/* Given two pointer to pascal strings
compares them and return:
"-1" str1 > str2
" 0" str1 == str2
" 1" str2 > str1
*/
int 	PCompareStrings_cs(register StringPtr str1, register StringPtr str2)
{
register int		count, fLen1, fLen2;
register Byte		ch1, ch2;

	fLen1 = *(Byte*)str1++;
	fLen2 = *(Byte*)str2++;
	if (fLen1 < fLen2)
		count = fLen1;
	else
		count = fLen2;
	do	{
		ch1 = *(Byte*)str1++;
		ch2 = *(Byte*)str2++;
		} while( (ch1 == ch2) && --count);
	if NOT(count)
		{
		if (fLen1 == fLen2)
			return 0;			// parole identiche
		else if (fLen1 > fLen2)
			return -1;			// str1 > str2					
		else
			return 1;			// str1 < str2
		}
	else
		{
		if (ch1 > ch2)
			return -1;		// str1 > str2					
		else
			return 1;		// str1 < str2
		}
}

//===========================================================================================
/* Given two pointer to pascal strings
compares them and return:
"-1" str1 > str2
" 0" str1 == str2
" 1" str2 > str1
*/
int 	PCompareStrings(register StringPtr str1, register StringPtr str2)
{
register int		count, fLen1, fLen2;
register Byte		ch1, ch2;

	fLen1 = *(Byte*)str1++;
	fLen2 = *(Byte*)str2++;
	if (fLen1 < fLen2)
		count = fLen1;
	else
		count = fLen2;
	do	{
		ch1 = *(Byte*)str1++;
		ch2 = *(Byte*)str2++;
		#ifdef __XLIB_WITH_HELPERS__
			ch1 = CharToLower(ch1);
			ch2 = CharToLower(ch2);
		#else
			LOW_CHAR(ch1);
			LOW_CHAR(ch2);
		#endif
		} while( (ch1 == ch2) && --count);

	if NOT(count)
		{
		if (fLen1 == fLen2)
			return 0;			// parole identiche
		else if (fLen1 > fLen2)
			return -1;			// str1 > str2					
		else
			return 1;			// str1 < str2
		}
	else
		{
		if (ch1 > ch2)
			return -1;		// str1 > str2					
		else
			return 1;		// str1 < str2
		}
}

//===========================================================================================
/*Boolean 	PAreStrEqual(register StringPtr strPtr1, register StringPtr strPtr2)
{
	register unsigned char	k = *strPtr1 + 1;

	while (*strPtr1++ == *strPtr2++ && --k);
	return(k == 0);
}*/

//===========================================================================================
void 	PAddChar(StringPtr DestStr, Byte ch)
{
	DestStr[++(*DestStr)] = ch;
}

//===========================================================================================
void 	PAddStr(register StringPtr destStr, register StringPtr strToAdd)
{
register Byte count, dLen;

	if NOT (count = *strToAdd++)	// source len
		return;

	dLen = *destStr;
	if (dLen >= (Byte)(255 - count) )
		{
		if NOT(count = 255 - dLen)
			return;
		}

	*destStr++ += count;
	destStr += dLen;
	do	{
		*destStr++ = *strToAdd++;
		} while(--count);
}

//===========================================================================================
void	PEquStr(register StringPtr destStr, register StringPtr sourStr)
{
register int	len = *sourStr + 1;

	do	{
		*destStr++ = *sourStr++;
		} while(--len);
}

//===========================================================================================
StringPtr PSubstitute(StringPtr str, Byte oldChar, Byte newChar)
{
int		len = str[0];
char	*strP = (Ptr)&str[1];
	
	if (len)
	{	do
		{	if (*strP == oldChar)
				*strP = newChar;
			strP++;
		} while(--len);
	}
	
return str;
}

//===========================================================================================
void PCutRightZeroDec(StringPtr theStr, int decDigit)
{
register Byte	dLen = theStr[0], i = decDigit, *tP;

tP = &theStr[dLen];
while ((*tP == '0') && --i)
	--tP;

dLen -= (decDigit - i);
if (i == 0)
	dLen--;		// tolgo anche la virgola
theStr[0] = dLen;
}

//===========================================================================================
XErr		PStringToNumExt(StringPtr str, long *numP, unsigned long *uLongP)
{
long	strLen = str[0];
double	theDouble;
//XErr	err = noErr;

	if (numP)
	{	if (strLen < 10)
			PStringToNum(str, numP);
		else if (strLen > 10)
			return XError(kXLibError, ErrXLibNumOverFlow);
		else
		{	theDouble = PStrToReal(str);
			if (theDouble <= 0x7FFFFFFF)
				*numP = (long)theDouble;
			else
				return XError(kXLibError, ErrXLibNumOverFlow);
		}
	}
	else if (uLongP)
	{	if (strLen < 10)
		{	long	aNum;
			PStringToNum(str, &aNum);
			*uLongP = aNum;
		}
		else
		{	theDouble = PStrToReal(str);
			if (theDouble <= 0xFFFFFFFF)
				*uLongP = (unsigned long)theDouble;
			else
				return XError(kXLibError, ErrXLibNumOverFlow);
		}
	}
	
return noErr;
}

//===========================================================================================
void		PUnsignedToString(unsigned long num, StringPtr str)
{
CStr255	cStr;

	sprintf(cStr, "%lu", num);
	if (str[0] >= CLen(cStr))
		CToPascal(cStr, str);
}

//===========================================================================================
XErr	PStringToLongNum(StringPtr str, LONGLONG *numP)
{
LONGLONG	ll;
Byte		ch;
int			n, strLen;
XErr		err = noErr;
LONGLONG	*powP = powers;
Boolean		minus = false;

	ll = 0;
	strLen = str[0];
	if ((strLen > 0) && (strLen < 20))
	{	do {
			ch = str[strLen];
			if ((ch >= '0') && (ch <= '9'))
				n = ch - '0';
			else if (ch == '-')
			{	minus = true;
				if (strLen == 1)
					break;
				else
					return -2;
			}
			else
				return -2;
			ll += n * *powP++;
		} while (--strLen);
		if (minus)
			ll = -ll;
	}
	else
		err = XError(kXLibError, ErrXLibNumOverFlow);
	
*numP = ll;
return err;
}

//===========================================================================================
double 		PStrToReal(const StringPtr sP)
{
CStr255		cStr;

	PascalToC(sP, cStr);
	return atof(cStr);
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// return 0 if equals
int 	CCompareStrings_cs(register char *str1, register char *str2)
{
long	res;

	res = strcmp(str1, str2);
	if (res > 0)
		return -1;
	else if (res < 0)
		return +1;
	else
		return 0;
}

//===========================================================================================
int 	CCompareStrings(register char *str1, register char *str2)
{
register int	ch1, ch2;

	do	{
		ch1 = *(Byte*)str1++;
		if not(ch1)
			{
			if (*str2)
				return 1;				// str1 < str2 else equal
			else
				return 0;				// str1 == str2			
			}
		
		ch2 = *(Byte*)str2++;
		if not(ch2)
			return -1;					// str1 > str2 else equal
		#ifdef __XLIB_WITH_HELPERS__
			ch1 = (int)CharToLower((Byte)ch1);
			ch2 = (int)CharToLower((Byte)ch2);
		#else
			LOW_CHAR(ch1);
			LOW_CHAR(ch2);
		#endif
		} while(ch1 == ch2);

	if (ch1 > ch2)
		return -1;		// str1 > str2					
	else
		return 1;		// str1 < str2
}

//===========================================================================================
int 	CCompareStringsExt(register char *str1, long len1, register char *str2, long len2)
{
register int	ch1, ch2;


	do	{
		ch1 = *(Byte*)str1++;
		if NOT(len1--)
			{
			if (len2)
				return 1;				// str1 < str2 else equal
			else
				return 0;				// str1 == str2			
			}
		
		ch2 = *(Byte*)str2++;
		if NOT(len2--)
			return -1;					// str1 > str2 else equal
		#ifdef __XLIB_WITH_HELPERS__
			ch1 = (int)CharToLower((Byte)ch1);
			ch2 = (int)CharToLower((Byte)ch2);
		#else
			LOW_CHAR(ch1);
			LOW_CHAR(ch2);
		#endif
		} while(ch1 == ch2);

	if (ch1 > ch2)
		return -1;		// str1 > str2					
	else
		return 1;		// str1 < str2
}

//===========================================================================================
/*int 	CCompareStrings(register char *str1, register char *str2)
{
register int		count, fLen1, fLen2;
register Byte		ch1, ch2;

	fLen1 = CLen(str1);
	fLen2 = CLen(str2);
	if (fLen1 < fLen2)
		count = fLen1;
	else
		count = fLen2;
	do	{
		ch1 = *(Byte*)str1++;
		LOW_CHAR(ch1);					// porta A-Z in minuscolo
		ch2 = *(Byte*)str2++;
		LOW_CHAR(ch2);					// porta A-Z in minuscolo
		} while( (ch1 == ch2) && --count);

	if NOT(count)
		{
		if (fLen1 == fLen2)
			return 0;			// parole identiche
		else if (fLen1 > fLen2)
			return -1;			// str1 > str2					
		else
			return 1;			// str1 < str2
		}
	else
		{
		if (ch1 > ch2)
			return -1;		// str1 > str2					
		else
			return 1;		// str1 < str2
		}
}*/

//===========================================================================================
int		CLen(const char *string)
{
	return strlen(string);

/*register const char	*s = string;

	while (*s++);
	return (s - string - 1);*/
}

//===========================================================================================
int		CAddStr(register char *destStr, register char *strToAdd)
{
char	ch, *destStrStart = destStr;

while (*destStr++);		// loop to string terminator

destStr--;				// step back to overwrite the zero

do	{					// copy string for append
	ch = *strToAdd++;
	*destStr++ = ch;
	} while(ch);

return (destStr - destStrStart - 1);
}

//===========================================================================================
int 	CAddChar(register char* s, Byte ch)
{
char	*sStart = s;

	while (*s++);
	*(s - sizeof(char)) = ch;
	*s = 0;

return (s - sStart);
}

//===========================================================================================
int		CAddStrX(register char *destStr, register char *strToAdd, int destLen)
{
char	ch, *destStrStart = destStr;

destStr += destLen;		// skip to string terminator

do	{					// copy string for append
	ch = *strToAdd++;
	*destStr++ = ch;
	} while(ch);

return (destStr - destStrStart - 1);
}

//===========================================================================================
int 	CAddCharX(register char* s, Byte ch, int sLen)
{
char	*sStart = s;

	s += sLen;
	*s++ = ch;
	*s = 0;

return (s - sStart);
}

//===========================================================================================
int		CEquStrCK(register char *destStr, register char *sourStr, int maxChars)
{
char	ch;
int		chCnt = 0;

do	{
	ch = *sourStr++;
	*destStr++ = ch;
	if (++chCnt >= maxChars)
		{
		chCnt = 0;		// will be -1 on ret (signal we exceeded max and copied only maxChars)
		*destStr = 0;
		break;
		}
	} while(ch);

return (chCnt - 1);
}

//===========================================================================================
// copies also the final 0
int		CEquStr(register char *destStr, register char *sourStr)
{
char	ch, *destStrStart = destStr;

do	{
	ch = *sourStr++;
	*destStr++ = ch;
	} while(ch);

return (destStr - destStrStart - 1);
}

//===========================================================================================
int	CSubstitute(char *strP, Byte oldChar, Byte newChar)
{	
char	*strPStart = strP;

	if (*strP)	// string empty?
	{	do
		{	if (*strP == oldChar)
				*strP = newChar;
			strP++;
		} while(*strP);
	}
return (strP - strPStart);
}

//===========================================================================================
XErr		CStringToNumExt(char *str, long *numP, unsigned long *uLongP)
{
long	strLen = CLen(str);
double	theDouble;
//XErr	err = noErr;

	if (numP)
	{	if NOT(strLen)
			*numP = 0;
		else
		{	if (strLen < 10)
				CStringToNum(str, numP);
			else if (strLen > 10)
				return XError(kXLibError, ErrXLibNumOverFlow);
			else
			{	theDouble = CStrToReal(str);
				if (theDouble <= 0x7FFFFFFF)
					*numP = (long)theDouble;
				else
					return XError(kXLibError, ErrXLibNumOverFlow);
			}
		}
	}
	else if (uLongP)
	{	if NOT(strLen)
			*uLongP = 0;
		else
		{	long	aLong;
		
			if (strLen < 10)
			{	CStringToNum(str, &aLong);
				*uLongP = aLong;
			}
			else
			{	theDouble = CStrToReal(str);
				if (theDouble <= 0xFFFFFFFF)
					*uLongP = (unsigned long)theDouble;
				else
					return XError(kXLibError, ErrXLibNumOverFlow);
			}
		}
	}
	
return noErr;
}

//===========================================================================================
void		CUnsignedToString(unsigned long num, char *str)
{
	sprintf(str, "%lu", num);
}

//===========================================================================================
void		CLongNumToString(LONGLONG ll, char *str)
{
int			n, powPos = 18;
Boolean		canPutZero = false;
LONGLONG	*tempLLPtr, templl;

	if (ll)
	{	if (ll < 0)
		{	ll = -ll;
			*str++ = '-';
		}
		tempLLPtr = &powers[18];
		do {
			templl = *tempLLPtr--;
			if ((n = (int)(ll / templl)) || canPutZero)
			{	*str++ = '0' + n;
				canPutZero = true;
				ll -= (templl * n);
			}	
		} while (--powPos >= 0);
	}
	else
		*str++ = '0';
	*str = 0;
}

//===========================================================================================
XErr		CStringToLongNum(char *str, long strLen, LONGLONG *numP)
{
LONGLONG	ll;
Byte		ch;
int			n;
XErr		err = noErr;
LONGLONG	*powP = powers;
Boolean		minus = false;

	ll = 0;
	if (strLen)
	{	if ((strLen > 0) && (strLen < 20))
		{	strLen--;
			do {
				ch = str[strLen];
				if ((ch >= '0') && (ch <= '9'))
					n = ch - '0';
				else if (ch == '-')
				{	minus = true;
					if NOT(strLen)	// must be the first char
						break;
					else
						return XError(kXLibError, ErrXConvertingStringToLong);
				}
				else
					return XError(kXLibError, ErrXConvertingStringToLong);
				ll += n * *powP++;
			} while (--strLen >= 0);
			if (minus)
				ll = -ll;
		}
		else
			err = XError(kXLibError, ErrXLibNumOverFlow);
	}
	
*numP = ll;
return err;
}

//===========================================================================================
double 		CStrToReal(const char *sP)
{
double		res;

	res = atof(sP);

return res;
}

//===========================================================================================
Boolean	IsIntNumber(char *cStr, long *result)
{
Ptr 	theP;
long	len;

	theP = cStr;
	len = CLen(cStr);
	while (len > 0)
	{	if ((*theP >= '0') && (*theP <= '9'))
		{	theP++;
			len--;
		}
		else
			return false;
	}
	CStringToNum(cStr, result);
	
return true;
}

// =================================================================================
// return true if str1 begins with str2
Boolean	CBegins(register char *str1, register char *str2, Boolean cs)
{
int			fLen1, fLen2;
Boolean		res;

	fLen1 = CLen(str1);
	fLen2 = CLen(str2);
	if (fLen1 < fLen2)
		res = false;
	else
	{	if (cs)
			res = NOT(CompareBlock(str1, str2, fLen2));
		else
		{
		Byte		saveChar;

			saveChar = str1[fLen2];
			str1[fLen2] = 0;
			res = CCompareStrings(str1, str2) == 0;
			str1[fLen2] = saveChar;
		}
	}
	
return res;
}

// =================================================================================
Boolean	IsSeparChar(Ptr tempP, long len, long *returnSizeP)
{
Byte ch = *tempP;

	if (len)
	{	ch = *tempP;
		if (returnSizeP)
			*returnSizeP = 1;
		if NOT(ch)
		{	if (returnSizeP)
				*returnSizeP = 0;
			return true;
		}
		else if (IsNewLine(tempP, len, returnSizeP) || (ch == '\r') || 
				(ch == ' ') || 
				(ch == '\t') || 
				(ch == '.') || 
				(ch == ',') || 
				(ch == ';') || 
				(ch == ':') || 
				(ch == '!') || 
				(ch == '?') || 
				(ch == '\"') || 
				(ch == '\'') || 
				(ch == '(') || 
				(ch == ')') || 
				(ch == '[') || 
				(ch == ']') || 
				(ch == '{') || 
				(ch == '}') || 
				(ch == '>')
			)
		return true;
	}

return false;
}

#if __MWERKS__
#pragma mark-
#endif

// Conversions
//===========================================================================================
/* this is bugged, copies also the zero char
StringPtr	exCToPascal(char *cStr, StringPtr string)
{
register Ptr	s = (Ptr)&string[1];
register int	cnt = 255;

	while ( (*s++ = *cStr++) && --cnt);
	string[0] = 255 - cnt;
	
return string;
}*/
//===========================================================================================
StringPtr	CToPascal(char *cStr, StringPtr string)
{
register Ptr	s = (Ptr)&string[1];
register int	ch, cnt = 255;

	while (--cnt)
	{	if (ch = *cStr++)
			*s++ = ch;
		else
			break;
	}
	string[0] = 255 - cnt - 1;
	
return string;
}

//===========================================================================================
char*	PascalToC(StringPtr string, char *cStr)
{
	CopyBlock(cStr, &string[1], string[0]);
	cStr[string[0]] = 0;

return cStr;
}

#if __MWERKS__
#pragma mark-
#endif

// Common Utils
//===========================================================================================
Boolean	SkipSpaceAndTab(Ptr *oldFilePP, long *lenP)
{
register Ptr	oldFileP;
register long	len;
Boolean			res = false;

	oldFileP = *oldFilePP;
	if ((*lenP > 0) && ((*oldFileP == ' ') || (*oldFileP == '\t')))
	{	res = true;
		len = *lenP;
		do {	
			oldFileP++;
			len--;
			} while (len && ((*oldFileP == ' ') || (*oldFileP == '\t')));
		*oldFilePP = oldFileP;
		*lenP = len;
	}
	
return res;
}

//===========================================================================================
void	SkipSpaceAndTabCRLF(Ptr *oldFilePP, long *lenP, long *lineP)
{
Ptr		oldFileP;
long	len;

	oldFileP = *oldFilePP;
	len = *lenP;
	if ((len > 0) && ((*oldFileP == ' ') || (*oldFileP == '\t') || IsNewLineExt(&oldFileP, &len, lineP)))
	{	do {	
			if ((len > 0) && ((*oldFileP == ' ') || (*oldFileP == '\t')))
			{	oldFileP++;
				len--;
			}
			else if (IsNewLineExt(&oldFileP, &len, lineP))
				;
			else
				break;
		} while (len > 0);
		*oldFilePP = oldFileP;
		*lenP = len;
	}
}

//===========================================================================================
void	SkipNums(Ptr *oldFilePP, long *lenP)
{
register Ptr	oldFileP;
register long	len;

	oldFileP = *oldFilePP;
	if ((*lenP > 0) && ((*oldFileP >= '0') && (*oldFileP <= '9')))
	{	len = *lenP;
		do {	
			oldFileP++;
			len--;
			} while (len && ((*oldFileP >= '0') && (*oldFileP <= '9')));
		*oldFilePP = oldFileP;
		*lenP = len;
	}
}

//===========================================================================================
void	SkipUntilChar(Ptr *oldFilePP, long *lenP, int ch, long *lineP)
{
register Ptr	oldFileP;
register long	len;

	oldFileP = *oldFilePP;
	if ((*lenP > 0) && (*oldFileP != ch))
	{	len = *lenP;
		do {	
			if (lineP && IsNewLine(oldFileP, len, nil))
				(*lineP)++;
			oldFileP++;
			len--;
			} while (len && (*oldFileP != ch));
		/*if (len)
		{	oldFileP++;
			len--;
		}*/
		*oldFilePP = oldFileP;
		*lenP = len;
	}
}

//===========================================================================================
int	SpecialChar(int ch)
{
	switch(ch)
	{	case 'r':
			return '\r';
		case 'n':
			return '\n';
		case 't':
			return '\t';
		case 'v':
			return '\v';
		case '\"':
			return '\"';
		case '\'':
			return '\'';
		case '\\':
			return '\\';
		default:
			return 0;
	}
}

//===========================================================================================
void	AddPascalToCStr(char *cStr, StringPtr name)
{
int	len = CLen(cStr);

	CopyBlock(cStr+len, &name[1], name[0]);
	cStr[len + name[0]] = 0;
}

//===========================================================================================
void	AddCStrToPascal(StringPtr name, char *cStr)
{
int	len = CLen(cStr);

	if ((len + name[0]) > 254)
		len = 254 - name[0];
	CopyBlock(&name[name[0]+1], cStr, len);
	name[0] += len;
}
#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
/*static Byte	_ByteToNum(Byte hiCh, int shift)
{
	if ( (hiCh <= '9') && (hiCh >= '0') )
		hiCh = (hiCh - '0') << shift;
	else if ( (hiCh <= 'F') && (hiCh >= 'A') )
		hiCh = (hiCh - 'A' + 10) << shift;
	else if ( (hiCh <= 'f') && (hiCh >= 'a') )
		hiCh = (hiCh - 'a' + 10) << shift;
	else
		hiCh = 0;
		
return hiCh;
}*/


//==================================================================
static long _HexStr2Num(char *strP, int len, Boolean *success)
{
int		shiftCnt = 0;
char	ch, *chP = strP + len - 1;
long	val = 0, chV;

*success = true;
while (--len >= 0)
	{
	ch = *chP--;
	if ((ch <= '9') && (ch >= '0'))
		chV = ch - '0';
	else if ((ch <= 'F') && (ch >= 'A'))
		chV = 10 + ch - 'A';
	else if ((ch <= 'f') && (ch >= 'a'))
		chV = 10 + ch - 'a';
	else
	{	*success = false;
		break;
	}
	val += chV << shiftCnt;
	shiftCnt += 4;
	}
return val;
}
//==================================================================
static LONGLONG _HexStr2NumLongLong(char *strP, int len, Boolean *success)
{
int			shiftCnt = 0;
char		ch, *chP = strP + len - 1;
LONGLONG	val = 0;
int			chV;

*success = true;
while (--len >= 0)
	{
	ch = *chP--;
	if ((ch <= '9') && (ch >= '0'))
		chV = ch - '0';
	else if ((ch <= 'F') && (ch >= 'A'))
		chV = 10 + ch - 'A';
	else if ((ch <= 'f') && (ch >= 'a'))
		chV = 10 + ch - 'a';
	else
	{	*success = false;
		break;
	}
	//cVal = (long long)chV << shiftCnt;
	val += (LONGLONG)chV << shiftCnt;
	shiftCnt += 4;
	}
return val;
}
//===========================================================================================
void 	NumToHexString(long num, char *strP)
{
int			len = sizeof(num) * 2;
const char	letter[16] = "0123456789ABCDEF";

strP += 2 + len;
*strP = 0;
do	{
	*--strP = letter[num & 0xF];
	num >>= 4;
	} while (--len);

*--strP = 'x';
*--strP = '0';
}
//===========================================================================================
void 	NumLongToHexString(LONGLONG num, char *strP)
{
int			len = sizeof(num) * 2;
const char	letter[16] = "0123456789ABCDEF";

strP += 2 + len;
*strP = 0;
do	{
	*--strP = letter[num & 0xF];
	num >>= 4;
	} while (--len);

*--strP = 'x';
*--strP = '0';
}

//===========================================================================================
// the stream must be >= 2 in length
int	Hex2Num(char *strP)
{
char	ch;
int		val, chV = 0;

	ch = *strP++;
	if ((ch <= '9') && (ch >= '0'))
		chV = ch - '0';
	else if ((ch <= 'F') && (ch >= 'A'))
		chV = 10 + ch - 'A';
	else if ((ch <= 'f') && (ch >= 'a'))
		chV = 10 + ch - 'a';
	val = (chV << 4);
	
	ch = *strP;
	if ((ch <= '9') && (ch >= '0'))
		chV = ch - '0';
	else if ((ch <= 'F') && (ch >= 'A'))
		chV = 10 + ch - 'A';
	else if ((ch <= 'f') && (ch >= 'a'))
		chV = 10 + ch - 'a';
	val += chV;

return val;
}

//===========================================================================================
long	HexStringToNum(StringPtr hexStr, XErr *errP)
{
char		*strP = (char*)&hexStr[1];
long		strLen, res = 0;
Boolean		success;

	strLen = hexStr[0];
	if ((strLen > 0) && (strLen <= 8))
	{	res = _HexStr2Num(strP, strLen, &success);
		if NOT(success)
			*errP = XError(kXLibError, ErrXConversion);
	}
	else if (errP)
		*errP = XError(kXLibError, ErrXConversion);
	
return res;
}
//===========================================================================================
LONGLONG	HexStringToNumLong(StringPtr hexStr, XErr *errP)
{
char		*strP = (char*)&hexStr[1];
long		strLen;
LONGLONG	res = 0;
Boolean		success;

	strLen = hexStr[0];
	if ((strLen > 0) && (strLen <= 16))
	{	res = _HexStr2NumLongLong(strP, strLen, &success);
		if NOT(success)
			*errP = XError(kXLibError, ErrXConversion);
	}
	else if (errP)
		*errP = XError(kXLibError, ErrXConversion);
	
return res;
}
//===========================================================================================
Boolean	StringInText(char *str, long strLen, char *text, long textLen, Byte sepChar)
{
char		*endP, *strP = str, *textP = text;
Boolean		result = true, different = false;
int			ch, tStrLen = strLen;

	// zap gremlins (without modifying the original)
	SkipSpaceAndTab(&textP, &textLen);
	endP = textP + textLen - 1;
	while (textLen && ((*endP == ' ') || (*endP == '\t')))
	{	endP--;
		textLen--;
	}
	if (textLen)
	{	do {
			if (NOT(tStrLen) || (*textP != *strP))
			{	different = true;
				SkipSpaceAndTab(&textP, &textLen);
				ch = *textP;
				if (textLen && ((NOT(tStrLen) && (ch == sepChar)) || (ch == '*')))
				{	result = true;
					tStrLen = 0;
					break;
				}
				else
				{	SkipUntilChar(&textP, &textLen, sepChar, nil);
					result = false;
					strP = str;
					tStrLen = strLen;
					if (textLen)
					{	textP++;
						textLen--;
						SkipSpaceAndTab(&textP, &textLen);
						different = false;
						continue;
					}
					else
						break;
				}
			}
			textP++;
			strP++;
			tStrLen--;
			textLen--;
		} while (textLen > 0);
		if (tStrLen)
			result = false;
		else if NOT(different)
			result = true;
	}
	else
		result = false;

return result;
}

//===================================
// please, ptrText allocated at least totChars in size
void	PadString(register Byte *ptrText, short textLen, int totChars, int padChar, Boolean before)
{
int		i, diff;

	if (totChars <= textLen)
		return;

	diff = totChars - textLen;
	if NOT(before)
	{	ptrText += textLen;
		for (i = 1; i <= diff; i++, ptrText++)
			*ptrText = padChar;
		*ptrText = 0;
	}
	else
	{	CopyBlock(ptrText+diff, ptrText, textLen);
		*(ptrText+textLen+diff) = 0;
		for (i = 1; i <= diff; i++, ptrText++)
			*ptrText = padChar;
	}
}

//===================================
long	ZapText(register Byte *ptrText, long textLen)
{
register Byte			*newTextPtr = ptrText;
register int			i;
register long			zapped = 0;
register Byte			curChar, oldChar = ' ';		// cos� zappi i primi spazi


if (i = textLen)
{	do	{
		curChar = *ptrText++;
		if ((curChar != ' ') || (oldChar != ' '))
			*newTextPtr++ = curChar;
		oldChar = curChar;
		} while(--i);

	zapped = ptrText - newTextPtr;
	if (*(newTextPtr - 1) == ' ') zapped++;
}

return(zapped);
}

//============================================================ -()
void CutRightZeroDec(char *theStr, int decDigit)
{
register Byte	dLen = CLen(theStr), i = decDigit, *tP;

tP = (Byte*)&theStr[dLen-1];
while ((*tP == '0') && --i)
	--tP;

dLen -= (decDigit - i);
if (i == 0)
	dLen--;		// tolgo anche la virgola
theStr[dLen] = 0;
}

//============================================================ -()
/*oid CutRightZeroDec(char *theStr, int decimals)
{
register Byte	i = decimals, *tP;

tP = (Byte*)theStr;
while (*tP)
	*tP++;
--tP;
while ((*tP == '0') && --i)
	--tP;
++tP;
*tP = 0;

dLen -= (decDigit - i);
if (i == 0)
	dLen--;		// tolgo anche la virgola
theStr[dLen] = 0;

}*/

//===========================================================================================
Boolean IsNewLine(Ptr theP, long len, long *returnSizeP)
{
register int	ch;

	if (len > 0)
	{	ch = *theP;
		if ((len > 1) && (ch == '\r') && (*(theP+1) == '\n'))		// Win32
		{	if (returnSizeP)
				*returnSizeP = 2;
			return true;
		}
		else if ((ch == '\r') || (ch == '\n'))		// Unix - MacOS
		{	if (returnSizeP)
				*returnSizeP = 1;
			return true;
		}
		else
			return false;
	}
	else
		return false;
}

//===========================================================================================
// assumes first char is already checked and is CR or LF
void IsNewLine2(Ptr theP, long len, long *returnSizeP)
{
long	retSize;

	if ((len > 1) && (*theP == '\r') && (theP[1] == '\n'))
		retSize = 2;
	else
		retSize = 1;

if (returnSizeP)
	*returnSizeP = retSize;
}

//===========================================================================================
Boolean IsNewLineExt(Ptr *thePPtr, long *lenP, long *lineP)
{	
Ptr		theP = *thePPtr;
long	len = *lenP;
Boolean	res;
register int	ch;

	if (len > 0)
	{	ch = *theP;
		if ((len > 1) && (ch == '\r') && (*(theP+1) == '\n'))		// Win32
		{	theP += 2;
			len -= 2;
			res = true;
			if (lineP)
				(*lineP)++;
		}
		else if ((ch == '\r') || (ch == '\n'))		// Unix - MacOS
		{	theP++;
			len--;
			res = true;
			if (lineP)
				(*lineP)++;
		}
		else
			res = false;
	}
	else
		res = false;

if (res)
{	*thePPtr = theP;
	*lenP = len;
}
return res;
}

//===========================================================================================
// assumes first char is already checked and is CR or LF
void IsNewLineExt2(Ptr *thePPtr, long *lenP, long *lineP)
{	
Ptr		theP = *thePPtr;
long	len = *lenP;

	if ((len > 1) && (*theP == '\r') && (theP[1] == '\n'))		// Win32
	{	theP += 2;
		len -= 2;
		if (lineP)
			(*lineP)++;
	}
	else		// Unix - MacOS
	{	theP++;
		len--;
		if (lineP)
			(*lineP)++;
	}

*thePPtr = theP;
*lenP = len;
}

//===========================================================================================
void 	URLFromFullRequest(char **phisURLP, long *phisURLLenP)
{
int				realLen, phisURLLen;
char			*phisURL;
register int	ch;

	phisURLLen = *phisURLLenP;
	phisURL = *phisURLP;
	
	while(phisURLLen && (*phisURL != ' '))
	{	phisURL++;
		phisURLLen--;
	}
	while(phisURLLen && (*phisURL == ' '))
	{	phisURL++;
		phisURLLen--;
	}
	*phisURLP = phisURL;
	realLen = 0;
	while(phisURLLen && ((ch = *phisURL) != ' ') && (ch != '\?') && (ch != '$'))
	{	phisURL++;
		phisURLLen--;
		realLen++;
	}
	*phisURLLenP = realLen;
}

//===========================================================================================
void 	ProtocolFromFullRequest(char **phisURLP, long *phisURLLenP)
{
int				realLen, phisURLLen;
char			*phisURL;
short			a;

	phisURLLen = *phisURLLenP;
	phisURL = *phisURLP;
	
	// Skip Method
	while(phisURLLen && (*phisURL != ' '))
	{	phisURL++;
		phisURLLen--;
	}
	while(phisURLLen && (*phisURL == ' '))
	{	phisURL++;
		phisURLLen--;
	}

	// Skip URL
	while(phisURLLen && (*phisURL != ' '))
	{	phisURL++;
		phisURLLen--;
	}
	while(phisURLLen && (*phisURL == ' '))
	{	phisURL++;
		phisURLLen--;
	}

	*phisURLP = phisURL;
	realLen = 0;
	while(phisURLLen && (*(short*)phisURL != CRLF))
	{	phisURL++;
		a = *(short*)phisURL;
		phisURLLen--;
		realLen++;
	}
	*phisURLLenP = realLen;
}

//===========================================================================================
static Boolean	_IsOk(char ch)
{
Boolean	res = false;

	if (((ch >= 'a') && (ch <= 'z')) || ((ch >= 'A') && (ch <= 'Z')) || ((ch >= '0') && (ch <= '9')) || (ch == '_') || (ch == '.') || (ch == '-'))
		res = true;
	else
		res = false;
	
return res;
}
//===========================================================================================
Boolean	_IsEMail(char *strP)
{
Boolean		result = false;
int			cnt;
char		ch;

	if NOT(IS_ALNUM(*strP))
		result = false;
	else
	{	while ((ch = *strP) != 0 && ch != '@') 
		{	if (ch == ' ')
				break;
			if NOT(_IsOk(ch))
				goto out;
			strP++;
		}
		if ((*strP != 0) && (*strP != ' '))
		{	strP++;
			if (*strP == '.')
				goto out;
			while ((ch = *strP) != 0 && ch != '.') 
			{	if NOT(_IsOk(ch))
					goto out;
				if ((ch == ' ') || (ch == '@'))
					break;
				strP++;
			}
			if ((*strP != 0) && (*strP != ' ') && (*strP != '@'))
			{	cnt = 0;
				while ((ch = *strP) != 0 && ch != ',' && ch != '\r' && ch != '\n') 
				{	if (ch == ' ')
						break;
					else if (ch == '.')
					{	if (strP[1] == '.')
							goto out;
						else
							cnt = 0;
					}
					else if NOT(_IsOk(ch))
						goto out;
					else
						cnt++;
					strP++;
				}
				if ((*strP == 0) && cnt)
					result = true;
				else
					result = false;
			}
			else
				result = false;
		}
		else
			result = false;
	}
out:
return result;
}

//===========================================================================================
// Makes one CRLF of many
void ZapNewLines(Byte *textP, long *lenP)
{
long		len, size = 0, tLen;
Byte		*readP, *writeP;
Boolean		justAdded = false;
//XErr		err = noErr;

	len = *lenP;
	if (len)
	{	tLen = len;
		readP = writeP = textP;
		do {
			if (IsNewLine((Ptr)readP, tLen, &size))
			{	if (justAdded)
				{	readP += size;
					len -= size;
					tLen -= size;
				}
				else
				{	justAdded = true;
					if (size == 2)
					{	*writeP++ = *readP++;
						*writeP++ = *readP++;
						tLen -= 2;
					}
					else
					{	*writeP++ = *readP++;
						--tLen;
					}
				}
			}
			else
			{	justAdded = false;
				*writeP++ = *readP++;
				--tLen;
			}
		} while (tLen > 0);
	}
	*lenP = len;
}

//===========================================================================================
/* used in WalkFolder
	
	suffix		action
	__________________________
	nil			no filter
	""			no filter
	*			no filter
	....... newSuffix is strchr(suffix, '.')
	.*			no filter
	*.*			no filter
*/
void	WFPrepareFilter(char *suffix, char *newSuffix)
{
char	*suffPtr;
int		newSuffLen;	//, suffLen;

	if (suffix && *suffix)
	{	/*
		ex:
		suffLen = CLen(suffix);
		suffPtr = &suffix[suffLen-1];
		newSuffLen = 1;
		while (suffPtr > suffix)
		{	if (*suffPtr == '.')
			{	suffPtr++;
				newSuffLen--;
				break;
			}
			else
			{	suffPtr--;
				newSuffLen++;
			}
		};*/
		if (suffPtr = strchr(suffix, '.'))
			suffPtr++;
		else
			suffPtr = suffix;
		newSuffLen = CLen(suffPtr);
		if ((newSuffLen == 1) && (*suffPtr == '*'))
			*newSuffix = 0;
		else
		{	if (newSuffLen > 31)
				suffPtr[31] = 0;
			CEquStr(newSuffix, suffPtr);
		}
	}
	else
		*newSuffix = 0;
}

Boolean	WFFilter(char *filePath, char *suffix)
{
int		filePathLen, suffLen, ch1, ch2;
char	*chPtr, *suffPtr;
Boolean	res;

	if (*suffix)
	{	filePathLen = CLen(filePath);
		chPtr = &filePath[filePathLen-1];
		suffLen = CLen(suffix);
		suffPtr = &suffix[suffLen-1];
		if (filePathLen >= suffLen)
		{	do {
				ch1 = *chPtr--;
				ch2 = *suffPtr--;
				LOW_CHAR(ch1);
				LOW_CHAR(ch2);
				if (ch1 != ch2)
				{	res = false;
					goto out;
				}
			} while (--suffLen);
			if (suffLen)
				res = false;
			else
				res = true;
		}
		else
			res = false;
	}
	else
		res = true;

out:
return res;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// return 0 if equals
int 	ComparePaths(register char *path1, register char *path2)
{
	#ifdef __UNIX_XLIB__
		return CCompareStrings_cs(path1, path2);
	#else
		return CCompareStrings(path1, path2);
	#endif
}

//===========================================================================================
// short AddMilPoint(register short sizeStr, register Ptr numSPtr, register StringPtr numDPtr)
void FormatNumber(char *inStr, char *outStr, int decimSep, int thousSep)
{
register char	*dP, *srcP, ch;
char			*decP = nil;
short			begSiz, nPts;
short			i,newSizeStr;
char			bufStr[256];
Ptr				originalStringP;
long			sizeStr = CLen(inStr), decSiz=0;

	if (NOT(thousSep) || NOT(decimSep))
	{	CEquStr(outStr, inStr);
		return;
	}
	if NOT(sizeStr)
		{
		outStr[0] = 0;
		return;
		}

	if ( sizeStr > 256 )
		sizeStr = 256;
	CopyBlock( bufStr, inStr, sizeStr );
	originalStringP = inStr;
	inStr = bufStr;
	dP = srcP = inStr;
	for(i=0; i < sizeStr; ++i)
	{	ch = *srcP++;
		// if ( ch != thousSep )
		{	if ( ch == '.' )
			{	decP = srcP-1;
				*decP = decimSep;
				decSiz = sizeStr-i;
				break;
			}
			else
				*dP++ = ch;
		}
	}
	newSizeStr = dP-inStr;
	if ( newSizeStr <= 0 )
		return;

	dP = (char*)outStr;
	if ( *inStr=='-' || *inStr=='+' )	// Copia il segno e lo esclude�
	{
		*dP++ = *inStr++;
		if ( --newSizeStr <= 0 )
			return;
	}

	nPts = newSizeStr / 3;
	switch( begSiz = newSizeStr % 3 )
	{
	case 0:	*dP++ = *inStr++;	--nPts;	// Considera una tripletta in meno.
	case 2: *dP++ = *inStr++;
	case 1: *dP++ = *inStr++;
			break;
	}

	if ( i=nPts )
	do{
		*dP++ = thousSep;
		*dP++ = *inStr++; *dP++ = *inStr++; *dP++ = *inStr++;
	}while ( --i );

	if ( decSiz )
	do
		*dP++ = *decP++;
	while( --decSiz );
	
	outStr[dP - (char*)outStr] = 0;

	/*
	if ( sizeStr != newSizeStr || CompareBlock( originalStringP, outStr+1, sizeStr ) )
		return;
	else
		return 0;
	*/
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	StringEscaped(Ptr *strPPtr, long *strLenP, BlockRef *refP)
{
long		destLen, sourceLen = *strLenP;
Ptr			saveDestP, destP, sourceP = *strPPtr;
XErr		err = noErr;
BlockRef	block;
int			ch;

	if (block = NewBlock((sourceLen * 2) + 2 + 1, &err, &destP))	// two " and zero final
	{	saveDestP = destP;// = GetPtr(block);
		*destP++ = '\"';
		destLen = sourceLen + 2;
		if (sourceLen)
		{	do {
				if ((ch = *sourceP) == '\"')
				{	*destP++ = '\\';
					*destP++ = ch;
					destLen++;
					sourceP++;
					sourceLen--;
				}
				else
				{	*destP++ = ch;
					sourceP++;
					sourceLen--;
				}
			} while ((sourceLen > 0) && NOT(err));
		}
		*destP++ = '\"';
		*destP = 0;
		*strPPtr = saveDestP;
 		*strLenP = destLen;
 		*refP = block;
	}
	else
	{	*refP = 0;
		*strPPtr = nil;
 		*strLenP = 0;
 	}
 	
return err;
}

//============================================================
void	CDebugStrExt(char *preMessage, long num, char *postMessage)
{
CStr255		msg;
CStr15		tStr;

	
	*msg = 0;
	if (preMessage)
		CAddStr(msg, preMessage);
	CNumToString(num, tStr);
	CAddStr(msg, tStr);
	if (postMessage)
		CAddStr(msg, postMessage);
	CDebugStr(msg);
}

//===========================================================================================
void	VersionToString(long version, char *versionStr, char *devVersion)
{
Byte	majorVers, middleVers, minorVers;
CStr15	tempStr;

#ifdef __LITTLE_ENDIAN__
	majorVers = *(Byte*)((Ptr)&version+2);
	middleVers = *(Byte*)((Ptr)&version+1);
	minorVers = *(Byte*)((Ptr)&version);
	CNumToString(majorVers, versionStr);
	CAddChar(versionStr, '.');
	CNumToString(middleVers, tempStr);
	CAddStr(versionStr, tempStr);
	if (minorVers)
	{	CAddChar(versionStr, '.');
		CNumToString(minorVers, tempStr);
		CAddStr(versionStr, tempStr);
	}
#else
	majorVers = *(Byte*)((Ptr)&version+1);
	middleVers = *(Byte*)((Ptr)&version+2);
	minorVers = *(Byte*)((Ptr)&version+3);
	CNumToString(majorVers, versionStr);
	CAddChar(versionStr, '.');
	CNumToString(middleVers, tempStr);
	CAddStr(versionStr, tempStr);
	if (minorVers)
	{	CAddChar(versionStr, '.');
		CNumToString(minorVers, tempStr);
		CAddStr(versionStr, tempStr);
	}
#endif
	if (devVersion)
		CAddStr(versionStr, devVersion);
}



