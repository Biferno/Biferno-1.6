/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XFilesCommon.c,v 1.3 2003-06-23 12:39:49 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

#include <string.h>

#if __MAC_XLIB__ || __USE_CARBON_FRAMEWORK__
#include "XFilesMacPrivate.h"
#ifdef __MACOSX__
//===========================================================================================
static long	_GetDirIDFromParID_Static(FSSpecPtr dirFspecPtr)
{
CInfoPBRec		cInfoRec;
long 			retDirId = 0;

cInfoRec.dirInfo.ioCompletion = nil;
cInfoRec.dirInfo.ioNamePtr = dirFspecPtr->name;
cInfoRec.dirInfo.ioVRefNum = dirFspecPtr->vRefNum;
cInfoRec.dirInfo.ioDrDirID = dirFspecPtr->parID;
cInfoRec.dirInfo.ioFDirIndex = 0;
if NOT (PBGetCatInfoSync(&cInfoRec))
 	retDirId = cInfoRec.dirInfo.ioDrDirID;

return retDirId;
}
#endif

#if __MAC_XLIB__
#define	_512b						512
#define MAX_FILE_ALLOC(block)		{if (block>_1Mb)block=_1Mb;}
#define _1Mb						1048576L
//===========================================================================================
static XErr	_FlushOneFile(short fRefNum)
{
IOParam		ioParam;

ioParam.ioRefNum = fRefNum;

return PBFlushFileSync((ParmBlkPtr)&ioParam);
}
XErr	CopyResourceFork(FSSpec *scrPtr, FSSpec *dstPtr);
//===========================================================================================
XErr	CopyResourceFork(FSSpec *scrPtr, FSSpec *dstPtr)
{
register Ptr	bufPtr;
Handle			bufHandle = nil;
OSErr			err = noErr;
char			stackBuff[_512b];
short			srcResRef = 0, dstResRef = 0;
long			inOutCount, resSize;
Boolean			done = false;

if (dstPtr->parID == fsRtParID)
	return fnfErr;
if (err = FSpOpenRF(scrPtr, fsRdPerm, &srcResRef))
	return err;
if (err = GetEOF(srcResRef, &resSize)) goto ErrLevel1;
if (resSize)
	{
	if (err = FSpOpenRF(dstPtr, fsRdWrPerm, &dstResRef)) goto ErrLevel1;
	if (err = SetEOF(dstResRef, 0)) goto ErrLevel2;
	bufPtr = stackBuff;
	inOutCount = resSize;
	MAX_FILE_ALLOC(inOutCount);
	while(inOutCount)
		{
		if (bufHandle = NewHandle(inOutCount))
			break;
		inOutCount >>= 1;
		}
	if (inOutCount)
		bufPtr = *bufHandle;
	else
		inOutCount = _512b;
	while not(done)
		{
		if ((err = FSRead(srcResRef, &inOutCount, bufPtr)) && not(done = (err == eofErr)))
			goto ErrLevel2;
		if (err = FSWrite(dstResRef, &inOutCount, bufPtr)) goto ErrLevel2;
		}
	err = _FlushOneFile(dstResRef);
	}
else
	goto ErrLevel1;
	
ErrLevel2:
	if (bufHandle) DisposeHandle(bufHandle);
	FSClose(dstResRef);
ErrLevel1:
	FSClose(srcResRef);
	return err;
}
#endif

//===========================================================================================
XErr GetMacOSSpecExt(XFilePathPtr filePath, FSSpec *fileSpecP, Boolean noFnfErr, Boolean resolveAlias)
{
XErr	err = noErr;

#ifdef __MACOSX__
	{
	FSRef 	newRef, folderRef;
	char	*strP;
	CStr255	folderPath;
	int		tLen;
	
		err = FSPathMakeRef((Byte*)filePath, &newRef, NULL);
		if (err == -43)
		{	CEquStr(folderPath, filePath);
			if (strP = strrchr(folderPath, '/'))
			{	*strP = 0;
				if NOT(err = FSPathMakeRef((Byte*)folderPath, &folderRef, NULL))
				{	if NOT(err = FSGetCatalogInfo(&folderRef, kFSCatInfoNone, NULL, NULL, fileSpecP, NULL))
					{	fileSpecP->parID = _GetDirIDFromParID_Static(fileSpecP);
						tLen = CLen(strP + 1);
						CopyBlock(&fileSpecP->name[1], strP + 1, tLen);
						fileSpecP->name[0] = tLen;
					}
				}
			}
		}
		else
			err = FSGetCatalogInfo(&newRef, kFSCatInfoNone, NULL, NULL, fileSpecP, NULL);
	}
#else
	err = _GetMacSpec(filePath, fileSpecP, noFnfErr, resolveAlias);
#endif

return err;
}
#endif

//===========================================================================================
void	XFiles_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{
	xlibCallBacksRecPtr->XGetApplicationFolderPath = (long)XGetApplicationFolderPath;
}

//===========================================================================================
XErr OpenNewXFile(XFilePathPtr filePathP, int fPerm, long fType, long fCreat, XFileRef *xFileRefP)
{
XErr		err;
XFileInfo	xFileInfo;


if not(err = OpenXFile(filePathP, CREATE_FILE_ALWAYS, fPerm, USE_CACHE, xFileRefP))
	{
	if not(err = GetXFileInfo(filePathP, &xFileInfo))
		{
		xFileInfo.macosType = fType;
		xFileInfo.macosCreator = fCreat;
		err = SetXFileInfo(filePathP, &xFileInfo);
		}
	}
return err;
}

//===========================================================================================
void	XGetFileNameFromPath(XFilePath filePath, Ptr fileName)
{
Ptr		fileNameStartP = filePath;
int		len;
char	ch;

do	{
	ch = *filePath++;
	if (ch == '/')
		fileNameStartP = filePath;	// last possible file name PTR
	} while (ch);
len = filePath - fileNameStartP - 1;
while (--len >= 0)
	{
	*fileName++ = *fileNameStartP++;
	}
*fileName = 0;
}

// =================================================================================
/*XErr CreateOpenXFile(XFilePathPtr filePathP, int fPerm, long fType, long fCreat, XFileRef *xFileRefP)
{
XErr		err;
XFileInfo	xFileInfo;


if not(err = OpenXFile(filePathP, CREATE_FILE_ALWAYS, fPerm, USE_CACHE, xFileRefP))
	{
	if not(err = GetXFileInfo(filePathP, &xFileInfo))
		{
		xFileInfo.macosType = fType;
		xFileInfo.macosCreator = fCreat;
		err = SetXFileInfo(filePathP, &xFileInfo);
		}
	}
return err;
}*/
#ifdef __XLIB_CLIENT__
	extern XLIB_CallBacksRec*	gXLibCallBacksRecPtr;
	//===========================================================================================
	XErr	XGetApplicationFolderPath(XFilePathPtr path)
	{
	XErr	(*p)(XFilePathPtr path) = (void*)gXLibCallBacksRecPtr->XGetApplicationFolderPath;

		return p(path);
	}
#else
	extern	XFilePath		gFragLocator_u_onDisk_path;
	//===========================================================================================
	// On Unix is:  $BIFERNOHOME=/.....
	XErr	XGetApplicationFolderPath(XFilePathPtr path)
	{
		CEquStr(path, gFragLocator_u_onDisk_path);
		
	return noErr;
	}
#endif

//===========================================================================================
// 	"/c/dir1/file.txt" -> "c:\dir1\file.txt"
void	FilePathXLibToWin32(XFilePathPtr filePath)
{
int		pLen;
char	*strP;

	pLen = CEquStr(filePath, filePath + 1);
	if (strP = strchr(filePath, '/'))
	{	CopyBlock(strP + 1, strP, pLen - (strP - filePath));
		*strP = ':';
		CSubstitute(strP + 1, '/', '\\');
	}
	else
		CAddStr(filePath, ":\\");	
}

//===========================================================================================
// 	"c:\dir1\file.txt" -> "/c/dir1/file.txt"
int		FilePathWin32ToXLib(XFilePathPtr filePath)
{
int		pLen;
char	*strP;

	pLen = CSubstitute(filePath, '\\', '/');
	if (strP = strchr(filePath, ':'))
	{	CopyBlock(filePath + 1, filePath, strP - filePath);
		*filePath = '/';
	}
	else
	{	*filePath = 0;	// err
		pLen = 0;
	}
	
return pLen;
}





