/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XMemoryPrivate.c,v 1.6 2008-04-16 14:31:01 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __XLIB_CLIENT__
//===========================================================================================
/*
Manager (Multithread) per il controllo del memory leaking
if def MEM_DEBUG_DUMP_LEAK dump leaking block
*/
//===========================================================================================
#include "XLib.h"
#ifdef CHECK_LEAKING

#include "XMemoryPrivate.h"
#include "XThreadsPrivate.h"

#define			MAX_THREADS_CHECK		128
#define			MAX_THREADS_FOR_TASK	64
#define			MAX_CHECKLOCK_LEVELS	32

typedef struct {
			unsigned long	taskTotThreads;
			unsigned long	threadID[MAX_THREADS_FOR_TASK];
			long			totPtrs;
			long			totHandles;
			Boolean			busy;
			Byte			pad;
			short			padShort;
		#ifdef MEM_DEBUG_DUMP_LEAK
			long			allAddressID;
		#endif
			long			totLocks;
			long			lastStack[MAX_CHECKLOCK_LEVELS];
			} ThisThreadMem;

static ThisThreadMem	gTotThreadsRec[MAX_THREADS_CHECK];

//===========================================================================================
static ThisThreadMem*	_GetThisMemRec(unsigned long threadID)
{
unsigned long	*threadIDP;
XErr			err = noErr;
ThisThreadMem	*memRecP;
int				i, j, tot;

	if NOT(threadID)
		err = XGetCurrentThread(&threadID);
	if NOT(err)
	{	memRecP = &gTotThreadsRec[0];
		for (i = 0; i < MAX_THREADS_CHECK; i++, memRecP++)
		{	if (memRecP->busy)
			{	tot = memRecP->taskTotThreads;
				threadIDP = &memRecP->threadID[tot-1];
				for (j = 0; j < tot; j++, threadIDP--)
				{	if (*threadIDP == threadID)
						goto out;
				}
			}
		}
	out:
		if (i == MAX_THREADS_CHECK)
			memRecP = nil;
	}
	else
		memRecP = nil;
	
if (err)
	CDebugStr("Error in check-leaking manager");
return memRecP;
}

//===========================================================================================
static void _ZeroOne(long buffID, register long id)
{
long				size;
register long	 	*tempP;
register int		count;

	if (buffID)
	{	XThreadsEnterCriticalSection();
		tempP = (long*)GetPtr(BufferGetBlockRef(buffID, &size));
		if (count = (size / sizeof(long)))
		{	do {	if (id == tempP[count])
					{	tempP[count]= 0;
						break;
					}
				} while(--count >= 0);
		}
		XThreadsLeaveCriticalSection();
	}
}

//===========================================================================================
void	_OneMoreHandle(BlockRef b)
{
ThisThreadMem	*memRecP;
#ifndef MEM_DEBUG_DUMP_LEAK
	#if __C_HAS_PRAGMA_UNUSED__	//ex __MWERKS__
		#pragma unused(b)
	#endif
#endif

	XThreadsEnterCriticalSection();
	if (memRecP = _GetThisMemRec(0))
	{	
	#ifdef __MAC_XLIB__
		memRecP->totHandles++;
	#else
		memRecP->totPtrs++;
	#endif
		#ifdef MEM_DEBUG_DUMP_LEAK
			if (memRecP->allAddressID)
			{	if (BufferAddLong(memRecP->allAddressID, b))
					CDebugStr("BufferAddLong in _OneMoreHandle failed!");
			}
		#endif
	}
	XThreadsLeaveCriticalSection();
}
//===========================================================================================
void	_OneMorePtr(BlockRef b)
{
ThisThreadMem	*memRecP;
#ifndef MEM_DEBUG_DUMP_LEAK
	#if __C_HAS_PRAGMA_UNUSED__	//ex __MWERKS__
		#pragma unused(b)
	#endif
#endif

	XThreadsEnterCriticalSection();
	if (memRecP = _GetThisMemRec(0))
	{	memRecP->totPtrs++;
		#ifdef MEM_DEBUG_DUMP_LEAK
			if (memRecP->allAddressID)
			{	if (BufferAddLong(memRecP->allAddressID, b))
					CDebugStr("BufferAddLong in _OneMorePtr failed!");
			}
		#endif
	}
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
void	_OneLessHandle(BlockRef b)
{
ThisThreadMem	*memRecP;
#ifndef MEM_DEBUG_DUMP_LEAK
	#if __C_HAS_PRAGMA_UNUSED__	//ex __MWERKS__
		#pragma unused(b)
	#endif
#endif

	XThreadsEnterCriticalSection();
	if (memRecP = _GetThisMemRec(0))
	{	
		#ifdef MEM_DEBUG_DUMP_LEAK
			if (memRecP->allAddressID)
				_ZeroOne(memRecP->allAddressID, b);
		#endif
		memRecP->totHandles--;
		/*if (memRecP->totHandles < 0)
		{	CStr255		logStr;
		
			sprintf(logStr, "CheckLeaking _OneLessHandle: totHandles negative (%d)!", memRecP->totHandles);
			CDebugStr(logStr);
		}*/
	}
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
void	_OneLessPtr(BlockRef b)
{
ThisThreadMem	*memRecP;
#ifndef MEM_DEBUG_DUMP_LEAK
	#if __C_HAS_PRAGMA_UNUSED__	//ex __MWERKS__
		#pragma unused(b)
	#endif
#endif

	XThreadsEnterCriticalSection();
	if (memRecP = _GetThisMemRec(0))
	{	
		#ifdef MEM_DEBUG_DUMP_LEAK
			if (memRecP->allAddressID)
				_ZeroOne(memRecP->allAddressID, b);
		#endif
		memRecP->totPtrs--;
		/*if (memRecP->totPtrs < 0)
		{	CStr255		logStr;
		
			sprintf(logStr, "CheckLeaking _OneLessPtr: totPtrs negative (%d)!", memRecP->totPtrs);
			CDebugStr(logStr);
		}*/
	}
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
Boolean	_Locking(void)
{
	ThisThreadMem	*memRecP;
	Boolean			res;
	
	if (memRecP = _GetThisMemRec(0))
	{	
		res = memRecP->totLocks > 0;
	}
	return res;
}

//===========================================================================================
void	_OneMoreLock(void)
{
	ThisThreadMem	*memRecP;
	
	if (memRecP = _GetThisMemRec(0))
	{	if (memRecP->totLocks < MAX_CHECKLOCK_LEVELS)
	{	memRecP->lastStack[memRecP->totLocks] = (long)&memRecP;
		memRecP->totLocks++;
		//if (memRecP->maxLevel < memRecP->totLocks)
		//	memRecP->maxLevel = memRecP->totLocks;
	}
	}
}

//===========================================================================================
// Questa deve essere void, altrimenti su Unix non funziona il Check dello stack
void	_OneLessLock(void)
{
ThisThreadMem	*memRecP;

	if (memRecP = _GetThisMemRec(0))
	{	if (memRecP->totLocks < MAX_CHECKLOCK_LEVELS)
		{	if (memRecP->totLocks <= 0)
				CDebugStr("memRecP->totLock going < 0");
			memRecP->totLocks--;
		/*
		Su CW 7 funziona, sull'8 no!! (boh!)
		#if !__MACOSX__	// on MacOSX there are always 32 bytes of differences between the two values
			if ((long)&memRecP != memRecP->lastStack[memRecP->totLocks])
				CDebugStr("_OneLessLock: locks don't match!");
		#endif
		*/
		}
	}
}

//===========================================================================================
void	_OneLessLockNoStackCheck(void)
{
ThisThreadMem	*memRecP;

	if (memRecP = _GetThisMemRec(0))
	{	if (memRecP->totLocks < MAX_CHECKLOCK_LEVELS)
		{	if (memRecP->totLocks <= 0)
				CDebugStr("memRecP->totLock going < 0");
			memRecP->totLocks--;
		}
	}
}

#ifdef MEM_DEBUG_DUMP_LEAK
//#include "Buffers.h"
//===========================================================================================
static void _DumpLeak(long buffID, long *totLeaksP, Boolean isHandle)
{
long			size;
register long 	*tempP;
register int	count;
BlockRef		bl;
Ptr				p;
long			len;
XFileRef 		refNum;
XErr			err = noErr;
CStr255			path;
	
	if (buffID)
	{	XThreadsEnterCriticalSection();
		bl = BufferGetBlockRef(buffID, &size);
		LockBlock(bl);
		tempP = (long*)GetPtr(bl);
		if (count = (size / sizeof(long)))
		{	*totLeaksP = 0;
			do {	
				if (*tempP)
				{	bl = *tempP;
					if (GetAddress(bl))
					{	p = GetPtr(bl);
						len = GetBlockSize(bl, nil);
						if (isHandle)
							CEquStr(path, "MEM_DEBUG_DUMP_LEAK_Hnd.txt");
						else
							CEquStr(path, "MEM_DEBUG_DUMP_LEAK_Ptr.txt");
						if NOT(err = OpenXFile(path, CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &refNum))
						{	err = WriteXFile(refNum, p, &len);
							CloseXFile(&refNum);
						}
						(*totLeaksP)++;
					}
				}
				tempP++;
			} while(--count);
		}
		XThreadsLeaveCriticalSection();
	}
}

#endif	// #ifdef MEM_DEBUG_DUMP_LEAK
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	InitMemoryLeakingMgr(void)
{
	ClearBlock(&gTotThreadsRec, sizeof(ThisThreadMem) * MAX_THREADS_CHECK);
}

//===========================================================================================
void	CheckLeakingMoreThread(unsigned long parent, unsigned long newThreadID)
{
ThisThreadMem	*memRecP;
long			tot;

	XThreadsEnterCriticalSection();
	if (memRecP = _GetThisMemRec(parent))
	{	tot = memRecP->taskTotThreads;
		if (tot < MAX_THREADS_FOR_TASK)
		{	memRecP->threadID[tot] = newThreadID;
			memRecP->taskTotThreads++;
		}
		else
			ClearBlock(memRecP, sizeof(ThisThreadMem));
	}
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
void	CheckLeakingLessThread(void)
{
ThisThreadMem	*memRecP;
long			tot;

	XThreadsEnterCriticalSection();
	if (memRecP = _GetThisMemRec(0))
	{	tot = memRecP->taskTotThreads;
		memRecP->threadID[tot-1] = 0;
		memRecP->taskTotThreads--;
	}
	XThreadsLeaveCriticalSection();
}

//===========================================================================================
Boolean	ResetLeaking(void)
{
ThisThreadMem	*memRecP;
unsigned long	threadID;
int				i;
XErr			err;
Boolean			result = false;
	
	#if __UNIX_XLIB__ && !CAN_USE_POSIX_THREADS
		return false;
	#endif
	
	__XThreadsEnterCriticalSection();
	memRecP = &gTotThreadsRec[0];
	for (i = 0; i < MAX_THREADS_CHECK; i++, memRecP++)
	{	if NOT(memRecP->busy)
			break;
	}
	if (i < MAX_THREADS_CHECK)
	{	ClearBlock(memRecP, sizeof(ThisThreadMem));
		if NOT(err = XGetCurrentThread(&threadID))
		{	memRecP->threadID[0] = threadID;
			memRecP->taskTotThreads = 1;
			memRecP->busy = true;
		#ifdef MEM_DEBUG_DUMP_LEAK
			memRecP->allAddressID = BufferCreate(128, nil);
		#endif
			result = true;
		}
		else
			CDebugStr("Error in check-leaking manager");
	}
	__XThreadsLeaveCriticalSection();

return result;
}

//===========================================================================================
void	CheckLeaking(char *cStr, long *leakPtrsP, long *leakHandlesP)
{
ThisThreadMem	*memRecP;
#ifdef MEM_DEBUG_DUMP_LEAK
	long	leaks;
#endif
	
	if (cStr)
		*cStr = 0;
	__XThreadsEnterCriticalSection();
	if (memRecP = _GetThisMemRec(0))
	{
	CStr255	msgStr;
	CStr15	numStr;
	
	#ifdef MEM_DEBUG_DUMP_LEAK
		// faccio dopo una BufferFree
		#if __MAC_XLIB__
			memRecP->totHandles--;
		#else
			memRecP->totPtrs--;
		#endif
	#endif
		if (memRecP->totLocks)
		{	sprintf(msgStr, "memRecP->totLocks: %d", memRecP->totLocks);
			CDebugStr(msgStr);
		}
		if (memRecP->totHandles)
		{	CNumToString(memRecP->totHandles, numStr);
			CEquStr(msgStr, "XMemoryCommon.c (CheckLeaking) => Handle Leaking: ");
			CAddStr(msgStr, numStr);
			if (cStr)
			{	CEquStr(cStr, msgStr);
				CNumToString(memRecP->threadID[0], numStr);
				CAddStr(cStr, " Thread: ");
				CAddStr(cStr, numStr);
			}
			#ifdef MEM_DEBUG_DUMP_LEAK
				if (memRecP->totHandles > 0)
				{	_DumpLeak(memRecP->allAddressID, &leaks, true);
					/*if (leaks != memRecP->totHandles)
					{	CStr255	cStr;
					
						sprintf(cStr, "Discordance in CheckLeaking (Hnd), %d, %d\n", leaks, memRecP->totHandles);
						CDebugStr(cStr);
					}*/
				}
			#endif
		}
		if (leakHandlesP)
			*leakHandlesP = memRecP->totHandles;

		if (memRecP->totPtrs)
		{	CNumToString(memRecP->totPtrs, numStr);
			CEquStr(msgStr, "XMemoryCommon.c (CheckLeaking) => Ptr Leaking: ");
			CAddStr(msgStr, numStr);
			if (cStr)
			{	if (*cStr)
					CAddStr(cStr, "\n");
				CAddStr(cStr, msgStr);
				CNumToString(memRecP->threadID[0], numStr);
				CAddStr(cStr, " Thread: ");
				CAddStr(cStr, numStr);
			}
			#ifdef MEM_DEBUG_DUMP_LEAK
				if (memRecP->totPtrs > 0)
				{	_DumpLeak(memRecP->allAddressID, &leaks, false);
					/*if (leaks != memRecP->totPtrs)
					{	CStr255	cStr;
				
						sprintf(cStr, "Discordance in CheckLeaking (Ptr), %d, %d\n", leaks, memRecP->totPtrs);
						CDebugStr(cStr);
					}*/
				}
			#endif
		}
		if (leakPtrsP)
			*leakPtrsP = memRecP->totPtrs;

		{
		unsigned long	i, *threadIDP, tot;

		memRecP->busy = false;
		tot = memRecP->taskTotThreads;
		threadIDP = memRecP->threadID;
		for (i = 0; i < tot; i++, threadIDP++)
			*threadIDP = 0;
		//memRecP->threadID = 0;
		}
	#ifdef MEM_DEBUG_DUMP_LEAK
		BufferFree(memRecP->allAddressID);
	#endif
	}
	__XThreadsLeaveCriticalSection();
}
#else
//===========================================================================================
Boolean	ResetLeaking(void)
{
	return false;
}

//===========================================================================================
void	CheckLeaking(char *cStr, long *leakPtrsP, long *leakHandlesP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(cStr, leakPtrsP, leakHandlesP)
#endif
}
#endif	// CHECK_LEAKING

#endif	// __XLIB_CLIENT__

