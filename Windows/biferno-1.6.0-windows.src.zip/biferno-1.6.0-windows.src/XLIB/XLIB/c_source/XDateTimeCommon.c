/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: XDateTimeCommon.c,v 1.8 2008-09-19 13:40:25 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XLibPrivate.h"

#include <stdio.h>
#include <time.h>

static	CStr15	dayOfWeek[7] = {"Sun,","Mon,","Tue,","Wed,","Thu,","Fri,","Sat,"};
static	CStr15	monthsOfYear[12] = {"Jan ","Feb ","Mar ","Apr ","May ","Jun ","Jul ", "Aug ","Sep ","Oct ","Nov ","Dec "};
static	int		iDate = -1;
static	char	sDate[2], sTime[2];	// Byte + 0-terminated

#if __UNIX_XLIB__
//===========================================================================================
void	XDateTime_InitGlue(XLIB_CallBacksRec* xlibCallBacksRecPtr)
{
		xlibCallBacksRecPtr->XGetTicks = (long)XGetTicks;
}
#endif

//===========================================================================================
static void	_SetDefaults(int *elemOrderP, Byte *dateSepP, Byte *timeSepP)
{	
	if (iDate == -1)
		iDate = GetSeparators(nil, nil, sDate, sTime);
	if (dateSepP)
		*dateSepP = *sDate;
	if (timeSepP)
		*timeSepP = *sTime;
	if (elemOrderP)
	{	switch(iDate)
		{	default:
			case _MDY:			// m/d/y
				elemOrderP[0] = 1; elemOrderP[1] = 0; elemOrderP[2] = 2;
			break;

			case _DMY:			// d/m/y
				elemOrderP[0] = 0; elemOrderP[1] = 1; elemOrderP[2] = 2;
			break;

			case _YMD:			// y/m/d
				elemOrderP[0] = 2; elemOrderP[1] = 1; elemOrderP[2] = 0;
			break;

			case _MYD:			// m/y/d
				elemOrderP[0] = 1; elemOrderP[1] = 2; elemOrderP[2] = 0;
			break;

			case _DYM:			// d/y/m
				elemOrderP[0] = 0; elemOrderP[1] = 2; elemOrderP[2] = 1;
			break;

			case _YDM:			// y/d/m
				elemOrderP[0] = 2; elemOrderP[1] = 0; elemOrderP[2] = 1;
			break;		
		}
	}
}

//===========================================================================================
static XErr	_DateTimeParamsFromOptionString(char *opt_formatStr, int *elemOrderP, Byte *dateSepP, Byte *timeSepP)
{
Byte		ch;
int			idx, i, optLen;
Boolean		sepTimeExpected, sepExpected;
XErr		err = noErr;
Byte		sepChar, sepTime;

	if NOT(opt_formatStr)
	{	_SetDefaults(elemOrderP, dateSepP, timeSepP);
		return noErr;
	}

	optLen = CLen(opt_formatStr);
	if (iDate == -1)
		iDate = GetSeparators(nil, nil, sDate, sTime);
	*dateSepP = *sDate;
	*timeSepP = *sTime;

	// date order
	if (optLen > 4)
	{	sepExpected = sepTimeExpected = false;
		sepChar = sepTime = 0;
		idx = 0;
		for (i = 0; (i < optLen) && NOT(err); i++)
		{	ch = opt_formatStr[i];
			switch(ch)
			{	case 'D':
				case 'd':
					if (sepExpected)
						err = XError(kXLibError, ErrXDateTimeFormatError);
					else
					{	elemOrderP[0] = idx++;
						sepExpected = true;
					}
					break;
				case 'M':
				case 'm':
					if (sepExpected)
						err = XError(kXLibError, ErrXDateTimeFormatError);
					else
					{	elemOrderP[1] = idx++;
						sepExpected = true;
					}
					break;
				case 'Y':
				case 'y':
					if (sepExpected)
						err = XError(kXLibError, ErrXDateTimeFormatError);
					else
					{	elemOrderP[2] = idx++;
						sepExpected = true;
					}
					break;
				case 'h':
				case 'H':
					sepTimeExpected = true;
					break;
				case ' ':
				case '\t':
					break;
				default:
					if (sepTimeExpected)
					{	sepTimeExpected = false;
						if NOT(sepTime)
							sepTime = ch;
						else if (ch != sepTime)
							err = XError(kXLibError, ErrXDateTimeFormatError);
						goto endWhile;
					}
					else
					{	sepExpected = false;
						if NOT(sepChar)
							sepChar = ch;
						else if (ch != sepChar)
							err = XError(kXLibError, ErrXDateTimeFormatError);
					}
					// _SetDefaults(elemOrderP, nil, nil);
					break;
			}
		}
	endWhile:
		if NOT(err)
		{	if (sepChar)
				*dateSepP = sepChar;
			if (sepTime)
				*timeSepP = sepTime;
		}
	}
	else
		_SetDefaults(elemOrderP, nil, nil);

return err;
}

//===========================================================================================
static	void _LeadTwoCharsStr(char *str)
{
	if (*(str+1) == 0)
	{	*(str+1) = *str;
		*str = '0';
		*(str+2) = 0;
	}
}

//===========================================================================================
static void	_RoundTime(long *num, long *up_num, long roundTo, Boolean zeroBased)
{
long	t_num, t_up_num, mod;

	t_num = *num;
	t_up_num = *up_num;
	if (t_num > roundTo)
	{	t_up_num += (t_num / roundTo);
		t_num = t_num % roundTo;
	}
	else if ((t_num == roundTo) && zeroBased)
	{	t_num = 0;
		t_up_num++;
	}
	else if (t_num < 0)
	{	t_up_num += (t_num / roundTo);
		mod = t_num % roundTo;
		t_num = roundTo + mod;
		t_up_num -= (mod != 0);
	}
	else if ((t_num == 0) && NOT(zeroBased))
	{	t_num = roundTo;
		t_up_num--;
	}
	*num = t_num;
	*up_num = t_up_num;
}

//===========================================================================================
/*static void	_RoundTimeExt(LONGLONG *num, LONGLONG *up_num, long roundTo, Boolean zeroBased)
{
LONGLONG	t_num, t_up_num, mod;
	
	t_num = *num;
	t_up_num = *up_num;
	if ((t_num > roundTo) || ((t_num == roundTo) && zeroBased))
	{	t_up_num += (t_num / roundTo);
		t_num = t_num % roundTo;
	}
	else if ((t_num < 0) || ((t_num == 0) && NOT(zeroBased)))
	{	t_up_num += (t_num / roundTo);
		mod = t_num % roundTo;
		t_num = roundTo + mod;
		t_up_num -= (mod != 0);
	}
	*num = t_num;
	*up_num = t_up_num;
}
*/
//===========================================================================================
/*suggerimento di MAX:
Questa regola si puo' applicare solo per le date a partire dall'anno 1582 (introduzione calendario Gregoriano) 
se ti mandano una data tipo 01/10/1581 � sicuramente una data falsa. 

bisestile = ( (!(anno >> 3) && anno % 100) || (!(anno % 400)) ) 
*/
static long _DaysOfMonth(long month, long year)
{
long	res = 0;

	switch(month)
	{
		case  1:
		case  3:
		case  5:
		case  7:
		case  8:
		case 10:
		case 12:
			res = 31;
			break;
		case  2:
			if (year <= 1582)
				res = 28;
	 		else if ((!(year & 3) && year % 100) || (!(year % 400))) 
	 			res = 29;
	 		else
	 			res = 28;
			break;
		case  4:
		case  6:
		case  9:
		case 11:
			res = 30;
	}

return res;
}

//===========================================================================================
/*static Boolean	_Bisestile(LONGLONG year)
{
Boolean	res;

	if (year <= 1582)
		res = true;
	else if ((!(year & 3) && year % 100) || (!(year % 400))) 
		res = false;
	else
		res = true;

return res;
}*/

//===========================================================================================
/*static LONGLONG _DaysOfMonthExt(LONGLONG month, LONGLONG year)
{
LONGLONG	res;

	switch(month)
	{
		case  1:
		case  3:
		case  5:
		case  7:
		case  8:
		case 10:
		case 12:
			res = 31;
			break;
		case  2:
			if (year <= 1582)
				res = 28;
	 		else if ((!(year & 3) && year % 100) || (!(year % 400))) 
	 			res = 29;
	 		else
	 			res = 28;
			break;
		case  4:
		case  6:
		case  9:
		case 11:
			res = 30;
	}

return res;
}
*/
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// ANSI Note: 100 = year 2000, months are 0-based, and 0 is Sunday
void	ANSI2XDateTime(Ptr timeRecP, XDateTimeRecP xTimeP)
{
struct tm* timeP = (struct tm*)timeRecP;

	xTimeP->year = timeP->tm_year + 1900;
	xTimeP->month = timeP->tm_mon + 1;
	xTimeP->day = timeP->tm_mday;
	xTimeP->hour = timeP->tm_hour;
	xTimeP->minute = timeP->tm_min;
	xTimeP->second = timeP->tm_sec;
	xTimeP->dayOfWeek = timeP->tm_wday + 1;
}

//===========================================================================================
// ANSI Note: 100 = year 2000, months are 0-based, and 0 is Sunday
void	XDateTime2ANSI(XDateTimeRecP xTimeP, Ptr timeRecP)
{
struct tm* timeP = (struct tm*)timeRecP;

	ClearBlock(timeP, sizeof(struct tm));
	timeP->tm_year = xTimeP->year - 1900;
	timeP->tm_mon = xTimeP->month - 1;
	timeP->tm_mday = xTimeP->day;
	timeP->tm_hour = xTimeP->hour;
	timeP->tm_min = xTimeP->minute;
	timeP->tm_sec = xTimeP->second;
	timeP->tm_wday = xTimeP->dayOfWeek - 1;
	timeP->tm_isdst = -1;	// let the system find if DST is on
}

#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
XErr	XStringToDateTime(char *dateStr, XDateTimeRecP dateRecP, char *opt_formatStr)
{
long			num;
Str31			numStr[3];
int				elemOrder[3];	
long			charCount;
register Byte	ch, *tmpStr, valSep = 0;
Str255			pascDateStr;
StringPtr		strP = pascDateStr;
Byte			dateSep, timeSep;
int				i;
Str15			aStr;
XErr			err = noErr;

	ClearBlock(dateRecP, sizeof(XDateTimeRec));
	CToPascal(dateStr, strP);
	if NOT(charCount = *strP++)
		return XError(kXLibError, ErrXDateTimeFormatError);

	strP[charCount] = 10;		// terminator
	
	// Date
	if (err = _DateTimeParamsFromOptionString(opt_formatStr, elemOrder, &dateSep, &timeSep))
		return err;
	
	do	{
	tmpStr = &numStr[valSep][1];
		do	{
			*tmpStr++ = ch = *strP++;
			charCount--;
			} while(ch != 10 && (ch >= '0' && ch <= '9'));
	numStr[valSep][0] = (Ptr)tmpStr - (Ptr)&numStr[valSep][2];		// [2] sono i bytes in pi�
	} while( (++valSep < 3) && ((ch == '-') || (ch == '/') || (ch == dateSep)) );
	strP--;
	charCount++;
	if (valSep != 3)
		return XError(kXLibError, ErrXDateTimeFormatError);

	PStringToNum(numStr[elemOrder[2]], &num);
	if (num > 9999 || num <= 0) return XError(kXLibError, ErrXDateTimeFormatError);
	dateRecP->year = num;

	PStringToNum(numStr[elemOrder[1]], &num);
	if (num > 12 || num <= 0) return XError(kXLibError, ErrXDateTimeFormatError);
	dateRecP->month = num;

	PStringToNum(numStr[elemOrder[0]], &num);
	if (num > _DaysOfMonth(dateRecP->month, dateRecP->year) || num <= 0) return XError(kXLibError, ErrXDateTimeFormatError);
	dateRecP->day = num;
	SkipSpaceAndTab((char**)&strP, &charCount);
	
	// time
	if (charCount)
	{	i = 1;
		while(charCount && (*strP >= '0' && *strP <= '9') && (i < 14))
		{	aStr[i++] = *strP++;
			charCount--;
		}
		if (i > 3)
			return XError(kXLibError, ErrXDateTimeFormatError);
		if (i > 1)
			aStr[0] = --i;
		else
			return XError(kXLibError, ErrXDateTimeFormatError);
		PStringToNum(aStr, &num);
		if (NOT(charCount--))
			return XError(kXLibError, ErrXDateTimeFormatError);
		if (*strP++ != timeSep)
			return XError(kXLibError, ErrXDateTimeFormatError);
		dateRecP->hour = num;
		
		i = 1;
		while(charCount && (*strP >= '0' && *strP <= '9') && (i < 14))
		{	aStr[i++] = *strP++;
			charCount--;
		}
		if (i > 3)
			return XError(kXLibError, ErrXDateTimeFormatError);
		if (i > 1)
			aStr[0] = --i;
		else
			return XError(kXLibError, ErrXDateTimeFormatError);
		PStringToNum(aStr, &num);
		dateRecP->minute = num;
		if (charCount--)
		{	if (*strP++ != timeSep)
				return XError(kXLibError, ErrXDateTimeFormatError);
			if (*strP >= '0' && *strP <= '9')
			{	i = 1;
				while(charCount && (*strP >= '0' && *strP <= '9') && (i < 14))
				{	aStr[i++] = *strP++;
					charCount--;
				}
				if (i > 3)
					return XError(kXLibError, ErrXDateTimeFormatError);
				if (i > 1)
					aStr[0] = --i;
				else
					return XError(kXLibError, ErrXDateTimeFormatError);
				PStringToNum(aStr, &num);
				dateRecP->second = num;
			}
			else
				return XError(kXLibError, ErrXDateTimeFormatError);
		}
	}

return(0);
}

//===========================================================================================
XErr	XDateTimeToString(XDateTimeRecP dateRecP, char *dateStr, long flags, char *opt_formatStr)
{
CStr7		dayStr, yearStr, monthStr;
CStr7		hourStr, minStr, secStr;
int			elemOrder[3], i;
Byte		dateSep, timeSep;	
char		sepDateStr[2], sepTimeStr[2];
XErr		err = noErr;

	*dateStr = 0;
	if (flags & kWantDate)
	{	CNumToString(dateRecP->day, dayStr);
		CNumToString(dateRecP->year, yearStr);
		CNumToString(dateRecP->month, monthStr);
		if (flags & kLeadingZeros)
		{	_LeadTwoCharsStr(dayStr);
			_LeadTwoCharsStr(yearStr);
			_LeadTwoCharsStr(monthStr);
		}
		if (err = _DateTimeParamsFromOptionString(opt_formatStr, elemOrder, &dateSep, &timeSep))
			return err;
		*dateStr = 0;
		*sepDateStr = dateSep;
		*(sepDateStr+1) = 0;
		for (i = 0; i < 3; i++)
		{	switch(elemOrder[i])
			{	case 0:
					CAddStr(dateStr, dayStr);
					break;
				case 1:
					CAddStr(dateStr, monthStr);
					break;
				case 2:
					CAddStr(dateStr, yearStr);
					break;
			}
			if (i < 2)
				CAddStr(dateStr, sepDateStr);
		}
	}
	else
	{	if (err = _DateTimeParamsFromOptionString(opt_formatStr, elemOrder, &dateSep, &timeSep))
			return err;	
	}
	
	if (flags & kWantHour)
	{	if (flags & kWantDate)
			CAddChar(dateStr, '\t');
		CNumToString(dateRecP->hour, hourStr);
		CNumToString(dateRecP->minute, minStr);
		if (flags & kWantSecs)
			CNumToString(dateRecP->second, secStr);
		if (flags & kLeadingZeros)
		{	_LeadTwoCharsStr(hourStr);
			_LeadTwoCharsStr(minStr);
			if (flags & kWantSecs)
				_LeadTwoCharsStr(secStr);
		}
		*sepTimeStr = timeSep;
		*(sepTimeStr+1) = 0;
		CAddStr(dateStr, hourStr);
		CAddStr(dateStr, sepTimeStr);
		CAddStr(dateStr, minStr);
		if (flags & kWantSecs)
		{	CAddStr(dateStr, sepTimeStr);
			CAddStr(dateStr, secStr);
		}
	}
	
return err;
}

//===========================================================================================
void	XCurrentDateTimeToString(char *dateStr, long flags)
{
XDateTimeRec	xdateRec;
unsigned long	secs;

	XGetSeconds(&secs);
	SecondsToXDateTime(secs, &xdateRec);
	XDateTimeToString(&xdateRec, dateStr, flags, nil);
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*void	XValidDateTimeExt(XDateTimeRecExtP xdtRecP)
{
LONGLONG	seconds, min, hour, day, month, year, dom;

	seconds = xdtRecP->second;
	min = xdtRecP->minute;
	hour = xdtRecP->hour;
	day = xdtRecP->day;
	month = xdtRecP->month;
	year = xdtRecP->year;
	
	_RoundTimeExt(&seconds, &min, 60, true);
	_RoundTimeExt(&min, &hour, 60, true);
	_RoundTimeExt(&hour, &day, 24, true);
	_RoundTimeExt(&day, &month, 30, true);
	_RoundTimeExt(&month, &year, 12, false);

	xdtRecP->second = seconds;
	xdtRecP->minute = min;
	xdtRecP->hour = hour;
	xdtRecP->day = day;
	xdtRecP->month = month;
	if (year < LONG_MAX)
		xdtRecP->year = year;
	else
		xdtRecP->year = 0;
}
*/
//===========================================================================================
void	XValidDateTime(XDateTimeRecP xdtRecP)
{
long	seconds, min, hour, day, month, year, dom;

	seconds = xdtRecP->second;
	min = xdtRecP->minute;
	hour = xdtRecP->hour;
	day = xdtRecP->day;
	month = xdtRecP->month;
	year = xdtRecP->year;
	
	_RoundTime(&seconds, &min, 60, true);
	_RoundTime(&min, &hour, 60, true);
	_RoundTime(&hour, &day, 24, true);
	_RoundTime(&month, &year, 12, false);
	if (day > (dom = _DaysOfMonth(month, year)))
	{	do {	
			day -= dom;
			month++;
			if (month > 12)
			{	year++;
				month = 1;
			}
		} while (day > (dom = _DaysOfMonth(month, year)));
	}
	else if (day <= 0)
	{	do {	
			if (--month <= 0)
			{	year--;
				month = 12;
			}
			dom = _DaysOfMonth(month, year);
			day += dom;
		} while (day <= 0);
	}
	//spostato su il 5/11/2002 _RoundTime(&month, &year, 12, false);

	xdtRecP->second = seconds;
	xdtRecP->minute = min;
	xdtRecP->hour = hour;
	xdtRecP->day = day;
	xdtRecP->month = month;
	xdtRecP->year = year;
}

//===========================================================================================
/*
Returns:
"-1" se la prima data � > della seconda
" 0" se le due date sono uguali
" 1" se la seconda data � > della prima
*/
short	XCompareDateTime(XDateTimeRecP dateRec1, XDateTimeRecP dateRec2)
{
	if (dateRec1->year == dateRec2->year)
	{	if (dateRec1->month == dateRec2->month)
		{	if (dateRec1->day == dateRec2->day)
			{	if (dateRec1->hour == dateRec2->hour)
				{	if (dateRec1->minute == dateRec2->minute)
					{	if (dateRec1->second == dateRec2->second)
							return(0);
						else
						{	if (dateRec1->second > dateRec2->second)
								return(-1);
							else
								return(1);
						}
					}
					else
					{	if (dateRec1->minute > dateRec2->minute)
							return(-1);
						else
							return(1);
					}
				}
				else
				{	if (dateRec1->hour > dateRec2->hour)
						return(-1);
					else
						return(1);
				}
			}
			else
			{	if (dateRec1->day > dateRec2->day)
					return(-1);
				else
					return(1);
			}
		}
		else
		{	if (dateRec1->month > dateRec2->month)
				return(-1);
			else
				return(1);
		}
	}
	else
	{	if (dateRec1->year > dateRec2->year)
			return(-1);
		else
			return(1);
	}
}

//===========================================================================================
void	XDateTimeToGMT(XDateTimeRecP xdtRecP)
{
struct tm	tmRec;
time_t		caltime;

	XDateTime2ANSI(xdtRecP, (Ptr)&tmRec);
	caltime = mktime(&tmRec);
	tmRec = *gmtime(&caltime);
	ANSI2XDateTime((Ptr)&tmRec, xdtRecP);
}

//===========================================================================================
void	GetUString(XDateTimeRecP xdtRecP, char *date)
{
CStr15	value;

	if (xdtRecP->dayOfWeek)
		CEquStr(date, dayOfWeek[xdtRecP->dayOfWeek - 1]);
	else
		CEquStr(date, dayOfWeek[0]);
	CAddChar(date, ' ');
	CNumToString(xdtRecP->day, value);
	CAddStr(date, value);
	CAddChar(date, ' ');
	CAddStr(date, monthsOfYear[xdtRecP->month - 1]);
	CNumToString(xdtRecP->year, value);
	CAddStr(date, value);
	CAddChar(date, ' ');

	CNumToString(xdtRecP->hour, value);
	CAddStr(date, value);
	CAddChar(date, ':');
	CNumToString(xdtRecP->minute, value);
	CAddStr(date, value);
	CAddChar(date, ':');
	CNumToString(xdtRecP->second, value);
	CAddStr(date, value);
	CAddStr(date, " GMT");
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void	XGetSeconds(unsigned long *secsP)
{
time_t		lTime;
struct tm	dc;

	System_EnterCS();
	time(&lTime);
	*secsP = (unsigned long)lTime;
	
	dc = *localtime(&lTime);
/*#ifdef __UNIX_XLIB__
	if (dc.tm_isdst > 0)
		*secsP += 3600;
#endif*/
	System_LeaveCS();
}

//===========================================================================================
void	XDateTimeToSeconds(XDateTimeRecP xdtRecP, time_t *secsP)
{
	if ((xdtRecP->year < BASE_YEAR) || (xdtRecP->year > MAX_YEAR))
		*secsP = 0;
	else
	{	
		struct tm	dc;

		XDateTime2ANSI(xdtRecP, (Ptr)&dc);
		*secsP = mktime(&dc);			// UTC seconds
	}
}

//===========================================================================================
void	SecondsToXDateTime(time_t secs, XDateTimeRecP xdtRecP)
{
	struct tm	dc;
	time_t		t_secs = secs;

	dc = *localtime(&t_secs);
	ANSI2XDateTime((Ptr)&dc, xdtRecP);
/*#ifdef __UNIX_XLIB__
	if (dc.tm_isdst > 0)
		xdtRecP->hour--;
#endif*/
}

