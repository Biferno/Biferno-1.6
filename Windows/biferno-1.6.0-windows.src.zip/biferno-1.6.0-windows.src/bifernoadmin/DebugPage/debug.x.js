var	CODE_BOX = 0;
var	INCL_BOX = 1;

//==============================================================================
function pageWidth()
{
	var pw = window.innerWidth != null ? window.innerWidth: document.documentElement && document.documentElement.clientWidth ? document.documentElement.clientWidth:document.body != null? document.body.clientWidth:null;
	<? if (isIE) ?>
		pw += 12;
	return pw;
} 
//==============================================================================
/*function pageHeight()
{
	return window.innerHeight != null? window.innerHeight: document.documentElement && document.documentElement.clientHeight ? document.documentElement.clientHeight:document.body != null? document.body.clientHeight:null;
}*/
//==============================================================================
function sizeFrames()
{
	var min = 800;
	// alert(pageWidth())
	var innerWidth = pageWidth();
	if (innerWidth < min)
		innerWidth = min
	innerWidth -= 32 + 15;
	stackWidth = 250
	
	// stack menu
	var _stackMenu = document.getElementById("varStackMenuId");
	// alert(_stackMenu.style.width)
	
	// variables
	var _vars = document.getElementById("variables");
	_vars.style.width = innerWidth + 'px';	
	
	// detail var box
	var vd = document.getElementById("varDetail");
	vd.style.width = innerWidth + 'px';
	var vdTitle = document.getElementById("varDetailTitleBox");
	vdTitle.style.width = innerWidth + 'px';
	
	var k = 0;
	var stackBox, varBox;
	for (j = $curStack$; j > 0; j--)
		{
		cb_container = document.getElementById("sourceCode_" + k);
		cb_container.style.width = innerWidth + 'px';

		cb = document.getElementById("codeBox_" + j);
		cb.style.width = innerWidth + 'px';
		}

	<? incDim = includeStack.dim ?>
	for (j = $incDim$; j > 0; j--)
		{
		cb_container = document.getElementById("inclCode_" + k);
		cb_container.style.width = innerWidth + 'px';

		cb = document.getElementById("includeBox_" + j);
		cb.style.width = innerWidth + 'px';
		}
}

//==============================================================================
function ToggleLine(theElem, detailsID, theChar1)
{
	detailsSpan = document.getElementById(detailsID);
	arrowSpan1 = document.getElementById(detailsID + "_ar1");
	arrowSpan2 = document.getElementById(detailsID + "_ar2");
	if (detailsSpan.style.display == 'inline')
	{	detailsSpan.style.display = 'none'
		arrowSpan1.innerHTML = theChar1
		arrowSpan2.innerHTML = "&rarr;"
		//detailsSpan.style.color = 'blue'
		arrowSpan2.style.color = 'blue'
		arrowSpan1.style.cursor = 's-resize'
		arrowSpan2.style.cursor = 's-resize'
	}
	else
	{	detailsSpan.style.display = 'inline'
		arrowSpan1.innerHTML = "&rarr;"
		arrowSpan2.innerHTML = theChar1
		arrowSpan2.style.color = 'green'	// '$DebugPrefs.RED$'
		//detailsSpan.style.color = 'red'
		arrowSpan1.style.cursor = 'e-resize'
		arrowSpan2.style.cursor = 'e-resize'
	}
}

//==============================================================================
function CloseDetail()
{
	var _variableDetail = document.getElementById("variableDetail");
	_variableDetail.style.display = 'none'
}

//==============================================================================
function VarDetails(theTitle, theValue, theName)
{
	//var _mainTable = document.getElementById("mainTable");
	//alert(_mainTable.width)
	
	var _varDetTitle = document.getElementById("varDetTitle");
	_varDetTitle.innerHTML = theTitle
	var _varDetail = document.getElementById("varDetail");
	_varDetail.innerHTML = '<pre>' + theValue + '<\/pre>'
		
	var _variableDetail = document.getElementById("variableDetail");
	_variableDetail.style.display = '$DebugPrefs.DEBUG_DISPLAY_TABLE_ROW$'

}

//==============================================================================
function SelLine(baseIndex, lNum, box_type)
{
	// alert(baseIndex + " " + lNum)
	var	startTit;
	var	elemName;
	
	if (box_type == CODE_BOX)
		elemName = "codeBox_" + ($curStack$ - baseIndex);
	else
		elemName = "includeBox_" + ($incStack$ - baseIndex);
	
	var sourceBox = document.getElementById(elemName);
	var scrollVal = ((lNum-1) * 18) - 180;
	if (scrollVal < 0)
		scrollVal = 0
	sourceBox.scrollTop = scrollVal;
}

//==============================================================================
function setSorted(toSort)
{
	var	menuStack = document.getElementById('varStackMenuId')
	var	elemName = "variables_" + menuStack.selectedIndex;
	var	variablesFrame = document.getElementById(elemName);
	var variablesFrameSorted = document.getElementById(elemName + "_sorted");

	if (toSort)
	{
		variablesFrameSorted.style.display = "block";
		variablesFrame.style.display = "none";
	}
	else
	{
		variablesFrameSorted.style.display = "none";
		variablesFrame.style.display = "block";
	}

	gSorted = toSort;
}

//==============================================================================
function selectVarBox(which, toSet, totStack)
{
	var	elemName = "variables_" + which;
	var	variablesFrame = document.getElementById(elemName);
	var	variablesFrameSorted = document.getElementById(elemName + "_sorted");
	
	if (toSet)
		variablesFrame.style.display = "inline";
	else
	{	
		if (variablesFrameSorted)
			variablesFrameSorted.style.display = "none";
		variablesFrame.style.display = "none";
	}
	
}

//==============================================================================
function selectCodeAndMark(which, toSet, box_type)
{
	var	startTit, fileTitle, lineToSel;
	
	if (box_type == CODE_BOX)
	{
		startTit = "sourceCode_";
		fileTitle = gFilePath[which];
		lineToSel = gSelLines[which];
	}
	else
	{
		startTit = "inclCode_";
		fileTitle = gFilePath_i[which];
		lineToSel = gSelLines_i[which];
	}
	
	// console.log(startTit + which + " -> " + (toSet ? 'show': 'hide'));
	
	theElemCode = document.getElementById(startTit + which);
	// theStackLine = document.getElementById("stackLine_" + which);
	if (toSet)
	{	
		theElemCode.style.display = "inline";
		codeFilePathElem = document.getElementById('codeFilePath');
		codeFilePathElem.innerHTML = fileTitle
		// on IE calling setStackFrame directly doesn't work the first time
		setTimeout("SelLine(" + which + ", " + lineToSel + "," + box_type + ")", 1);
		
	}
	else
		theElemCode.style.display = "none";
}

//==============================================================================
function setStackFrame(newCurrent, tot)
{
	// var sortControlElem = document.getElementById('sortControl');

	// safari calls also for separator (tot) and white section of list (-1)
	if ((newCurrent >= 0) && (newCurrent != tot))
	{	
		if (gCurItem >= 0)
			selectVarBox(gCurItem, false, tot);
		if (gCurStack >= 0)
		{	
			selectVarBox(gCurStack, false, tot);
			if (newCurrent < tot)
				selectCodeAndMark(gCurStack, false, CODE_BOX);
		}
		if (newCurrent < tot)
		{	
			selectVarBox(newCurrent, true, tot);
			selectCodeAndMark(newCurrent, true, CODE_BOX);
			
			// hide current include
			if (gIncCurrent >= 0)
				selectCodeAndMark(gIncCurrent, false, INCL_BOX);

			gCurStack = newCurrent;
		}
		else
		{	
			selectVarBox(newCurrent, true, tot);
			gCurItem = newCurrent;
		}
	}
}

//==============================================================================
function setStackFrameFromMenu(theMenu, tot)
{
	var newCurrent = theMenu.selectedIndex
	setStackFrame(newCurrent, tot)
}

//==============================================================================
function setStackFrameDefault()
{
	sizeFrames()
	setStackFrame(0, $curStack$);
}

//==============================================================================
function setIncludeStackFrameFromMenu(theMenu)
{
	var newCurrentInclude = theMenu.selectedIndex - 1;
	
	// hide old include
	if (gIncCurrent >= 0)
		selectCodeAndMark(gIncCurrent, false, INCL_BOX);
		
	if (newCurrentInclude >= 0)
	{
		// set and show new current include
		gIncCurrent = newCurrentInclude;
		selectCodeAndMark(gIncCurrent, true, INCL_BOX);
		
		// hide current code block
		selectCodeAndMark(gCurStack, false, CODE_BOX);
	}
	else
	{
		// show the Current code block
		selectCodeAndMark(gCurStack, true, CODE_BOX);
	}
}

