<SCRIPT LANGUAGE="JavaScript">
	<!-- begin hiding of script
	function ShowWin(url)
	{
		variableWindow=window.open('', 'Win', 'scrollbars=yes,width=300,height=270')
		variableWindow.location = url
	}
	function ShowWinBig(url)
	{
		variableWindow=window.open('', 'Win', 'scrollbars=yes,width=320,height=270')
		variableWindow.location = url
	}
	function CheckWich(which)
	{
		document.AdminForm.which.value = which;
	}
	
	function CheckModifyWich(which)
	{
		document.AdminOneForm.modify_which.value = which;
	}

	function CheckForm()
	{	
		if (document.AdminOneForm.modify_which.value == 'delete')
			res = confirm('Do you really want to delete permanently this variable?');
		else
			res = true	
		if (res)
		{	window.close()
			// window.opener.location = "/index.bfr"
		}
		
	return true
	}
	
	// end script hiding -->
</SCRIPT>
