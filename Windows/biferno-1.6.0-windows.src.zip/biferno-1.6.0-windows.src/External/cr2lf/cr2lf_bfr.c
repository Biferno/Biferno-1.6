/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: cr2lf_bfr.c,v 1.4 2003-06-26 17:03:59 valfer Exp $
	|______________________________________________________________________________
*/
/*
	BAPI (Biferno Application Programming Interface)
	
	Example:		cr2lf
	
	Description:	BAPI Function substitutes CR to LF in a string
	
	Tabasoft Sas 2001
*/

// Includes
#include 	"BifernoAPI.h"

// Globals
static long		gs_cr2lfPluginID;

// Constants
#define	kCR2LF			1
#define	VERSION			"1.0b1"

//===========================================================================================
static XErr	_cr2lf(long api_data, ObjRef *param, ObjRef *result)
{
XErr		err = noErr;
CStr255		paramString;
char		*strP;
long		paramStringLength;

	// Get the string for the param objRef
	err = BAPI_ObjToString(api_data, param, paramString, &paramStringLength, 255, 
																		kImplicitTypeCast);
	if (err)
		return err;
	
	// Change CRs in LFs
	strP = paramString;
	while (*strP)
	{	if (*strP == '\r')
			*strP = '\n';
		strP++;
	}
	
	// Create the result object
	err = BAPI_StringToObj(api_data, paramString, paramStringLength, result);
	
return err;
}
#ifdef __MWERKS__
#pragma mark-
#endif
//===========================================================================================
/*
	We will have this event at Biferno start up.
*/
static XErr	_Register(Biferno_ParamBlockPtr pbPtr)
{
RegisterRec		*registerRecP = &pbPtr->param.registerRec;

	// Our extension implements a new Function (not a full class)
	registerRecP->pluginType = kNewFunctionsPlugin;
	
	// Give a name for the extension. Note that this is not the name
	// of the function (we will set it later).
	// No more than 63 chars
	CEquStr(registerRecP->pluginName, "cr2lf Function");
	
	// Give a description of the extension (Max 255 chars)
	CEquStr(registerRecP->pluginDescr, "Tabasoft cr2lf: Substitue CR to LF in a string");
	CEquStr(registerRecP->pluginVersionStr, VERSION);

	// Get the plugin ID
	gs_cr2lfPluginID = registerRecP->pluginID;
	
return noErr;
}

//===========================================================================================
/*
	In the Init function we declare the name, prototype, etc.. of the function we implement.
*/
static XErr	_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BAPI_MemberRecord	myFunction; 
		
	CEquStr(myFunction.name, "cr2lf");	
	myFunction.value = kCR2LF;
	CEquStr(myFunction.prototype, "string cr2lf(string text)");	
	
	// Declare our function(s)
	err = BAPI_NewFunctions(pbPtr->api_data, gs_cr2lfPluginID, &myFunction, 1);

return err;
}

//===========================================================================================
/*
	In the Execute Function we run our function (finally!)
*/
static XErr	_ExecuteFunction(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*executeMethodRecP = &pbPtr->param.executeMethodRec;

	// Choose the function to execute (for now is trivial)
	switch(executeMethodRecP->methodID)
	{
		case kCR2LF:
			err = _cr2lf(pbPtr->api_data, &executeMethodRecP->paramVarsP[0].objRef,
															&executeMethodRecP->resultObjRef);
			break;
	
		default:
			// Set the error "type" to kBAPI_Error and the error "value" to Err_NoSuchFunction
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
	}
	
return err;
}

#ifdef __MWERKS__
#pragma mark-
#pragma export on
#endif
//===========================================================================================
XErr	BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	// In out Dispatch we handle only the messages: kRegister, kInit and kExecuteFunction
	switch(message)
	{
		case kRegister:
			err = _Register(pbPtr);
			break;
		case kInit:
			err = _Init(pbPtr);
			break;
		case kShutDown:
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kClone:
		case kDestructor:
		case kExecuteOperation:
		case kExecuteMethod:
			break;
		case kExecuteFunction:
			err = _ExecuteFunction(pbPtr);
			break;
		case kGetProperty:
		case kSetProperty:
		case kPrimitive:
		case kGetErrMessage:
		case kSuperIsChanged:
		default:
			break;
	}
	
return err;
}
#ifdef __MWERKS__
#pragma export off
#endif

