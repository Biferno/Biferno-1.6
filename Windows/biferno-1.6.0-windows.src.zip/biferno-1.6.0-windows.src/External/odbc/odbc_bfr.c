/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: odbc_bfr.c,v 1.41 2006-05-30 14:53:14 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"BifernoAPI.h"
#include 	"BfrVersion.h"
#ifdef	ODBC_BUILT_IN
	#include 	"StaticClasses.h"
#endif

#include 	"BDBAPI.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include 	"DBConnectPool.h"

#ifdef __MAC_XLIB__
	#if __MACOSX__
		#include <iODBC/sql.h>
		#include <iODBC/sqlext.h>
		#include <iODBC/sqlucode.h>
		#include <iODBC/sqltypes.h>
	#else
		#include "sql.h"
		#include "sqlext.h"
	#endif
#elif __WIN_XLIB__
	#include <SQL.h>
	#include <SQLEXT.h>
#elif __UNIX_XLIB__
	#include <sql.h>
	#include <sqlext.h>
	#include <sqltypes.h>
#endif

#ifndef SQLLEN
	#define	SQLLEN	SQLINTEGER
#endif
#ifndef SQLULEN
	#define	SQLULEN	SQLUINTEGER
#endif


#define		MAX_PREPARED			16	// da levare

#define		BOUND_LIMIT				256
#define		GET_DATA_STEP			4096

#define		MAX_FIELD_TITLE_LENGTH	63
#define		MAX_ARRAY_ROW_SIZE		10000

#define	MAX_PARAMETERS			32

typedef struct
{		
	char 			title[MAX_FIELD_TITLE_LENGTH+1];
	long			maxSize;
	SQLSMALLINT		sqlType;
	BlockRef		boundVariableBlock;
	Ptr				boundVariableP;
	BlockRef		valueSizeIndicatorBlock;
	SQLLEN			*valueSizeIndicatorP;
} ODBCColumnDescr;

/*typedef struct
{		
	CStr255			name;		// name of the biferno bound obj
	char			staticStorage[MAX_BOUND_PARAM_LENGTH + 1];
	Ptr				valueP;
	BlockRef		valueBlock;
	long			valueStorage;
	SQLINTEGER		length;
	long			mode;
} ODBCParameterDescr;*/

typedef struct
{		
	HSTMT 			hstmt;
	CStr255			warning;
	long			curPos;
	long			firstFetched;
	long			lastFetched;
	long			realPos;
	long			totOutputBounds;
	Boolean			cursorExists;
	Boolean			notTotalBound;
	Boolean			fetchOff;
	Boolean			fromPool;
	long			cursorType;
	long			rowArraySize;
	long			totRecs;
	long			totColumns;
	BlockRef		columnDescr;
	ODBCColumnDescr	*columnDescrP;
	CStr255			sqlString;		// only for non scrollable
	BlockRef		stringBlock;	// only for non scrollable
	long			stringLen;		// only for non scrollable
	SQLUINTEGER		numRowsFetched;
	CStr255			rowStatus;
	BlockRef		rowStatusArrayBlock;
	SQLUSMALLINT	*rowStatusArrayP;
	long			totParameters;
	BlockRef		parameters[MAX_PARAMETERS];
} ODBCCursorRec;

typedef struct
{		
	long			slot;
	HDBC 			hdbc;
	long			poolConnectIndex;
	CStr63			host;
	CStr63			user;
	CStr63			password;
	CStr63			db;
	CStr255			warning;
} ODBCRec;

#define	myODBCClassName	"odbc"

static	SQLHANDLE				gHenv = 0;
static	long					odbcClassID;
static	long					gsApiVersion, gsMaxUsers;
static	PoolRef					gsODBCRecPoolRef = nil;
static	BlockRef				gsPoolConnectRecBlock = 0;
static	PoolConnectRec			*gsPoolConnectRecP;
static	BDBAPI_Rec				bdbRec;

XErr ODBC_BDBAPI_Dispatch(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr);

//===========================================================================================
static int _odbcErrorString(ODBCRec *odbcRecP, ODBCCursorRec *cursorP, char *resultString, char *sqlStateStr)
{
unsigned 	char buf[200];
unsigned 	char sqlstate[15];
SQLINTEGER	nativeError = 0;
RETCODE		res;

	if (resultString)
		*resultString = 0;	
	if (sqlStateStr)
		*sqlStateStr = 0;	
	if (gHenv)
	{	if (odbcRecP && odbcRecP->hdbc)
		{	if (cursorP)
			{	/*
				*  Get statement errors
				*/				
				res = SQLGetDiagRec(SQL_HANDLE_STMT, cursorP->hstmt, 1, sqlstate, &nativeError, buf, sizeof (buf), NULL);
				if ((res == SQL_SUCCESS) || (res == SQL_SUCCESS_WITH_INFO))
				{
					sprintf(resultString, "%s, SQLSTATE=%s\r\n", buf, sqlstate);
					CEquStr(sqlStateStr, (char*)sqlstate);
				}
			}
			/*
			*  Get connection errors
			*/
			res = SQLGetDiagRec(SQL_HANDLE_DBC, odbcRecP->hdbc, 1, sqlstate, &nativeError, buf, sizeof (buf), NULL);
			if ((res == SQL_SUCCESS) || (res == SQL_SUCCESS_WITH_INFO))
			{
				sprintf(resultString, "%s, SQLSTATE=%s\r\n", buf, sqlstate);
				CEquStr(sqlStateStr, (char*)sqlstate);
			}
		}
		/*
		*  Get environmental errors
		*/
		res = SQLGetDiagRec(SQL_HANDLE_ENV, gHenv, 1, sqlstate, &nativeError, buf, sizeof (buf), NULL);
		if ((res == SQL_SUCCESS) || (res == SQL_SUCCESS_WITH_INFO))
		{
			sprintf(resultString, "%s, SQLSTATE=%s\r\n", buf, sqlstate);
			CEquStr(sqlStateStr, (char*)sqlstate);
		}
		if (nativeError)
		{	CNumToString(nativeError, (char*)buf);
			CAddStr(resultString, " (Native Err: ");
			CAddStr(resultString, (char*)buf);
			CAddStr(resultString, ")");
		}
	}

return -1;
}

//===========================================================================================
static void	_odbcSetError(XErr *errP, ODBCRec *odbcRecP, ODBCCursorRec *cursorP, char *optString, char *strError)
{
CStr15		tStr;
XErr		err;
CStr255		tempStr, resultStr;
int			actLen, maxLen, strLen;
Boolean		addPeriods;

	if (errP)
		err = *errP;
	else
		err = noErr;
	*resultStr = 0;
	if NOT(err)
		err = ErrDBMSError;
	_odbcErrorString(odbcRecP, cursorP, resultStr, tempStr);
	CEquStr(strError, ":");
	CAddStr(strError, tempStr);
	if NOT(*resultStr)
	{	CNumToString(err, tStr);
		CAddStr(strError, tStr);
	}
	CAddStr(strError, ":odbc:");
	if (optString)
	{	CAddStr(strError, optString);
		CAddStr(strError, " - ");
	}
	if (strLen = CLen(resultStr))
	{	actLen = CLen(strError);
		maxLen = (sizeof(CStr255) - 1) - 3 - actLen;	// also ...
		if (strLen > maxLen)
		{	strLen = maxLen;
			addPeriods = true;
		}
		else
			addPeriods = false;
		CopyBlock(strError + actLen, resultStr, strLen);
		strError[actLen + strLen] = 0;
		if (addPeriods)
			CAddStr(strError, "...");
	}
	err = XError(kBAPI_ClassError, ErrDBMSError);
	if (errP)
		*errP = err;
}

//===========================================================================================
static XErr	ConnectionClosePoolCallBack(Ptr buffer)
{
HDBC	hdbc = *(HDBC*)buffer;
	
	SQLDisconnect(hdbc);
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);

return noErr;
}

/*#pragma mark-
//===========================================================================================
static XErr		_ClosePoolConnect(BlockRef poolBlockRef, PoolConnectRec *poolConnectP)
{
long				totConnect, i;
PoolConnectItem		*itemP;
XErr				err = noErr;

	XThreadsEnterCriticalSection();
	totConnect = poolConnectP->totConnect;
	itemP = poolConnectP->item;
	for (i = 0; i < totConnect; i++, itemP++)
	{	if (itemP->hdbc)
		{	SQLDisconnect(itemP->hdbc);
			SQLFreeHandle(SQL_HANDLE_DBC, itemP->hdbc);
		}
	}
	DisposeBlock(&poolBlockRef);
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	_GetPoolConnect(PoolConnectRec *poolConnectP, ODBCRec *odbcRecP, char *connString)
{
long				totConnect, i;
PoolConnectItem		*itemP;
XErr				err = noErr;

	XThreadsEnterCriticalSection();
	totConnect = poolConnectP->totConnect;
	itemP = poolConnectP->item;
	for (i = 0; i < totConnect; i++, itemP++)
	{	if (NOT(itemP->inUse) && NOT(CCompareStrings_cs(connString, itemP->connStr)))
		{	odbcRecP->hdbc = itemP->hdbc;
			itemP->inUse = true;
			odbcRecP->poolConnectIndex = i;
		}
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	_ReleasePoolConnect(PoolConnectRec *poolConnectP, ODBCRec *odbcRecP)
{
XErr	err = noErr;

	XThreadsEnterCriticalSection();
	poolConnectP->item[odbcRecP->poolConnectIndex].inUse = false;
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
static XErr	_AddPoolConnect(BlockRef poolBlockRef, PoolConnectRec **poolConnectPPtr, HDBC hdbc, char *connString, long *poolConnectIndexP)
{
long				totConnect;
PoolConnectItem		*itemP;
XErr				err = noErr;
PoolConnectRec 		*poolConnectP = *poolConnectPPtr;

	XThreadsEnterCriticalSection();
	totConnect = poolConnectP->totConnect;
	if NOT(err = SetBlockSize(poolBlockRef, sizeof(PoolConnectRec) + (totConnect * sizeof(PoolConnectItem))))
	{	*poolConnectPPtr = poolConnectP = (PoolConnectRec*)GetPtr(poolBlockRef);
		if (poolConnectIndexP)
			*poolConnectIndexP = totConnect;
		itemP = &poolConnectP->item[totConnect];
		itemP->hdbc = hdbc;
		CEquStr(itemP->connStr, connString);
		itemP->inUse = true;
		poolConnectP->totConnect++;
	}
	XThreadsLeaveCriticalSection();

return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
/*static XErr	_GetRowArraySize(ODBCRec *odbcRecP, long cursorID, HSTMT hstmt, char *error, long *rowArraySizeP)
{
SQLUINTEGER		rowArraySize;
XErr			err = noErr;

	if (SQLGetStmtAttr(hstmt, SQL_ATTR_ROW_ARRAY_SIZE, (SQLPOINTER)&rowArraySize, SQL_IS_UINTEGER, 0) == SQL_SUCCESS)
		*rowArraySizeP = rowArraySize;
	else
		_odbcSetError(&err, odbcRecP, cursorID, "SQLSetStmtAttr-SQL_ATTR_ROW_ARRAY_SIZE", error);
	
return err;
}*/

//===========================================================================================
static XErr	_AllocStatement(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{
XErr			err = noErr;

	XThreadsEnterCriticalSection();
	if (SQLAllocHandle(SQL_HANDLE_STMT, odbcRecP->hdbc, &cursorP->hstmt) != SQL_SUCCESS)
		_odbcSetError(&err, odbcRecP, 0, "_AllocStatement: SQLAllocHandle-SQL_HANDLE_STMT", error);
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
static XErr		_RowCount(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error, long *rowCountP)
{
SQLLEN			totRecs;
RETCODE			rc;
XErr			err = noErr;

	rc = SQLRowCount(cursorP->hstmt, &totRecs);
	if (rc == SQL_SUCCESS)
	{	if NOT(totRecs)
			totRecs = -1;
		*rowCountP = totRecs;
	}
	else
		_odbcSetError(&err, odbcRecP, cursorP, "_RowCount: SQLRowCount", error);

return err;
}

//===========================================================================================
static XErr	_ResetCursor(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{
XErr		err = noErr;
RETCODE		rc;

	if (cursorP->cursorExists)
	{	rc = SQLCloseCursor(cursorP->hstmt);
		if (rc != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, cursorP, "_ResetCursor: SQLCloseCursor", error);
		else
		{	cursorP->curPos = cursorP->realPos = 1;
			cursorP->totRecs = -1;
			cursorP->firstFetched = 0;
			cursorP->lastFetched = 0;
			cursorP->cursorExists = false;
			cursorP->fetchOff = 0;
			cursorP->numRowsFetched = 0;
		}
	}

return err;
}

//===========================================================================================
static XErr	_ExecStatement(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error, char *sqlStringP, long sqlStringLen, Boolean onlyPrepare, Boolean firstTime)
{	
XErr		err = noErr;

	if NOT(err = _ResetCursor(cursorP, odbcRecP, error))
	{	if (onlyPrepare)
		{	if (SQLPrepare(cursorP->hstmt, (UCHAR*)sqlStringP, sqlStringLen) != SQL_SUCCESS)
				_odbcSetError(&err, odbcRecP, cursorP, "_ExecStatement: SQLPrepare", error);
		}
		else
		{	if (cursorP->fromPool && NOT(firstTime))
			{	if (SQLExecute(cursorP->hstmt) != SQL_SUCCESS)
					_odbcSetError(&err, odbcRecP, cursorP, "_ExecStatement: SQLExecute", error);
			}
			else
			{	RETCODE	res = SQLExecDirect(cursorP->hstmt, (UCHAR*)sqlStringP, sqlStringLen);
				if (res == SQL_SUCCESS_WITH_INFO)
					_odbcSetError(nil, odbcRecP, cursorP, "_ExecStatement: SQLExecDirect", cursorP->warning);
				else if (res == SQL_NO_DATA)
				{	res = SQL_SUCCESS;
					CEquStr(cursorP->warning, "SQLExecDirect affected no data");
				}
				if ((res == SQL_SUCCESS) || (res == SQL_SUCCESS_WITH_INFO))
					cursorP->cursorExists = true;
				else
					_odbcSetError(&err, odbcRecP, cursorP, "_ExecStatement: SQLExecDirect", error);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_SetRowArraySize(ODBCCursorRec *cursorP, long rowArraySize, ODBCRec *odbcRecP, char *error, Boolean check)
{
XErr			err = noErr;
SQLUINTEGER		realRowArraySize;
RETCODE			rc;

	if (cursorP->rowArraySize != rowArraySize)
	{	if (check && cursorP->notTotalBound && (rowArraySize != 1))
			return noErr;
		else
		{	rc = SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_ROW_ARRAY_SIZE, (SQLPOINTER)rowArraySize, SQL_IS_UINTEGER);
			if (rc == SQL_SUCCESS_WITH_INFO)
			{	_odbcSetError(nil, odbcRecP, cursorP, "_SetRowArraySize: SQLSetStmtAttr:SQL_ATTR_ROW_ARRAY_SIZE", cursorP->warning);
				if (SQLGetStmtAttr(cursorP->hstmt, SQL_ATTR_ROW_ARRAY_SIZE, (SQLPOINTER)&realRowArraySize, SQL_IS_UINTEGER, 0) == SQL_SUCCESS)
					rowArraySize = realRowArraySize;
				else
					_odbcSetError(&err, odbcRecP, cursorP, "_SetRowArraySize: SQLGetStmtAttr-SQL_ATTR_ROW_ARRAY_SIZE", error);
			}	
			else if (rc != SQL_SUCCESS)
				_odbcSetError(&err, odbcRecP, cursorP, "_SetRowArraySize: SQLSetStmtAttr-SQL_ATTR_ROW_ARRAY_SIZE", error);
			if NOT(err)
				cursorP->rowArraySize = rowArraySize;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_SetRowBindByColumn(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{
XErr	err = noErr;
RETCODE	rc;

	//if NOT(cursorP->boundByColumn)
	//{	
	rc = SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_ROW_BIND_TYPE, SQL_BIND_BY_COLUMN, 0);
	if (rc != SQL_SUCCESS)
		_odbcSetError(&err, odbcRecP, cursorP, "_SetRowBindByColumn: SQLSetStmtAttr-SQL_ATTR_ROW_BIND_TYPE", error);
	//else
	//	cursorP->boundByColumn = true;
	//}
	
return err;
}

//===========================================================================================
/*static XErr	_GetCursorKeySize(ODBCCursorRec *cursorP, long *keysetSizeP, ODBCRec *odbcRecP, char *error)
{
SQLUINTEGER		keysetSize;
XErr			err = noErr;
RETCODE			rc;

	rc = SQLGetStmtAttr(hstmt, SQL_ATTR_KEYSET_SIZE, (SQLPOINTER)&keysetSize, SQL_IS_UINTEGER, 0);
	if (rc == SQL_SUCCESS)
		*keysetSizeP = keysetSize;
	else
		_odbcSetError(&err, odbcRecP, cursorID, "SQLGetStmtAttr-SQL_ATTR_KEYSET_SIZE", error);

return err;
}
*/
//===========================================================================================
/*static XErr	_SetCursorKeySize(ODBCCursorRec *cursorP, long keysetSize, ODBCRec *odbcRecP, char *error)
{
XErr			err = noErr;
RETCODE			rc;
SQLUINTEGER		realKeysetSize;

	if (cursorP->keySetSize != keysetSize)
	{	rc = SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_KEYSET_SIZE, (SQLPOINTER)keysetSize, SQL_IS_UINTEGER);
		if (rc == SQL_SUCCESS_WITH_INFO)
		{	if (SQLGetStmtAttr(cursorP->hstmt, SQL_ATTR_KEYSET_SIZE, (SQLPOINTER)&realKeysetSize, SQL_IS_UINTEGER, 0) == SQL_SUCCESS)
				keysetSize = realKeysetSize;
			else
				_odbcSetError(&err, odbcRecP, cursorP, "SQLGetStmtAttr-SQL_ATTR_KEYSET_SIZE", error);
		}
		else if (rc != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, cursorP, "SQLSetStmtAttr-SQL_ATTR_KEYSET_SIZE", error);
		if NOT(err)
			cursorP->keySetSize = keysetSize;
	}
	
return err;
}*/

//===========================================================================================
static XErr	_SetFetchOff(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{
XErr	err = noErr;

	if NOT(cursorP->fetchOff)
	{	if (SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_RETRIEVE_DATA, (SQLPOINTER)SQL_RD_OFF, 0) != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, cursorP, "_SetFetchOff: SQLSetStmtAttr: SQL_ATTR_RETRIEVE_DATA(SQL_RD_OFF)", error);
		else
			cursorP->fetchOff = true;
	}
	
return err;
}

//===========================================================================================
static XErr	_SetFetchOn(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{
XErr	err = noErr;

	if (cursorP->fetchOff)
	{	if (SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_RETRIEVE_DATA, (SQLPOINTER)SQL_RD_ON, 0) != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, cursorP, "_SetFetchOn: SQLSetStmtAttr: SQL_ATTR_RETRIEVE_DATA(SQL_RD_ON)", error);
		else
			cursorP->fetchOff = false;
	}
	
return err;
}
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	_FreeColDescrs(ODBCCursorRec *cursorP)
{
XErr			err = noErr;
ODBCColumnDescr	*descrP;
int				totCols, i;

	if (cursorP->columnDescr)
	{	descrP = cursorP->columnDescrP;
		totCols = cursorP->totColumns;
		for (i = 0; i < totCols; i++, descrP++)
		{	if (descrP->boundVariableBlock)
				DisposeBlock(&descrP->boundVariableBlock);
			if (descrP->valueSizeIndicatorBlock)
				DisposeBlock(&descrP->valueSizeIndicatorBlock);
		}
		if (cursorP->rowStatusArrayBlock)
			DisposeBlock(&cursorP->rowStatusArrayBlock);
		cursorP->rowStatusArrayP = nil;
		if (cursorP->columnDescr)
			DisposeBlock(&cursorP->columnDescr);
	}
	
return err;
}

//===========================================================================================
static void	_FreeParameters(ODBCCursorRec *cursorP)
{
	bdbRec.BDBAPI_DisposeParams(0, 0, cursorP->parameters, cursorP->totParameters);
	cursorP->totParameters = 0;
	/*if (totParameters = cursorP->totParameters)
	{	for (i = 0; i < MAX_PARAMETERS; i++)
		{	if (tBl = cursorP->parameters[i])
			{	paramDescrP = (ODBCParameterDescr*)GetPtr(tBl);
				if (paramDescrP->valueBlock)
					DisposeBlock(&paramDescrP->valueBlock);
				DisposeBlock(&cursorP->parameters[i]);
				if NOT(--totParameters)
					break;
			}
		}
		cursorP->totParameters = 0;
	}*/
}

//===========================================================================================
static XErr	_FreePreparedCursor(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, Boolean totalFree, char *error)
{
XErr				err = noErr;
RETCODE				rc;

	if (cursorP->cursorExists)
	{	rc = SQLCloseCursor(cursorP->hstmt);
		if (rc != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, cursorP, "_FreePreparedCursor: SQLCloseCursor", error);
		else
			cursorP->cursorExists = false;
	}
	if (totalFree)
	{	if (SQLFreeHandle(SQL_HANDLE_STMT, cursorP->hstmt) != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, 0, "_FreePreparedCursor: SQLFreeHandle-SQL_HANDLE_STMT", error);
		if (cursorP->stringBlock)
			DisposeBlock(&cursorP->stringBlock);
	}
	
return err;
}

//===========================================================================================
static XErr	_disposePreparedCallBack(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(api_data)
#endif
ODBCCursorRec	*cursorP = (ODBCCursorRec*)the_cursorP;
ODBCRec			*odbcRecP = (ODBCRec*)userData;
XErr			err = noErr, err2 = noErr;

	//if (busy)
	err = _FreePreparedCursor(cursorP, odbcRecP, true, error);
	_FreeParameters(cursorP);
	err2 = _FreeColDescrs(cursorP);
	if (NOT(err) && err2)
		err = err2;
	
return err;
}

typedef struct {
				ODBCRec		*odbcRecP;
				BindRec		*bindRecP;
				} BindRecord;

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static RETCODE	_FetchScroll(HSTMT hstmt, SQLSMALLINT mode, long curPos)
{
	return SQLFetchScroll(hstmt, mode, curPos);
}

//===========================================================================================
/*static ODBCCursorRec*	_GetCursorP(long api_data, ODBCRec *odbcRecP, long cursID, Boolean poolMandatory)
{
long			cursRealID, poolID;
ODBCCursorRec	*cursorP = nil;

	_GetCursorValueCB(api_data, cursID, &poolID, &cursRealID);
	if (cursRealID > 0)
	{	if (poolID)
		{	BlockRef	preparedBlock;
		
			if ((poolID > 0) && (poolID <= odbcRecP->totPrepared))
			{	preparedBlock = odbcRecP->prepared[poolID-1].block;
				cursorP = ((ODBCCursorRec*)GetPtr(preparedBlock)) + (cursRealID - 1);
			}
		}
		else if (poolMandatory)
			cursorP = nil;
		else
			cursorP = &odbcRecP->cursor[cursRealID-1];
	}
	
return cursorP;
}*/

//===========================================================================================
static XErr	_FreeCursor(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{
XErr		err = noErr;
RETCODE		rc;

	_FreeColDescrs(cursorP);
	if (cursorP->stringBlock)
		DisposeBlock(&cursorP->stringBlock);
	if (cursorP->cursorExists)
	{	rc = SQLCloseCursor(cursorP->hstmt);
		if (rc != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, cursorP, "_FreeCursor: SQLCloseCursor", error);
	}

return err;
}

//===========================================================================================
static XErr	_BindColumns(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{	
XErr			err = noErr;
SQLSMALLINT		totCols;
ODBCColumnDescr	*descrP;
HSTMT			hstmt = cursorP->hstmt;
int				i;

	if (cursorP->rowStatusArrayP)
	{	if (SQLSetStmtAttr(hstmt, SQL_ATTR_ROW_STATUS_PTR, cursorP->rowStatusArrayP, 0) != SQL_SUCCESS)
			_odbcSetError(&err, odbcRecP, cursorP, "_BindColumns: SQLSetStmtAttr-SQL_ATTR_ROW_STATUS_PTR", error);
		else
		{	descrP = cursorP->columnDescrP;
			totCols = (SQLSMALLINT)cursorP->totColumns;
			for (i = 1; (i <= totCols) && NOT(err); i++, descrP++)
			{	if (descrP->maxSize <= BOUND_LIMIT)
				{	if (SQLBindCol(hstmt, (SQLSMALLINT)i, SQL_C_CHAR, (SQLPOINTER)descrP->boundVariableP, descrP->maxSize+1, descrP->valueSizeIndicatorP) != SQL_SUCCESS)
						_odbcSetError(&err, odbcRecP, cursorP, "_BindColumns: SQLBindCol", error);
				}
				else
					break;
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_UnbindColumns(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error)
{
XErr		err = noErr;
HSTMT		hstmt = cursorP->hstmt;

	if (SQLSetStmtAttr(hstmt, SQL_ATTR_ROW_STATUS_PTR, NULL, 0) != SQL_SUCCESS)
		_odbcSetError(&err, odbcRecP, cursorP, "_UnbindColumns: SQLSetStmtAttr-SQL_ATTR_ROW_STATUS_PTR", error);
	else
		SQLFreeStmt(hstmt, SQL_UNBIND);

return err;
}

//===========================================================================================
static long	_FieldNumFromName(ODBCCursorRec *cursorP, char *fieldName)
{
long			totCols = cursorP->totColumns, i;
ODBCColumnDescr	*descrP;

	descrP = cursorP->columnDescrP;
	for (i = 1; i <= totCols; i++, descrP++)
	{	if NOT(CCompareStrings_cs(fieldName, descrP->title))
			return i;
	}

return 0;
}

//===========================================================================================
static XErr	_DescribeColumns(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error, Boolean alsoBind)
{	
SQLSMALLINT		sqlType, decimals, nullable, i, totCols, titleLen;
ODBCColumnDescr	*descrP;
HSTMT			hstmt = cursorP->hstmt;
XErr			err = noErr;
SQLULEN			maxSize;
long			totSize;

	if (SQLNumResultCols(hstmt, &totCols) == SQL_SUCCESS)
	{	if (totCols)
		{	cursorP->totColumns = totCols;
			totSize = sizeof(ODBCColumnDescr) * totCols;
			if NOT(cursorP->columnDescr)
			{	if (cursorP->columnDescr = NewPtrBlock(totSize, &err, (Ptr*)&descrP))
				{	cursorP->columnDescrP = descrP;	// = cursorP->columnDescrP = (ODBCColumnDescr*)GetPtr(cursorP->columnDescr);
					ClearBlock(descrP, totSize);
				}
			}
			else
				descrP = cursorP->columnDescrP;
			if NOT(err)
			{	if (totCols < (255 / sizeof(SQLUSMALLINT)))
					cursorP->rowStatusArrayP = (SQLUSMALLINT*)cursorP->rowStatus;
				else
				{	if (cursorP->rowStatusArrayBlock)
						err = SetBlockSize(cursorP->rowStatusArrayBlock, sizeof(SQLUSMALLINT) * cursorP->rowArraySize);
					else
						cursorP->rowStatusArrayBlock = NewBlockLocked(sizeof(SQLUSMALLINT) * cursorP->rowArraySize, &err, nil);
					if NOT(err)
						cursorP->rowStatusArrayP = (SQLUSMALLINT*)GetPtr(cursorP->rowStatusArrayBlock);
				}
				if NOT(err)
				{	if (alsoBind)
					{	if (SQLSetStmtAttr(hstmt, SQL_ATTR_ROW_STATUS_PTR, cursorP->rowStatusArrayP, 0) != SQL_SUCCESS)
							_odbcSetError(&err, odbcRecP, cursorP, "_DescribeColumns: SQLSetStmtAttr-SQL_ATTR_ROW_STATUS_PTR", error);
					}
					if NOT(err)
					{	for (i = 1; (i <= totCols) && NOT(err); i++, descrP++)
						{	if (SQLDescribeCol(hstmt, i, (UCHAR*)descrP->title, MAX_FIELD_TITLE_LENGTH, &titleLen, &sqlType, &maxSize, &decimals, &nullable) != SQL_SUCCESS)
								_odbcSetError(&err, odbcRecP, cursorP, "_DescribeColumns: SQLDescribeCol", error);
							else
							{	if NOT(maxSize)
								{	// 24/2/2004 In some drivers (i.e. FrontBase) SQLDescribeCol returns 0 as maxSize (not reliable?)
									if (SQLColAttribute(hstmt, i, SQL_DESC_DISPLAY_SIZE, NULL, 0, NULL, (SQLLEN*)&maxSize) != SQL_SUCCESS)
										_odbcSetError(&err, odbcRecP, cursorP, "_DescribeColumns: SQLColAttribute", error);
								}
								if NOT(err)
								{	descrP->maxSize = maxSize;
									descrP->title[titleLen] = 0;
									descrP->sqlType = sqlType;
									if ((maxSize <= BOUND_LIMIT) && NOT(cursorP->notTotalBound))	// no "bound" column after a "GetData" column
									{	if (descrP->boundVariableBlock)
											err = SetBlockSize(descrP->boundVariableBlock, (maxSize+2) * cursorP->rowArraySize);
										else
											descrP->boundVariableBlock = NewBlockLocked((maxSize+2) * cursorP->rowArraySize, &err, nil);
										if NOT(err)
										{	descrP->boundVariableP = GetPtr(descrP->boundVariableBlock);
											if (descrP->valueSizeIndicatorBlock)
												err = SetBlockSize(descrP->valueSizeIndicatorBlock, sizeof(SQLINTEGER) * cursorP->rowArraySize);
											else
												descrP->valueSizeIndicatorBlock = NewBlockLocked(sizeof(SQLINTEGER) * cursorP->rowArraySize, &err, nil);
											if NOT(err)
											{	descrP->valueSizeIndicatorP = (SQLLEN*)GetPtr(descrP->valueSizeIndicatorBlock);
												if (alsoBind)
												{	if (SQLBindCol(hstmt, i, SQL_C_CHAR, (SQLPOINTER)descrP->boundVariableP, descrP->maxSize+1, descrP->valueSizeIndicatorP) != SQL_SUCCESS)
														_odbcSetError(&err, odbcRecP, cursorP, "_DescribeColumns: SQLBindCol", error);
												}
											}
										}
									}
									else
										cursorP->notTotalBound = true;
								}
							}
						}
						if (NOT(err) && cursorP->notTotalBound)
							err = _SetRowArraySize(cursorP, 1, odbcRecP, error, false);
					}
				}
				if (err)
					DisposeBlock(&cursorP->columnDescr);
			}
		}
		else
			cursorP->cursorExists = false;
	}
	else
		_odbcSetError(&err, odbcRecP, cursorP, "_DescribeColumns: SQLNumResultCols", error);
	
return err;
}

//===========================================================================================
static XErr	_GetCursorType(ODBCCursorRec *cursorP, ODBCRec *odbcRecP, char *error, long *cursTypeP)
{
SQLUINTEGER		cursType;
XErr			err = noErr;
RETCODE			rc;

	rc = SQLGetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)&cursType, SQL_IS_UINTEGER, 0);
	if (rc == SQL_SUCCESS)
	{	*cursTypeP = cursType;
		/*switch(cursType)
		{	case SQL_CURSOR_FORWARD_ONLY:
				*cursTypeP = SQL_CURSOR_FORWARD_ONLY;
				break;
			case SQL_CURSOR_STATIC:
				*cursTypeP = SQL_CURSOR_STATIC;
				break;
			case SQL_CURSOR_KEYSET_DRIVEN:
				*cursTypeP = SQL_CURSOR_KEYSET_DRIVEN;
				break;
			case SQL_CURSOR_DYNAMIC:
				*cursTypeP = SQL_CURSOR_DYNAMIC;
				break;
		}*/
	}
	else
		_odbcSetError(&err, odbcRecP, cursorP, "_GetCursorType: SQLGetStmtAttr-SQL_ATTR_CURSOR_TYPE", error);

return err;
}

//===========================================================================================
static XErr	_SetCursorType(ODBCCursorRec *cursorP, long type, ODBCRec *odbcRecP, char *error, Boolean firstTime)
{
SQLINTEGER		which;
XErr			err = noErr;
RETCODE			res;

	if (firstTime)
	{	switch (type)
		{	case kDynamic:
				which = SQL_CURSOR_DYNAMIC;
				if  ((res = SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)which, SQL_IS_INTEGER)) != SQL_SUCCESS)
				{	if (res = SQL_SUCCESS_WITH_INFO)
						_odbcSetError(nil, odbcRecP, cursorP, "_SetCursorType: SQL_CURSOR_DYNAMIC->SQL_CURSOR_KEYSET_DRIVEN", odbcRecP->warning);
					which = SQL_CURSOR_KEYSET_DRIVEN;
					if  (SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)which, SQL_IS_INTEGER) != SQL_SUCCESS)
					{	if (res = SQL_SUCCESS_WITH_INFO)
							_odbcSetError(nil, odbcRecP, cursorP,  "_SetCursorType: SQL_CURSOR_DYNAMIC->SQL_CURSOR_FORWARD_ONLY", odbcRecP->warning);
						which = SQL_CURSOR_FORWARD_ONLY;
						if  (SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)which, SQL_IS_INTEGER) != SQL_SUCCESS)
							_odbcSetError(&err, odbcRecP, cursorP, "_SetCursorType: SQLSetStmtAttr", error);
					}
				}
				break;
			case kStatic:
			case kDefault:
			default:
				which = SQL_CURSOR_STATIC;
				if  ((res = SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)which, SQL_IS_INTEGER)) != SQL_SUCCESS)
				{	if (res = SQL_SUCCESS_WITH_INFO)
						_odbcSetError(nil, odbcRecP, cursorP, "_SetCursorType: SQL_CURSOR_STATIC->SQL_CURSOR_KEYSET_DRIVEN", odbcRecP->warning);
					which = SQL_CURSOR_KEYSET_DRIVEN;
					if  (SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)which, SQL_IS_INTEGER) != SQL_SUCCESS)
					{	which = SQL_CURSOR_FORWARD_ONLY;
						if (res = SQL_SUCCESS_WITH_INFO)
							_odbcSetError(nil, odbcRecP, cursorP, "_SetCursorType: SQL_CURSOR_STATIC->SQL_CURSOR_FORWARD_ONLY", odbcRecP->warning);
						if  (SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)which, SQL_IS_INTEGER) != SQL_SUCCESS)
							_odbcSetError(&err, odbcRecP, cursorP, "_SetCursorType: SQLSetStmtAttr", error);
					}
				}
				break;
		}
		/*if (which != SQL_CURSOR_FORWARD_ONLY)
		{	rc = SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER)which, SQL_IS_INTEGER);
			if (rc == SQL_SUCCESS_WITH_INFO)
				err = _GetCursorType(cursorP, odbcRecP, error, &which);
			else if (rc != SQL_SUCCESS)
				_odbcSetError(&err, odbcRecP, cursorP, "SQLSetStmtAttr", error);
		}*/
		if NOT(err)
			cursorP->cursorType = which;
	}
	if NOT(err)
	{	if NOT(err = _SetRowBindByColumn(cursorP, odbcRecP, error))
			err = _SetRowArraySize(cursorP, cursorP->rowArraySize, odbcRecP, error, true);
	}

return err;
}

//===========================================================================================
static XErr	_ExecuteQuery(ODBCCursorRec *cursorP, char *sqlStringP, long sqlStringLen, Boolean onlyPrepare, Boolean firstTime, ODBCRec *odbcRecP, char *error)
{
XErr		err = noErr;
Ptr			p;

	if (firstTime)
		err = _AllocStatement(cursorP, odbcRecP, error);
	if NOT(err)
	{	if NOT(err = _SetCursorType(cursorP, cursorP->cursorType, odbcRecP, error, firstTime))
		{	if (SQLSetStmtAttr(cursorP->hstmt, SQL_ATTR_ROWS_FETCHED_PTR, &cursorP->numRowsFetched, SQL_IS_UINTEGER) != SQL_SUCCESS)
				_odbcSetError(&err, odbcRecP, cursorP, "_ExecuteQuery: SQLSetStmtAttr-SQL_ATTR_ROWS_FETCHED_PTR", error);
			if NOT(err)
			{	if (firstTime && NOT(onlyPrepare) && (cursorP->cursorType == SQL_CURSOR_FORWARD_ONLY))
				{	if (sqlStringLen < 255)
					{	CEquStr(cursorP->sqlString, sqlStringP);
						cursorP->stringBlock = 0;
						cursorP->stringLen = sqlStringLen;
					}
					else if (cursorP->stringBlock = NewBlock(sqlStringLen+1, &err, &p))
					{	//p = GetPtr(cursorP->stringBlock);
						CopyBlock(p, sqlStringP, sqlStringLen);
						p[sqlStringLen] = 0;
						cursorP->stringLen = sqlStringLen;
					}
				}
				if NOT(err)
				{	if NOT(err = _ExecStatement(cursorP, odbcRecP, error, sqlStringP, sqlStringLen, onlyPrepare, firstTime))
					{	if (firstTime)
						{	cursorP->curPos = 1;
							cursorP->totRecs = -1;
						}
						cursorP->realPos = 1;
					}
				}
			}
		}
		if (err && firstTime)
			SQLFreeHandle(SQL_HANDLE_STMT, cursorP->hstmt);
	}

return err;
}

//===========================================================================================
static XErr	_ForwardOnlyBeginFromScratch(long api_data, long db_api_data, ODBCCursorRec *cursorP, long cursID, ODBCRec *odbcRecP, char *error)
{
XErr			err = noErr;
RETCODE			rc;
HSTMT			hstmt = cursorP->hstmt;
BlockRef		bl;
char			*sqlP;
int				len;
PrepareParams	params;
long			prepareID;

	rc = SQLCloseCursor(hstmt);
	if (rc != SQL_SUCCESS)
		_odbcSetError(&err, odbcRecP, cursorP, "_ForwardOnlyBeginFromScratch: SQLCloseCursor", error);
	else
	{	if (cursorP->fromPool)
		{	if NOT(err = bdbRec.BDBAPI_GetCursorPrepareID(api_data, db_api_data, cursID, &prepareID))
			{	if NOT(err = bdbRec.BDBAPI_GetPrepareParams(api_data, db_api_data, prepareID, &params))
				{	sqlP = params.sqlStringP;
					len = params.sqlStringLen;
				}
			}
		}
		else
		{	bl = cursorP->stringBlock;
			if (bl)
				sqlP = GetPtr(bl);
			else
				sqlP = cursorP->sqlString;
			len = cursorP->stringLen;
		}
		if (bl)
		{	LockBlock(bl);
			err = _ExecuteQuery(cursorP, sqlP, len, false, false, odbcRecP, error);
			UnlockBlock(bl);
		}
		else
			err = _ExecuteQuery(cursorP, sqlP, len, false, false, odbcRecP, error);
		if NOT(err)
			err = _BindColumns(cursorP, odbcRecP, error);
	}
	
return err;
}

//===========================================================================================
// N.B. If you are across pages, you must fetch singles
static XErr	_Scroll(ODBCCursorRec *cursorP, long from, long to, ODBCRec *odbcRecP, char *error)
{
XErr		err = noErr, err2 = noErr;
long		mod, diff, i, totSingleScroll, totPageScroll, rowArraySize;
HSTMT		hstmt = cursorP->hstmt;
RETCODE		rc = SQL_SUCCESS;

	if (diff = to - from)
	{	if NOT(err = _UnbindColumns(cursorP, odbcRecP, error))
		{	if (SQLSetStmtAttr(hstmt, SQL_ATTR_RETRIEVE_DATA, (SQLPOINTER)SQL_RD_OFF, 0) == SQL_SUCCESS)
			{	rowArraySize = cursorP->rowArraySize;
				mod = rowArraySize - ((from-1) % rowArraySize);
				totSingleScroll = mod == rowArraySize ? 0 : mod-1;
				if (totSingleScroll)
				{	if NOT(err = _SetRowArraySize(cursorP, 1, odbcRecP, error, false))
					{	for (i = 0; (i < totSingleScroll) && NOT(err); i++)
						{	rc = _FetchScroll(hstmt, SQL_FETCH_NEXT, 0);
							cursorP->realPos += cursorP->numRowsFetched;
							if (rc == SQL_NO_DATA)
								break;
							else if (rc != SQL_SUCCESS)
								_odbcSetError(&err, odbcRecP, cursorP, "_Scroll: SQLFetch", error);
						}
					}
				}
				if (NOT(err) && (rc != SQL_NO_DATA))
				{	diff -= totSingleScroll;
					if (totPageScroll = diff / rowArraySize)
					{	err = _SetRowArraySize(cursorP, rowArraySize, odbcRecP, error, false);
						if NOT(err)
						{	for (i = 0; (i < totPageScroll) && NOT(err); i++)
							{	rc = _FetchScroll(hstmt, SQL_FETCH_NEXT, 0);
								cursorP->realPos += cursorP->numRowsFetched;
								if (rc == SQL_NO_DATA)
									break;
								else if (rc != SQL_SUCCESS)
									_odbcSetError(&err, odbcRecP, cursorP, "_Scroll: SQLFetch", error);
							}
						}
					}
					if (NOT(err) && (rc != SQL_NO_DATA))
					{	diff -= (totPageScroll * rowArraySize);
						if (totSingleScroll = diff)
						{	err = _SetRowArraySize(cursorP, 1, odbcRecP, error, false);
							if NOT(err)
							{	for (i = 0; (i < totSingleScroll) && NOT(err); i++)
								{	rc = _FetchScroll(hstmt, SQL_FETCH_NEXT, 0);
									cursorP->realPos += cursorP->numRowsFetched;
									if (rc == SQL_NO_DATA)
										break;
									else if (rc != SQL_SUCCESS)
										_odbcSetError(&err, odbcRecP, cursorP, "_Scroll: SQLFetch", error);
								}
							}
						}
					}
				}
				err2 = _SetRowArraySize(cursorP, rowArraySize, odbcRecP, error, false);	
				if NOT(err)
					err = err2;
				if (SQLSetStmtAttr(hstmt, SQL_ATTR_RETRIEVE_DATA, (SQLPOINTER)SQL_RD_ON, 0) != SQL_SUCCESS)
				{	_odbcSetError(&err2, odbcRecP, cursorP, "_Scroll: SQLSetStmtAttr: SQL_ATTR_RETRIEVE_DATA(ON)", error);
					if NOT(err)
						err = err2;
				}
			}
			err2 = _BindColumns(cursorP, odbcRecP, error);
			if NOT(err)
				err = err2;
		}
		else
			_odbcSetError(&err, odbcRecP, cursorP, "_Scroll: SQLSetStmtAttr-SQL_ATTR_RETRIEVE_DATA(OFF)", error);
		
	}

return err;
}

//===========================================================================================
/*
PROVE di _GetLongData
static XErr		_GetLongData(long api_data, ODBCCursorRec *cursorP, long columnIndex, ODBCRec *odbcRecP, char *error, ObjRef *objRefP)
{	
RETCODE		rc;
//SQLINTEGER	offset;
Ptr			tempP;
BlockRef	block;
XErr		err = noErr;
//char		*textTempP;
Boolean		expanded = false;
CStr255		tempStr, strError;
long		actLen;
SQLINTEGER	length = 0;

	actLen = 6000;	//GET_DATA_STEP;
	if (block = NewBlock(actLen + 1, &err))
	{	LockBlock(block);
		tempP = GetPtr(block);
		do {
			rc = SQLGetData(cursorP->hstmt, columnIndex, SQL_C_CHAR, tempP, actLen, &length);
			length -= CLen(tempP);
			switch(rc)
			{	case SQL_SUCCESS_WITH_INFO:
					_odbcErrorString(odbcRecP, cursorP, tempStr, strError);
				case SQL_SUCCESS:
					if (length == SQL_NULL_DATA)
					{	totLen = 0;
						goto finished;
					}
					else
					{	returnLen = CLen(textTempP);
						totLen += returnLen;
						offset += returnLen;
						if NOT(expanded)
						{	
					actLen += GET_DATA_STEP;
					if NOT(err = SetBlockSize(block, actLen + 1))
						tempP = GetPtr(block);
					break;
				case SQL_NO_DATA:
					goto finished;
				default:
					_odbcSetError(&err, odbcRecP, cursorP, "SQLGetData", error);
					break;
			}
		} while NOT(err);
	finished:
		if NOT(err)
			err = BAPI_StringToObj(api_data, tempP, CLen(tempP), objRefP);
		DisposeBlock(&block);
	}

return err;
}

*/
//===========================================================================================
static XErr		_GetLongData(long api_data, ODBCCursorRec *cursorP, long columnIndex, ODBCRec *odbcRecP, char *error, ObjRef *objRefP)
{	
RETCODE		rc;
SQLINTEGER	offset;
SQLLEN		length;
Ptr			tempP;
BlockRef	block;
long		returnLen, blockSize;
XErr		err = noErr;
char		*textTempP;
//Boolean		expanded = false;
CStr255		tempStr, strError;

	blockSize = GET_DATA_STEP;
	if (block = NewBlockLocked(blockSize, &err, &tempP))
	{	//LockBlock(block);
		//tempP = GetPtr(block);
		offset = 0;
		do {
			textTempP = tempP + offset;
			length = 0;
			rc = SQLGetData(cursorP->hstmt, (unsigned short)columnIndex, SQL_C_CHAR, textTempP, blockSize - offset, &length);
			switch(rc)
			{	case SQL_SUCCESS_WITH_INFO:
					_odbcErrorString(odbcRecP, cursorP, tempStr, strError);
					//_odbcSetError(nil, odbcRecP, cursorP, "SQLGetData", cursorP->warning);
				case SQL_SUCCESS:
					switch(length)
					{
						case SQL_NULL_DATA:
						case SQL_NO_TOTAL:
							offset = 0;
							goto finished;

						case 0:
							goto finished;

						default:
							if (length < 0)
							{	_odbcSetError(&err, odbcRecP, cursorP, "SQLGetData: length < 0", error);
								goto finished;
							}
							else
							{	returnLen = CLen(textTempP);
								offset += returnLen;
								if (blockSize < (offset + length + 1))
								{	blockSize = offset + length + 1;
									if NOT(err = SetBlockSize(block, blockSize))
										tempP = GetPtr(block);
								}
							}
							break;
					}
					break;
					/*
					ex:
					if (length == SQL_NULL_DATA)
					{	totLen = 0;
						goto finished;
					}
					else if NOT(length)
						goto finished;
					else
					{	returnLen = CLen(textTempP);
						totLen += returnLen;
						offset += returnLen;
						if NOT(expanded)
						{	if NOT(err = SetBlockSize(block, returnLen + length + 1))
							{	tempP = GetPtr(block);
								maxStorage = returnLen + length;
								expanded = true;
							}
						}
					}*/

				case SQL_NO_DATA:
					goto finished;
					
				default:
					_odbcSetError(&err, odbcRecP, cursorP, "_GetLongData: SQLGetData", error);
					break;
			}
		} while NOT(err);
	finished:
		if NOT(err)
			err = BAPI_StringToObj(api_data, tempP, offset, objRefP);
		DisposeBlock(&block);
	}

return err;
}

//===========================================================================================
static XErr	_BuondVarsToArray(long api_data, ODBCCursorRec *cursorP, long index, ObjRef *resultObjRefP, ODBCRec *odbcRecP, Boolean undefNull, char *error)
{	
XErr			err = noErr;
ODBCColumnDescr	*descrP;
long			totCols;
ObjRef			tObjRef, arrayObjRef;
int				i;
SQLINTEGER		vsInd;
SQLUSMALLINT	rs;
Ptr				boundP;
CStr255			aCStr;
CStr15			tStr;
int				ind, titleLen;

	descrP = cursorP->columnDescrP;
	totCols = cursorP->totColumns;
	//BAPI_InvalObjRef(api_data, &arrayObjRef);
	arrayObjRef = *resultObjRefP;
	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &arrayObjRef))
	{	if (index != -1)
		{	if (cursorP->rowStatusArrayP)
			{	rs = cursorP->rowStatusArrayP[index];
				if ((rs == SQL_ROW_SUCCESS) || (rs == SQL_ROW_SUCCESS_WITH_INFO))
				{	for (i = 1; i <= totCols; i++, descrP++)
					{	boundP = descrP->boundVariableP + (index * (descrP->maxSize+1));
						BAPI_InvalObjRef(api_data, &tObjRef);
						if (descrP->valueSizeIndicatorP)
						{	vsInd = descrP->valueSizeIndicatorP[index];
							switch(vsInd)
							{	case SQL_NULL_DATA:
									if (undefNull)
										err = BAPI_StringToObj(api_data, DB_NULL_VALUE, DB_NULL_VALUE_LEN, &tObjRef);
									else
										err = BAPI_StringToObj(api_data, "", 0, &tObjRef);
									break;
								case SQL_NO_TOTAL:
									err = BAPI_StringToObj(api_data, "SQL_NO_TOTAL", 0, &tObjRef);	// non dovrebbe mai succedere
									break;
								default:
									err = BAPI_StringToObj(api_data, boundP, vsInd, &tObjRef);
									break;
							}
						}
						else
							err = _GetLongData(api_data, cursorP, i, odbcRecP, error, &tObjRef);
						if NOT(err)
						{	err = BAPI_ArrayAddElement(api_data, &arrayObjRef, descrP->title, &tObjRef);
							if (err && (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName)))
							{	ind = 2;
								titleLen = CLen(descrP->title);
								do {
									CNumToString(ind++, tStr);
									if ((titleLen + 1 + CLen(tStr)) < 255)
									{	CEquStr(aCStr, descrP->title);
										CAddStr(aCStr, "_");
										CAddStr(aCStr, tStr);
										err = BAPI_ArrayAddElement(api_data, &arrayObjRef, aCStr, &tObjRef);
									}
									else
									{	err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
										break;
									}
								} while (err == XError(kBAPI_Error, Err_DuplicatedArrayElemName));
							}
						}
						else
							break;
					}
				}
				else if (rs == SQL_ROW_ERROR)
					_odbcSetError(&err, odbcRecP, cursorP, "_BuondVarsToArray: rowStatusArray", error);
			}
		}
		if NOT(err)
			*resultObjRefP = arrayObjRef;
	}
	
return err;
}
#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
/*static XErr	_Info(long api_data, Ptr connBuffP, long which, ObjRef *resObjP)
{
XErr			err = noErr;
unsigned int	version;
CStr255			aCStr;
ODBCRec			*odbcRecP;
char			*strP = nil;
	
	if (connBuffP)
		odbcRecP = (ODBCRec*)connBuffP;
	switch (which)
	{	
		case kInfo:
			strP = mysql_info_EntryPoint(odbcRecP->connection);
			break;
		case kServerInfo:
			strP = mysql_get_server_info_EntryPoint(odbcRecP->connection);
			break;
		case kHostInfo:
			strP = mysql_get_host_info_EntryPoint(odbcRecP->connection);
			break;
		case kProtoInfo:
			version = mysql_get_proto_info_EntryPoint(odbcRecP->connection);
			CNumToString(version, aCStr);
			strP = aCStr;
			break;
		case kStat:
			strP = mysql_stat_EntryPoint(odbcRecP->connection);
			break;
		case kClientInfo:
			strP = mysql_get_client_info_EntryPoint();
			break;
		
		default:
			break;
	}
	if (strP)
		err = BAPI_StringToObj(api_data, strP, CLen(strP), resObjP);
	else
		err = BAPI_StringToObj(api_data, "", 0, resObjP);
	
return err;
}
*/

//===========================================================================================
//long api_data, char *connectionString, long len, BlockRef *connBuffBlockRefP, long *connBuffLenP, char *error
static XErr	_Connect(BDBAPI_ParamBlockPtr pbPtr)
{
ODBCRec		*odbcRecP;
XErr		err = noErr;
RETCODE		rc;
UCHAR		buf[2048];
short		buflen;
//long 		api_data = pbPtr->api_data;
uint32_t	slot;
ConnectRec	*connectRecP = &pbPtr->param.connectRec;
//BlockRef	block;

	slot = 0;
	if NOT(err = PoolNewPtr(gsODBCRecPoolRef, (Ptr*)&odbcRecP, &slot))
	{	ClearBlock(odbcRecP, sizeof(ODBCRec));
		odbcRecP->slot = slot;
		//odbcRecP->block = block;
		if NOT(err = GetPoolConnect(gsPoolConnectRecP, (Ptr)&odbcRecP->hdbc, sizeof(HDBC), connectRecP->connString, &odbcRecP->poolConnectIndex))
		{	if NOT(odbcRecP->hdbc)
			{	XThreadsEnterCriticalSection();
				if (SQLAllocConnect(gHenv, &odbcRecP->hdbc) == SQL_SUCCESS)
				{	rc = SQLDriverConnect(odbcRecP->hdbc, NULL, (UCHAR*)connectRecP->connString, SQL_NTS, (UCHAR*)buf, sizeof(buf), &buflen, SQL_DRIVER_NOPROMPT);
					if (rc == SQL_SUCCESS_WITH_INFO)
						_odbcSetError(nil, odbcRecP, nil, "SQLDriverConnect", odbcRecP->warning);
					if ((rc != SQL_SUCCESS) && (rc != SQL_SUCCESS_WITH_INFO))
					{	_odbcSetError(&err, odbcRecP, 0, "SQLDriverConnect", pbPtr->error);
						SQLFreeHandle(SQL_HANDLE_DBC, odbcRecP->hdbc);
					}
				}
				else
					_odbcSetError(&err, nil, 0, "SQLAllocConnect", pbPtr->error);
				if NOT(err)
					err = AddPoolConnect(gsPoolConnectRecBlock, &gsPoolConnectRecP, (Ptr)&odbcRecP->hdbc, sizeof(HDBC), connectRecP->connString, &odbcRecP->poolConnectIndex);
				XThreadsLeaveCriticalSection();
			}
		}
	}
	if NOT(err)
	{	connectRecP->connBufferLength = sizeof(ODBCRec);
		connectRecP->connBuffer = nil;	//block;
		connectRecP->connPointer = (Ptr)odbcRecP;
	}
	else if (slot)
		PoolDisposePtr(gsODBCRecPoolRef, slot);

return err;
}

//===========================================================================================
static XErr	_FreeCursorCallBack(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(api_data)
#endif
ODBCCursorRec	*cursorP = (ODBCCursorRec*)the_cursorP;
ODBCRec			*odbcRecP = (ODBCRec*)userData;
XErr			err = noErr;

	if (/*busy && */cursorP->hstmt)
	{	err = _FreeCursor(cursorP, odbcRecP, error);
		SQLFreeHandle(SQL_HANDLE_STMT, cursorP->hstmt);
	}
	
return err;
}

//===========================================================================================
static XErr	_Disconnect(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
long 			api_data = pbPtr->api_data, db_api_data = pbPtr->db_api_data;
char			*error = pbPtr->error;

	err = bdbRec.BDBAPI_DisposeAllCursorsSlots(api_data, db_api_data, _FreeCursorCallBack, (long)odbcRecP, error);
	/*
	totCursors = odbcRecP->totCursors;
	total = MAX_CURSOR;
	for (i = 0, idx = 0; (i < total) && (idx < totCursors); i++)
	{	cursorP = &odbcRecP->cursor[i];
		if (cursorP->hstmt && cursorP->busy)			// gi� disposto?
		{	err = _FreeCursor(cursorP, odbcRecP, error);
			SQLFreeHandle(SQL_HANDLE_STMT, cursorP->hstmt);
			idx++;
		}
	}
	*/
	ReleasePoolConnect(gsPoolConnectRecP, odbcRecP->poolConnectIndex);
	err = bdbRec.BDBAPI_DisposeAllPrepares(api_data, db_api_data, _disposePreparedCallBack, (long)odbcRecP, error);
	/*if (totPrepares = odbcRecP->totPrepared)
	{	
		// prepareBlockP = &odbcRecP->prepared[0].block;
		preparedItemP = &odbcRecP->prepared[0];
		for (i = 0; i < totPrepares; i++, preparedItemP++)
		{	
			err = _ReleasePrepareCB(api_data, preparedItemP, _disposePreparedCallBack, (long)odbcRecP, error);
		}
	}*/
	PoolDisposePtr(gsODBCRecPoolRef, odbcRecP->slot);

return err;
}

//===========================================================================================
static XErr	_FetchRec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
ODBCCursorRec	*cursorP;
long			cursID;
HSTMT 			hstmt;
int				index;
int				curPos, realPos;
Boolean			undefNull, toRefetch;	//, finished = false;
SQLSMALLINT		mode;
RETCODE			rc;

	cursID = pbPtr->param.fetchRec.cursorID;
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, cursID, (Ptr*)&cursorP))
	{	undefNull = pbPtr->param.fetchRec.undefNull;
		hstmt = cursorP->hstmt;
		curPos = cursorP->curPos;
		realPos = cursorP->realPos;
		toRefetch = (cursorP->curPos < cursorP->firstFetched) || (cursorP->curPos > cursorP->lastFetched);
		if (toRefetch)
		{	cursorP->firstFetched = curPos;
			if (realPos != curPos)
			{	if (cursorP->cursorType == SQL_CURSOR_FORWARD_ONLY)
				{	if (realPos > curPos)
						err = _ForwardOnlyBeginFromScratch(pbPtr->api_data, pbPtr->db_api_data, cursorP, cursID, odbcRecP, pbPtr->error);
					if (curPos != 1)
						err = _Scroll(cursorP, cursorP->realPos, curPos, odbcRecP, pbPtr->error);
					if NOT(err)
						mode = SQL_FETCH_NEXT;
				}
				else
					mode = SQL_FETCH_ABSOLUTE;
			}
			else
				mode = SQL_FETCH_NEXT;		
			if NOT(err)
			{	rc = _FetchScroll(cursorP->hstmt, mode, curPos);		// scroll until end
				if (rc == SQL_SUCCESS_WITH_INFO)
					_odbcSetError(nil, odbcRecP, cursorP, "SQLFetchScroll", cursorP->warning);
				if ((rc == SQL_SUCCESS) || (rc == SQL_SUCCESS_WITH_INFO))
				{	cursorP->realPos = curPos + cursorP->numRowsFetched;
					cursorP->lastFetched = cursorP->realPos - 1;
				}
				else if (rc == SQL_NO_DATA)
				{	if (mode == SQL_FETCH_ABSOLUTE)
						cursorP->realPos = curPos + cursorP->numRowsFetched;
				}
				else
					_odbcSetError(&err, odbcRecP, cursorP, "_FetchAfter: SQLFetchScroll", pbPtr->error);
			}
		}
		if NOT(err)
		{	cursorP->curPos++;
			if (curPos > cursorP->lastFetched)
				index = -1;
			else
				index = curPos-cursorP->firstFetched;
			err = _BuondVarsToArray(pbPtr->api_data, cursorP, index, &pbPtr->param.fetchRec.object, odbcRecP, undefNull, pbPtr->error);
		}
	}

return err;
}

//===========================================================================================
static XErr	_BindCursor(ODBCRec	*odbcRecP, ODBCCursorRec *cursorP, long paramNum, long paramMode, long paramStorage, char *paramObjName, char *error)
{	
XErr					err = noErr;
RETCODE					rc;
BlockRef				storageBlock;
BDBAPI_ParameterDescr	*paramP;
SQLSMALLINT				mode;
BDBAPI_ParameterDescr	*paramDescrP;
long					paramNumZB = paramNum - 1;

	if (paramNum > MAX_PARAMETERS)
		_odbcSetError(&err, odbcRecP, cursorP, "_Bind: Invalid Param Num", error);
	else if (cursorP->parameters[paramNumZB])	// exists
	{	paramDescrP = (BDBAPI_ParameterDescr*)GetPtr(cursorP->parameters[paramNumZB]);
		if (paramDescrP->valueBlock)
			DisposeBlock(&paramDescrP->valueBlock);
		DisposeBlock(&cursorP->parameters[paramNumZB]);
		cursorP->totParameters--;
	}
	if NOT(err)
	{	if (storageBlock = NewPtrBlock(sizeof(BDBAPI_ParameterDescr), &err, (Ptr*)&paramP))
		{	ClearBlock(paramP, sizeof(BDBAPI_ParameterDescr));
			switch(paramMode)
			{
				case kInputBindMode:
					mode = SQL_PARAM_INPUT;
					break;
				case kOutputBindMode:
					mode = SQL_PARAM_OUTPUT;
					break;
				case kInputOutputBindMode:
					mode = SQL_PARAM_INPUT_OUTPUT;
					break;
				default:
					mode = SQL_PARAM_INPUT;
					break;		
			}
			paramP->valueStorage = paramStorage + 1;
			if (paramP->valueBlock = NewPtrBlock(paramP->valueStorage, &err, (Ptr*)&paramP->valueP))
			{	rc = SQLBindParameter(cursorP->hstmt, (unsigned short)paramNum, mode, SQL_C_CHAR, SQL_CHAR, paramP->valueStorage, 0, (SQLPOINTER)paramP->valueP, paramP->valueStorage, &paramP->length);
				if (rc != SQL_SUCCESS)
					_odbcSetError(&err, odbcRecP, cursorP, "_Bind:SQLBindParameter", error);			
				if NOT(err)
				{	if (cursorP->totParameters < MAX_PARAMETERS)
					{	CEquStr(paramP->name, paramObjName);
						paramP->mode = paramMode;
						cursorP->parameters[paramNumZB] = storageBlock;
						cursorP->totParameters++;
					}
					else
						_odbcSetError(&err, odbcRecP, cursorP, "_Bind: Too many parameters", error);
				}
				if (err)
					DisposeBlock(&paramP->valueBlock);
			}
			if (err)
				DisposeBlock(&storageBlock);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_Bind(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ODBCRec				*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
BindRec				*bindRecP = &pbPtr->param.bindRec;
ODBCCursorRec		*cursorP;
//long 				api_data = pbPtr->api_data;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, bindRecP->cursorID, (Ptr*)&cursorP))
		err = _BindCursor(odbcRecP, cursorP, bindRecP->paramNum, bindRecP->paramMode, bindRecP->paramStorage, bindRecP->paramObjName, pbPtr->error);

return err;
}

//===========================================================================================
static XErr	_Call(BDBAPI_ParamBlockPtr pbPtr, Boolean isExt)
{
XErr					err = noErr, err2 = noErr;
ODBCRec					*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
CallRec					*callRecP = &pbPtr->param.callRec;
long 					cursID, queryStringLen, lastLoop, pos, totParams, i, api_data = pbPtr->api_data, db_api_data = pbPtr->db_api_data;
RETCODE					rc;
ODBCCursorRec			*cursorP;
BlockRef				storageBlock[MAX_PARAMETERS], returnStorageBlock = 0;
BDBAPI_ParameterDescr	*ret_paramP, *paramP[MAX_PARAMETERS];
SQLSMALLINT				mode;
CStr255					aCStr, queryString;

	totParams = callRecP->totParams;
	if (totParams > MAX_PARAMETERS)
	{	_odbcSetError(&err, odbcRecP, nil, "_Call: Too many parameters", pbPtr->error);
		return err;
	}
	
	ClearBlock(storageBlock, sizeof(BlockRef) * MAX_PARAMETERS);
	ClearBlock(paramP, sizeof(BDBAPI_ParameterDescr*) * MAX_PARAMETERS);
	// Get a free cursor
	err = bdbRec.BDBAPI_NewCursorSlot(api_data, db_api_data, &cursID, (Ptr*)&cursorP);
	/*
	XThreadsEnterCriticalSection();
	cursorP = &odbcRecP->cursor[0];
	for (i = 0; i < MAX_CURSOR; i++, cursorP++)
	{	if NOT(cursorP->busy)
			break;
	}
	if (i == MAX_CURSOR)
	{	CEquStr(pbPtr->error, "odbc: Too many cursor (call 'Free(int cursorID)' to dispose a Cursor)");
		err = XError(kBAPI_ClassError, ErrTooManyCursors);
	}
	else
	{	odbcRecP->totCursors++;
		ClearBlock(cursorP, sizeof(ODBCCursorRec));
		cursorP->busy = true;
		cursID = _SetCursorValueCB(pbPtr->api_data, (short)0, (short)(i+1));
	}
	XThreadsLeaveCriticalSection();
	*/
	if NOT(err)
	{	if NOT(err = _AllocStatement(cursorP, odbcRecP, pbPtr->error))
		{	// Bind the return value
			if (returnStorageBlock = NewPtrBlock(sizeof(BDBAPI_ParameterDescr), &err, (Ptr*)&ret_paramP))
			{	rc = SQLBindParameter(cursorP->hstmt, 1, SQL_PARAM_OUTPUT, SQL_C_CHAR, SQL_CHAR, MAX_BOUND_PARAM_LENGTH, 0, (SQLPOINTER)ret_paramP->staticStorage, MAX_BOUND_PARAM_LENGTH, &ret_paramP->length);
				if (rc != SQL_SUCCESS)
					_odbcSetError(&err, odbcRecP, cursorP, "_Call:SQLBindParameter", pbPtr->error);
			}
			// Bind all the parameters
			if NOT(err)
			{	CEquStr(queryString, "{? = CALL ");
				CAddStr(queryString, callRecP->procName);
				queryStringLen = CAddStr(queryString, "(");
				lastLoop = totParams - 1;
				for (i = 0, pos = 2; (i < totParams) && NOT(err); i++)
				{	if (storageBlock[i] = NewPtrBlock(sizeof(BDBAPI_ParameterDescr), &err, (Ptr*)&paramP[i]))
					{	if (BAPI_IsReference(pbPtr->api_data, &callRecP->params[i].objRef))
							mode = SQL_PARAM_INPUT_OUTPUT;
						else
							mode = SQL_PARAM_INPUT;
						rc = SQLBindParameter(cursorP->hstmt, (unsigned short)pos++, mode, SQL_C_CHAR, SQL_CHAR, MAX_BOUND_PARAM_LENGTH, 0, (SQLPOINTER)paramP[i]->staticStorage, MAX_BOUND_PARAM_LENGTH, &paramP[i]->length);
						if (rc != SQL_SUCCESS)
							_odbcSetError(&err, odbcRecP, cursorP, "_Call:SQLBindParameter", pbPtr->error);			
						if NOT(err)
						{	paramP[i]->mode = mode;
							// Copy parameter value to the bound buffer
							if (BAPI_IsObjRefValid(api_data, &callRecP->params[i].objRef))
							{	if NOT(err = BAPI_ObjToString(api_data, &callRecP->params[i].objRef, aCStr, nil, 256, kImplicitTypeCast))
								{	CEquStr((char*)paramP[i]->staticStorage, aCStr);
									paramP[i]->length = CLen(aCStr);
									if (queryStringLen + 3 < 255)
									{	if (i == lastLoop)
											queryStringLen = CAddStr(queryString, "?");
										else
											queryStringLen = CAddStr(queryString, "?, ");
									}
									else
										_odbcSetError(&err, odbcRecP, cursorP, "_Call:String too long", pbPtr->error);
								}
							}
						}
					}
				}
				if NOT(err)
				{	if (queryStringLen + 3 < 255)
						queryStringLen = CAddStr(queryString, ")}");
					else
						_odbcSetError(&err, odbcRecP, cursorP, "_Call:String too long", pbPtr->error);
					if NOT(err)
					{	rc = SQLExecDirect(cursorP->hstmt, (UCHAR*)queryString, queryStringLen);
						if (rc != SQL_SUCCESS)
							_odbcSetError(&err, odbcRecP, cursorP, "_Call:SQLExecDirect", pbPtr->error);			
						if NOT(err)
						{	cursorP->cursorExists = true;
							// retrieve return value
							if NOT(err = BAPI_StringToObj(api_data, ret_paramP->staticStorage, ret_paramP->length, callRecP->returnValue))
							{	// retrieve input/output params
								for (i = 0; (i < totParams) && NOT(err); i++)
								{	if (paramP[i]->mode == SQL_PARAM_INPUT_OUTPUT)
										err = BAPI_StringToObj(api_data, paramP[i]->staticStorage, paramP[i]->length, &callRecP->params[i].objRef);
								}
							}
						}
					}
				}
			}
		}
	}

	// termination
	if (returnStorageBlock)
		DisposeBlock(&returnStorageBlock);
	for (i = 0; (i < totParams); i++)
		DisposeBlock(&storageBlock[i]);
	if (isExt)
	{	XThreadsEnterCriticalSection();
		callRecP->cursorID = /*odbcRecP->lastCursor = */cursID;
		XThreadsLeaveCriticalSection();
	}
	else
	{	err2 = bdbRec.BDBAPI_DisposeCursorSlot(api_data, db_api_data, cursID, _FreeCursorCallBack, (long)odbcRecP, pbPtr->error);
		/*XThreadsEnterCriticalSection();
		if NOT(err2 = _FreeCursor(cursorP, odbcRecP, pbPtr->error))
		{	cursorP->busy = false;
			odbcRecP->totCursors--;
		}
		XThreadsLeaveCriticalSection();*/
		if (err2 && NOT(err))
			err = err2;
	}
	
return err;
}

//===========================================================================================
static XErr	_Exec(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
ExecRec			*execRecP = &pbPtr->param.execRec;
ODBCCursorRec	*cursorP, cursoOnStack;

	if (execRecP->dontReturnCursor)
	{	cursorP = &cursoOnStack;
		ClearBlock(cursorP, sizeof(ODBCCursorRec));
	}
	else
		err = bdbRec.BDBAPI_NewCursorSlot(pbPtr->api_data, pbPtr->db_api_data, &execRecP->cursorID, (Ptr*)&cursorP);
	if NOT(err)
	{	cursorP->cursorType = execRecP->cursorMode;
		cursorP->rowArraySize = execRecP->rowSetSize;
		if NOT(err = _ExecuteQuery(cursorP, execRecP->sqlStringP, execRecP->sqlStringLen, execRecP->onlyPrepare, true, odbcRecP, pbPtr->error))
			err = _DescribeColumns(cursorP, odbcRecP, pbPtr->error, true);
	}
	if (execRecP->dontReturnCursor && NOT(err))
		_FreeCursorCallBack(pbPtr->api_data, pbPtr->db_api_data, (Ptr)cursorP, (long)odbcRecP, pbPtr->error);
	else if (err && NOT(execRecP->dontReturnCursor))
		bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, execRecP->cursorID, nil, 0, pbPtr->error);	// free the slot
	
return err;
}

typedef struct
{
	PrepareRec		*prepareRecP;
	ODBCRec			*odbcRecP;
} PrepareCallBackRec;

//===========================================================================================
static XErr	_PrepareCallBack(long api_data, long db_api_data, Ptr the_cursorP, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(api_data)
#endif
ODBCCursorRec			*cursorP = (ODBCCursorRec*)the_cursorP;
PrepareCallBackRec		*prepCBRecP = (PrepareCallBackRec*)userData;
XErr					err = noErr;
PrepareRec				*prepareRecP = prepCBRecP->prepareRecP;

	cursorP->cursorType = prepareRecP->cursorMode;
	cursorP->rowArraySize = prepareRecP->rowSetSize;
	if NOT(err = _ExecuteQuery(cursorP, prepareRecP->sqlStringP, prepareRecP->sqlStringLen, true, true, prepCBRecP->odbcRecP, error))
		;// describe after _ExecPrepared err = _DescribeColumns(cursorP, prepCBRecP->odbcRecP, error, false);

return err;
}

//===========================================================================================
static XErr	_FreePrepare(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ODBCRec				*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
FreePrepareRec		*freePrepareRecP = &pbPtr->param.freePrepareRec;

	err = bdbRec.BDBAPI_DisposePrepare(pbPtr->api_data, pbPtr->db_api_data, freePrepareRecP->prepareID, _disposePreparedCallBack, (long)odbcRecP, pbPtr->error);
	
return err;
}

//===========================================================================================
static XErr	_Prepare(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ODBCRec				*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
PrepareRec			*prepareRecP = &pbPtr->param.prepareRec;
PrepareCallBackRec	prepCBRec;
PrepareParams		params;

	params.sqlStringP = prepareRecP->sqlStringP;
	params.sqlStringLen = prepareRecP->sqlStringLen;
	params.totCursors = prepareRecP->totCursors;
	//params.cursorMode = prepareRecP->cursorMode;
	params.userData = (long)odbcRecP;
	prepCBRec.prepareRecP = prepareRecP;
	prepCBRec.odbcRecP = odbcRecP;
	if NOT(err = bdbRec.BDBAPI_NewPrepare(pbPtr->api_data, pbPtr->db_api_data, &params, _PrepareCallBack, (long)&prepCBRec, pbPtr->error))
		prepareRecP->prepareID = params.prepareID;
	
return err;
}

//===========================================================================================
static XErr	_GetPrepared(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
//ODBCRec				*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
GetPreparedRec		*getPreparedRecP = &pbPtr->param.getPreparedRec;
ODBCCursorRec		*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetPreparedCursor(pbPtr->api_data, pbPtr->db_api_data, getPreparedRecP->prepareID, &getPreparedRecP->cursorID, (Ptr*)&cursorP))
	{	cursorP->fromPool = true;
		cursorP->curPos = cursorP->realPos = 1;
		cursorP->totRecs = -1;
		cursorP->firstFetched = 0;
		cursorP->lastFetched = 0;
		cursorP->cursorExists = false;
		cursorP->fetchOff = 0;
		cursorP->numRowsFetched = 0;
		// delayed until after ExecPrepared err = _BindColumns(cursorP, odbcRecP, pbPtr->error);
	}

return err;
}

//===========================================================================================
static XErr	_bindCallBack(long api_data, long db_api_data, Ptr cursorP, long userData, char *error)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(api_data)
#endif
BindRecord		*bindRecordP = (BindRecord*)userData;
BindRec			*bindRecP = bindRecordP->bindRecP;

	return _BindCursor(bindRecordP->odbcRecP, (ODBCCursorRec*)cursorP, bindRecP->paramNum, bindRecP->paramMode, bindRecP->paramStorage, bindRecP->paramObjName, error);
}

//===========================================================================================
static XErr	_BindAll(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
BindRec			*bindRecP = &pbPtr->param.bindRec;
BindRecord		bindRecord;

	bindRecord.odbcRecP = odbcRecP;
	bindRecord.bindRecP = bindRecP;
	//preparedItemP = &odbcRecP->prepared[bindRecP->prepareID-1];
	err = bdbRec.BDBAPI_PrepareLoop(pbPtr->api_data, pbPtr->db_api_data, bindRecP->prepareID, _bindCallBack, (long)&bindRecord, pbPtr->error);
	
return err;
}

//===========================================================================================
static Boolean 	_IsParamNull(BDBAPI_ParameterDescr *paramP, long index, long userData)
{
	return (paramP->length == SQL_NULL_DATA);
}

//===========================================================================================
static XErr	_ExecPrepared(BDBAPI_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ODBCRec				*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
ExecPreparedRec		*execPreparedRecP = &pbPtr->param.execPreparedRec;
ODBCCursorRec		*cursorP;
long				api_data = pbPtr->api_data, db_api_data = pbPtr->db_api_data;
char				*error = pbPtr->error;
RETCODE				rc;
SQLSMALLINT			totCols;
CStr63				aCStr;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, execPreparedRecP->cursorID, (Ptr*)&cursorP))
	{	if NOT(err = _ResetCursor(cursorP, odbcRecP, error))
		{	/*if (totParameters = cursorP->totParameters)
			{	index = 0;
				tot = MAX_PARAMETERS;
				do 
				{	if (tBl = cursorP->parameters[index++])
					{	paramP = (ODBCParameterDescr*)GetPtr(tBl);
						if ((paramP->mode == SQL_PARAM_INPUT) || (paramP->mode == SQL_PARAM_INPUT_OUTPUT))
						{	if NOT(err = BAPI_IsVariableDefined(api_data, (char*)paramP->name, 0, &isDef, &tObjRef))
							{	if (isDef)
									err = BAPI_ObjToString(api_data, &tObjRef, (char*)paramP->valueP, &paramP->length, paramP->valueStorage, kExplicitTypeCast);
								else
								{	CEquStr(aCStr, "_ExecPrepared: Bind Variable not defined (");
									CAddStr(aCStr, paramP->name);
									CAddStr(aCStr, ")");
									_odbcSetError(nil, odbcRecP, cursorP, aCStr, cursorP->warning);
								}
							}
						}
					}
				} while (--tot && NOT(err));
			}*/
			if NOT(err = bdbRec.BDBAPI_FlushParamsInputs(api_data, db_api_data, cursorP->parameters, cursorP->totParameters, error, nil))
			{	rc = SQLExecute(cursorP->hstmt);
				if (rc == SQL_SUCCESS_WITH_INFO)
					_odbcSetError(nil, odbcRecP, cursorP, "SQLExecute", cursorP->warning);
				else if (rc == SQL_NO_DATA)
				{	rc = SQL_SUCCESS;
					CEquStr(cursorP->warning, "SQLExecute affected no data");
				}
				if ((rc == SQL_SUCCESS) || (rc == SQL_SUCCESS_WITH_INFO))
				{	
					err = bdbRec.BDBAPI_LoadParamsOutputs(api_data, db_api_data, cursorP->parameters, cursorP->totParameters, _IsParamNull, 0, error, nil);
					/*if (totParameters = cursorP->totParameters)		// retrieve parameters for stored procs
					{	
					Ptr			strToEvalP;
					BlockRef	tempBlock;
					long		strToEvalLen;
					
						index = 0;
						tot = MAX_PARAMETERS;
						do 
						{	if (tBl = cursorP->parameters[index++])
							{	paramP = (ODBCParameterDescr*)GetPtr(tBl);
								if ((paramP->mode == SQL_PARAM_OUTPUT) || (paramP->mode == SQL_PARAM_INPUT_OUTPUT))
								{	strToEvalLen = CLen(paramP->name) + 2 + paramP->length + 1 + 1;
									if (strToEvalLen > 255)
									{	strToEvalP = aCStr;
										tempBlock = 0;
									}
									else
										tempBlock = NewPtrBlock(strToEvalLen, &err, &strToEvalP);
									if NOT(err)
									{	strToEvalP = GetPtr(tempBlock);
										CEquStr(strToEvalP, paramP->name);
										CAddStr(strToEvalP, "=\"");
										if (paramP->length != SQL_NULL_DATA)
										{	paramP->valueP[paramP->length] = 0;
											CAddStr(strToEvalP, (char*)paramP->valueP);
										}
										CAddStr(strToEvalP, "\"");
										BAPI_InvalObjRef(api_data, &tObjRef);
										if (err = BAPI_Eval(api_data, strToEvalP, strToEvalLen, &tObjRef, true))
											break;
										if (tempBlock)
											DisposeBlock(&tempBlock);
									}
								}
							}
						} while (--tot);
					}*/
					if ((SQLNumResultCols(cursorP->hstmt, &totCols) == SQL_SUCCESS) && totCols)
					{	cursorP->cursorExists = true;
						err = _DescribeColumns(cursorP, odbcRecP, error, true);
					}
				}
				else
				{	if (rc == SQL_NEED_DATA)
						CEquStr(aCStr, "SQLExecute need data");
					else
						CEquStr(aCStr, "SQLExecute error");
					_odbcSetError(&err, odbcRecP, cursorP, aCStr, error);
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_RowSetSize(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
RowSetSizeRec	*rowSetSizeRecP = &pbPtr->param.rowSetSizeRec;
ODBCCursorRec	*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, rowSetSizeRecP->cursorID, (Ptr*)&cursorP))
	{	if NOT(err = _SetRowArraySize(cursorP, rowSetSizeRecP->size, odbcRecP, pbPtr->error, true))
			err = _DescribeColumns(cursorP, odbcRecP, pbPtr->error, true);
	}
	
return err;
}

//===========================================================================================
static XErr	_FreeResult(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
FreeResultRec	*freeResultRecP = &pbPtr->param.freeResultRec;
ODBCCursorRec	*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, (Ptr*)&cursorP))
	{	if (cursorP->fromPool)
			err = _FreePreparedCursor(cursorP, odbcRecP, false, pbPtr->error);
		else
		{	if NOT(err = _FreeCursor(cursorP, odbcRecP, pbPtr->error))
			{	if (SQLFreeHandle(SQL_HANDLE_STMT, cursorP->hstmt) != SQL_SUCCESS)
					_odbcSetError(&err, odbcRecP, 0, "SQLFreeHandle-SQL_HANDLE_STMT", pbPtr->error);
			}
		}
		if NOT(err)
			err = bdbRec.BDBAPI_DisposeCursorSlot(pbPtr->api_data, pbPtr->db_api_data, freeResultRecP->cursorID, nil, 0, pbPtr->error);	// free the slot
	}
	
return err;
}

//===========================================================================================
static XErr	_GetAffectedRecs(BDBAPI_ParamBlockPtr pbPtr)
{
	XErr				err = noErr;	//, err2 = noErr;
ODBCRec				*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
GetAffectedRecsRec	*getAffectedRecsRecP = &pbPtr->param.getAffectedRecsRec;
ODBCCursorRec		*cursorP;

	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getAffectedRecsRecP->cursorID, (Ptr*)&cursorP))
		err = _RowCount(cursorP, odbcRecP, pbPtr->error, &getAffectedRecsRecP->affectedRecs);
	/*cursID = getAffectedRecsRecP->cursorID;	
	if (cursID == -1)
		cursID = odbcRecP->lastCursor;
	if (cursorP = _GetCursorP(pbPtr->api_data, odbcRecP, cursID, false))
	{	if (cursorP->busy)
			err = _RowCount(cursorP, odbcRecP, pbPtr->error, &getAffectedRecsRecP->affectedRecs);
		else
			_odbcSetError(&err, odbcRecP, 0, "_GetAffectedRecs: Operation on a free cursor", pbPtr->error);
	}
	else
		_odbcSetError(&err, odbcRecP, 0, "_GetAffectedRecs: Bad Cursor ID", pbPtr->error);*/

return err;
}

//===========================================================================================
static XErr	_GetCurRecs(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr, err2 = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
GetCurRecsRec	*getCurRecsRecP = &pbPtr->param.getCurRecsRec;
ODBCCursorRec	*cursorP;
long			saveRowArraySize;
SQLINTEGER		totRecs;
RETCODE			rc;
char			*error = pbPtr->error;
SQLSMALLINT		mode;

	/*cursID = getCurRecsRecP->cursorID;	
	if (cursID == -1)
		cursID = odbcRecP->lastCursor;
	if (cursorP = _GetCursorP(pbPtr->api_data, odbcRecP, cursID, false))
	{	if (cursorP->busy)
		{*/
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, getCurRecsRecP->cursorID, (Ptr*)&cursorP))
	{	if (cursorP->totRecs < 0)
		{	if NOT(err = _RowCount(cursorP, odbcRecP, pbPtr->error, &cursorP->totRecs))	// just to try
			{	if (cursorP->totRecs < 0)
				{	totRecs = cursorP->realPos - 1;
					mode = SQL_FETCH_NEXT;
					if NOT(err)	
					{	if NOT(err = _SetFetchOff(cursorP, odbcRecP, error))
						{	if NOT(err = _UnbindColumns(cursorP, odbcRecP, error))
							{	saveRowArraySize = cursorP->rowArraySize;
								if NOT(err = _SetRowArraySize(cursorP, MAX_ARRAY_ROW_SIZE, odbcRecP, error, false))
								{	do {
										rc = _FetchScroll(cursorP->hstmt, mode, 1);		// scroll until end
										if (rc == SQL_SUCCESS)
										{	totRecs += cursorP->numRowsFetched;
											if (cursorP->numRowsFetched < (SQLUINTEGER)cursorP->rowArraySize)
												break;
										}
										else
										{	if (rc != SQL_NO_DATA)
												_odbcSetError(&err, odbcRecP, cursorP, "_FetchAfter: SQLFetchScroll", error);
											else
											{	totRecs += cursorP->numRowsFetched;
												break;
											}
										}
									} while (1);
									if NOT(err)
									{	cursorP->totRecs = totRecs;
										cursorP->realPos = totRecs + 1;
										// getCurRecsRecP->curRecs = totRecs; lo fa dopo
									}
									err2 = _SetRowArraySize(cursorP, saveRowArraySize, odbcRecP, error, false);
									if NOT(err)
										err = err2;
								}								
								err2 = _BindColumns(cursorP, odbcRecP, error);
								if NOT(err)
									err = err2;
							}
							err2 = _SetFetchOn(cursorP, odbcRecP, error);
							if NOT(err)
								err = err2;
						}
					}
				}
			}
		}
	}
	/*	else
			_odbcSetError(&err, odbcRecP, 0, "_GetCurRecs: Operation on a free cursor", pbPtr->error);
	}
	else
		_odbcSetError(&err, odbcRecP, 0, "_GetCurRecs: Bad Cursor ID", pbPtr->error);*/
	
	if NOT(err)
		getCurRecsRecP->curRecs = cursorP->totRecs;
		
return err;
}

//===========================================================================================
static XErr	_SeekTell(BDBAPI_ParamBlockPtr pbPtr, long which)
{
XErr			err = noErr;
//ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
ODBCCursorRec	*cursorP;
long			cursID;

	if (which == kSeek)
		cursID = pbPtr->param.seekRec.cursorID;
	else
		cursID = pbPtr->param.tellRec.cursorID;
	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, cursID, (Ptr*)&cursorP))
	{	if (which == kSeek)
			cursorP->curPos = pbPtr->param.seekRec.pos;
		else
			pbPtr->param.tellRec.pos = cursorP->curPos;
	}

	/*if (cursID == -1)
		cursID = odbcRecP->lastCursor;
	if (cursorP = _GetCursorP(pbPtr->api_data, odbcRecP, cursID, false))
	{	if (cursorP->busy)
		{	if (which == kSeek)
				cursorP->curPos = pbPtr->param.seekRec.pos;
			else
				pbPtr->param.tellRec.pos = cursorP->curPos;
		}
		else
			_odbcSetError(&err, odbcRecP, 0, "_SeekTell: Operation on a free cursor", pbPtr->error);
	}
	else
		_odbcSetError(&err, odbcRecP, 0, "_SeekTell: Bad Cursor ID", pbPtr->error);
	*/
	
return err;
}

//===========================================================================================
static XErr	_Warning(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;
ODBCCursorRec	*cursorP;
long			cursID;

	if (cursID = pbPtr->param.warningRec.cursorID)
	{	if NOT(err = bdbRec.BDBAPI_GetCursorSlot(pbPtr->api_data, pbPtr->db_api_data, cursID, (Ptr*)&cursorP))
		{	if (*cursorP->warning)
				CEquStr(pbPtr->param.warningRec.warning, cursorP->warning);
			else
				CEquStr(pbPtr->param.warningRec.warning, odbcRecP->warning);
		}
	}
	else
		CEquStr(pbPtr->param.warningRec.warning, odbcRecP->warning);
	
return err;
}
//===========================================================================================
/*static XErr	_Escape(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
EscapeRec		*escapeRecP = &pbPtr->param.escapeRec;
BlockRef		resultBlock;
long			resultLen;

	if NOT(err = SubstituteExt(escapeRecP->stringP, escapeRecP->stringLen, &resultBlock, &resultLen, "\'", "\'\'", 2, true, false))	
	{	LockBlock(resultBlock);
		err = BAPI_StringToObj(pbPtr->api_data, GetPtr(resultBlock), resultLen, &escapeRecP->resultObj);
		DisposeBlock(&resultBlock);
	}
	
return err;
}*/

//===========================================================================================
static XErr	_BeginTran(BDBAPI_ParamBlockPtr pbPtr)
{
	XErr			err = noErr;	//, err2 = noErr;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;

	if (SQLSetConnectAttr(odbcRecP->hdbc, SQL_ATTR_AUTOCOMMIT, (SQLPOINTER)SQL_AUTOCOMMIT_OFF, SQL_IS_INTEGER) != SQL_SUCCESS)
		_odbcSetError(&err, odbcRecP, 0, "SQLSetConnectAttr: SQL_ATTR_AUTOCOMMIT(OFF)", pbPtr->error);
	
return err;
}

//===========================================================================================
static XErr	_EndTran(BDBAPI_ParamBlockPtr pbPtr, Boolean toCommit)
{
XErr			err = noErr, err2 = noErr;
long			what;
ODBCRec			*odbcRecP = (ODBCRec*)pbPtr->connBufferPtr;

	XThreadsEnterCriticalSection();
	if (toCommit)
		what = SQL_COMMIT;
	else
		what = SQL_ROLLBACK;
	if (SQLEndTran(SQL_HANDLE_DBC, odbcRecP->hdbc, (short)what) != SQL_SUCCESS)
		_odbcSetError(&err, odbcRecP, 0, "SQLEndTran", pbPtr->error);
	if (SQLSetConnectAttr(odbcRecP->hdbc, SQL_ATTR_AUTOCOMMIT, (SQLPOINTER)SQL_AUTOCOMMIT_ON, SQL_IS_INTEGER) != SQL_SUCCESS)
	{	_odbcSetError(&err2, odbcRecP, 0, "SQLSetConnectAttr: SQL_ATTR_AUTOCOMMIT(OFF)", pbPtr->error);
		if NOT(err)
			err = err2;
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
/*static XErr	_Prepare(BDBAPI_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
PrepareRec		*prepareRecP = &pbPtr->param.prepareRec;
long			poolConnectIndex, tot = gsMaxUsers, i;
HDBC			hdbc;
RETCODE			rc;
char			buf[257];
short			buflen;
BlockRef		preparePoolBlock;
PoolConnectRec	*preparePoolP;
HSTMT			hstmt;

	if (preparePoolBlock = NewBlock(sizeof(PoolConnectRec), &err))
	{	preparePoolP = (PoolConnectRec*)GetPtr(preparePoolBlock);
		for (i = 0; (i < tot) && NOT(err); i++)
		{	if (SQLAllocConnect(gHenv, &hdbc) == SQL_SUCCESS)
			{	rc = SQLDriverConnect(hdbc, (HWND)-1L, (UCHAR*)prepareRecP->connStringP, SQL_NTS, (UCHAR*)buf, sizeof(buf), &buflen, SQL_DRIVER_NOPROMPT);
				if (rc != SQL_SUCCESS)
				{	_odbcSetError(&err, nil, 0, "SQLDriverConnect", pbPtr->error);
					SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
				}
			}
			else
				_odbcSetError(&err, nil, 0, "SQLAllocConnect", pbPtr->error);
			if NOT(err)
			{	if (SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt) != SQL_SUCCESS)
					_odbcSetError(&err, odbcRecP, 0, "SQLAllocHandle-SQL_HANDLE_STMT", error);
				else
				{	err = _AddPoolConnect(gsPoolConnectRecBlock, &preparePoolP, hdbc, prepareRecP->connStringP, &poolConnectIndex);
				
				}
			}
		}
	}

return err;
}*/

/*
//===========================================================================================
static XErr	_odbcStoreResult(long api_data, Ptr connBuffP, long len, Boolean store, long *cursIDP, char *error)
{
XErr		err = noErr;
ODBCRec	*odbcRecP = (ODBCRec*)connBuffP;
int			i;
MYSQL_RES	**tRecP;

	tRecP = &odbcRecP->my_sql_res[0];
	for (i = 0; i < MAX_CURSOR; i++, tRecP++)
	{	if NOT(*tRecP)
			break;
	}
	if (i == MAX_CURSOR)
	{	CEquStr(error, "Too much cursor");
		err = XError(kBAPI_Error, Err_ClassFatalError);
	}
	else
	{	if (store)
			*tRecP = mysql_store_result_EntryPoint(odbcRecP->connection);
		else
			*tRecP = mysql_use_result_EntryPoint(odbcRecP->connection);
		if NOT(*tRecP)
		{	err = mysql_errno_EntryPoint(odbcRecP->connection);
			_Err2ODBCError(&err, error, odbcRecP, nil);
		}
		else
		{	odbcRecP->curPos[i] = 1;
			odbcRecP->lastResult = i+1;
			odbcRecP->totRes++;
			*cursIDP = i+1;
		}
	}
	TRACE("mysql_store_result ok");

return err;
}
//===========================================================================================
static XErr	_odbcFreeResult(long api_data, Ptr connBuffP, long len, long cursID, char *error)
{
XErr		err = noErr;
ODBCRec	*odbcRecP = (ODBCRec*)connBuffP;
MYSQL_RES	*tResult;

	if (cursID == -1)
		cursID = odbcRecP->lastResult;
	if (cursID && (cursID <= MAX_CURSOR))
	{	tResult = odbcRecP->my_sql_res[cursID-1];
		if (tResult)
		{	mysql_free_result_EntryPoint(tResult);
			if (err = mysql_errno_EntryPoint(odbcRecP->connection))
				_Err2ODBCError(&err, error, odbcRecP, nil);
			else
			{	odbcRecP->my_sql_res[cursID-1] = 0L;
				odbcRecP->totRes--;
			}
		}
		else
			_Err2ODBCError(&err, error, odbcRecP, "Bad cursor id");
	}
	else
		_Err2ODBCError(&err, error, odbcRecP, "Bad cursor id");
	
return err;
}

//===========================================================================================
static XErr	_odbcSeek(long api_data, Ptr connBuffP, long len, long cursID, long offset, char *error)
{
XErr		err = noErr;
ODBCRec	*odbcRecP = (ODBCRec*)connBuffP;
MYSQL_RES	*tRes;

	if (cursID == -1)
		cursID = odbcRecP->lastResult;
	if (cursID)
	{	if (offset > 0)
		{	if (tRes = odbcRecP->my_sql_res[cursID-1])
			{	mysql_data_seek_EntryPoint(tRes, offset-1);
				if (err = mysql_errno_EntryPoint(odbcRecP->connection))
					_Err2ODBCError(&err, error, odbcRecP, nil);
			}
			else
				_Err2ODBCError(&err, error, odbcRecP, "Selection is empty");
		}
		else
			_Err2ODBCError(&err, error, odbcRecP, "Bad offset for cursor");
	}
	else
		_Err2ODBCError(&err, error, odbcRecP, "Bad cursor id");
	
return err;
}

//===========================================================================================
static XErr	_odbcTell(long api_data, Ptr connBuffP, long len, long cursID, long *offsetP, char *error)
{
XErr		err = noErr;
ODBCRec	*odbcRecP = (ODBCRec*)connBuffP;

	if (cursID == -1)
		cursID = odbcRecP->lastResult;
	if (cursID)
		*offsetP = odbcRecP->curPos[cursID-1];
	else
		_Err2ODBCError(&err, error, odbcRecP, "Bad cursor id");
	
return err;
}

//===========================================================================================
static XErr	_odbcFetchRec(long api_data, Ptr connBuffP, long len, long cursID, ObjRef *resultObjRefP, char *error)
{	
XErr			err = noErr;
MYSQL_ROW		row;
MYSQL_FIELD		*field;
MYSQL_RES		*my_sql_res;
BlockRef		bl;
ParameterRec	*varRecsP;
ObjRef			tObjRef;
long			i, totFields;
ODBCRec		*odbcRecP = (ODBCRec*)connBuffP;
MYSQL_RES		*tResult;

	if (cursID == -1)
		cursID = odbcRecP->lastResult;
	if (cursID)
	{	tResult = odbcRecP->my_sql_res[cursID-1];
		if (tResult)
			totFields = mysql_num_fields_EntryPoint(tResult);
		else
			_Err2ODBCError(&err, error, odbcRecP, "Bad cursor id");
		if NOT(err)
		{	if (totFields < 0)
			{	CEquStr(error, "Error getting num of fields");
				err = XError(kBAPI_ClassError, ErrDBMSError);
			}
			else if (bl = NewBlock(sizeof(ParameterRec) * totFields, &err))
			{	LockBlock(bl);
				varRecsP = (ParameterRec*)GetPtr(bl);
				if (row = mysql_fetch_row_EntryPoint(tResult))
				{	for (i = 0; (i < totFields) && NOT(err); i++)
					{	*varRecsP[i].name = 0;
						if (row[i])
							err = BAPI_StringToObj(api_data, row[i], CLen(row[i]), &varRecsP[i].objRef);
						else
							err = BAPI_StringToObj(api_data, "", 0, &varRecsP[i].objRef);
					}
					if NOT(err)
					{	err = BAPI_NewArray(api_data, false, i, nil, TEMP, varRecsP->objRef.type, varRecsP, i, nil, resultObjRefP);
						if NOT(err)
						{	ArrayIndexRec	mCoord;
							
							mysql_field_seek_EntryPoint(tResult, 0);	// sei sicuro di questa?
							ClearBlock(&mCoord, sizeof(ArrayIndexRec));
							for (i = 0; (i < totFields) && NOT(err); i++)
							{	if (field = mysql_fetch_field_EntryPoint(tResult))
								{	mCoord.ind = i+1;
									tObjRef = *resultObjRefP;
									if NOT(err = BAPI_ResolveArrayElem(api_data, &tObjRef, &mCoord, 1, nil))
										err = BAPI_SetObjName(api_data, &tObjRef, field->name);
								}
							}
						}
					}
				}
				else
					_Err2ODBCError(&err, error, odbcRecP, "No More Records In Selection");
				DisposeBlock(&bl);
			}
		}
		if NOT(err)
			odbcRecP->curPos[cursID-1] = 1;
	}
	else
		_Err2ODBCError(&err, error, odbcRecP, "Bad cursor id");

if (err)
	_Err2ODBCError(&err, error, odbcRecP, "Bad cursor id");

return err;
}

//===========================================================================================
static XErr	_odbcGetAffectedRecs(long api_data, Ptr connBuffP, long len, long *affectedRecsP, char *error)
{
XErr		err = noErr;
ODBCRec	*odbcRecP = (ODBCRec*)connBuffP;

	*affectedRecsP = mysql_affected_rows_EntryPoint(odbcRecP->connection);
	if (err = mysql_errno_EntryPoint(odbcRecP->connection))
		_Err2ODBCError(&err, error, odbcRecP, nil);

return err;
}

//===========================================================================================
/*static XErr	_odbcGetInfo(long api_data, Ptr connBuffP, long connBuffLen, ObjRef *objRefP, char *error)
{
	return _Info(api_data, connBuffP, kInfo, objRefP);
}

//===========================================================================================
static XErr	_odbcGetServerInfo(long api_data, Ptr connBuffP, long connBuffLen, ObjRef *objRefP, char *error)
{
	return _Info(api_data, connBuffP, kServerInfo, objRefP);
}

//===========================================================================================
static XErr	_odbcGetHostInfo(long api_data, Ptr connBuffP, long connBuffLen, ObjRef *objRefP, char *error)
{
	return _Info(api_data, connBuffP, kHostInfo, objRefP);
}

//===========================================================================================
static XErr	_odbcGetProtoInfo(long api_data, Ptr connBuffP, long connBuffLen, ObjRef *objRefP, char *error)
{
	return _Info(api_data, connBuffP, kProtoInfo, objRefP);
}

//===========================================================================================
static XErr	_odbcGetStat(long api_data, Ptr connBuffP, long connBuffLen, ObjRef *objRefP, char *error)
{
	return _Info(api_data, connBuffP, kStat, objRefP);
}

//===========================================================================================
static XErr	_odbcGetClientInfo(long api_data, ObjRef *objRefP, char *error)
{
	return _Info(api_data, nil, kClientInfo, objRefP);
}

//===========================================================================================
static XErr	_odbcEscape(long api_data, char *sourceP, long sourceLen, ObjRef *objRefP, char *error)
{
BlockRef	escapedStrBlock;
char		*escapeStringP;
XErr		err = noErr;
	
	if (escapedStrBlock = NewBlock((sourceLen * 2) + 1, &err))
	{	escapeStringP = GetPtr(escapedStrBlock);
		mysql_escape_string_EntryPoint(escapeStringP, sourceP, sourceLen);
		err = BAPI_StringToObj(api_data, escapeStringP, CLen(escapeStringP), objRefP);
		DisposeBlock(&escapedStrBlock);
	}

return err;
}

#pragma mark-*/
#if __MWERKS__
#pragma mark-
#pragma export on
#endif
//===========================================================================================
XErr ODBC_BDBAPI_Dispatch(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kConnect:
			err = _Connect(pbPtr);
			break;
		case kDisconnect:
			err = _Disconnect(pbPtr);
			break;
		case kExec:
			err = _Exec(pbPtr);
			break;
		case kCall:
			err = _Call(pbPtr, false);
			break;
		case kCallExt:
			err = _Call(pbPtr, true);
			break;
		case kPrepare:
			err = _Prepare(pbPtr);
			break;
		case kFreePrepare:
			err = _FreePrepare(pbPtr);
			break;
		case kRowSetSize:
			err = _RowSetSize(pbPtr);
			break;
		case kGetPrepared:
			err = _GetPrepared(pbPtr);
			break;
		case kBind:
			err = _Bind(pbPtr);
			break;
		case kBindAll:
			err = _BindAll(pbPtr);
			break;
		case kExecPrepared:
			err = _ExecPrepared(pbPtr);
			break;
		case kFreeResult:
			err = _FreeResult(pbPtr);
			break;
		case kSeek:
			err = _SeekTell(pbPtr, message);
			break;
		case kTell:
			err = _SeekTell(pbPtr, message);
			break;
		case kWarning:
			err = _Warning(pbPtr);
			break;
		case kGetCurRecs:
			err = _GetCurRecs(pbPtr);
			break;
		case kGetAffectedRecs:
			err = _GetAffectedRecs(pbPtr);
			break;
		case kFetchRec:
			err = _FetchRec(pbPtr);
			break;
		/*case kGetInfo:
			break;
		case kGetServerInfo:
			break;
		case kGetHostInfo:
			break;
		case kGetProtoInfo:
			break;
		case kGetStat:
			break;*/
		case kRealEscape:
		case kRealUnescape:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		case kTransaction:
			err = _BeginTran(pbPtr);
			break;
		case kCommit:
			err = _EndTran(pbPtr, true);
			break;
		case kRollBack:
			err = _EndTran(pbPtr, false);
			break;
		default:
			err = XError(kBAPI_Error, Err_NotImplemented);
			break;
		/*case kGetClientInfo:
			break;*/
	}

return err;
}
#if __MWERKS__
#pragma export off
#pragma mark-
#endif
//===========================================================================================
static XErr	ODBC_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(pbPtr)
#endif
	
	if (gHenv)
	{	SQLFreeHandle(SQL_HANDLE_ENV, gHenv);
		gHenv = 0;
	}
	if (gsPoolConnectRecBlock)
		ClosePoolConnect(gsPoolConnectRecBlock, gsPoolConnectRecP, ConnectionClosePoolCallBack);
	if (gsODBCRecPoolRef)
		DeletePool(gsODBCRecPoolRef);
	
return noErr;
}

//===========================================================================================
static XErr	InitCallBacks(long api_data, BDBAPI_Rec *theRecP)
{
XErr					err = noErr;
BDBAPI_Init_CallBack	BDBAPI_Init_EP;

	if NOT(err = BAPI_GetSymbol(api_data, BAPI_ClassIDFromName(api_data, "db", false), "BDBAPI_Init", (long*)&BDBAPI_Init_EP))
		err = BDBAPI_Init_EP(&bdbRec);

return err;
}

//===========================================================================================
static XErr	ODBC_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;

	/*if NOT(SQLAllocHandle)
	{	_odbcSetError(&err, nil, nil, "Can't Initialize ODBC library", pbPtr->error);
		return err;
	}*/
	if (gsPoolConnectRecBlock = NewBlockLocked(sizeof(PoolConnectRec), &err, (Ptr*)&gsPoolConnectRecP))
	{	ClearBlock(gsPoolConnectRecP, sizeof(PoolConnectRec));
		if (SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &gHenv) == SQL_SUCCESS)
		{	if (SQLSetEnvAttr(gHenv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER) == SQL_SUCCESS)
			{	if NOT(err = InitCallBacks(api_data, &bdbRec))
				{	if NOT(err = bdbRec.BDBAPI_Register("odbc", ODBC_BDBAPI_Dispatch, sizeof(ODBCCursorRec), false))
						err = NewPool(sizeof(ODBCRec), gsMaxUsers, &gsODBCRecPoolRef);
				}
			}
			else
				_odbcSetError(&err, nil, 0, "SQLSetEnvAttr:SQL_ATTR_ODBC_VERSION", pbPtr->error);
			if (err)
				SQLFreeHandle(SQL_HANDLE_ENV, gHenv);
		}
		else
			_odbcSetError(&err, nil, 0, "SQLAllocHandle:SQL_HANDLE_ENV", pbPtr->error);
		if (err)
		{	DisposeBlock(&gsPoolConnectRecBlock);
			gsPoolConnectRecBlock = 0;
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#pragma export on
#endif
//===========================================================================================
#ifdef	ODBC_BUILT_IN
	XErr odbc_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#else
	XErr BAPI_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
#endif
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, myODBCClassName);
			CEquStr(pbPtr->param.registerRec.pluginDescr, "Tabasoft odbc support");
			// BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
			//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
			VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
			if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
				CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
			gsApiVersion = pbPtr->param.registerRec.api_version;
			gsMaxUsers = pbPtr->param.registerRec.maxUsers;
			odbcClassID = pbPtr->param.registerRec.pluginID;
			break;
		case kInit:
			err = ODBC_Init(pbPtr);
			break;
		case kShutDown:
			err = ODBC_ShutDown(pbPtr);
			break;
		case kRun:
			/*pbPtr->plugin_run_data = BufferCreate(12 * sizeof(long), &err);
			if NOT(err)
				err = BufferAddLong(pbPtr->plugin_run_data, 0L);*/
			break;
		case kExit:
			/*{
			long		tot, i, size, *tempP;
			BlockRef	block;
			
				block = BufferGetBlockRefExt(pbPtr->plugin_run_data, &size, (Ptr*)&tempP);
				LockBlock(block);
				size /= sizeof(long);
				tot = *tempP++;
				size--;
				for (i = 0; (i < size) && tot; i++, tempP++)
				{	if (*tempP)
					{	err = _FreePreparedCursorStuff((ODBCCursorRec*)*tempP, nil, false, pbPtr->error);
						tot--;
					}
				}
				BufferFree(pbPtr->plugin_run_data);
			}*/
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteFunction:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
#pragma export off
#endif
//#endif
