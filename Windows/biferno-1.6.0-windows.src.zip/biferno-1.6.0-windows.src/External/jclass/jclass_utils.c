/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: jclass_utils.c,v 1.5 2004-03-23 15:42:11 valfer Exp $
	|______________________________________________________________________________
*/

#include 	"BifernoAPI.h"
#include 	"jclass_utils.h"
#include 	"jclass_bfr.h"
#if __MACOSX__
	#include <JavaVM/jni.h>
#else
	#include 	"jni.h"
#endif

//===========================================================================================
XErr	CString2jstring(JNIEnv *env, char *stringP, jstring *theStringP, char *strError)
{
//jclass		theClass;
//jmethodID	methodID;
XErr		err = noErr;
BlockRef	resultBlockRef;
long		resultLen;
Ptr			textP;

	if NOT(err = Encode_UTF(stringP, CLen(stringP), &resultBlockRef, &resultLen))
	{	textP = GetPtr(resultBlockRef);		
		if NOT(*theStringP = (*env)->NewStringUTF(env, textP))
		{	if (strError)
				CEquStr(strError, "NewStringUTF");
			err = XError(kBAPI_ClassError, Err_JClassError);
		}
		DisposeBlock(&resultBlockRef);
	}
	
	/*else 
	{	
	if (theClass = (*env)->FindClass(env, "java/lang/String"))
	{	if (methodID = (*env)->GetMethodID(env, theClass, "String", "([C)V"))
		{	(*env)->CallVoidMethod(env, theString, methodID, stringP);
			if ((*env)->ExceptionOccurred(env) != NULL)
			{	(*env)->ExceptionDescribe(env);
				(*env)->ExceptionClear(env);
				err = XError(kBAPI_Error, Err_JavaException);
			}
		}
		else
		{	if (strError)
				CEquStr(strError, "String");
			err = XError(kBAPI_Error, Err_JavaMethodNotFound);
		}
	}
	else
	{	if (strError)
			CEquStr(strError, "String");
		err = XError(kBAPI_Error, Err_CantDestroyJavaVM);
	}*/

return err;
}
//===========================================================================================
XErr	jstring2CStringExt(JNIEnv *env, jstring jObject, BlockRef *resultBlockRefP, long *resultLenP, char *strError)
{
const char		*p;
jboolean		isCopy;
XErr			err = noErr;

	if (p = (*env)->GetStringUTFChars(env, jObject, &isCopy))
	{	err = Decode_UTF(p, CLen(p), resultBlockRefP, resultLenP);
		(*env)->ReleaseStringUTFChars(env, jObject, p);
		if (err)
			DisposeBlock(resultBlockRefP);
	}
	else
	{	if (strError)
			CEquStr(strError, "GetStringUTFChars");
		err = XError(kBAPI_ClassError, Err_JClassError);
	}

return err;
}

//===========================================================================================
XErr	jstring2CString(JNIEnv *env, jstring jObject, char *str, long maxLength, char *strError)
{
const char		*p;
jboolean		isCopy;
XErr			err = noErr;
BlockRef		resultBlockRef;
long			resultLen;
Ptr				textP;

	if (p = (*env)->GetStringUTFChars(env, jObject, &isCopy))
	{	if NOT(err = Decode_UTF(p, CLen(p), &resultBlockRef, &resultLen))
		{	if (resultLen < maxLength)
			{	textP = GetPtr(resultBlockRef);
				CEquStr(str, textP);
			}
			else
				err = XError(kBAPI_ClassError, Err_JavaStringTooLong);
			(*env)->ReleaseStringUTFChars(env, jObject, p);
			DisposeBlock(&resultBlockRef);
		}
	}
	else
	{	if (strError)
			CEquStr(strError, "GetStringUTFChars");
		err = XError(kBAPI_ClassError, Err_JClassError);
	}

return err;
}

//===========================================================================================
XErr	GetStringField(JNIEnv *envP, jclass theClass, char *fieldName, char *fieldStr, long maxStorage, char *strError)
{
jfieldID		fieldID;
jobject			jObject;
XErr			err = noErr;

	if (fieldID = (*envP)->GetStaticFieldID(envP, theClass, fieldName, "Ljava/lang/String;"))
	{	if (jObject = (*envP)->GetStaticObjectField(envP, theClass, fieldID))
			err = jstring2CString(envP, jObject, fieldStr, maxStorage, strError);
	}
	else
	{	if (strError)
			CEquStr(strError, fieldName);
		err = XError(kBAPI_ClassError, Err_JavaFieldNotFound);
	}
	
return err;
}

//===========================================================================================
XErr	GetObjectField(JNIEnv *envP, jclass theClass, char *fieldName, char *fieldSignature, jobject *resultObjectP, char *strError)
{
jfieldID		fieldID;
jobject			jObject;
XErr			err = noErr;

	if (fieldID = (*envP)->GetStaticFieldID(envP, theClass, fieldName, fieldSignature))
	{	if (jObject = (*envP)->GetStaticObjectField(envP, theClass, fieldID))
			*resultObjectP = jObject;
		else
		{	if (strError)
				CEquStr(strError, fieldName);
			err = XError(kBAPI_ClassError, Err_JavaFieldNotFound);
		}
	}
	else
	{	if (strError)
			CEquStr(strError, fieldName);
		err = XError(kBAPI_ClassError, Err_JavaFieldNotFound);
	}
	
return err;
}

//===========================================================================================
XErr	GetIntField(JNIEnv	*envP, jclass theClass, char *fieldName, long *fieldValue, char *strError)
{
jfieldID	fieldID;
XErr		err = noErr;

	if (fieldID = (*envP)->GetStaticFieldID(envP, theClass, fieldName, "I"))
		*fieldValue = (*envP)->GetStaticIntField(envP, theClass, fieldID);
	else
	{	if (strError)
			CEquStr(strError, fieldName);
		err = XError(kBAPI_ClassError, Err_JavaFieldNotFound);
	}

return err;
}

//#endif	// end if JAVA_ENABLED
