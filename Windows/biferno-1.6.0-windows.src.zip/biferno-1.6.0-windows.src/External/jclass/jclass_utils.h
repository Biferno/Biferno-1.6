#ifndef __JCLASS_UTILS__
	#define __JCLASS_UTILS__

	#if __MACOSX__
		#include <JavaVM/jni.h>
	#else
		#include 	"jni.h"
	#endif

	XErr	CString2jstring(JNIEnv *env, char *stringP, jstring *theStringP, char *strError);
	XErr	jstring2CStringExt(JNIEnv *env, jstring jObject, BlockRef *resultBlockRefP, long *resultLenP, char *strError);
	XErr	jstring2CString(JNIEnv *env, jstring jObject, char *str, long maxLength, char *strError);
	XErr	GetStringField(JNIEnv *envP, jclass theClass, char *fieldName, char *fieldStr, long maxStorage, char *strError);
	XErr	GetObjectField(JNIEnv *envP, jclass theClass, char *fieldName, char *fieldSignature, jobject *resultObjectP, char *strError);
	XErr	GetIntField(JNIEnv	*envP, jclass theClass, char *fieldName, long *fieldValue, char *strError);

#endif
