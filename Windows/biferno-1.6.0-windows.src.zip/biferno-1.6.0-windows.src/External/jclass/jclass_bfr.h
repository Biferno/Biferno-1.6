#ifndef __JCLASS__
	#define __JCLASS__

	// Errors
	#define	START_ERR	300
	enum {
			Err_JClassError = START_ERR,
			Err_JavaClassNotFound,
			Err_JavaException,
			Err_JavaStringTooLong,
			Err_JavaFieldNotFound
	};
	#define	TOT_ERRORS	5

	XErr	End_JVM(void);
	XErr	Init_JVM(void);

	#include 	"BifernoAPI.h"

	XErr	byte_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
	XErr	float_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);
	XErr	short_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr);

#endif
