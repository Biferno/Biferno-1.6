/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: jXLibHelper.c,v 1.10 2005-11-07 17:19:35 valfer Exp $
	|______________________________________________________________________________
*/

/*************************************************
Per Installare Java:

Scaricarsi il jre e il sdk

definire:

$JAVA_HOME			=>		JAVA_HOME=/home/valerio/Java/jdk1.3
$PATH				=>		PATH=$JAVA_HOME/bin:$PATH
$CLASS_PATH			=>		CLASS_PATH=.

poi

$LD_LIBRARY_PATH	=>		LD_LIBRARY_PATH=$JAVA_HOME/jre/lib/ppc:$JAVA_HOME/jre/lib/ppc/native_threads:$JAVA_HOME/jre/lib/ppc/classic
*************************************************/

// Includes & defines
#include 	"XLib.h"
#if __MACOSX__
	#include <JavaVM/jni.h>
	#define	JNI_CreateJavaVM_sym				"JNI_CreateJavaVM_Impl"
	#define	JNI_GetDefaultJavaVMInitArgs_sym	"JNI_GetDefaultJavaVMInitArgs_Impl"
#else
	#include 	"jni.h"
	#define	JNI_CreateJavaVM_sym				"JNI_CreateJavaVM"
	#define	JNI_GetDefaultJavaVMInitArgs_sym	"JNI_GetDefaultJavaVMInitArgs"
#endif
#define		CLASS_INPUT		"-Djava.class.path="

//extern	BufferID	gStdErrBuffer;

//static	FILE			*gsStartUpLog;
// Static
/*
static JavaVM			*g_jvm;
static JavaVMInitArgs 	g_vm_args;
static JNIEnv 			*g_mainThreadEnvP;
static BlockRef			g_localClassPathBlock = 0;
static JavaVMOption		g_options[TOT_OPTIONS]; 
static long				g_Libjvm;
static CreateJavaVM_t	CreateJavaVM_EP = nil;
static CStr255			g_LogFilePath;
static FILE				*g_LogFp = nil;
static Boolean			g_triedOnce = false;
*/
#if __UNIX_XLIB__
	#include <errno.h>
#endif

typedef jint (JNICALL *CreateJavaVM_t)(JavaVM **pvm, void **env, void *args);

#define		TOT_OPTIONS		2
typedef struct {
				JavaVM				*jvm;
				JavaVMInitArgs 		vm_args;
				JNIEnv 				*mainThreadEnvP;
				JavaVMOption		options[TOT_OPTIONS]; 
				CreateJavaVM_t		createJavaVM_EP;
				BlockRef			localClassPathBlock;
				long				libjvm;
				BlockRef			block;
				//CStr255				logFilePath;
				//FILE				*logFp = nil;
				//Boolean				triedOnce;
				//Boolean				pad1;
				//short				pad2;
				} JVMRecord;

//===========================================================================================
/*static jint	(JNICALL vfPrintFunc)(FILE* theFile, const char *fmt, va_list ap)
{
#if __MWERKS__
	#pragma unused(theFile)
#endif
char		*p, *sval;
int			ival;
double		dval;
CStr255		aCStr;
XErr		err = noErr;

	for (p=(char*)fmt; *p; p++)
	{  if (*p != '%')
	   {  fwrite(p, 1, 1, gsStartUpLog);
	   	  fprintf(stderr, "%c", *p);
		  continue;
	   }
	   switch (*++p)
	   {
	   case 'd':
		  ival = va_arg(ap, int);
		  sprintf(aCStr, "%d", ival);
		  fwrite(aCStr, 1, CLen(aCStr), gsStartUpLog);
		  fprintf(stderr, aCStr);
		  break;
	   case 'f':
		  dval = va_arg(ap, double);
		  sprintf(aCStr, "%f", dval);
		  fwrite(aCStr, 1, CLen(aCStr), gsStartUpLog);
		  fprintf(stderr, aCStr);
		  break;
	   case 's':
		  *aCStr = 0;
		  sval = va_arg(ap, char *);
		  fwrite(sval, 1, CLen(sval), gsStartUpLog);
		  fprintf(stderr, sval);
		  break;
	   default:
		  fwrite(p, 1, 1, gsStartUpLog);
		  fprintf(stderr, "%c", *p);
		  break;
	   }
	}
	fflush(gsStartUpLog);

return err;
}*/

XErr	XLibAttachJVM(Ptr jvmHelperP, void **envPPtr);
XErr	XLibDetachJVM(Ptr jvmHelperP);
XErr	XLibGetMainJVM(Ptr jvmHelperP, void **jvmEnvP);
XErr	XLibInit_JVM(LogCallBack logCallBack, void *userData, Ptr *jvmHelperPPtr);
XErr	XLibEnd_JVM(Ptr jvmHelperP);

#if __MWERKS__
	#pragma export on
#endif
//===========================================================================================
XErr	XLibAttachJVM(Ptr jvmHelperP, void **envPPtr)
{
XErr				err = noErr;
JNIEnv 				*envP = nil;
jint				res;
JavaVMAttachArgs 	attach_args;
JVMRecord			*jvmRecP = (JVMRecord*)jvmHelperP;

	XThreadsEnterCriticalSection();
	if (jvmRecP)
	{
		attach_args.version = JNI_VERSION_1_2;
		attach_args.name = NULL;
		attach_args.group = NULL;
	#if __UNIX_XLIB__
		res = (*jvmRecP->jvm)->AttachCurrentThread(jvmRecP->jvm, (void**)&envP, (void*)&attach_args);
	#elif __WIN_XLIB__
		res = (*jvmRecP->jvm)->AttachCurrentThread(jvmRecP->jvm, (void**)&envP, (void*)&attach_args);
	#else
		#if __MACOSX__
			res = (*jvmRecP->jvm)->AttachCurrentThread(jvmRecP->jvm, (void**)&envP, (void*)&attach_args);
		#else
			res = (*jvmRecP->jvm)->AttachCurrentThread(jvmRecP->jvm, &envP, (void*)&attach_args);
		#endif
	#endif	
		if (res != JNI_OK)
			err = XError(kXHelperError, ErrJavaHelperAttachCurrentThreadException);
		else
			*envPPtr = (void*)envP;
		// code to solve the forName failure
		/*if NOT(err)
		{	
		jclass		classThread;
		jmethodID	currentThreadID, setContextClassLoaderID;
		jobject		curThread;
		
			if (classThread = (*envP)->FindClass(envP, "java/lang/Thread"))
			{	if (currentThreadID = (*envP)->GetStaticMethodID(envP, classThread, "currentThread", "()Ljava/lang/Thread;"))
				{	if (curThread = (*envP)->CallStaticObjectMethod(envP, classThread, currentThreadID))
					{	if (setContextClassLoaderID = (*envP)->GetMethodID(envP, classThread, "setContextClassLoader", "(Ljava/lang/ClassLoader;)V"))
						{	
						jfieldID jFieldAccessControlContext;

							if (jFieldAccessControlContext = (*envP)->GetFieldID(envP, classThread, "inheritedAccessControlContext", "Ljava/security/AccessControlContext;"))
							{	(*envP)->SetObjectField(envP, curThread, jFieldAccessControlContext, gs_jMainThreadAccessControlContext);
								(*envP)->CallObjectMethod(envP, curThread, setContextClassLoaderID, gs_jMainThreadClassLoader);
							}
						}
					}
				}
			}
			if ((*envP)->ExceptionOccurred(envP) != NULL)
			{	(*envP)->ExceptionDescribe(envP);
				(*envP)->ExceptionClear(envP);
			}
		}*/
		// -- end code to solve the forName failure
	}
	else
		*envPPtr = nil;
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	XLibDetachJVM(Ptr jvmHelperP)
{
jint			res;
JVMRecord		*jvmRecP = (JVMRecord*)jvmHelperP;

	XThreadsEnterCriticalSection();
	if (jvmRecP)
		res = (*jvmRecP->jvm)->DetachCurrentThread(jvmRecP->jvm);
	XThreadsLeaveCriticalSection();
	
return noErr;
}

//===========================================================================================
XErr	XLibGetMainJVM(Ptr jvmHelperP, void **jvmEnvP)
{
JVMRecord		*jvmRecP = (JVMRecord*)jvmHelperP;

	*jvmEnvP = (void*)jvmRecP->mainThreadEnvP;

return noErr;
}

//===========================================================================================
/*static void _PrintJNIInfo(void)
{
	// Print them all out
	printf( "JNI Information\n" );
	printf( "===============\n" );
	printf( "\tJDK version: %#010x\n", g_vm_args.version );
	printf( "\n" );
	printf( "Properties and Classpath\n" );
	printf( "========================\n" );
	printf( "\tProperties: 0x%08x\n", g_vm_args.properties );
	printf( "\tClasspath: %s\n",
	( g_vm_args.classpath == NULL ) ? "not set" : g_vm_args.classpath );
	printf( "\n" );
	printf( "Class Loader Information\n" );
	printf( "========================\n" );
	printf( "\tCheck Source? %s\n",
	( g_vm_args.checkSource == JNI_TRUE ) ? "yes" : "no" );
	printf( "\tVerify Classes? %s\n",
	( g_vm_args.verifyMode == JNI_TRUE ) ? "yes" : "no" );
	printf( "\n" );
	printf( "Garbage Collector Information\n" );
	printf( "=============================\n" );
	printf( "\tEnable Class GC? %s\n",
	( g_vm_args.enableClassGC == JNI_TRUE ) ? "yes" : "no" );
	160
	Chapter 13. Embedding a JVM
	printf( "\tEnable Verbose GC? %s\n",
	( g_vm_args.enableVerboseGC == JNI_TRUE ) ? "yes" : "no" );
	printf( "\tDisable Async GC? %s\n",
	( g_vm_args.disableAsyncGC == JNI_TRUE ) ? "yes" : "no" );
	printf( "\n" );
	printf( "Debugging Information\n" );
	printf( "=====================\n" );
	printf( "\tRemote Debugging Enabled? %s\n",
	( g_vm_args.debugging == JNI_TRUE ) ? "yes" : "no" );
	printf( "\tRemote Debugging Port: %d\n", g_vm_args.debugPort );
	printf( "\n" );
	printf( "Memory Allocation Information\n" );
	printf( "=============================\n" );
	printf( "\tNative Thread Stack Size ( bytes ): %d\n",
	g_vm_args.nativeStackSize );
	printf( "\tJava Thread Stack Size ( bytes ): %d\n",
	g_vm_args.javaStackSize );
	printf( "\tMinimum JVM Heap Size ( bytes ): %d\n",
	g_vm_args.minHeapSize );
	printf( "\tMaximum JVM Heap Size ( bytes ): %d\n",
	g_vm_args.maxHeapSize );
	printf( "\n" );
	printf( "Function Hooks\n" );
	printf( "==============\n" );
	printf( "\tvfprintf() @ %x\n", g_vm_args.vfprintf );
	printf( "\texit() @ %x\n", g_vm_args.exit );
	printf( "\tabort() @ %x\n", g_vm_args.abort );
}*/

//===========================================================================================
XErr	XLibInit_JVM(LogCallBack logCallBack, void *userData, Ptr *jvmHelperPPtr)
{
XErr			err = noErr;
jint			res;
char			*classPathEnv = nil;
long			i, classPathEnvLen = 0;
CStr255			aCStr;
Ptr				classPathP;
CStr31			tStr;
JVMRecord		*jvmRecP = nil;
BlockRef		jvmRecBlock;

	//gsStartUpLog = fopen("biferno_jvm.log", "w");
	if (*jvmHelperPPtr)
		return noErr;

	if NOT(jvmRecBlock = NewBlockLocked(sizeof(JVMRecord), &err, (Ptr*)&jvmRecP))
		return err;
	ClearBlock(jvmRecP, sizeof(JVMRecord));
	//gStdErrBuffer = 0;
	// ClearBlock(&jvmRecP->vm_args, sizeof(JavaVMInitArgs));
	jvmRecP->block = jvmRecBlock;
	jvmRecP->vm_args.version = JNI_VERSION_1_2;		// version of structure arguments
//#if __UNIX_XLIB__
	{
	CStr255			errString;
	char			*jvmPathP;
	CStr255			libJVMPath;
	
	if (jvmPathP = (char*)getenv("BIFERNO_JVMLIBPATH"))
		CEquStr(libJVMPath, jvmPathP);
	else
	{
	#if __MACOSX__
		CEquStr(libJVMPath, "libjvm.dylib");
	#elif __WIN_XLIB__
		CEquStr(libJVMPath, "jvm.dll");
	#else
		CEquStr(libJVMPath, "libjvm.so");
	#endif
	}
	if NOT(err = XLoadDLL(libJVMPath, &jvmRecP->libjvm, errString, nil, false))
	{	if (err = XGetDLLSymbol(jvmRecP->libjvm, JNI_CreateJavaVM_sym, (long*)&jvmRecP->createJavaVM_EP, false))
		{	if (logCallBack)
			{	sprintf(aCStr, "Can't find symbol: %s", JNI_CreateJavaVM_sym);
				logCallBack(userData, aCStr);
			}
		}
		/*if NOT()
 		{	if NOT(err = XGetDLLSymbol(g_Libjvm, JNI_GetDefaultJavaVMInitArgs_sym, (long*)&JNI_GetDefaultJavaVMInitArgs_EP, false))
 				;//res = JNI_GetDefaultJavaVMInitArgs_EP(&g_vm_args);
 		}*/
 	}
 	else if (logCallBack)
		logCallBack(userData, errString);
 	}
//#else
	//res = JNI_GetDefaultJavaVMInitArgs(&g_vm_args);
//#endif
	
	//if (res == JNI_OK)
	if NOT(err)
	{	//_PrintJNIInfo();
		jvmRecP->mainThreadEnvP = nil;
		jvmRecP->vm_args.nOptions = TOT_OPTIONS; 
		ClearBlock(jvmRecP->options, sizeof(JavaVMOption) * TOT_OPTIONS);
		//jvmRecP->options[0].optionString = "-verbose:class";
		//jvmRecP->options[1].optionString = "-verbose:jni";
		//jvmRecP->options[2].optionString = "-verbose:gc";
	//#ifdef __UNIX_XLIB__
		if (classPathEnv = (char*)getenv("CLASSPATH"))
			classPathEnvLen = CLen(classPathEnv);
		else
			classPathEnvLen = 1;	// "."
	//#else
	//	classPathEnvLen = 1;	// "."		
	//#endif
		if (jvmRecP->localClassPathBlock = NewPtrBlock(CLen(CLASS_INPUT) + classPathEnvLen + 1, &err, &classPathP))
		{	CEquStr(classPathP, CLASS_INPUT);
			if (classPathEnv)
				CAddStr(classPathP, classPathEnv);
			else
				CAddStr(classPathP, ".");
			jvmRecP->options[0].optionString = classPathP;
			jvmRecP->options[1].optionString = "-Djava.awt.headless=true";
			//jvmRecP->options[2].optionString = "vfprintf";
			//jvmRecP->options[2].extraInfo = vfPrintFunc;
			
			jvmRecP->vm_args.options = jvmRecP->options; 
			jvmRecP->vm_args.ignoreUnrecognized = JNI_FALSE; 
			if (logCallBack)
			{	logCallBack(userData, "JVM Options:");
				for (i = 0; i < TOT_OPTIONS; i++)
				{	sprintf(aCStr, "%s", jvmRecP->options[i].optionString);
					if (jvmRecP->options[i].extraInfo)
					{	CAddStr(aCStr, " (");
						CNumToString((long)jvmRecP->options[i].extraInfo, tStr);
						CAddStr(aCStr, tStr);
						CAddStr(aCStr, ")");
					}
					logCallBack(userData, aCStr);
				}
				logCallBack(userData, "");
			}
			//#if __UNIX_XLIB__
			res = jvmRecP->createJavaVM_EP(&jvmRecP->jvm, (void**)&jvmRecP->mainThreadEnvP, &jvmRecP->vm_args);
			/*#elif __WIN_XLIB__
				res = JNI_CreateJavaVM(&g_jvm, (void**)&g_mainThreadEnvP, &g_vm_args);
			#else
				res = JNI_CreateJavaVM(&g_jvm, &g_mainThreadEnvP, &g_vm_args);
			#endif*/
			if (res != JNI_OK)
			{	if (logCallBack)
				{	sprintf(aCStr, "CreateJavaVM returned: %d", res);
					logCallBack(userData, aCStr);
				}
				err = XError(kXHelperError, ErrJavaHelperJVMLoadFailed);
			}
		}
	}

	//else
	//	err = XError(kXHelperError, JavaError);
	// code to solve the forName failure
	/*if NOT(err)
	{
jclass		classLoaderClass, classThread;
jmethodID	getContextClassLoaderID, currentThreadID, setContextClassLoaderID;
jobject		jThisClassLoader, curThread;
JNIEnv 		*env = g_mainThreadEnvP;

jclass		jClassAccessController;
jmethodID	jMethodGetContext;
jobject		jAccessControlContext;

	if NOT(classThread = (*env)->FindClass(env, "java/lang/Thread"))
		goto out_err;
	if NOT(currentThreadID = (*env)->GetStaticMethodID(env, classThread, "currentThread", "()Ljava/lang/Thread;"))
		goto out_err;
	if NOT(getContextClassLoaderID = (*env)->GetMethodID(env, classThread, "getContextClassLoader", "()Ljava/lang/ClassLoader;"))
		goto out_err;
	if NOT(curThread = (*env)->CallStaticObjectMethod(env, classThread, currentThreadID))
		goto out_err;
	if NOT(jThisClassLoader = (*env)->CallObjectMethod(env, curThread, getContextClassLoaderID))
		goto out_err;
	gs_jMainThreadClassLoader = (*env)->NewGlobalRef(env, jThisClassLoader);
	
	if NOT(jClassAccessController = (*env)->FindClass(env, "java/security/AccessController"))
		goto out_err;
	if NOT(jMethodGetContext = (*env)->GetStaticMethodID(env, jClassAccessController, "getContext", "()Ljava/security/AccessControlContext;"))
		goto out_err;
	if NOT(jAccessControlContext = (*env)->CallStaticObjectMethod(env, jClassAccessController, jMethodGetContext))
		goto out_err;
	if NOT(gs_jMainThreadAccessControlContext = (*env)->NewGlobalRef(env, jAccessControlContext))
		goto out_err;
	*/
	/*	
	if NOT(classThread = (*env)->FindClass(env, "java/lang/Thread"))
		goto out_err;
	if NOT(currentThreadID = (*env)->GetStaticMethodID(env, classThread, "currentThread", "()Ljava/lang/Thread;"))
		goto out_err;
	if NOT(curThread = (*env)->CallStaticObjectMethod(env, classThread, currentThreadID))
		goto out_err;
	if NOT(setContextClassLoaderID = (*env)->GetMethodID(env, classThread, "setContextClassLoader", "(Ljava/lang/ClassLoader;)V"))
		goto out_err;
	if NOT(classLoaderClass = (*env)->FindClass(env, "java/lang/ClassLoader"))
		goto out_err;
	if NOT(getSystemClassLoaderID = (*env)->GetStaticMethodID(env, classLoaderClass, "getSystemClassLoader", "()Ljava/lang/ClassLoader;"))
		goto out_err;
	if NOT(classLoaderObject = (*env)->CallStaticObjectMethod(env, classLoaderClass, getSystemClassLoaderID))
		goto out_err;
	(*env)->CallVoidMethodV(env, curThread, setContextClassLoaderID, classLoaderObject);
	*/
	/*goto out_ok;
out_err:
	err = XError(kXHelperError, JavaError);
out_ok:
	err = noErr;
	}*/
	// -- end code to solve the forName failure
	
	// Check if was an exception
	/*if (jvmRecP->mainThreadEnvP)
	{	if ((*jvmRecP->mainThreadEnvP)->ExceptionOccurred(jvmRecP->mainThreadEnvP) != NULL)
		{	(*jvmRecP->mainThreadEnvP)->ExceptionDescribe(jvmRecP->mainThreadEnvP);
			(*jvmRecP->mainThreadEnvP)->ExceptionClear(jvmRecP->mainThreadEnvP);
		}
	}*/

if NOT(err)
	*jvmHelperPPtr = (Ptr)jvmRecP;
else if (jvmRecP->localClassPathBlock)
	DisposeBlock(&jvmRecP->localClassPathBlock);

return err;
}

//===========================================================================================
XErr	XLibEnd_JVM(Ptr jvmHelperP)
{
XErr		err = noErr;
JVMRecord	*jvmRecP = (JVMRecord*)jvmHelperP;
BlockRef	block;

	if (jvmRecP)
	{	//(*g_mainThreadEnvP)->DeleteGlobalRef(g_mainThreadEnvP, gs_jMainThreadClassLoader);			// code to solve the forName failure
		//(*g_mainThreadEnvP)->DeleteGlobalRef(g_mainThreadEnvP, gs_jMainThreadAccessControlContext);	// code to solve the forName failure
		(*jvmRecP->jvm)->DestroyJavaVM(jvmRecP->jvm);
		/*
		ex
		if ((*jvmRecP->jvm)->DestroyJavaVM(jvmRecP->jvm) != JNI_OK)
			err = XError(kXHelperError, ErrJavaHelperDestroyJavaVMException);
		*/
		DisposeBlock(&jvmRecP->localClassPathBlock);
		//#if __UNIX_XLIB__
		XFreeDLL(&jvmRecP->libjvm, false);
		block = jvmRecP->block;
		DisposeBlock(&block);
		//#endif
	}
	
return err;
}
#if __MWERKS__
	#pragma export off
#endif


