/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: xmlNode_bfr.c,v 1.13 2006-05-30 14:53:14 valfer Exp $
	|______________________________________________________________________________
*/

#include "BifernoAPI.h"
#include "BfrVersion.h"
#include "xml_bfr.h"

#include <libxml/parser.h>

//static unsigned long 	gsApiVersion;
static long 			gsXmlNodeClassID;

typedef struct {
				xmlNodePtr		nodeP;
				XMLRecord		*xmlRecP;
				} XMLNodeRecord;

// Properties
#define TOT_PROPERTIES 4
enum {
		kName = 1,
		kChildren,
		kNext,
		kContent
};

// Methods
#define TOT_METHODS 6
enum {
		kGetAttr = 1,
		kNew,
		kNewMixed,
		kSetTreeFromString,
		kNewAttr,
		kNewPI
};

// Errors
#define	START_ERR	260
enum {
		Err_NullNode = START_ERR,
		Err_CantCreateAttribute,
		Err_CantCreateNode,
		Err_UTF8ConversionFailed,
		Err_IsolatinConversionFailed,
		Err_DocGetRootElementFailed,
		Err_AddChildFailed,
		Err_CopyNodeFailed,
		Err_ParseMemoryFailed,
		Err_AddPrevSiblingFailed
};
static CStr63	gsXmlNodeErrorsStr[] = 
		{	
		"Err_NullNode",
		"Err_CantCreateAttribute",
		"Err_CantCreateNode",
		"Err_UTF8ConversionFailed",
		"Err_IsolatinConversionFailed",
		"Err_DocGetRootElementFailed",
		"Err_AddChildFailed",
		"Err_CopyNodeFailed",
		"Err_ParseMemoryFailed",
		"Err_AddPrevSiblingFailed"
		};

#define	TOT_ERRORS	10

typedef struct {
				BlockRef	xmlStringUTF;	// <-
				long		xmlStringLen;	// <-
				xmlDocPtr	tempDoc;		// ->
			} XMLParseRecord;

//===========================================================================================
XErr	XML_EncodeUTF(Byte *stringP, int stringLen, BlockRef *resultStringHP, long *resultLenP)
{
XErr	err = noErr;
Byte	*outP;
int		res, outLen;

	if NOT(err = NativeToIso((Ptr)stringP, stringLen))
	{	outLen = stringLen * 2 * sizeof(xmlChar) + 1;
		if (*resultStringHP = NewBlockLocked(outLen, &err, (Ptr*)&outP))
		{	res = isolat1ToUTF8(outP, &outLen, stringP, &stringLen);
			if (res < 0)
			{	err = XError(kBAPI_ClassError, Err_UTF8ConversionFailed);
	        	DisposeBlock(resultStringHP);
	        }
	        else
	      	{	outP[outLen] = 0;                 
				*resultLenP = outLen;
			}
		}
	}
	
return err;                                            
}

//===========================================================================================
XErr	XML_DecodeUTF(Byte *stringP, int stringLen, BlockRef *resultStringHP, long *resultLenP)
{
XErr	err = noErr;
Byte	*outP;
int		res, outLen;

	outLen = stringLen * 2 * sizeof(xmlChar) + 1;
	if (*resultStringHP = NewBlockLocked(outLen, &err, (Ptr*)&outP))
	{	res = UTF8Toisolat1(outP, &outLen, stringP, &stringLen);
		if (res < 0)
			err = XError(kBAPI_ClassError, Err_IsolatinConversionFailed);
        else
		{	outP[outLen] = 0;
      		*resultLenP = outLen;
      		err = IsoToNative((Ptr)outP, outLen);
      	}
      	if (err)
      		DisposeBlock(resultStringHP);        
	}
	
return err;                                            
}

//===========================================================================================
XErr	CreateXmlNode(long api_data, XMLRecord *xmlRecP, xmlNodePtr nodeP, ObjRef *resultObjRefP, long constructorPrivateData)
{
XErr			err = noErr;
XMLNodeRecord	xmlNodeRec;
//long			pdata;

	xmlNodeRec.nodeP = nodeP;
	xmlNodeRec.xmlRecP = xmlRecP;
	if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&xmlNodeRec, sizeof(XMLNodeRecord), gsXmlNodeClassID, true, constructorPrivateData, resultObjRefP))
		xmlRecP->refCount++;

return err;
}

//===========================================================================================
static XErr _MyParseMemory(long userData)
{
XMLParseRecord	*pRecP = (XMLParseRecord*)userData;

	pRecP->tempDoc = xmlParseMemory(GetPtr(pRecP->xmlStringUTF), pRecP->xmlStringLen);

return noErr;
}

//===========================================================================================
static XErr	_SetTreeFromString(ExecuteMethodRec *exeMethodRecP, long api_data, XMLNodeRecord *xmlNodeRecP)
{
XErr			err = noErr;
CStr255			aCStr;
char			*xmlStringP;
long			stdErrLen, xmlStringLen;
BlockRef		stdErrNative, stdErr, ref, xmlStringUTF;
xmlNodePtr		newNodeP, tempRootP, copyNode;
XMLParseRecord	pRec;
Boolean			isInit;
ParameterRec	*parP = exeMethodRecP->paramVarsP;

	if NOT(err = BAPI_GetStringBlock(api_data,  &parP[0].objRef, aCStr, &xmlStringP, &xmlStringLen, &ref, kImplicitTypeCast))
	{	if NOT(err = XML_EncodeUTF((Byte*)xmlStringP, xmlStringLen, &xmlStringUTF, &xmlStringLen))
		{	pRec.xmlStringUTF = xmlStringUTF;
			pRec.xmlStringLen = xmlStringLen;
			// XMLRedirOutput must be called under critical section (and all during stdErr blockref use)
			XThreadsEnterCriticalSection();
			if NOT(err = XMLRedirOutput(_MyParseMemory, (long)&pRec, &stdErr, &stdErrLen))
			{	if (stdErrLen)
				{	if (NOT(err = BAPI_IsVariableInitialized(api_data, &parP[1].objRef, &isInit)) && isInit)
					{	if NOT(err = XML_DecodeUTF((Byte*)GetPtr(stdErr), stdErrLen, &stdErrNative, &stdErrLen))
						{	err = BAPI_StringToObj(api_data, GetPtr(stdErrNative), stdErrLen, &parP[1].objRef);
							DisposeBlock(&stdErrNative);
						}
					}
					err = XError(kBAPI_ClassError, Err_ParseMemoryFailed);
				}
				else
				{	if (tempRootP = xmlDocGetRootElement(pRec.tempDoc))
					{	if (copyNode = xmlCopyNode(tempRootP, true))
						{	if (newNodeP = xmlAddChild(xmlNodeRecP->nodeP, copyNode))
							{	err = CreateXmlNode(api_data, xmlNodeRecP->xmlRecP, newNodeP, &exeMethodRecP->resultObjRef, 0);
								xmlFreeDoc(pRec.tempDoc);
							}
							else
								err = XError(kBAPI_ClassError, Err_AddChildFailed);
						}
						else
							err = XError(kBAPI_ClassError, Err_CopyNodeFailed);
					}
					else
						err = XError(kBAPI_ClassError, Err_DocGetRootElementFailed);
				}
				// remember: never dispose stdErr (ex DisposeBlock(&stdErr)), it's a global
			}
			XThreadsLeaveCriticalSection();
			DisposeBlock(&xmlStringUTF);
		}
		DisposeBlock(&ref);
	}
	
return err;
}

//===========================================================================================
static XErr	_NewPI(ExecuteMethodRec *exeMethodRecP, long api_data, XMLNodeRecord *xmlNodeRecP)
{
BlockRef	ref;
CStr255		name, aCStr;
char		*contentP;
long		contentLen, contentUTFLen, nameLen, nameUTFLen;
BlockRef	nameUTF, contentUTF;
XErr		err = noErr;
xmlNodePtr	temp, newNodeP;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, &nameLen, 256, kImplicitTypeCast))
	{	if NOT(err = XML_EncodeUTF((Byte*)name, nameLen, &nameUTF, &nameUTFLen))
		{	if NOT(err = BAPI_GetStringBlock(api_data,  &exeMethodRecP->paramVarsP[1].objRef, aCStr, &contentP, &contentLen, &ref, kImplicitTypeCast))
			{	if NOT(err = XML_EncodeUTF((Byte*)contentP, contentLen, &contentUTF, &contentUTFLen))
				{	if (temp = xmlNewPI((const xmlChar *)GetPtr(nameUTF), (const xmlChar *)GetPtr(contentUTF)))
					{	if NOT(newNodeP = xmlAddPrevSibling(xmlNodeRecP->nodeP, temp))
						{	err = XError(kBAPI_ClassError, Err_AddPrevSiblingFailed);
							xmlFreeNode(temp);
						}
					}
					else
						err = XError(kBAPI_ClassError, Err_CantCreateNode);
					DisposeBlock(&contentUTF);
				}
				DisposeBlock(&ref);
			}
			if NOT(err)
          		err = CreateXmlNode(api_data, xmlNodeRecP->xmlRecP, newNodeP, &exeMethodRecP->resultObjRef, 0);
		}
		DisposeBlock(&nameUTF);
	}
	
return err;
}

//===========================================================================================
static XErr	_NewNode(ExecuteMethodRec *exeMethodRecP, long api_data, XMLNodeRecord *xmlNodeRecP, Boolean isMixed)
{
BlockRef	ref;
CStr255		name, aCStr;
char		*contentP;
long		contentLen, contentUTFLen, nameLen, nameUTFLen;
BlockRef	nameUTF, contentUTF;
XErr		err = noErr;
xmlNodePtr	newNodeP;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, &nameLen, 256, kImplicitTypeCast))
	{	if NOT(err = XML_EncodeUTF((Byte*)name, nameLen, &nameUTF, &nameUTFLen))
		{	if (isMixed)
			{	if NOT(err = BAPI_GetStringBlock(api_data,  &exeMethodRecP->paramVarsP[1].objRef, aCStr, &contentP, &contentLen, &ref, kImplicitTypeCast))
				{	if NOT(err = XML_EncodeUTF((Byte*)contentP, contentLen, &contentUTF, &contentUTFLen))
					{	newNodeP = xmlNewChild(xmlNodeRecP->nodeP, nil, (Byte*)GetPtr(nameUTF), (Byte*)GetPtr(contentUTF));
						DisposeBlock(&contentUTF);
					}
					DisposeBlock(&ref);
				}
			}
			else
				newNodeP = xmlNewChild(xmlNodeRecP->nodeP, nil, (Byte*)GetPtr(nameUTF), nil);
			if (newNodeP)
          		err = CreateXmlNode(api_data, xmlNodeRecP->xmlRecP, newNodeP, &exeMethodRecP->resultObjRef, 0);
			else
				err = XError(kBAPI_ClassError, Err_CantCreateNode);
		}
		DisposeBlock(&nameUTF);
	}
	
return err;
}

//===========================================================================================
static XErr	_NewAttr(ExecuteMethodRec *exeMethodRecP, long api_data, XMLNodeRecord *xmlNodeRecP)
{
BlockRef	ref;
CStr255		name, aCStr;
char		*contentP;
long		contentLen, contentUTFLen, nameLen, nameUTFLen;
BlockRef	nameUTF, contentUTF;
XErr		err = noErr;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, &nameLen, 256, kImplicitTypeCast))
	{	if NOT(err = BAPI_GetStringBlock(api_data,  &exeMethodRecP->paramVarsP[1].objRef, aCStr, &contentP, &contentLen, &ref, kImplicitTypeCast))
		{	if NOT(err = XML_EncodeUTF((Byte*)name, nameLen, &nameUTF, &nameUTFLen))
			{	if NOT(err = XML_EncodeUTF((Byte*)contentP, contentLen, &contentUTF, &contentUTFLen))
				{	if NOT(xmlNewProp(xmlNodeRecP->nodeP, (Byte*)GetPtr(nameUTF), (Byte*)GetPtr(contentUTF)))
						err = XError(kBAPI_ClassError, Err_CantCreateAttribute);
					DisposeBlock(&contentUTF);
				}
				DisposeBlock(&nameUTF);
			}
			DisposeBlock(&ref);
		}                    
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	XmlNode_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				api_data = pbPtr->api_data;
BAPI_MemberRecord	XmlNodeProperites[TOT_PROPERTIES] = 
			{	
				"name",			kName,			"string name",
				"children",		kChildren,		"xmlNode children",
				"next",			kNext,			"xmlNode next",
				"content",		kContent,		"string content"
			};
BAPI_MemberRecord	XmlNodeMethods[TOT_METHODS] = 
			{	
				"GetAttr",			kGetAttr,			"string GetAttr(string attrName)",
				"NewChild",			kNew,				"xmlNode NewChild(string name)",
				"NewMixedChild",	kNewMixed,			"xmlNode NewMixedChild(string name, string content)",
				"SetTreeFromString",kSetTreeFromString,	"xmlNode SetTreeFromString(string xmlstring, string *errorMsg)",
				"NewAttr",			kNewAttr,			"void NewAttr(string attrName, string attrContent)",
				"NewPI",			kNewPI,				"xmlNode NewPI(string name, string content)"
			};

	if (err = BAPI_NewProperties(api_data, gsXmlNodeClassID, XmlNodeProperites, TOT_PROPERTIES, nil))
		return err;
	if (err = BAPI_NewMethods(api_data, gsXmlNodeClassID, XmlNodeMethods, TOT_METHODS, nil))
		return err;
	err = BAPI_RegisterErrors(api_data, gsXmlNodeClassID, START_ERR, gsXmlNodeErrorsStr, TOT_ERRORS);

return err;
}
//===========================================================================================
static XErr	XmlNode_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr				err = noErr;
XMLNodeRecord		xmlNodeRec;
long				tLen;
ConstructorRec		*constructorRecP = &pbPtr->param.constructorRec;

	if (message == kClone)
	{	tLen = sizeof(XMLNodeRecord);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&xmlNodeRec, &tLen, 0, nil))
			err = CreateXmlNode(pbPtr->api_data, xmlNodeRec.xmlRecP, xmlNodeRec.nodeP, &constructorRecP->resultObjRef, constructorRecP->privateData);
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation); 

return err;
}

//===========================================================================================
static XErr	XmlNode_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
DestructorRec		*destructorRecP = &pbPtr->param.destructorRec;
long				objLen;
XMLNodeRecord		xmlNodeRec;

	objLen = sizeof(XMLNodeRecord);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&xmlNodeRec, &objLen, 0, nil))
	{	if (objLen)
			DecrementNode(xmlNodeRec.xmlRecP);
    }

return err;
}

//===========================================================================================
static XErr	XmlNode_Primitive(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
PrimitiveRec	*primitiveRecP = &pbPtr->param.primitiveRec;
long			tLen, strLen, api_data = pbPtr->api_data;
char			*strP, *p;
PrimitiveUnion	*param_d;
//CStr255			buffer;
BlockRef		resultStringBlock = 0;
XMLNodeRecord	xmlNodeRec;

	tLen = sizeof(XMLNodeRecord);
	if NOT(err = BAPI_ReadObj(api_data, &primitiveRecP->objRef, (Ptr)&xmlNodeRec, &tLen, 0, nil))
	{	param_d = &primitiveRecP->result;
		switch(primitiveRecP->resultWanted)
		{
			case kCString:
				if (xmlNodeRec.nodeP)
				{	strP = (char*)xmlNodeRec.nodeP->name;
					if NOT(err = XML_DecodeUTF((Byte*)strP, CLen(strP), &resultStringBlock, &strLen))
						strP = GetPtr(resultStringBlock);
				}
				else
				{	strP = "[null node]";
					strLen = CLen(strP);
				}
				p = param_d->text.stringP;
				if (p)
				{	if (param_d->text.stringMaxStorage >= (strLen+1))
					{	CopyBlock(p, strP, strLen);
						p[strLen] = 0;
						param_d->text.stringLen = strLen;
					}
					else
					{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = strLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = strLen;
				break;
				
			case kBool:
				param_d->boolValue = (xmlNodeRec.nodeP != 0);
				break;

			default:
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
				break;
	  	}
	  	if (resultStringBlock)
	  		DisposeBlock(&resultStringBlock);
	}
	
return err;
}

//===========================================================================================
static XErr	XmlNode_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*executeMethodRecP = &pbPtr->param.executeMethodRec;
XMLNodeRecord		xmlNodeRec;
long				tLen, api_data = pbPtr->api_data;
xmlChar				*attr;
CStr255				attrName;
BlockRef			resultStringBlock;

	tLen = sizeof(XMLNodeRecord);
	if NOT(err = BAPI_ReadObj(api_data, &executeMethodRecP->objRef, (Ptr)&xmlNodeRec, &tLen, 0, nil))
	{	if NOT(xmlNodeRec.nodeP)
			err = XError(kBAPI_ClassError, Err_NullNode);
		else
		{	switch(executeMethodRecP->methodID)
			{
				case kGetAttr:
	      			if NOT(err = BAPI_ObjToString(api_data, &executeMethodRecP->paramVarsP[0].objRef, attrName, nil, 256, kImplicitTypeCast))
					{	if (attr = xmlGetProp(xmlNodeRec.nodeP, (Byte*)attrName))
						{	if NOT(err = XML_DecodeUTF((Byte*)attr, CLen((Ptr)attr), &resultStringBlock, &tLen))
							{	err = BAPI_StringToObj(api_data, GetPtr(resultStringBlock), tLen, &executeMethodRecP->resultObjRef);
								DisposeBlock(&resultStringBlock);
							}
						}
						else
							err = BAPI_StringToObj(api_data, "", 0, &executeMethodRecP->resultObjRef);
					}
					break;
				
				case kNew:
	 				err = _NewNode(executeMethodRecP, api_data, &xmlNodeRec, false);
	 				break;
					    
				case kNewMixed:
	 				err = _NewNode(executeMethodRecP, api_data, &xmlNodeRec, true);
	 				break;

				case kSetTreeFromString:
	 				err = _SetTreeFromString(executeMethodRecP, api_data, &xmlNodeRec);
	 				break;
				
				case kNewAttr:                     
	 				err = _NewAttr(executeMethodRecP, api_data, &xmlNodeRec);
	 				break;

				case kNewPI:
	 				err = _NewPI(executeMethodRecP, api_data, &xmlNodeRec);
	 				break;
	
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	XmlNode_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;
XMLNodeRecord		xmlNodeRec;
long				tLen, api_data = pbPtr->api_data;
xmlChar				*key;
BlockRef			resultStringBlock;

	tLen = sizeof(XMLNodeRecord);
	if NOT(err = BAPI_ReadObj(api_data, &getPropertyRec->objRef, (Ptr)&xmlNodeRec, &tLen, 0, nil))
	{	if NOT(xmlNodeRec.nodeP)
			err = XError(kBAPI_ClassError, Err_NullNode);
		else
		{	switch(getPropertyRec->propertyID)
			{
				case kName:
					if (xmlNodeRec.nodeP->name)
					{	if NOT(err = XML_DecodeUTF((Byte*)xmlNodeRec.nodeP->name, CLen((const char *)xmlNodeRec.nodeP->name), &resultStringBlock, &tLen))
						{	err = BAPI_StringToObj(api_data, GetPtr(resultStringBlock), tLen, &getPropertyRec->resultObjRef);
							DisposeBlock(&resultStringBlock);
						}
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
					break;

				case kChildren:
					err = CreateXmlNode(api_data, xmlNodeRec.xmlRecP, xmlNodeRec.nodeP->xmlChildrenNode, &getPropertyRec->resultObjRef, 0);
					break;

				case kNext:
					err = CreateXmlNode(api_data, xmlNodeRec.xmlRecP, xmlNodeRec.nodeP->next, &getPropertyRec->resultObjRef, 0);
					break;
				
				case kContent:
					// if (key = xmlNodeListGetString(xmlNodeRec.xmlRecP->docP, xmlNodeRec.nodeP, 1))
					if (key = xmlNodeGetContent(xmlNodeRec.nodeP))
					{	if NOT(err = XML_DecodeUTF(key, CLen((const char *)key), &resultStringBlock, &tLen))
						{	err = BAPI_StringToObj(api_data, GetPtr(resultStringBlock), tLen, &getPropertyRec->resultObjRef);
							DisposeBlock(&resultStringBlock);
						}
						xmlFree(key);
					}
					else
						err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
					break;
					
				default:
					err = XError(kBAPI_Error, Err_NoSuchProperty);
					break;
			}
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	xmlNode_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
	case kRegister:
		pbPtr->param.registerRec.pluginType = kNewClassPlugin;
		CEquStr(pbPtr->param.registerRec.pluginName, "xmlNode");
		gsXmlNodeClassID = pbPtr->param.registerRec.pluginID;
		pbPtr->param.registerRec.wantDestructor = true;
		pbPtr->param.registerRec.fixedSize = true;
		CEquStr(pbPtr->param.registerRec.constructor, "");
		CEquStr(pbPtr->param.registerRec.pluginDescr, "DOM: xmlNode interface for Biferno");
		//BAPI_GetVersions(pbPtr->api_data, pbPtr->param.registerRec.pluginVersionStr, nil, nil);
		//CEquStr(pbPtr->param.registerRec.pluginVersionStr, CUR_BIFERNO_VERSION_STR);
		VersionToString(CUR_BIFERNO_VERSION, pbPtr->param.registerRec.pluginVersionStr, nil);
		if NOT(CCompareStrings(STATUS_VERS_STR, "unstable"))
			CAddChar(pbPtr->param.registerRec.pluginVersionStr, 'u');
		break;
	case kInit:
		err = XmlNode_Init(pbPtr);
		break;
	case kShutDown:
    	break;
	case kRun:
    	break;
	case kExit:
    	break;
	case kConstructor:
	case kTypeCast:
	case kClone:
    	err = XmlNode_Constructor(pbPtr, message);
    	break;
	case kDestructor:
		err = XmlNode_Destructor(pbPtr);
		break;
	case kExecuteOperation:
		err = XError(kBAPI_Error, Err_IllegalOperation);
		break;
	case kExecuteMethod:
		err = XmlNode_ExecuteMethod(pbPtr);
		break;
	case kExecuteFunction:
		break;
	case kGetProperty:
		err = XmlNode_GetProperty(pbPtr);
		break;
	case kSetProperty:
		err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
		break;
	case kPrimitive:
		err = XmlNode_Primitive(pbPtr);
		break;
	case kGetErrMessage:
		break;
	default:
		break;
	}

return err;
}
