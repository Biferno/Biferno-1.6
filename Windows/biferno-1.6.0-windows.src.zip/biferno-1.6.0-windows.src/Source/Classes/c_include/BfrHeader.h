/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BfrHeader.h,v 1.1 2003-06-25 15:44:43 valfer Exp $
	|______________________________________________________________________________
*/
typedef struct HeaderObjectRec
{
	DLMRef		list;
} HeaderObjectRec;

typedef  XErr 	(*PackHeader_Prot)(HeaderObjectRec *headObjP, BlockRef *headBlockP, long *headBlockLenP);
XErr	PackHeader(HeaderObjectRec *headObjP, BlockRef *headBlockP, long *headBlockLenP);

typedef  XErr 	(*TokenizeHeader_Prot)(char *headerP, long headerLen, HeaderObjectRec *headObjP, long listGlobal);
XErr	TokenizeHeader(char *headerP, long headerLen, HeaderObjectRec *headObjP, long listGlobal);

typedef  XErr 	(*InitializeHeaderOut_Prot)(char *serverName, HeaderObjectRec *newHeadObjRecP, Boolean empty);
XErr	InitializeHeaderOut(char *serverName, HeaderObjectRec *newHeadObjRecP, Boolean empty);

typedef  XErr 	(*ObjRefFromHeaderObjectRec_Prot)(long api_data, HeaderObjectRec *headObjRecP, ObjRef *objRef);
XErr	ObjRefFromHeaderObjectRec(long api_data, HeaderObjectRec *headObjRecP, ObjRef *objRef);

typedef  XErr 	(*DisposeHeaderObject_Prot)(HeaderObjectRec *headObjRecP);
void	DisposeHeaderObject(HeaderObjectRec *headObjRecP);

typedef  XErr 	(*CloneHeaderObjectRec_Prot)(HeaderObjectRec *headObjRecP, HeaderObjectRec *newHeadObjRecP);
XErr	CloneHeaderObjectRec(HeaderObjectRec *headObjRecP, HeaderObjectRec *newHeadObjRecP);

typedef  XErr 	(*GetCookie_Prot)(HeaderObjectRec *headObjRecP, char *cookieName, char *cookieValue, long maxStorage);
XErr	GetCookie(HeaderObjectRec *headObjRecP, char *cookieName, char *cookieValue, long maxStorage);

typedef  XErr 	(*SetCookie_Prot)(HeaderObjectRec *headObjRecP, char *cookieName, char *cookieValue);
XErr	SetCookie(HeaderObjectRec *headObjRecP, char *cookieName, char *cookieValue);

typedef  XErr 	(*GetHeaderField_Prot)(long api_data, char *fieldName, ObjRef *objRefP);
XErr	GetHeaderField(long api_data, char *fieldName, ObjRef *objRefP);

typedef  XErr 	(*SetHeaderField_Prot)(HeaderObjectRec *headObjRecP, char *fieldName, long index, char *contentP, long contentLen);
XErr	SetHeadField(HeaderObjectRec *headObjRecP, char *fieldName, long index, char *contentP, long contentLen);
