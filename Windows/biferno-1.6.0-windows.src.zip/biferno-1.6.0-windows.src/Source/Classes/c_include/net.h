/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: net.h,v 1.2 2003-06-19 10:47:26 valfer Exp $
	|______________________________________________________________________________
*/
#ifndef __NET__
#define __NET__

#include "def.h"

/*	Constants. */

#define kBufSize 			(4*1024)			/* buffer size */
#define kBufSizeDiv2		(kBufSize/2)		/* buffer size div 2 */
#define kMinTCPBufSize		(16*1024)			/* minimum MacTCP stream buffer size */

#ifdef __MAC_XLIB__
	typedef	unsigned long		NetAddress;
#else
	typedef	XSafeHostent		NetAddress;
#endif	

#if __MAC_XLIB__ && !TARGET_API_MAC_CARBON
	#include "OpenTransport.h"
	#include "OpenTptInternet.h"
#endif

/*	Types. */

typedef struct TStream {			/* Stream info */

	//TCPiopb pBlock;					/* MacTCP parameter block (must be first, unused with
									   //Open Transport) */
	
	/* Fields used with both Open Transport and MacTCP. */
									   
	BlockRef next;					/* ex TStream*: pointer to next stream in list of all open streams */
	BlockRef nextClose;				/* ex TStream*: pointer to next stream in list of closing streams */
	BlockRef nextFree;				/* ex TStream*: pointer to next stream in list of available preallocated streams */
	
	NetAddress serverAddr;			/* IP address of server */
	unsigned short serverPort;		/* port number on server */
	unsigned short localPort;		/* local port number */
	char buf[kBufSize];				/* data buffer */
	char *in;						/* pointer to next location in data buffer in
									   which incoming network bytes should be stored */
	char *out;						/* pointer to next location in data buffer from
									   which bytes should be removed and delivered
									   to our clients (note: we always have out <= in) */
	Boolean fromFreeList;			/* true if this buffer was obtained from the free list */
	Boolean passiveOpenInProgress;	/* true while passive open is in progress on steam */
	CStr255 command;				/* last command sent on stream */
	CStr255 response;				/* last response received on stream */
	long responseCode;				/* last response code received on stream */
	Boolean closing;				/* true when closing stream */
	Boolean otherSideHasClosed;		/* true when other side has closed its end of 
									   the stream */
	Boolean weHaveClosed;			/* true when we have closed our end of the stream */
	Boolean release;				/* true when stream should be released */
	long bytesIn;					/* number of bytes received on stream */
	long bytesOut;					/* number of bytes sent on stream */
	
#if __MAC_XLIB__
/* Fields used only with Open Transport. */
	EndpointRef	ref;				/* endpoint reference */
	Boolean		complete;			/* true when asynch operation has completed */
	OTEventCode	code;				/* event code */
	OTResult	result;				/* result */
	void		*cookie;			/* cookie */
	TCall		*call;				/* pointer to call structure */
	TBind		*bindReq;			/* pointer to bind request structure */
	TBind		*bindRet;			/* pointer to bind return structure */
#else
	int			socketRef;			// Socket reference
#endif
	
	/* Fields used only with MacTCP. */
	
	/*long myA5;					//our A5 register
	StreamPtr tcpStream;			//MacTCP stream pointer
	struct wdsEntry wds[2];			//MacTCP write data structure
	char mactcpBuf[1];				//MacTCP buffer - size depends on MTU (must be last)
	*/
	
} TStream, *TStreamPtr;

#ifdef __MAC_XLIB__
	typedef struct TMyOTInetSvcInfo {		/* Open Transport Internet services provider info */
		InetSvcRef ref;			/* provider reference */
		Boolean complete;		/* true when asynch operation has completed */
		OTResult result;		/* result code */
		void *cookie;			/* cookie */
	} TMyOTInetSvcInfo;
#endif

#define netOpenDriverErr		100
#define netOpenStreamErr		101
#define netLostConnectionErr	102
#define netDNRErr				103
#define netTruncatedErr			104

typedef struct NetStreamPrivateData {
	char private[1];
} NetStreamPrivateData, **NetStreamRef;

typedef struct NetServerErrInfo {
	CStr255 command;
	CStr255 response;
	long responseCode;
} NetServerErrInfo;

typedef XErr (*NetGiveTimeFunction) (void);
typedef void (*NetLogFunction) (char logEntryType, NetAddress *serverAddr,
	unsigned short serverPort, unsigned short localPort, char *str, long userData);
typedef void (*NetDoOneResponse) (long responseCode, CStr255 response, Ptr userDataPtr);
typedef XErr (*NetChunkFunction) (Ptr t, long tLen, Ptr userDataPtr,
	long *truncPos);

XErr NetInit (NetGiveTimeFunction giveTime, NetLogFunction log, short numBuffs, Boolean initOpenTransport);
XErr NetIdle (long userdata);
XErr NetTerm (Boolean closeOpenTransport, long userdata);

XErr NetOpen (NetAddress *addr, unsigned short port, Boolean getHello, NetStreamRef *stream, long *responseCode, CStr255 response, long userData, char *errmsg);
XErr NetClose (NetStreamRef stream, long userData);
XErr NetCommand (NetStreamRef stream, char *command, 
	long *responseCode, CStr255 response, long userData);
XErr NetGetExtraResponse (NetStreamRef stream, long *responseCode, 
	CStr255 response, long userData);
XErr NetBatchedCommands (NetStreamRef stream, BlockRef *commandsP, NetDoOneResponse doOneResponse, Ptr userDataPtr, long userData);
XErr NetPutText (NetStreamRef stream, BlockRef *textP, Boolean munge, long userData);
XErr NetGetText (NetStreamRef stream, BlockRef *text, 
	NetChunkFunction chunkFunction, Ptr userDataPtr, long userData);

XErr NetFTPDataPassiveOpen (unsigned short *port, NetStreamRef *stream, long userData);
XErr NetFTPDataClose (NetStreamRef stream, long userData);
XErr NetFTPDataWaitForConnection (NetStreamRef stream, long userData);
XErr NetPutFTPData (NetStreamRef stream, Boolean mapCR, BlockRef *dataP, long userData);
XErr NetGetFTPData (NetStreamRef stream, Boolean mapCR, BlockRef *data, long userData);

XErr NetAddrToName (NetAddress *addr, CStr255 name);

Boolean NetMacTCPDNROperationInProgress (void);
void NetGetServerErrInfo (NetStreamRef stream, NetServerErrInfo *serverErrInfo);
void NetGetStreamStats (NetStreamRef stream, long *bytesIn, long *bytesOut);
Boolean NetHaveOT (void);
short NetGetNumOpenStreams (void);

void LogMessage (TStreamPtr s, char logEntryType, char *str, long userData);
XErr TranslateErrorCode (XErr err);

// Platform dependent
XErr NetGetMyName (CStr255 name);
XErr NetGetMyAddrStr (char *addrStr);
XErr NetNameToAddr (char *name, unsigned short defaultPort, NetAddress *addr, unsigned short *port);
void NetAddressToString (NetAddress *address, CStr255 name);

XErr DoTCPCreate(BlockRef sBlock);
XErr DoTCPRcv (TStreamPtr s, Ptr data, unsigned short *len);
XErr DoTCPRelease (BlockRef sBlock, long userData);
XErr DoTCPActiveOpen (TStreamPtr s, NetAddress *addr, unsigned short port, long userData);
XErr DoTCPSend (TStreamPtr s, Ptr data, unsigned short len/*, Boolean push*/);
XErr DoTCPPassiveOpen (TStreamPtr s, unsigned short *port);

XErr MyOTStreamWait (TStreamPtr s, Boolean returnImmediatelyOnError);
#ifdef __MAC_XLIB__
	XErr MyOTOpenInetServices (TMyOTInetSvcInfo *svcInfo);
	XErr MyOTInetSvcWait (TMyOTInetSvcInfo *svcInfo, Boolean returnImmediatelyOnError);
#endif

XErr MungeOut (BlockRef *textBlockP, Boolean mungePeriods);

#endif
