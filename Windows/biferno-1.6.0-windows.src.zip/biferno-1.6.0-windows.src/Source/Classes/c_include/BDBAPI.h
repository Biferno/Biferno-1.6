/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BDBAPI.h,v 1.13 2005-05-16 10:42:41 valfer Exp $
	|______________________________________________________________________________
*/
#ifndef __BDBAPIBIFERNO__
	#define __BDBAPIBIFERNO__
	
// Errors
#define	BDBAPI_FIRST_ERR	200
enum {
		ErrDBMSError = BDBAPI_FIRST_ERR,
		ErrGettingCurRecs,
		ErrGettingAffectedRecs,
		ErrBadSeekIndex,
		ErrNotEnoughStorageForRecord,
		ErrUnknownDBType,
		ErrBadCursorMode,
		ErrTooManyCursors,
		ErrTooManyPrepares,
		ErrBadPrepareID,
		ErrBadCursorID,
		ErrInvalidFree,
		ErrNoCursorAvailable,
		ErrUndefinedBindVariable,
		ErrUnknownSpecific
};
#define BDBAPI_TOT_ERRORS	15
// Cursor types
enum {
		kDefault = 1,
		kStatic,
		kDynamic,
		kInputBindMode,
		kOutputBindMode,
		kInputOutputBindMode,
		kNull
	};
// Messages
typedef enum {
	kConnect,
	kDisconnect,
	kExec,
	kCall,
	kCallExt,
	kPrepare,
	kFreePrepare,
	kRowSetSize,
	kGetPrepared,
	kBind,
	kBindAll,
	kExecPrepared,
	kFreeResult,
	kSeek,
	kTell,
	kWarning,
	kGetCurRecs,
	kGetAffectedRecs,
	kFetchRec,
	kTransaction,
	kCommit,
	kRollBack,
	kRealEscape,
	kRealUnescape,
	kGetSpecific,
	kSetSpecific,
	kLobWrite,
	kLobRead
} BDBAPI_Message;

#define BDBAPI_LAST_MESSAGE		kLobRead

typedef struct {
	CStr255			connString;				// in
	long			connStringLen;			// in
	BlockRef		connBuffer;				// out
	Ptr				connPointer;			// out
	long			connBufferLength;		// out
} ConnectRec;
typedef struct {
	BlockRef		connBuffer;				// in
	long			connBufferLength;		// in
} DisconnectRec;
typedef struct {
	long			cursorID;				// in
} FreeResultRec;
typedef struct {
	char			*sqlStringP;			// in
	long			sqlStringLen;			// in
	long			rowSetSize;				// in
	short			cursorMode;				// in
	Boolean			onlyPrepare;			// in
	Boolean			dontReturnCursor;		// in
	long			cursorID;				// out	
} ExecRec;
typedef struct {
	CStr255			procName;				// in
	ParameterRec 	*params;				// in
	long			totParams;				// in
	ObjRef			*returnValue;			// out
	long			cursorID;				// out (only if kCallExt)
} CallRec;
typedef struct {
	long			cursorID;				// in	
} ExecPreparedRec;
typedef struct {
	long			cursorID;				// in
	long			pos;					// in
} SeekRec;
typedef struct {
	long			cursorID;				// in
	long			pos;					// out
} TellRec;
typedef struct {
	long			cursorID;				// in
	CStr255			warning;				// out
} WarningRec;
typedef struct {
	long			cursorID;				// in
	Boolean			undefNull;				// in
	Boolean			fetchLocator;			// in
	short			pad2;
	ObjRef			object;					// out
} FetchRec;
typedef struct {
	long			cursorID;				// in
	long			curRecs;				// out
} GetCurRecsRec;
typedef struct {
	long			cursorID;				// in
	long			affectedRecs;			// out
} GetAffectedRecsRec;
typedef struct {
	char			*stringP;				// in
	long			stringLen;				// in
	Boolean			byteEsc;				// in
	Boolean			unescape;				// in
	short			pad2;
	ObjRef			resultObj;				// out
} RealEscapeRec;
typedef struct {
	long			totCursors;				// in
	long			cursorMode;				// in
	long			rowSetSize;				// in
	char			*sqlStringP;			// in
	long			sqlStringLen;			// in
	long			prepareID;				// out
} PrepareRec;
typedef struct {
	long			prepareID;				// in
} FreePrepareRec;
typedef struct {
	long			cursorID;				// in
	long			size;					// in
} RowSetSizeRec;
typedef struct {
	long			prepareID;				// in
	long			cursorID;				// out
} GetPreparedRec;
typedef struct {
	long			cursorID;				// in
	long			prepareID;				// in (if BindAll)
	CStr255			paramObjName;			// in
	long			paramNum;				// in
	long			paramMode;				// in
	long			paramStorage;			// in
} BindRec;
typedef struct {
	long			cursorID;		// in
	CStr255			name;			// in
	CStr255			value;			// out
} GetSpecificRec;
typedef struct {
	long			cursorID;		// in
	CStr255			name;			// in
	CStr255			value;			// in
} SetSpecificRec;
typedef struct {
	long			locator;		// in		
	long			offset;			// in		LobRead/LobWrite
	long			len;			// in		LobRead
	Ptr				buffer;			// in		LobWrite
	ObjRef			outObj;			// out		LobRead
} LobRec;
typedef union {
	ConnectRec			connectRec;
	DisconnectRec		disconnectRec;
	FreeResultRec		freeResultRec;
	ExecRec				execRec;
	BindRec				bindRec;
	CallRec				callRec;
	PrepareRec			prepareRec;
	FreePrepareRec		freePrepareRec;
	RowSetSizeRec		rowSetSizeRec;
	GetPreparedRec		getPreparedRec;
	ExecPreparedRec		execPreparedRec;
	SeekRec				seekRec;
	TellRec				tellRec;
	WarningRec			warningRec;
	FetchRec			fetchRec;
	GetCurRecsRec		getCurRecsRec;
	GetAffectedRecsRec	getAffectedRecsRec;
	RealEscapeRec		realEscapeRec;
	GetSpecificRec		getSpecificRec;
	SetSpecificRec		setSpecificRec;
	LobRec				lobRec;
} BDBAPI_PB_Union;
typedef struct {
	long				api_data;
	long				db_api_data;
	CStr255				error;
	Ptr					connBufferPtr;
	long				connBufferLength;
	BDBAPI_PB_Union		param;
} BDBAPI_ParamBlock, *BDBAPI_ParamBlockPtr;

// BDBAPIDispatch
typedef	XErr	(*BDBAPI_Dispatch)(BDBAPI_Message message, BDBAPI_ParamBlockPtr pbPtr);

// Prepare Delegation
/*
#define		kAllCursors		-2
#define		kBindSubstitute		1
#define		kBindFlush			2
*/
#define		MAX_BOUND_PARAM_LENGTH	255
typedef struct
{		
	CStr255			name;		// name of the biferno bound obj
	char			staticStorage[MAX_BOUND_PARAM_LENGTH + 1];
	Ptr				valueP;
	BlockRef		valueBlock;
	long			valueStorage;
	long			paramNum;
	long			length;
	long			mode;
} BDBAPI_ParameterDescr;

// Call back
typedef	XErr 	(*BDBAPI_CallBack)(long api_data, long db_api_data, Ptr cursorP, long userData, char *error);
typedef	Boolean	(*BDBAPI_IsNullCallBack)(BDBAPI_ParameterDescr *paramP, long index, long userData);

// Prepare Record
typedef struct
{		
	char			*sqlStringP;	// in
	long			sqlStringLen;	// in
	long			totCursors;		// in
	//long			cursorMode;		// in
	long			userData;		// in
	long			prepareID;		// out
} PrepareParams;


#define	DB_NULL_VALUE		"\v\r\n\t"
#define	DB_NULL_VALUE_LEN	4

// Main Record (Functions)
typedef struct
{		
	XErr	(*BDBAPI_Register)(char *dbmsName, BDBAPI_Dispatch dispatcher, long sizeOfCursor, Boolean multiThreadLimited);
	XErr	(*BDBAPI_ObjToConnBuffer)(long api_data, long db_api_data, ObjRef *objRefP, Ptr connBuffP, long *lenP, long maxStorage);
	XErr	(*BDBAPI_Escape)(long api_data, long db_api_data, char *stringP, long stringLen, BlockRef *resultBlockP, long *resultLenP);
	XErr	(*BDBAPI_NewCursorSlot)(long api_data, long db_api_data, long *cursorIDP, Ptr *cursorPPtr);
	XErr	(*BDBAPI_GetCursorSlot)(long api_data, long db_api_data, long cursorID, Ptr *cursorPPtr);
	XErr	(*BDBAPI_DisposeCursorSlot)(long api_data, long db_api_data, long cursorID, BDBAPI_CallBack _callBack, long userData, char *error);
	XErr	(*BDBAPI_DisposeAllCursorsSlots)(long api_data, long db_api_data, BDBAPI_CallBack _callBack, long userData, char *error);
	XErr	(*BDBAPI_NewPrepare)(long api_data, long db_api_data, PrepareParams *paramsP, BDBAPI_CallBack _callBack, long userData, char *error);
	XErr	(*BDBAPI_DisposePrepare)(long api_data, long db_api_data, long prepareID, BDBAPI_CallBack _callBack, long userData, char *error);
	XErr	(*BDBAPI_DisposeAllPrepares)(long api_data, long db_api_data, BDBAPI_CallBack _callBack, long userData, char *error);
	XErr	(*BDBAPI_GetPrepareParams)(long api_data, long db_api_data, long prepareID, PrepareParams *paramsP);
	XErr	(*BDBAPI_GetPreparedCursor)(long api_data, long db_api_data, long prepareID, long *cursorIDP, Ptr *cursorPPtr);
	XErr	(*BDBAPI_PrepareLoop)(long api_data, long db_api_data, long prepareID, BDBAPI_CallBack _callBack, long userData, char *error);
	XErr	(*BDBAPI_GetCursorPrepareID)(long api_data, long db_api_data, long cursorID, long *prepareIDP);
	XErr	(*BDBAPI_FlushParamsInputs)(long api_data, long db_api_data, BlockRef *params, long totParams, char *error, Boolean *hasParamsP);
	XErr	(*BDBAPI_DisposeParams)(long api_data, long db_api_data, BlockRef *params, long totParams);
	XErr	(*BDBAPI_LoadParamsOutputs)(long api_data, long db_api_data, BlockRef *params, long totParams, BDBAPI_IsNullCallBack _IsNull, long userData, char *error, Boolean *hasParamsP);
	XErr	(*BDBAPI_NativeCursor)(long api_data, ObjRef *dbObjRefP, char *driver, long *cursorAddrP);
} BDBAPI_Rec;

// Prototypes
XErr	BDBAPI_Register(char *dbmsName, BDBAPI_Dispatch dispatcher, long sizeOfCursor, Boolean multiThreadLimited);
XErr	BDBAPI_ObjToConnBuffer(long api_data, long db_api_data, ObjRef *objRefP, Ptr connBuffP, long *lenP, long maxStorage);
XErr	BDBAPI_Escape(long api_data, long db_api_data, char *stringP, long stringLen, BlockRef *resultBlockP, long *resultLenP);
XErr	BDBAPI_NewCursorSlot(long api_data, long db_api_data, long *cursorIDP, Ptr *cursorPPtr);
XErr	BDBAPI_GetCursorSlot(long api_data, long db_api_data, long cursorID, Ptr *cursorPPtr);
XErr	BDBAPI_DisposeCursorSlot(long api_data, long db_api_data, long cursorID, BDBAPI_CallBack _callBack, long userData, char *error);
XErr	BDBAPI_DisposeAllCursorsSlots(long api_data, long db_api_data, BDBAPI_CallBack _callBack, long userData, char *error);
XErr	BDBAPI_NewPrepare(long api_data, long db_api_data, PrepareParams *paramsP, BDBAPI_CallBack callback, long userData, char *error);
XErr	BDBAPI_DisposePrepare(long api_data, long db_api_data, long prepareID, BDBAPI_CallBack _callBack, long userData, char *error);
XErr	BDBAPI_DisposeAllPrepares(long api_data, long db_api_data, BDBAPI_CallBack _callBack, long userData, char *error);
XErr	BDBAPI_GetPrepareParams(long api_data, long db_api_data, long prepareID, PrepareParams *paramsP);
XErr	BDBAPI_GetPreparedCursor(long api_data, long db_api_data, long prepareID, long *cursorIDP, Ptr *cursorPPtr);
XErr	BDBAPI_PrepareLoop(long api_data, long db_api_data, long prepareID, BDBAPI_CallBack _callBack, long userData, char *error);
XErr	BDBAPI_GetCursorPrepareID(long api_data, long db_api_data, long cursorID, long *prepareIDP);
XErr	BDBAPI_FlushParamsInputs(long api_data, long db_api_data, BlockRef *params, long totParams, char *error, Boolean *hasParamsP);
XErr	BDBAPI_DisposeParams(long api_data, long db_api_data, BlockRef *params, long totParams);
XErr	BDBAPI_LoadParamsOutputs(long api_data, long db_api_data, BlockRef *params, long totParams, BDBAPI_IsNullCallBack _IsNull, long userData, char *error, Boolean *hasParamsP);
XErr	BDBAPI_NativeCursor(long api_data, ObjRef *dbObjRefP, char *driver, long *cursorAddrP);

XErr	BDBAPI_Init(BDBAPI_Rec *theRecP);
typedef	Boolean	(*BDBAPI_Init_CallBack)(BDBAPI_Rec *theRecP);
typedef	Boolean	(*BDBAPI_MapFetch_CallBack)(long cursorAddress, long *polyIDP, double *valueP, Boolean *isNullP);

#endif
