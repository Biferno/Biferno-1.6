/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: MathMethods.c,v 1.8 2003-11-20 10:33:10 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include	<math.h>
#include	<stdio.h>

#ifdef __VISUALCPP__
	#define	round(x)	x
	#define	trunc(x)	x
#endif

enum{
		kPow = 1,
		//kSetFormat,
		kToString,
		kToHexString,
        kAbs,
        kSqr,
        kSqrt,
        kSin,
        kCos,
		k_Int,		// only for double
		kRound		// only for double
	};
#define TOT_METHODES				10
#define TOT_DOUBLE_METHODES			TOT_METHODES
#define TOT_INTEGERS_METHODES		TOT_METHODES-2	// leave Int and Round

enum{
		kPI = 1
	};

static long		mathClassID;
static long		gs_int_id, gs_unsigned_id, gs_double_id, gs_long_id;
enum {
		k_int = 1,
		k_unsigned,
		k_long,
		k_double
	};

void 		NumToHexString(long num, char *strP);
void 		NumLongToHexString(LONGLONG num, char *strP);
//===========================================================================================
static XErr	_ToHexString(Biferno_ParamBlockPtr pbPtr, long which, long item, unsigned long u_item, LONGLONG ll_item, double *r_item)
{
XErr				err = noErr;
CStr255				resStr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;

	switch(which)
	{	case k_int:
			NumToHexString(item, resStr);
			break;
		case k_unsigned:
			NumToHexString(u_item, resStr);
			break;
		case k_long:
			NumLongToHexString(ll_item, resStr);
			break;
		default:
			NumLongToHexString((LONGLONG)*r_item, resStr);
			break;
	}
	err = BAPI_StringToObj(pbPtr->api_data, resStr, CLen(resStr), &exeMethodRecP->resultObjRef);
		
return err;
}

//===========================================================================================
static XErr	_ToString(Biferno_ParamBlockPtr pbPtr, long which, long item, unsigned long u_item, LONGLONG ll_item, double *r_item)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				zapped, resLen, api_data = pbPtr->api_data;
CStr255				resultStr;
Boolean				cutRightZero, wantThousandSep;
long				decimals;
Byte				thousSep, decimSep;
int					i;
char				*tStrP;

	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[0].objRef, &wantThousandSep, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &decimals, kImplicitTypeCast))
			err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &cutRightZero, kImplicitTypeCast);
	}
	if NOT(err)
	{	if (decimals < 0)
			decimals = 0;
		switch(which)
		{	case k_int:
				CNumToString(item, resultStr);
				if (decimals && NOT(cutRightZero))
				{	tStrP = resultStr;
					while (*tStrP)
						tStrP++;
					*tStrP++ = '.';
					for (i = 0; i < decimals; i++)
						*tStrP++ = '0';
					*tStrP = 0;
				}
				break;
			case k_unsigned:
				CNumToString(u_item, resultStr);
				if (decimals && NOT(cutRightZero))
				{	tStrP = resultStr;
					while (*tStrP)
						tStrP++;
					*tStrP++ = '.';
					for (i = 0; i < decimals; i++)
						*tStrP++ = '0';
					*tStrP = 0;
				}
				break;
			case k_long:
				CLongNumToString(ll_item, resultStr);
				if (decimals && NOT(cutRightZero))
				{	tStrP = resultStr;
					while (*tStrP)
						tStrP++;
					*tStrP++ = '.';
					for (i = 0; i < decimals; i++)
						*tStrP++ = '0';
					*tStrP = 0;
				}
				break;
			default:
				CRealToStr(r_item, resultStr, (short)decimals);
				if (cutRightZero && decimals)
					CutRightZeroDec(resultStr, decimals);
				break;
		}
		resLen = CLen(resultStr);
		if (zapped = ZapText((Byte*)resultStr, resLen))
		{	resLen -= zapped;
			resultStr[resLen] = 0;
		}
		if NOT(err = BAPI_GetNumberFormat(api_data, &thousSep, &decimSep))
		{	if (wantThousandSep && thousSep)
			{	CStr255		resultStrOut;
			
				if NOT(decimSep)
					decimSep = '.';
				FormatNumber(resultStr, resultStrOut, decimSep, thousSep);
				err = BAPI_StringToObj(api_data, resultStrOut, CLen(resultStrOut), &exeMethodRecP->resultObjRef);
			}
			else if (decimSep && decimSep)
			{	CSubstitute(resultStr, '.', decimSep);
				err = BAPI_StringToObj(api_data, resultStr, CLen(resultStr), &exeMethodRecP->resultObjRef);
			}
			else
				err = BAPI_StringToObj(api_data, resultStr, CLen(resultStr), &exeMethodRecP->resultObjRef);
		}
	}
		
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Math_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewFunctionsRec		*initRecP = &pbPtr->param.initRec.newFunctionsRec;
XErr				err = noErr;
long				api_data = pbPtr->api_data;
BAPI_MemberRecord	constRec = {"pi", kPI, "double"};
BAPI_MemberRecord	mathMethods[TOT_METHODES] = 
					{	"Pow",			kPow, 			"obj Pow(obj exp)",
						//"SetFormat",	kSetFormat,		"static void SetFormat(char thousSep, char decimSep)",
						"ToString",		kToString, 		"string ToString(boolean wantThousandSep=false, int decimals=2, boolean cutRightZero=true)",
						"Hex",			kToHexString, 	"string Hex(void)",
						"Abs",			kAbs, 			"obj Abs(void)",
						"Sqr",			kSqr, 			"obj Sqr(void)",
						"Sqrt",			kSqrt, 			"obj Sqrt(void)",
						"Sin",			kSin, 			"obj Sin(void)",
						"Cos",			kCos, 			"obj Cos(void)",
						"Int",			k_Int, 			"int Int(void)",
						"Round",		kRound, 		"int Round(void)"
					};


		
	if (err = BAPI_NewMethods(api_data, mathClassID, mathMethods, TOT_INTEGERS_METHODES, "int"))
		return err;
	if (err = BAPI_NewMethods(api_data, mathClassID, mathMethods, TOT_INTEGERS_METHODES, "unsigned"))
		return err;
	if (err = BAPI_NewMethods(api_data, mathClassID, mathMethods, TOT_INTEGERS_METHODES, "long"))
		return err;
	if (err = BAPI_NewMethods(api_data, mathClassID, mathMethods, TOT_DOUBLE_METHODES, "double"))
		return err;
	
	if (err = BAPI_NewConstants(api_data, mathClassID, &constRec, 1, "double"))
		return err;

	gs_int_id = BAPI_ClassIDFromName(api_data, "int", false);
	gs_unsigned_id = BAPI_ClassIDFromName(api_data, "unsigned", false);
	gs_double_id = BAPI_ClassIDFromName(api_data, "double", false);
	gs_long_id = BAPI_ClassIDFromName(api_data, "long", false);
	
return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	Math_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;

	if (getPropertyRec->isConstant)
	{	switch(getPropertyRec->propertyID)
		{
			case kPI:
				err = BAPI_DoubleToObj(pbPtr->api_data, 3.141592653589793238462643383279, &getPropertyRec->resultObjRef);
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchConstant);
				break;
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	Math_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				item;
double				r_item, param;
unsigned long		u_item;
long 				classID, which, api_data = pbPtr->api_data, methodID = exeMethodRecP->methodID;
LONGLONG			ll_item;
ObjRefP				objP;

	//if (methodID != kSetFormat)	
	//{
		classID = BAPI_GetObjClassID(api_data, &exeMethodRecP->objRef);
		if (classID == gs_int_id)
		{	err = BAPI_ObjToInt(api_data, &exeMethodRecP->objRef, &item, kImplicitTypeCast);
			which = k_int;
		}
		else if (classID == gs_unsigned_id)
		{	err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->objRef, &u_item, kImplicitTypeCast);
			which = k_unsigned;
		}
		else if (classID == gs_long_id)
		{	err = BAPI_ObjToLong(api_data, &exeMethodRecP->objRef, &ll_item, kImplicitTypeCast);
			which = k_long;
		}
		else
		{	err = BAPI_ObjToDouble(api_data, &exeMethodRecP->objRef, &r_item, kImplicitTypeCast);
			which = k_double;
		}
	//}
	
	if NOT(err)
	{	switch(methodID)
		{	
			case kPow:
				objP = &exeMethodRecP->paramVarsP[0].objRef;
				if (BAPI_GetObjClassID(api_data, objP) == kStringClassID)
				{	err = XError(kBAPI_Error, Err_IllegalOperation);
					CEquStr(pbPtr->error, "The exponent of Pow is invalid");
				}
				else
					err = BAPI_ObjToDouble(api_data, objP, &param, kImplicitTypeCast);
				if NOT(err)
				{	switch(which)
					{	case k_int:
							err = BAPI_IntToObj(api_data, (long)pow(item, param), &exeMethodRecP->resultObjRef);
							break;
						case k_unsigned:
							err = BAPI_UnsignedToObj(api_data, (unsigned long)pow(u_item, param), &exeMethodRecP->resultObjRef);
							break;
						case k_long:
							err = BAPI_LongToObj(api_data, (LONGLONG)pow((double)ll_item, param), &exeMethodRecP->resultObjRef);
							break;
						case k_double:
							err = BAPI_DoubleToObj(api_data, pow(r_item, param), &exeMethodRecP->resultObjRef);
							break;
					}
				}
				break;
				
			/*case kSetFormat:
				if (exeMethodRecP->totParams == 2)
				{	Byte	decSep[2], thousSep[2];
				
					if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, (Ptr)thousSep, nil, 2, kImplicitTypeCast))
					{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, (Ptr)decSep, nil, 2, kImplicitTypeCast))
						{	err = BAPI_SetNumberFormat(api_data, *thousSep, *decSep);
						
						}
						else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
						{	err = XError(kBAPI_Error, Err_IllegalTypeCast);
							CEquStr(pbPtr->error, "thousandSep must be a char");
						}
					}
					else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
					{	err = XError(kBAPI_Error, Err_IllegalTypeCast);
						CEquStr(pbPtr->error, "decimSep must be a char");
					}
				}
				else
					err = XError(kBAPI_Error, Err_PrototypeMismatch);
				break;
			*/
			case kToString:
				err = _ToString(pbPtr, which, item, u_item, ll_item, &r_item);
				break;

			case kToHexString:
				err = _ToHexString(pbPtr, which, item, u_item, ll_item, &r_item);
				break;
				
			case k_Int:
				switch(which)
				{	case k_int:
						err = BAPI_IntToObj(api_data, trunc(item), &exeMethodRecP->resultObjRef);
						break;
					case k_unsigned:
						err = BAPI_UnsignedToObj(api_data, trunc(u_item), &exeMethodRecP->resultObjRef);
						break;
					case k_long:
						err = BAPI_LongToObj(api_data, trunc(ll_item), &exeMethodRecP->resultObjRef);
						break;
					case k_double:
						err = BAPI_IntToObj(api_data, (long)trunc(r_item), &exeMethodRecP->resultObjRef);
						break;
				}
				break;

			case kRound:
				switch(which)
				{	case k_int:
						err = BAPI_IntToObj(api_data, round(item), &exeMethodRecP->resultObjRef);
						break;
					case k_unsigned:
						err = BAPI_UnsignedToObj(api_data, round(u_item), &exeMethodRecP->resultObjRef);
						break;
					case k_long:
						err = BAPI_LongToObj(api_data, round(ll_item), &exeMethodRecP->resultObjRef);
						break;
					case k_double:
						err = BAPI_IntToObj(api_data, (long)round(r_item), &exeMethodRecP->resultObjRef);
						break;
				}
				break;
			case kAbs:
				switch(which)
				{	case k_int:
						if (item < 0)
							item = -item;
						err = BAPI_IntToObj(api_data, item, &exeMethodRecP->resultObjRef);
						break;
					case k_unsigned:
						err = BAPI_UnsignedToObj(api_data, u_item, &exeMethodRecP->resultObjRef);
						break;
					case k_long:
						if (ll_item < 0)
							ll_item = -ll_item;
						err = BAPI_LongToObj(api_data, ll_item, &exeMethodRecP->resultObjRef);
						break;
					case k_double:
						if (r_item < 0)
							r_item = -r_item;
						err = BAPI_DoubleToObj(api_data, r_item, &exeMethodRecP->resultObjRef);
						break;
				}
				break;
	        case kSqr:
				param = 2;
				switch(which)
				{	case k_int:
						err = BAPI_IntToObj(api_data, (long)pow(item, param), &exeMethodRecP->resultObjRef);
						break;
					case k_unsigned:
						err = BAPI_UnsignedToObj(api_data, (unsigned long)pow(u_item, param), &exeMethodRecP->resultObjRef);
						break;
					case k_long:
						err = BAPI_LongToObj(api_data, (LONGLONG)pow((double)ll_item, param), &exeMethodRecP->resultObjRef);
						break;
					case k_double:
						err = BAPI_DoubleToObj(api_data, pow(r_item, param), &exeMethodRecP->resultObjRef);
						break;
				}
				break;
	        case kSqrt:
				switch(which)
				{	case k_int:
						r_item = item;
						break;
					case k_unsigned:
						r_item = u_item;
						break;
					case k_long:
						r_item = (double)ll_item;
						break;
					case k_double:
						break;
				}
				err = BAPI_DoubleToObj(api_data, sqrt(r_item), &exeMethodRecP->resultObjRef);
				break;
	        case kSin:
				switch(which)
				{	case k_int:
						r_item = item;
						break;
					case k_unsigned:
						r_item = u_item;
						break;
					case k_long:
						r_item = (double)ll_item;
						break;
					case k_double:
						break;
				}
				err = BAPI_DoubleToObj(api_data, sin(r_item), &exeMethodRecP->resultObjRef);
				break;
	        case kCos:
				switch(which)
				{	case k_int:
						r_item = item;
						break;
					case k_unsigned:
						r_item = u_item;
						break;
					case k_long:
						r_item = (double)ll_item;
						break;
					case k_double:
						break;
				}
				err = BAPI_DoubleToObj(api_data, cos(r_item), &exeMethodRecP->resultObjRef);
				break;

			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	Math_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "MathMethods");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(Math Methods for int/unsigned/double)");
			mathClassID = pbPtr->param.registerRec.pluginID;
			// not interested in api_version
			break;
		case kInit:
			err = Math_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			/*{
			long	tLen;
			Byte	tStr[2];
			Boolean	isDef;

				tLen = 2;
				if NOT(err = BAPI_GetConfig(pbPtr->api_data, "DECIMAL_SEP", (char*)tStr, &tLen, &isDef))
				{	*(Byte*)&pbPtr->plugin_run_data = *tStr;
					tLen = 2;
					if NOT(err = BAPI_GetConfig(pbPtr->api_data, "THOUSAND_SEP", (char*)tStr, &tLen, &isDef))
						*(Byte*)((Ptr)&pbPtr->plugin_run_data + 1) = *tStr;
				}
			}*/
			break;
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kDestructor:
		case kExecuteOperation:
			break;
		case kExecuteMethod:
			err = Math_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Math_GetProperty(pbPtr);
			break;
		case kSetProperty:
		//case kModify:
		case kPrimitive:
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


