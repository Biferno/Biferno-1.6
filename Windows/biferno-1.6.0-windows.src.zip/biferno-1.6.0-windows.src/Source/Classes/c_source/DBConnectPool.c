/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: DBConnectPool.c,v 1.4 2003-06-24 12:10:57 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"DBConnectPool.h"

/*#ifdef __MAC_XLIB__
	#include "sqlmac.h"
	#include "sqlext.h"
#elif __WIN_XLIB__
	#include <SQL.h>
	#include <SQLEXT.h>
	#include "oci.h"
#else
	#include "oci.h"
#endif
*/

#if __MWERKS__
#pragma export on
#endif
//===========================================================================================
XErr	ClosePoolConnect(BlockRef poolBlockRef, PoolConnectRec *poolConnectP, CloseConnectCallBack callback)
{
long				totConnect, i;
PoolConnectItem		*itemP;
XErr				err = noErr;

	XThreadsEnterCriticalSection();
	totConnect = poolConnectP->totConnect;
	itemP = poolConnectP->item;
	for (i = 0; i < totConnect; i++, itemP++)
	{	callback(itemP->buffer);
		//if (itemP->serverHP)
		//	_CloseSession(itemP->serverHP, itemP->errorHP, itemP->serverContextHP, itemP->sessionHP);
	}
	DisposeBlock(&poolBlockRef);
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	GetPoolConnect(PoolConnectRec *poolConnectP, Ptr buffer, long storage, char *connString, long *poolConnectIndexP)
{
long				totConnect, i;
PoolConnectItem		*itemP;
XErr				err = noErr;

	//if (storage < SIZE_OF_BUFFER)
	//	CDebugStr("Err: GetPoolConnect storage < SIZE_OF_BUFFER");
	XThreadsEnterCriticalSection();
	totConnect = poolConnectP->totConnect;
	itemP = poolConnectP->item;
	for (i = 0; i < totConnect; i++, itemP++)
	{	if (NOT(itemP->inUse) && NOT(CCompareStrings_cs(connString, itemP->connStr)))
		{	CopyBlock(buffer, itemP->buffer, storage);
			/*bociRecP->serverHP = itemP->serverHP;
			bociRecP->serverContextHP = itemP->serverContextHP;
			bociRecP->sessionHP = itemP->sessionHP;*/
			itemP->inUse = true;
			*poolConnectIndexP = i;
			break;
		}
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	ReleasePoolConnect(PoolConnectRec *poolConnectP, long poolConnectIndex)
{
XErr	err = noErr;

	XThreadsEnterCriticalSection();
	poolConnectP->item[poolConnectIndex].inUse = false;
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	AddPoolConnect(BlockRef poolBlockRef, PoolConnectRec **poolConnectPPtr, Ptr buffer, long sizeofBuffer, char *connString, long *poolConnectIndexP)
{
long				totConnect;
PoolConnectItem		*itemP;
XErr				err = noErr;
PoolConnectRec 		*poolConnectP = *poolConnectPPtr;

	if (sizeofBuffer > SIZE_OF_BUFFER)
		CDebugStr("Err: AddPoolConnect sizeofBuffer > SIZE_OF_BUFFER");
	XThreadsEnterCriticalSection();
	totConnect = poolConnectP->totConnect;
	if NOT(err = SetBlockSize(poolBlockRef, sizeof(PoolConnectRec) + (totConnect * sizeof(PoolConnectItem))))
	{	*poolConnectPPtr = poolConnectP = (PoolConnectRec*)GetPtr(poolBlockRef);
		if (poolConnectIndexP)
			*poolConnectIndexP = totConnect;
		itemP = &poolConnectP->item[totConnect];
		CopyBlock(itemP->buffer, buffer, sizeofBuffer);
		/*itemP->serverHP = serverHP;
		itemP->errorHP = errorHP;
		itemP->serverContextHP = serverContextHP;
		itemP->sessionHP = sessionHP;
		*/
		CEquStr(itemP->connStr, connString);
		itemP->inUse = true;
		poolConnectP->totConnect++;
	}
	XThreadsLeaveCriticalSection();

return err;
}
#if __MWERKS__
#pragma export off
#endif
