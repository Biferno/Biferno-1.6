/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoFunctions.c,v 1.1.1.1 2003-03-25 13:07:40 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"
//#include	"Helpers.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include <stdlib.h>

#if __UNIX_XLIB__ || __MACOSX__
	#if __MACOSX__
		#include <sys/types.h>
		#include <unistd.h>
		#include <stdlib.h>
	#endif
	#include <pwd.h>
	#include <grp.h>
	#include <errno.h>
#endif

// Biferno Functions
enum{
		kWantDestructor = 1,
		kCanHavePersistent,
		kCloneObjects,
		kGetMaxUsers,
		kGetTotVariables,
		kGetIndVariable,
		kConstructorString,
		kDebuggerString,
		kGetPubVariable,
		kPublish,
		kUnpublish,
		kLockObj,
		kUnlockObj,
		kGetInfo,
		kGetDoc,
		//kGetMemberDoc,
		kGetPrototype,
		kGetMembers,
		kPrint,
		kClassAvailable,
		kSystem,
		//kTest,
		kMillisecs,
		kDelay,
		//kFullPath,
		kNoCache,
		kIsCacheActive,
		k_GetErrMessage,
		//kGetErrNum,
		kGetBasePath,
		kGetServerRoot,
		kGetBifernoHome,
		kUpSince,
		kIsDef,
		kIsClassDef,
		kIsFuncDef,
		kIsInitialized,
		kGetApplications,
		kFlushAll,
		kReloadAll,
		kFlushAppFiles,
		kFlushOneCacheFile,
		kReloadApp,
		kGetClasses,
		kGetApplicationFunctions,
		kRegisterApplication,
		kGetApplicationClasses,
		kGetExtendedClass,
		kGetVersion,
		kGetNumVersion,
		kOnErrorResume,
		kValueOf,
		kEval,
		kHide,
		kShow,
		kGetIndSID,
		kSessionVariable,
		kPageWasInCache,
		kPageWillBeCached,
		kCache,
		kJavaEnabled,
		kOnErrorSuspend,
		kOnErrorState,
		kOnErrorFunction,
		kSetTimeout,
		kGetTimeout,
		kGetUser,
		kGetGroup,
		kSetUser,
		kGetCache,
		kSetCustomOutput,
		kSetStandardOutput,
		kGetCurrentOutput,
		kUndef,
		kGetEnv,
		kPutEnv,
		kSetEnv,
		kUnsetEnv,
		kLogString,
		kLaunchProcess,
		kValueOfInput
		
	};
#define TOT_FUNCTIONS	77
// Costants
/*#define TOT_COSTANTS	4
enum{
		kMethodConst = 1,
		kPropertyConst,
		kConstantConst,
		kFunctionConst
	};*/
	
static long	kBifernoFunctionsClassID;
static long	bifernoVersion;

#include <stdio.h>
//===========================================================================================
static XErr	BifernoFunctions_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewFunctionsRec	*initRecP = &pbPtr->param.initRec.newFunctionsRec;
XErr			err = noErr;
BAPI_MemberRecord	bifernoFuncs[TOT_FUNCTIONS] = 
					{	
						"WantDestructor", 			kWantDestructor, 			"boolean WantDestructor(string className)",
						"CanHavePersistent", 		kCanHavePersistent, 		"boolean CanHavePersistent(string className)",
						"CloneObjects", 			kCloneObjects, 				"boolean CloneObjects(string className)",
						"GetMaxUsers", 				kGetMaxUsers, 				"int GetMaxUsers(void)",
						"GetTotVariables", 			kGetTotVariables, 			"int GetTotVariables(string scope=\"local\")",
						"GetIndVariable", 			kGetIndVariable, 			"obj GetIndVariable(int index=1, string *name, boolean sorted=false, string scope=\"local\")",
						"ConstructorString",		kConstructorString,			"string ConstructorString(obj variable)",
						"DebuggerString",			kDebuggerString,			"string DebuggerString(obj variable)",
						"GetPubVariable", 			kGetPubVariable, 			"obj GetPubVariable(string application, string scope, string name)",
						"Publish", 					kPublish, 					"void Publish(obj varToPublish)",
						"UnPublish", 				kUnpublish, 				"void Unpublish(obj varToUnpublish)",
						"LockObj",					kLockObj,					"void LockObj(obj varToLock)",
						"UnlockObj",				kUnlockObj,					"void UnlockObj(obj varToUnlock)",
						"GetPrototype",	 			kGetPrototype, 				"string GetPrototype(string function)",
						"GetInfo",	 				kGetInfo, 					"array GetInfo(string name, string which)",
						"GetDoc",	 				kGetDoc, 					"array GetDoc(string name)",
						//"GetMemberDoc",	 			kGetMemberDoc, 				"array GetMemberDoc(string className, string memberName)",
						"GetMembers", 				kGetMembers, 				"array GetMembers(string which=\"method\", string className, string applicationName)",
						"GetErrMessage", 			k_GetErrMessage, 			"string GetErrMessage(string className, int error)",
						"print", 					kPrint, 					"void print(string str)",
						"ClassAvailable", 			kClassAvailable, 			"boolean ClassAvailable(string className, boolean allTypes)",
						"System", 					kSystem, 					"string System(string *compileFlags)",
						//"Test", 					kTest, 						"string Test(array *aVar)",
						"Millisecs", 				kMillisecs, 				"unsigned Millisecs(void)",
						"Delay", 					kDelay, 					"void Delay(int seconds)",
						"GetBasePath",				kGetBasePath,				"string GetBasePath(void)",
						"GetServerRoot",			kGetServerRoot,				"string GetServerRoot(void)",
						"GetBifernoHome",			kGetBifernoHome,			"string GetBifernoHome(void)",
						"UpSince",					kUpSince,					"string UpSince(void)",
						"NoCache",					kNoCache,					"void NoCache(void)",
						"IsCacheActive",			kIsCacheActive,				"boolean IsCacheActive(void)",
						"IsDef",					kIsDef,						"boolean IsDef(string name)",
						"IsClassDef",				kIsClassDef,				"boolean IsClassDef(string name)",
						"IsFunctionDef",			kIsFuncDef,					"boolean IsFunctionDef(string name)",
						"IsInitialized",			kIsInitialized,				"boolean IsInitialized(obj variable)",
						
						"GetApplications",			kGetApplications,			"array GetApplications(void)",
						
						"Flush",					kFlushAll,					"void Flush(void)",
						"Reload",					kReloadAll,					"void Reload(void)",
						"FlushAppFiles",			kFlushAppFiles,				"void FlushAppFiles(void)",
						"FlushFile",				kFlushOneCacheFile,			"void FlushFile(string filePath)",
						"ReloadApp",				kReloadApp,					"void ReloadApp(void)",
						"GetClasses",				kGetClasses,				"array GetClasses(string applName)",
						"RegisterApplication",		kRegisterApplication,		"void RegisterApplication(string applName, string fullPath)",
						"GetApplicationFunctions",	kGetApplicationFunctions,	"string GetApplicationFunctions(string applName)",
						"GetApplicationClasses",	kGetApplicationClasses,		"array GetApplicationClasses(string applName)",
						"GetExtendedClass",			kGetExtendedClass,			"string GetExtendedClass(string className)",
						
						"GetVersion",				kGetVersion,				"string GetVersion(void)",
						"GetNumVersion",			kGetNumVersion,				"unsigned GetVersion(void)",
						"OnErrorResume",			kOnErrorResume,				"void OnErrorResume(string funcName=\"\")",
						"ValueOf",					kValueOf,					"obj ValueOf(string line)",
						"Eval",						kEval,						"string Eval(string text, boolean resume)",
						"Hide",						kHide,						"void Hide(obj varToHide)",
						"Show",						kShow,						"void Show(obj varToShow)",
						"GetIndSID",				kGetIndSID,					"string GetIndSID(int index)",
						"SessionVariable",			kSessionVariable,			"string SessionVariable(string SID, string name)",
						
						"PageWasInCache",			kPageWasInCache,			"boolean PageWasInCache()",
						"PageWillBeCached",			kPageWillBeCached,			"boolean PageWillBeCached()",
						"Cache",					kCache,						"void Cache(void)",
						"JavaEnabled",				kJavaEnabled,				"boolean JavaEnabled(void)",
						"OnErrorSuspend",			kOnErrorSuspend,			"void OnErrorSuspend(void)",
						"OnErrorState",				kOnErrorState,				"boolean OnErrorState(void)",
						"OnErrorFunction",			kOnErrorFunction,			"string OnErrorFunction(void)",

						"SetTimeout",				kSetTimeout,				"void SetTimeout(unsigned minutes)",
						"GetTimeout",				kGetTimeout,				"unsigned GetTimeout(void)",

						"getUser",					kGetUser,					"string getUser(void)",
						"getGroup",					kGetGroup,					"string getGroup(void)",
						"setUser",					kSetUser,					"int setUser(string newUser)",
						
						"GetAppCache",				kGetCache,					"array GetAppCache(int *totalBytes)",
						
						"SetCustomOutput",			kSetCustomOutput,			"void SetCustomOutput(string outputFunction)",
						"SetStandardOutput",		kSetStandardOutput,			"void SetStandardOutput(void)",
						"GetCurrentOutput",			kGetCurrentOutput,			"string GetCurrentOutput(void)",
						"Undef",					kUndef,						"void Undef(obj variable)",

						"getenv",					kGetEnv,					"string getenv(string varName)",
						"putenv",					kPutEnv,					"void putenv(string str)",
						"setenv",					kSetEnv,					"void setenv(string name, string value, boolean rewrite)",
						"unsetenv",					kUnsetEnv,					"void unsetenv(string name)",
						
						"LogString",				kLogString,					"void LogString(string log)",
						
						"LaunchProcess",			kLaunchProcess,				"boolean LaunchProcess(string executablePath, string commandLineString, boolean waitEnd, unsigned timeout_ms)",
						"ValueOfInput", 			kValueOfInput,				"string ValueOfInput(obj var)"						
					};
	
	if (err = BAPI_NewFunctions(pbPtr->api_data, kBifernoFunctionsClassID, bifernoFuncs, TOT_FUNCTIONS))
		return err;

return err;
}

#pragma mark-
//===========================================================================================
static XErr	_getUser(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
#if __UNIX_XLIB__ || __MACOSX__
struct passwd	*pwp;

	if (pwp = getpwuid(getuid()))
		err = BAPI_StringToObj(api_data, pwp->pw_name, CLen(pwp->pw_name), &exeMethodRecP->resultObjRef);
		
#else
	err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
#endif

return err;
}

//===========================================================================================
static XErr	_getGroup(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
#if __UNIX_XLIB__ || __MACOSX__
struct group	*grp;

	if (grp = getgrgid(getgid()))
		err = BAPI_StringToObj(api_data, grp->gr_name, CLen(grp->gr_name), &exeMethodRecP->resultObjRef);
		
#else
	err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
#endif

return err;
}

//===========================================================================================
static XErr	_setUser(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;

#if __UNIX_XLIB__ || __MACOSX__
struct 	passwd	*ent;
CStr63	newUser;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, newUser, nil, 63, kImplicitTypeCast))
		{	errno = 0;
			TRACE("getpwnam")
			if (ent = getpwnam(newUser))
			{	errno = 0;
				TRACE("setgid")
				if (setgid(ent->pw_gid) == -1)
					err = errno;
				else
				{	errno = noErr;
					TRACE("setuid")
					if (setuid(ent->pw_uid) == -1)
						err = errno;	
				}
			}
			else
				err = errno;
		}
		err = BAPI_IntToObj(api_data, err, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
#else
	#pragma unused(exeMethodRecP, totParams, api_data)
#endif

return err;
}

//===========================================================================================
static XErr	_getEnv(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
char		*strP;
CStr255		varName;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, varName, nil, 255, kImplicitTypeCast))
	{	if (strP = getenv(varName))
			err = BAPI_StringToObj(api_data, strP, CLen(strP), &exeMethodRecP->resultObjRef);
		else
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_PutEnv(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
#if __UNIX_XLIB__
CStr255			aCStr;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, aCStr, nil, 255, kImplicitTypeCast))
	{	errno = 0;
		if (putenv(aCStr))
			err = errno;
	}
#endif
	
return err;
}

//===========================================================================================
static XErr	_SetEnv(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
#if __UNIX_XLIB__
CStr255			name, value;
Boolean			rewrite;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, name, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &paramsP[1].objRef, value, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &paramsP[2].objRef, &rewrite, kImplicitTypeCast))
			{	errno = 0;
				if (setenv(name, value, rewrite))
					err = errno;
			}
		}
	}
#endif
	
return err;
}

//===========================================================================================
static XErr	_UnsetEnv(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
#if __UNIX_XLIB__
CStr255			name;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP[0].objRef, name, nil, 255, kImplicitTypeCast))
		unsetenv(name);
#endif
	
return err;
}

//===========================================================================================
static XErr	_LogString(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *execMethodRecP)
{
XErr			err = noErr;
long			api_data = pbPtr->api_data;
ParameterRec 	*paramsP = execMethodRecP->paramVarsP;
CStr255			logStr;

	if NOT(err = BAPI_ObjToString(api_data, &paramsP->objRef, logStr, nil, 255, kImplicitTypeCast))
		err = BAPI_Log(api_data, logStr);
		
return err;
}

#pragma mark-
//===========================================================================================
static XErr	_GetClInfo(ExecuteMethodRec *exeMethodRecP, long api_data, long which)
{
BAPI_ClassInfo	classInfo;
XErr			err = noErr;
CStr63			className;
Boolean			res;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, className, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_GetClassInfo(api_data, BAPI_ClassIDFromName(api_data, className, false), &classInfo))
		{	switch(which)
			{	case kWantDestructor:
					res = classInfo.wantDestructor;
					break;
				case kCanHavePersistent:
					res = classInfo.canHavePersistent;
					break;
				case kCloneObjects:
					res = classInfo.cloneObjects;
					break;
				default:
					err = XError(kBAPI_Error, Err_BadSyntax);
					break;
			}
			if NOT(err)
				err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetMaxUsers(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
long		maxUsers;

	if NOT(err = BAPI_GetMaxUsers(api_data, &maxUsers))
		err = BAPI_IntToObj(api_data, maxUsers, &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_GetTotVariables(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
long		totVars, scope;
CStr63		cStr;

	if ((totParams == 0) || (totParams == 1))
	{	if ((totParams != 1) || NOT(BAPI_IsObjRefValid(api_data, &exeMethodRecP->paramVarsP[0].objRef)/*exeMethodRecP->paramVarsP[0].objRef.id*/))
			scope = LOCAL;
		else
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, cStr, nil, 63, kImplicitTypeCast))
				err = BAPI_ScopeID(api_data, cStr, &scope);
		}
		if NOT(err)
		{	if NOT(err = BAPI_GetTotVariables(api_data, &totVars, scope))
				err = BAPI_IntToObj(api_data, totVars, &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetIndVariable(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
long		index, scope;
CStr63		cStr;
Boolean		sorted;

	if ((totParams >= 1) && (totParams <= 4))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kImplicitTypeCast))
		{	if (totParams >= 3)
			{	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->paramVarsP[2].objRef))
					err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &sorted, kImplicitTypeCast);
				else
					sorted = false;
			}
			else
				sorted = false;
			if NOT(err)
			{	if (totParams == 4)
				{	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->paramVarsP[3].objRef))
					{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[3].objRef, cStr, nil, 63, kImplicitTypeCast))
							err = BAPI_ScopeID(api_data, cStr, &scope);
					}
					else
						scope = LOCAL;
				}
				else
					scope = LOCAL;
				if NOT(err)
				{	if NOT(err = BAPI_GetIndVariable(api_data, index, scope, sorted, cStr, &exeMethodRecP->resultObjRef))
					{	if (totParams > 1)
						{	ObjRefP		tObjP = &exeMethodRecP->paramVarsP[1].objRef;
						
							//BAPI_InvalObjRef(api_data, tObjP);
							err = BAPI_StringToObj(api_data, cStr, CLen(cStr), tObjP);
						}
					}
				}
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_ConstructorString(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
long		strLen;
Ptr			stringP;
BlockRef	ref;

	if NOT(err = BAPI_GetStringBlockExt(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &strLen, &ref, kExplicitTypeCast, kForConstructor))
	{	err = BAPI_StringToObj(api_data, stringP, strLen, &exeMethodRecP->resultObjRef);		
		BAPI_ReleaseStringBlock(&ref);
	}
	
return err;
}

//===========================================================================================
static XErr	_DebuggerString(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
long		strLen;
Ptr			stringP;
BlockRef	ref;

	if NOT(err = BAPI_GetStringBlockExt(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &strLen, &ref, kExplicitTypeCast, kForDebug))
	{	err = BAPI_StringToObj(api_data, stringP, strLen, &exeMethodRecP->resultObjRef);		
		BAPI_ReleaseStringBlock(&ref);
	}
	
return err;
}

//===========================================================================================
static XErr	_GetPubVariable(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
long		scopeID;
CStr255		applName;
CStr63		theName, theScope;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applName, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, theScope, nil, 63, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, theName, nil, 63, kImplicitTypeCast))
			{	if NOT(err = BAPI_ScopeID(api_data, theScope, &scopeID))
					err = BAPI_GetPublishedVar(api_data, applName, scopeID, theName, &exeMethodRecP->resultObjRef);
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetDoc(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr			err = noErr;
CStr63			cStr;

	if ((totParams == 1) || (totParams == 2))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, cStr, nil, 63, kImplicitTypeCast))
			err = BAPI_GetDocumentation(api_data, cStr, &exeMethodRecP->resultObjRef);
	
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
/*static XErr	_GetMembDoc(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
BlockRef		docBlockRef;
BAPI_Doc 		*docBlockP;
CStr63			className, memberName;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, className, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, memberName, nil, 63, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetDoc(api_data, "folder", "Walk", &docBlockRef))
			{	docBlockP = (BAPI_Doc*)GetPtr(docBlockRef);
				BAPI_ReleaseDoc(api_data, &docBlockRef);
			}
		}
	}
	
return err;
}
*/
//===========================================================================================
static XErr	_GetInfo(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long api_data)
{
#pragma unused(pbPtr)
XErr		err = noErr;
	
	return XError(kBAPI_Error, Err_NotImplemented);
/*
CStr63		cStr;
CStr255		whichStr;
long		which;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, cStr, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, whichStr, nil, 255, kImplicitTypeCast))
		{	if NOT(CCompareStrings_cs(whichStr, "method"))
				which = kMethod;
			else if NOT(CCompareStrings_cs(whichStr, "property"))
				which = kProperty;
			else if NOT(CCompareStrings_cs(whichStr, "constant"))
				which = kProperty;
			else if NOT(CCompareStrings_cs(whichStr, "error"))
				which = kProperty;
			else if NOT(CCompareStrings_cs(whichStr, "function"))
				which = kFunction;
			else
				which = 0;
			if NOT(err)
				err = BAPI_GetInfo(api_data, cStr, which, &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
*/

return err;
}

//===========================================================================================
static XErr	_GetPrototype(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;

	return XError(kBAPI_Error, Err_NotImplemented);
/*	
CStr255		prototype;
CStr63		cStr;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, cStr, nil, 63, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetPrototype(api_data, cStr, prototype, 255))
				err = BAPI_StringToObj(api_data, prototype, CLen(prototype), &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
*/
return err;
}

//===========================================================================================
/*static XErr	_RegisterApplication(ExecuteMethodRec *exeMethodRecP, long api_data)
{
CStr63		applName, applPath;
XErr		err = noErr;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applName, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, applPath, nil, 63, kImplicitTypeCast))
			err = BAPI_RegisterApplication(api_data, applName, applPath);
	}
	
return err;
}
*/
//===========================================================================================
static XErr	_GetApplications(ExecuteMethodRec *exeMethodRecP, long api_data)
{
	return BAPI_GetApplication(api_data, &exeMethodRecP->resultObjRef, 0);
}

//===========================================================================================
static XErr	_Flush(long api_data)
{
XErr		err = noErr;

	err = BAPI_Flush(api_data);
	
return err;
}

//===========================================================================================
static XErr	_Reload(long api_data)
{
XErr		err = noErr;

	err = BAPI_Reload(api_data);
	
return err;
}


//===========================================================================================
static XErr	_FlushAppFiles(long api_data)
{
XErr		err = noErr;

	err = BAPI_FlushAppFiles(api_data);
	
return err;
}

//===========================================================================================
static XErr	_FlushOneCacheFile(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
XFilePath	filePath;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
		err = BAPI_FlushFile(api_data, filePath);

return err;
}

//===========================================================================================
static XErr	_ReloadApp(long api_data)
{
XErr		err = noErr;

	err = BAPI_ReloadApp(api_data);
	
return err;
}

//===========================================================================================
static XErr	_GetApplicationFunctions(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr63		applName;

	if (NOT(totParams) || (totParams == 1))
	{	BlockRef	blockRef;
		long		len;
	
		if (totParams == 1)
			err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applName, nil, 63, kImplicitTypeCast);
		else
			*applName = 0;
		if NOT(err)
		{	if NOT(err = BAPI_GetApplicationFunctions(api_data, &blockRef, &len, ", <br>", applName))
			{	LockBlock(blockRef);
				err = BAPI_StringToObj(api_data, GetPtr(blockRef), len, &exeMethodRecP->resultObjRef);
				DisposeBlock(&blockRef);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetClasses(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		applName;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applName, nil, 255, kImplicitTypeCast))
		return BAPI_GetClasses(api_data, applName, &exeMethodRecP->resultObjRef);
	/*
	if NOT(totParams)
	{	BlockRef	blockRef;
		long		len;
	
		if NOT(err = BAPI_GetClasses(api_data, &blockRef, &len, ", <br>", nil))
		{	LockBlock(blockRef);
			err = BAPI_StringToObj(api_data, GetPtr(blockRef), len, &exeMethodRecP->resultObjRef);
			DisposeBlock(&blockRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
	*/

return err;
}

//===========================================================================================
static XErr	_GetExtendedClass(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		className;
long		extendedClassID;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, className, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ExtendedClass(api_data, BAPI_ClassIDFromName(api_data, className, false), &extendedClassID))
		{	if (extendedClassID)
			{	if NOT(err = BAPI_NameFromClassID(api_data, extendedClassID, className))
					err = BAPI_StringToObj(api_data, className, CLen(className), &exeMethodRecP->resultObjRef);
			}
			else
				err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
		}
	}

return err;
}

//===========================================================================================
static XErr	_RegisterApplication(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		applicationName;
CStr255		applicationPath;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applicationName, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, applicationPath, nil, 255, kImplicitTypeCast))
			err = BAPI_RegisterApplication(api_data, applicationName, applicationPath);
	}
	
return err;
}

//===========================================================================================
static XErr	_GetApplicationClasses(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		applName;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, applName, nil, 63, kImplicitTypeCast))
		return BAPI_GetClasses(api_data, applName, &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_GetMembers(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		aCStr;
CStr255		applName, whichStr;
char		*stringP;
long		which;
long		variant = 0;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, whichStr, nil, 255, kImplicitTypeCast))
	{	if NOT(CCompareStrings_cs(whichStr, "method"))
			which = kMethod;
		else if NOT(CCompareStrings_cs(whichStr, "property"))
			which = kProperty;
		else if NOT(CCompareStrings_cs(whichStr, "constant"))
		{	which = kProperty;
			variant = kOnlyConstants;
		}
		else if NOT(CCompareStrings_cs(whichStr, "error"))
		{	which = kProperty;
			variant = kOnlyErrors;
		}
		else if NOT(CCompareStrings_cs(whichStr, "function"))
			which = kFunction;
		else
		{	err = XError(kBAPI_Error, Err_BadSyntax);
			CEquStr(pbPtr->error, "GetMembers: bad member type");
		}
		if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr, nil, 63, kImplicitTypeCast))
		{	if (*aCStr)
				stringP = aCStr;
			else
				stringP = nil;
			if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[2].objRef, applName, nil, 255, kImplicitTypeCast))
				err = BAPI_GetMembers(api_data, stringP, which, variant, applName, &exeMethodRecP->resultObjRef);
		}
	}

return err;
}

//===========================================================================================
/*static XErr	_GetErrNum(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		errName, errClass;
long		errNum;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, errName, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, errClass, nil, 63, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetErrNum(api_data, errName, errClass, &errNum))
				err = BAPI_IntToObj(api_data, errNum, &exeMethodRecP->resultObjRef);
		}
	}

return err;
}*/

//===========================================================================================
static XErr	_GetErrMessage(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		errMessage;
long		classID, theError;
CStr63		className;

	if (totParams == 2)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, className, nil, 63, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &theError, kImplicitTypeCast))
			{	if (classID = BAPI_ClassIDFromName(api_data, className, false))
				{	if NOT(err = BAPI_GetErrMessage(api_data, classID, theError, nil, errMessage, nil))
					{	err = BAPI_StringToObj(api_data, errMessage, CLen(errMessage), &exeMethodRecP->resultObjRef);
					}
				}
				else
					err = XError(kBAPI_Error, Err_NoSuchClass);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Print(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
BlockRef	ref;
char		*stringP;
long		stringLen;

	if (totParams == 1)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
		{	err = BAPI_StandardOutput(api_data, stringP, stringLen, true);
			BAPI_ReleaseStringBlock(&ref);
		}
		BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_ClassAvailable(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
Boolean		res;
CStr255		aCStr;
Boolean		allTypes;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, nil, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &allTypes, kImplicitTypeCast))
		{	if (BAPI_ClassIDFromName(api_data, aCStr, allTypes))
				res = true;
			else
				res = false;
			err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);
		}
	}

return err;
}

//===========================================================================================
static XErr	_System(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
char		compileFlagsStr[1024];

	if (NOT(totParams) || (totParams == 1))
	{	if NOT(err = BAPI_Platform(0, aCStr, compileFlagsStr, 1024))
		{	if NOT(err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &exeMethodRecP->resultObjRef))
			{	if (totParams == 1)
				{	ObjRefP	tObjP = &exeMethodRecP->paramVarsP[0].objRef;
					//BAPI_InvalObjRef(api_data, tObjP);
					err = BAPI_StringToObj(api_data, compileFlagsStr, CLen(compileFlagsStr), tObjP);
				}
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
/*static XErr	_Test(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr			err = noErr;
ObjRefP			tObjP = &exeMethodRecP->paramVarsP[0].objRef;
//ObjRef			tObjref;
ParameterRec	varRec;
//CStr255			aCStr;

	BAPI_ClearParameterRec(api_data, &varRec);
	//err = BAPI_StringToObj(api_data, "index.bfr copia", CLen("index.bfr copia"), &varRec.objRef);
	//err = BAPI_Constructor(api_data, BAPI_ClassIDFromName(api_data, "file", true), &varRec, 1, tObjP);
	
	err = BAPI_GetInfo(api_data, "db.Exec", kMethod, tObjP);
	
/*	BAPI_ClearParameterRec(api_data, &varRec);
	//BAPI_InvalObjRef(api_data, &tObjref);
	//err = BAPI_StringToObj(api_data, "pippo", CLen("pippo"), &tObjref);

	// err = BAPI_StringToObj(api_data, "valeriovaleriovaleriovalerio", CLen("valeriovaleriovaleriovalerio"), &tObjref);
	
	
	CEquStr(aCStr, "myNewVar");
	varRec.objRef = *tObjP;
	varRec.expP = (Ptr)aCStr;
	varRec.expLen = CLen(aCStr);
	
	//varRec = *exeMethodRecP->paramVarsP;
	err = BAPI_ExecuteFunction(api_data, &varRec, 1, "System", &tObjref);

	//err = BAPI_Eval(api_data, "pippo = 20", CLen("pippo = 20"), nil, false);
	
	// err = BAPI_ArrayToObj(api_data, false, 0, nil, 0, nil, tObjP);
	//err = BAPI_InvalObjRef(api_data, &tObjref);
	//err = BAPI_StringToObj(api_data, "pippo", 5, &tObjref);
	//err = BAPI_TypeCast(api_data, &tObjref, BAPI_ClassIDFromName(api_data, "multipart", true), tObjP, kExplicitTypeCast);
	//err = BAPI_StringToObj(api_data, "PIPPO", 5, tObjP);
	//err = BAPI_IntToObj(api_data, 3, tObjP);

return err;
}*/

//===========================================================================================
static XErr	_Millisecs(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr			err = noErr;
unsigned long	m_secs;

	if NOT(totParams)
	{	XGetMilliseconds(&m_secs);
		err = BAPI_UnsignedToObj(api_data, m_secs, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	__Delay(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr			err = noErr;
unsigned long	secs;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->paramVarsP[0].objRef, &secs, kImplicitTypeCast))
			XDelay(secs * 60);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
/*static XErr	_FullPath(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		cStr;
long		len;
char		currentBasePath[512];

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, cStr, &len, 255, kImplicitTypeCast))
		{	cStr[len] = 0;
			if (len && ((*cStr == '/') || (*cStr == ':')))
				CEquStr(currentBasePath, cStr);
			else
			{	if NOT(err = BAPI_GetCurrentBasePath(api_data, currentBasePath, false))
					CAddStr(currentBasePath, cStr);
			}
			if NOT(err)
				err = BAPI_StringToObj(api_data, currentBasePath, CLen(currentBasePath), &exeMethodRecP->resultObjRef);
		}
	
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}
*/
//===========================================================================================
static XErr	_GetBasePath(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
char		currentBasePath[512];
CStr255		tempStr;

	if (totParams == 0)
	{	if NOT(err = BAPI_GetCurrentBasePath(api_data, currentBasePath, false))
		{	CEquStr(tempStr, FILE_HD_PREFIX);
			CAddStr(tempStr, currentBasePath);
			err = BAPI_StringToObj(api_data, tempStr, CLen(tempStr), &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetServerRoot(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
char		serverRoot[512];
CStr255		tempStr;
int			tempStrLen;

	if (totParams == 0)
	{	if NOT(err = BAPI_GetCurrentBasePath(api_data, serverRoot, true))
		{	if (*serverRoot)
			{	CEquStr(tempStr, FILE_HD_PREFIX);
				CAddStr(tempStr, serverRoot);
				tempStrLen = CLen(tempStr);
			}
			else
				tempStrLen = 0;
			err = BAPI_StringToObj(api_data, tempStr, tempStrLen, &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetBifernoHome(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
char		bifernoHome[512];
CStr255		tempStr;

	if (totParams == 0)
	{	if NOT(err = XGetApplicationFolderPath(bifernoHome))
		{	CEquStr(tempStr, FILE_HD_PREFIX);
			CAddStr(tempStr, bifernoHome);
			err = BAPI_StringToObj(api_data, tempStr, CLen(tempStr), &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_UpSince(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;

	err = BAPI_GetHTTPParam(api_data, BAPI_UpSinceDate, &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_Cache(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data, Boolean state)
{
#pragma unused(exeMethodRecP)
XErr		err = noErr;

	if NOT(totParams)
		err = BAPI_SetFileCacheState(api_data, state);
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_IsCacheActive(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#pragma unused(exeMethodRecP)
XErr		err = noErr;

	if NOT(totParams)
		err = BAPI_BooleanToObj(api_data, BAPI_IsCacheActive(api_data), &exeMethodRecP->resultObjRef);
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_IsDef(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr	err = noErr;
CStr63	name;
long	len;
Boolean	exists;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, &len, 63, kImplicitTypeCast))
		{	if (len)
			{	name[len] = 0;
				if NOT(err = BAPI_IsVariableDefined(api_data, name, 0, &exists, nil))
					err = BAPI_BooleanToObj(api_data, exists, &exeMethodRecP->resultObjRef);
			}
			else
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_IsClassFuncDef(ExecuteMethodRec *exeMethodRecP, Boolean isFunc, long api_data)
{
XErr		err = noErr;
CStr63		name;
Boolean		isDef;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, name, nil, 63, kImplicitTypeCast))
	{	if (isFunc)
			err = BAPI_IsFuncDef(api_data, name, &isDef);
		else
			err = BAPI_IsClassDef(api_data, name, &isDef);
		if NOT(err)	
			err = BAPI_BooleanToObj(api_data, isDef, &exeMethodRecP->resultObjRef);
	
	}
return err;
}

//===========================================================================================
static XErr	_IsInitialized(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
Boolean		isInitialized;

	if NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[0].objRef, &isInitialized))
		err = BAPI_BooleanToObj(api_data, isInitialized, &exeMethodRecP->resultObjRef);
		
return err;
}

//===========================================================================================
static XErr	_GetVersion(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr	err = noErr;
CStr255	versStr;

	if NOT(err = BAPI_GetVersions(0, versStr, nil, nil))
		err = BAPI_StringToObj(api_data, versStr, CLen(versStr), &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_GetNumVersion(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
unsigned long	vers;

	if NOT(err = BAPI_GetNumVersions(0, &vers, nil, nil))
		err = BAPI_UnsignedToObj(api_data, vers, &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_OnErrorResume(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#pragma unused(exeMethodRecP)
XErr		err = noErr;
CStr255		funcName;
char		*strP;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, funcName, nil, 255, kImplicitTypeCast))
			strP = funcName;
	}
	else if NOT(totParams)
		strP = nil;
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

	if NOT(err)	
		err = BAPI_OnError(api_data, kResume, strP, nil);

return err;
}

//===========================================================================================
static XErr	_OnErrorSuspend(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#pragma unused(exeMethodRecP)
XErr		err = noErr;

	if NOT(totParams)
		err = BAPI_OnError(api_data, kSuspend, nil, nil);

return err;
}

//===========================================================================================
static XErr	_OnErrorState(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#pragma unused(exeMethodRecP)
XErr		err = noErr;
Boolean		state;

	if NOT(totParams)
	{	if NOT(err = BAPI_OnError(api_data, kGetState, nil, &state))
			err = BAPI_BooleanToObj(api_data, state, &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_OnErrorFunction(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#pragma unused(exeMethodRecP)
XErr		err = noErr;
CStr255		functionName;

	if NOT(totParams)
	{	if NOT(err = BAPI_OnError(api_data, kGetFunction, functionName, nil))
			err = BAPI_StringToObj(api_data, functionName, CLen(functionName), &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
/*static XErr	_Free(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#pragma unused(exeMethodRecP)
XErr		err = noErr;

	if (totParams == 1)
		err = BAPI_FreeObj(api_data, &exeMethodRecP->paramVarsP[0]);
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}*/

//===========================================================================================
static XErr	_ValueOf(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
char		*valuOfStr;
CStr255		aCStr;
long		valuOfLen;
BlockRef	ref;

	if (totParams == 1)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &valuOfStr, &valuOfLen, &ref, kImplicitTypeCast))
		{	if (valuOfLen)
			{	err = BAPI_Eval(api_data, valuOfStr, valuOfLen, &exeMethodRecP->resultObjRef, true);
				if (err == XError(kBAPI_Error, Err_UndefinedIdentifier))
					err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
			}
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
			BAPI_ReleaseStringBlock(&ref);
		}	
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Publish(ExecuteMethodRec *exeMethodRecP, long api_data, Boolean toPublish)
{
	return BAPI_Publish(api_data, toPublish, &exeMethodRecP->paramVarsP[0].objRef);
}

//===========================================================================================
static XErr	_LockObject(ExecuteMethodRec *exeMethodRecP, long api_data, Boolean toLock)
{
XErr		err = noErr;

	if (toLock)
		err = BAPI_LockObj(api_data, &exeMethodRecP->paramVarsP[0].objRef);
	else
		err = BAPI_UnlockObj(api_data, &exeMethodRecP->paramVarsP[0].objRef);

return err;
}

//===========================================================================================
static XErr	_Hide(ExecuteMethodRec *exeMethodRecP, Boolean toHide, long api_data)
{
	return BAPI_Hide(api_data, toHide, &exeMethodRecP->paramVarsP[0].objRef);
}

//===========================================================================================
static XErr	_Eval(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
BlockRef	ref;
char		*stringP;
long		stringLen;
Boolean		resume;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &resume, kExplicitTypeCast))
		{	if (stringLen)
				err = BAPI_Eval(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef, false);
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
			if (err && resume)
			{	if NOT(err = BAPI_GetErrDescription(api_data, err, aCStr, nil, nil, nil, nil, 0))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &exeMethodRecP->resultObjRef);
			}
		}
		BAPI_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	_GetIndSID(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
long		index;
CStr255		sidStr;

	if (NOT(totParams) || (totParams == 1))
	{	if (totParams == 1)
			err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kExplicitTypeCast);
		else
			index = 0;	
		if NOT(err)
		{	if NOT(err = BAPI_GetIndSID(api_data, index, sidStr))
				err = BAPI_StringToObj(api_data, sidStr, CLen(sidStr), &exeMethodRecP->resultObjRef);
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_SessionVariable(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data, char *error)
{
XErr		err = noErr;
long		resultLen;
CStr255		sidStr, varName, result;

	if (totParams == 2)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, sidStr, nil, 255, kExplicitTypeCast))
		{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, varName, nil, 255, kExplicitTypeCast))
			{	err = BAPI_SessionVariableToString(api_data, sidStr, varName, result, &resultLen, 255);
				if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
					CEquStr(error, "SessionVariable cant return more than 255 chars strings");
				else if NOT(err)
					err = BAPI_StringToObj(api_data, result, resultLen, &exeMethodRecP->resultObjRef);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_PageWasInCache(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
Boolean		wasInCache;

	if NOT(totParams)
	{	if NOT(err = BAPI_GetCurrentFilePath(api_data, nil, nil, &wasInCache, nil))
			err = BAPI_BooleanToObj(api_data, wasInCache, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_PageWillBeCached(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
Boolean		willBeCached;

	if NOT(totParams)
	{	if NOT(err = BAPI_GetCurrentFilePath(api_data, nil, nil, nil, &willBeCached))
			err = BAPI_BooleanToObj(api_data, willBeCached, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_JavaEnabled(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
long		envP;
Boolean		res;

	if NOT(totParams)
	{	err = BAPI_JavaGetCurrentJNIEnv(api_data, &envP);
		if (err == XError(kBAPI_Error, Err_JavaFrameworkNotAvailable))
			res = false;
		else
			res = true;
		err = BAPI_BooleanToObj(api_data, res, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetTimeout(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
unsigned long	timeout;

	if NOT(err = BAPI_GetTimeout(api_data, &timeout))
		err = BAPI_UnsignedToObj(api_data, timeout, &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_SetTimeout(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
unsigned long	minutes;

	if NOT(err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->paramVarsP[0].objRef, &minutes, kImplicitTypeCast))
		err = BAPI_SetTimeout(api_data, minutes * 3600);	// Minutes to ticks

return err;
}

//===========================================================================================
static XErr	_GetCache(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
unsigned long	totalBytesInCache;

	if NOT(err = BAPI_GetCache(api_data, &exeMethodRecP->resultObjRef, &totalBytesInCache))
	{	if (exeMethodRecP->totParams)
		err = BAPI_IntToObj(api_data, totalBytesInCache, &exeMethodRecP->paramVarsP[0].objRef);
	}

return err;
}

//===========================================================================================
static XErr	_SetCustomOutput(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		funcName;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, funcName, nil, 63, kImplicitTypeCast))
		err = BAPI_SetCustomOutput(api_data, funcName);

return err;
}

//===========================================================================================
static XErr	_SetStandardOutput(long api_data)
{
	return BAPI_SetStandardOutput(api_data);
}

//===========================================================================================
static XErr	_GetCurrentOutput(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		funcName;

	if NOT(err = BAPI_GetOutputFunction(api_data, funcName))
		err = BAPI_StringToObj(api_data, funcName, CLen(funcName), &exeMethodRecP->resultObjRef);

return err;
}

//===========================================================================================
static XErr	_Undef(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;

	err = BAPI_Undef(api_data, &exeMethodRecP->paramVarsP[0].objRef);

return err;
}

//===========================================================================================
static XErr	_LaunchProcess(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
CStr255			executablePath;
char			commandLineString[512];
Boolean 		waitEnd;
unsigned long	timeout_ms;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, executablePath, nil, 255, kImplicitTypeCast))
	{	
	#ifndef __UNIX_XLIB__
		if NOT(err = BAPI_RealPath(api_data, executablePath, true))	
	#endif	
		{	commandLineString[0] = ' ';
			if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, &commandLineString[1], nil, 511, kImplicitTypeCast))
			{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[2].objRef, &waitEnd, kImplicitTypeCast))
				{	if NOT(err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->paramVarsP[3].objRef, &timeout_ms, kImplicitTypeCast))
					{	err = XLaunchProcess(executablePath, commandLineString, waitEnd, timeout_ms);
						if (err == XError(kXLibError, ErrXThreads_Timeout))
							err = BAPI_BooleanToObj(api_data, true, &exeMethodRecP->resultObjRef);
						else if NOT(err)
							err = BAPI_BooleanToObj(api_data, false, &exeMethodRecP->resultObjRef);
					}
				}
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_ValueOfInput(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
long			textLen;
Ptr				textP;
BlockRef		ref, encodedStringBlock;
CStr255			aCStr;

	if NOT(err = BAPI_GetStringBlockExt(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &textP, &textLen, &ref, kExplicitTypeCast, kForConstructor))
	{	if NOT(err = BAPI_EncodeURL(api_data, (Byte*)textP, textLen, &encodedStringBlock, &textLen, false, nil))
		{	LockBlock(encodedStringBlock);
			textP = GetPtr(encodedStringBlock);
			err = BAPI_StringToObj(api_data, textP, textLen, &exeMethodRecP->resultObjRef);
			DisposeBlock(&encodedStringBlock);
		}
		BAPI_ReleaseStringBlock(&ref);
	}

return err;
}

//===========================================================================================
/*static XErr	_GetHeaderIn(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;

	if (totParams == 0)
		err = BAPI_GetHeaderIn(api_data, &exeMethodRecP->resultObjRef);
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetHeaderOut(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;

	if (totParams == 0)
		err = BAPI_GetHeaderOut(api_data, &exeMethodRecP->resultObjRef);
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_GetHeaderField(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data, Boolean out)
{
XErr	err = noErr;
CStr255	fieldName;

	if (totParams == 1)
		err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0], fieldName, nil, 255, kImplicitTypeCast);
	else if NOT(totParams)
		CEquStr(fieldName, "");
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);
	if NOT(err)
	{	err = BAPI_GetHeaderField(api_data, fieldName, &exeMethodRecP->resultObjRef, out);
		if (err == Err_HeaderFieldNotFound)
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_AddHeaderField(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data, Boolean set)
{
XErr		err = noErr;
CStr255		fieldName;
CStr255		aCStr;
BlockRef	ref;
char		*stringP;
long		stringLen;

	if ((totParams == 2) || (totParams == 1))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0], fieldName, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1], aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
			{	if NOT(*fieldName)
					CEquStr(fieldName, "");
				if (set)
					err = BAPI_SetHeaderField(api_data, fieldName, stringP, stringLen);
				else
					err = BAPI_AddHeaderField(api_data, fieldName, stringP, stringLen);
				BAPI_ReleaseStringBlock(&ref);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}
*/
#pragma mark-
//===========================================================================================
static XErr	BifernoFunctions_ExecuteFunction(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				totParams = exeMethodRecP->totParams;
long 				api_data = pbPtr->api_data, methodID = exeMethodRecP->methodID;

	//TRACEN("BifernoFunctions_ExecuteFunction", methodID, 0)
	//exeMethodRecP->resultObjRef.id = 0;
	//BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
	switch (methodID)
	{	
		case kWantDestructor:
			err = _GetClInfo(exeMethodRecP, api_data, methodID);
			break;
		case kCanHavePersistent:
			err = _GetClInfo(exeMethodRecP, api_data, methodID);
			break;
		case kCloneObjects:
			err = _GetClInfo(exeMethodRecP, api_data, methodID);
			break;

		case  kGetMaxUsers:
			err = _GetMaxUsers(exeMethodRecP, api_data);
			break;
		case  kGetTotVariables:
			err = _GetTotVariables(exeMethodRecP, totParams, api_data);
			break;
		case kGetIndVariable:
			err = _GetIndVariable(exeMethodRecP, totParams, api_data);
			break;
		case kConstructorString:
			err = _ConstructorString(exeMethodRecP, api_data);
			break;
		case kDebuggerString:
			err = _DebuggerString(exeMethodRecP, api_data);
			break;
		case kGetPubVariable:
			err = _GetPubVariable(exeMethodRecP, api_data);
			break;
		case kPublish:
			err = _Publish(exeMethodRecP, api_data, true);
			break;
		case kUnpublish:
			err = _Publish(exeMethodRecP, api_data, false);
			break;
		case kLockObj:
			err = _LockObject(exeMethodRecP, api_data, true);
			break;
		case kUnlockObj:
			err = _LockObject(exeMethodRecP, api_data, false);
			break;
		case kGetPrototype:
			err = _GetPrototype(exeMethodRecP, totParams, api_data);
			break;
		case kGetInfo:
			err = _GetInfo(pbPtr, exeMethodRecP, api_data);
			break;
		case kGetDoc:
			err = _GetDoc(exeMethodRecP, totParams, api_data);
			break;
		/*case kGetMemberDoc:
			err = _GetMembDoc(exeMethodRecP, api_data);
			break;*/
		case kGetMembers:
			err = _GetMembers(pbPtr, exeMethodRecP, api_data);
			break;
		case kPrint:
			err = _Print(exeMethodRecP, totParams, api_data);
			break;
		case kClassAvailable:
			err = _ClassAvailable(exeMethodRecP, api_data);
			break;
		case kSystem:
			err = _System(exeMethodRecP, totParams, api_data);
			break;
		/*case kTest:
			err = _Test(exeMethodRecP, totParams, api_data);
			break;*/
		case kMillisecs:
			err = _Millisecs(exeMethodRecP, totParams, api_data);
			break;
		case kDelay:
			err = __Delay(exeMethodRecP, totParams, api_data);
			break;
		/*case kFullPath:
			err = _FullPath(exeMethodRecP, totParams, api_data);
			break;*/
		case kNoCache:
			err = _Cache(exeMethodRecP, totParams, api_data, false);
			break;
		case kIsCacheActive:
			err = _IsCacheActive(exeMethodRecP, totParams, api_data);
			break;
		case k_GetErrMessage:
			err = _GetErrMessage(exeMethodRecP, totParams, api_data);
			break;
		/*case kGetErrNum:
			err = _GetErrNum(exeMethodRecP, api_data);
			break;	*/		
		case kGetBasePath:
			err = _GetBasePath(exeMethodRecP, totParams, api_data);
			break;
		case kGetServerRoot:
			err = _GetServerRoot(exeMethodRecP, totParams, api_data);
			break;
		case kGetBifernoHome:
			err = _GetBifernoHome(exeMethodRecP, totParams, api_data);
			break;
		case kUpSince:
			err = _UpSince(exeMethodRecP, api_data);
			break;
		case kIsDef:
			err = _IsDef(exeMethodRecP, totParams, api_data);
			break;
		case kIsClassDef:
			err = _IsClassFuncDef(exeMethodRecP, false, api_data);
			break;
		case kIsFuncDef:
			err = _IsClassFuncDef(exeMethodRecP, true, api_data);
			break;
		case kIsInitialized:
			err = _IsInitialized(exeMethodRecP, api_data);
			break;
		case kGetApplications:
			err = _GetApplications(exeMethodRecP, api_data);
			break;
		case kFlushAll:
			err = _Flush(api_data);
			break;
		case kReloadAll:
			err = _Reload(api_data);
			break;
		case kFlushAppFiles:
			err = _FlushAppFiles(api_data);
			break;
		case kFlushOneCacheFile:
			err = _FlushOneCacheFile(exeMethodRecP, api_data);
			break;
		case kReloadApp:
			err = _ReloadApp(api_data);
			break;		
		case kGetClasses:
			err = _GetClasses(exeMethodRecP, api_data);
			break;
		case kGetApplicationFunctions:
			err = _GetApplicationFunctions(exeMethodRecP, totParams, api_data);
			break;
		case kRegisterApplication:
			err = _RegisterApplication(exeMethodRecP, api_data);
			break;
		case kGetApplicationClasses:
			err = _GetApplicationClasses(exeMethodRecP, api_data);
			break;
		case kGetExtendedClass:
			err = _GetExtendedClass(exeMethodRecP, api_data);
			break;
		
		case kGetVersion:
			err = _GetVersion(exeMethodRecP, api_data);
			break;
		case kGetNumVersion:
			err = _GetNumVersion(exeMethodRecP, api_data);
			break;
		case kOnErrorResume:
			err = _OnErrorResume(exeMethodRecP, totParams, api_data);
			break;
		/*case kFree:
			err = _Free(exeMethodRecP, totParams, api_data);
			break;*/
		case kValueOf:
			err = _ValueOf(exeMethodRecP, totParams, api_data);
			break;
		case kEval:
			err = _Eval(exeMethodRecP, api_data);
			break;
		case kHide:
			err = _Hide(exeMethodRecP, true, api_data);
			break;
		case kShow:
			err = _Hide(exeMethodRecP, false, api_data);
			break;
		case kGetIndSID:
			err = _GetIndSID(exeMethodRecP, totParams, api_data);
			break;
		case kSessionVariable:
			err = _SessionVariable(exeMethodRecP, totParams, api_data, pbPtr->error);
			break;
		
		case kPageWasInCache:
			err = _PageWasInCache(exeMethodRecP, totParams, api_data);
			break;
		case kPageWillBeCached:
			err = _PageWillBeCached(exeMethodRecP, totParams, api_data);
			break;
		case kCache:
			err = _Cache(exeMethodRecP, totParams, api_data, true);
			break;
		case kJavaEnabled:
			err = _JavaEnabled(exeMethodRecP, totParams, api_data);
			break;
		case kOnErrorSuspend:
			err = _OnErrorSuspend(exeMethodRecP, totParams, api_data);
			break;
		case kOnErrorState:
			err = _OnErrorState(exeMethodRecP, totParams, api_data);
			break;
		case kOnErrorFunction:
			err = _OnErrorFunction(exeMethodRecP, totParams, api_data);
			break;

		case kSetTimeout:
			err = _SetTimeout(exeMethodRecP, api_data);
			break;
		case kGetTimeout:
			err = _GetTimeout(exeMethodRecP, api_data);
			break;

		case kGetUser:
			err = _getUser(exeMethodRecP, api_data);
			break;
		case kGetGroup:
			err = _getGroup(exeMethodRecP, api_data);
			break;
		case kSetUser:
			err = _setUser(exeMethodRecP, totParams, api_data);
			break;
			
		case kGetCache:
			err = _GetCache(exeMethodRecP, api_data);
			break;
		
		case kSetCustomOutput:
			err = _SetCustomOutput(exeMethodRecP, api_data);
			break;
		case kSetStandardOutput:
			err = _SetStandardOutput(api_data);
			break;
		case kGetCurrentOutput:
			err = _GetCurrentOutput(exeMethodRecP, api_data);
			break;
		case kUndef:
			err = _Undef(exeMethodRecP, api_data);
			break;

		case kGetEnv:
			err = _getEnv(exeMethodRecP, api_data);
			break;
		case kPutEnv:
			err = _PutEnv(pbPtr, exeMethodRecP);
			break;
		case kSetEnv:
			err = _SetEnv(pbPtr, exeMethodRecP);
			break;
		case kUnsetEnv:
			err = _UnsetEnv(pbPtr, exeMethodRecP);
			break;
		case kLogString:
			err = _LogString(pbPtr, exeMethodRecP);
			break;
		case kLaunchProcess:
			err = _LaunchProcess(exeMethodRecP, api_data);
			break;
		case kValueOfInput:
			err = _ValueOfInput(exeMethodRecP, api_data);
			break;
		
		default:
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
	}

return err;
}

#pragma mark-
#pragma export on
#pragma export on
//===========================================================================================
XErr	BifernoFunctions_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	//TRACE("BifernoFunctions_Biferno_Dispatch on")
	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "Biferno Functions");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(Generic Functions)");
			kBifernoFunctionsClassID = pbPtr->param.registerRec.pluginID;
			bifernoVersion = pbPtr->param.registerRec.api_version;
			break;
		case kInit:
			err = BifernoFunctions_Init(pbPtr);
			break;
		case kShutDown:
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kDestructor:
		case kExecuteOperation:
		case kExecuteMethod:
			break;
		case kExecuteFunction:
			err = BifernoFunctions_ExecuteFunction(pbPtr);
			break;
		case kGetProperty:
		case kSetProperty:
		case kPrimitive:
			break;


		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	//TRACEN("BifernoFunctions_Biferno_Dispatch off", err, message)
	
return err;
}
#pragma export off

