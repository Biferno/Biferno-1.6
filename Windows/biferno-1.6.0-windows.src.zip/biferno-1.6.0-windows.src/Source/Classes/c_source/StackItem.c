/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: StackItem.c,v 1.2 2008-06-13 14:27:46 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

// defines
#define	gsPlugName	"stackItem"

static 	long	stackItemClassID;
static 	long	gsApiVersion;

// Properties
enum{
	kFilePath = 1,
	kLine,
	kPrototype,
	kClassOwner,
	kIncludeIndex,
	kThisObj
} StackItem_Property;

#define TOT_PROPERTIES	6

//===========================================================================================
static XErr	StackItem_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				api_data = pbPtr->api_data;
BAPI_MemberRecord	stackItemProperty[TOT_PROPERTIES] = 
					{	//"itemType",			kItemType,		"string",
						//"fileName",			kFileName,		"string",
						"filePath",			kFilePath,		"string",
						"line",				kLine,			"int",
						"prototype",		kPrototype,		"string",
						"classOwner",		kClassOwner,	"string",
						"includeIndex",		kIncludeIndex,	"int",
						"thisObj",			kThisObj,		"obj"
					};

	if (err = BAPI_NewProperties(api_data, stackItemClassID, stackItemProperty, TOT_PROPERTIES, nil))
		return err;		

return err;
}

//===========================================================================================
/*static XErr	StackItem_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr				err = noErr;
ConstructorRec		*constructorRecP = &pbPtr->param.constructorRec;
long				api_data = pbPtr->api_data;
long				tLen, totParams;
ParameterRec		*paramsP;
StackRecord			stackRec;
CStr63				classOwnerName;

	ClearBlock(&stackRec, sizeof(StackRecord));
	switch (message == kClone)
	{	
		case kClone:
			if (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP[0].objRef) == stackItemClassID)
			{	tLen = sizeof(StackRecord);
				err = BAPI_ReadObj(api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&stackRec, &tLen, 0, nil);
			}
			else
				err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kConstructor:
			totParams = constructorRecP->totVars;
			paramsP = constructorRecP->varRecsP;
			if (err = BAPI_ObjToString(api_data, &paramsP[0].objRef, stackRec.type, nil, 32, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToString(api_data, &paramsP[1].objRef, stackRec.fileName, nil, 256, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToString(api_data, &paramsP[2].objRef, stackRec.filePath, nil, 256, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToInt(api_data, &paramsP[3].objRef, &stackRec.line, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToString(api_data, &paramsP[4].objRef, stackRec.prototype, nil, 256, kImplicitTypeCast))
				goto out;
			if (err = BAPI_ObjToString(api_data, &paramsP[5].objRef, classOwnerName, nil, 64, kImplicitTypeCast))
				goto out;
			stackRec.classOwner = BAPI_ClassIDFromName(api_data, classOwnerName, false);
			break;
		default:
			err = XError(kBAPI_Error, Err_IllegalOperation);
	}
	if NOT(err)
		err = BAPI_BufferToObj(api_data, (Ptr)&stackRec, sizeof(StackRecord), stackItemClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
	
out:
return err;
}
*/
//===========================================================================================
static XErr	StackItem_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr				err = noErr;
long				tLen, api_data = pbPtr->api_data;
StackRecord			stackRec;
CStr255				aCStr;

	if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
	{	tLen = sizeof(StackRecord);
		if (NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&stackRec, &tLen, 0, nil)))
		{	switch(getPropertyRec->propertyID)
			{
				/*case kItemType:
					err = BAPI_StringToObj(api_data, stackRec.type, CLen(stackRec.type), &getPropertyRec->resultObjRef);
					break;*/
				/*case kFileName:
					err = BAPI_StringToObj(api_data, stackRec.fileName, CLen(stackRec.fileName), &getPropertyRec->resultObjRef);
					break;*/
				case kFilePath:
					CEquStr(aCStr, "file:/");
					CAddStr(aCStr, stackRec.filePath);
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRec->resultObjRef);
					break;
				case kLine:
					err = BAPI_IntToObj(api_data, stackRec.line, &getPropertyRec->resultObjRef);
					break;
				case kPrototype:
					err = BAPI_StringToObj(api_data, stackRec.prototype, CLen(stackRec.prototype), &getPropertyRec->resultObjRef);
					break;
				case kClassOwner:
					if (NOT(err = BAPI_NameFromClassID(api_data, stackRec.classOwner, aCStr)))
						err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &getPropertyRec->resultObjRef);
					break;
				case kIncludeIndex:
					err = BAPI_IntToObj(api_data, stackRec.includeStackPointer, &getPropertyRec->resultObjRef);
					break;
				case kThisObj:
					getPropertyRec->resultObjRef = stackRec.thisObjRef;
					break;
				default:
					err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					break;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);

return err;
}

//===========================================================================================
static XErr	StackItem_Primitive(Biferno_ParamBlockPtr pbPtr)
{
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
XErr				err = noErr;
long				size, tLen;
Primitive_String	*textP;
PrimitiveUnion		*param_d;
StackRecord			stackRec;
CStr255				resStr;

	param_d = &typeCast->result;
	tLen = sizeof(StackRecord);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&stackRec, &tLen, 0, nil))
	{	if (typeCast->resultWanted == kBool)
			typeCast->result.boolValue = true;
		else if (typeCast->resultWanted == kCString)
		{	textP = &param_d->text;
			CEquStr(resStr, "Stack Item");
			size = CLen(resStr);
			if (textP->stringP)
			{	if (textP->stringMaxStorage >= (size + 1))
				{	CopyBlock(textP->stringP, resStr, size);
					textP->stringP[size] = 0;
					textP->stringLen = size;
				}
				else
				{	CopyBlock(textP->stringP, resStr, textP->stringMaxStorage - 1);
					textP->stringP[textP->stringMaxStorage - 1] = 0;
					textP->stringLen = size;
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
				}
			}
			else
				textP->stringLen = size;
		}
		else
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	stackItem_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			stackItemClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			// CEquStr(pbPtr->param.registerRec.constructor, "void StackItem(string itemType, string fileName, string filePath, int line, string prototype, string classOwner)");
			break;
		case kInit:
			err = StackItem_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			XError(kBAPI_Error, Err_NoSuchMethod);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = StackItem_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kPrimitive:
			err = StackItem_Primitive(pbPtr);
			break;
		case kSuperIsChanged:
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
#pragma export off
#endif

