#include 	"XLib.h"
//#include	"Helpers.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#ifdef WITH_CONVERT_IMAGE

#include 	"ConvIm.h"

enum{
		kConvertImage = 1
	};
#define TOT_FUNCTIONS	1

static long	gsConvertImageClassID;

//===========================================================================================
XErr		GetRescaledDims(long xsize, long ysize, double scale, int *widthP, int *heightP, char *errMessage)
{
XErr	err = noErr;
long	width = *widthP, height = *heightP;

	if (scale)
	{	width = xsize / scale;
		height = ysize / scale;
	}
	else
	{	if (width <= 0)
		{	if (height > 0)
				width = (double)height * (double)xsize / (double)ysize;
			else
			{	err = 22;
				CEquStr(errMessage, "BifernoConvertImage: invalid width");
			}
		}
		if (height <= 0)
		{	if (width > 0)
				height = (double)width * (double)ysize / (double)xsize;
			else
			{	err = 23;
				CEquStr(errMessage, "BifernoConvertImage: invalid height");
			}
		}
	}
	*heightP = height;
	*widthP = width;
	
return err;
}

//===========================================================================================
static XErr	_ConvertImage(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		errMessage, sourceFilePath, destFilePath;
long		jpegQuality, width, height;
double		scale;
Boolean		overwrite;

	*errMessage = 0;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, sourceFilePath, nil, 255, kImplicitTypeCast))
		goto out;
	if (err = BAPI_RealPath(api_data, sourceFilePath, true))
		goto out;
	if (err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, destFilePath, nil, 255, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &jpegQuality, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToDouble(api_data, &exeMethodRecP->paramVarsP[3].objRef, &scale, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[4].objRef, &width, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[5].objRef, &height, kImplicitTypeCast))
		goto out;
	if (err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[6].objRef, &overwrite, kImplicitTypeCast))
		goto out;

	err = BAPI_RealPath(api_data, destFilePath, true);
	if (err == XError(kXLibError, ErrXFiles_FileNotFound))
		err = noErr;
	else if NOT(err)
	{	if (overwrite)
		{	if (err = DeleteXFile(destFilePath))
				goto out;
		}
		else
		{	err = XError(kXLibError, ErrXFiles_DuplicatedFile);
			goto out;
		}
	}
	else
		goto out;
	
	if (err = BifernoConvertImage(sourceFilePath, destFilePath, jpegQuality, scale, width, height, errMessage))
		err = noErr;

	BAPI_StringToObj(api_data, errMessage, CLen(errMessage), &exeMethodRecP->resultObjRef);

out:
return err;
}

#pragma mark-
//===========================================================================================
static XErr	ConvertImage_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
BAPI_MemberRecord	convImageFuncs[TOT_FUNCTIONS] = 
					{	
						"ConvertImage",	kConvertImage,	"string ConvertImage(string sourceFilePath, string destFilePath, int jpegQuality, double scale, long width, long height, boolean overwrite)"
					};
	
	if (err = BAPI_NewFunctions(pbPtr->api_data, gsConvertImageClassID, convImageFuncs, TOT_FUNCTIONS))
		return err;

return err;
}

//===========================================================================================
static XErr	ConvertImage_ExecuteFunction(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				totParams = exeMethodRecP->totParams;
long 				api_data = pbPtr->api_data, methodID = exeMethodRecP->methodID;

	//exeMethodRecP->resultObjRef.id = 0;
	//BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
	switch (methodID)
	{	
		case kConvertImage:
			err = _ConvertImage(exeMethodRecP, api_data);
			break;

		default:
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
	}

return err;
}

#pragma export on
//===========================================================================================
XErr	ConvertImage_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "ConvertImage");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(Convert Image Formats)");
			gsConvertImageClassID = pbPtr->param.registerRec.pluginID;
			break;
		case kInit:
			err = ConvertImage_Init(pbPtr);
			break;
		case kShutDown:
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kDestructor:
		case kExecuteOperation:
		case kExecuteMethod:
			break;
		case kExecuteFunction:
			err = ConvertImage_ExecuteFunction(pbPtr);
			break;
		case kGetProperty:
		case kSetProperty:
		case kPrimitive:
			break;


		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#pragma export off

#endif
