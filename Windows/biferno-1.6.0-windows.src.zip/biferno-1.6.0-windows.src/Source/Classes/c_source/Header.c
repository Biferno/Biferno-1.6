/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Header.c,v 1.14 2008-04-16 14:30:04 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include 	"BfrHeader.h"

// defines
#define	gsPlugName	"header"

// Errors
#define	HEADER_START_ERR	10000
enum {
		ErrHeaderFieldNotFound = HEADER_START_ERR,
		ErrInvalidHeader
};
CStr63	gHeaderErrorsStr[] = 
	{	
		"ErrHeaderFieldNotFound",
		"ErrInvalidHeader"
	};
#define	TOT_ERRORS	2

// Methods
enum{
		kGetField = 1,
		kSetField,
		kAddField,
		kRemoveField
	};
#define TOT_METHODES	4

static 	long	headerClassID;
static 	long	gsApiVersion;

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr				err = noErr;
BAPI_MemberRecord	headerMethods[TOT_METHODES] = 
					{	"GetField",		kGetField, 			"string GetField(string name, long index=1)",
						"SetField",		kSetField, 			"void SetField(string name, string content, long index=1)",
						"AddField",		kAddField, 			"void AddField(string name, string content)",
						"RemoveField",	kRemoveField, 		"void RemoveField(string name, long index=1)"
					};


	if (err = BAPI_NewMethods(api_data, headerClassID, headerMethods, TOT_METHODES, nil))
		return err;

	err = BAPI_RegisterErrors(api_data, headerClassID, HEADER_START_ERR, gHeaderErrorsStr, TOT_ERRORS);

return noErr;
}

//===========================================================================================
static XErr	_GetFieldDataBlock(DLMRef list, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long objID)
{		
XErr		err = noErr;
long		dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock;

	*refP = 0;
	if NOT(err = DLM_GetObj(list, objID, nil, &dataLen, 0, nil))
	{	++dataLen;	// 0-final
		if (aCStr && (dataLen < 255))
		{	dataP = aCStr;
			*refP = 0;
			if (stringP)
				*stringP = dataP;
		}
		else
		{	if (dataBlock = NewBlockLocked(dataLen, &err, (Ptr*)&dataP))
			{	//LockBlock(dataBlock);
				//dataP = GetPtr(dataBlock);
				if (stringP)
					*stringP = dataP;
				*refP = dataBlock;
			}
		}
		if NOT(err)
		{	dataLen--;
			if NOT(err = DLM_GetObj(list, objID, dataP, &dataLen, 0, nil))
			{	if (stringLen)
					*stringLen = dataLen;
				dataP[dataLen] = 0;
			}
		}	
	}
	
if (err && *refP)
	DisposeBlock(&dataBlock);
return err;
}

#define	FIRST_LINE		"HTTP/1.1 200 OK"
#define	CONT_TYPE		"text/html"
#define	X_POWERED		"Biferno (<A HREF=\"http://www.tabasoft.it/biferno\">http://www.tabasoft.it/biferno</A>)"
//#define	CONNECT			"close"

//===========================================================================================
XErr	InitializeHeaderOut(char *serverName, HeaderObjectRec *newHeadObjRecP, Boolean empty)
{
XErr			err = noErr;
long			servLen;
DLMRef			headList = 0;
XDateTimeRec	timeRec;
unsigned long 	secs;
CStr255			gmtString;

	ClearBlock(newHeadObjRecP, sizeof(HeaderObjectRec));
	if NOT(err = DLM_CreateAcceptDupl(&headList, NAME_LIST, LOCAL_LIST))
	{	if NOT(empty)
		{	if (DLM_NewObj(headList, "0", FIRST_LINE, CLen(FIRST_LINE), 0, 0, &err))
			{	if (DLM_NewObj(headList, "Content-type", CONT_TYPE, CLen(CONT_TYPE), 0, 0, &err))
				{	if (DLM_NewObj(headList, "X-Powered-By", X_POWERED, CLen(X_POWERED), 0, 0, &err))
					{	//if (DLM_NewObj(headList, "Connection", CONNECT, CLen(CONNECT), 0, 0, &err))
						//{	
						if (servLen = CLen(serverName))
							DLM_NewObj(headList, "Server", serverName, CLen(serverName), 0, 0, &err);
						if NOT(err)
						{	XGetSeconds(&secs);
							SecondsToXDateTime(secs, &timeRec);
							XDateTimeToGMT(&timeRec);
							GetUString(&timeRec, gmtString);
							DLM_NewObj(headList, "Date", gmtString, CLen(gmtString), 0, 0, &err);
						}
						//}
					}
				}
			}
		}
	}
	if (err)
	{	if (headList)
			DLM_Dispose(&headList, nil, 0);
	}
	else
		newHeadObjRecP->list = headList;

return err;
}

//===========================================================================================
XErr	PackHeader(HeaderObjectRec *headObjP, BlockRef *headBlockP, long *headBlockLenP)
{
XErr		err = noErr;
long		objID, totObjs;
int			k;
CStr255		aCStr, theName;
long		id, dataLen;
char		*dataP;
BlockRef	ref;
DLMRef 		list = headObjP->list;

	if (id = BufferCreate(256, &err))
	{	if NOT(err = DLM_GetTotObjs(list, &totObjs, false))
		{	if (totObjs)
			{	for (k = 1; (k <= totObjs) && NOT(err); k++)
				{	if NOT(err = DLM_GetIndObj(list, k, nil, &dataLen, 0, nil, &objID, theName, false, false))
					{	if NOT(err = _GetFieldDataBlock(list, aCStr, &dataP, &dataLen, &ref, objID))
						{	if ((k == 1) && (((*theName == '0') && (*(theName+1) == 0)) || NOT(*theName)))
								err = BufferAddText(id, dataP, dataLen, NO_ENC, 0);
							else
							{	if NOT(err = BufferAddCString(id, theName, NO_ENC, 0))
								{	if NOT(err = BufferAddCString(id, ": ", NO_ENC, 0))
										err = BufferAddText(id, dataP, dataLen, NO_ENC, 0);
								}
							}
							if NOT(err)
								err = BufferAddCString(id, "\r\n", NO_ENC, 0);
							if (ref)
								DisposeBlock(&ref);
						}
					
					}
				}
				if NOT(err)
				{	if NOT(err = BufferAddCString(id, "\r\n", NO_ENC, 0))
						err = BufferAddChar(id, 0);
				}
			}
			else
				err = BufferAddChar(id, 0);
		}
		if (err)
			BufferFree(id);
		else
		{	*headBlockP = BufferGetBlockRef(id, headBlockLenP);
			--(*headBlockLenP);
			BufferClose(id);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_AddOne(DLMRef headList, Ptr headerP, Ptr *itemPPtr, long *itemLenP, Boolean *firstP)
{
Boolean		first = *firstP;
long 		nameLen, itemLen = *itemLenP;
Ptr			itemP = *itemPPtr;
CStr255		name;
XErr		err = noErr;
char		*nameStr;

	if (first)
	{	first = false;
		if (DLM_NewObj(headList, "0", itemP, itemLen, 0, 0, &err))
		{	itemP = headerP;
			itemLen = 0;
		}
	}
	else
	{	if (itemLen)
		{	nameStr = name;
			nameLen = 0;
			do {
				if (itemLen && (*itemP == ':'))
				{	itemP++;
					itemLen--;
					if (itemLen && (*itemP == ' '))
					{	itemP++;
						itemLen--;
					}
					break;
				}
				else if (nameLen < 255)
				{	*nameStr++ = *itemP;
					nameLen++;
				}
				else
					err = XError(kBAPI_ClassError, ErrInvalidHeader);	//ex err = XError(kBAPI_Error, Err_BadSyntax);
				itemP++;
				itemLen--;
			} while ((itemLen > 0) && NOT(err));
			if NOT(err)
			{	name[nameLen] = 0;
				if (DLM_NewObj(headList, name, itemP, itemLen, 0, 0, &err))
				{	itemP = headerP;
					itemLen = 0;
				}
			}
		}
	}
	
	*itemLenP = itemLen;
	*itemPPtr = itemP;
	*firstP = first;

return err;
}

//===========================================================================================
XErr	TokenizeHeader(char *headerP, long headerLen, HeaderObjectRec *headObjP, long listGlobal)
{
XErr		err = noErr;
Boolean		first = true;
Ptr			itemP;
long		advance, itemLen;
DLMRef		headList = 0;

	ClearBlock(headObjP, sizeof(HeaderObjectRec));
	if NOT(err = DLM_CreateAcceptDupl(&headList, NAME_LIST, listGlobal))
	{	if (headerLen)
		{	itemP = headerP;
			itemLen = 0;
			{	do {
					if (IsNewLine(headerP, headerLen, &advance))
					{	headerP += advance;
						headerLen -= advance;
						err = _AddOne(headList, headerP, &itemP, &itemLen, &first);
					}
					else
					{	headerP++;
						headerLen--;
						itemLen++;
					}
				} while ((headerLen > 0) && NOT(err));
			}
			// last
			if (itemLen)
				err = _AddOne(headList, headerP, &itemP, &itemLen, &first);
		}
	}
	
if (err && headList)
	DLM_Dispose(&headList, nil, 0);
else
	headObjP->list = headList;
return err;
}

//===========================================================================================
XErr	CloneHeaderObjectRec(HeaderObjectRec *headObjRecP, HeaderObjectRec *newHeadObjRecP)
{
XErr			err = noErr;

	*newHeadObjRecP = *headObjRecP;
	err = DLM_CloneList(headObjRecP->list, &newHeadObjRecP->list);

return err;
}

//===========================================================================================
XErr	ObjRefFromHeaderObjectRec(long api_data, HeaderObjectRec *headObjRecP, ObjRef *objRef)
{
XErr			err = noErr;
HeaderObjectRec newHeadObjectRec;
long			plugin_run_data;

	newHeadObjectRec = *headObjRecP;
	if NOT(err = DLM_CloneList(headObjRecP->list, &newHeadObjectRec.list))
	{	err = BAPI_BufferToObj(api_data, (Ptr)&newHeadObjectRec, sizeof(HeaderObjectRec), headerClassID, true, nil, objRef);
		if (err)
			DLM_Dispose(&newHeadObjectRec.list, nil, 0);
		else
		{	if NOT(err = BAPI_GetPluginRunData(api_data, headerClassID, &plugin_run_data))
			{	plugin_run_data++;
				err = BAPI_SetPluginRunData(api_data, headerClassID, plugin_run_data);
			}
		}
	}
		
return err;
}

//===========================================================================================
void	DisposeHeaderObject(HeaderObjectRec *headObjRecP)
{
	DLM_Dispose(&headObjRecP->list, nil, 0);
}

//===========================================================================================
XErr	GetHeaderField(long api_data, char *fieldName, ObjRef *objRefP)
{
ObjRef			pageIn, headIn;
XErr			err = noErr;
Boolean			isDef;
ParameterRec	fieldNameS;

	if NOT(err = BAPI_IsVariableDefined(api_data, "pageIn", GLOBAL, &isDef, &pageIn))
	{	if (isDef)
		{	ClearBlock(&fieldNameS, sizeof(ParameterRec));
			if NOT(err = BAPI_StringToObj(api_data, fieldName, CLen(fieldName), &fieldNameS.objRef))
			{	if NOT(err = BAPI_GetProperty(api_data, &pageIn, "head", 1, nil, &headIn))
				{	err = BAPI_ExecuteMethod(api_data, &headIn, &fieldNameS, 1, "GetField", objRefP, nil);
					if (err)
						err = BAPI_StringToObj(api_data, "", 0, objRefP);
				}
			}
		}
		else
		{	BAPI_InvalObjRef(api_data, objRefP);
			//objRefP->classID = 0;
			//objRefP->id = 0;
			err = XError(kBAPI_Error, Err_PageInNotDefined);
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	SetCookie(HeaderObjectRec *headObjRecP, char *cookieName, char *cookieValue)
{
XErr		err = noErr;
CStr255		aCStr;

	CEquStr(aCStr, cookieName);
	CAddChar(aCStr, '=');
	CAddStr(aCStr, cookieValue);
	CAddChar(aCStr, ';');
	CAddStr(aCStr, " Path=/;");
	DLM_NewObj(headObjRecP->list, "Set-Cookie", aCStr, CLen(aCStr), 0, 0, &err);

return err;
}

//===========================================================================================
XErr	GetCookie(HeaderObjectRec *headObjRecP, char *cookieName, char *cookieValue, long maxStorage)
{
XErr		err = noErr;
long		objID;
CStr255		aCStr;
Ptr			saveP, dataP;
long		len, cookieNameLen, dataLen;
BlockRef	ref;
char		*itemP;
long		itemLen;

	*cookieValue = 0;
	if (objID = DLM_GetObjID(headObjRecP->list, "Cookie", nil, nil))
	{	if NOT(err = _GetFieldDataBlock(headObjRecP->list, aCStr, &dataP, &dataLen, &ref, objID))
		{	cookieNameLen = CLen(cookieName);
			SkipSpaceAndTab(&dataP, &dataLen);
			itemP = dataP;
			itemLen = 0;
			if (dataLen)
			{	do {
					if (dataLen && (*dataP == '='))
					{	if NOT(CompareBlock(itemP, cookieName, itemLen))
						{	dataP++;
							dataLen--;
							saveP = dataP;
							SkipUntilChar(&dataP, &dataLen, ';', nil);
							len = dataP - saveP;
							if (len > maxStorage)
								len = maxStorage;
							CopyBlock(cookieValue, saveP, len);
							cookieValue[len] = 0;
							break;
						}
						else
						{	SkipUntilChar(&dataP, &dataLen, ';', nil);
							if (dataLen--)
								dataP++;
							SkipSpaceAndTab(&dataP, &dataLen);
						}
						itemLen = 0;
						itemP = dataP;
					}
					else
					{	dataP++;
						dataLen--;
						itemLen++;
					}
				} while ((dataLen > 0) && NOT(err));
			}
			if (ref)
				DisposeBlock(&ref);
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_GetField(Biferno_ParamBlockPtr pbPtr, HeaderObjectRec *headObjRecP, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
long		objID, index, totParams = exeMethodRecP->totParams;
CStr255		fieldName, aCStr;
Ptr			dataP;
long		dataLen;
BlockRef	ref;
long 		api_data = pbPtr->api_data;

	if ((totParams == 1) || (totParams == 2))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, fieldName, nil, 255, kImplicitTypeCast))
		{	if (totParams == 1)
				index = 1;
			else
				err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &index, kImplicitTypeCast);
			if NOT(err)
			{	if NOT(*fieldName)
					CEquStr(fieldName, "0");
				if (objID = DLM_GetIndexObjID(headObjRecP->list, fieldName, index, nil, nil))
				{	if NOT(err = _GetFieldDataBlock(headObjRecP->list, aCStr, &dataP, &dataLen, &ref, objID))
					{	err = BAPI_StringToObj(api_data, dataP, dataLen, &exeMethodRecP->resultObjRef);
						if (ref)
							DisposeBlock(&ref);
					}
				}
				else
				{	err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
					/*err = XError(kBAPI_ClassError, ErrHeaderFieldNotFound);
					CEquStr(pbPtr->error, "header error: no field was found with name \"");
					CAddStr(pbPtr->error, fieldName);
					CAddStr(pbPtr->error, "\"");
					*/
				}
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_AddOneLine(HeaderObjectRec *headObjRecP, char *fieldName, char *stringP, long stringLen)
{
XErr	err = noErr;

	if NOT(*fieldName)
		CEquStr(fieldName, "0");
	DLM_NewObj(headObjRecP->list, fieldName, stringP, stringLen, 0, 0, &err);

return err;
}

//===========================================================================================
XErr	SetHeadField(HeaderObjectRec *headObjRecP, char *fieldName, long index, char *contentP, long contentLen)
{
long		objID;
XErr		err = noErr;

	if NOT(*fieldName)
		CEquStr(fieldName, "0");
	if (objID = DLM_GetIndexObjID(headObjRecP->list, fieldName, index, nil, nil))
		err = DLM_ModifyObj(headObjRecP->list, objID, contentP, contentLen, 0, nil, 0, nil);
	else
		err = _AddOneLine(headObjRecP, fieldName, contentP, contentLen);
	
return err;
}

//===========================================================================================
static XErr	_AddField(Biferno_ParamBlockPtr pbPtr, HeaderObjectRec *headObjRecP, ExecuteMethodRec *exeMethodRecP)
{
XErr				err = noErr;
long				totParams = exeMethodRecP->totParams;
CStr255				fieldName, aCStr;
Ptr					stringP;
long				stringLen;
BlockRef			ref;
long 				api_data = pbPtr->api_data;

	if (totParams == 2)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, fieldName, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
			{	
				/*if NOT(*fieldName)
					CEquStr(fieldName, "0");
				DLM_NewObj(headObjRecP->list, fieldName, stringP, stringLen, 0, 0, &err);
				if NOT(err)
				*/
				if NOT(err = _AddOneLine(headObjRecP, fieldName, stringP, stringLen))
					exeMethodRecP->sideEffect = true;
				BAPI_ReleaseBlock(&ref);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_SetField(Biferno_ParamBlockPtr pbPtr, HeaderObjectRec *headObjRecP, ExecuteMethodRec *exeMethodRecP)
{
XErr				err = noErr;
long				totParams = exeMethodRecP->totParams;
CStr255				fieldName, aCStr;
Ptr					stringP;
long				index, stringLen;
BlockRef			ref;
long 				api_data = pbPtr->api_data;

	if ((totParams == 2) || (totParams == 3))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, fieldName, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[1].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
			{	if (totParams == 2)
					index = 1;
				else
					err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &index, kImplicitTypeCast);
				if NOT(err)
				{	if NOT(err = SetHeadField(headObjRecP, fieldName, index, stringP, stringLen))
						exeMethodRecP->sideEffect = true;
					/*if NOT(*fieldName)
						CEquStr(fieldName, "0");
					if (objID = DLM_GetIndexObjID(headObjRecP->list, fieldName, index, nil, nil))
					{	if NOT(err = DLM_ModifyObj(headObjRecP->list, objID, stringP, stringLen, 0, nil, 0, nil))
							exeMethodRecP->sideEffect = true;
					}
					else
					{	if NOT(err = _AddOneLine(headObjRecP, fieldName, stringP, stringLen))
							exeMethodRecP->sideEffect = true;
					}*/
				}
				BAPI_ReleaseBlock(&ref);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_RemoveField(Biferno_ParamBlockPtr pbPtr, HeaderObjectRec *headObjRecP, ExecuteMethodRec *exeMethodRecP)
{
XErr				err = noErr;
long				totParams = exeMethodRecP->totParams;
CStr255				fieldName;
long				objID, index;
//HeaderObjectRec		newHeadObjRec;
long 				api_data = pbPtr->api_data;

	if ((totParams == 1) || (totParams == 2))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, fieldName, nil, 255, kImplicitTypeCast))
		{	if (totParams == 1)
				index = 1;
			else
				err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &index, kImplicitTypeCast);
			//if NOT(err = CloneHeaderObjectRec(headObjRecP, &newHeadObjRec))
			{	if (objID = DLM_GetIndexObjID(headObjRecP->list, fieldName, index, nil, nil))
				{	if NOT(err = DLM_DeleteObj(headObjRecP->list, objID, nil, 0))
					{	// if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&newHeadObjRec, sizeof(HeaderObjectRec), headerClassID, true, "", TEMP, VARIABLE, &exeMethodRecP->resultObjRef))
						//	pbPtr->plugin_run_data++;
						exeMethodRecP->sideEffect = true;
					}
				}
				else
				{	err = XError(kBAPI_ClassError, ErrHeaderFieldNotFound);
					CEquStr(pbPtr->error, "header error: no field was found with name \"");
					CAddStr(pbPtr->error, fieldName);
					CAddStr(pbPtr->error, "\"");
				}
				//if (err)
				//	DisposeHeaderObject(&newHeadObjRec);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
static XErr	Header_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	headerClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.wantDestructor = true;
	pbPtr->param.registerRec.fixedSize = true;
	CEquStr(pbPtr->param.registerRec.constructor, "void header(string headerString)");
	//pbPtr->param.registerRec.instanceIsDLM = true;

	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "PackHeader", (long)PackHeader))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "TokenizeHeader", (long)TokenizeHeader))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "InitializeHeaderOut", (long)InitializeHeaderOut))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "ObjRefFromHeaderObjectRec", (long)ObjRefFromHeaderObjectRec))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "DisposeHeaderObject", (long)DisposeHeaderObject))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "CloneHeaderObjectRec", (long)CloneHeaderObjectRec))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "GetCookie", (long)GetCookie))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "SetCookie", (long)SetCookie))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, headerClassID, "GetHeaderField", (long)GetHeaderField))
		goto out;
		
out:
return err;
}

//===========================================================================================
static XErr	Header_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _RegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	Header_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	headerClassID = 0;
	
return noErr;
}

//===========================================================================================
static XErr	Header_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			stringLen;
long			/*tscope, */tLen, api_data = pbPtr->api_data;
CStr255			aCStr;
Ptr				stringP;
BlockRef		ref = 0;
HeaderObjectRec headObjectRec;
long			listGlobal, tscope;

	if (constructorRecP->totVars == 1)
	{	if (clone && (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP->objRef) == headerClassID))
		{	HeaderObjectRec newHeadObjectRec;
		
			tLen = sizeof(HeaderObjectRec);
			err = BAPI_ReadObj(api_data, &constructorRecP->varRecsP->objRef, (Ptr)&headObjectRec, &tLen, 0, nil);
			if NOT(err)
			{	if NOT(err = DLM_CloneList(headObjectRec.list, &newHeadObjectRec.list))
				{	err = BAPI_BufferToObj(api_data, (Ptr)&newHeadObjectRec, sizeof(HeaderObjectRec), headerClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
					if (err)
						DLM_Dispose(&newHeadObjectRec.list, nil, 0);
				}
			}
		}
		else
		{	if NOT(err = BAPI_GetStringBlock(api_data, &constructorRecP->varRecsP->objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
			{	tscope = BAPI_ConstructorScope(api_data, constructorRecP->privateData);
				if ((tscope == APPLICATION) || (tscope == PERSISTENT))
					listGlobal = GLOBAL_LIST;
				else
					listGlobal = LOCAL_LIST;
				if NOT(err = TokenizeHeader(stringP, stringLen, &headObjectRec, listGlobal))
				{	if (err = BAPI_BufferToObj(api_data, (Ptr)&headObjectRec, sizeof(HeaderObjectRec), headerClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
						DLM_Dispose(&headObjectRec.list, nil, 0);
				}
				BAPI_ReleaseBlock(&ref);
			}
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "header(string headerString)");
	}
	
	//if NOT(err)
	//	BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, headerClassID);
		//constructorRecP->resultObjRef.classID = headerClassID;
		
return err;
}

//===========================================================================================
static XErr	Header_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
HeaderObjectRec headObjectRec;
long			objLen;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(HeaderObjectRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&headObjectRec, &objLen, 0, nil))
		{	if (objLen)
			{	
				DLM_Dispose(&headObjectRec.list, nil, 0);
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	Header_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				tLen, api_data = pbPtr->api_data;
HeaderObjectRec		headRec;
Boolean				needSer;

	tLen = sizeof(HeaderObjectRec);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&headRec, &tLen, 0, nil))
	{	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
			err = BAPI_NeedSerialize(api_data, &exeMethodRecP->objRef, &needSer);
		else
			needSer = false;
		if NOT(err)
		{	if (needSer)
				XThreadsEnterCriticalSection();
			switch(exeMethodRecP->methodID)
			{
				case kGetField:
					err = _GetField(pbPtr, &headRec, exeMethodRecP);
					break;
				case kSetField:
					err = _SetField(pbPtr, &headRec, exeMethodRecP);
					break;
				case kAddField:
					err = _AddField(pbPtr, &headRec, exeMethodRecP);
					break;
				case kRemoveField:
					err = _RemoveField(pbPtr, &headRec, exeMethodRecP);
					break;

				default:
					err = XError(kBAPI_Error, Err_NoSuchMethod);
					break;
			}
			if (needSer)
				XThreadsLeaveCriticalSection();
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Header_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
long			headBlockLen, tLen, strLen;
char			*strP, *p;
HeaderObjectRec	headObjectRec;
BlockRef		headBlock;
PrimitiveUnion	*param_d;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &typeCast->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		tLen = sizeof(HeaderObjectRec);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&headObjectRec, &tLen, 0, nil))
		{	param_d = &typeCast->result;
			if (tLen)
				err = PackHeader(&headObjectRec, &headBlock, &headBlockLen);
			else
				headBlock = headBlockLen = 0;
			if NOT(err)
			{	switch (typeCast->resultWanted)
				{	case kCString:
						if (headBlock)
						{	if (param_d->text.variant == kForConstructor)
							{
							BlockRef	escapedBlock;
							
								LockBlock(headBlock);
								strP = GetPtr(headBlock);
								strLen = headBlockLen;
								if NOT(err = StringEscaped(&strP, &strLen, &escapedBlock))
								{	DisposeBlock(&headBlock);
									headBlock = escapedBlock;
									headBlockLen = strLen;
								}
							}
							LockBlock(headBlock);
							strP = GetPtr(headBlock);
							strLen = headBlockLen;
						}
						else
						{	strP = nil;
							strLen = 0;
						}
						p = param_d->text.stringP;
						if (p)
						{	if (param_d->text.stringMaxStorage >= (strLen+1))
							{	CopyBlock(p, strP, strLen);
								p[strLen] = 0;
								param_d->text.stringLen = strLen;
							}
							else
							{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
								p[param_d->text.stringMaxStorage - 1] = 0;
								param_d->text.stringLen = strLen;
								err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
							}
						}
						else
							param_d->text.stringLen = strLen;
						break;
						
					case kChar:
						err = XError(kBAPI_Error, Err_IllegalTypeCast);
						break;
					
					case kBool:
						param_d->boolValue = (headBlockLen != 0);
						break;
					
					default:
						err = XError(kBAPI_Error, Err_IllegalTypeCast);
						break;
				}
				if (headBlock)
					DisposeBlock(&headBlock);
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
/*static XErr	Header_GetErrDescr(Biferno_ParamBlockPtr pbPtr)
{
GetErrDescrRec		*getErrDescrRecP = &pbPtr->param.getErrDescrRec;
short				tErr;

	CEquStr(getErrDescrRecP->errType, "Class header Error");
	if (((tErr = getErrDescrRecP->err) >= HEADER_START_ERR) && (tErr < lastErr))
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, gHeaderErrorsStr[tErr - HEADER_START_ERR]);
	}
	else
	{	CEquStr(getErrDescrRecP->errMessage, "");
		CEquStr(getErrDescrRecP->errName, "Unknown Error");
	}

return noErr;
}
*/
#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	header_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = Header_Register(pbPtr);
			break;
		case kInit:
			err = Header_Init(pbPtr);
			break;
		case kShutDown:
			err = Header_ShutDown(pbPtr);
			break;
		case kRun:
			//pbPtr->plugin_run_data = 0;
			break;
		case kExit:
		/*#ifdef MEM_DEBUG
			if ((*pbPtr->plugin_run_dataP))
				BAPI_Log(pbPtr->api_data, "header: leaking");
		#endif*/
			break;
		case kConstructor:
		case kTypeCast:
			err = Header_Constructor(pbPtr, false);
			break;
		case kClone:
			err = Header_Constructor(pbPtr, true);
			break;
		case kDestructor:
			err = Header_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Header_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = Header_TypeCast(pbPtr);
			break;
		/*case kGetErrDescr:
			err = Header_GetErrDescr(pbPtr);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


