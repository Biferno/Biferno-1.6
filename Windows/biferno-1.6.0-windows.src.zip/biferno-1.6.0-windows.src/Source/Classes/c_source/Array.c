/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Array.c,v 1.16 2008-02-12 12:06:30 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

//#include	"Helpers.h"

static long						arrayClassID;
static long						gsApiVersion;
//static long		gs_bool_id, gs_int_id, gs_unsigned_id, gs_double_id, gs_char_id, gs_string_id, gs_array_id, gs_float_id, gs_byte_id, gs_short_id, gs_long_id, gs_time_id;

//#define	gsObj1Str		"obj1"
//#define	gsObj2Str		"obj2"
//#define	kArString		"ar"

//#define	gsObjStrLen		4
//#define	kArStringLen	2

#define	gsArrayPlugName		"array"

// Properties
enum{
		kName = 1,
		kDim
	};
#define TOT_PROPRIETIES	2

// Methods
enum{
		kGetElemClass = 1,
		kSetElemClass,
		kAdd,
		kSetDim,
		kDelete,
		kToString,
		kIndex,
		k_Reverse,
		k_Swap,
		k_Find,
		k_Count,
		k_Min,
		k_Max,
		k_Reset,
		k_SubArray,
		k_Insert,
		k_Sort
	};
#define TOT_METHODES	17

#define TOT_COSTANTS	4

// Errors
#define	ARRAY_START_ERR	100
enum {
		ErrBadStartIndex = ARRAY_START_ERR,
		ErrBadEndIndex,
		ErrBadElementName
};

CStr63	gArrayErrorsStr[] = 
	{	
		"ErrBadStartIndex",
		"ErrBadEndIndex",
		"ErrBadElementName"
		};

#define	TOT_ERRORS	3

//===========================================================================================
static Boolean	_FixedSize(long api_data, long classID)
{
Boolean		fixedSize;

	BAPI_FixedSize(api_data, classID, &fixedSize);

return fixedSize;
}

//===========================================================================================
static XErr	_ArrayToString(long api_data, Boolean putConstrName, ObjRef *arrObjRefP, long *idP, Boolean forConstructor, Boolean forDebug)
{
XErr			err = noErr;
long			dataLen, i, arrayDim;
ObjRef			tObjRef;
Ptr				strP, dataP;
CStr255			aStr;
BlockRef		ref, dataBlock;
long			strLen, lastLoop, arrClassID, id = 0;
//ArrayIndexRec	mCoord;
CStr63			name;
Boolean			notPrintable = false;

	if NOT(err = BAPI_GetArrayInfo(api_data, arrObjRefP, &arrayDim, &arrClassID, nil))
	{	if (id = BufferCreate(512, &err))
		{	
			/*if (forDebug)
			{	if NOT(err = BAPI_NameFromClassID(api_data, arrClassID, aStr))
				{	if (err = BufferAddCString(id, "class element: ", NO_ENC, 0))
						goto out;
					if (err = BufferAddCString(id, aStr, NO_ENC, 0))
						goto out;
					if (err = BufferAddCString(id, "  \r\n", NO_ENC, 0))
						goto out;
				}
			}
			*/
			
			if (NOT(forDebug) && NOT(forConstructor) && putConstrName)
			{	if (err = BufferAddCString(id, "array(", NO_ENC, 0))
					goto out;
			}
			/*
			CNumToString(arrayDim, tStr);
			if (err = BufferAddCString(id, tStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, ", ", NO_ENC, 0))
				goto out;
			*/
			//*mCoord.ind_name = 0;
			lastLoop = arrayDim - 1;
			for (i = 0; (i < arrayDim) && NOT(err); i++)
			{	if (forDebug)
				{	CEquStr(name, "[");
					CNumToString(i+1, aStr);
					CAddStr(name, aStr);
					CAddStr(name, "] ");
					BufferAddCString(id, name, NO_ENC, 0);
				}
				
				dataBlock = 0;
				dataP = nil;
				tObjRef = *arrObjRefP;
				//mCoord.ind = i+1;
				if NOT(err = BAPI_ElementOfArray(api_data, &tObjRef, i+1, &tObjRef))
				{	if NOT(err = BAPI_GetObjInfo(api_data, &tObjRef, nil, name))
					{	if (forConstructor)
							err = BAPI_ObjToConstrString(api_data, &tObjRef, nil, &dataLen, 0, kExplicitTypeCast);
						else
							err = BAPI_ObjToString(api_data, &tObjRef, nil, &dataLen, 0, kExplicitTypeCast);
						if (/*forDebug && */err/*((err == XError(kBAPI_Error, Err_BAPI_ObjNotPrintable)) || (err == XError(kBAPI_Error, Err_IllegalTypeCast)))*/)
						{	dataLen = -1;	// then there is a ++
							notPrintable = true;
							err = noErr;
						}
						else
							notPrintable = false;
						if NOT(err)
						{	if (++dataLen < 255)
							{	dataP = aStr;
								dataBlock = 0;
							}
							else
							{	if (dataBlock = NewBlockLocked(dataLen, &err, &dataP))
								{	//LockBlock(dataBlock);
									//dataP = GetPtr(dataBlock);
								}
							}
							if NOT(err)
							{	if NOT(notPrintable)
								{	if (forConstructor)
										err = BAPI_ObjToConstrString(api_data, &tObjRef, dataP, &dataLen, dataLen, kExplicitTypeCast);
									else
										err = BAPI_ObjToString(api_data, &tObjRef, dataP, &dataLen, dataLen, kExplicitTypeCast);
								}
								if NOT(err)
									dataP[dataLen] = 0;
							}
						}
						if NOT(err)
						{	strLen = CLen(name);
							if (forConstructor)
							{	strP = name;
								if (err = StringEscaped(&strP, &strLen, &ref))
									goto out;
								err = BufferAddBuffer(id, strP, strLen);
								DisposeBlock(&ref);
							}
							else
								err = BufferAddCString(id, name, NO_ENC, 0);
							if (err)
								goto out;
							if (strLen)
							{	if (err = BufferAddChar(id, ':'))
									goto out;
							}
							/*if (forDebug && NOT(tObjRef.classID))
							{	if (err = BufferAddCString(id, "[UNDEF]", NO_ENC, 0))
									goto out;
							}*/
							if (err = BufferAddCString(id, dataP, NO_ENC, 0))
								goto out;
							if (NOT(forDebug) && (i < lastLoop))
							{	if (err = BufferAddCString(id, ", ", NO_ENC, 0))
									goto out;
							}
						}
						if (forDebug && (i < lastLoop))
							BufferAddCString(id, " \r\n", NO_ENC, 0);
						if (dataBlock)
							DisposeBlock(&dataBlock);
					}
				}
			}
			if NOT(err)
			{	if (NOT(forDebug) && NOT(forConstructor) && putConstrName)
				{	if (err = BufferAddChar(id, ')'))
						goto out;
				}
			}
		}
	}

out:
if NOT(err)
	*idP = id;
else if (id)
	BufferFree(id);

return err;
}

//===========================================================================================
/*static XErr	_ArrayToStrings(long api_data, ObjRef *arrObjRefP, Boolean names, long *idP)
{
XErr			err = noErr;
long			dataLen, i, arrayDim;
ObjRef			tObjRef;
Ptr				dataP;
CStr255			aStr;
BlockRef		dataBlock;
long			arrayDLRef, arrClassID, id = 0;
ArrayIndexRec	mCoord;
CStr15			tStr, arCSTR;
CStr63			pluginName, name;

	CEquStr(arCSTR, "[Array]");
	if NOT(err = BAPI_GetArrayInfo(api_data, arrObjRefP, &arrayDim, &arrClassID))
	{	if (id = BufferCreate(512, &err))
		{	*mCoord.ind_name = 0;
			if NOT(names)
			{	if NOT(err = BAPI_NameFromClassID(api_data, arrClassID, pluginName))
				{	if NOT(err = BufferAddCString(id, pluginName, NO_ENC, 0))
					{	if NOT(err = BufferAddCString(id, "[", NO_ENC, 0))
						{	CNumToString(arrayDim, tStr);
							if NOT(err = BufferAddCString(id, tStr, NO_ENC, 0))
								err = BufferAddCString(id, "] ", NO_ENC, 0);
						}
					}
				}
			}
			if NOT(err)
			{	for (i = 0; (i < arrayDim) && NOT(err); i++)
				{	dataBlock = 0;
					dataP = nil;
					tObjRef = *arrObjRefP;
					mCoord.ind = i+1;
					err = BAPI_ResolveArrayElem(api_data, &tObjRef, &mCoord, 1, nil);
					if NOT(err)
					{	if NOT(err = BAPI_GetObjInfo(api_data, &tObjRef, nil, name))
						{	if (names)
							{	if NOT(err = BufferAddCString(id, name, NO_ENC, 0))
								{	if (i < arrayDim - 1)
										err = BufferAddCString(id, ", ", NO_ENC, 0);
								}
							}		
							else
							{	if (tObjRef.classID == arrayClassID)
									dataP = arCSTR;
								else if NOT(err = BAPI_ObjToString(api_data, &tObjRef, nil, &dataLen, 0, kExplicitTypeCast))
								{	if (++dataLen < 255)
									{	dataP = aStr;
										dataBlock = 0;
									}
									else
									{	if (dataBlock = NewBlock(dataLen, &err))
										{	LockBlock(dataBlock);
											dataP = GetPtr(dataBlock);
										}
									}
									if NOT(err)
									{	err = BAPI_ObjToString(api_data, &tObjRef, dataP, &dataLen, dataLen, kExplicitTypeCast);
										dataP[dataLen] = 0;
									}
								}
								if NOT(err)
								{	CNumToString(i+1, tStr);
									if NOT(err = BufferAddCString(id, "[", NO_ENC, 0))
									{	if NOT(err = BufferAddCString(id, tStr, NO_ENC, 0))
										{	if NOT(err = BufferAddCString(id, "] ", NO_ENC, 0))
											{	if NOT(err = BufferAddCString(id, name, NO_ENC, 0))
												{	if NOT(err = BufferAddCString(id, "=\'", NO_ENC, 0))
													{	if NOT(err = BufferAddCString(id, dataP, NO_ENC, 0))
															err = BufferAddCString(id, "\' ", NO_ENC, 0);
													}
												}
											}
										}
									}
								}
								if (dataBlock)
									DisposeBlock(&dataBlock);
							}
						}
					}
				}
			}
		}
	}

if NOT(err)
	*idP = id;
else if (id)
	BufferFree(id);

return err;
}
*/
typedef struct {
				long		buffID;
				CStr63		separator;
				long		separatorLen;
				Boolean		alsoName;
				Byte		pad1;
				short		pad2;
			} ToStringCallBackRecord;

//===========================================================================================
static XErr	_ToStringCallBack(long api_data, char *name, ObjRefP element, long param)
{
XErr					err = noErr;
ToStringCallBackRecord	*recP = (ToStringCallBackRecord*)param;
CStr255					aCStr;
Ptr						stringP;
long					stringLen;
BlockRef				ref;

	if NOT(err = BAPI_GetStringBlock(api_data, element, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
	{	if (recP->alsoName)
		{	if NOT(err = BufferAddCString(recP->buffID, name, NO_ENC, 0))
				err = BufferAddChar(recP->buffID, '=');
		}
		if NOT(err)
		{	if NOT(err = BufferAddBuffer(recP->buffID, stringP, stringLen))
				err = BufferAddBuffer(recP->buffID, recP->separator, recP->separatorLen);
		}
		BAPI_ReleaseBlock(&ref);	
	}

return err;
}

typedef struct {
				ObjRefP		arrayObjRefP;
				long		index;
				Boolean		found;
				Boolean		counting;
				short		pad2;
				ObjRefP		countArrayP;
				} _FindRec;

//===========================================================================================
static XErr	_FindCallBack(long api_data, char *elemName, ObjRefP element, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(elemName)
#endif
XErr		err = noErr;
ObjRef		result;
Boolean		res;
_FindRec	*findRecP = (_FindRec*)param;
ObjRef 		objToAdd;

	if NOT(err = BAPI_ExecuteOperation(api_data, findRecP->arrayObjRefP, element, EVAL_EQUA, &result))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &result, &res, kImplicitTypeCast))
		{	if (res)
			{	findRecP->found = true;
				if (findRecP->counting)
				{	BAPI_InvalObjRef(api_data, &objToAdd);
					if NOT(err = BAPI_IntToObj(api_data, findRecP->index+1, &objToAdd))
						err = BAPI_ArrayAddElement(api_data, findRecP->countArrayP, nil, &objToAdd);
				}
				else
					err = XError(kBAPI_Error, Err_BAPI_LoopAbort);
			}
			findRecP->index++;
		}
	}
	
return err;
}

typedef struct {
				ObjRefP		arrayObjRefP;
				long		index;
				long		oper;
				ObjRef		curObj;
				long		curIndex;
				} _MinMaxRec;

//===========================================================================================
static XErr	_MinMaxCallBack(long api_data, char *elemName, ObjRefP element, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(elemName)
#endif
XErr			err = noErr;
ObjRef			result;
Boolean			res;
_MinMaxRec		*minMaxRecP = (_MinMaxRec*)param;

	//if NOT(minMaxRecP->curObj.id)
	if NOT(BAPI_IsObjRefValid(api_data, &minMaxRecP->curObj))
	{	minMaxRecP->curObj = *element;
		minMaxRecP->curIndex = minMaxRecP->index;
	}
	else
	{	if NOT(err = BAPI_ExecuteOperation(api_data, element, &minMaxRecP->curObj, minMaxRecP->oper, &result))
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &result, &res, kImplicitTypeCast))
			{	if (res)
				{	minMaxRecP->curObj = *element;
					minMaxRecP->curIndex = minMaxRecP->index;
				}
			}
		}
	}
	minMaxRecP->index++;
	
return err;
}

typedef struct {
				ObjRef		arrayObjRef;
				long		current;
				long		start;
				long		end;
			} SubArrRec;

//===========================================================================================
static XErr	_SubArrayCallBack(long api_data, char *elemName, ObjRefP element, long param)
{
XErr			err = noErr;
SubArrRec		*subArrRecP = (SubArrRec*)param;
	
	if (subArrRecP->current > subArrRecP->end)
		return XError(kBAPI_Error, Err_BAPI_LoopAbort);
	else if (subArrRecP->current >= subArrRecP->start)
		err = BAPI_ArrayAddElement(api_data, &subArrRecP->arrayObjRef, elemName, element);
	subArrRecP->current++;
		
return err;
}

typedef struct {
				char		*compareFunc;
				long		mode;
				ObjRef		arrayObjRef;
			} _SortRec;

//===========================================================================================
static Boolean	_SortCallBack(long api_data, ObjRefP elem1, ObjRefP elem2, long param, XErr *errP)
{
XErr			err = noErr;
_SortRec		*sortRecP = (_SortRec*)param;
ParameterRec	parameters[4];
ObjRef			result;
Boolean			res;

	*parameters[0].name = 0;
	if NOT(err = BAPI_InvalObjRef(api_data, &parameters[0].objRef))
	{	if NOT(err = BAPI_MakeRef(api_data, &sortRecP->arrayObjRef, &parameters[0].objRef))
		{	BAPI_ClearParameterRec(api_data, &parameters[1]);
			if NOT(err = BAPI_IntToObj(api_data, BAPI_ArrayGetElementIndex(api_data, &sortRecP->arrayObjRef, elem1)/*elem1->id*/, &parameters[1].objRef))
			{	BAPI_ClearParameterRec(api_data, &parameters[2]);
				if NOT(err = BAPI_IntToObj(api_data, BAPI_ArrayGetElementIndex(api_data, &sortRecP->arrayObjRef, elem2)/*elem2->id*/, &parameters[2].objRef))
				{	BAPI_ClearParameterRec(api_data, &parameters[3]);
					if NOT(err = BAPI_IntToObj(api_data, sortRecP->mode, &parameters[3].objRef))
					{	if NOT(err = BAPI_ExecuteFunction(api_data, parameters, 4, sortRecP->compareFunc, &result))
							err = BAPI_ObjToBoolean(api_data, &result, &res, kImplicitTypeCast);
					}
				}
			}
		}
	}
	*errP = err;
	
return res;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_MinMax(long api_data, ExecuteMethodRec *exeMethodRecP, long which)
{
XErr					err = noErr;
//long					pos = 0;
_MinMaxRec				minMaxRec;

	minMaxRec.arrayObjRefP = &exeMethodRecP->paramVarsP->objRef;
	minMaxRec.index = 1;
	if NOT(err = BAPI_InvalObjRef(api_data, &minMaxRec.curObj))
	{	//minMaxRec.curObj.id = 0;
		if (which == k_Min)
			minMaxRec.oper = EVAL_LTH;
		else
			minMaxRec.oper = EVAL_GTH;
		if NOT(err = BAPI_ArrayLoop(api_data, &exeMethodRecP->objRef, _MinMaxCallBack, (long)&minMaxRec))
			err = BAPI_IntToObj(api_data, minMaxRec.curIndex, &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_Find(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
//long		pos = 0;
_FindRec	findRec;
	
	findRec.arrayObjRefP = &exeMethodRecP->paramVarsP->objRef;
	findRec.index = 0;
	findRec.found = false;
	findRec.counting = false;
	err = BAPI_ArrayLoop(api_data, &exeMethodRecP->objRef, _FindCallBack, (long)&findRec);
	if NOT(err)
	{	if NOT(findRec.found)
			findRec.index = 0;
		err = BAPI_IntToObj(api_data, findRec.index, &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_Count(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
//long		pos = 0;
_FindRec	findRec;

	findRec.arrayObjRefP = &exeMethodRecP->paramVarsP->objRef;
	findRec.index = 0;
	findRec.found = false;
	findRec.counting = true;
	findRec.countArrayP = &exeMethodRecP->resultObjRef;
	if NOT(err = BAPI_ArrayToObj(api_data, true, nil, 0, nil, nil, findRec.countArrayP))
	{	err = BAPI_ArrayLoop(api_data, &exeMethodRecP->objRef, _FindCallBack, (long)&findRec);
		//exeMethodRecP->resultObjRef = findRec.countArray;
	}

return err;
}

//===========================================================================================
static XErr	_SetElemClass(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
long		classID;
CStr63		className;
	
	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, className, nil, 63, kImplicitTypeCast))
	{	if (classID = BAPI_ClassIDFromName(api_data, className, false))
		{	if NOT(err = BAPI_SetArrayElemClass(api_data, &exeMethodRecP->objRef, classID))
				exeMethodRecP->sideEffect = true;
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchClass);
	}
	
return err;
}

//===========================================================================================
static XErr	_Reset(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr	err = noErr;

	if NOT(err = BAPI_ArrayReset(api_data, &exeMethodRecP->objRef))
		exeMethodRecP->sideEffect = true;
		
return err;
}

//===========================================================================================
static XErr	_SubArray(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
long		arrayDim;
long		elemClassID, start, end;
Boolean		fixedSize;
//ObjRef		resultArray;

	if NOT(err = BAPI_GetArrayInfo(api_data, &exeMethodRecP->objRef, &arrayDim, &elemClassID, nil))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &start, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &end, kImplicitTypeCast))
			{	if NOT(start)
					start = 1;
				if NOT(end)
					end = arrayDim;
				if ((start <= 0) || (start > arrayDim))
					err = XError(kBAPI_ClassError, ErrBadStartIndex);
				else if (end < 0)
					err = XError(kBAPI_ClassError, ErrBadEndIndex);
				else if (end > (arrayDim + 1))
					end = arrayDim + 1;
				if NOT(err)
				{	if NOT(err = BAPI_FixedSize(api_data, elemClassID, &fixedSize))
					{	if NOT(err = BAPI_ArrayToObj(api_data, fixedSize, nil, 0, nil, nil, &exeMethodRecP->resultObjRef))
						{	SubArrRec	subArrRec;
							
							subArrRec.start = start;
							subArrRec.end = end;
							subArrRec.arrayObjRef = exeMethodRecP->resultObjRef;
							subArrRec.current = 1;
							err = BAPI_ArrayLoop(api_data, &exeMethodRecP->objRef, _SubArrayCallBack, (long)&subArrRec);
							//exeMethodRecP->resultObjRef = resultArray;
						}
					}
				}
			}
		}
	}								

return err;
}

//===========================================================================================
static XErr	_Insert(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
long		pos, arrayDim;

	if NOT(err = BAPI_GetArrayInfo(api_data, &exeMethodRecP->objRef, &arrayDim, nil, nil))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &pos, kImplicitTypeCast))
		{	if NOT(err = BAPI_ArrayInsert(api_data, &exeMethodRecP->objRef, pos, &exeMethodRecP->paramVarsP[1], exeMethodRecP->totParams - 1))
				exeMethodRecP->sideEffect = true;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_Sort(long api_data, ExecuteMethodRec *exeMethodRecP, char *error)
{
XErr						err = noErr;
CStr63						callBackName;
_SortRec					_sortRec;
BAPI_ArraySortCallBack		callBackP;
long						alg, mode;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &mode, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, callBackName, nil, 63, kImplicitTypeCast))
		{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[2].objRef, &alg, kImplicitTypeCast))
			{	if (*callBackName)
				{	_sortRec.compareFunc = callBackName;
					callBackP = _SortCallBack;
				}
				else
					callBackP = nil;
				_sortRec.mode = mode;
				_sortRec.arrayObjRef = exeMethodRecP->objRef;
				if NOT(err = BAPI_ArraySort(api_data, &exeMethodRecP->objRef, mode, alg, callBackP, (long)&_sortRec))
					exeMethodRecP->sideEffect = true;
				else if (err == XError(kBAPI_Error, Err_PrototypeMismatch))
					CEquStr(error, "Compare prototype is: boolean CompareFunc(array *ar, int ind1, int ind2, int mode)");
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_Reverse(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;

	if NOT(err = BAPI_ArrayReverse(api_data, &exeMethodRecP->objRef))
		exeMethodRecP->sideEffect = true;
		
return err;
}

//===========================================================================================
static XErr	_Swap(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr	err = noErr;
long	elem1, elem2;
			
	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP->objRef, &elem1, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &elem2, kImplicitTypeCast))
		{	if NOT(err = BAPI_ArraySwap(api_data, &exeMethodRecP->objRef, elem1, elem2))
				exeMethodRecP->sideEffect = true;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetIndex(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
ObjRef			tObjRef;
ArrayIndexRec	mCoords;

	err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, mCoords.ind_name, nil, 63, kImplicitTypeCast);
	if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
		err = XError(kBAPI_Error, Err_StringTooLong);
	else if NOT(err)
	{	mCoords.ind = 0;
		tObjRef = exeMethodRecP->objRef;
		err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &mCoords, 1, &tObjRef);
		if (err == XError(kBAPI_Error, Err_ArrayElementNotFound))
		{	err = BAPI_InvalObjRef(api_data, &tObjRef);
			//tObjRef.id = 0;
			//err = noErr;
		}
		if NOT(err)	
			err = BAPI_IntToObj(api_data, BAPI_ArrayGetElementIndex(api_data, &exeMethodRecP->objRef, &tObjRef), &exeMethodRecP->resultObjRef);
	}
	
return err;
}

//===========================================================================================
static XErr	_ToString(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr					err = noErr;
ToStringCallBackRecord	rec;
long					buffSize;
Ptr						buffP;
BlockRef				block;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, rec.separator, &rec.separatorLen, 63, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &rec.alsoName, kImplicitTypeCast))
		{	if (rec.buffID = BufferCreate(255, &err))
			{	if NOT(err = BAPI_ArrayLoop(api_data, &exeMethodRecP->objRef, _ToStringCallBack, (long)&rec))
				{	block = BufferGetBlockRefExtSize(rec.buffID, &buffSize, &buffP);
					LockBlock(block);
					if (buffSize)
						err = BAPI_StringToObj(api_data, buffP, buffSize - rec.separatorLen, &exeMethodRecP->resultObjRef);
					else
						err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
				}
				BufferFree(rec.buffID);
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_Add(long api_data, ExecuteMethodRec *exeMethodRecP)
{
ParameterRec	*paramP;
XErr			err = noErr;
int				i, totElems = exeMethodRecP->totParams;

	for (i = 0; i < totElems; i++)
	{	paramP = &exeMethodRecP->paramVarsP[i];
		if NOT(err = BAPI_ArrayAddElement(api_data, &exeMethodRecP->objRef, paramP->name, &paramP->objRef))
			exeMethodRecP->sideEffect = true;
	}
	
return err;
}

//===========================================================================================
static XErr	_SetDim(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr	err = noErr;
long	newDim;
			
	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP->objRef, &newDim, kImplicitTypeCast))
	{	if NOT(err = BAPI_SetArrayDim(api_data, &exeMethodRecP->objRef, newDim))
			exeMethodRecP->sideEffect = true;
	}
	
return err;
}

//===========================================================================================
static XErr	_DeleteObjects(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr	err = noErr;
long	startElem, stopElem;
			
	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP->objRef, &startElem, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &stopElem, kImplicitTypeCast))
		{	if NOT(stopElem)
				stopElem = startElem;
			if NOT(err = BAPI_ArrayDelete(api_data, &exeMethodRecP->objRef, startElem, stopElem))
				exeMethodRecP->sideEffect = true;
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// Ci si deve registrare dando il nome della classe (costruttore), dicendo di 
// che tipo � il plugin e ricevendo la propria classID
static XErr	Array_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;
BAPI_MemberRecord	arrayProperty[TOT_PROPRIETIES] = 
					{	"name[]",	kName,		"string",
						"dim",		kDim,		"int"
					};
					
BAPI_MemberRecord	arrayMethodes[TOT_METHODES] = 
					{	"GetElemClass", kGetElemClass, 	"string GetElemClass(void)",
						"SetElemClass", kSetElemClass, 	"void SetElemClass(string className)",
						"Add", 			kAdd, 			"void Add(nonames obj element...)",
						"SetDim", 		kSetDim, 		"void SetDim(int newDim)",
						"Delete",		kDelete,		"void Delete(int start, int end)",
						"ToString", 	kToString, 		"string ToString(string separator=\", \", boolean alsoName=false)",
						"Index", 		kIndex, 		"int Index(string elementName)",
						"Reverse", 		k_Reverse, 		"void Reverse(void)",
						"Swap", 		k_Swap, 		"void Swap(int index1, int index2)",
						"Find", 		k_Find, 		"int Find(obj element)",
						"Count", 		k_Count, 		"array Count(obj element)",
						"Min", 			k_Min, 			"int Min(void)",
						"Max", 			k_Max, 			"int Max(void)",
						"Reset", 		k_Reset, 		"void Reset(void)",
						"SubArray", 	k_SubArray, 	"array SubArray(int start, int end)",
						"Insert", 		k_Insert, 		"void Insert(nonames int pos, obj elementN...)",
						"Sort", 		k_Sort, 		"void Sort(int mode=asc, string compareFunc, int alg)"
					};

BAPI_MemberRecord	arrayCostants[TOT_COSTANTS] = 
					{	"asc", 		kArraySortAsc,		"int",
						"desc", 	kArraySortDesc,		"int",
						"bubble", 	kSortBubble,		"int",
						"shell", 	kSortShell,			"int"
					};

	if (err = BAPI_NewProperties(api_data, arrayClassID, arrayProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewMethods(api_data, arrayClassID, arrayMethodes, TOT_METHODES, nil))
		return err;		
	if (err = BAPI_NewConstants(api_data, arrayClassID, arrayCostants, TOT_COSTANTS, nil))
		return err;

	err = BAPI_RegisterErrors(api_data, arrayClassID, ARRAY_START_ERR, gArrayErrorsStr, TOT_ERRORS);

return err;
}

//===========================================================================================
static XErr	Array_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	arrayClassID = 0;
	
return noErr;
}

//===========================================================================================
static XErr	Array_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data;
Boolean			fixedSize;
long			totElements = constructorRecP->totVars;
ObjRef			*objP;

	objP = &constructorRecP->varRecsP[0].objRef;
	if (message == kClone)
	{	if (BAPI_GetObjClassID(api_data, objP) == arrayClassID)
			CDebugStr("Array clone: should never happen");
		else
			err = XError(kBAPI_Error, Err_IllegalOperation);
	}
	else
	{	if (constructorRecP->typeCastType == kImplicitTypeCast)
			err = XError(kBAPI_Error, Err_ExplicitTypeCastRequired);
		else
		{	if (totElements)
				fixedSize = _FixedSize(api_data, BAPI_GetObjClassID(api_data, objP));
			else
				fixedSize = false;
			err = BAPI_ArrayToObj(api_data, fixedSize, &constructorRecP->varRecsP[0], totElements, nil, constructorRecP->privateData, &constructorRecP->resultObjRef);
		}
	}
		
return err;
}

//===========================================================================================
// Il risultato va messo in objRef1
static XErr	Array_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
ExecuteOperationRec		*exeOperationRecP = &pbPtr->param.executeOperationRec;
XErr					err= noErr;

	if (exeOperationRecP->operation == EVAL_ADD)
	{
		err = BAPI_ArrayConcat(pbPtr->api_data, &exeOperationRecP->objRef1, &exeOperationRecP->objRef2, &exeOperationRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);

return err;
}

//===========================================================================================
// esegue un metodo e torna il risultato, se void si deve settare resultObjRef a 0
static XErr	Array_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
long				api_data = pbPtr->api_data;
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
CStr63				name;
long				arrayType;

	switch(exeMethodRecP->methodID)
	{	case kGetElemClass:
			if NOT(exeMethodRecP->totParams)
			{	if NOT(err = BAPI_GetArrayInfo(api_data, &exeMethodRecP->objRef, nil, &arrayType, nil))
				{	if NOT(err = BAPI_NameFromClassID(api_data, arrayType, name))
						err = BAPI_StringToObj(api_data, name, CLen(name), &exeMethodRecP->resultObjRef);
				}
			}
			else
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
			break;
		case kSetElemClass:
			err = _SetElemClass(api_data, exeMethodRecP);
			break;
		case kAdd:
			err = _Add(api_data, exeMethodRecP);
			break;
		case kSetDim:
			err = _SetDim(api_data, exeMethodRecP);
			break;
		case kDelete:
			err = _DeleteObjects(api_data, exeMethodRecP);
			break;		
		case kToString:
			err = _ToString(api_data, exeMethodRecP);
			break;
		case kIndex:
			err = _GetIndex(api_data, exeMethodRecP);
			break;
		case k_Reverse:
			err = _Reverse(api_data, exeMethodRecP);
			break;
		case k_Swap:
			err = _Swap(api_data, exeMethodRecP);
			break;
		case k_Find:
			err = _Find(api_data, exeMethodRecP);
			break;
		case k_Count:
			err = _Count(api_data, exeMethodRecP);
			break;
		case k_Min:
			err = _MinMax(api_data, exeMethodRecP, k_Min);
			break;
		case k_Max:
			err = _MinMax(api_data, exeMethodRecP, k_Max);
			break;
		case k_Reset:
			err = _Reset(api_data, exeMethodRecP);
			break;
		case k_SubArray:
			err = _SubArray(api_data, exeMethodRecP);
			break;
		case k_Insert:
			err = _Insert(api_data, exeMethodRecP);
			break;
		case k_Sort:
			err = _Sort(api_data, exeMethodRecP, pbPtr->error);
			break;

		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}

return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	Array_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
ObjRef			tObjRef;
long			api_data = pbPtr->api_data;
ArrayIndexRec	mCoord;
CStr63			name;
long			i, arrayDim;

	if (getPropertyRec->isConstant)
		err = BAPI_IntToObj(api_data, getPropertyRec->propertyID, &getPropertyRec->resultObjRef);
	else switch(getPropertyRec->propertyID)
	{
		case kName:
			mCoord = getPropertyRec->propertyIndex[0];
			if (mCoord.ind || *mCoord.ind_name)
			{	tObjRef = getPropertyRec->objRef;
				if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &mCoord, 1, &tObjRef))
				{	if NOT(err = BAPI_GetObjInfo(api_data, &tObjRef, nil, name))
						err = BAPI_StringToObj(pbPtr->api_data, name, CLen(name), &getPropertyRec->resultObjRef);
				}
			}
			else
			{	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &getPropertyRec->resultObjRef))
				{	if NOT(err = BAPI_GetArrayInfo(api_data, &getPropertyRec->objRef, &arrayDim, nil, nil))
					{	for (i = 0; (i < arrayDim) && NOT(err); i++)
						{	//mCoord.ind = i+1;
							tObjRef = getPropertyRec->objRef;
							if NOT(err = BAPI_ElementOfArray(api_data, &tObjRef, i+1, &tObjRef))
							{	if NOT(err = BAPI_GetObjInfo(api_data, &tObjRef, nil, name))
								{	BAPI_InvalObjRef(api_data, &tObjRef);
									if NOT(err = BAPI_StringToObj(api_data, name, CLen(name), &tObjRef))
										err = BAPI_ArrayAddElement(api_data, &getPropertyRec->resultObjRef, name, &tObjRef);
								}
							}
						}
					}
				}
			}
			break;

		case kDim:
			if NOT(err = BAPI_GetArrayInfo(api_data, &getPropertyRec->objRef, &arrayDim, nil, nil))
				err = BAPI_IntToObj(pbPtr->api_data, arrayDim, &getPropertyRec->resultObjRef);
			break;
			
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	Array_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr			err= noErr;
SetPropertyRec	*setPropertyRecP = &pbPtr->param.setPropertyRec;
ObjRef			tObjRef;
long			api_data = pbPtr->api_data;
ArrayIndexRec	mCoord;
CStr63			name;

	switch(setPropertyRecP->propertyID)
	{
		case kName:
			mCoord = setPropertyRecP->propertyIndex[0];
			if (mCoord.ind || *mCoord.ind_name)
			{	tObjRef = setPropertyRecP->objRef;
				if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, name, nil, 64, kImplicitTypeCast))
					err = BAPI_SetArrayElemName(api_data, &tObjRef, &mCoord, 1, name);
				else if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
					err = XError(kBAPI_Error, Err_TooLongName);
				/*
				if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, &mCoord, 1, &tObjRef))
				{	if NOT(err = BAPI_ObjToString(api_data, &setPropertyRecP->value, name, nil, 63, kImplicitTypeCast))
					{	if (*name)
							err = BAPI_SetObjName(api_data, &tObjRef, name);
						else
						{	err = XError(kBAPI_ClassError, ErrBadElementName);
							CEquStr(pbPtr->error, "Bad name as array index");
						}
					}
				}*/
			}
			else
				err = XError(kBAPI_Error, Err_IllegalOperation);
			break;

		case kDim:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;

		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
static XErr	Array_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
XErr			err = noErr;
BlockRef		dataBlock;
long			arrayDim, id = 0, size, api_data = pbPtr->api_data;
Ptr				p;
Primitive_String	*textP;
Boolean			forDebug, forConstructor;
PrimitiveUnion	*param_d;

	if (typeCast->resultWanted == kBool)
	{	if NOT(err = BAPI_GetArrayInfo(api_data, &typeCast->objRef, &arrayDim, nil, nil))
			typeCast->result.boolValue = (arrayDim != 0);
	}
	else if (typeCast->resultWanted == kCString)
	{	if (typeCast->typeCastType == kExplicitTypeCast)
		{	param_d = &typeCast->result;
			//if (typeCast->resultWanted == kCString)
			//{	
			forConstructor = (param_d->text.variant == kForConstructor);
			forDebug = (param_d->text.variant == kForDebug);
			/*}
			else
			{	forConstructor = false;
				forDebug = false;
			}*/
			if NOT(err = _ArrayToString(api_data, true, &typeCast->objRef, &id, forConstructor, forDebug))
			{	if (dataBlock = BufferGetBlockRef(id, &size))
				{	p = GetPtr(dataBlock);
					LockBlock(dataBlock);
					/*if (typeCast->resultWanted == kCString)
					{	*/
					textP = &param_d->text;
					if (textP->stringP)
					{	if (textP->stringMaxStorage >= (size + 1))
						{	CopyBlock(textP->stringP, p, size);
							textP->stringP[size] = 0;
							textP->stringLen = size;
						}
						else
						{	CopyBlock(textP->stringP, p, textP->stringMaxStorage - 1);
							textP->stringP[textP->stringMaxStorage - 1] = 0;
							textP->stringLen = size;
							err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
						}
					}
					else
						textP->stringLen = size;
					//}
					//else
					//	err = XError(kBAPI_Error, Err_IllegalTypeCast);
				}
				BufferFree(id);
			}
		}
		else
			err = XError(kBAPI_Error, Err_ExplicitTypeCastRequired);
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif
//===========================================================================================
XErr	array_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsArrayPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			arrayClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void array(...)");	// ci va aggiunto nonames nel prototipo
			break;
		case kInit:
			err = Array_Init(pbPtr);
			break;
		case kShutDown:
			err = Array_ShutDown(pbPtr);
			break;
		case kRun:
			// do nothing
			break;
		case kExit:
			// do nothing
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Array_Constructor(pbPtr, message);
			break;
		/*case kClone:
			err = Array_Constructor(pbPtr, true);
			break;*/
		case kDestructor:
			// do nothing
			break;
		case kExecuteOperation:
			err = Array_ExecuteOperation(pbPtr);
			break;
		case kExecuteMethod:
			err = Array_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Array_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Array_SetProperty(pbPtr);
			break;
		/*case kModify:
			err = Array_Modify(pbPtr);
			break;*/
		case kPrimitive:
			err = Array_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif

