/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: CacheItem.c,v 1.8 2008-04-16 14:29:50 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include 	"BfrTime.h"

typedef struct
{
	XFilePath		userPath;
	unsigned long	sum;
	unsigned long	min;
	unsigned long	max;
	unsigned long	last;
	unsigned long	average;
	time_t			lastAccess;
	unsigned long	hits;
	unsigned long	currentUsers;
} CacheItemRecord;

// defines
#define	gsPlugName	"cacheItem"

static 	long	cacheItemClassID;
static 	long	gsApiVersion, gsFileClassID, gsStringClassID;

static 	time_TimeRecToObjRef_Prot		gsTimeRecToObjRef;
static 	time_ObjRefToTimeRec_Prot		gsObjRefToTimeRec;

// Properties
enum{
		kSum = 1,
		kMin,
		kMax,
		kLast,
		kAverage,
		kHits,
		kCurrentUsers,
		kLastAccess,
		kUserPath
	} CacheItem_Property;

#define TOT_PROPERTIES	9

// Methods
enum{
		kFlush = 1
	} CacheItem_Method;
#define TOT_METHODES	1

// Errors
/*
#define	START_ERR	100
enum {
		ErrFileIsNotInCache = START_ERR
		//ErrCantFlushCurrentFile
};

CStr63	gCacheItemErrorsStr[] = 
	{	
		"ErrFileIsNotInCache"
		//"ErrCantFlushCurrentFile"
		};

#define	TOT_ERRORS	1
*/

//===========================================================================================
/*static XErr	_PathFromCacheItem(long api_data, ObjRefP theFileObjRefP, char *filePath)
{
ObjRef	pathObjRef;
XErr	err = noErr;
long	filePathLen;
CStr255	aCStr;

	if NOT(err = BAPI_GetProperty(api_data, theFileObjRefP, "path", 1, nil, &pathObjRef))
	{	if NOT(err = BAPI_ObjToString(api_data, &pathObjRef, filePath, &filePathLen, 255, kExplicitTypeCast))
		{	filePathLen -= 6;
			CopyBlock(aCStr, filePath + 6, filePathLen);		// skip file:/
			aCStr[filePathLen] = 0;
			CEquStr(filePath, aCStr);
		}
	}
	
return err;
}*/

//===========================================================================================
/*static XErr	_SuperConstructor(long api_data, ParameterRec *paramsP, long totParams, long theScope, long theType, ObjRef *resultP)
{
XErr	err = noErr;
ObjRef	fileObjRef;


	if NOT(err = BAPI_Constructor(api_data, TEMP, VARIABLE, nil, gsFileClassID, paramsP, totParams, &fileObjRef))
	{	err = BAPI_NewPrivateObj(api_data, &fileObjRef, theScope, theType, resultP);
		// if NOT(err = BAPI_NewSingleList(api_data, false, &fileObjRef, resultP))
			err = BAPI_AvoidDestructor(api_data, &fileObjRef, kWhole);
	}
	
return err;
}*/

//===========================================================================================
/*static XErr	_Destruct(long dlRef, long objID, long flags, long userData, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
ObjRef		objRef;
XErr		err = noErr;

	objRef.list = dlRef;
	objRef.id = objID;
	objRef.classID = userData;
	objRef.type = 0;
	objRef.scope = 0;
	err = BAPI_Destructor(param, &objRef);
	
return err;
}
*/
//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	cacheItemMethods[TOT_METHODES] = 
					{	"Flush", 		kFlush, 		"void Flush(void)"
					};

BAPI_MemberRecord	cacheItemProperty[TOT_PROPERTIES] = 
					{	"totExecTime", 		kSum,			"unsigned",
						"minExecTime",		kMin,			"unsigned",
						"maxExecTime",		kMax,			"unsigned",
						"lastExecTime",		kLast,			"unsigned",
						"averageExecTime",	kAverage,		"unsigned",
						"hits",				kHits,			"unsigned",
						"currentUsers",		kCurrentUsers,	"unsigned",
						"lastAccess",		kLastAccess,	"time",
						"userPath",			kUserPath,		"string"
						
						
					};

	if (err = BAPI_NewProperties(api_data, cacheItemClassID, cacheItemProperty, TOT_PROPERTIES, nil))
		return err;		

	if (err = BAPI_NewMethods(api_data, cacheItemClassID, cacheItemMethods, TOT_METHODES, nil))
		return err;

	// err = BAPI_RegisterErrors(api_data, cacheItemClassID, START_ERR, gCacheItemErrorsStr, TOT_ERRORS);

//out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	CacheItem_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		timeClID, api_data = pbPtr->api_data;

	timeClID = BAPI_ClassIDFromName(api_data, "time", false);
	gsFileClassID = BAPI_ClassIDFromName(api_data, "file", false);
	gsStringClassID = BAPI_ClassIDFromName(api_data, "string", false);
	if NOT(err = BAPI_GetSymbol(api_data, timeClID, "time_ObjRefToTimeRec", (long*)&gsObjRefToTimeRec))
	{	if NOT(err = BAPI_GetSymbol(api_data, timeClID, "time_TimeRecToObjRef", (long*)&gsTimeRecToObjRef))
			err = _RegisterListMembers(api_data);
	}
		
return err;
}

//===========================================================================================
static XErr	CacheItem_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	cacheItemClassID = 0;
	
return noErr;
}

//===========================================================================================
static XErr	CacheItem_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr				err = noErr;
ConstructorRec		*constructorRecP = &pbPtr->param.constructorRec;
long				api_data = pbPtr->api_data;
long				totParams;
CacheItemRecord		ciRec;
ParameterRec		*paramsP;
CacheItemInfo		itemInfo;
//CStr255				filePath;
//ParameterRec		param;
ObjRef				superObjRef;

	ClearBlock(&ciRec, sizeof(CacheItemRecord));
	if (clone)
	{	
		/*
		21/1/2003
		in realt� la clone non verr� mai chiamate perch� visto che noDestructor la fa 
		biferno da solo (e tiene conto anche del super)

		if (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP[0].objRef) == cacheItemClassID)
		{	tLen = sizeof(CacheItemRecord);
			if NOT(err = BAPI_ReadObj(api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&ciRec, &tLen, 0, nil))
			{	if NOT(err = BAPI_GetSuperObj(api_data, &constructorRecP->varRecsP[0].objRef, &superObjRef))
				{	//BAPI_ClearParameterRec(api_data, &param);
					//param.objRef = superObjRef;
					ObjRef	newSuperObjRef;
					
					BAPI_InvalObjRef(api_data, &newSuperObjRef);
					if NOT(err = BAPI_Clone(api_data, &superObjRef, &newSuperObjRef))
					{	if NOT(err = BAPI_BufferToObjWithSuper(api_data, (Ptr)&ciRec, sizeof(CacheItemRecord), cacheItemClassID, true, &newSuperObjRef, constructorRecP->privateData, &constructorRecP->resultObjRef))
							;//err = BAPI_AvoidDestructor(api_data, &superObjRef, kWhole);
					}
				}
			}
		}
		else*/
		
			err = XError(kBAPI_Error, Err_IllegalOperation);
	}
	else
	{	totParams = constructorRecP->totVars;
		paramsP = constructorRecP->varRecsP;
		// Save the user path
		BAPI_InvalObjRef(api_data, &superObjRef);
		if NOT(err = BAPI_ObjToString(api_data, &paramsP->objRef, ciRec.userPath, nil, 255, kImplicitTypeCast))
		{	if (BAPI_GetObjClassID(api_data, &paramsP->objRef) == gsFileClassID)
			{	//BAPI_ClearParameterRec(api_data, &param);
				//param.objRef = paramsP->objRef;
				err = BAPI_Clone(api_data, &paramsP->objRef, &superObjRef, true);
			}
			else
				err = BAPI_Constructor(api_data, gsFileClassID, paramsP, totParams, &superObjRef);
			if NOT(err)
			{	if NOT(err = CFGetFileInfo(ciRec.userPath + FILE_HD_PREFIX_LEN, &itemInfo))
				{	if (*itemInfo.path)
					{	// CEquStr(ciRec.path, itemInfo.path);
						ciRec.sum = itemInfo.sum;
						ciRec.min = itemInfo.min;
						ciRec.max = itemInfo.max;
						ciRec.last = itemInfo.last;
						ciRec.hits = itemInfo.hits;
						ciRec.currentUsers = itemInfo.currentUsers;
						ciRec.lastAccess = itemInfo.lastAccess;
						if (ciRec.hits)
							ciRec.average = ciRec.sum / ciRec.hits;
						else
							ciRec.average = 0;
					}
					if NOT(err = BAPI_BufferToObjWithSuper(api_data, (Ptr)&ciRec, sizeof(CacheItemRecord), cacheItemClassID, true, &superObjRef, constructorRecP->privateData, &constructorRecP->resultObjRef))
						;//err = BAPI_AvoidDestructor(api_data, &superObjRef, kWhole);
				}
			}
		}
	}
		
return err;
}

//===========================================================================================
static XErr	CacheItem_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				tLen, api_data = pbPtr->api_data;
CacheItemRecord		ciRec;

	tLen = sizeof(CacheItemRecord);
	err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&ciRec, &tLen, 0, nil);	
	if NOT(err)
	{	switch(exeMethodRecP->methodID)
		{	case kFlush:
				err = BAPI_FlushFile(api_data, ciRec.userPath);
				break;
			default:
				err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
				break;
		}
	}

return err;
}

//===========================================================================================
static XErr	CacheItem_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec		*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr				err = noErr;
long				tLen, api_data = pbPtr->api_data;
CacheItemRecord		ciRec;
XDateTimeRec		timeRec;

	if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
	{	tLen = sizeof(CacheItemRecord);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&ciRec, &tLen, 0, nil))
		{	switch(getPropertyRec->propertyID)
			{
				/*case kFile:
					err = BAPI_CloneObj(api_data, &ciRec.superObjRef, nil, TEMP, VARIABLE, &getPropertyRec->resultObjRef);
					break;
				*/
				case kSum:
					err = BAPI_UnsignedToObj(api_data, ciRec.sum, &getPropertyRec->resultObjRef);
					break;
				case kMin:
					err = BAPI_UnsignedToObj(api_data, ciRec.min, &getPropertyRec->resultObjRef);
					break;
				case kMax:
					err = BAPI_UnsignedToObj(api_data, ciRec.max, &getPropertyRec->resultObjRef);
					break;
				case kLast:
					err = BAPI_UnsignedToObj(api_data, ciRec.last, &getPropertyRec->resultObjRef);
					break;
				case kAverage:
					err = BAPI_UnsignedToObj(api_data, ciRec.average, &getPropertyRec->resultObjRef);
					break;
				case kHits:
					err = BAPI_UnsignedToObj(api_data, ciRec.hits, &getPropertyRec->resultObjRef);
					break;
				case kCurrentUsers:
					err = BAPI_UnsignedToObj(api_data, ciRec.currentUsers, &getPropertyRec->resultObjRef);
					break;
				case kLastAccess:
					SecondsToXDateTime(ciRec.lastAccess, &timeRec);
					err = gsTimeRecToObjRef(api_data, &timeRec, &getPropertyRec->resultObjRef);
					break;
				case kUserPath:
					err = BAPI_StringToObj(api_data, ciRec.userPath, CLen(ciRec.userPath), &getPropertyRec->resultObjRef);
					break;
				default:
					err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					break;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);

return err;
}

//===========================================================================================
static XErr	CacheItem_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
XErr				err = noErr;
long				propertyID, tLen, api_data = pbPtr->api_data;
CacheItemRecord		ciRec;
XDateTimeRec 		timeRec;

	tLen = sizeof(CacheItemRecord);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &setPropertyRecP->objRef, (Ptr)&ciRec, &tLen, 0, nil))
	{	propertyID = setPropertyRecP->propertyID;
		switch(propertyID)
		{
			//case kFile:
			//	break;
			case kSum:
				err = BAPI_ObjToUnsigned(api_data, &setPropertyRecP->value, &ciRec.sum, kImplicitTypeCast);
				break;
			case kMin:
				err = BAPI_ObjToUnsigned(api_data, &setPropertyRecP->value, &ciRec.min, kImplicitTypeCast);
				break;
			case kMax:
				err = BAPI_ObjToUnsigned(api_data, &setPropertyRecP->value, &ciRec.max, kImplicitTypeCast);
				break;
			case kLast:
				err = BAPI_ObjToUnsigned(api_data, &setPropertyRecP->value, &ciRec.last, kImplicitTypeCast);
				break;
			case kAverage:
				err = BAPI_ObjToUnsigned(api_data, &setPropertyRecP->value, &ciRec.average, kImplicitTypeCast);
				break;
			case kHits:
				err = BAPI_ObjToUnsigned(api_data, &setPropertyRecP->value, &ciRec.hits, kImplicitTypeCast);
				break;
			case kCurrentUsers:
				err = BAPI_ObjToUnsigned(api_data, &setPropertyRecP->value, &ciRec.currentUsers, kImplicitTypeCast);
				break;
			case kLastAccess:
				if NOT(err = gsObjRefToTimeRec(api_data, &setPropertyRecP->value, &timeRec))
					XDateTimeToSeconds(&timeRec, &ciRec.lastAccess);
				break;
			case kUserPath:
				err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
				break;
			default:
				err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
				break;
		}
		if NOT(err)
			BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&ciRec, tLen);
	}
	
return err;
}

//===========================================================================================
static XErr	CacheItem_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
//PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
//XErr			err = noErr;

	return XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
}

//===========================================================================================
static XErr	CacheItem_SuperIsChanged(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	return XError(kBAPI_Error, Err_IllegalOperation);	// per ora
}

//===========================================================================================
/*static XErr	CacheItem_GetSuperObj(Biferno_ParamBlockPtr pbPtr)
{
GetSuperObjRec	*getSuperObjRec = &pbPtr->param.getSuperObjRec;
long			tLen;
XErr			err = noErr;

	tLen = sizeof(ObjRef);
	err = BAPI_GetObj(pbPtr->api_data, &getSuperObjRec->objRef, (Ptr)&getSuperObjRec->superObjRef, &tLen, offsetof(CacheItemRecord, fileSuperObjRef)+1, nil);

return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	cacheItem_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			cacheItemClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.extendedClass, "file");
			CEquStr(pbPtr->param.registerRec.constructor, "void cacheItem(string path, int openMode, int permission)");
			break;
		case kInit:
			err = CacheItem_Init(pbPtr);
			break;
		case kShutDown:
			err = CacheItem_ShutDown(pbPtr);
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = CacheItem_Constructor(pbPtr, false);
			break;
		case kClone:
			err = CacheItem_Constructor(pbPtr, true);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = CacheItem_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = CacheItem_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = CacheItem_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = CacheItem_TypeCast(pbPtr);
			break;
		case kSuperIsChanged:
			err = CacheItem_SuperIsChanged(pbPtr);
			break;
		/*case kGetSuperObj:
			err = CacheItem_GetSuperObj(pbPtr);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
#pragma export off
#endif

