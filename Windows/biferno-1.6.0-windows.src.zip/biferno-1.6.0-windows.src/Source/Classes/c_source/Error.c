/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Error.c,v 1.13 2006-03-03 12:06:41 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include 	<string.h>
//#include 	<stdlib.h>

static long	errClassID;
static long		gsApiVersion;

typedef struct
	{
	long			err;
	long			errType;
	long			classID;
	long			eFileLineNum;
	long			eFileOffset;		// to know the char in the line
	BlockRef		eFileLine;
	long			eFileLineLength;
	//long			eTotMsgs;
	CStr63			eClass;
	CStr63			eSubError;
	CStr255			eName;
	CStr255			descr;
	CStr255			eMsg;	// compatibility (the last message)
	CStr255			eSubErrDescr;
	CStr255			eClassNote;
	CStr255			eFilePath;
	BlockRef		eTable;
	long			eTableLength;
	long			eLastMultiStrLine;
	//ErrorMsgRecord	eMsgRecord;
	} ErrRecord;

// Properties
enum{
		k_errNum = 1,
		k_eName,
		k_eMsg,
		//k_eMsgList,
		k_eClass,
		k_eSubErr,
		k_eSubErrDescr,
		k_eClassNote,
		k_eFilePath,
		k_eFileLineNum,
		k_eFileOffset,
		k_eFileLine,
		k_eTable,
		//k_eStack,
		k_eDescr,
		k_eResumable,
		k_eLastMultiStrLine
	};
#define TOT_PROPRIETIES	15

// Properties
enum{
		kOnErrorFunction = 1,
		kOnErrorState,
		kOnErrorSuspend,
		kOnErrorResume,
		kThrowException,
		kUpdate
	};
#define TOT_METHODS	6

/*typedef struct {
			ObjRef	objRef;
			Ptr		thisPtr;
			} GlobErrRec;
*/

//===========================================================================================
/*static long	_ErrFromSubErr(ErrRecord *errRecP)
{
long	errNum;

	//errNum = atoi(errRecP->eSubError);
	CStringToNum(errRecP->eSubError, &errNum);

return errNum;
}*/

//===========================================================================================
/*static XErr	_UpdateEMsgRecord(long api_data, ObjRef *errRefP)
{
XErr		err = noErr;
ErrRecord	errRec;
long		tLen;

	tLen = sizeof(ErrRecord);
	if NOT(err = BAPI_ReadObj(api_data, errRefP, (Ptr)&errRec, &tLen, 0, nil))
	{	if NOT(err = BAPI_GetErrorMsgRecord(api_data, &errRec.eMsgRecord))
			err = BAPI_ModifyObj(api_data, errRefP, (Ptr)&errRec, sizeof(ErrRecord));
	}
	
return err;
}*/

//===========================================================================================
static void	_SetSubErr(ErrRecord *errRecP, char *message)
{
Ptr		tempP, saveP;
long	subErrNum, tempLen;
Byte	saveChar;

	*errRecP->eSubError = 0;
	*errRecP->eSubErrDescr = 0;
	CEquStr(errRecP->eClassNote, message);
	/* eSubError
	if begins with ':' -> set eSubError to number, eSubErrDescr to descr, eClassNote empty
	*/
	tempP = message;
	tempLen = CLen(tempP);
	if (tempLen && (*tempP == ':'))
	{	tempP++;
		tempLen--;
		saveP = tempP;
		if (tempP = strchr(tempP, ':'))
		{	saveChar = *tempP;
			*tempP = 0;
			if (IsIntNumber(saveP, &subErrNum))
			{	CNumToString(subErrNum, errRecP->eSubError);
				if (saveP + tempLen > ++tempP)
				{	tempLen = CLen (tempP);
					SkipSpaceAndTab(&tempP, &tempLen);
					if (tempLen)
						CEquStr(errRecP->eSubErrDescr, tempP);
				}
			}
			else
			{	*tempP = saveChar;
				CEquStr(errRecP->eSubError, "?");
				CEquStr(errRecP->eSubErrDescr, saveP);
			}
			*errRecP->eClassNote = 0;
		}
	}
}

//===========================================================================================
static XErr	_IntToErrRec(long api_data, XErr theError, ErrRecord *errRecP)
{
XErr			err = noErr;
CStr255			eNameStr, classErrNotes;
CStr63			errClass;
long			tot, errValue, errType;
CStr63			title[1];
CStr255			msg[1];

	if NOT(err = BAPI_GetErrDescription(api_data, theError, eNameStr, classErrNotes, errClass, errRecP->descr, nil, errRecP->classID, nil))
	{	XErrorGetTypeValue(theError, &errValue, &errType);
		errRecP->err = errValue;
		CEquStr(errRecP->eName, eNameStr);
		//errRecP->eTotMsgs = 0;
		if NOT(err = BAPI_GetErrorMsgRecord(api_data, nil/*&errRecP->eMsgRecord*/, &errRecP->eLastMultiStrLine))
		{	if NOT(BAPI_GetMessageRecords(api_data, title, msg, &tot, 1))
			{	if (tot)
				{	if (CLen(title[0]) + 1 + CLen(msg[0]) <= 255)
					{	CEquStr(errRecP->eMsg, title[0]);
						CAddStr(errRecP->eMsg, " ");
						CAddStr(errRecP->eMsg, msg[0]);
					}
				}
				else
					*errRecP->eMsg = 0;
			}
			if (errType == kBAPI_ClassError)
				CEquStr(errRecP->eClass, errClass);
			else
				*errRecP->eClass = 0;
			if NOT(*errRecP->eSubError)
				_SetSubErr(errRecP, classErrNotes);
			/*if (*initP++ == ':')
				initP++;
			//  ex ((*initP++ == ':') && 
			if (strP = strchr(initP, ':')
			{	tLen = strP - initP;
				iLen = CLen(initP);
				if (tLen > 63)
					tLen = 63;
				CopyBlock(errRecP->eSubError, initP, tLen);
				errRecP->eSubError[tLen] = 0;
				
				tLen = iLen - (strP - initP) - 1;
				if (tLen > 255)
					tLen = 255;
				CopyBlock(errRecP->eSubErrDescr, strP + 1, tLen);
				if (zapped = ZapText((Byte*)errRecP->eSubErrDescr, tLen))
					tLen -= zapped;
				errRecP->eSubErrDescr[tLen] = 0;
			}
			else
			{	*errRecP->eSubError = 0;
				*errRecP->eSubErrDescr = 0;
			}*/
			if NOT(err = BAPI_GetCurrentFilePath(api_data, errRecP->eFilePath, &errRecP->eFileLineNum, nil, nil))
			{	if NOT(err = BAPI_GetCurrentFileOffset(api_data, &errRecP->eFileOffset))
				{	if NOT(err = BAPI_GetStatus(api_data, &errRecP->eFileLine, &errRecP->eFileLineLength, &errRecP->eTable, &errRecP->eTableLength, nil, nil/*&errRecP->eStack, &errRecP->eStackLength*/))
						err = DecodeIsolatinFast(GetPtr(errRecP->eFileLine), false, &errRecP->eFileLineLength);
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_OnErrorResume(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(exeMethodRecP)
#endif
XErr		err = noErr;
CStr255		funcName;
char		*strP;

	if (totParams == 1)
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, funcName, nil, 255, kImplicitTypeCast))
			strP = funcName;
	}
	else if NOT(totParams)
		strP = nil;
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

	if NOT(err)	
		err = BAPI_OnError(api_data, kResume, strP, nil);

return err;
}

//===========================================================================================
static XErr	_OnErrorSuspend(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(exeMethodRecP)
#endif
XErr		err = noErr;

	if NOT(totParams)
		err = BAPI_OnError(api_data, kSuspend, nil, nil);

return err;
}

//===========================================================================================
static XErr	_OnErrorState(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(exeMethodRecP)
#endif
XErr		err = noErr;
Boolean		state;

	if NOT(totParams)
	{	if NOT(err = BAPI_OnError(api_data, kGetState, nil, &state))
			err = BAPI_BooleanToObj(api_data, state, &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_OnErrorFunction(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(exeMethodRecP)
#endif
XErr		err = noErr;
CStr255		functionName;

	if NOT(totParams)
	{	if NOT(err = BAPI_OnError(api_data, kGetFunction, functionName, nil))
			err = BAPI_StringToObj(api_data, functionName, CLen(functionName), &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_ThrowException(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
long		errNum, errType;
CStr255		className;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &errNum, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, className, nil, 255, kImplicitTypeCast))
		{	if (*className)
				errType = kBAPI_ClassError;
			else
				errType = kBAPI_Error;
			err = BAPI_Exception(api_data, errType, errNum, className, true);
		}
	}

return err;
}

//===========================================================================================
static XErr	_Update(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr		err = noErr;
ErrRecord	errRec;
long		tLen;

	tLen = sizeof(ErrRecord);
	if NOT(err = BAPI_ReadObj(api_data, &exeMethodRecP->objRef, (Ptr)&errRec, &tLen, 0, nil))
	{	if NOT(err = _IntToErrRec(api_data, XError(errRec.errType, errRec.err), &errRec))
		{	if NOT(err = BAPI_ModifyObj(api_data, &exeMethodRecP->objRef, (Ptr)&errRec, sizeof(ErrRecord)))
				exeMethodRecP->sideEffect = true;
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	_CreateMsgArray(long api_data, ErrRecord *errRecP, ObjRef *arrayP)
{
long			totItems, i;
ObjRef			tObjRef;
XErr			err = noErr;
char			*strP;
ErrorMsgRecord	*eMsgP = &errRecP->eMsgRecord;
CStr255			title;

	totItems = eMsgP->totMsg;
	if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, arrayP))
	{	for (i = 0; (i < totItems) && NOT(err); i++)
		{	if NOT(err = BAPI_InvalObjRef(api_data, &tObjRef))
			{	strP = eMsgP->msg[i].msg;
				if NOT(err = BAPI_StringToObj(api_data, strP, CLen(strP), &tObjRef))
				{	sprintf(title, "%d) %s", i+1, eMsgP->msg[i].title);
					err = BAPI_ArrayAddElement(api_data, arrayP, title, &tObjRef);
				}
			}
		}
	}

return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Err_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
BAPI_MemberRecord	errProperty[TOT_PROPRIETIES] = 
					{	"errNum", 		k_errNum,		"int",
						"name", 		k_eName,		"string",
						"msg",			k_eMsg,			"string",
						"errClass", 	k_eClass,		"string",
						"subErr",		k_eSubErr,		"string",
						"subErrDescr",	k_eSubErrDescr,	"string",
						"classNote", 	k_eClassNote,	"string",
						"path", 		k_eFilePath,	"string",
						"lineNum",		k_eFileLineNum,	"int",
						"fileOffset",	k_eFileOffset,	"int",
						"line", 		k_eFileLine,	"string",
						"table", 		k_eTable,		"string",
						//"stack", 		k_eStack,		"string",
						"descr",		k_eDescr,		"string",
						"resumable",	k_eResumable,	"boolean",
						"lastMultiStrLine",	k_eLastMultiStrLine,	"int"
						//"msgList[]",	k_eMsgList,		"string"
					};

BAPI_MemberRecord	errMethods[TOT_METHODS] = 
					{	"Function",			kOnErrorFunction,	"static string Function(void)",
						"State",			kOnErrorState,		"static boolean State(void)",
						"Suspend",			kOnErrorSuspend,	"static void Suspend(void)",
						"Resume",			kOnErrorResume,		"static void Resume(string funcName)",
						"ThrowException",	kThrowException,	"static void ThrowException(int errNum, string class)",
						"Update",			kUpdate,			"void Update(void)"
					};
BAPIErrorRecord		*bapiErrorDescrsP;

long	startErr, totErrors;
//CStr63	*errorStrings;
	
	if (err = BAPI_NewProperties(pbPtr->api_data, errClassID, errProperty, TOT_PROPRIETIES, nil))
		return err;		

	if (err = BAPI_NewMethods(pbPtr->api_data, errClassID, errMethods, TOT_METHODS, nil))
		return err;		

	if NOT(err = BAPI_GetErrorStrings(pbPtr->api_data, &startErr, &bapiErrorDescrsP, &totErrors))
	{	BlockRef	bl;
		CStr63		*tempP, *saveP;
		int			i;
		
		if (bl = NewBlockLocked(sizeof(CStr63) * totErrors, &err, (Ptr*)&saveP))
		{	//LockBlock(bl);
			tempP = saveP;// = (CStr63*)GetPtr(bl);
			for (i = 0; i < totErrors; i++, bapiErrorDescrsP++, tempP++)
				CEquStr(*tempP, bapiErrorDescrsP->name);
			err = BAPI_RegisterErrors(pbPtr->api_data, errClassID, startErr, saveP, totErrors);
			DisposeBlock(&bl);
		}
	}

return err;
}

//===========================================================================================
// Finalizzazioni
static XErr	Err_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	errClassID = 0;
	
return noErr;
}

//===========================================================================================
/*static XErr	Err_Run(Biferno_ParamBlockPtr pbPtr)
{
ErrRecord		errRec;
XErr			err = noErr;
//ObjRef			globErrObjRef;
//GlobErrRec		*globErrRecPtr;

	errRec.err = noErr;
	*errRec.eName = 0;
	*errRec.eMsg = 0;
	*errRec.eClass = 0;
	*errRec.eClassNote = 0;
	*errRec.eSubError = 0;
	*errRec.eSubErrDescr = 0;
	errRec.eFileLineNum = 0;
	errRec.eFileLine = 0;
	errRec.eTable = 0;
	if NOT(err = BAPI_GetCurrentFilePath(pbPtr->api_data, errRec.eFilePath, nil, nil, nil))
	{	if NOT(err = BAPI_BufferToObj(pbPtr->api_data, (Ptr)&errRec, sizeof(ErrRecord), errClassID, true, "err", GLOBAL, VARIABLE, nil))
		{	
		}
	}
return err;
}*/

//===========================================================================================
static XErr	Err_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean cloning)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			tLen, api_data = pbPtr->api_data;
ErrRecord		errRec;
CStr255			eSubError;

	ClearBlock(&errRec, sizeof(ErrRecord));
	if (cloning && (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP[0].objRef) == errClassID))
	{	ErrRecord	s_errRec;
	
		tLen = sizeof(ErrRecord);
		if NOT(err = BAPI_ReadObj(pbPtr->api_data, &constructorRecP->varRecsP[0].objRef, (Ptr)&s_errRec, &tLen, 0, nil))
		{	errRec = s_errRec;
			errRec.eFileLine = errRec.eTable = 0;
			if (s_errRec.eFileLine)
				err = DuplicateBlock(s_errRec.eFileLine, &errRec.eFileLine);
			if NOT(err)
			{	if (s_errRec.eTable)
					err = DuplicateBlock(s_errRec.eTable, &errRec.eTable);
			}
		}
	}
	else
	{	if (constructorRecP->totVars >= 1)
		{	// long	errType;
			CStr63	className;
			
			if NOT(err = BAPI_ObjToInt(api_data, &constructorRecP->varRecsP[0].objRef, &errRec.err, kImplicitTypeCast))
			{	if (constructorRecP->totVars >= 2)
				{	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[1].objRef, eSubError, nil, 255, kImplicitTypeCast))
						_SetSubErr(&errRec, eSubError);
				}
				if NOT(err)
				{	if (constructorRecP->totVars >= 3)
					{	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[2].objRef, className, nil, 63, kImplicitTypeCast))
						{	if (*className)
							{	errRec.errType = kBAPI_ClassError;
								errRec.classID = BAPI_ClassIDFromName(api_data, className, false);
							}
							else
								errRec.errType = kBAPI_Error;
						}
					}
					else
						errRec.errType = kBAPI_Error;
					if ((errRec.errType != kBAPI_Error) && (errRec.errType != kBAPI_ClassError))
						errRec.errType = kBAPI_Error;
				}
			}
		}
		else
			err = XError(kBAPI_Error, Err_PrototypeMismatch);
	}
	if NOT(err)
		err = BAPI_BufferToObj(api_data, (Ptr)&errRec, sizeof(ErrRecord), errClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);

if (err)
{	if (errRec.eFileLine)
		DisposeBlock(&errRec.eFileLine);
	if (errRec.eTable)
		DisposeBlock(&errRec.eTable);
}
return err;
}

//===========================================================================================
static XErr	Err_Destructor(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
ErrRecord		errRec;
long			tLen;

	tLen = sizeof(ErrRecord);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&errRec, &tLen, 0, nil))
	{	if (tLen)
		{	if (errRec.eFileLine)
				DisposeBlock(&errRec.eFileLine);
			if (errRec.eTable)
				DisposeBlock(&errRec.eTable);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Err_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
ErrRecord			errRec1, errRec2;
Boolean				res;
long				tLen;
long				api_data = pbPtr->api_data;

	if (exeOperationRecP->operation == EVAL_EQUA)
	{	tLen = sizeof(ErrRecord);
		if NOT(err = BAPI_ReadObj(api_data, &exeOperationRecP->objRef1, (Ptr)&errRec1, &tLen, 0, nil))
		{	tLen = sizeof(ErrRecord);
			if NOT(err = BAPI_ReadObj(api_data, &exeOperationRecP->objRef2, (Ptr)&errRec2, &tLen, 0, nil))
			{	res = ((errRec1.err == errRec2.err) && (errRec1.errType == errRec2.errType));
				err = BAPI_BooleanToObj(pbPtr->api_data, res, &exeOperationRecP->resultObjRef);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);

return err;
}

//===========================================================================================
static XErr	Err_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
long				totParams = exeMethodRecP->totParams;

	switch(exeMethodRecP->methodID)
	{
		case kOnErrorFunction:
			err = _OnErrorFunction(exeMethodRecP, totParams, api_data);
			break;
		case kOnErrorState:
			err = _OnErrorState(exeMethodRecP, totParams, api_data);
			break;
		case kOnErrorSuspend:
			err = _OnErrorSuspend(exeMethodRecP, totParams, api_data);
			break;
		case kOnErrorResume:
			err = _OnErrorResume(exeMethodRecP, totParams, api_data);
			break;
		case kThrowException:
			err = _ThrowException(api_data, exeMethodRecP);
			break;
		case kUpdate:
			err = _Update(api_data, exeMethodRecP);
			break;

		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}

return err;
}

//===========================================================================================
// si deve tornare l'oggetto rappresentante la propriet� propertyName
static XErr	Err_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
ErrRecord		errRec;
long			tLen;
CStr255			descr;
long			api_data = pbPtr->api_data;
Boolean			resumable;

	tLen = sizeof(ErrRecord);
	if NOT(err = BAPI_ReadObj(api_data, &getPropertyRec->objRef, (Ptr)&errRec, &tLen, 0, nil))
	{	switch(getPropertyRec->propertyID)
		{
			case k_errNum:
				err = BAPI_IntToObj(api_data, errRec.err, &getPropertyRec->resultObjRef);
				break;
			case k_eName:
				err = BAPI_StringToObj(api_data, errRec.eName, CLen(errRec.eName), &getPropertyRec->resultObjRef);
				break;
			case k_eMsg:
				err = BAPI_StringToObj(api_data, errRec.eMsg, CLen(errRec.eMsg), &getPropertyRec->resultObjRef);
				break;
			case k_eClass:
				err = BAPI_StringToObj(api_data, errRec.eClass, CLen(errRec.eClass), &getPropertyRec->resultObjRef);
				break;
			case k_eSubErr:
				err = BAPI_StringToObj(api_data, errRec.eSubError, CLen(errRec.eSubError), &getPropertyRec->resultObjRef);
				break;
			case k_eSubErrDescr:
				err = BAPI_StringToObj(api_data, errRec.eSubErrDescr, CLen(errRec.eSubErrDescr), &getPropertyRec->resultObjRef);
				break;
			case k_eClassNote:
				err = BAPI_StringToObj(api_data, errRec.eClassNote, CLen(errRec.eClassNote), &getPropertyRec->resultObjRef);
				break;
			case k_eFilePath:
				CEquStr(descr, "file:/");
				CAddStr(descr, errRec.eFilePath);
				err = BAPI_StringToObj(api_data, descr, CLen(descr), &getPropertyRec->resultObjRef);
				break;
			case k_eFileLineNum:
				err = BAPI_IntToObj(api_data, errRec.eFileLineNum, &getPropertyRec->resultObjRef);
				break;
			case k_eFileOffset:
				err = BAPI_IntToObj(api_data, errRec.eFileOffset, &getPropertyRec->resultObjRef);
				break;
			case k_eFileLine:
				if (errRec.eFileLine)
					err = BAPI_StringToObj(api_data, GetPtr(errRec.eFileLine), errRec.eFileLineLength, &getPropertyRec->resultObjRef);
				else
					err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
				break;
			case k_eTable:
				if (errRec.eTable)
				{	LockBlock(errRec.eTable);
					err = BAPI_StringToObj(api_data, GetPtr(errRec.eTable), errRec.eTableLength, &getPropertyRec->resultObjRef);
					UnlockBlock(errRec.eTable);
				}
				else
					err = BAPI_StringToObj(api_data, "", 0, &getPropertyRec->resultObjRef);
				break;
			case k_eDescr:
				err = BAPI_StringToObj(api_data, errRec.descr, CLen(errRec.descr), &getPropertyRec->resultObjRef);
				//if NOT(err = BAPI_GetErrDescription(api_data, XError(errRec.errType, errRec.err), nil, nil, nil, descr, nil, 0, nil))
				//	err = BAPI_StringToObj(api_data, descr, CLen(descr), &getPropertyRec->resultObjRef);				
				break;
			case k_eResumable:
				if NOT(err = BAPI_GetErrDescription(api_data, XError(errRec.errType, errRec.err), nil, nil, nil, descr, &resumable, 0, nil))
					err = BAPI_BooleanToObj(api_data, resumable, &getPropertyRec->resultObjRef);				
				break;
			case k_eLastMultiStrLine:
				err = BAPI_IntToObj(api_data, errRec.eLastMultiStrLine, &getPropertyRec->resultObjRef);
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}

return err;
}

//===========================================================================================
// si deve settare la propriet� di objRef
static XErr	Err_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;
ErrRecord		errRec;
long			tLen;

	tLen = sizeof(ErrRecord);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &setPropertyRec->objRef, (Ptr)&errRec, &tLen, 0, nil))
	{	switch(setPropertyRec->propertyID)
		{
			case k_eMsg:
				if NOT(err = BAPI_ObjToString(pbPtr->api_data, &setPropertyRec->value, errRec.eMsg, nil, 255, kImplicitTypeCast))
					err = BAPI_ModifyObj(pbPtr->api_data, &setPropertyRec->objRef, (Ptr)&errRec, sizeof(ErrRecord));
				break;
			default:
				err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
				break;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	Err_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
CStr255			eNameStr, aCStr;
long			cLen;
Ptr				p;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
//TypeCastParam	*param_s = &typeCast->param1, *param_d = &typeCast->param2;
long			api_data = pbPtr->api_data;
ErrRecord		errRec;
PrimitiveUnion	*param_d;
//ParameterRec	parameter;
long			tLen;

	/*switch(param_s->which)
	{	case kInt:
		case kLong:
		case kUnsigned:
		case kDouble:
		case kBool:
		case kCString:
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
			break;
		case kObj:
			if (param_s->u.objRef.classID == errClassID)
			{	long tLen = sizeof(ErrRecord);
				err = BAPI_GetObj(api_data, &param_s->u.objRef, (Ptr)&errRec, &tLen, 0, nil);
			}
			else
			{	if NOT(err = BAPI_ObjToInt(api_data, &param_s->u.objRef, &aLong, kImplicitTypeCast))
					err = _IntToErrRec(api_data, aLong, &errRec);
			}
			break;
	}
	*/
	tLen = sizeof(ErrRecord);
	if NOT(err = BAPI_ReadObj(api_data, &typeCast->objRef, (Ptr)&errRec, &tLen, 0, nil))
	{	param_d = &typeCast->result;
		switch(typeCast->resultWanted)
		{	case kInt:
				param_d->intValue = errRec.err;
				break;
			case kLong:
				param_d->longValue = errRec.err;
				break;
			case kUnsigned:
				param_d->uIntValue = errRec.err;
				break;
			case kDouble:
				param_d->doubleValue = errRec.err;
				break;
			case kBool:
				param_d->boolValue = (errRec.err != 0);
				break;
			case kCString:
				CNumToString(errRec.err, aCStr);
				if NOT(param_d->text.variant == kForConstructor)
				{	CAddStr(aCStr, " (");
					if NOT(BAPI_GetErrDescription(api_data, XError(errRec.errType, errRec.err), eNameStr, nil, nil, nil, nil, errRec.classID, nil))
						CAddStr(aCStr, eNameStr);
					CAddStr(aCStr, ")");
				}
				cLen = CLen(aCStr);
				if (p = param_d->text.stringP)
				{	if (param_d->text.stringMaxStorage >= (cLen + 1))
					{	CopyBlock(p, aCStr, cLen);
						p[cLen] = 0;
						param_d->text.stringLen = cLen;
					}
					else
					{	CopyBlock(p, aCStr, param_d->text.stringMaxStorage - 1);
						p[param_d->text.stringMaxStorage - 1] = 0;
						param_d->text.stringLen = cLen;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->text.stringLen = cLen;
				break;
			case kChar:
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
				break;
			/*case kObj:
				BAPI_ClearParameterRec(api_data, &parameter);
				errRec.eFileLine = 0;
				errRec.eTable = 0;
				if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&errRec, sizeof(ErrRecord), errClassID, true, nil, TEMP, VARIABLE, &parameter.objRef))
					err = BAPI_Clone(api_data, TEMP, VARIABLE, nil, param_d->objRef.classID, &parameter, 1, &param_d->objRef);
				break;*/
			default:
				CDebugStr("Unknown TypeCast Parameter");
				break;
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	error_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "error");
			gsApiVersion = pbPtr->param.registerRec.api_version;
			errClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = true;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.constructor, "void error(int theError, string theSubError, string class)");
			//err = BAPI_RegisterSymbol(pbPtr->api_data, errClassID, "error_UpdateEMsgRecord", (long)_UpdateEMsgRecord);
			break;
		case kInit:
			err = Err_Init(pbPtr);
			break;
		case kShutDown:
			err = Err_ShutDown(pbPtr);
			break;
		case kRun:
			//err = Err_Run(pbPtr);
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = Err_Constructor(pbPtr, false);
			break;
		case kClone:
			err = Err_Constructor(pbPtr, true);
			break;
		case kDestructor:
			err = Err_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = Err_ExecuteOperation(pbPtr);
			//err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Err_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Err_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Err_SetProperty(pbPtr);
			break;
		/*case kModify:
			err = Err_Modify(pbPtr);
			break;*/
		case kPrimitive:
			err = Err_TypeCast(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


