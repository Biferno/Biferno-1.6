#if __MACOSX__
	#include <QuickTime/ImageCompression.h>
#else
	#include <ImageCompression.h>
#endif

#include "XLib.h"

#include "ConvIm.h"

#include "XFilesMacPrivate.h"
#include "XMemoryPrivate.h"

typedef struct
	{
	long 			thumbType;			// => in	(possibili valori: 'JPEG', 'PICT', 0 (no thumb))
	long 			thumbJPEGQuality;	// => in	(quelle del QuickTime)
	long 			thumbDimension;		// => in	(lato maggiore)
	Boolean			forWWW;				// => in	(se � per Internet mette il JPEG header al posto del thumbDescr
	Byte			pad;
	short			wwwHeaderSize;
	long			width;				// => out
	long			height;				// => out
	short			depth;				// => out
	short			version;			// => out
	short			hRes;				// => out
	short			vRes;				// => out
	long			thwidth;			// => out
	long			thheight;			// => out
	long			thDescrSize;		// => out
	long			thSize;				// => out
	} ImageInfo, *ImageInfoP;

static	long				gsQuickTimeAvail = -1;
static	short				gsQuickTimeVersion;
static	unsigned long		gsParserLastTicks;
static	CStr255 			httpJPEGHeadStr = "HTTP/1.0 200 OK\r\nMIME-Version: 1.0\r\nServer: WebSTAR\r\nContent-type: image/jpeg\r\n\r\n";
static	RGBColor			HImyWhite = {0xFFFF, 0xFFFF, 0xFFFF}, HImyBlack = {0x0000, 0x0000, 0x0000};

	enum{
		kErrQTUnavailable = 1,
		kErrQTInvalidVersion
		};
		

//#define	CHECKSTACK_FORTHUMB(rowBytes)	(((long)(rowBytes & 0x3FFF) * 6L) < (StackSpace() / 2))
#define	CHECKSTACK_FORTHUMB(rowBytes)	(true)	// nessun controllo su stack miniature

//===========================================================================================
static XErr	MySetHandleSize(Handle h, long newSize)
{
	SetHandleSize(h, newSize);
	return MemError();
}

//===========================================================================================
static void	MyDisposeHandle(Handle *hP)
{
	if (*hP)
	{	DisposeHandle(*hP);
		*hP = 0;
	}
	else
		DebugStr("\pConvert Image: Handle nil");
}

//===========================================================================================
static Handle	MyNewHandle(long size, XErr *errP)
{
Handle	h;
	
	h = NewHandle(size);
	*errP = MemError();
	
return h;
}

#pragma mark-
//===========================================================================================
static GWorldPtr _BuildGWorld(long Rows, long Columns, short PixelDepth, PaletteHandle palH, XErr *GworldErr)
{
QDErr			graphicErr;
GWorldPtr		gWorldPtr;
GWorldFlags		flags = useTempMem;
Rect			myGWorldRect;
CTabHandle		cTabH = nil;
long			ignore, MemDisponibile, MemNecess; 
OSErr			GworldErrShort;

	myGWorldRect.top 	= myGWorldRect.left = 0;
	myGWorldRect.bottom = Rows;
	myGWorldRect.right	= Columns;
	
	if (palH)
	{
		if (cTabH = (CTabHandle)MyNewHandle(sizeof(ColorTable), GworldErr))
		{	Palette2CTab(palH, cTabH);
			(*cTabH)->ctSeed = GetCTSeed();
		}
		else
		{
			// *GworldErr = MemError();
			return nil;
		}
	}

	if 	(PixelDepth == 32)
		MemNecess = (long)Rows * ((((long)Columns * 4) + 8) & 0xFFFFFFFC);		
	else if (PixelDepth == 4)
		MemNecess = (long)Rows * ((((long)Columns / 2) + 8) & 0xFFFFFFFC);
	else if (PixelDepth == 1)
		MemNecess = (long)Rows * ((((long)Columns / 8) + 8) & 0xFFFFFFFC);
	else
		MemNecess = (long)Rows * (((long)Columns + 8) & 0xFFFFFFFC);
	MemNecess += (2048/* ex sizeof(ColorGrafPort)*/ + (2 * sizeof(PixMap)) + (10L * 1024L));
	if (cTabH)
		MemNecess += GetHandleSize((Handle)cTabH);

	MemDisponibile = MaxMem(&ignore);

	if (MemDisponibile > MemNecess)
		graphicErr = NewGWorld(&gWorldPtr, PixelDepth, &myGWorldRect, cTabH, nil, 0);
	else
		graphicErr = memFullErr;

	if (graphicErr)
	{	Handle	sysCuscinoH;
		if (sysCuscinoH = TempNewHandle(64L * 1024L, &GworldErrShort))	// let the system breathe
			{
			MemDisponibile = TempMaxMem(&ignore);
			if (MemDisponibile > MemNecess)
				{
				graphicErr = NewGWorld(&gWorldPtr, PixelDepth, &myGWorldRect, cTabH, nil, flags);
				if ( (graphicErr == cTempMemErr) || (graphicErr == cNoMemErr) )
					graphicErr = memFullErr;
				}
			DisposeHandle(sysCuscinoH);
			}
		else
			*GworldErr = GworldErrShort;
	}

	if (cTabH)
		DisposeCTable(cTabH);

	if (*GworldErr = graphicErr)
		return nil;
	else
		return gWorldPtr;
}

//===========================================================================================
static void _GetScaledPictRect(Rect *imageRectP, Rect *dstRectPtr, short maxSide)
{
long		realPicH, realPicW;

*(long*)dstRectPtr = 0;
realPicH = imageRectP->bottom - imageRectP->top;
realPicW = imageRectP->right - imageRectP->left;
if (realPicH > realPicW)
	{
	dstRectPtr->right = (realPicW * maxSide) / realPicH;
	dstRectPtr->bottom = maxSide;
	}
else
	{
	dstRectPtr->right = maxSide;
	dstRectPtr->bottom = (realPicH * maxSide) / realPicW;
	}
}

//===========================================================================================
static pascal OSErr _THProgressProc (short s, Fixed f, long userData)
{
#pragma unused(s, f, userData)
	
	if ((TickCount() - gsParserLastTicks) > 60)
	{	YieldToAnyThread();
		gsParserLastTicks = TickCount();
	}

return noErr;
}

//===========================================================================================
static OSErr _JpegCompression(PixMapHandle pmHand, Handle *ThumbHP, ImageInfoP infoPtr, Boolean addHTTPHeader, Boolean forFile)
{
XErr					err = noErr;
long					maxSize = 0;
Ptr						dataP;
ImageDescriptionHandle	imageDescH = nil;
Rect					bounds = (**pmHand).bounds;
Handle					tmpHand;
long					quality;
long					headerLen;
long					thSize, descrSize;
ICMProgressProcRecord	progRec;
/*#ifdef powerc
	RoutineDescriptor	progProcRec = BUILD_ROUTINE_DESCRIPTOR(uppICMProgressProcInfo, _THProgressProc);
						progProcPtr = &progProcRec;
#else
	progProcPtr = THProgressProc;
#endif
*/

if NOT(gsQuickTimeAvail)
	return kErrQTUnavailable;

headerLen = 0;
descrSize = 0;
if NOT(forFile)
{	if NOT(tmpHand = MyNewHandle(1, &err))
		return err;
}
else
{
	tmpHand = *ThumbHP;
}
quality = infoPtr->thumbJPEGQuality;
if (err = GetMaxCompressionSize(pmHand, &bounds, 0, quality, 'jpeg', bestCompressionCodec, &maxSize))
	{
	if NOT(forFile)
		MyDisposeHandle(&tmpHand);
	return err;
	}
imageDescH = (ImageDescriptionHandle)MyNewHandle(4, &err);
if NOT(err)
{
	if (addHTTPHeader)
		headerLen = CLen(httpJPEGHeadStr);
	if NOT(err = MySetHandleSize(tmpHand, headerLen + maxSize))
	{	HLock(tmpHand);
		dataP = *tmpHand + headerLen;
		progRec.progressProc = NewICMProgressUPP(_THProgressProc);
		progRec.progressRefCon = 0L;
		err = FCompressImage(pmHand, &bounds, 32, quality, 'jpeg',
							bestCompressionCodec, nil, 0, maxSize, nil, &progRec, imageDescH,  dataP);
		DisposeICMProgressUPP(progRec.progressProc);
		HUnlock(tmpHand);
		if NOT(err)
		{
			infoPtr->thDescrSize = (*imageDescH)->idSize;
			infoPtr->thSize = thSize = (*imageDescH)->dataSize;
			infoPtr->wwwHeaderSize = headerLen;
			if (forFile)
			{
				MySetHandleSize(tmpHand, thSize);
				*ThumbHP = tmpHand;
			}
			else if (addHTTPHeader)
			{	CopyBlock(*tmpHand, httpJPEGHeadStr, headerLen);
				MySetHandleSize(tmpHand, headerLen + thSize);
				MyDisposeHandle(ThumbHP);
				*ThumbHP = tmpHand;
			}
			else
			{	descrSize = infoPtr->thDescrSize;
				MySetHandleSize(*ThumbHP, thSize + descrSize);
				if NOT(err = LMGetMemErr())
				{	CopyBlock(**ThumbHP, *imageDescH, descrSize);
					CopyBlock(**ThumbHP + headerLen + descrSize, *tmpHand, thSize);
					MyDisposeHandle(&tmpHand);
				}
			}
		}
	}
	MyDisposeHandle((Handle*)&imageDescH);
}
return err;
}

//===========================================================================================
static OSErr _MakeJpegThumb(PixMapHandle pmHand, Rect *rectPtr, Handle *ThumbHP, ImageInfoP infoPtr)
{
Rect			scalRect;
GWorldPtr		gwPtr;
CGrafPtr		cgPtr;
GDHandle		gdH;
XErr			err;
PixMapHandle	pixMapH;

_GetScaledPictRect(rectPtr, &scalRect, infoPtr->thumbDimension);
infoPtr->thwidth = scalRect.right - scalRect.left;
infoPtr->thheight = scalRect.bottom - scalRect.top;
if NOT(infoPtr->thwidth)
	infoPtr->thwidth = 2;
if NOT(infoPtr->thheight)
	infoPtr->thheight = 2;
scalRect.top = scalRect.left = 0;
scalRect.bottom = infoPtr->thheight;
scalRect.right = infoPtr->thwidth;
if (gwPtr = _BuildGWorld(infoPtr->thheight, infoPtr->thwidth, 32, nil, &err))
	{
	GetGWorld(&cgPtr, &gdH);
	SetGWorld(gwPtr, 0);
	ForeColor(blackColor);
	BackColor(whiteColor);
	pixMapH = GetGWorldPixMap(gwPtr);
	LockPixels(pixMapH);
	CopyBits((BitMap*)*pmHand, (BitMap*)*pixMapH, rectPtr, &scalRect, ditherCopy, 0);
	err = _JpegCompression(pixMapH, ThumbHP, infoPtr, infoPtr->forWWW, false);
	DisposeGWorld(gwPtr);
	SetGWorld(cgPtr, gdH);
	}

return err;
}

//===========================================================================================
static OSErr _PixMap2Thumb(PixMapHandle pmHand, Rect *rectPtr, long ColorDepth, Handle *ThumbHP, ImageInfoP infoPtr)
{
OSErr	err = noErr;

if NOT(gsQuickTimeAvail)
	return kErrQTUnavailable;

if (infoPtr->thumbType == 'PICT')
	err = MakeThumbnailFromPixMap(pmHand, rectPtr, ColorDepth, (PicHandle)*ThumbHP, nil);
else if (infoPtr->thumbType == 'JPEG')
	err = _MakeJpegThumb(pmHand, rectPtr, ThumbHP, infoPtr);
return err;
}

//===========================================================================================
static OSErr	_ThumbFromGWorld(GWorldPtr gWorldPtr, Rect *theRectP, long depth, ImageInfoP infoPtr, Handle *theThumbNail)
{
XErr			err = 0;
PixMapHandle	pmHand;
Handle			ThumbH = 0;

	pmHand = GetGWorldPixMap(gWorldPtr);
	LockPixels(pmHand);
	if CHECKSTACK_FORTHUMB((*pmHand)->rowBytes)
		{	
		if (ThumbH = MyNewHandle(sizeof(Picture), &err) )
			{
			if (err = _PixMap2Thumb(pmHand, theRectP, depth, &ThumbH, infoPtr))				
				{	MyDisposeHandle((Handle*)&ThumbH);
					ThumbH = nil;
				}
			}
		}
	else
		err = -149;			// notEnoughStack;

*theThumbNail = (Handle)ThumbH;
return err;
}

//===========================================================================================
static OSErr	_GetImage(FSSpecPtr specPtr, GWorldPtr *gwPtrP, PaletteHandle *palHandP, Rect *imageRectP, ImageInfoP infoPtr, Handle *ThumbHP)
{
GraphicsImportComponent	gi;
ImageDescriptionHandle	imageDescH;
XErr					err;
GDHandle				curGDH;
GWorldPtr				gwP, curGWPtr;
Rect					imageRect;
long					depth;
PixMapHandle			pmHand;

	if NOT(gsQuickTimeAvail)
		return kErrQTUnavailable;
	else if (gsQuickTimeVersion < 0x0250)	// prima della 2.5
		return kErrQTInvalidVersion;
	
	if NOT(err = GetGraphicsImporterForFile(specPtr, &gi))
	{	if NOT(err = GraphicsImportGetImageDescription(gi, &imageDescH))
		{	if (imageDescH)
			{	imageRect.top = imageRect.left = 0;
				imageRect.right = (*imageDescH)->width;
				imageRect.bottom = (*imageDescH)->height;
				if (infoPtr)
				{	infoPtr->height = imageRect.bottom;
					infoPtr->width = imageRect.right;
					infoPtr->depth = (*imageDescH)->depth;
					infoPtr->version = (*imageDescH)->version;
					infoPtr->hRes = (*imageDescH)->hRes;
					infoPtr->vRes = (*imageDescH)->vRes;
				}
				if (imageRectP)
					*imageRectP = imageRect;
				if ((*imageDescH)->depth == 24)	// non puoi passare 24 a NewGWorld
					depth = 32;
				else
					depth = (*imageDescH)->depth;
				if (gwP = _BuildGWorld(imageRect.bottom, imageRect.right, depth, nil, &err))	
				{	GetGWorld(&curGWPtr,&curGDH);
					SetGWorld(gwP, nil);
					if NOT(err = GraphicsImportSetGWorld(gi, gwP, nil))
					{	if NOT(err = GraphicsImportSetBoundsRect(gi, &imageRect))
						{	pmHand = GetGWorldPixMap(gwP);
							LockPixels(pmHand);
							err = GraphicsImportDraw(gi);
							UnlockPixels(pmHand);
						}
					}
					SetGWorld(curGWPtr, curGDH);
					if (err)
						DisposeGWorld(gwP);
					else
					{	if (palHandP)
							*palHandP = nil;
						if (gwPtrP)
							*gwPtrP = gwP;
						else	// => for thumb
						{	err = _ThumbFromGWorld(gwP, &imageRect, (*imageDescH)->depth, infoPtr, ThumbHP);
							DisposeGWorld(gwP);
						}
					}
				}
				DisposeHandle((Handle)imageDescH);
			}
			else
				err = memFullErr;
		}
		CloseComponent(gi);
	}

return err;
}

//===========================================================================================
/*
inQuality is 0 ... 100

value are:

	codecLosslessQuality          = 0x00000400,
	codecMaxQuality               = 0x000003FF,
	codecMinQuality               = 0x00000000,
	codecLowQuality               = 0x00000100,
	codecNormalQuality            = 0x00000200,
	codecHighQuality              = 0x00000300
*/
static long		_GetQuality(long inQuality)
{
long	n;

	n = (double)inQuality * (double)(codecLosslessQuality - codecMinQuality) / (double)(100 - 0);
	
return n;
}

#pragma mark-
//===========================================================================================
XErr		BifernoConvertImage(char *srcfile, char *dstfile, int jpegQuality, double scale, int width, int height, char *errMessage)
{
XErr			err = noErr, err2 = noErr;
FSSpec			fileSpec, destSpec;
long			aLong, xsize, ysize;
GWorldPtr		gwPtr = nil, newGWPtr = nil;
PaletteHandle 	paletH;
Rect			destRect, imageRect;
PixMapHandle	pixMapH = nil, newPixMapH = nil;
ImageInfo 		jpegInfo;
CGrafPtr		curPort;
GDHandle		curGdh;
Handle			jpegH;
short			fileRefNum;
long			inOutCount;

	if (errMessage)
		*errMessage = 0;
	if (gsQuickTimeAvail == -1)
	{	if NOT(Gestalt(gestaltQuickTime, &aLong))	
		{	gsQuickTimeAvail = 1;
			if NOT(Gestalt(gestaltQuickTimeVersion, &aLong))
				gsQuickTimeVersion = *(short*)&aLong;
		}
		else
		{	gsQuickTimeAvail = 0;
			err = kErrQTUnavailable;
		}
	}
	if NOT(err)
	{	if NOT(err = GetMacOSSpecExt(srcfile, &fileSpec, false, true))
		{	if NOT(err = _GetImage(&fileSpec, &gwPtr, &paletH, &imageRect, nil, nil))
			{	xsize = imageRect.right - imageRect.left;
				ysize = imageRect.bottom - imageRect.top;
				if NOT(err = GetRescaledDims(xsize, ysize, scale, &width, &height, errMessage))
				{	pixMapH = GetGWorldPixMap(gwPtr);
					LockPixels(pixMapH);
					ClearBlock(&jpegInfo, sizeof(ImageInfo));
					jpegInfo.thumbJPEGQuality = _GetQuality(jpegQuality);
					if ((width != xsize) || (height != ysize))
					{	destRect.top = destRect.left = 0;
						destRect.right = width;
						destRect.bottom = height;
						if (newGWPtr = _BuildGWorld(destRect.bottom, destRect.right, 32, paletH, &err))
						{	newPixMapH = GetGWorldPixMap(newGWPtr);
							LockPixels(newPixMapH);
							GetGWorld(&curPort, &curGdh);
							SetGWorld((CGrafPtr)newGWPtr, curGdh);
							RGBForeColor(&HImyBlack);
							RGBBackColor(&HImyWhite);	
							CopyBits((BitMap*)*pixMapH, (BitMap*)*newPixMapH, &imageRect, &destRect, ditherCopy, 0);
							SetGWorld(curPort, curGdh);
							UnlockPixels(pixMapH);
							DisposeGWorld(gwPtr);
							pixMapH = newPixMapH;
							gwPtr = newGWPtr;
						}
						else
						{				
							// faccio CopyBits su se stesso
							GetGWorld(&curPort, &curGdh);
							SetGWorld((CGrafPtr)gwPtr, curGdh);
							RGBForeColor(&HImyBlack);
							RGBBackColor(&HImyWhite);	
							CopyBits((BitMap*)*pixMapH, (BitMap*)*pixMapH, &imageRect, &destRect, ditherCopy, 0);
							pixMapH = GetGWorldPixMap(gwPtr);
							LockPixels(pixMapH);
							(*pixMapH)->bounds = destRect;
							SetGWorld(curPort, curGdh);
						}
					}
					if NOT(err)
					{	if (jpegH = MyNewHandle(sizeof(Picture), &err))
						{	if NOT(err = _JpegCompression(pixMapH, &jpegH, &jpegInfo, false, true))				
							{	if NOT(err = GetMacOSSpecExt(dstfile, &destSpec, true, true))
								{	err = FSpCreate(&destSpec, 'ogle', 'JPEG', smSystemScript);
									if NOT(err)
									{	if NOT(err = FSpOpenDF(&destSpec, fsRdWrPerm, &fileRefNum))
										{	inOutCount = GetHandleSize(jpegH);
											HLock(jpegH);
											err = FSWrite(fileRefNum, &inOutCount, *jpegH);
											err2 = FSClose(fileRefNum);
											if (err2 && NOT(err))
												err = err2;
										}
									}
								}
							}
							MyDisposeHandle(&jpegH);
						}
					}
					UnlockPixels(pixMapH);
				}
				if (paletH) 
					DisposePalette(paletH);
				DisposeGWorld(gwPtr);
			}
		}
	}
	
	if (err)
	{	switch(err)
		{
			case kErrQTUnavailable:
				CEquStr(errMessage, "BifernoConvertImage: kErrQTUnavailable, Quick Time is needed");
				break;
		
			case kErrQTInvalidVersion:
				CEquStr(errMessage, "BifernoConvertImage: kErrQTInvalidVersion, Newer Quick Time is needed");
				break;
		
			default:
				if NOT(*errMessage)
					sprintf(errMessage, "BifernoConvertImage: Unknown error (%d)", err);
				break;
		}
	}
	
return err;
}

