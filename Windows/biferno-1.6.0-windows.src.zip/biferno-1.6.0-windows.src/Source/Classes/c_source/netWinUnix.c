/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: netWinUnix.c,v 1.7 2008-02-18 14:32:49 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include "def.h"
#include "net.h"

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#include <errno.h>

#ifdef __UNIX_XLIB__
	#include <unistd.h>
	#include <sys/socket.h>
	#include <sys/socketvar.h>
	#include <sys/types.h>
	#include <sys/file.h>
	#include <sys/un.h>
	#include <netdb.h>
	#include <pthread.h>
	#include <netinet/in.h>
#endif
extern NetLogFunction 	gLog;				/* pointer to logging function, or nil if none */

extern BlockRef 		gAll;				/* pointer to list of open streams */
extern BlockRef 		gClose;				/* pointer to list of closing streams */
extern BlockRef 		gFree;				/* pointer to list of available preallocated stream buffers */

#ifdef __UNIX_XLIB__
	#define	ZEROERRNO		errno = noErr
#else
	#define	ZEROERRNO	0
#endif

//===========================================================================================
static XErr		_GetErr(void)
{
	#ifdef __UNIX_XLIB__
		return errno;
	#else
		return GetLastError();
	#endif
}

/*----------------------------------------------------------------------------
	NetNameToAddr 
	
	Translate a domain name to an IP address.
	
	Entry: 	name = C-format domain name string, optionally followed by a
				comma, space, or colon and then the port number.
			defaultPort = default port number.
	
	Exit:	function result = error code.
			*addr = IP address.
			*port = port number.
----------------------------------------------------------------------------*/

XErr NetNameToAddr (char *name, unsigned short defaultPort, NetAddress *addr, unsigned short *port)
{
XErr 			err = noErr/*, giveTimeErr = noErr*/;
short 			i;
static short 	numCache = 0;
//Boolean 		done = false;
CStr255 		domainName;
char 			*p, *q;
static struct 	{
				CStr255 	domainName;
				NetAddress	addr;
				} cache[10];
Boolean			found = false;

	p = name;
	q = domainName;
	while (*p != 0 && *p != ',' && *p != ' ' && *p != ':') *q++ = *p++;
	*q = 0;
	q = p;
	while (*q == ' ') q++;
	if (*q == 0) {
		*port = defaultPort;
	} else {
		p++;
		if (!isdigit(*p)) return netDNRErr;
		q = p+1;
		while (isdigit(*q)) q++;
		while (*q == ' ') q++;
		if (*q != 0) return netDNRErr;
		*port = atoi(p);
	}
	
	XThreadsEnterCriticalSection();
	for (i=0; i<numCache; i++) {
		if (strcmp(domainName, cache[i].domainName) == 0)
		{	*addr = cache[i].addr;
			found = true;
			break;
		}
	}
	if NOT(found)
	{	if NOT(err = GetHostByNameSafe(domainName, addr))
		{	if (numCache < 10)
			{	strcpy(cache[numCache].domainName, domainName);
				cache[numCache].addr = *addr;
				numCache++;
			}
		}
	}
	XThreadsLeaveCriticalSection();
	
	/*
	ex:
	
	XThreadsEnterCriticalSection();
	ZEROERRNO;
	if ((*addr = gethostbyname(domainName)) == NULL)
		err = _GetErr();
	if NOT(err)
	{
	On Win32 the hostent struct pointer is not valid 
	across threads (... to study better the problem!).
	On MacOSX crashes if uncomment this code ... mmh for now disable caching dns names
	/*#if !__WIN_XLIB__ && !__MACOSX__
		if (numCache < 10)
		{	strcpy(cache[numCache].domainName, domainName);
			cache[numCache].addr = *addr;
			numCache++;
		}
	#endif
	}
	*/
	if (err == ENOENT)
		err = netOpenStreamErr;

return err;
}

/*----------------------------------------------------------------------------
	NetGetMyAddrStr 
	
	Get this Mac's IP address as a dotted-decimal string

	Exit:	function result = error code.
			addrStr = this Mac's IP address, as a C-format string.
				You must allocate at least 16 bytes for this string.
				The returned string has max length 15.
----------------------------------------------------------------------------*/
	
XErr NetGetMyAddrStr (char *addrStr)
{
XErr 				err = noErr;

	ZEROERRNO;
	if (gethostname(addrStr, 255) < 0)
		err = _GetErr();

return err;
}

/*----------------------------------------------------------------------------
	NetGetMyName 
	
	Get this Mac's domain name, if any.
	
	Exit:	function result = error code.
			name = domain name of this Mac, as a C-format string.
----------------------------------------------------------------------------*/

XErr NetGetMyName (CStr255 name)
{
XErr 	err = noErr;
int		len;

	ZEROERRNO;
	if (gethostname(name, 255) < 0)
		err = _GetErr();
	if NOT(err)
	{	len = strlen(name);
		if (name[len-1] == '.')
			name[len-1] = 0;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

/*----------------------------------------------------------------------------
	DoTCPCreate 
	
	Create a stream.
	
	Entry:	s = pointer to stream.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr DoTCPCreate(BlockRef sBlock)
{
XErr 			err = noErr;
TStreamPtr		s = (TStreamPtr)GetPtr(sBlock);
	
	ZEROERRNO;
	s->socketRef = socket(PF_INET, SOCK_STREAM, 0);	
	if (s->socketRef < 0)
		err = _GetErr();
	if NOT(err)
	{	XThreadsEnterCriticalSection();
		s->next = gAll;
		gAll = sBlock;
		XThreadsLeaveCriticalSection();
	}

return err;
}



/*----------------------------------------------------------------------------
	DoTCPRelease 
	
	Release a stream.
	
	Entry:	s = pointer to stream.
	
	Exit:	function result = error code.
	
	Any active connection is also aborted, if necessary, before releasing 
	the stream.
	
	With MacTCP, the function uses its own TCPiopb parameter block instead 
	of the one inside the stream block, because the one inside the stream block
	may already be in use by some other asynchronous operation.
----------------------------------------------------------------------------*/

XErr DoTCPRelease (BlockRef sBlock, long userData)
{
XErr 		err = noErr;
BlockRef 	xs, next, prev = nil;
TStreamPtr s;
	
	if (sBlock == nil)
		return noErr;
	s = (TStreamPtr)GetPtr(sBlock);
#if __WIN_XLIB__
	closesocket(s->socketRef);
#else
	close(s->socketRef);	
#endif
	XThreadsEnterCriticalSection();
	for (xs = gAll; xs != nil; xs = next)
	{	next = ((TStreamPtr)GetPtr(xs))->next;
		if (xs == sBlock) {
			if (prev == nil) {
				gAll = next;
			} else {
				((TStreamPtr)GetPtr(prev))->next = next;
			}
			break;
		}
		prev = xs;
	}
	XThreadsLeaveCriticalSection();
	
	if (gLog != nil)
		LogMessage(s, ' ', "Stream closed.", userData);

return err;
}



/*----------------------------------------------------------------------------
	DoTCPActiveOpen 
	
	Open an active stream.
	
	Entry:	s = pointer to stream.
			addr = IP address of server.
			port = port number of service.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr DoTCPActiveOpen(TStreamPtr s, NetAddress *addr, unsigned short port, long userData)
{
XErr 				err = noErr;
// InetAddress 		*inetAddr;
struct 				sockaddr_in saddr;
	
	saddr.sin_family = AF_INET;
	memcpy(&saddr.sin_addr, addr->h_addr_list0, addr->h_length);
	saddr.sin_port = htons(port);
	// now we connect to the server
	ZEROERRNO;
	if ((connect(s->socketRef, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in))) < 0)
		err = _GetErr();
	if NOT(err)
	{	
		s->localPort = port;	// Valerio: 21/9/2001 see Mac code, I wrote "port"
		if (gLog != nil)
			LogMessage(s, ' ', "Stream opened.", userData);
	}
	return err;
}



/*----------------------------------------------------------------------------
	DoTCPPassiveOpen 
	
	Open a passive stream.
	
	Entry:	s = pointer to stream.
	
	Exit:	function result = error code.
			*port = assigned unused local port number.
			
	Note: Unlike the other "DoTCPxxx" functions, DoTCPPassiveOpen is
	asynchronous. The passive stream is opened, but the function does not
	wait for another host to connect. The function is used by 
	NetFTPDataPassiveOpen to open passive FTP data streams. The caller must 
	call NetFTPDataWaitForConnection to wait for the FTP server to connect
	to the stream.
----------------------------------------------------------------------------*/

XErr DoTCPPassiveOpen (TStreamPtr s, unsigned short *port)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(s, port)
#endif
	// da fare, serve solo per ftp
return noErr;
}



/*----------------------------------------------------------------------------
	DoTCPSend 
	
	Send data on a stream.
	
	Entry:	s = pointer to stream.
			data = pointer to data to send.
			len = length of data to send.
			push = true to set push data flag. This flag should be set on
				the last buffer of data being sent on the stream before
				a response from the server is expected. This flag is needed
				to keep IBM VM/CMS happy. (Note OT handles this internally,
				so this is needed only with MacTCP.)
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr DoTCPSend (TStreamPtr s, Ptr data, unsigned short len)
{
XErr 	err = noErr;
int		c_socket;
long	totalSent, bytesSent, bytesToSent, t;

	s->in = s->out = s->buf;
	c_socket = s->socketRef;
	totalSent = 0;
	bytesToSent = len;
	do {
		t = bytesToSent;
		ZEROERRNO;
		bytesSent = send(c_socket, data + totalSent, t, 0);
		if (bytesSent < 0)
			err = _GetErr();
		if (err)
			break;
		totalSent += bytesSent;
		bytesToSent -= bytesSent;
		s->bytesOut += bytesSent;
	} while (totalSent < len);

return err;
}



/*----------------------------------------------------------------------------
	DoTCPRcv 
	
	Reveive data on a stream.
	
	Entry:	s = pointer to stream.
			data = pointer to data buffer.
			*len = length of data buffer.
	
	Exit:	function result = error code.
			*len = number of bytes received.
----------------------------------------------------------------------------*/

XErr DoTCPRcv (TStreamPtr s, Ptr data, unsigned short *len)
{
XErr 		err = noErr;
long		bytesRcv;

	ZEROERRNO;
	bytesRcv = recv(s->socketRef, data, *len, 0);
	if (bytesRcv < 0)
	{	err = _GetErr();
		//printf("DoTCPRcv Return %d Err %d Len %d\n", bytesRcv, err, *len);
	}
	/*else if NOT(bytesRcv)
	{
		printf("DoTCPRcv Return 0 %d Err %d Len %d\n", bytesRcv, err, *len);
	}*/
	if NOT(err)
	{	*len = (unsigned short)bytesRcv;
		s->bytesIn += bytesRcv;
	}

return err;
}

