/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: ServerInfo.c,v 1.10 2004-05-04 13:21:55 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

// defines
#define	gsPlugName	"serverInfo"

// Properties
#define TOT_PROPRIETIES	3
enum{
		k_domain = BAPI_Domain,
		/*k_port = BAPI_Port,
		k_directoryPath = BAPI_DirectoryPath,
		k_versionNumber = BAPI_VersionNumber,
		k_totalConnections = BAPI_TotalConnections,
		k_currentUserLevel = BAPI_CurrentUserLevel,
		k_highestUserLevel = BAPI_HighestUserLevel,
		k_currentFreeMemory = BAPI_CurrentFreeMemory,
		k_minimumFreeMemory = BAPI_MinimumFreeMemory,
		k_totalConTimeouts = BAPI_TotalConnTimeouts,
		k_totalConBusies = BAPI_TotalConBusies,
		k_totalConDenied = BAPI_TotalConDenied,
		k_totalBytesSent = BAPI_TotalBytesSent,*/
		//k_upSinceDate = BAPI_UpSinceDate,
		k_ServerName,
		k_ServerRoot
	};

static 	long	gsApiVersion, serverInfoClassID;

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	serverProperty[TOT_PROPRIETIES] = 
					{	
						"domain",				k_domain,				"static string",
						/*"port",					k_port,					"static int",
						"directoryPath",		k_directoryPath,		"static string",
						"versionNumber",		k_versionNumber,		"static string",
						"totalConnections",		k_totalConnections,		"static int",
						"currentUserLevel",		k_currentUserLevel,		"static int",
						"highestUserLevel",		k_highestUserLevel,		"static int",
						"currentFreeMemory",	k_currentFreeMemory,	"static int",
						"minimumFreeMemory",	k_minimumFreeMemory,	"static int",
						"totalConTimeouts",		k_totalConTimeouts,		"static int",
						"totalConBusies",		k_totalConBusies,		"static int",
						"totalConDenied",		k_totalConDenied,		"static int",
						"totalBytesSent",		k_totalBytesSent,		"static int",*/
						//"upSinceDate",			k_upSinceDate,			"static string",
						"serverName",			k_ServerName,			"static string",
						"root",					k_ServerRoot,			"static string"
					};

	if (err = BAPI_NewProperties(api_data, serverInfoClassID, serverProperty, TOT_PROPRIETIES, nil))
		return err;		

//out:
return err;
}

//===========================================================================================
static XErr	_GetServerRoot(GetPropertyRec *getPropertyRec, long api_data)
{
XErr		err = noErr;
char		serverRoot[512];
CStr255		tempStr;
int			tempStrLen;

	if NOT(err = BAPI_GetCurrentBasePath(api_data, serverRoot, true))
	{	if (*serverRoot)
		{	CEquStr(tempStr, FILE_HD_PREFIX);
			CAddStr(tempStr, serverRoot);
			tempStrLen = CLen(tempStr);
		}
		else
			tempStrLen = 0;
		err = BAPI_StringToObj(api_data, tempStr, tempStrLen, &getPropertyRec->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_GetHeaderOutField(long api_data, char *fieldName, ObjRef *objRefP)
{
ObjRef			pageIn, headIn;
XErr			err = noErr;
Boolean			isDef;
ParameterRec	fieldNameS;

	if NOT(err = BAPI_IsVariableDefined(api_data, "pageOut", GLOBAL, &isDef, &pageIn))
	{	if (isDef)
		{	ClearBlock(&fieldNameS, sizeof(ParameterRec));
			if NOT(err = BAPI_StringToObj(api_data, fieldName, CLen(fieldName), &fieldNameS.objRef))
			{	if NOT(err = BAPI_GetProperty(api_data, &pageIn, "head", 1, nil, &headIn))
				{	err = BAPI_ExecuteMethod(api_data, &headIn, &fieldNameS, 1, "GetField", objRefP, nil);
					if (err)
						err = BAPI_StringToObj(api_data, "", 0, objRefP);
				}
			}
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	ServerInfo_Register(Biferno_ParamBlockPtr pbPtr)
{
	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	serverInfoClassID = pbPtr->param.registerRec.pluginID;
	
return noErr;
}

//===========================================================================================
static XErr	ServerInfo_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	//initRecP->plugin_global_data = nil;
	//CEquStr(initRecP->constructor, "static void serverInfo(void)");
	err = _RegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	ServerInfo_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr				err = noErr;

	err = XError(kBAPI_Error, Err_NoSuchMethod);
	
return err;
}

//===========================================================================================
static XErr	ServerInfo_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			which, api_data = pbPtr->api_data;

	switch(which = getPropertyRec->propertyID)
	{
		case k_domain:
		/*case k_port:
		case k_directoryPath:
		case k_versionNumber:
		case k_totalConnections:
		case k_currentUserLevel:
		case k_highestUserLevel:
		case k_currentFreeMemory:
		case k_minimumFreeMemory:
		case k_totalConTimeouts:
		case k_totalConBusies:
		case k_totalConDenied:
		case k_totalBytesSent:*/
			err = BAPI_GetHTTPParam(api_data, which, &getPropertyRec->resultObjRef);
			break;
		/*case k_upSinceDate:
			// in futuro dovr� essere l' up since del web server, non di Biferno come � oggi
			err = BAPI_GetHTTPParam(api_data, which, &getPropertyRec->resultObjRef);
			break;*/
		case k_ServerName:
			err = _GetHeaderOutField(api_data, "Server", &getPropertyRec->resultObjRef);
			break;
		case k_ServerRoot:
			err = _GetServerRoot(getPropertyRec, api_data);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
static XErr	ServerInfo_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	switch(setPropertyRec->propertyID)
	{
		case k_domain:
		/*case k_port:
		case k_directoryPath:
		case k_versionNumber:
		case k_totalConnections:
		case k_currentUserLevel:
		case k_highestUserLevel:
		case k_currentFreeMemory:
		case k_minimumFreeMemory:
		case k_totalConTimeouts:
		case k_totalConBusies:
		case k_totalConDenied:
		case k_totalBytesSent:*/
		//case k_upSinceDate:
		case k_ServerName:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	serverInfo_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = ServerInfo_Register(pbPtr);
			break;
		case kInit:
			err = ServerInfo_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = ServerInfo_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = ServerInfo_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = ServerInfo_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		/*case kGetErrDescr:
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


