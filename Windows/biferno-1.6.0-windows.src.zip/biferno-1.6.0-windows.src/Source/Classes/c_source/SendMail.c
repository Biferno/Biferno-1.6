/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: SendMail.c,v 1.29 2008-11-14 11:19:54 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifdef WITH_SENDMAIL

#include 	"XLib.h"
//#include	"Helpers.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include 	"SendMail.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include 	"smtp.h"

// SendMail

// Errors:
#define	SENDMAIL_FIRSTERR	100
#define	SENDMAIL_TOT_ERRORS	7
enum{
		ErrNetOpenDriver = SENDMAIL_FIRSTERR,
		ErrNetOpenStream,
		ErrNetLostConnection,
		ErrNetDNR,
		ErrNetTruncated,
		ErrSmtpError,
		ErrAuthTooLong
	};

CStr63	sendMailErrors[SENDMAIL_TOT_ERRORS] = 
	{	"ErrNetOpenDriver",
		"ErrNetOpenStream",
		"ErrNetLostConnection",
		"ErrNetDNR",
		"ErrNetTruncated",
		"ErrSmtpError",
		"ErrAuthTooLong"
	};

enum{
		kSendMail = 1,
		kSendMailAsync,
		kSendMailFile,
		kParseMailFile,
		kGetMXRecords
	};

#define TOT_METHODS	5
	
typedef struct {
				XFileRef	fileRef;
				} SendMailUserData;

#define	SEND_MAIL_EOL_STRING	"\r\n"

#define	TIMEOUT_TAG		"sm_timeout"
#define	HOST_TAG		"sm_host"
#define	FROM_TAG		"sm_from"
#define	AUTH_TAG		"sm_auth"
#define	TO_TAG			"sm_to"
#define	BODY_TAG		"sm_body"
#define	LAST_ERROR_TAG	"sm_last_error"
#define	CREATE_SECS_TAG	"sm_creation_secs"

#define	XML_HEAD			"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"yes\"?>"
#define	ROOT_ELEM			"<biferno_mail>"
#define	ROOT_ELEM_CLOSE		"</biferno_mail>"

#define	DEFAULT_SPOOL_FILE_NAME				"bfr_smtp_spool.xml"
#define	DEFAULT_SPOOL_TIMEOUT_MINUTES		5

enum {
		kTIMEOUT = 10,
		kHOST,
		kFROM,
		kAUTH,
		kTO,
		kBODY,
		kLAST_ERROR,
		kCREATION_SECS
	};

#define	LOG_FILE		"BifernoSmtp.log"
#define	QUEUE_FILE		"BifernoSmtp.que"
#define	QUEUE_TEMP_FILE	"BifernoSmtp.que.temp"
#define	DOING_TEMP_FILE	"BifernoSmtp.doing"

#define	TIME_BETWEEN_SENT	(60L * 2L)	// 2 minutes
#define	MAX_LOG_ENTRY		512

//#define	kSendMailTimeout		(unsigned long)(1000L * 2L)	// 2 seconds

static volatile Boolean gsShuttingDown = false;

static long				sendMailClassID;
static long				bifernoVersion;
static Boolean			gsDoingAsync = false, gFileQueueModified = false;
static unsigned long	gsLastSend = 0;
static CStr255			gsQueueFilePath, gsQueueTempFilePath, gsLogFilePath;
static XFileRef			gsLogFileRef = 0;
static Boolean			gsLocally = false;
static long				gsMaxUsers;
static XFileRef			gsDoing_xrefNum;
static CStr255			gsDoingFilePath, gTempSpoolPath;

static XErr	SendMail_Run(Boolean doAnyway);


#define	kAsyncWaitTimeout	(unsigned long)(1000L * 10L)	// 10 secs

//===========================================================================================
XErr	VerifyMailAddress(char *address, char *errMessage, Boolean *resultP)
{
CStr255		host, user;
char		*strP;
XErr		err = noErr;
Boolean		result;
BlockRef	mxBlock;
int			i;
long		mxTot;
MXRecord	*mxRecordP;

	CEquStr(user, address);
	strP = user;
	do {
		if (*strP == '@')
		{	*strP = 0;
			break;
		}
	} while (*strP++);
	result = false;
	if (*++strP)
	{	CEquStr(host, strP);
		mxTot = 32;
		if (mxBlock = NewBlockLocked(sizeof(MXRecord) * mxTot, &err, (Ptr*)&mxRecordP))
		{	if NOT(err = GetMXRecords(host, mxRecordP, &mxTot))
			{	if (mxTot)
				{	for (i = 0; (i < mxTot) && NOT(err); i++, mxRecordP++)
					{	if (result = IsAddressValid(mxRecordP->name, address, errMessage))
							break;
					}
				}
			}
			else
				err = noErr;
			DisposeBlock(&mxBlock);
		}
	}

*resultP = result;
return err;
}

//===========================================================================================
Boolean	IsAddressValid(char *host, char *user, char *errMessage)
{
XErr				err = noErr;
SmtpStreamRef 		stream;
NetServerErrInfo 	serverErrInfo;
Boolean				isValid;
SendMailUserData	smUserData;
Boolean				connOpen;

	connOpen = false;
	isValid = false;
	smUserData.fileRef = gsLogFileRef;
	if (err = SmtpOpen(host, &stream, (long)&smUserData, nil))
		goto exit;
	connOpen = true;
	if (err = SmtpIsAddressValid(stream, host, user, (long)&smUserData, &isValid))
		goto exit;
	
	if (err = SmtpClose(stream, (long)&smUserData))
		goto exit;
	
	SmtpIdle((long)&smUserData);		// To Dispose some stuff
	
return isValid;
exit:
if (err == smtpServerErr)
{	SmtpGetServerErrInfo(stream, &serverErrInfo);
	CEquStr(errMessage, serverErrInfo.response);
	SmtpClose(stream, (long)&smUserData);
	err = XError(kBAPI_ClassError, ErrSmtpError);
}
else
{	switch(err)
	{	case netOpenDriverErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "NetInit could not initialize the network driver");
			err = XError(kBAPI_ClassError, ErrNetOpenDriver);
			break;
		case netOpenStreamErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "Stream open failed");
			err = XError(kBAPI_ClassError, ErrNetOpenStream);
			break;
		case netLostConnectionErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "Stream was unexpectedly closed or aborted by server");
			err = XError(kBAPI_ClassError, ErrNetLostConnection);
			break;
		case netDNRErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "DNR failed to resolve name or address");
			err = XError(kBAPI_ClassError, ErrNetDNR);
			break;
		case netTruncatedErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "Incoming text was truncated");
			err = XError(kBAPI_ClassError, ErrNetTruncated);
			break;
		default:
			if NOT(*errMessage)
				CEquStr(errMessage, "Smtp/Net: unknown error");
			if (connOpen)
				SmtpClose(stream, (long)&smUserData);
			break;
	}
}
SmtpIdle((long)&smUserData);		// To Dispose some stuff
return isValid;
}

//============================================================
static void	_NewSuffix(XFilePathPtr path, char *suffix)
{
char	*strP;
int		suffixLen, strPLen;

	if (strP = strrchr(path, '.'))
	{	strPLen = CLen(++strP);
		suffixLen = CLen(suffix);
		if ((strPLen < suffixLen) || CCompareStrings(strP + strPLen - suffixLen, suffix))
		{	*strP = 0;
			CAddStr(strP, suffix);
		}
	}
	else
	{	CAddChar(path, '.');
		CAddStr(path, suffix);
	}
}

//===========================================================================================
static XErr 	_LogToCentralSmtpLog(char *filePath, XErr theError)
{
XErr		err = noErr;
char		logStr[MAX_LOG_ENTRY];
CStr255		tStr, eNameStr, eMsg;
long		actLen;

	XThreadsEnterCriticalSection();
	
	XCurrentDateTimeToString(logStr, kComplete);
	CAddChar(logStr, '\t');
	
	CAddStr(logStr, filePath);
	CAddChar(logStr, '\t');

	CNumToString(theError, tStr);
	CAddStr(logStr, tStr);
	ErrorGetDescr(theError, eNameStr, eMsg);
	CAddChar(logStr, '\t');
	
	CAddStr(logStr, eNameStr);
	CAddChar(logStr, '\t');
	
	CAddStr(logStr, eMsg);
	CAddStr(logStr, EOL_STRING);

	LockXFile(gsLogFileRef, 0, -1, true);		// for multiprocess
	actLen = CLen(logStr);
	err = WriteXFile(gsLogFileRef, logStr, &actLen);
	UnlockXFile(gsLogFileRef, 0, -1);
	
	XThreadsLeaveCriticalSection();

return err;
}

//============================================================
static void _Log(char logEntryType, NetAddress *serverAddr, unsigned short serverPort, unsigned short localPort, char *str, long userData)
{
XErr		err = noErr;
char		logStr[MAX_LOG_ENTRY];
long		strLen, actLen;
CStr15		tStr;
CStr63		serverAddrStr;
XFileRef	xFileRef;

	if (userData)
	{	if NOT(xFileRef = ((SendMailUserData*)userData)->fileRef)
		{	XThreadsLeaveCriticalSection();
			return;
		}
	}
	else
		return;
		
	XThreadsEnterCriticalSection();
	XCurrentDateTimeToString(logStr, kComplete);
	CAddChar(logStr, '\t');
	CAddChar(logStr, logEntryType);

	// serverAddr
#if __UNIX_XLIB__ || __WIN_XLIB__
	if (serverAddr->h_length)
#else
	if (serverAddr)
#endif
		NetAddressToString(serverAddr, serverAddrStr);
	else
		CEquStr(serverAddrStr, "");
	CAddChar(logStr, '\t');
	CAddStr(logStr, serverAddrStr);
	
	// serverPort
	CAddChar(logStr, '\t');
	CNumToString(serverPort, tStr);
	CAddStr(logStr, tStr);

	// localPort
	CAddChar(logStr, '\t');
	CNumToString(localPort, tStr);
	CAddStr(logStr, tStr);
	
	actLen = CLen(logStr);
	strLen = CLen(str);
	if (actLen + strLen < 512)
	{	CAddChar(logStr, '\t');
		CAddStr(logStr, str);
		actLen += strLen + 1;
	}
	else
	{	CAddChar(logStr, '\t');
		CAddStr(logStr, "...");
		actLen += 4;
	}
	CAddStr(logStr, EOL_STRING);
	actLen += 2;
	LockXFile(xFileRef, 0, -1, true);		// for multiprocess
	err = WriteXFile(xFileRef, logStr, &actLen);
	UnlockXFile(xFileRef, 0, -1);
	
	XThreadsLeaveCriticalSection();
}

//============================================================
static XErr	_ChecklogFile(void)
{
XErr		err = noErr;
CStr255		logTitleStr;
long		tLen, eof;

	XThreadsEnterCriticalSection();
	if (NOT(gsLogFileRef) || (CheckPath(gsLogFilePath, true)))
	{	if NOT(err = OpenXFile(gsLogFilePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &gsLogFileRef))
		{	LockXFile(gsLogFileRef, 0, -1, true);
			if NOT(err = GetXEOF(gsLogFileRef, &eof))
			{	if (eof)
					err = SetXFPos(gsLogFileRef, FROM_EOF, 0);
				else
				{	// CEquStr(logTitleStr, "DATE\tHOUR\tTYPE\tSERVER\tPORT\tLOCALPORT\tMESSAGE");
					CEquStr(logTitleStr, "Biferno SMTP Central Log File");
					CAddStr(logTitleStr, EOL_STRING);
					tLen = CLen(logTitleStr);
					err = WriteXFile(gsLogFileRef, logTitleStr, &tLen);
				}
			}
			UnlockXFile(gsLogFileRef, 0, -1);
		}
	}
	XThreadsLeaveCriticalSection();
	
return err;
}

//============================================================
static XErr	_Yield(void)
{
	if (gsShuttingDown)
		return XError(kXLibError, ErrXThreads_Timeout);
	else
		return BAPI_Yield(0, nil);

return noErr;
}

//===========================================================================================
static XErr	_GetText(long api_data, ObjRefP objRef, BlockRef *refP, long *lenP)
{		
XErr		err = noErr;
long		allocLen = 0, dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock = 0;

	if NOT(err = BAPI_ObjToString(api_data, objRef, nil, &dataLen, 0, kImplicitTypeCast))
	{	allocLen = dataLen + 1;								// BAPI_ObjToString wants 0-final space
		if (dataBlock = NewBlockLocked(allocLen, &err, &dataP))
		{	if NOT(err = BAPI_ObjToString(api_data, objRef, dataP, nil, allocLen, kImplicitTypeCast))
				err = SetBlockSize(dataBlock, dataLen);		// to shrink (smtp code calls GetBlockSize to know the size)
		}
	}
	
if (err)
{	if (dataBlock)
		DisposeBlock(&dataBlock);
}
else
{	if (lenP)
		*lenP = dataLen;
	*refP = dataBlock;
}
return err;
}

//===========================================================================================
/* textBlock can contain also an header (for example for subject) with CRLFCRLF at end
exapmle:
To: valfer@flashnet.it
From: taba@flashnet.it
Subject: this is the subject

...text of mail
*/
static XErr	_DoSendMail(char *host, char *fromaddress, char *auth, char *toaddress, BlockRef *textBlockP, char *errMessage, SendMailUserData *smUserDataP, Boolean *mailSentP)
{
XErr				err = noErr;
SmtpStreamRef 		stream;
NetServerErrInfo 	serverErrInfo;
CStr63				tStr;
CStr255				tempStr;
Boolean				connOpen;

	_ChecklogFile();
	*errMessage = 0;
	connOpen = false;
	CEquStr(tempStr, "SmtpOpen");
	if (err = SmtpOpen(host, &stream, (long)smUserDataP, tempStr))
		goto exit;
	connOpen = true;
	CEquStr(tempStr, "SmtpSendMessage");
	if (err = SmtpSendMessage(stream, fromaddress, auth, toaddress, textBlockP, (long)smUserDataP, mailSentP))
		goto exit;
	CEquStr(tempStr, "SmtpClose");
	if (err = SmtpClose(stream, (long)smUserDataP))
		goto exit;
	CEquStr(tempStr, "SmtpIdle");
	SmtpIdle((long)smUserDataP);		// To Dispose some stuff
	
	DisposeBlock(textBlockP);
	
return noErr;
exit:
DisposeBlock(textBlockP);
if (err == smtpServerErr)
{	SmtpGetServerErrInfo(stream, &serverErrInfo);
	CEquStr(errMessage, serverErrInfo.response);
	SmtpClose(stream, (long)smUserDataP);
	err = XError(kBAPI_ClassError, ErrSmtpError);
	// ex err = noErr;
}
else
{	switch(err)
	{	case netOpenDriverErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "NetInit could not initialize the network driver");
			err = XError(kBAPI_ClassError, ErrNetOpenDriver);
			break;
		case netOpenStreamErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "Stream open failed");
			err = XError(kBAPI_ClassError, ErrNetOpenStream);
			break;
		case netLostConnectionErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "Stream was unexpectedly closed or aborted by server");
			err = XError(kBAPI_ClassError, ErrNetLostConnection);
			break;
		case netDNRErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "DNR failed to resolve name or address");
			err = XError(kBAPI_ClassError, ErrNetDNR);
			break;
		case netTruncatedErr:
			if NOT(*errMessage)
				CEquStr(errMessage, "Incoming text was truncated");
			err = XError(kBAPI_ClassError, ErrNetTruncated);
			break;
		default:
			//if (err != 54)
			//	printf("Err no 54\n");
			if NOT(*errMessage)
			{	CEquStr(errMessage, "Smtp/Net: unknown error (");
				CNumToString(err, tStr);
				CAddStr(errMessage, tStr);
				CAddStr(errMessage, "-");
				XErrorGetDescr(err, tempStr, nil);
				CAddStr(errMessage, tempStr);
				CAddStr(errMessage, ")");
			}
			if (connOpen)
				SmtpClose(stream, (long)smUserDataP);
			break;
	}
}
SmtpIdle((long)smUserDataP);		// To Dispose some stuff
return err;
}

//===========================================================================================
static XErr 	_GetNextTag(Ptr *textPPtr, long *lenP, long *tagP, Ptr *fromPPtr, long *contentLengthP, Ptr startFilePtr, long *offsetFromStartP, BlockRef *resultStringBlockP)
{
XErr		err = noErr;
long		compLen, tLen, len, tagID = 0;
Ptr			saveP, textP;
CStr63		compareStr, tagStr;
Boolean		found;

	*resultStringBlockP = 0;
	textP = *textPPtr;
	len = *lenP;
	SkipUntilChar(&textP, &len, '<', nil);
	*fromPPtr = nil;
	*contentLengthP = 0;
	if (len)
	{	textP++;
		len--;
		saveP = textP;
		SkipUntilChar(&textP, &len, '>', nil);
		tLen = textP - saveP;
		if (tLen > 63)
			tLen = 63;
		CopyBlock(tagStr, saveP, tLen);
		tagStr[tLen] = 0;
		if NOT(CCompareStrings_cs(tagStr, TIMEOUT_TAG))
			tagID = kTIMEOUT;
		else if NOT(CCompareStrings_cs(tagStr, HOST_TAG))
			tagID = kHOST;
		else if NOT(CCompareStrings_cs(tagStr, FROM_TAG))
			tagID = kFROM;
		else if NOT(CCompareStrings_cs(tagStr, AUTH_TAG))
			tagID = kAUTH;
		else if NOT(CCompareStrings_cs(tagStr, TO_TAG))
			tagID = kTO;
		else if NOT(CCompareStrings_cs(tagStr, BODY_TAG))
			tagID = kBODY;
		else if NOT(CCompareStrings_cs(tagStr, LAST_ERROR_TAG))
			tagID = kLAST_ERROR;
		else if NOT(CCompareStrings_cs(tagStr, CREATE_SECS_TAG))
			tagID = kCREATION_SECS;
		if (len)
		{	textP++;
			len--;
			if (tagID)
			{	*fromPPtr = textP;
				CEquStr(compareStr, "</");
				CAddStr(compareStr, tagStr);
				CAddStr(compareStr, ">");
				compLen = CLen(compareStr);
				found = false;
				while ((len >= compLen) && NOT(found = NOT(CompareBlock(textP, compareStr, compLen))))
				{	textP++;
					len--;
				}
				if (found)
				{	*contentLengthP = textP - *fromPPtr;
					*offsetFromStartP = *fromPPtr - startFilePtr;
					if NOT(err = DecodeIsolatin((Byte*)*fromPPtr, *contentLengthP, resultStringBlockP, contentLengthP, false))
					{	LockBlock(*resultStringBlockP);
						*fromPPtr = GetPtr(*resultStringBlockP);
						textP += compLen;
						len -= compLen;
					}
				}
			}
		}
	}
	if (tagP)
		*tagP = tagID;

	*textPPtr = textP;
	*lenP = len;

return err;
}

//===========================================================================================
static XErr 	_ParseFile(Ptr *textPPtr, long *lenP, char *host, char *fromaddress, char *auth, BlockRef *toAddressBlockP, Ptr *toaddress, long *timeoutP, BlockRef *textBlockP, long *lastErrorOffsetP, long *lastErrorLengthP, char *creatSecsStr)
{
XErr		err = noErr;
long		tagID, len, length;
Ptr			textBlockPointer, saveP, textP, fromP;
CStr63		aCStr;
BlockRef	blockToDispose;
long		offsetFromStart;

	if (lastErrorOffsetP)
		*lastErrorOffsetP= 0;
	if (lastErrorLengthP)
		*lastErrorLengthP = 0;
	*auth = 0;
	textP = saveP = *textPPtr;
	len = *lenP;
	while ((len > 0) && NOT(err))
	{	if NOT(err = _GetNextTag(&textP, &len, &tagID, &fromP, &length, saveP, &offsetFromStart, &blockToDispose))
		{	switch(tagID)
			{
				case kTIMEOUT:
					if (length > 63)
						length = 63;
					CopyBlock(aCStr, fromP, length);
					aCStr[length] = 0;
					CStringToNum(aCStr, timeoutP);
					break;
				case kHOST:
					if (length > 255)
						length = 255;
					CopyBlock(host, fromP, length);
					host[length] = 0;
					break;
				case kFROM:
					if (length > 255)
						length = 255;
					CopyBlock(fromaddress, fromP, length);
					fromaddress[length] = 0;
					break;
				case kAUTH:
					if (length > 255)
						length = 255;
					CopyBlock(auth, fromP, length);
					auth[length] = 0;
					break;
				case kTO:
					if (*toAddressBlockP = NewBlockLocked(length + 1, &err, toaddress))
					{	CopyBlock(*toaddress, fromP, length);
						(*toaddress)[length] = 0;
					}
					break;
				case kBODY:
					if (*textBlockP = NewBlockLocked(length, &err, &textBlockPointer))
					{	//LockBlock(*textBlockP);
						CopyBlock(textBlockPointer, fromP, length);
					}
					break;
				case kLAST_ERROR:
					if (lastErrorOffsetP)
						*lastErrorOffsetP = offsetFromStart;
					if (lastErrorLengthP)
						*lastErrorLengthP = length;
					break;
				case kCREATION_SECS:
					if (length > 255)
						length = 255;
					CopyBlock(creatSecsStr, fromP, length);
					creatSecsStr[length] = 0;
					break;					
			}
			if (blockToDispose)
				DisposeBlock(&blockToDispose);
		}
	}
	*textPPtr = textP;
	*lenP = len;

return err;
}

//===========================================================================================
/*
Parse the file "filePath" and get all mail infos. Then send the mail.

If there is an error in sending mail:
	
	if the file timed out	
		delete it
	else
		write an error in "filePath" (in xml tag)
		
if the mail is successfull
	
	if (deleteIfSuccess)
		delete the file "filePath"
	
		
*/
static XErr 	_SendFile(char *filePath, SendMailUserData *smUserDataP, char *errMessageStringP, /*Boolean *fileDeletedP, */Boolean deleteIfSuccess, XErr *resultErrorP)
{
XFileRef		fileRef;
long			errTagClosedLen, errMessageLen, fileEOF, lastErrorOffset, lastErrorLength, timeout, eof;
BlockRef		block = nil;
XErr			err = noErr, err2 = noErr;
Ptr				saveP, textP;
CStr255			creatSecsStr, errTagClosed, fromaddress, auth, host, errMessage;
BlockRef		textBlock;
//XFileInfo		xFileInfo;
unsigned long	pos, nowSecs;
time_t			creatSecs;
char			*toaddress;
BlockRef		toAddressBlock = 0;
Boolean			mailSent;

	if (resultErrorP)
		*resultErrorP = noErr;
		
	*errMessage = 0;
	//if (fileDeletedP)
	//	*fileDeletedP = false;
	err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef);
	if (err == XError(kXLibError, ErrXFiles_FileNotFound))
		return noErr;
	if NOT(err)
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	fileEOF = eof;
			if (eof)
			{	if (block = NewBlockLocked(eof, &err, &saveP))
				{	textP = saveP;
					if NOT(err = ReadXFile(fileRef, textP, &eof))
						err = _ParseFile(&textP, &eof, host, fromaddress, auth, &toAddressBlock, &toaddress, &timeout, &textBlock, &lastErrorOffset, &lastErrorLength, creatSecsStr);
					UnlockBlock(block);
				}
			}
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}
	if NOT(err)
	{	mailSent = false;
		err = _DoSendMail(host, fromaddress, auth, toaddress, &textBlock, errMessage, smUserDataP, &mailSent);
		if (err && NOT(mailSent))	//(err)
		{	if (resultErrorP)
				*resultErrorP = err;
			XGetSeconds(&nowSecs);
			CStringToNum(creatSecsStr, (long*)&creatSecs);
			if (((nowSecs - creatSecs) / 60) >= (unsigned long)timeout)		// timeout is in minutes
			{	XThreadsEnterCriticalSection();
				_LogToCentralSmtpLog(filePath, err);
				if NOT(err = DeleteXFile(filePath))
				{	//if (fileDeletedP)
					//	*fileDeletedP = true;
				}
				XThreadsLeaveCriticalSection();
			}
			else if NOT(err2 = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_WRITE_PERM, false, &fileRef))
			{	CEquStr(errTagClosed, "</");
				CAddStr(errTagClosed, LAST_ERROR_TAG);
				CAddStr(errTagClosed, ">");
				errTagClosedLen = CLen(errTagClosed);
				pos = lastErrorOffset + lastErrorLength + errTagClosedLen;
				if NOT(err2 = SetXFPos(fileRef, FROM_START, pos))
				{	LockBlock(block);
					textP = GetPtr(block);
					fileEOF -= pos;
					if NOT(err2 = ReadXFile(fileRef, textP, &fileEOF))
					{	if NOT(err2 = SetXFPos(fileRef, FROM_START, lastErrorOffset))
						{	errMessageLen = CLen(errMessage);
							if NOT(err2 = WriteXFile(fileRef, errMessage, &errMessageLen))
							{	if NOT(err2 = WriteXFile(fileRef, errTagClosed, &errTagClosedLen))
								{	if NOT(err2 = WriteXFile(fileRef, GetPtr(block), &fileEOF))
										err2 = SetXEOF(fileRef, lastErrorOffset + errMessageLen + errTagClosedLen + fileEOF);
								}
							}
						}
					}
				}
				CloseXFile(&fileRef);
			}
		}
		else
		{	if (err)
				err = _LogToCentralSmtpLog(filePath, err);
			if (deleteIfSuccess)
			{	XThreadsEnterCriticalSection();
				if NOT(err = DeleteXFile(filePath))
				{	//if (fileDeletedP)
					//	*fileDeletedP = true;
				}
				XThreadsLeaveCriticalSection();
			}
		}
		if (errMessageStringP)
			CEquStr(errMessageStringP, errMessage);
	}
	if (toAddressBlock)
		DisposeBlock(&toAddressBlock);
	if (block)
		DisposeBlock(&block);
	
return err;
}

//===========================================================================================
static XErr	_GetNextLine(Ptr *textPPtr, long *lenP, char *line)
{
XErr	err = noErr;
Ptr		textP, saveP;
long	returnSize, len, tLen;

	textP = saveP = *textPPtr;
	len = *lenP;
	returnSize = 0;
	while ((len > 0) && NOT(IsNewLine(textP, len, &returnSize)))
	{	textP++;
		len--;
	}
	tLen = textP - saveP;
	if (tLen > 255)
		tLen = 255;
	CopyBlock(line, saveP, tLen);
	line[tLen] = 0;
	if (returnSize)
	{	textP += returnSize;
		len -= returnSize;
	}
	*textPPtr = textP;
	*lenP = len;

return err;
}

//===========================================================================================
static void _LogAsyncMail(Boolean init)
{
//unsigned long	threadID;
CStr255			aCStr;

	// task id
	/*XGetCurrentThread(&threadID);
	CNumToString(threadID, tempStr);
	CEquStr(aCStr, "Thread ");
	CAddStr(aCStr, tempStr);
	BAPI_Log(0, aCStr);

	// date time "FINISHED"
	XCurrentDateTimeToString(tempStr, kWantDate);
	CEquStr(aCStr, tempStr);
	CAddStr(aCStr, " ");
	XCurrentDateTimeToString(tempStr, kWantHour+kWantSecs+kLeadingZeros);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, EOL_STRING);*/
	if (init)
		CEquStr(aCStr, "SendMail Doing Async - INIT");
	else
		CEquStr(aCStr, "SendMail Doing Async - END");
	BAPI_Log(0, aCStr);
	//BAPI_Log(0, EOL_STRING);
}

//===========================================================================================
static void _LogAsyncSending(char *mailFile, Boolean init, XErr err, char *errMessage)
{
//unsigned long	threadID;
CStr255			tempStr;
char			aCStr[1024];
long			eNum, eType;

	// task id
	/*XGetCurrentThread(&threadID);
	CNumToString(threadID, tempStr);
	CEquStr(aCStr, "Thread ");
	CAddStr(aCStr, tempStr);
	BAPI_Log(0, aCStr);*/

	// date time "FINISHED"
	/*XCurrentDateTimeToString(tempStr, kWantDate);
	CEquStr(aCStr, tempStr);
	CAddStr(aCStr, " ");
	XCurrentDateTimeToString(tempStr, kWantHour+kWantSecs+kLeadingZeros);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, EOL_STRING);*/
	CEquStr(aCStr, "SendMailAsync: ");
	CAddStr(aCStr, mailFile);
	if (init)
		CAddStr(aCStr, " ...");
	else
	{	if (err)
		{	BAPI_Log(0, aCStr);
			*aCStr = 0;
			XErrorGetTypeValue(err, &eNum, &eType);
			CAddStr(aCStr, " Error: ");
			CNumToString(eNum, tempStr);
			CAddStr(aCStr, tempStr);
			CAddStr(aCStr, "-");
			if (eType == kBAPI_ClassError)
				CEquStr(tempStr, sendMailErrors[eNum - SENDMAIL_FIRSTERR]);
			else
				XErrorGetDescr(err, tempStr, nil);
			CAddStr(aCStr, tempStr);
			if (errMessage/* && *errMessage*/)
			{	CAddStr(aCStr, " [");
				CAddStr(aCStr, errMessage);
				CAddStr(aCStr, "]");
			}
		}
		else
		{	//CAddStr(aCStr, EOL_STRING);
			CAddStr(aCStr, " OK");
		}
	}
	BAPI_Log(0, aCStr);
	//BAPI_Log(0, EOL_STRING);
}

//===========================================================================================
static void 	_AdjustAfterAsync(XFileRef temp_xrefNum, BufferID logFileBufferID)
{
long		tLen, buffSize;
BlockRef	block;
char		*pathP;
XErr		err = noErr;
long		temp_eof, totBytes;
Ptr			tempP;
CStr255		aLine;

	if (temp_xrefNum)
	{	if NOT(err = GetXEOF(temp_xrefNum, &temp_eof))
		{	if (temp_eof)
			{	if NOT(err = SetXFPos(temp_xrefNum, FROM_START, 0))
				{	if (block = NewBlockLocked(temp_eof, &err, &tempP))
					{	if NOT(err = ReadXFile(temp_xrefNum, tempP, &temp_eof))
						{	if NOT(err = SetXFPos(temp_xrefNum, FROM_START, 0))
							{	totBytes = 0;
								while ((temp_eof > 0) && NOT(err))
								{	if NOT(err = _GetNextLine(&tempP, &temp_eof, aLine))
									{	if (*(long*)aLine != '****')
										{	CAddStr(aLine, EOL_STRING);
											tLen = CLen(aLine);
											if NOT(err = WriteXFile(temp_xrefNum, aLine, &tLen))
												totBytes += tLen;
										}
									}
								};
								if NOT(err)
									err = SetXEOF(temp_xrefNum, totBytes);
							}
						}
						DisposeBlock(&block);
					}
				}
			}
		}
	}
	
 	block = BufferGetBlockRefExtSize(logFileBufferID, &buffSize, &pathP);
	LockBlock(block);
	if (buffSize)
	{	do 
		{	err = DeleteXFile(pathP); 
			tLen = CLen(pathP) + 1;
			pathP += tLen;
			buffSize -= tLen;
		} while (buffSize > 0);
	}
	UnlockBlock(block);
}

//===========================================================================================
static void* 	_DoAsync(void* args)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(args)
#endif
XErr				err = noErr, err2 = noErr;
XFileRef 			temp_xrefNum = 0, xrefNum = 0, log_xrefNum = 0;
long				lineOffset, tLen, eof = 0, logEOF;
BlockRef			block = 0;
Ptr					initP, saveP, textP = nil;
CStr255				errMessage, logFile, mailFile;
SendMailUserData 	smUserData;
//Boolean				fileDeleted;
#if CHECK_LEAKING
	Boolean			checkLeak;
	long			leaksHnd;
	CStr255			logStr;
#endif
BufferID			logFileBufferID;
XErr				resultErr = noErr;
long				totEof, temp_eof;

// This check is for other processes
#ifdef __MAC_XLIB__
Boolean		isOpen;

	if NOT(err = IsXFileOpen(gsDoingFilePath, &isOpen))
	{	if (isOpen)
		{	gFileQueueModified = true;
			return noErr;
		}
		else
			err = OpenXFile(gsDoingFilePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &gsDoing_xrefNum);
	}
	else
		return (void*)err;
#else
	if (err = LockXFile(gsDoing_xrefNum, 0, -1, false))
	{	gFileQueueModified = true;
		return noErr;
	}
#endif


#if CHECK_LEAKING
	checkLeak = ResetLeaking();
#endif
	XThreadsEnterCriticalSection();
	if NOT(gsDoingAsync)
	{	gsDoingAsync = true;
		_LogAsyncMail(true);
		if (logFileBufferID = BufferCreate(256, &err))
		{	gFileQueueModified = false;		// we are going to manage it
		init:
			totEof = 0;
			if NOT(err = OpenXFile(gsQueueTempFilePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &temp_xrefNum))
			{	if NOT(err = OpenXFile(gsQueueFilePath, OPEN_FILE_EXISTING, READ_WRITE_PERM, false, &xrefNum))
				{	if NOT(err = GetXEOF(xrefNum, &eof))
					{	if NOT(err = GetXEOF(temp_xrefNum, &temp_eof))
						{	if (totEof = temp_eof + eof)
							{	if (block = NewBlockLocked(totEof, &err, &saveP))
								{	textP = saveP;
									// Copy temp+que -> temp
									if (temp_eof)
										err = ReadXFile(temp_xrefNum, textP, &temp_eof);
									if NOT(err)
									{	if (eof)
											err = ReadXFile(xrefNum, textP + temp_eof, &eof);
										if NOT(err)
										{	if NOT(err = SetXFPos(temp_xrefNum, FROM_START, 0))
											{	if NOT(err = WriteXFile(temp_xrefNum, textP, &totEof))
												{	// Reset que
													err = SetXEOF(xrefNum, 0);
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else if (err == XError(kXLibError, ErrXFiles_FileNotFound))
					err = noErr;
			}
			// Close que
			if (xrefNum)
			{	err2 = CloseXFile(&xrefNum);
				if (err2 && NOT(err))
					err = err2;
			}
			XThreadsLeaveCriticalSection();
			// nota che se qui fai passare qualche thread, questa trova gsDoingAsync a true e salta gi�
			// quindi dovrebbe essere ok
			initP = textP;
			while ((totEof > 0) && NOT(err))
			{	lineOffset = textP - initP;
				if NOT(err = _GetNextLine(&textP, &totEof, mailFile))
				{	if (*(long*)mailFile == '****')
						continue;
					_LogAsyncSending(mailFile, true, 0, nil);
					CEquStr(logFile, mailFile);
					_NewSuffix(logFile, "log");
					if (err = OpenXFile(logFile, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &log_xrefNum))
					{	err = noErr;
						log_xrefNum = 0;
					}
					else if (NOT(err = GetXEOF(log_xrefNum, &logEOF)) && logEOF)
						err = SetXFPos(log_xrefNum, FROM_EOF, 0);
					if (err)
						err = noErr;
					smUserData.fileRef = log_xrefNum;
					err = _SendFile(mailFile, &smUserData, errMessage, false, &resultErr);
					if (log_xrefNum)
						CloseXFile(&log_xrefNum);
					if (resultErr)
					{	
						err = noErr;
						// if error, do nothing, leave it in temp file
						//tLen = textP - initP;
						//err = WriteXFile(temp_xrefNum, initP, &tLen);
					}
					else
					{	// We will delete all success mail files later
						if NOT(err = BufferAddCString(logFileBufferID, mailFile, NO_ENC, 0))
						{	if NOT(err = BufferAddChar(logFileBufferID, 0))
							{	if NOT(err = BufferAddCString(logFileBufferID, logFile, NO_ENC, 0))
									err = BufferAddChar(logFileBufferID, 0);
							}
						}
						if NOT(err)
						{	// Mark as success line from temp
							if NOT(err = SetXFPos(temp_xrefNum, FROM_START, lineOffset))
							{	tLen = 4;
								err = WriteXFile(temp_xrefNum, "****", &tLen);
							}
						}
						//DeleteXFile(logFile);
					}
					_LogAsyncSending(mailFile, false, resultErr, errMessage);				
				}
				if (gsShuttingDown)
					break;
			}
			if (block)
				DisposeBlock(&block);
			XThreadsEnterCriticalSection();
			_AdjustAfterAsync(temp_xrefNum, logFileBufferID);
			if (temp_xrefNum)
			{	err2 = CloseXFile(&temp_xrefNum);
				if (err2 && NOT(err))
					err = err2;
			}
			if (gFileQueueModified)
			{	gFileQueueModified = false;
				BufferReset(logFileBufferID);
				goto init;
			}
			/*
			if (err)
			{
				err2 = DeleteXFile(gsQueueTempFilePath);
			}
			else
			{	if (gsShuttingDown)
					err2 = DeleteXFile(gsQueueTempFilePath);
				else
				{	if (gFileQueueModified)
					{
						err2 = DeleteXFile(gsQueueTempFilePath);
						gFileQueueModified = false;
						BufferReset(logFileBufferID);
						goto init;
					}
					else
					{
						//exit(0);
						if NOT(err2 = DeleteXFile(gsQueueFilePath))
							err = RenameXFile(gsQueueTempFilePath, gsQueueFilePath);
					}
				}
			}
			*/
			
			BufferFree(logFileBufferID);
		}
		_LogAsyncMail(false);
		
		//DeleteXFile(gsDoingFilePath);
		gsDoingAsync = false;
		
	}
	XThreadsLeaveCriticalSection();
#if CHECK_LEAKING
	if (checkLeak)
	{	CheckLeaking(logStr, nil, &leaksHnd);
		if (*logStr)
			BAPI_Log(0, logStr);
	}
#endif

#ifdef __MAC_XLIB__
	CloseXFile(&gsDoing_xrefNum);
#else
	UnlockXFile(gsDoing_xrefNum, 0, -1);
#endif
	
return (void*)err;
}

//===========================================================================================
static XErr	_WriteTag(XFileRef xrefNum, char *tag, char *text, long len, Boolean dosPeriods)
{
XErr		err = noErr;
CStr63		aCStr;
long		tLen;
BlockRef	resultStringBlock;
long		resultLen;

	CEquStr(aCStr, "<");
	CAddStr(aCStr, tag);
	CAddStr(aCStr, ">");
	tLen = CLen(aCStr);
	if (err = WriteXFile(xrefNum, aCStr, &tLen))
		goto out;	
	if NOT(err = EncodeIsolatin((Byte*)text, len, &resultStringBlock, &resultLen, false, true, false, false, 0L))
	{	LockBlock(resultStringBlock);
		if (dosPeriods)
		{	if NOT(err = SetBlockSize(resultStringBlock, resultLen))
			{	if NOT(err = MungeOut(&resultStringBlock, false))
				{	LockBlock(resultStringBlock);
					resultLen = GetBlockSize(resultStringBlock, nil);
				}
			}
		}
		if NOT(err)
			err = WriteXFile(xrefNum, GetPtr(resultStringBlock), &resultLen);
		DisposeBlock(&resultStringBlock);
	}
	if (err)
		goto out;
	CEquStr(aCStr, "</");
	CAddStr(aCStr, tag);
	CAddStr(aCStr, ">");
	CAddStr(aCStr, SEND_MAIL_EOL_STRING);
	tLen = CLen(aCStr);
	if (err = WriteXFile(xrefNum, aCStr, &tLen))
		goto out;

out:
return err;
}

//===========================================================================================
static XErr	_WriteMailFile(XFileRef xrefNum, char *host, char *fromaddress, char *auth, char *toaddress, BlockRef text, long textLen, unsigned long minutes, char *createSecsString)
{
XErr	err = noErr;
CStr15	timeStr;
CStr255	aCStr;
long	tLen;

	// header
	CEquStr(aCStr, XML_HEAD);
	CAddStr(aCStr, SEND_MAIL_EOL_STRING);
	tLen = CLen(aCStr);
	if (err = WriteXFile(xrefNum, aCStr, &tLen))
		goto out;
	// Root element
	CEquStr(aCStr, ROOT_ELEM);
	CAddStr(aCStr, SEND_MAIL_EOL_STRING);
	tLen = CLen(aCStr);
	//tLen = CLen(ROOT_ELEM);
	if (err = WriteXFile(xrefNum, aCStr, &tLen))
		goto out;
	CNumToString(minutes, timeStr);
	if (err = _WriteTag(xrefNum, TIMEOUT_TAG, timeStr, CLen(timeStr), false))
		goto out;
	if (err = _WriteTag(xrefNum, HOST_TAG, host, CLen(host), false))
		goto out;
	if (err = _WriteTag(xrefNum, FROM_TAG, fromaddress, CLen(fromaddress), false))
		goto out;
	if (auth && *auth)
	{	if (err = _WriteTag(xrefNum, AUTH_TAG, auth, CLen(auth), false))
			goto out;
	}
	if (err = _WriteTag(xrefNum, TO_TAG, toaddress, CLen(toaddress), false))
		goto out;
	LockBlock(text);
	if (err = _WriteTag(xrefNum, BODY_TAG, GetPtr(text), textLen, true))
		goto out;
	UnlockBlock(text);
	if (err = _WriteTag(xrefNum, LAST_ERROR_TAG, "", 0, false))
		goto out;
	if (err = _WriteTag(xrefNum, CREATE_SECS_TAG, createSecsString, CLen(createSecsString), false))
		goto out;
	// Root element close
	tLen = CLen(ROOT_ELEM_CLOSE);
	if (err = WriteXFile(xrefNum, ROOT_ELEM_CLOSE, &tLen))
		goto out;
	
out:
return err;
}

//===========================================================================================
static XErr	_GetMXRecords(ExecuteMethodRec *exeMethodRecP, long api_data)
{
CStr255		domain;
XErr		err = noErr;
MXRecord	*mxRecordP;
long		mxTot;
BlockRef	mxBlock;
int			i;
ObjRef		tObjRef, *resObjRefP;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, domain, nil, 255, kImplicitTypeCast))
	{	mxTot = 32;
		if (mxBlock = NewBlockLocked(sizeof(MXRecord) * mxTot, &err, (Ptr*)&mxRecordP))
		{	if NOT(err = GetMXRecords(domain, mxRecordP, &mxTot))
			{	resObjRefP = &exeMethodRecP->resultObjRef;
				if NOT(err = BAPI_ArrayToObj(api_data, true, nil, 0, nil, nil, resObjRefP))
				{	for (i = 0; (i < mxTot) && NOT(err); i++, mxRecordP++)
					{	BAPI_InvalObjRef(api_data, &tObjRef);
						if NOT(err = BAPI_IntToObj(api_data, mxRecordP->preference, &tObjRef))
							err = BAPI_ArrayAddElement(api_data, resObjRefP, mxRecordP->name, &tObjRef);
					}
				}
			}
			DisposeBlock(&mxBlock);
		}
	}

return err;
}

//===========================================================================================
static XErr	_EncodeAuth(char *from, char *auth)
{
CStr255		clearString;
int			l_a, l_f, l_p, tempLen = 0;
char		*authIDP, *strP;
XErr		err = noErr;
	
	// authid:passwd -> authid\0from\0passwd
	if (strP = strchr(auth, ':'))
	{	authIDP = from = auth;
		*strP++ = 0;
	}
	else
	{	strP = auth;
		authIDP = from;
	}
	l_a = CLen(authIDP);
	l_f = CLen(from);
	l_p = CLen(strP);
	if ((l_a + l_f + l_p + 2) < 255)
	{	CopyBlock(clearString + tempLen, authIDP, l_a);
		tempLen += l_a;
		*(clearString + tempLen++) = 0;
		CopyBlock(clearString + tempLen, from, l_f);
		tempLen += l_f;
		*(clearString + tempLen++) = 0;
		CopyBlock(clearString + tempLen, strP, l_p);
		tempLen += l_p;
		if ((5 + (4 * tempLen)/3) < 255)
			HTUU_encode((Byte*)clearString, tempLen, auth);
		else
			err = XError(kBAPI_ClassError, ErrAuthTooLong);
	}
	else
		err = XError(kBAPI_ClassError, ErrAuthTooLong);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_SendMailFile(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long api_data)
{
CStr255				filePath, logFile;
SendMailUserData 	smUserData;
XFileRef			log_xrefNum;
XErr				err = noErr, err2 = noErr;
//Boolean				fileDeleted;

	*pbPtr->error = 0;
	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, true))
		{	CEquStr(logFile, filePath);
			CAddStr(logFile, ".log");
			if (err = OpenXFile(logFile, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &log_xrefNum))
			{	err = noErr;
				log_xrefNum = 0;
			}
			smUserData.fileRef = log_xrefNum;
			err = _SendFile(filePath, &smUserData, pbPtr->error, true, nil);
			if (log_xrefNum)
				CloseXFile(&log_xrefNum);
			if NOT(err)
				DeleteXFile(logFile);
			err2 = BAPI_StringToObj(api_data, pbPtr->error, CLen(pbPtr->error), &exeMethodRecP->resultObjRef);
			if (NOT(err) && err2)
				err = err2;
		}
	}

return err;
}

//===========================================================================================
static XErr	_ParseMailFile(ExecuteMethodRec *exeMethodRecP, long api_data)
{
CStr255				filePath;
XFileRef			fileRef;
XErr				err = noErr, err2 = noErr;
CStr255				lastError, host, fromaddress, auth;
long				timeout;
BlockRef			block, textBlock = 0;
long				eof, lastErrorOffset, lastErrorLength;
Ptr					textP, saveP;
char				*toaddress;
BlockRef			toAddressBlock = 0;
CStr255				creatSecsStr;

	*lastError = *host = *fromaddress = 0;
	timeout = 0;
	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, filePath, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_RealPath(api_data, filePath, true))
		{	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef))
			{	if NOT(err = GetXEOF(fileRef, &eof))
				{	if (eof)
					{	if (block = NewBlockLocked(eof, &err, &saveP))
						{	//LockBlock(block);
							textP = saveP;// = GetPtr(block);
							if NOT(err = ReadXFile(fileRef, textP, &eof))
							{	if NOT(err = _ParseFile(&textP, &eof, host, fromaddress, auth, &toAddressBlock, &toaddress, &timeout, &textBlock, &lastErrorOffset, &lastErrorLength, creatSecsStr))
								{	if (lastErrorLength > 255)
										lastErrorLength = 255;
									CopyBlock(lastError, saveP + lastErrorOffset, lastErrorLength);
									lastError[lastErrorLength] = 0;
								}
							}
							DisposeBlock(&block);
						}
					}
				}
				err2 = CloseXFile(&fileRef);
				if (err2 && NOT(err))
					err = err2;
			}
		}
		if NOT(err)
		{	ObjRef	tObjRef, arrayObjRef;
		
			BAPI_InvalObjRef(api_data, &arrayObjRef);
			if NOT(err = BAPI_ArrayToObj(api_data, false, nil, 0, nil, nil, &arrayObjRef))
			{	// host
				BAPI_InvalObjRef(api_data, &tObjRef);
				if (err = BAPI_StringToObj(api_data, host, CLen(host), &tObjRef))
					goto out;
				if (err = BAPI_ArrayAddElement(api_data, &arrayObjRef, HOST_TAG, &tObjRef))
					goto out;
				// from
				BAPI_InvalObjRef(api_data, &tObjRef);
				if (err = BAPI_StringToObj(api_data, fromaddress, CLen(fromaddress), &tObjRef))
					goto out;
				if (err = BAPI_ArrayAddElement(api_data, &arrayObjRef, FROM_TAG, &tObjRef))
					goto out;
				// to
				BAPI_InvalObjRef(api_data, &tObjRef);
				if (err = BAPI_StringToObj(api_data, toaddress, CLen(toaddress), &tObjRef))
					goto out;
				if (err = BAPI_ArrayAddElement(api_data, &arrayObjRef, TO_TAG, &tObjRef))
					goto out;
				// body
				BAPI_InvalObjRef(api_data, &tObjRef);
				LockBlock(textBlock);
				if (err = BAPI_StringToObj(api_data, GetPtr(textBlock), GetBlockSize(textBlock, &err), &tObjRef))
					goto out;
				UnlockBlock(textBlock);
				if NOT(err)
				{	if (err = BAPI_ArrayAddElement(api_data, &arrayObjRef, BODY_TAG, &tObjRef))
						goto out;
					// timeout
					BAPI_InvalObjRef(api_data, &tObjRef);
					CNumToString(timeout, host);
					if (err = BAPI_StringToObj(api_data, host, CLen(host), &tObjRef))
						goto out;
					UnlockBlock(textBlock);
					if (err = BAPI_ArrayAddElement(api_data, &arrayObjRef, TIMEOUT_TAG, &tObjRef))
						goto out;
					// last error
					BAPI_InvalObjRef(api_data, &tObjRef);
					if (err = BAPI_StringToObj(api_data, lastError, CLen(lastError), &tObjRef))
						goto out;
					if (err = BAPI_ArrayAddElement(api_data, &arrayObjRef, LAST_ERROR_TAG, &tObjRef))
						goto out;
					// creation secs
					BAPI_InvalObjRef(api_data, &tObjRef);
					if (err = BAPI_StringToObj(api_data, creatSecsStr, CLen(creatSecsStr), &tObjRef))
						goto out;
					if (err = BAPI_ArrayAddElement(api_data, &arrayObjRef, CREATE_SECS_TAG, &tObjRef))
						goto out;
					exeMethodRecP->resultObjRef = arrayObjRef;
				}
			}
		
		}
	out:
		if (textBlock)
			DisposeBlock(&textBlock);
		if (toAddressBlock)
			DisposeBlock(&toAddressBlock);
	}

return err;
}

//===========================================================================================
static XErr	_SendMail(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr				err = noErr, err2 = noErr;
CStr255				fromaddress, host, aCStr, auth;
BlockRef			textBlock = 0, ref = 0;
SendMailUserData 	smUserData;
char				*toaddress;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, host, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, fromaddress, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[2].objRef, aCStr, &toaddress, nil, &ref, kImplicitTypeCast))
			{	if NOT(err = _GetText(api_data, &exeMethodRecP->paramVarsP[3].objRef, &textBlock, nil))
				{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[4].objRef, auth, nil, 255, kImplicitTypeCast))
					{	smUserData.fileRef = gsLogFileRef;
						if (*auth)
							err = _EncodeAuth(fromaddress, auth);
						if NOT(err)
						{	err = _DoSendMail(host, fromaddress, auth, toaddress, &textBlock, pbPtr->error, nil, nil);	// This dispose of textBlock
							err2 = BAPI_StringToObj(api_data, pbPtr->error, CLen(pbPtr->error), &exeMethodRecP->resultObjRef);
							if (NOT(err) && err2)
								err = err2;
						}
					}
				}
				BAPI_ReleaseBlock(&ref);
			}
		}
	}

return err;
}

//===========================================================================================
XErr	SendAsyncronousMail(long api_data, char *host, char *fromaddress, char *auth, char *toaddress, BlockRef textBlock, long textLen, char *filePath, unsigned long minutes, char *resultString)
{
XErr			err = noErr;
CStr255			aCStr, aCStr2;
unsigned long	index;
long			tLen;
XFileRef		xrefNum;
CStr15			indStr;
Boolean			fileCreated = false;

	if NOT(minutes)
		minutes = DEFAULT_SPOOL_TIMEOUT_MINUTES;

	if	(*filePath)
	{	if (err = BAPI_RealPath(api_data, filePath, true))
		{	if (err == XError(kXLibError, ErrXFiles_FileNotFound))
				err = noErr;					
		}
	}
	else
	{	CEquStr(filePath, gTempSpoolPath);
		err = BAPI_RealPath(0, filePath, true);
		if ((err == XError(kXLibError, ErrXFiles_FolderNotFound)) || (err == XError(kXLibError, ErrXFiles_FileNotFound)))
			err = CreateXFolder(filePath);
	}
	if NOT(err)
	{	
	CStr255		saveStr;
	char		*strP;
	int			aCStrLen;
	Boolean		isDir;
	
		index = 1;
		if (*filePath)
			CEquStr(aCStr, filePath);
		else
		{	BAPI_GetBifernoHome(api_data, aCStr);
			CEquStr(aCStr, aCStr + FILE_HD_PREFIX_LEN);
		}
		if NOT(CheckPath(aCStr, true))
			err = XIsFolder(aCStr, &isDir);
		else
			isDir = false;
		if NOT(err)
		{	aCStrLen = CLen(aCStr);
			if (isDir)
			{	if (aCStr[aCStrLen-1] != '/')
					CAddChar(aCStr, '/');
				CAddStr(aCStr, DEFAULT_SPOOL_FILE_NAME);
			}
			else
			{	if ((aCStrLen < 4) || CCompareStrings(aCStr + aCStrLen - 4, ".xml"))
					CAddStr(aCStr, ".xml");
			}
			XThreadsEnterCriticalSection();
			CEquStr(filePath, aCStr);
			while (CheckPath(aCStr, true) != XError(kXLibError, ErrXFiles_FileNotFound))		
			{	CNumToString(index++, indStr);
				CEquStr(aCStr, filePath);
				if (strP = strrchr(aCStr, '.'))
				{	CEquStr(saveStr, strP);
					*strP = 0;
					CAddChar(strP, '_');
					CAddStr(strP, indStr);
					CAddStr(strP, saveStr);
				}
				else	// should never happen (added .xml)
				{	CAddChar(aCStr, '_');
					CAddStr(aCStr, indStr);
				}
			}
			if NOT(err = OpenXFile(aCStr, CREATE_FILE_NEW, READ_WRITE_PERM, false, &xrefNum))
			{	
			unsigned long 	createSecs;
			CStr255			createSecsString;
			
				fileCreated = true;
				XGetSeconds(&createSecs);
				CNumToString(createSecs, createSecsString);
				if NOT(err = _WriteMailFile(xrefNum, host, fromaddress, auth, toaddress, textBlock, textLen, minutes, createSecsString))	
				{	CloseXFile(&xrefNum);
					xrefNum = 0;
					if NOT(err = OpenXFile(gsQueueFilePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &xrefNum))
					{	if NOT(err = SetXFPos(xrefNum, FROM_EOF, 0))
						{	CEquStr(aCStr2, aCStr);
							CAddStr(aCStr2, EOL_STRING);
							tLen = CLen(aCStr2);
							LockXFile(xrefNum, 0, -1, true);		// for multiprocess
							err = WriteXFile(xrefNum, aCStr2, &tLen);
							UnlockXFile(xrefNum, 0, -1);
						}
						CloseXFile(&xrefNum);
						xrefNum = 0;
					}
					if NOT(err)
					{	CEquStr(resultString, FILE_HD_PREFIX);
						CAddStr(resultString, aCStr);
						// err = BAPI_StringToObj(api_data, aCStr2, CLen(aCStr2), &exeMethodRecP->resultObjRef);
					}
				}
				if (xrefNum)
					CloseXFile(&xrefNum);
			}
			gFileQueueModified = true;
			XThreadsLeaveCriticalSection();
		}
	}
	if (err)
	{	if (fileCreated)
			DeleteXFile(aCStr);
	}
	else
		SendMail_Run(true);
	
return err;
}

//===========================================================================================
static XErr	_SendMailAsync(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
CStr255			auth, toCStr, resultString, fromaddress, host, filePath;
unsigned long	minutes;
long			textLen;
BlockRef		textBlock = 0, toRef = 0;
char			*toaddress;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, host, nil, 255, kImplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, fromaddress, nil, 255, kImplicitTypeCast))
		{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[2].objRef, toCStr, &toaddress, nil, &toRef, kImplicitTypeCast))
			{	if NOT(err = _GetText(api_data, &exeMethodRecP->paramVarsP[3].objRef, &textBlock, &textLen))
				{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[4].objRef, filePath, nil, 255, kImplicitTypeCast))
					{	if NOT(err = BAPI_ObjToUnsigned(api_data, &exeMethodRecP->paramVarsP[5].objRef, &minutes, kImplicitTypeCast))
						{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[6].objRef, auth, nil, 255, kImplicitTypeCast))
							{	if (*auth)
									err = _EncodeAuth(fromaddress, auth);
								if NOT(err)
								{	if NOT(err = SendAsyncronousMail(api_data, host, fromaddress, auth, toaddress, textBlock, textLen, filePath, minutes, resultString))
										err = BAPI_StringToObj(api_data, resultString, CLen(resultString), &exeMethodRecP->resultObjRef);
								}
							}
						}
					}
				}
			}
		}
	}
	if (toRef)
		BAPI_ReleaseBlock(&toRef);
	if (textBlock)
		DisposeBlock(&textBlock);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	SendMail_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data, methodID = exeMethodRecP->methodID;

	//exeMethodRecP->resultObjRef.id = 0;
	//BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
	switch(methodID)
	{	
		case  kSendMail:
			err = _SendMail(pbPtr, exeMethodRecP, api_data);
			break;
		case kSendMailAsync:
			err = _SendMailAsync(exeMethodRecP, api_data);
			break;
		case kSendMailFile:
			err = _SendMailFile(pbPtr, exeMethodRecP, api_data);
			break;
		case kParseMailFile:
			err = _ParseMailFile(exeMethodRecP, api_data);
			break;
		case kGetMXRecords:
			err = _GetMXRecords(exeMethodRecP, api_data);
			break;
			
		default:
			err = Err_NoSuchFunction;
			break;
	}

return err;
}

//===========================================================================================
static XErr	SendMail_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr					err = noErr;
BAPI_MemberRecord		sendMailMethods[TOT_METHODS] = 
					{	"SendMail", 		kSendMail, 			"static string SendMail(string host, string from, string to, string text, string auth)",
						"SendMailAsync", 	kSendMailAsync, 	"static string SendMailAsync(string host, string from, string to, string text, string filePath, unsigned minutes, string auth)",
						"SendMailFile",		kSendMailFile,		"static string SendMailFile(string filePath)",
						"ParseMailFile",	kParseMailFile,		"static array ParseMailFile(string filePath)",
						"GetMXRecords",		kGetMXRecords,		"static array GetMXRecords(string domain)"
					};
	
CStr255				basePath, aCStr;
long				aLong;

	if (err = BAPI_NewMethods(pbPtr->api_data, sendMailClassID, sendMailMethods, TOT_METHODS, nil))
		return err;
	
	if (err = BAPI_RegisterErrors(pbPtr->api_data, sendMailClassID, SENDMAIL_FIRSTERR, sendMailErrors, SENDMAIL_TOT_ERRORS))
		return err;

	if (err = NetInit(_Yield, _Log, (short)gsMaxUsers/*pbPtr->param.initRec.maxUsers*/, false))
		return err;

	BAPI_GetBifernoHome(0, gTempSpoolPath);				// file:/...
	if (gTempSpoolPath[CLen(gTempSpoolPath)-1] != '/')
		CAddChar(gTempSpoolPath, '/');
	CAddStr(gTempSpoolPath, "BifernoSpool/");

	if NOT(err = XGetApplicationFolderPath(basePath))
	{	CEquStr(gsQueueFilePath, basePath);
		CAddStr(gsQueueFilePath, QUEUE_FILE);
		
		CEquStr(gsQueueTempFilePath, basePath);
		CAddStr(gsQueueTempFilePath, QUEUE_TEMP_FILE);
		
		CEquStr(gsLogFilePath, basePath);
		CAddStr(gsLogFilePath, LOG_FILE);

		CEquStr(gsDoingFilePath, basePath);
		CAddStr(gsDoingFilePath, DOING_TEMP_FILE);
		
		gsLogFileRef = 0;
		_ChecklogFile();

		gsDoingAsync = false;
		gFileQueueModified = false;
		gsLastSend = 0;
		gsShuttingDown = false;
		//gsSendMailAsyncSemaphore = XThreadsCreateSemaphore(_GREEN, &err);
		//if NOT(err)
		{	
			if NOT(err = OpenXFile(gsDoingFilePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &gsDoing_xrefNum))
			{	
				#ifndef __MAC_XLIB__
					ChangeFileMode(gsDoing_xrefNum, gsDoingFilePath, kS_IRUSR+kS_IWUSR+kS_IRGRP+kS_IWGRP+kS_IROTH+kS_IWOTH);
				#endif
				XCurrentDateTimeToString(aCStr, kComplete);
				CAddStr(aCStr, EOL_STRING);
				CAddStr(aCStr, "Smtp Doing File created");
				aLong = CLen(aCStr);
				err = WriteXFile(gsDoing_xrefNum, aCStr, &aLong);
				#ifdef __MAC_XLIB__	
					CloseXFile(&gsDoing_xrefNum);
				#endif
			}
			else
				sprintf(pbPtr->error, "Err %d while opening '%s'", (int)err, DOING_TEMP_FILE);
		}
	}
				
return err;
}

//===========================================================================================
static XErr	SendMail_ShutDown(long api_data)
{
XErr			err = noErr, err2 = noErr;
unsigned long 	initMilliSecs, millisecs;

	if (gsDoingAsync)
	{	BAPI_Log(api_data, "Waiting end of Async ...");
		gsShuttingDown = true;
		XGetMilliseconds(&initMilliSecs);
		while (gsDoingAsync)
		{	
		#ifndef __MAC_XLIB__
			XDelay(20);
		#endif
			SmtpIdle(0);
			if (err = BAPI_Yield(api_data, nil))
				break;
			XGetMilliseconds(&millisecs);
			if ((millisecs - initMilliSecs) > kAsyncWaitTimeout)
				break;
		}
	}
	err2 = NetTerm(false, 0);
	if (err2 && NOT(err))
		err = err2;
	if (gsLogFileRef && NOT(CheckPath(gsLogFilePath, true)))
		CloseXFile(&gsLogFileRef);
	if (gsDoing_xrefNum)
		CloseXFile(&gsDoing_xrefNum);
	//err = XThreadsCloseSemaphore(gsSendMailAsyncSemaphore);
	
return err;
}


//===========================================================================================
/*static void _LogWaiting(Boolean init)
{
unsigned long	threadID;
CStr255			aCStr, tempStr;

	XThreadsEnterCriticalSection();
	
	// task id
	XGetCurrentThread(&threadID);
	CNumToString(threadID, tempStr);
	CEquStr(aCStr, "Thread ");
	CAddStr(aCStr, tempStr);
	BAPI_Log(0, aCStr);

	// date time "FINISHED"
	XCurrentDateTimeToString(tempStr, kWantDate);
	CEquStr(aCStr, tempStr);
	CAddStr(aCStr, " ");
	XCurrentDateTimeToString(tempStr, kWantHour+kWantSecs+kLeadingZeros);
	CAddStr(aCStr, tempStr);
	CAddStr(aCStr, EOL_STRING);
	if (init)
		CAddStr(aCStr, " Waiting");
	else
		CAddStr(aCStr, " finish wait");
	BAPI_Log(0, aCStr);
	BAPI_Log(0, EOL_STRING);
	
	XThreadsLeaveCriticalSection();
}
*/
//===========================================================================================
static XErr	SendMail_Run(Boolean doAnyway)
{
XErr			err = noErr;
unsigned long	now = 0;
Boolean			doIt = false;
unsigned long	threadID;

	if (doAnyway)
		doIt = true;
	else
	{	XGetSeconds(&now);
		if ((now - gsLastSend) > TIME_BETWEEN_SENT)
			doIt = true;
	}
	if (doIt)
	{	//_LogWaiting(true);
		if NOT(err = XNewThread(&threadID, 0, _DoAsync, 64L * 1019L, nil))
		{	if NOT(now)
				XGetSeconds(&now);
			gsLastSend = now;
		}
		//_LogWaiting(false);
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	sendMail_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "smtp");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(EMail utility)");
			sendMailClassID = pbPtr->param.registerRec.pluginID;
			bifernoVersion = pbPtr->param.registerRec.api_version;
			gsLocally = pbPtr->param.registerRec.bifernoInLocalMode;
			gsMaxUsers = pbPtr->param.registerRec.maxUsers;
			break;
		case kInit:
			if NOT(err = SendMail_Init(pbPtr))
			{	if NOT(gsLocally)
					err = SendMail_Run(true);
			}
			break;
		case kShutDown:
			err = SendMail_ShutDown(pbPtr->api_data);
			break;
		case kRun:
			if (NOT(pbPtr->param.runRec.shuttingDown) && NOT(gsLocally/*pbPtr->param.runRec.localScript*/))
				err = SendMail_Run(false);
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kDestructor:
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = SendMail_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kGetProperty:
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kGetErrMessage:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
		default:
			err = Err_BAPI_MessageNotHandled;
			break;
	}
	
return err;
}
#if __MWERKS__
#pragma export off
#endif


#endif	// WITH_SENDMAIL
