/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Reference.c,v 1.17 2006-06-21 10:40:22 valfer Exp $
	|______________________________________________________________________________
*/

#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"Reference.h"
#include 	<string.h>

static 	long	gsApiVersion, gsRefClassID;

typedef struct {
				ObjRef			target;
				BlockRef		propList;
				} RefRecord;

//===========================================================================================
// get target class
static XErr	Ref_GetTargetClass(long api_data, ObjRefP objRef, long *targetClassP, Boolean recursive)
{
XErr		err = noErr;
long		tLen;
RefRecord	refRecord;

	tLen = sizeof(RefRecord);
	if NOT(err = BAPI_GetObj(api_data, objRef, (Ptr)&refRecord, &tLen, 0, nil))
	{	if (tLen)
		{	if (recursive && (BAPI_GetObjClassID(api_data, &refRecord.target) == gsRefClassID))
				err = Ref_GetTargetClass(api_data, &refRecord.target, targetClassP, recursive);
			else
			{	if (refRecord.propList)
					err = BAPI_GetPropertyListClassID(api_data, refRecord.propList, targetClassP);
				else
					*targetClassP = BAPI_GetObjClassID(api_data, &refRecord.target);
			}
		}
		else
			*targetClassP = 0;
	}
	
return err;
}

//===========================================================================================
// get target with all its properties
static XErr	Ref_GetTarget(long api_data, ObjRefP objRef, ObjRefP realTargetP, Boolean recursive)
{
XErr		err = noErr;
long		tLen;
RefRecord	refRecord;
ObjRef		target;

	if (BAPI_GetObjClassID(api_data, objRef) == gsRefClassID)
	{
		tLen = sizeof(RefRecord);
		if NOT(err = BAPI_ReadObj(api_data, objRef, (Ptr)&refRecord, &tLen, 0, nil))
		{	if (recursive && (BAPI_GetObjClassID(api_data, &refRecord.target) == gsRefClassID))
				err = Ref_GetTarget(api_data, &refRecord.target, &target, recursive);
			else
				target = refRecord.target;
			if NOT(err)
			{	if (BAPI_GetObjClassID(api_data, &target) == gsRefClassID)
					*realTargetP = target;
				else
					err = BAPI_ApplyPropertyList(api_data, &target, refRecord.propList, GET, false, realTargetP);
			}
		}
	}
	else
		*realTargetP = *objRef;
	
return err;
}

//===========================================================================================
// get target with all its properties
static XErr	Ref_NewReference(long api_data, ObjRefP target, BlockRef propList, ObjRef *resultObjRefP)
{
XErr		err = noErr;
RefRecord	refRecord;

	refRecord.target = *target;
	refRecord.propList = propList;
	err = BAPI_BufferToObj(api_data, &refRecord, sizeof(refRecord), gsRefClassID, true, nil, resultObjRefP);
	
return err;
}

//===========================================================================================
static XErr	Ref_SetTarget(long api_data, ObjRefP objRef, ObjRefP value, Boolean recursive)
{
XErr		err = noErr;
long		tLen;
RefRecord	refRecord;

	tLen = sizeof(RefRecord);
	if NOT(err = BAPI_ReadObj(api_data, objRef, (Ptr)&refRecord, &tLen, 0, nil))
	{	if (recursive && (BAPI_GetObjClassID(api_data, &refRecord.target) == gsRefClassID))
			err = Ref_SetTarget(api_data, &refRecord.target, value, recursive);
		else
			err = BAPI_ApplyPropertyList(api_data, &refRecord.target, refRecord.propList, SET, false, value);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_Ref_GetPrimitiveString(PrimitiveRec *primitiveRecP, char *result, long strLen)
{
XErr			err = noErr;
char			*strP, *p;
PrimitiveUnion	*param_d = &primitiveRecP->result;

	if (primitiveRecP->resultWanted == kCString)
	{	strP = result;
		p = param_d->text.stringP;
		if (p)
		{	if (param_d->text.stringMaxStorage >= (strLen+1))
			{	CopyBlock(p, strP, strLen);
				p[strLen] = 0;
				param_d->text.stringLen = strLen;
			}
			else
			{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
				p[param_d->text.stringMaxStorage - 1] = 0;
				param_d->text.stringLen = strLen;
				err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
			}
		}
		else
			param_d->text.stringLen = strLen;
	}
	else
		err = XError(kBAPI_Error, Err_IllegalTypeCast);

return err;
}

//===========================================================================================
static XErr	_Ref_ModifyHook(long api_data, ObjRefP varToSet, ObjRefP value)
{
XErr			err = noErr;
RefRecord		refRecord;
long			objLen;
Boolean			needSer;
ObjRef			targ, cloned;
ParameterRec	param;

	if NOT(err = BAPI_NeedSerialize(api_data, varToSet, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(RefRecord);
		if NOT(err = BAPI_ReadObj(api_data, varToSet, (Ptr)&refRecord, &objLen, 0, nil))	// ex BAPI_GetObj
		{	if (BAPI_GetObjClassID(api_data, value) == gsRefClassID)
				err = Ref_GetTarget(api_data, value, value, true);
			if NOT(err)
			{	if (refRecord.propList)
				{	if NOT(err = BAPI_ApplyPropertyList(api_data, &refRecord.target, refRecord.propList, GET, true, &targ))
						err = BAPI_ApplyPropertyList(api_data, &targ, refRecord.propList, SET, false, value);
				}
				else
				{	// if value is not TEMP, create a copy
					if (BAPI_GetObjScope(api_data, value) != TEMP)
					{	*param.name = 0;
						param.objRef = *value;
						BAPI_InvalObjRef(api_data, &cloned);
						if NOT(err = BAPI_Clone(api_data, value, &cloned, false))
							value = &cloned;
					}
					if NOT(err)
						err = BAPI_ReplaceObj(api_data, &refRecord.target, value, true);
				}
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr	_Ref_ScopeAllowedHook(long api_data, ObjRefP objP, long scope, Boolean *allowedP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(scope)
#endif
XErr		err = noErr;
long		tLen, target_scope;
RefRecord	refRecord;

	tLen = sizeof(RefRecord);
	if NOT(err = BAPI_ReadObj(api_data, objP, (Ptr)&refRecord, &tLen, 0, nil))
	{	// can't ref an object with wider scope
		target_scope = BAPI_GetObjScope(api_data, &refRecord.target);
		*allowedP = (Boolean)(scope <= target_scope);
	}
		
return err;
}

//===========================================================================================
static XErr	_Ref_IncrementHook(long api_data, ObjRefP varToIncrement, Boolean isDecr)
{
XErr			err = noErr;
Boolean			needSer;
ObjRef			target;

	if NOT(err = BAPI_NeedSerialize(api_data, varToIncrement, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if NOT(err = Ref_GetTarget(api_data, varToIncrement, &target, false))
		{	if NOT(err = BAPI_Increment(api_data, &target, isDecr))
				err = Ref_SetTarget(api_data, varToIncrement, &target, false);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr	Ref_GetTargetInfo(long api_data, ExecuteMethodRec *exeMethodRecP)
{
XErr			err = noErr;
RefRecord		refRecord;
long			stackDiff, propNamesBlockLength, totSize, tLen;
CStr63			scopeName, name;
BufferID		buffID;
BlockRef		propNamesBlock, buffBlock;
Ptr				resultP;
ObjRefP			tObjP;
Boolean			isInit;

	tLen = sizeof(RefRecord);
	if NOT(err = BAPI_GetObj(api_data, &exeMethodRecP->objRef, (Ptr)&refRecord, &tLen, 0, nil))
	{	if (tLen)
		{	if (buffID = BufferCreate(256, &err))
			{	if (err = BAPI_GetObjInfo(api_data, &refRecord.target, nil, name))
					goto out;
				if (err = BufferAddCString(buffID, name, NO_ENC, 0))
					goto out;
				if (refRecord.propList)
				{	if (err = BAPI_GetPropertyListNames(api_data, refRecord.propList, &propNamesBlock, &propNamesBlockLength))
						goto out;
					LockBlock(propNamesBlock);
					err = BufferAddBuffer(buffID, GetPtr(propNamesBlock), propNamesBlockLength);
					DisposeBlock(&propNamesBlock);
					if (err)
						goto out;
				}
				buffBlock = BufferGetBlockRefExtSize(buffID, &totSize, &resultP);
				LockBlock(buffBlock);
				err = BAPI_StringToObj(api_data, resultP, totSize, &exeMethodRecP->resultObjRef);
				BufferFree(buffID);
				if NOT(err = BAPI_LocateObj(api_data, &refRecord.target, scopeName, &stackDiff))
				{	// scope
					tObjP = &exeMethodRecP->paramVarsP[0].objRef;
					if NOT(err = BAPI_IsVariableInitialized(api_data, tObjP, &isInit))
					{	if (isInit)
							err = BAPI_StringToObj(api_data, scopeName, CLen(scopeName), tObjP);
					}
					// stack diff
					tObjP = &exeMethodRecP->paramVarsP[1].objRef;
					if NOT(err = BAPI_IsVariableInitialized(api_data, tObjP, &isInit))
					{	if (isInit)
							err = BAPI_IntToObj(api_data, stackDiff, tObjP);
					}
				}
			}
		}
		else
			err = BAPI_StringToObj(api_data, "", 0, &exeMethodRecP->resultObjRef);
	}

out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Ref_Constructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
long			api_data = pbPtr->api_data;
long			targetStrLen;
RefRecord		refRecord;
CStr255			targetStr;

	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP->objRef, targetStr, &targetStrLen, 256, kImplicitTypeCast))
	{	if NOT(err = BAPI_GetReference(api_data, targetStr, &refRecord.target, &refRecord.propList))
			err = BAPI_BufferToObj(api_data, &refRecord, sizeof(refRecord), gsRefClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
	}
		
return err;
}

//===========================================================================================
static XErr	Ref_Clone(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
ObjRef			target;
Boolean			needSer;
long			objLen, api_data = pbPtr->api_data;
BlockRef		newPropList;
RefRecord		refRecord;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &constructorRecP->varRecsP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if (constructorRecP->cloneTarget)
		{	if NOT(err = Ref_GetTarget(api_data, &constructorRecP->varRecsP->objRef, &target, false))
				err = BAPI_Clone(api_data, &target, &constructorRecP->resultObjRef, false);
		}
		else
		{	objLen = sizeof(RefRecord);
			if NOT(err = BAPI_GetObj(pbPtr->api_data, &constructorRecP->varRecsP->objRef, (Ptr)&refRecord, &objLen, 0, nil))
			{	// Clone the prop list
				if (refRecord.propList)
				{	if NOT(err = BAPI_ClonePropertyList(api_data, refRecord.propList, &newPropList))
						refRecord.propList = newPropList;
				}
				if NOT(err)
					err = BAPI_BufferToObj(api_data, &refRecord, sizeof(refRecord), gsRefClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef);
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}


//===========================================================================================
static XErr	Ref_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
RefRecord		refRecord;
long			objLen;
Boolean			needSer;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &destructorRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		objLen = sizeof(RefRecord);
		if NOT(err = BAPI_GetObj(pbPtr->api_data, &destructorRecP->objRef, (Ptr)&refRecord, &objLen, 0, nil))
		{	if (objLen && refRecord.propList)
				BAPI_DisposePropertyList(pbPtr->api_data, &refRecord.propList);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr	Ref_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				api_data = pbPtr->api_data;
Boolean				sideEffect, needSer;
ObjRef				realTarg;

	if (BAPI_IsObjRefValid(api_data, &exeMethodRecP->objRef))
		err = BAPI_NeedSerialize(api_data, &exeMethodRecP->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if (exeMethodRecP->methodID == 1)
		{
			err = Ref_GetTargetInfo(api_data, exeMethodRecP);
		}
		else
		{	if NOT(err = Ref_GetTarget(api_data, &exeMethodRecP->objRef, &realTarg, false))
			{	if NOT(err = BAPI_ExecuteMethod(api_data, &realTarg, exeMethodRecP->paramVarsP, exeMethodRecP->totParams, exeMethodRecP->methodName, &exeMethodRecP->resultObjRef, &sideEffect))
				{	if (sideEffect)
						err = Ref_SetTarget(api_data, &exeMethodRecP->objRef, &realTarg, false);
				}
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
static XErr	Ref_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
Boolean			needSer;
long			api_data = pbPtr->api_data;
ObjRef			realTarg;

	if (BAPI_IsObjRefValid(api_data, &getPropertyRec->objRef))
		err = BAPI_NeedSerialize(api_data, &getPropertyRec->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if (getPropertyRec->propertyID == 1)
		{
			err = Ref_GetTarget(api_data, &getPropertyRec->objRef, &getPropertyRec->resultObjRef, false);
		}
		else
		{	if NOT(err = Ref_GetTarget(api_data, &getPropertyRec->objRef, &realTarg, true))
				err = BAPI_GetProperty(api_data, &realTarg, getPropertyRec->propertyName, getPropertyRec->propertyDim, getPropertyRec->propertyIndex, &getPropertyRec->resultObjRef);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr	Ref_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
long				api_data = pbPtr->api_data;
Boolean				needSer;
ObjRef				realTarg;

	if (BAPI_IsObjRefValid(api_data, &setPropertyRecP->objRef))
		err = BAPI_NeedSerialize(api_data, &setPropertyRecP->objRef, &needSer);
	else
		needSer = false;
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if (setPropertyRecP->propertyID == 1)
		{
			err = _Ref_ModifyHook(api_data, &setPropertyRecP->objRef, &setPropertyRecP->value);
		}
		else
		{	if NOT(err = Ref_GetTarget(api_data, &setPropertyRecP->objRef, &realTarg, false))
			{	if NOT(err = BAPI_SetProperty(api_data, &realTarg, setPropertyRecP->propertyName, setPropertyRecP->propertyDim, setPropertyRecP->propertyIndex, &setPropertyRecP->value))
					err = Ref_SetTarget(api_data, &setPropertyRecP->objRef, &realTarg, false);
			}
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}
		
return err;
}

//===========================================================================================
static XErr Ref_Init(Biferno_ParamBlockPtr pbPtr)
{
BAPI_MemberRecord	refProperty[1] = 
					{	"target", 	1,	"obj"
					};
BAPI_MemberRecord	refMethod[1] = 
					{	"GetTargetInfo", 	1,	"string GetTargetInfo(string *targetScope, int *targetStack)"
					};
XErr	err = noErr;

	if NOT(err = BAPI_NewProperties(pbPtr->api_data, gsRefClassID, refProperty, 1, nil))
		err = BAPI_NewMethods(pbPtr->api_data, gsRefClassID, refMethod, 1, nil);

return err;
}

//===========================================================================================
static XErr	Ref_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, "ref");
	gsApiVersion = pbPtr->param.registerRec.api_version;
	gsRefClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.fixedSize = true;
	pbPtr->param.registerRec.dynamic = true;
	pbPtr->param.registerRec.wantDestructor = true;
	CEquStr(pbPtr->param.registerRec.constructor, "void ref(string target)");
	// Hooks
	pbPtr->param.registerRec.modifyHook = _Ref_ModifyHook;
	pbPtr->param.registerRec.scopeAllowedHook = _Ref_ScopeAllowedHook;
	pbPtr->param.registerRec.incrementHook = _Ref_IncrementHook;
	if NOT(err = BAPI_RegisterSymbol(pbPtr->api_data, gsRefClassID, "Ref_GetTarget", (long)Ref_GetTarget))
	{	if NOT(err = BAPI_RegisterSymbol(pbPtr->api_data, gsRefClassID, "Ref_NewReference", (long)Ref_NewReference))
			if NOT(err = BAPI_RegisterSymbol(pbPtr->api_data, gsRefClassID, "Ref_GetTargetClass", (long)Ref_GetTargetClass))
				;//err = BAPI_RegisterSymbol(pbPtr->api_data, gsRefClassID, "Ref_SetTarget", (long)Ref_SetTarget);
	}

//out:
return err;
}

//===========================================================================================
static XErr	Ref_Primitive(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
RefRecord		refRecord;
Boolean			needSer;
long			totSize, propNamesBlockLength, tLen, api_data = pbPtr->api_data;
PrimitiveRec	*primitiveRecP = &pbPtr->param.primitiveRec;
CStr255			name, resultStr;
ObjRef			real_target;
BufferID		buffID = 0;
BlockRef		buffBlock, propNamesBlock;
Ptr				resultP;

	if NOT(err = BAPI_NeedSerialize(api_data, &primitiveRecP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		switch(primitiveRecP->result.text.variant)
		{	
			case kNormal:
			case kForConstructor:
				if NOT(err = Ref_GetTarget(api_data, &primitiveRecP->objRef, &primitiveRecP->objRef, false))
					err = BAPI_Accessor(api_data, BAPI_GetObjClassID(api_data, &primitiveRecP->objRef), kPrimitive, pbPtr);
				break;
			case kForDebug:
				tLen = sizeof(RefRecord);
				if NOT(err = BAPI_GetObj(api_data, &primitiveRecP->objRef, (Ptr)&refRecord, &tLen, 0, nil))
				{	if (tLen)
					{	if (buffID = BufferCreate(256, &err))
						{	if (err = BufferAddCString(buffID, "-> ", NO_ENC, 0))
								goto out;
							if (refRecord.propList)
							{	if (err = BAPI_GetPropertyListNames(api_data, refRecord.propList, &propNamesBlock, &propNamesBlockLength))
									goto out;
								LockBlock(propNamesBlock);
								err = BufferAddBuffer(buffID, GetPtr(propNamesBlock), propNamesBlockLength);
								DisposeBlock(&propNamesBlock);
								if (err)
									goto out;
								if (err = BufferAddCString(buffID, " of ", NO_ENC, 0))
									goto out;
							}
							if (err = BAPI_GetObjInfo(api_data, &refRecord.target, nil, name))
								goto out;
							if (err = BufferAddCString(buffID, name, NO_ENC, 0))
								goto out;
							if (err = BAPI_ApplyPropertyList(api_data, &refRecord.target, refRecord.propList, GET, false, &real_target))
								goto out;
							BAPI_NameFromClassID(api_data, BAPI_GetObjClassID(api_data, &real_target), name);
							CEquStr(resultStr, " (");
							CAddStr(resultStr, name);
							tLen = CAddStr(resultStr, ":");
							if (BAPI_ObjToDebugString(api_data, &real_target, resultStr + tLen, nil, 256 - tLen - 4, kExplicitTypeCast))
							{	resultStr[255 - 4] = 0;
								CAddStr(resultStr, "...)");
							}
							else
								CAddChar(resultStr, ')');
							if (err = BufferAddCString(buffID, resultStr, NO_ENC, 0))
								goto out;
								
							buffBlock = BufferGetBlockRefExtSize(buffID, &totSize, &resultP);
							LockBlock(buffBlock);
							err = _Ref_GetPrimitiveString(primitiveRecP, resultP, totSize);
						}
						//CEquStr(resultStr, "-> ");
						//CAddStr(resultStr, refRecord.targetStr);
						err = _Ref_GetPrimitiveString(primitiveRecP, resultP, totSize);
					}
					else
						err = _Ref_GetPrimitiveString(primitiveRecP, "", 0);
				}
				break;
		}				
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

out:
if (buffID)
	BufferFree(buffID);
return err;
}

//===========================================================================================
static XErr	Ref_ExecuteOperation(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteOperationRec	*exeOperationRecP = &pbPtr->param.executeOperationRec;
long				api_data = pbPtr->api_data;
Boolean				needSer;
ObjRef				targ1, targ2;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &exeOperationRecP->objRef1, &needSer))
	{	if NOT(needSer)
			err = BAPI_NeedSerialize(pbPtr->api_data, &exeOperationRecP->objRef2, nil);
	}
	if NOT(err)
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if NOT(err = Ref_GetTarget(api_data, &exeOperationRecP->objRef1, &targ1, false))
		{	if NOT(err = Ref_GetTarget(api_data, &exeOperationRecP->objRef2, &targ2, false))
				err = BAPI_ExecuteOperation(api_data, &targ1, &targ2, exeOperationRecP->operation, &exeOperationRecP->resultObjRef);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

		
return err;
}

//===========================================================================================
static XErr	Ref_Opposite(Biferno_ParamBlockPtr pbPtr)
{
OppositeRec		*oppP = &pbPtr->param.oppositeRec;
XErr			err = noErr;
ObjRef			target;
Boolean			needSer;
long			api_data = pbPtr->api_data;

	if NOT(err = BAPI_NeedSerialize(pbPtr->api_data, &oppP->objRef, &needSer))
	{	if (needSer)
			XThreadsEnterCriticalSection();
		if NOT(err = Ref_GetTarget(api_data, &oppP->objRef, &target, false))
		{	oppP->objRef = target;
			err = BAPI_Accessor(api_data, BAPI_GetObjClassID(api_data, &target), kOpposite, pbPtr);
		}
		if (needSer)
			XThreadsLeaveCriticalSection();
	}

return err;
}


#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	reference_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = Ref_Register(pbPtr);
			break;
		case kInit:
			err = Ref_Init(pbPtr);
			break;
		case kShutDown:
		case kRun:
		case kExit:
			break;
		case kConstructor:
			err = Ref_Constructor(pbPtr);
			break;
		case kTypeCast:
			err = XError(kBAPI_Error, Err_IllegalTypeCast);
			break;
		case kClone:
			err = Ref_Clone(pbPtr);
			break;
		case kDestructor:
			err = Ref_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = Ref_ExecuteOperation(pbPtr);
			break;
		case kOpposite:
			err = Ref_Opposite(pbPtr);
			break;
		case kExecuteMethod:
			err = Ref_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
		case kGetProperty:
			err = Ref_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Ref_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = Ref_Primitive(pbPtr);
			break;
		case kGetErrMessage:
		case kSuperIsChanged:
			break;
		default:
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


