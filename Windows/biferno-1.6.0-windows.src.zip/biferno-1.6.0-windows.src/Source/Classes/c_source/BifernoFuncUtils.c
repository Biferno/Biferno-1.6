/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoFuncUtils.c,v 1.7 2006-03-15 15:03:59 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include 	"XLibPrivate.h"
//#include	"Helpers.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

#include <stdlib.h>

#if __UNIX_XLIB__ || __MACOSX__
	#if __MACOSX__
		#include <sys/types.h>
		#include <unistd.h>
		#include <stdlib.h>
	#endif
	#include <pwd.h>
	#include <grp.h>
	#include <errno.h>
#endif

// Biferno Functions
enum{
		kPrint = 1,
		kEval
	};
#define TOT_FUNCTIONS	2
	
static long	kBifernoUtilsClassID;
static long	bifernoVersion;

#include <stdio.h>
//===========================================================================================
static XErr	BifernoUtils_Init(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
BAPI_MemberRecord	bifernoFuncs[TOT_FUNCTIONS] = 
					{	
						"print", 	kPrint, 	"void print(string str)",
						"Eval",		kEval,		"string Eval(string text, boolean resume)"
					};
	
	if (err = BAPI_NewFunctions(pbPtr->api_data, kBifernoUtilsClassID, bifernoFuncs, TOT_FUNCTIONS))
		return err;

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_Print(ExecuteMethodRec *exeMethodRecP, long totParams, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
BlockRef	ref;
char		*stringP;
long		stringLen;

	if (totParams == 1)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
		{	err = BAPI_StandardOutput(api_data, stringP, stringLen, true);
			BAPI_ReleaseBlock(&ref);
		}
		BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

//===========================================================================================
static XErr	_Eval(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
BlockRef	ref;
char		*stringP;
long		stringLen;
Boolean		resume;

	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, &exeMethodRecP->paramVarsP[1].objRef, &resume, kExplicitTypeCast))
		{	if (stringLen)
				err = BAPI_Eval(api_data, stringP, stringLen, &exeMethodRecP->resultObjRef, false, resume);
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
			if (err && resume)
			{	BAPI_ResetError(api_data);
				if NOT(err = BAPI_GetErrDescription(api_data, err, aCStr, nil, nil, nil, nil, 0, nil))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &exeMethodRecP->resultObjRef);
			}
		}
		BAPI_ReleaseBlock(&ref);
	}

return err;
}

//===========================================================================================
static XErr	BifernoUtils_ExecuteFunction(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				totParams = exeMethodRecP->totParams;
long 				api_data = pbPtr->api_data, methodID = exeMethodRecP->methodID;

	switch (methodID)
	{	
		case kPrint:
			err = _Print(exeMethodRecP, totParams, api_data);
			break;
		case kEval:
			err = _Eval(exeMethodRecP, api_data);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchFunction);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif
//===========================================================================================
XErr	BifernoUtils_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewFunctionsPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, "Biferno Functions");
			CEquStr(pbPtr->param.registerRec.pluginDescr, "(Utils)");
			kBifernoUtilsClassID = pbPtr->param.registerRec.pluginID;
			bifernoVersion = pbPtr->param.registerRec.api_version;
			break;
		case kInit:
			err = BifernoUtils_Init(pbPtr);
			break;
		case kShutDown:
		case kRun:
		case kExit:
		case kConstructor:
		case kTypeCast:
		case kDestructor:
		case kExecuteOperation:
		case kExecuteMethod:
			break;
		case kExecuteFunction:
			err = BifernoUtils_ExecuteFunction(pbPtr);
			break;
		case kGetProperty:
		case kSetProperty:
		case kPrimitive:
			break;


		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}
	
return err;
}
#if __MWERKS__
#pragma export off
#endif


