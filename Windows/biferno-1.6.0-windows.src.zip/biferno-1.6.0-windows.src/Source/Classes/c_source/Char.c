/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Char.c,v 1.6 2003-07-16 13:19:19 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

static long	charClassID;
static long		gsApiVersion, gsIntClassID, gsStringClassID;

#define	gsPlugName	"char"

static BAPI_MemberRecord	charProperty[1] = {	"ascii", 1,	"unsigned"};

//===========================================================================================
/*static XErr	_CharToNum(char *charP, long *valP, LONGLONG *llValueP, unsigned long *uValP, double *doubValP)
{
int		ch = *charP;
XErr	err = noErr;

	if ((ch >= '0') && (ch <= '9'))
	{	if (valP)
		{	if (CStringToNumExt(charP, valP, nil) == -1)
				err = XError(kBAPI_Error, Err_Overflow);
		}
		else if (uValP)
		{	if (CStringToNumExt(charP, nil, uValP) == -1)
				err = XError(kBAPI_Error, Err_Overflow);
		}
		else if (llValueP)
		{	if (CStringToLongNum(charP, 1, llValueP) == -1)
				err = XError(kBAPI_Error, Err_Overflow);
		}
		else if (doubValP)
			*doubValP = CStrToReal(charP);
	}
	else
	{	if (valP)
			*valP = ch;
		else if (uValP)
			*uValP = ch;
		else if (llValueP)
			*llValueP = ch;
		else if (doubValP)
			*doubValP = ch;
	}
		
return err;		
}*/

//===========================================================================================
/*static void	_SpecialChars(Ptr textPPtr, long *textLenP)
{
Ptr		tempP;
long	tempLen, finalLen;
int		ch;

	tempP = textPPtr;
	tempLen = *textLenP;
	finalLen = tempLen;
	if (tempLen)
	{	do {
			if ((tempLen > 1) && (*tempP == '\\') && (ch = SpecialChar(*(tempP+1))))
			{	*tempP = ch;
				tempP++;
				tempLen--;
				CopyBlock(tempP, tempP+1, finalLen - tempLen);
				finalLen--;
			}
			tempP++;
			tempLen--;
		} while (tempLen > 0);
	}
	
*textLenP = finalLen;
}*/

//===========================================================================================
static XErr	Char_Constructor(Biferno_ParamBlockPtr pbPtr, Biferno_Message message)
{
XErr			err = noErr;
long			strLen;
ConstructorRec	*constructorRecP = &pbPtr->param.constructorRec;
//long			saveScope;
CStr15			theChar;
ObjRef			super;
long			api_data = pbPtr->api_data;

	//saveScope = constructorRecP->scope;
	//constructorRecP->scope = TEMP;		// Cos� la stringa la crei temporanea
	if (constructorRecP->totVars == 1)
	{	if ((message == kConstructor) && (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP->objRef) == gsIntClassID))
		{	long	aLong;
		
			if NOT(err = BAPI_ObjToInt(api_data, &constructorRecP->varRecsP->objRef, &aLong, kImplicitTypeCast))
			{	if (aLong <= 255)
					*theChar = (char)aLong;
				else
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
			}
		}
		else 
		{	//BAPI_InvalObjRef(api_data, &constructorRecP->resultObjRef);
			err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP->objRef, theChar, &strLen, 2, kImplicitTypeCast);
			if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall) || (strLen != 1))
			{	CEquStr(pbPtr->error, "argument must be 1-char-string");
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
			}
			/*if NOT(err = BAPI_Accessor(api_data, gsStringClassID, kConstructor, pbPtr))
			{	err = BAPI_ObjToString(api_data, &constructorRecP->resultObjRef, theChar, &strLen, 2, kImplicitTypeCast);
				if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
				{	CEquStr(pbPtr->error, "argument must be 1-char-string");
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
				}
			}*/
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
		CEquStr(pbPtr->error, "char(obj param)");
	}
	
	if NOT(err)
	{	//constructorRecP->scope = saveScope;
		BAPI_InvalObjRef(api_data, &super);
		if NOT(err = BAPI_StringToObj(api_data, theChar, 1, &super))
		{	if NOT(err = BAPI_BufferToObjWithSuper(api_data, theChar, 1, charClassID, true, &super, constructorRecP->privateData, &constructorRecP->resultObjRef))
				;//BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, charClassID);
				//constructorRecP->resultObjRef.classID = charClassID;
		}
	}

return err;
}

//===========================================================================================
static XErr	Char_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
Byte			theChar;

	if (getPropertyRec->propertyID == 1)
	{	if NOT(err = BAPI_ObjToChar(pbPtr->api_data, &getPropertyRec->objRef, (Ptr)&theChar, kExplicitTypeCast))
			err = BAPI_IntToObj(pbPtr->api_data, theChar, &getPropertyRec->resultObjRef);
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);

return err;
}

//===========================================================================================
static XErr	Char_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	if (setPropertyRec->propertyID == 1)
		err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
	else
		err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);

return err;
}

//===========================================================================================
static XErr	Char_SuperIsChanged(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
ObjRef		superObjRef, *objRefP = &pbPtr->param.superIsChangedRec.objRef;
Byte		theChar;
long		dataLen, api_data = pbPtr->api_data;

	if NOT(err = BAPI_GetSuperObj(api_data, objRefP, &superObjRef))	
	{	dataLen = 1;
		if NOT(err = BAPI_GetObj(api_data, &superObjRef, (Ptr)&theChar, &dataLen, 1, nil))
			err = BAPI_ModifyObj(api_data, objRefP, &theChar, 1);
	}
	
return err;
}

//===========================================================================================
/*static XErr	Char_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
CStr255			aCStr;
long			strLen;
Ptr				strP = nil;
PrimitiveRec		*typeCast = &pbPtr->param.primitiveRec;
TypeCastParam	*param_s = &typeCast->param1, *param_d = &typeCast->param2;
long			api_data = pbPtr->api_data;
long			ref = 0;
unsigned long	uLong;

	switch(param_s->which)
	{	case kInt:
		#ifdef NUM_STRING_TYPECAST_EXPLICIT	
			if (typeCast->type != kExplicitTypeCast)
				return XError(kBAPI_Error, Err_IllegalTypeCast);
		#endif
			CNumToString(param_s->u.intValue, aCStr);
			strP = aCStr;
			strLen = CLen(aCStr);
			break;
		case kLong:
		#ifdef NUM_STRING_TYPECAST_EXPLICIT	
			if (typeCast->type != kExplicitTypeCast)
				return XError(kBAPI_Error, Err_IllegalTypeCast);
		#endif
			CLongNumToString(param_s->u.longValue, aCStr);
			strP = aCStr;
			strLen = CLen(aCStr);
			break;
		case kUnsigned:
		#ifdef NUM_STRING_TYPECAST_EXPLICIT	
			if (typeCast->type != kExplicitTypeCast)
				return XError(kBAPI_Error, Err_IllegalTypeCast);
		#endif
			CNumToString(param_s->u.uIntValue, aCStr);
			strP = aCStr;
			strLen = CLen(aCStr);
			break;
		case kDouble:
		#ifdef NUM_STRING_TYPECAST_EXPLICIT	
			if (typeCast->type != kExplicitTypeCast)
				return XError(kBAPI_Error, Err_IllegalTypeCast);
		#endif
			CRealToStr(&param_s->u.doubleValue, aCStr, 2);
			strP = aCStr;
			strLen = CLen(aCStr);
			break;
		case kBool:
		#ifdef NUM_STRING_TYPECAST_EXPLICIT	
			if (typeCast->type != kExplicitTypeCast)
				return XError(kBAPI_Error, Err_IllegalTypeCast);
		#endif
			if (param_s->u.boolValue)
				CEquStr(aCStr, "true");
			else
				CEquStr(aCStr, "false");
			strP = aCStr;
			strLen = CLen(aCStr);
			break;
		case kCString:
			strP = param_s->u.text.stringP;
			strLen = param_s->u.text.stringLen;
			break;
		case kObj:
			if (param_s->u.objRef.classID == charClassID)
			{	strLen = 1;
				if NOT(err = BAPI_GetObj(api_data, &param_s->u.objRef, aCStr, &strLen, 0, nil))
					aCStr[strLen] = 0;
			}
			else
				err = BAPI_ObjToString(api_data, &param_s->u.objRef, aCStr, &strLen, 2, typeCast->type);
			strP = aCStr;
			if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
				err = XError(kBAPI_Error, Err_IllegalTypeCast);
			break;
	}
	if NOT(err)
	{	switch(param_d->which)
		{	case kInt:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				err = _CharToNum(aCStr, &param_d->u.intValue, nil, nil, nil);
				//if (CStringToNumExt(aCStr, &param_d->u.intValue, nil) == -1)
				//	err = XError(kBAPI_Error, Err_Overflow);
				break;
			case kLong:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				err = _CharToNum(aCStr, nil, &param_d->u.longValue, nil, nil);
				//if (CStringToLongNum(aCStr, strLen, &param_d->u.longValue) == -1)
				//	err = XError(kBAPI_Error, Err_Overflow);
				break;
			case kUnsigned:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				err = _CharToNum(aCStr, nil, nil, &param_d->u.uIntValue, nil);
				//if (CStringToNumExt(aCStr, nil, &param_d->u.uIntValue) == -1)
				//	err = XError(kBAPI_Error, Err_Overflow);
				break;
			case kDouble:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				err = _CharToNum(aCStr, nil, nil, nil, &param_d->u.doubleValue);
				//param_d->u.doubleValue = CStrToReal(aCStr);
				break;
			case kBool:
			#ifdef NUM_STRING_TYPECAST_EXPLICIT	
				if (typeCast->type != kExplicitTypeCast)
					return XError(kBAPI_Error, Err_IllegalTypeCast);
			#endif
				//if (CStringToNumExt(aCStr, nil, &uLong) == -1)
				//	err = XError(kBAPI_Error, Err_Overflow);
				if NOT(err = _CharToNum(aCStr, nil, nil, &uLong, nil))
					param_d->u.boolValue = (uLong != 0);
				break;
			case kCString:
				if (param_d->u.text.stringP)
				{	if (param_d->u.text.stringMaxStorage >= strLen)
					{	CopyBlock(param_d->u.text.stringP, strP, strLen);
						param_d->u.text.stringLen = strLen;
					}
					else
					{	CopyBlock(param_d->u.text.stringP, strP, param_d->u.text.stringMaxStorage);
						param_d->u.text.stringLen = param_d->u.text.stringMaxStorage;
						err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
					}
				}
				else
					param_d->u.text.stringLen = strLen + 1;
				break;
			case kObj:
				if (strLen == 1)
					err = BAPI_BufferToObj(api_data, strP, strLen, charClassID, false, nil, TEMP, VARIABLE, &param_d->u.objRef);
				else
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
				break;
			default:
				CDebugStr("Unknown TypeCast Parameter");
				break;
		}
	}


return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	char_Biferno_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			pbPtr->param.registerRec.pluginType = kNewClassPlugin;
			CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
			gsApiVersion = pbPtr->param.registerRec.api_version;
			charClassID = pbPtr->param.registerRec.pluginID;
			pbPtr->param.registerRec.wantDestructor = false;
			pbPtr->param.registerRec.fixedSize = true;
			CEquStr(pbPtr->param.registerRec.extendedClass, "string");
			CEquStr(pbPtr->param.registerRec.constructor, "void char(string str)");
			break;
		case kInit:
			{
			//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;

				gsIntClassID = BAPI_ClassIDFromName(pbPtr->api_data, "int", false);				
				gsStringClassID = BAPI_ClassIDFromName(pbPtr->api_data, "string", false);
				err = BAPI_NewProperties(pbPtr->api_data, charClassID, charProperty, 1, nil);
			}
			break;
		case kShutDown:
			charClassID = 0;
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = Char_Constructor(pbPtr, message);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
		case kExecuteMethod:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Char_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Char_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
		case kSuperIsChanged:
			err = Char_SuperIsChanged(pbPtr);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


