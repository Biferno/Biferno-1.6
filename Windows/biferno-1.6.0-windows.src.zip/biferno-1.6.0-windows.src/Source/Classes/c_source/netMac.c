/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: netMac.c,v 1.2 2003-06-23 12:39:45 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include "def.h"
#include "net.h"

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

/*	Constants. */

#define kBufSize 			(4*1024)			/* buffer size */
#define kBufSizeDiv2		(kBufSize/2)		/* buffer size div 2 */
#define kMinTCPBufSize		(16*1024)			/* minimum MacTCP stream buffer size */

#if __MAC_XLIB__ && !TARGET_API_MAC_CARBON
	#include "OpenTransport.h"
	#include "OpenTptInternet.h"
#endif

extern Boolean gHaveOT;					/* true if we have Open Transport */
extern NetGiveTimeFunction gGiveTime;	/* pointer to GiveTime function */
extern NetLogFunction gLog;				/* pointer to logging function, or nil if none */

extern BlockRef gAll;				/* pointer to list of open streams */
extern BlockRef gClose;				/* pointer to list of closing streams */
extern BlockRef gFree;				/* pointer to list of available preallocated stream buffers */

#if TARGET_API_MAC_CARBON
	extern OTClientContextPtr	gOutClientContext;
#endif

/*----------------------------------------------------------------------------
	NetGetMyAddr 
	
	Get this Mac's IP address.
	
	Exit:	function result = error code.
			*addr = the IP address of this Mac.
			
	With Open Transport, if the Mac has more than one IP interface, the
	IP address of the default interface is returned.
----------------------------------------------------------------------------*/

static XErr _NetGetMyAddr (unsigned long *addr)
{
//struct GetAddrParamBlock pBlock;
XErr 				err = noErr;	//, giveTimeErr = noErr;
unsigned long 		myAddr;
InetInterfaceInfo 	ifaceInfo;
TMyOTInetSvcInfo 	svcInfo;

	if (gHaveOT) {
	
		err = OTInetGetInterfaceInfo(&ifaceInfo, kDefaultInetInterface);
		if (err == kOTNotFoundErr) {
			/* If OT is not loaded, the OTInetGetInterfaceInfo call fails with
			   error kOTNotFoundErr. In this case, we open an inet services
			   endpoint temporarily just to force OT to load, and we try
			   the call again. */
			err = MyOTOpenInetServices(&svcInfo);
			if (err != noErr) return TranslateErrorCode(err);
			err = OTInetGetInterfaceInfo(&ifaceInfo, kDefaultInetInterface);
			OTCloseProvider(svcInfo.ref);
		}
		if (err != noErr) return TranslateErrorCode(err);
		myAddr = ifaceInfo.fAddress;
	
	} else {
	
		/*memset(&pBlock, 0, sizeof(pBlock));
		pBlock.ioResult = 1;
		pBlock.csCode = ipctlGetAddr;
		pBlock.ioCRefNum = gRefNum;
		PBControlAsync((ParmBlkPtr)&pBlock);
		while (pBlock.ioResult > 0) {
			giveTimeErr = (*gGiveTime)();
			if (err == noErr) err = giveTimeErr;
		}
		if (err != noErr) return TranslateErrorCode(err);
		err = pBlock.ioResult;
		if (err != noErr) return TranslateErrorCode(err);
		myAddr = pBlock.ourAddress;
		*/
	}
	
	*addr = myAddr;
	return noErr;
}

#pragma mark-
/*----------------------------------------------------------------------------
	MyOTStreamNotifyProc 
	
	Open Transport notifier proc for TCP streams.
	
	Entry:	s = pointer to stream.
			code = OT event code.
			result = OT result.
			cookie = OT cookie.
----------------------------------------------------------------------------*/

static pascal void MyOTStreamNotifyProc (TStreamPtr s, OTEventCode code, OTResult result, void *cookie)
{
	switch (code) {
		case T_DISCONNECT:
			/* Other side has aborted. */
			s->otherSideHasClosed = true;
			s->complete = true;
			break;
		case T_ORDREL:
			/* Other side has closed. Close our side if necessary. */
			s->otherSideHasClosed = true;
			s->complete = true;
			OTRcvOrderlyDisconnect(s->ref);
			if (!s->weHaveClosed) {
				OTSndOrderlyDisconnect(s->ref);
				s->weHaveClosed = true;
			}
			if (s->closing) s->release = true;
			break;
		case T_DATA:
			if (s->closing) {
				/* Consume and discard response to "QUIT" comand. */
				do {
					result = OTRcv(s->ref, s->buf, kBufSize, nil);
				} while (result >= 0);
			}
			break;
		case T_OPENCOMPLETE:
		case T_BINDCOMPLETE:
		case T_CONNECT:
		case T_PASSCON:
			s->complete = true;
			s->code = code;
			s->result = result;
			s->cookie = cookie;
			break;
	}
}



/*----------------------------------------------------------------------------
	MyOTStreamWait 
	
	Wait for an asynchronous Open Transport stream call to complete.
	
	Entry:	s = pointer to stream.
			returnImmediatelyOnError = true to return immediately if
				the GiveTime function returns an error.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr MyOTStreamWait (TStreamPtr s, Boolean returnImmediatelyOnError)
{
XErr err = noErr, giveTimeErr = noErr;

	do {
		giveTimeErr = (*gGiveTime)();
		if (err == noErr)
			err = giveTimeErr;
		if ((err != noErr) && returnImmediatelyOnError)
			return err;
	} while (!s->complete);
	if (err == noErr)
		err = s->result;

return err;
}



/*----------------------------------------------------------------------------
	MyOTInetSvcNotifyProc 
	
	Open Transport notifier proc for an Internet services provider.
	
	Entry:	svcIfno = pointer to MyOTInetSvcInfo struct.
			code = OT event code.
			result = OT result.
			cookie = OT cookie.
----------------------------------------------------------------------------*/

static pascal void MyOTInetSvcNotifyProc (TMyOTInetSvcInfo *svcInfo, OTEventCode code,
	OTResult result, void *cookie)
{
	switch (code) {
		case T_OPENCOMPLETE:
		case T_DNRSTRINGTOADDRCOMPLETE:
		case T_DNRADDRTONAMECOMPLETE:
			svcInfo->complete = true;
			svcInfo->result = result; 
			svcInfo->cookie = cookie;
			break;
	}
}



/*----------------------------------------------------------------------------
	MyOTInetSvcWait 
	
	Wait for an asynchronous Open Transport Internet services call to complete.
	
	Entry:	svcInfo = pointer to TMyOTInetSvcInfo struct.
			returnImmediatelyOnError = true to return immediately if
				the GiveTime function returns an error.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr MyOTInetSvcWait (TMyOTInetSvcInfo *svcInfo, Boolean returnImmediatelyOnError)
{
	XErr err = noErr;
	XErr giveTimeErr = noErr;

	do {
		giveTimeErr = (*gGiveTime)();
		if (err == noErr) err = giveTimeErr;
		if (err != noErr && returnImmediatelyOnError) return err;
	} while (!svcInfo->complete);
	if (err == noErr) err = svcInfo->result;
	return err;
}



/*----------------------------------------------------------------------------
	MyOTOpenInetServices 
	
	Open an Internet services provider.
	
	Entry:	svcInfo = pointer to TMyOTInetSvcInfo struct for this
				provider.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr MyOTOpenInetServices (TMyOTInetSvcInfo *svcInfo)
{
	XErr err = noErr;

	svcInfo->complete = false;
#if TARGET_API_MAC_CARBON
	{
	OTNotifyUPP	upp;
	
		if (upp = NewOTNotifyUPP((OTNotifyProcPtr)MyOTInetSvcNotifyProc))
		{	err = OTAsyncOpenInternetServicesInContext (kDefaultInternetServicesPath, 0, upp, svcInfo, gOutClientContext);
			DisposeOTNotifyUPP(upp);
		}
		else
			err = XError(kXLibError, ErrXMemory_Full);
	}
#else
	err = OTAsyncOpenInternetServices(kDefaultInternetServicesPath, 0, (OTNotifyProcPtr)MyOTInetSvcNotifyProc, svcInfo);
#endif
	if (err != noErr) return err;
	err = MyOTInetSvcWait(svcInfo, false);
	if (err != noErr) return err;
	svcInfo->ref = svcInfo->cookie;
	return noErr;
}



#pragma mark-
/*----------------------------------------------------------------------------
	DoTCPCreate 
	
	Create a stream.
	
	Entry:	s = pointer to stream.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr DoTCPCreate(BlockRef sBlock)
{
	XErr err = noErr;
	OSStatus oterr;
	TStreamPtr s = (TStreamPtr)GetPtr(sBlock);
	
	if (gHaveOT) {
	
		s->complete = false;
	#if TARGET_API_MAC_CARBON
		{
		OTNotifyUPP	upp;
		
			if (upp = NewOTNotifyUPP((OTNotifyProcPtr)MyOTStreamNotifyProc))
			{	err = OTAsyncOpenEndpointInContext (OTCreateConfiguration(kTCPName), 0, nil, upp, s, gOutClientContext);
				DisposeOTNotifyUPP(upp);
			}
			else
				err = XError(kXLibError, ErrXMemory_Full);
		}
	#else
		err = OTAsyncOpenEndpoint(OTCreateConfiguration(kTCPName), 0, nil, (OTNotifyProcPtr)MyOTStreamNotifyProc, s);
	#endif
		if (err != noErr) return err;
		err = MyOTStreamWait(s, false);
		if (err != noErr) return err;
		if (s->code != T_OPENCOMPLETE)
			return netOpenStreamErr;
		s->ref = s->cookie;
	#if TARGET_API_MAC_CARBON
		s->call = OTAllocInContext(s->ref, T_CALL, T_ADDR, &oterr, gOutClientContext);
		err = oterr;
		if (err != noErr) goto exit; 
		s->bindReq = OTAllocInContext(s->ref, T_BIND, T_ADDR, &oterr, gOutClientContext);
		err = oterr;
		if (err != noErr) goto exit;
		s->bindRet = OTAllocInContext(s->ref, T_BIND, T_ADDR, &oterr, gOutClientContext);
	#else
		s->call = OTAlloc(s->ref, T_CALL, T_ADDR, &oterr);
		err = oterr;
		if (err != noErr) goto exit; 
		s->bindReq = OTAlloc(s->ref, T_BIND, T_ADDR, &oterr);
		err = oterr;
		if (err != noErr) goto exit;
		s->bindRet = OTAlloc(s->ref, T_BIND, T_ADDR, &oterr);
	#endif
		err = oterr;
		if (err != noErr) goto exit;
	
	} else {
	
		/*InitMacTCPParamBlock(&s->pBlock, TCPCreate);
		s->pBlock.csParam.create.rcvBuff = s->mactcpBuf;
		s->pBlock.csParam.create.rcvBuffLen = gTCPBufSize;
		err = CallMacTCP(s, false);
		if (err != noErr) return err;
		s->tcpStream = s->pBlock.tcpStream;
		*/
	}
	
	XThreadsEnterCriticalSection();
	s->next = gAll;
	gAll = sBlock;
	XThreadsLeaveCriticalSection();
	return noErr;
	
exit:

	OTCloseProvider(s->ref);
	return err;
}



/*----------------------------------------------------------------------------
	DoTCPRelease 
	
	Release a stream.
	
	Entry:	s = pointer to stream.
	
	Exit:	function result = error code.
	
	Any active connection is also aborted, if necessary, before releasing 
	the stream.
	
	With MacTCP, the function uses its own TCPiopb parameter block instead 
	of the one inside the stream block, because the one inside the stream block
	may already be in use by some other asynchronous operation.
----------------------------------------------------------------------------*/

XErr DoTCPRelease (BlockRef sBlock, long userData)
{
	//TCPiopb pBlock;
	XErr err = noErr;
	BlockRef xs, next, prev = nil;
	Boolean abort;
	TStreamPtr s;
	
	if (sBlock == nil) return noErr;
	s = (TStreamPtr)GetPtr(sBlock);
	
	abort = !s->otherSideHasClosed || !s->weHaveClosed;
	
	if (gHaveOT) {
	
		if (abort) OTSndDisconnect(s->ref, nil);
		err = OTCloseProvider(s->ref);
	
	} else {
	
		/*InitMacTCPParamBlock(&pBlock, TCPRelease);
		pBlock.tcpStream = s->tcpStream;
		err = PBControlSync((ParmBlkPtr)&pBlock);*/
	}
	
	XThreadsEnterCriticalSection();
	for (xs = gAll; xs != nil; xs = next)
	{
		next = ((TStreamPtr)GetPtr(xs))->next;
		if (xs == sBlock) {
			if (prev == nil) {
				gAll = next;
			} else {
				((TStreamPtr)GetPtr(prev))->next = next;
			}
			break;
		}
		prev = xs;
	}
	XThreadsLeaveCriticalSection();
	
	if (gLog != nil) LogMessage(s, ' ', abort ? "Stream aborted." : "Stream released.", userData);
	return err;
}



/*----------------------------------------------------------------------------
	DoTCPActiveOpen 
	
	Open an active stream.
	
	Entry:	s = pointer to stream.
			addr = IP address of server.
			port = port number of service.
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr DoTCPActiveOpen (TStreamPtr s, NetAddress *addr, unsigned short port, long userData)
{
XErr 			err = noErr;
InetAddress 	*inetAddr;
	
	if (gHaveOT) {
	
		s->complete = false;
		err = OTBind(s->ref, nil, s->bindRet);
		if (err != noErr) return err;
		err = MyOTStreamWait(s, true);
		if (err != noErr) return err;
		if (s->code != T_BINDCOMPLETE)
			return netOpenStreamErr;
		inetAddr = (InetAddress*)s->bindRet->addr.buf;
		s->localPort = inetAddr->fPort;
		OTInitInetAddress((InetAddress*)s->call->addr.buf, port, *addr);
		s->call->addr.len = sizeof(InetAddress);
		s->complete = false;
		err = OTConnect(s->ref, s->call, nil);
		if (err != noErr && err != kOTNoDataErr) 
		{	if (s->otherSideHasClosed)
				return netOpenStreamErr;
			else
				return err;
		}
		err = MyOTStreamWait(s, true);
		if (err != noErr)
		{	if (s->otherSideHasClosed)
				return netOpenStreamErr;
			else
				return err;
		}
		if (s->code != T_CONNECT)
			return netOpenStreamErr;
		err = OTRcvConnect(s->ref, nil);
		if (err != noErr) return err;

	} else {
	
		/*InitMacTCPParamBlock(&s->pBlock, TCPActiveOpen);
		s->pBlock.tcpStream = s->tcpStream;
		s->pBlock.csParam.open.remoteHost = addr;
		s->pBlock.csParam.open.remotePort = port;
		err = CallMacTCP(s, true);
		if (err == noErr) {
			s->localPort = s->pBlock.csParam.open.localPort;
		} else {
			return s->otherSideHasClosed ? netOpenStreamErr : err;
		}*/
	}
	
	if (gLog != nil) LogMessage(s, ' ', "Stream opened.", userData);
	return noErr;
}



/*----------------------------------------------------------------------------
	DoTCPPassiveOpen 
	
	Open a passive stream.
	
	Entry:	s = pointer to stream.
	
	Exit:	function result = error code.
			*port = assigned unused local port number.
			
	Note: Unlike the other "DoTCPxxx" functions, DoTCPPassiveOpen is
	asynchronous. The passive stream is opened, but the function does not
	wait for another host to connect. The function is used by 
	NetFTPDataPassiveOpen to open passive FTP data streams. The caller must 
	call NetFTPDataWaitForConnection to wait for the FTP server to connect
	to the stream.
----------------------------------------------------------------------------*/

XErr DoTCPPassiveOpen (TStreamPtr s, unsigned short *port)
{
	XErr err = noErr;
	InetAddress *inetAddr;
	
	if (gHaveOT) {
	
		s->bindReq->addr.len = 0;
		s->bindReq->qlen = 1;
		s->complete = false;
		err = OTBind(s->ref, s->bindReq, s->bindRet);
		if (err != noErr) return err;
		err = MyOTStreamWait(s, true);
		if (err != noErr) return err;
		if (s->code != T_BINDCOMPLETE)
			return netOpenStreamErr;
		inetAddr = (InetAddress*)s->bindRet->addr.buf;
		*port = s->localPort = inetAddr->fPort;
	
	} else {
	
		/*InitMacTCPParamBlock(&s->pBlock, TCPPassiveOpen);
		s->pBlock.tcpStream = s->tcpStream;
		PBControlAsync((ParmBlkPtr)&s->pBlock);
		while (s->pBlock.csParam.open.localPort == 0) {
			err = (*gGiveTime)();
			if (err != noErr) return err;
		}
		*port = s->localPort = s->pBlock.csParam.open.localPort;
		*/
		
	}
	
	s->passiveOpenInProgress = true;
	return noErr;
}



/*----------------------------------------------------------------------------
	DoTCPSend 
	
	Send data on a stream.
	
	Entry:	s = pointer to stream.
			data = pointer to data to send.
			len = length of data to send.
			push = true to set push data flag. This flag should be set on
				the last buffer of data being sent on the stream before
				a response from the server is expected. This flag is needed
				to keep IBM VM/CMS happy. (Note OT handles this internally,
				so this is needed only with MacTCP.)
	
	Exit:	function result = error code.
----------------------------------------------------------------------------*/

XErr DoTCPSend (TStreamPtr s, Ptr data, unsigned short len/*, Boolean push*/)
{
	XErr err = noErr;
	OTResult result;

	s->in = s->out = s->buf;
	
	if (gHaveOT) {
	
		while (len > 0) {
			err = (*gGiveTime)();
			if (err != noErr) return err;
			result = OTSnd(s->ref, data, len, 0);
			if (result >= 0) {
				len -= result;
				s->bytesOut += result;
				data += result;
			} else if (result != kOTFlowErr) {
				return s->otherSideHasClosed ? netLostConnectionErr : result;
			}
		}
		return noErr;
	
	} else {
	
		/*s->wds[0].ptr = data;
		s->wds[0].length = len;
		InitMacTCPParamBlock(&s->pBlock, TCPSend);
		s->pBlock.tcpStream = s->tcpStream;
		s->pBlock.csParam.send.wdsPtr = (Ptr)s->wds;
		s->pBlock.csParam.send.pushFlag = push;
		err = CallMacTCP(s, true);
		if (err == noErr) s->bytesOut += len;
		return s->otherSideHasClosed ? netLostConnectionErr : err;
	*/
	}

return err;
}



/*----------------------------------------------------------------------------
	DoTCPRcv 
	
	Reveive data on a stream.
	
	Entry:	s = pointer to stream.
			data = pointer to data buffer.
			*len = length of data buffer.
	
	Exit:	function result = error code.
			*len = number of bytes received.
----------------------------------------------------------------------------*/

XErr DoTCPRcv (TStreamPtr s, Ptr data, unsigned short *len)
{
	XErr err = noErr;
	OTResult result;
	
	if (gHaveOT) {
	
		err = (*gGiveTime)();
		if (err != noErr) return err;
		result = OTRcv(s->ref, data, *len, nil);
		if (result >= 0) {
			*len = result;
			s->bytesIn += result;
			return noErr;
		} else if (s->otherSideHasClosed) {
			return netLostConnectionErr;
		} else if (result == kOTNoDataErr) {
			*len = 0;
			return noErr;
		} else {
			return result;
		}
	
	} else {
	
		/*InitMacTCPParamBlock(&s->pBlock, TCPRcv);
		s->pBlock.tcpStream = s->tcpStream;
		s->pBlock.csParam.receive.rcvBuff = StripAddress(data);
		s->pBlock.csParam.receive.rcvBuffLen = *len;
		err = CallMacTCP(s, true);
		*len = s->pBlock.csParam.receive.rcvBuffLen;
		if (err == noErr) s->bytesIn += *len;
		return err != noErr && s->otherSideHasClosed ? netLostConnectionErr : err;
		*/
	}

return err;
}
#pragma mark-
/*----------------------------------------------------------------------------
	NetNameToAddr 
	
	Translate a domain name to an IP address.
	
	Entry: 	name = C-format domain name string, optionally followed by a
				comma, space, or colon and then the port number.
			defaultPort = default port number.
	
	Exit:	function result = error code.
			*addr = IP address.
			*port = port number.
----------------------------------------------------------------------------*/

XErr NetNameToAddr (char *name, unsigned short defaultPort, NetAddress *addr, unsigned short *port)
{
	XErr err = noErr;	//, giveTimeErr = noErr;
	short i;
	static struct {
		CStr255 domainName;
		unsigned long addr;
	} cache[10];
	static short numCache = 0;
	//struct hostInfo hInfoMacTCP;
	InetHostInfo hInfoOT;
	//Boolean done = false;
	CStr255 domainName;
	char *p, *q;
	TMyOTInetSvcInfo svcInfo;
	
	p = name;
	q = domainName;
	while (*p != 0 && *p != ',' && *p != ' ' && *p != ':') *q++ = *p++;
	*q = 0;
	q = p;
	while (*q == ' ') q++;
	if (*q == 0) {
		*port = defaultPort;
	} else {
		p++;
		if (!isdigit(*p)) return netDNRErr;
		q = p+1;
		while (isdigit(*q)) q++;
		while (*q == ' ') q++;
		if (*q != 0) return netDNRErr;
		*port = atoi(p);
	}
	
	for (i=0; i<numCache; i++) {
		if (strcmp(domainName, cache[i].domainName) == 0) {
			*addr = cache[i].addr;
			return noErr;
		}
	}
	
	if (gHaveOT) {
	
		err = OTInetStringToHost(domainName, addr);
		if (err != noErr) {
			err = MyOTOpenInetServices(&svcInfo);
			if (err == kEINVALErr || err == -3198) return netDNRErr;
			if (err != noErr) return TranslateErrorCode(err);
			svcInfo.complete = false;
			err = OTInetStringToAddress(svcInfo.ref, domainName, &hInfoOT);
			if (err == noErr) err = MyOTInetSvcWait(&svcInfo, true);
			OTCloseProvider(svcInfo.ref);
			if (err != noErr) {
				if (err == kOTNoDataErr || err == kOTBadNameErr) err = netDNRErr;
				return TranslateErrorCode(err);
			}
			*addr = hInfoOT.addrs[0];
		}
	
	} else {
	/*
		while (gMacTCPDNROperationInProgress) {
			// Some other thread is using the DNR. Wait for it to finish. 
			err = (*gGiveTime)();
			if (err != noErr) return err;
		}
		err = OpenResolver(nil);
		if (err != noErr) return TranslateErrorCode(err);
		memset(&hInfoMacTCP, 0, sizeof(hInfoMacTCP));
		gMacTCPDNROperationInProgress = true;
		
		err = StrToAddr(domainName, &hInfoMacTCP, gMacTCPDNRResultProcUPP, (char*)&done);
		if (err == cacheFault) {
			err = noErr;
			while (!done) {
				giveTimeErr = (*gGiveTime)();
				if (err == noErr) err = giveTimeErr;
			}
			if (err == noErr) err = hInfoMacTCP.rtnCode;
		}
		
		gMacTCPDNROperationInProgress = false;
		(*gGiveTime)();
		CloseResolver();
		if (err != noErr) return TranslateErrorCode(err);
		*addr = hInfoMacTCP.addr[0];
	*/	
	}
	
	if (numCache < 10) {
		strcpy(cache[numCache].domainName, domainName);
		cache[numCache].addr = *addr;
		numCache++;
	}
	return noErr;
}

/*----------------------------------------------------------------------------
	NetGetMyAddrStr 
	
	Get this Mac's IP address as a dotted-decimal string

	Exit:	function result = error code.
			addrStr = this Mac's IP address, as a C-format string.
				You must allocate at least 16 bytes for this string.
				The returned string has max length 15.
----------------------------------------------------------------------------*/

XErr NetGetMyAddrStr (char *addrStr)
{
	unsigned long addr;
	XErr err = noErr;
	
	err = _NetGetMyAddr(&addr);
	if (err != noErr) return TranslateErrorCode(err);
	sprintf(addrStr, "%ld.%ld.%ld.%ld",
		(addr >> 24) & 0xff,
		(addr >> 16) & 0xff,
		(addr >> 8) & 0xff,
		addr & 0xff);
	return noErr;
}

/*----------------------------------------------------------------------------
	NetGetMyName 
	
	Get this Mac's domain name, if any.
	
	Exit:	function result = error code.
			name = domain name of this Mac, as a C-format string.
----------------------------------------------------------------------------*/

XErr NetGetMyName (CStr255 name)
{
	NetAddress	addr;
	short 		len;
	XErr 		err = noErr;

	err = _NetGetMyAddr(&addr);
	if (err != noErr) return TranslateErrorCode(err);
	err = NetAddrToName(&addr, name);
	if (err != noErr) return TranslateErrorCode(err);
	len = strlen(name);
	if (name[len-1] == '.') name[len-1] = 0;
	return noErr;
}


/*----------------------------------------------------------------------------
	NetAddrToName 
	
	Translate an IP address to a domain name.
	
	Entry:	addr = IP address.
	
	Exit:	function result = error code.
			name = domain name, as a C-format string.
----------------------------------------------------------------------------*/

XErr NetAddrToName (NetAddress *addr, CStr255 name)
{
	//struct hostInfo hInfoMacTCP;
	XErr err = noErr;	//, giveTimeErr = noErr;
	//Boolean done=false;
	TMyOTInetSvcInfo svcInfo;
	
	if (gHaveOT) {
	
		err = MyOTOpenInetServices(&svcInfo);
		if (err != noErr) return TranslateErrorCode(err);
		svcInfo.complete = false;
		err = OTInetAddressToName(svcInfo.ref, *addr, name);
		if (err == noErr) err = MyOTInetSvcWait(&svcInfo, true);
		OTCloseProvider(svcInfo.ref);
		if (err != noErr) {
			if (err == kOTNoDataErr || err == kOTBadNameErr) err = netDNRErr;
			return TranslateErrorCode(err);
		}
		return noErr;	
	
	} else {
	
		/*while (gMacTCPDNROperationInProgress) {
			// Some other thread is using the DNR. Wait for it to finish. 
			err = (*gGiveTime)();
			if (err != noErr) return err;
		}
		
		err = OpenResolver(nil);
		if (err != noErr) return TranslateErrorCode(err);
		memset(&hInfoMacTCP, 0, sizeof(hInfoMacTCP));
		
		gMacTCPDNROperationInProgress = true;
		err = AddrToName(addr, &hInfoMacTCP, gMacTCPDNRResultProcUPP, (char*)&done);
		if (err == cacheFault) {
			err = noErr;
			while (!done) {
				giveTimeErr = (*gGiveTime)();
				if (err == noErr) err = giveTimeErr;
			}
			if (err == noErr) err = hInfoMacTCP.rtnCode;
		}
		gMacTCPDNROperationInProgress = false;
		(*gGiveTime)();
		CloseResolver();
		if (err != noErr) return TranslateErrorCode(err);
		hInfoMacTCP.cname[254] = 0;
		strcpy(name, hInfoMacTCP.cname);
		return noErr;
		*/
	}

return err;
}

/*----------------------------------------------------------------------------
	NetHaveOT 
	
	Determine whether we have Open Transport.
	
	Exit:	function result = true if Open Transport and Open Transport/TCP
				are both installed.
----------------------------------------------------------------------------*/

Boolean NetHaveOT (void)
{
	static Boolean gotIt = false;
	static Boolean haveOT;
	XErr err = noErr;
	long result;
	
	if (!gotIt)
	{
		err = Gestalt(gestaltOpenTpt, &result);
		haveOT = err == noErr && 
			(result & gestaltOpenTptPresentMask) != 0 &&
			(result & gestaltOpenTptTCPPresentMask) != 0;
		gotIt = true;
	}
	return haveOT;
}





