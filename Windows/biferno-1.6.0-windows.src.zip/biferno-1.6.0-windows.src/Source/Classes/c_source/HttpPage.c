/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: HttpPage.c,v 1.23 2006-10-09 10:41:14 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"
#include	"XLibPrivate.h"

#include 	"HTTPMgr.h"

#include 	"BifernoAPI.h"
#include	"BifernoEngineAPI.h"	// HttpPage is a special class, no class include this
#include 	"StaticClasses.h"

#include 	"BfrHeader.h"

#include 	"HttpPage.h"

#include 	<string.h>

typedef struct
{
	HeaderObjectRec		head;	// oggetto di tipo header
	long				body;	// buffer ID (vedi Buffer.c)
} PageRec;

// defines
#define	gsPlugName	"httpPage"

static 	long	pageClassID;
static 	long	gsApiVersion, gsHeaderClassID, gsRequestClassID;

// Methods
enum{
		kExecMethod = 1
	};
#define TOT_METHODES	1

#define TOT_PROPRIETIES	2
// Properties
enum{
		kHeader = 1,
		kBody
	};

#define		MAX_BODY_STRING		512L

// Errors
#define	HTTPPAGE_START_ERR	10000
enum {
		ErrServerRespondedNoData = HTTPPAGE_START_ERR,
		ErrResponseHeaderIsInvalid
		//ErrCantConnectToServer
};
#define	TOT_ERRORS	2

CStr63	gHttpPageErrorsStr[] = 
	{	
		"ErrServerRespondedNoData",
		"ErrResponseHeaderIsInvalid"
		//"ErrCantConnectToServer"
		};

#define	MAX_REFERER_LENGTH	2048

static PackHeader_Prot					_PackHeader;
static TokenizeHeader_Prot				_TokenizeHeader;
static InitializeHeaderOut_Prot			_InitializeHeaderOut;
static ObjRefFromHeaderObjectRec_Prot	_ObjRefFromHeaderObjectRec;
static DisposeHeaderObject_Prot			_DisposeHeaderObject;
static CloneHeaderObjectRec_Prot		_CloneHeaderObjectRec;
static GetCookie_Prot					_GetCookie;
static SetCookie_Prot					_SetCookie;
static GetHeaderField_Prot				_GetHeaderField;

static	XErr	(*_Redirect)(long api_data, char *url, long urlLen, Boolean use307, Boolean useMetaEquiv);

#ifdef __LITTLE_ENDIAN__
	#define	CRLFCRLF			0x0a0d0a0d	//'\n\r\n\r'
	#define	CRLF				'\n\r'
#else
	#define	CRLFCRLF			'\r\n\r\n'
	#define	CRLF				'\r\n'
#endif

//#define	CONTENT_LENGTH_PRE_STR		"global pageOut.head.SetField(\"Content-length\", \""

//static long	gHeadBL = 0;
//===========================================================================================
static XErr	HttpPage_Print(long api_data, ObjRef *pageOutObjRefP, char *stringP, long stringLen)
{
XErr	err = noErr;
long	tLen;
PageRec	pageOutRec;

	tLen = sizeof(PageRec);
	err = BAPI_ReadObj(api_data, pageOutObjRefP, (Ptr)&pageOutRec, &tLen, 0, nil);
	if NOT(err)
	{	
		err = BufferAddBuffer(pageOutRec.body, stringP, stringLen);
	}
	
return err;
}

//===========================================================================================
/*static XErr	HttpPage_DisposeOutput(long api_data, ObjRef *pageOutObjRef)
{
XErr		err = noErr;
long		tLen, plugin_run_data;
PageRec		pageOutRec;

	tLen = sizeof(PageRec);
	if NOT(err = BAPI_ReadObj(api_data, pageOutObjRef, (Ptr)&pageOutRec, &tLen, 0, nil))
	{	_DisposeHeaderObject(&pageOutRec.head);
		BufferFree(pageOutRec.body);
		if NOT(err = BAPI_GetPluginRunData(api_data, pageClassID, &plugin_run_data))
		{	plugin_run_data--;
			if NOT(err = BAPI_SetPluginRunData(api_data, pageClassID, plugin_run_data))
			{	ClearBlock(&pageOutRec, tLen);
				err = BAPI_ModifyObj(api_data, pageOutObjRef, (Ptr)&pageOutRec, tLen);
			}
		}
	}	
	
return 0;
}
*/
//===========================================================================================
static XErr	HttpPage_GetOutput(long api_data, ObjRef *pageOutObjRef, Boolean prefixLength, Boolean onlyHead, BlockRef *pageOutBlockRef, long *lenP)
{
XErr		err = noErr;
long		prelen, tot, plugin_run_data, headLen, tLen, bodyLen;
PageRec		pageOutRec;
BlockRef	headBlock, bodyBlock;
Ptr			bodyP, headP;

	tLen = sizeof(PageRec);
	if NOT(err = BAPI_ReadObj(api_data, pageOutObjRef, (Ptr)&pageOutRec, &tLen, 0, nil))
	{	if NOT(err = _PackHeader(&pageOutRec.head, &headBlock, &headLen))
		{	bodyBlock = BufferGetBlockRef(pageOutRec.body, &bodyLen);
			if (prefixLength)
				prelen = sizeof(long);
			else
				prelen = 0;
			if (onlyHead)
				bodyLen = 0;
			if (tot = headLen + bodyLen)
				err = SetBlockSize(bodyBlock, prelen + tot);
			if NOT(err)
			{	bodyP = GetPtr(bodyBlock);
				headP = GetPtr(headBlock);
				CopyBlock(bodyP + prelen + headLen, bodyP, bodyLen);
				CopyBlock(bodyP + prelen, headP, headLen);
				if (prelen)
					*(long*)bodyP = XHostToNetwork(tot);
				*pageOutBlockRef = bodyBlock;
				*lenP = prelen + tot;
				_DisposeHeaderObject(&pageOutRec.head);
				BufferClose(pageOutRec.body);		// note that is not free, but only closed
				if NOT(err = BAPI_GetPluginRunData(api_data, pageClassID, &plugin_run_data))
				{	plugin_run_data--;
					err = BAPI_SetPluginRunData(api_data, pageClassID, plugin_run_data);
				}
			}
			DisposeBlock(&headBlock);
		}
	}	
	
return 0;
}

//===========================================================================================
/*XErr	HttpPage_DebugCheckPage(long api_data, char *name)
{
XErr			err = noErr;
PageRec			pageRec;
long			objLen;
ObjRef 			objRef;
Boolean			isDef;

	if NOT(err = BAPI_IsVariableDefined(api_data, name, GLOBAL, &isDef, &objRef))
	{	if (isDef)
		{	objLen = sizeof(PageRec);
			if NOT(err = BAPI_GetObj(api_data, &objRef, (Ptr)&pageRec, &objLen, 0, nil))
			{	if (pageRec.head.list)
					DLM_CheckList(pageRec.head.list);
			}
		}
	}
	
return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

#define	HEADER_CONSTR		"header"
#define	HEADER_CONSTR_LEN	6

//===========================================================================================
static XErr	_PrimitiveString(PrimitiveUnion	*param_d, Ptr strP, long strLen)
{
Ptr		p;
XErr	err = noErr;

	p = param_d->text.stringP;
	if (p)
	{	if (param_d->text.stringMaxStorage >= (strLen+1))
		{	CopyBlock(p, strP, strLen);
			p[strLen] = 0;
			param_d->text.stringLen = strLen;
		}
		else
		{	CopyBlock(p, strP, param_d->text.stringMaxStorage - 1);
			p[param_d->text.stringMaxStorage - 1] = 0;
			param_d->text.stringLen = strLen;
			err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
		}
	}
	else
		param_d->text.stringLen = strLen;
		
return err;
}

//===========================================================================================
static XErr	_GetHTTPText(PageRec *pageRecP, Ptr headP, long headBlockLen, Ptr dest_textP, long *lenP, long maxStorage, Boolean forConstr)
{
BlockRef	bodyBlock;
long		totLen, bodyLength;
XErr		err = noErr;
long		addPeriods = 0;

	bodyBlock = BufferGetBlockRef(pageRecP->body, &bodyLength);
	if (bodyLength > MAX_BODY_STRING)
	{	bodyLength = MAX_BODY_STRING;
		addPeriods = 3;
	}
	if (forConstr)
		totLen = HEADER_CONSTR_LEN + 1 + headBlockLen + 3 + bodyLength + 1;	// header(h),"body"
	else
		totLen = headBlockLen + bodyLength;
	if (addPeriods)
		totLen += 3;
	if (dest_textP)
	{	
	Ptr			textP;
	BlockRef	tempBlock;
	
		if (tempBlock = NewBlockLocked(totLen + 1, &err, &textP))
		{	if (forConstr)
			{	CopyBlock(textP, HEADER_CONSTR, HEADER_CONSTR_LEN);
				CopyBlock(textP + HEADER_CONSTR_LEN, "(", 1);
				CopyBlock(textP + HEADER_CONSTR_LEN + 1, headP, headBlockLen);
				CopyBlock(textP + HEADER_CONSTR_LEN + 1 + headBlockLen, "),\"", 3);
				CopyBlock(textP + HEADER_CONSTR_LEN + 1 + headBlockLen + 3, GetPtr(bodyBlock), bodyLength);
				if (addPeriods)
					CopyBlock(textP + HEADER_CONSTR_LEN + 1 + headBlockLen + 3 + bodyLength, "...", 3);
				CopyBlock(textP + HEADER_CONSTR_LEN + 1 + headBlockLen + 3 + bodyLength + addPeriods, "\"", 1);
			}
			else
			{	CopyBlock(textP, headP, headBlockLen);
				CopyBlock(textP + headBlockLen, GetPtr(bodyBlock), bodyLength);
				if (addPeriods)
					CopyBlock(textP + headBlockLen + bodyLength, "...", 3);
			}
			textP[totLen] = 0;
			if (maxStorage >= (totLen + 1))
			{	CopyBlock(dest_textP, textP, totLen);
				dest_textP[totLen] = 0;
			}
			else
			{	CopyBlock(dest_textP, textP, maxStorage - 1);
				dest_textP[maxStorage - 1] = 0;
				err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
			}
			if (lenP)
				*lenP = totLen;
			DisposeBlock(&tempBlock);
		}
	}
	else if (lenP)
		*lenP = totLen;

return err;
}

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr				err = noErr;
BAPI_MemberRecord	pageMethods[TOT_METHODES] = 
					{	"Exec",		kExecMethod, 			"httpPage Exec(string server, int port=80)"
					};

BAPI_MemberRecord	pageProperty[TOT_PROPRIETIES] = 
					{	"head", 	kHeader,	"header",
						"body", 	kBody,		"string"
					};

	if (err = BAPI_NewMethods(api_data, pageClassID, pageMethods, TOT_METHODES, nil))
		return err;
	if (err = BAPI_NewProperties(api_data, pageClassID, pageProperty, TOT_PROPRIETIES, nil))
		return err;		

	err = BAPI_RegisterErrors(api_data, pageClassID, HTTPPAGE_START_ERR, gHttpPageErrorsStr, TOT_ERRORS);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*static XErr	_Add(long api_data, ExecuteMethodRec *exeMethodRecP, PageRec *pageRecP)
{
XErr		err = noErr;
ObjRef 		*paramsP = exeMethodRecP->paramVarsP;
long 		totParams = exeMethodRecP->totParams;
CStr255		aCStr;
BlockRef	ref;
char		*stringP;
long		stringLen;

	if (totParams == 1)
	{	if NOT(err = BAPI_GetStringBlock(api_data, &exeMethodRecP->paramVarsP[0], aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
		{	err = BufferAddBuffer(pageRecP->body, stringP, stringLen);
			BAPI_ReleaseStringBlock(&ref);
		}
	}
	else
		return XError(kBAPI_Error, Err_PrototypeMismatch);
	
return err;
}*/

#ifdef __LITTLE_ENDIAN__
	#define HEADER_END			0x0A0D0A0D		// '\n\r\n\r'
#else
	#define HEADER_END			'\r\n\r\n'
#endif
//#define	POST_REDIR_NOTIF	"SESSION_MSG=Warning:%20this%20page%20needs%20to%20be%20reloaded"
//===========================================================================================
static Boolean _EndsWithRedir(char *urlP, long urlLen, Boolean deny)
{
int			diff;	
Boolean		res;
char		*strP;
long		bRefLen;

	if (deny)
		strP = BIFERNO_DENY;
	else
		strP = BIFERNO_REDIR;
	bRefLen = CLen(strP);
	diff = urlLen - bRefLen;
	if ((diff >= 0) && NOT(CCompareStrings(urlP + diff, strP)))
		res = true;
	else
		res = false;

return res;
}

//===========================================================================================
static XErr	_RedirForCookies(long api_data, PageRec *pageOutP, Boolean useDenyRedir)
{
char		*urlP, *searchArgsP, *redirStr;
CStr255		urlString, searchArgsString;
ObjRef		urlObjRef, searchArgsObjRef, methodObjRef;
XErr		err = noErr;
long		urlLen, searchArgsLen;
char		*strP;
CStr63		methodStr;
BlockRef	urlRef, searchArgsRef, redirStrBlock;
long		bRefLen, toAlloc;

	BAPI_InvalObjRef(api_data, &urlObjRef);
	if NOT(err = BAPI_GetHTTPParam(api_data, BAPI_URL, &urlObjRef))
	{	if NOT(err = BAPI_GetStringBlock(api_data, &urlObjRef, urlString, &urlP, &urlLen, &urlRef, kImplicitTypeCast))
		{	if NOT(_EndsWithRedir(urlP, urlLen, true))
			{	if (NOT(useDenyRedir) && (_EndsWithRedir(urlP, urlLen, false)))
					useDenyRedir = true;
				/*{	err = XError(kBAPI_Error, Err_CookieDisabled);
					CEquStr(errStr, "Enable cookies in browser and retry");
				}
				else
				{*/
				BAPI_InvalObjRef(api_data, &searchArgsObjRef);
				if NOT(err = BAPI_GetHTTPParam(api_data, BAPI_SearchArg, &searchArgsObjRef))
				{	if NOT(err = BAPI_GetStringBlock(api_data, &searchArgsObjRef, searchArgsString, &searchArgsP, &searchArgsLen, &searchArgsRef, kImplicitTypeCast))
					{	if (useDenyRedir)
							bRefLen = CLen(BIFERNO_DENY);
						else
							bRefLen = CLen(BIFERNO_REDIR);
						toAlloc = urlLen + bRefLen + 1 + searchArgsLen + 1;
						if (redirStrBlock = NewBlockLocked(toAlloc, &err, &redirStr))
						{	CEquStr(redirStr, urlP);
							if (strP = strrchr(redirStr, '/'))
								*strP = 0;
							else
								*redirStr = 0;
							if (useDenyRedir)
							{	// remove "bifernoadmin"
								if (strP = strrchr(redirStr, '/'))
									*strP = 0;
								CAddStr(redirStr, BIFERNO_DENY);
							}
							else
								CAddStr(redirStr, BIFERNO_REDIR);
							if NOT(err = _SetCookie(&pageOutP->head, "BIFERNO_TRY", urlP))
							{	BAPI_InvalObjRef(api_data, &methodObjRef);
								if NOT(err = BAPI_GetHTTPParam(api_data, BAPI_Method, &methodObjRef))
								{	if NOT(err = BAPI_ObjToString(api_data, &methodObjRef, methodStr, nil, 63, kImplicitTypeCast))
									{	Boolean		use307;
									
										if NOT(strcmp(methodStr, "POST"))
											use307 = true;
										else
											use307 = false;
										if (searchArgsLen)
										{	CAddChar(redirStr, '?');
											CAddStr(redirStr, searchArgsP);
										}
										err = _Redirect(api_data, redirStr, CLen(redirStr), use307, true);
									}
								}								
							}
							DisposeBlock(&redirStrBlock);
						}
						BAPI_ReleaseBlock(&searchArgsRef);
					}
				}
			}
		BAPI_ReleaseBlock(&urlRef);
		}
	}

return err;
}

#define	CONT_LENGTH_TAG			"content-length"
#define	CONT_LENGTH_TAG_LEN		14

//===========================================================================================
// Research of content-length for http transactions
static Boolean	_CompleteCallBack(long bufferID, long bufferLen, long totalLengthP)
{
//XErr		err = noErr;
long		saveLen, headerLength, totLen = *(long*)totalLengthP;
Ptr			bufferP, saveP;
CStr63		aCStr;
int			i;
Boolean		finished = false;

	if (totLen != -1)
	{	if (totLen)
		{	if (bufferLen >= totLen)
				finished = true;
		}
		else
		{	BufferGetBlockRefExt(bufferID, &bufferP);
			saveP = bufferP;
			saveLen = bufferLen;
			while (bufferLen)
			{	if ((bufferLen > 3) && (*(long*)bufferP == CRLFCRLF))
				{	headerLength = bufferLen = bufferP - saveP + 4; // sizeof(CRLFCRLF)
					bufferP = saveP;
					while (bufferLen >= CONT_LENGTH_TAG_LEN)
					{	CopyBlock(aCStr, bufferP, CONT_LENGTH_TAG_LEN);
						aCStr[CONT_LENGTH_TAG_LEN] = 0;
						CUp2LowerStr(aCStr, 0);
						if NOT(CompareBlock(CONT_LENGTH_TAG, aCStr, CONT_LENGTH_TAG_LEN))
						{	bufferP += CONT_LENGTH_TAG_LEN;
							bufferLen -= CONT_LENGTH_TAG_LEN;
							SkipSpaceAndTab(&bufferP, &bufferLen);
							bufferP++;		// ':'
							bufferLen--;
							SkipSpaceAndTab(&bufferP, &bufferLen);
							i = 0;
							while(bufferLen && (i < 63))
							{	if (*(short*)bufferP == CRLF)
									break;
								else
								{	aCStr[i++] = *bufferP;
									bufferP++;
									bufferLen--;
								}
							}
							aCStr[i] = 0;
							CStringToNum(aCStr, &totLen);
							totLen += headerLength;
							*(long*)totalLengthP = totLen;
							if (saveLen >= totLen)
								finished = true;
							break;
						}
						else
						{	bufferP++;
							bufferLen--;
						}
					}
					if NOT(totLen)	// not found
						*(long*)totalLengthP = -1;
					break;
				}
				bufferP++;
				bufferLen--;
			}
		}
	}
	
return finished;
}

//===========================================================================================
static XErr	_get_timeout(long api_data, long *timeout_secsP)
{
XErr			err = noErr;
ObjRef			objRef;
Boolean			isDef;
unsigned long	timeout;

	if NOT(err = BAPI_GetCurrentScriptInfo(api_data, &timeout, nil, nil, nil))
	{	if (timeout)
			*timeout_secsP = timeout / 60;	// ticks -> seconds
		else	// if in config timeout is not yet defined
		{	
		long			aLong;
			
			if NOT(err = BAPI_IsVariableDefined(api_data, "TIMEOUT", APPLICATION, &isDef, &objRef))
			{	if NOT(OBJ_CLASSID(objRef))
					isDef = false;
				if (isDef)
				{	if NOT(err = BAPI_ObjToInt(api_data, &objRef, &aLong, kExplicitTypeCast))
						*timeout_secsP = aLong * 60;	// minute -> seconds
				}
				else
					*timeout_secsP = 0;
			}
		}
	}
	
return err;
}


//===========================================================================================
static XErr	_Exec(Biferno_ParamBlockPtr pbPtr, ExecuteMethodRec *exeMethodRecP, PageRec *pageRecP)
{
XErr			err = noErr;
long			totParams = exeMethodRecP->totParams;
long 			tLen, port, size, api_data = pbPtr->api_data, bodyLen, headBlockLen, serverResponseLen;
BlockRef		serverResponse, bodyBlock, headBlock;
Ptr				p;
CStr255			errString, serverAddr;
PageRec			newPageRec;
long			totalLength = 0;
long 			timeout_secs;

	if ((totParams == 1) || (totParams == 2))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP->objRef, serverAddr, nil, 255, kImplicitTypeCast))
		{	if (totParams == 2)
				err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[1].objRef, &port, kImplicitTypeCast);
			else
				port = 80;
			if NOT(err = _PackHeader(&pageRecP->head, &headBlock, &headBlockLen))
			{	bodyBlock = BufferGetBlockRef(pageRecP->body, &bodyLen);
				if (size = (headBlockLen + bodyLen))
				{	if NOT(err = SetBlockSize(headBlock, size = (headBlockLen + bodyLen)))
					{	p = GetPtr(headBlock);
						CopyBlock(p + headBlockLen, GetPtr(bodyBlock), bodyLen);
						LockBlock(headBlock);
						if NOT(err = _get_timeout(api_data, &timeout_secs))
						{	if NOT(err = XClientCall(serverAddr, port, headBlock, size , &serverResponse, &serverResponseLen, nil, errString, _CompleteCallBack, (long)&totalLength, timeout_secs, DONT_EXPECT_PREFIXED))
							{	LockBlock(serverResponse);
								p = GetPtr(serverResponse);
								if (tLen = serverResponseLen)
								{	do {
										p++;
										tLen--;
									} while (tLen && (*(long*)p != HEADER_END));
									if (tLen)
									{	p += sizeof(long);
										tLen -= sizeof(long);
									}
									ClearBlock(&newPageRec, sizeof(PageRec));
									if NOT(err = _TokenizeHeader(GetPtr(serverResponse), serverResponseLen-tLen, &newPageRec.head, LOCAL_LIST))
									{	if (newPageRec.body = BufferCreate(255, &err))
										{	if (tLen)
												err = BufferAddBuffer(newPageRec.body, p, tLen);
											if NOT(err)
											{	if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&newPageRec, sizeof(PageRec), pageClassID, true, nil, &exeMethodRecP->resultObjRef))
													;//(*pbPtr->plugin_run_dataP)++;
											}
										}
										if (err)
										{	if (newPageRec.body)
												BufferFree(newPageRec.body);
											if (newPageRec.head.list)
												_DisposeHeaderObject(&newPageRec.head);
										}
									}
									else
										err = XError(kBAPI_ClassError, ErrResponseHeaderIsInvalid);
								}
								else
									err = XError(kBAPI_ClassError, ErrServerRespondedNoData);
								DisposeBlock(&serverResponse);
							}
							else
							{	CEquStr(pbPtr->error, errString);
								//err = XError(kBAPI_ClassError, ErrCantConnectToServer);
							}
						}
					}
				}
				else
				{	CEquStr(pbPtr->error, "Header is empty");
					//err = XError(kBAPI_ClassError, ErrCantConnectToServer);
				}
				DisposeBlock(&headBlock);
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_PrototypeMismatch);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	HttpPage_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	pageClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.wantDestructor = true;
	pbPtr->param.registerRec.fixedSize = true;
	CEquStr(pbPtr->param.registerRec.constructor, "void httpPage(header head, string body)");
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, pageClassID, "HttpPage_Print", (long)HttpPage_Print))
		goto out;
	if (err = BAPI_RegisterSymbol(pbPtr->api_data, pageClassID, "HttpPage_GetOutput", (long)HttpPage_GetOutput))
		goto out;
	//if (err = BAPI_RegisterSymbol(pbPtr->api_data, pageClassID, "HttpPage_DisposeOutput", (long)HttpPage_DisposeOutput))
	//	goto out;

out:
return err;
}

//===========================================================================================
static XErr	HttpPage_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	gsHeaderClassID = BAPI_ClassIDFromName(api_data, "header", false);
	gsRequestClassID = BAPI_ClassIDFromName(api_data, "request", false);
	if (err = _RegisterListMembers(api_data))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "PackHeader", (long*)&_PackHeader))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "TokenizeHeader", (long*)&_TokenizeHeader))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "InitializeHeaderOut", (long*)&_InitializeHeaderOut))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "ObjRefFromHeaderObjectRec", (long*)&_ObjRefFromHeaderObjectRec))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "DisposeHeaderObject", (long*)&_DisposeHeaderObject))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "CloneHeaderObjectRec", (long*)&_CloneHeaderObjectRec))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "GetCookie", (long*)&_GetCookie))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "SetCookie", (long*)&_SetCookie))
		goto out;
	if (err = BAPI_GetSymbol(api_data, gsHeaderClassID, "GetHeaderField", (long*)&_GetHeaderField))
		goto out;

	if (err = BAPI_GetSymbol(api_data, gsRequestClassID, "Redirect", (long*)&_Redirect))
		goto out;

out:	
return err;
}

//===========================================================================================
static XErr	HttpPage_ShutDown(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif

	pageClassID = 0;
	
return noErr;
}

//===========================================================================================
static XErr	HttpPage_Exit(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;
CStr63		tStr;
long		bodyLen, tLen, api_data = pbPtr->api_data;
PageRec		pageOutRec;
ObjRef		pageOutObjRef;
Boolean		isDef;
	
	if NOT(err = BAPI_IsVariableDefined(api_data, "pageOut", GLOBAL, &isDef, &pageOutObjRef))
	{	if (isDef)
		{	tLen = sizeof(PageRec);
			if NOT(err = BAPI_ReadObj(api_data, &pageOutObjRef, (Ptr)&pageOutRec, &tLen, 0, nil))
			{	BufferGetBlockRef(pageOutRec.body, &bodyLen);
				CNumToString(bodyLen, tStr);
				err = SetHeadField(&pageOutRec.head, "Content-length", 0, tStr, CLen(tStr));
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	HttpPage_Run(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr, httpErr = noErr;
RunRec		*runRecP = &pbPtr->param.runRec;
long		sessionOk = 0, api_data = pbPtr->api_data;
PageRec		pageIn, pageOut;
ObjRef		pageObjRef;
Boolean		setCookie = false, isDef;
CStr63		biferno_TryStr, biferno_SIDStr, ipAddress, biferno_XIDStr;
Boolean		isValid, redirectSetBifernoTry = false;
ObjRef		aObjRef;
long		tLen;
ConstructorAPIdataRec	constrData;
char		refererStr[MAX_REFERER_LENGTH];
Boolean		useDenyRedir = false;

	// page in
	ClearBlock(&pageIn, sizeof(PageRec));
	if (runRecP->headInBlock)
	{	if (err = BAPI_GetIntConfig(api_data, "SESSION", &sessionOk, &isDef))
			return err;
		LockBlock(runRecP->headInBlock);
		err = _TokenizeHeader(GetPtr(runRecP->headInBlock), runRecP->headInBlockLen, &pageIn.head, LOCAL_LIST);
		UnlockBlock(runRecP->headInBlock);
	}
	else
	{	err = _TokenizeHeader("", 0, &pageIn.head, LOCAL_LIST);
		sessionOk = false;
	}
	if NOT(err)
	{	if (pageIn.body = BufferCreate(255, &err))
		{	if (runRecP->postBlock)
				BufferAddBuffer(pageIn.body, GetPtr(runRecP->postBlock), runRecP->postBlockLen);
			BAPI_InvalObjRef(api_data, &pageObjRef);
			constrData.scope = GLOBAL;
			constrData.type = CONSTANT;
			CEquStr(constrData.resultObjName, "pageIn");
			if (err = BAPI_BufferToObj(api_data, (Ptr)&pageIn, sizeof(PageRec), pageClassID, true, (long)&constrData, &pageObjRef))
			{	if (pageIn.body)
					BufferFree(pageIn.body);
				if (pageIn.head.list)
					_DisposeHeaderObject(&pageIn.head);
			}
		}
		if (NOT(err) && sessionOk)
		{	if NOT(err = _GetCookie(&pageIn.head, "BIFERNO_SID", biferno_SIDStr, 63))
			{	if NOT(err = _GetCookie(&pageIn.head, "BIFERNO_XID", biferno_XIDStr, 63))
				{	if (*biferno_SIDStr)
					{	if NOT(err = BAPI_CheckSID(api_data, biferno_SIDStr, biferno_XIDStr, &isValid))
						{	if NOT(isValid)
							{	*biferno_SIDStr = 0;
								httpErr = XError(kBAPI_Error, Err_InvalidSessionCookie);
								CEquStr(pbPtr->error, "Invalid checksum (try restarting your browser)");
								goto doPageOut;
							}
						}
					}
					if NOT(err)
					{	if NOT(err = HTTPControllerGetIPAddress(BAPI_HTTPTaskID(api_data), ipAddress))
						{	
							if NOT(*biferno_SIDStr)
							{	unsigned long	milliseconds;
								CStr63			tStr;
								
								if NOT(err = _GetCookie(&pageIn.head, "BIFERNO_TRY", biferno_TryStr, 63))
								{	if NOT(err = _GetHeaderField(api_data, "Referer", &aObjRef))
									{	long	refererStrLen;
									
										if NOT(err = BAPI_ObjToString(api_data, &aObjRef, refererStr, &refererStrLen, MAX_REFERER_LENGTH, kImplicitTypeCast))
										{	
											if (*biferno_TryStr /*|| NOT(exists)*/)
											{	CEquStr(biferno_SIDStr, ipAddress);
												XGetMilliseconds(&milliseconds);
												CNumToString(milliseconds, tStr);
												CAddChar(biferno_SIDStr, '-');
												CAddStr(biferno_SIDStr, tStr);
												setCookie = true;
												err = BAPI_SetSID(api_data, biferno_SIDStr, biferno_XIDStr, true);
											}
											else
											{	char	*strP;
											
												if (strP = strchr(refererStr, '?'))
												{	*strP = 0;
													refererStrLen = CLen(refererStr);
												}
												if (((tLen = refererStrLen - CLen(BIFERNO_REDIR)) < 0) || (CCompareStrings(refererStr + tLen, BIFERNO_REDIR)))
													redirectSetBifernoTry = true;
												else
												{	// NOT ends with deny
													if (((tLen = refererStrLen - CLen(BIFERNO_DENY)) < 0) || (CCompareStrings(refererStr + tLen, BIFERNO_DENY)))
														useDenyRedir = true;
												}
											}
										}
									}	
								}
							}
							else
							{	setCookie = false;
								err = BAPI_SetSID(api_data, biferno_SIDStr, biferno_XIDStr, false);
							}
						}
					}
				}
			}
		}
	}

doPageOut:
	// page out
	if NOT(err)
	{	ClearBlock(&pageOut, sizeof(PageRec));
		if NOT(err = _InitializeHeaderOut(runRecP->serverName, &pageOut.head, (Boolean)(runRecP->headInBlock == nil)))
		{	if (setCookie)
			{	if NOT(err = _SetCookie(&pageOut.head, "BIFERNO_XID", biferno_XIDStr))
					err = _SetCookie(&pageOut.head, "BIFERNO_SID", biferno_SIDStr);
			}
			if NOT(err)
			{	if (pageOut.body = BufferCreate(255, &err))
				{	BAPI_InvalObjRef(api_data, &pageObjRef);
					constrData.scope = GLOBAL;
					constrData.type = VARIABLE;
					CEquStr(constrData.resultObjName, "pageOut");
					if (err = BAPI_BufferToObj(api_data, (Ptr)&pageOut, sizeof(PageRec), pageClassID, true, (long)&constrData, &pageObjRef))
					{	if (pageOut.body)
							BufferFree(pageOut.body);
						if (pageOut.head.list)
							_DisposeHeaderObject(&pageOut.head);
					}
					else
					{	
						if NOT(err = BAPI_SetPageOut(api_data, &pageObjRef))
						{
							if (redirectSetBifernoTry)
								err = _RedirForCookies(api_data, &pageOut, useDenyRedir);
						}
					}
				}
			}
		}
	}
	/*if (err_CookieDisabled)
		err = XError(kBAPI_Error, Err_CookieDisabled);
	else
	{	*/
	if (NOT(err) && httpErr)
		err = httpErr;
	
return err;
}

//===========================================================================================
static XErr	HttpPage_Constructor(Biferno_ParamBlockPtr pbPtr, Boolean clone)
{
XErr				err = noErr;
ConstructorRec		*constructorRecP = &pbPtr->param.constructorRec;
long				dataLen, tLen, api_data = pbPtr->api_data;
PageRec				pageRec;
HeaderObjectRec		headObjectRec;
BlockRef			bl;

	if (clone && (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP->objRef) == pageClassID))
	{	PageRec	newPageRec;
	
		tLen = sizeof(PageRec);
		if NOT(err = BAPI_ReadObj(api_data, &constructorRecP->varRecsP->objRef, (Ptr)&pageRec, &tLen, 0, nil))
		{	if NOT(err = _CloneHeaderObjectRec(&pageRec.head, &newPageRec.head))
			{	if NOT(err = BufferClone(pageRec.body, &newPageRec.body, -1))
				{	if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&newPageRec, sizeof(PageRec), pageClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
						;//(*pbPtr->plugin_run_dataP)++;
				}
				if (err)
					_DisposeHeaderObject(&newPageRec.head);
			}
		}
	}
	else
	{	if (constructorRecP->totVars == 2)
		{	if (BAPI_GetObjClassID(api_data, &constructorRecP->varRecsP->objRef) == gsHeaderClassID)
			{	tLen = sizeof(HeaderObjectRec);
				if NOT(err = BAPI_ReadObj(api_data, &constructorRecP->varRecsP->objRef, (Ptr)&headObjectRec, &tLen, 0, nil))
				{	if NOT(err = _CloneHeaderObjectRec(&headObjectRec, &pageRec.head))
					{	if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[1].objRef, nil, &dataLen, 0, kImplicitTypeCast))
						{	if (pageRec.body = BufferCreate(255, &err))
							{	if NOT(err = BufferCheck(pageRec.body, ++dataLen, nil))		// ++ for 0 terminated
								{	bl = BufferGetBlockRef(pageRec.body, nil);
									LockBlock(bl);
									if NOT(err = BAPI_ObjToString(api_data, &constructorRecP->varRecsP[1].objRef, GetPtr(bl), nil, dataLen, kImplicitTypeCast))
									{	BufferSetLength(pageRec.body, dataLen);
										if NOT(err = BAPI_BufferToObj(api_data, (Ptr)&pageRec, sizeof(PageRec), pageClassID, true, constructorRecP->privateData, &constructorRecP->resultObjRef))
											;//(*pbPtr->plugin_run_dataP)++;
									}
									UnlockBlock(bl);
								}
							}
						}
						if (err)
						{	if (pageRec.body)
								BufferFree(pageRec.body);
							if (pageRec.head.list)
								_DisposeHeaderObject(&pageRec.head);
						}
					}
				}
			}
			else
			{	err = XError(kBAPI_Error, Err_IllegalTypeCast);
				CEquStr(pbPtr->error, "httpPage(header head, string body)");
			}
		}
		else
		{	err = XError(kBAPI_Error, Err_PrototypeMismatch);
			CEquStr(pbPtr->error, "httpPage(header head, string body)");
		}
	}
	
//if NOT(err)
//	BAPI_ObjRefSetClassID(api_data, &constructorRecP->resultObjRef, pageClassID);
	//constructorRecP->resultObjRef.classID = pageClassID;
		
return err;
}

//===========================================================================================
static XErr	HttpPage_Destructor(Biferno_ParamBlockPtr pbPtr)
{
XErr			err = noErr;
DestructorRec	*destructorRecP = &pbPtr->param.destructorRec;
PageRec			pageRec;
long			objLen, api_data = pbPtr->api_data;

	objLen = sizeof(PageRec);
	if NOT(err = BAPI_GetObj(api_data, &destructorRecP->objRef, (Ptr)&pageRec, &objLen, 0, nil))
	{	if (objLen && pageRec.head.list)
		{	
		#ifdef MEM_DEBUG
			DLM_CheckList(pageRec.head.list);
		#endif
			_DisposeHeaderObject(&pageRec.head);
			BufferFree(pageRec.body);
			//(*pbPtr->plugin_run_dataP)--;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	HttpPage_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long 				tLen;
PageRec				pageRec;

	tLen = sizeof(PageRec);
	if NOT(err = BAPI_ReadObj(pbPtr->api_data, &exeMethodRecP->objRef, (Ptr)&pageRec, &tLen, 0, nil))
	{	switch(exeMethodRecP->methodID)
		{
			case kExecMethod:
				err = _Exec(pbPtr, exeMethodRecP, &pageRec);
				break;

			default:
				err = XError(kBAPI_Error, Err_NoSuchMethod);
				break;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	HttpPage_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
PageRec			pageRec;
long			objLen, api_data = pbPtr->api_data, bodyLen;
BlockRef		bodyBlock;

	objLen = sizeof(PageRec);
	if NOT(err = BAPI_ReadObj(api_data, &getPropertyRec->objRef, (Ptr)&pageRec, &objLen, 0, nil))
	{	switch(getPropertyRec->propertyID)
		{
			case kHeader:
				err = _ObjRefFromHeaderObjectRec(api_data, &pageRec.head, &getPropertyRec->resultObjRef);
				break;
			case kBody:
				bodyBlock = BufferGetBlockRef(pageRec.body, &bodyLen);
				LockBlock(bodyBlock);
				err = BAPI_StringToObj(api_data, GetPtr(bodyBlock), bodyLen, &getPropertyRec->resultObjRef);
				UnlockBlock(bodyBlock);
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}

return err;
}

//===========================================================================================
static XErr	HttpPage_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec		*setPropertyRecP = &pbPtr->param.setPropertyRec;
XErr				err = noErr;
PageRec				pageRec;
long				objLen, api_data = pbPtr->api_data;
CStr255				aCStr;
BlockRef			ref;
char				*stringP;
long				stringLen;
HeaderObjectRec		headObjectRec;

	objLen = sizeof(PageRec);
	if NOT(err = BAPI_ReadObj(api_data, &setPropertyRecP->objRef, (Ptr)&pageRec, &objLen, 0, nil))
	{	switch(setPropertyRecP->propertyID)
		{
			case kHeader:
				if (BAPI_GetObjClassID(api_data, &setPropertyRecP->value) == gsHeaderClassID)
				{	objLen = sizeof(HeaderObjectRec);
					if NOT(err = BAPI_ReadObj(api_data, &setPropertyRecP->value, (Ptr)&headObjectRec, &objLen, 0, nil))
					{	_DisposeHeaderObject(&pageRec.head);
						if NOT(err = _CloneHeaderObjectRec(&headObjectRec, &pageRec.head))
							err = BAPI_ModifyObj(api_data, &setPropertyRecP->objRef, (Ptr)&pageRec, sizeof(PageRec));
					}
				}
				break;
			case kBody:
				if NOT(err = BAPI_GetStringBlock(api_data, &setPropertyRecP->value, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
				{	if NOT(err = BufferCheck(pageRec.body, stringLen, nil))
					{	if NOT(err = BufferReset(pageRec.body))
							err = BufferAddBuffer(pageRec.body, stringP, stringLen);
					}
					BAPI_ReleaseBlock(&ref);
				}
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}

return err;
}

//===========================================================================================
static XErr	HttpPage_TypeCast(Biferno_ParamBlockPtr pbPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pbPtr)
#endif
XErr			err = noErr;
PrimitiveRec	*typeCast = &pbPtr->param.primitiveRec;
long			headBlockLen, tLen;
char			*headP;
BlockRef		headBlock;
PageRec			pageRec;
PrimitiveUnion	*param_d;
Boolean			forConstr;

	tLen = sizeof(PageRec);
	if NOT(err = BAPI_GetObj(pbPtr->api_data, &typeCast->objRef, (Ptr)&pageRec, &tLen, 0, nil))
	{	param_d = &typeCast->result;
		forConstr = param_d->text.variant == kForConstructor;
		if (tLen)
			err = _PackHeader(&pageRec.head, &headBlock, &headBlockLen);
		else
			headBlock = headBlockLen = 0;
		if NOT(err)
		{	if (headBlock)
			{	if (param_d->text.variant == kForConstructor)
				{
				BlockRef	escapedBlock;
				Ptr			strP;
				long		strLen;
				
					LockBlock(headBlock);
					strP = GetPtr(headBlock);
					strLen = headBlockLen;
					if NOT(err = StringEscaped(&strP, &strLen, &escapedBlock))
					{	DisposeBlock(&headBlock);
						headBlock = escapedBlock;
						headBlockLen = strLen;
					}
				}
				LockBlock(headBlock);
				headP = GetPtr(headBlock);
			}
			if NOT(err)
			{	if (typeCast->resultWanted == kCString)
				{	if (headBlock)
						err = _GetHTTPText(&pageRec, headP, headBlockLen, param_d->text.stringP, &param_d->text.stringLen, param_d->text.stringMaxStorage, forConstr);
					else
						err = _PrimitiveString(param_d, nil, 0);
				}
				else
					err = XError(kBAPI_Error, Err_IllegalTypeCast);
			}
			if (headBlock)
				DisposeBlock(&headBlock);
		}
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	httpPage_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = HttpPage_Register(pbPtr);
			break;
		case kInit:
			err = HttpPage_Init(pbPtr);
			break;
		case kShutDown:
			err = HttpPage_ShutDown(pbPtr);
			break;
		case kRun:
			//pbPtr->plugin_run_data = 0;
			err = HttpPage_Run(pbPtr);
			break;
		case kExit:
		/*#ifdef MEM_DEBUG
			if (*pbPtr->plugin_run_dataP)
			{	CStr63	debugStr;
			
				sprintf(debugStr, "httpPage: leaking, %d", (*pbPtr->plugin_run_dataP));
				BAPI_Log(pbPtr->api_data, debugStr);
			}
		#endif*/
			err = HttpPage_Exit(pbPtr);
			break;
		case kConstructor:
		case kTypeCast:
			err = HttpPage_Constructor(pbPtr, false);
			break;
		case kClone:
			err = HttpPage_Constructor(pbPtr, true);
			break;
		case kDestructor:
			err = HttpPage_Destructor(pbPtr);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = HttpPage_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = HttpPage_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = HttpPage_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = HttpPage_TypeCast(pbPtr);
			break;
		/*case kGetErrDescr:
			err = HttpPage_GetErrDescr(pbPtr);
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


