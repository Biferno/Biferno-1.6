/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Client.c,v 1.7 2006-03-03 12:06:41 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"
#include 	"BfrHeader.h"

// defines
#define	gsPlugName	"client"

// Methods
enum{
		kGetIndSID = 1,
		kSessionVariable
	};
#define TOT_METHODES	2

// Properties
#define TOT_PROPRIETIES	6
enum{
		kIPAddress = 1,
		kAddress,
		kUser,
		k_Password,
		kFromUser,
		kUserAgent
	};

static 	long	gsApiVersion, clientClassID;

//===========================================================================================
static XErr	_GetIndSID(ExecuteMethodRec *exeMethodRecP,long api_data)
{
XErr		err = noErr;
long		index;
CStr255		sidStr;

	if NOT(err = BAPI_ObjToInt(api_data, &exeMethodRecP->paramVarsP[0].objRef, &index, kExplicitTypeCast))
	{	if (index)
			err = BAPI_GetIndSID(api_data, index, sidStr);
		else
			err = BAPI_GetSID(api_data, sidStr, nil);
		if NOT(err)
			err = BAPI_StringToObj(api_data, sidStr, CLen(sidStr), &exeMethodRecP->resultObjRef);
	}

return err;
}

//===========================================================================================
static XErr	_SessionVariable(ExecuteMethodRec *exeMethodRecP, long api_data, char *error)
{
XErr		err = noErr;
long		resultLen;
CStr255		sidStr, varName, result;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, sidStr, nil, 255, kExplicitTypeCast))
	{	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[1].objRef, varName, nil, 255, kExplicitTypeCast))
		{	err = BAPI_SessionVariableToString(api_data, sidStr, varName, result, &resultLen, 255);
			if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
				CEquStr(error, "SessionVariable cant return more than 255 chars strings");
			else if NOT(err)
				err = BAPI_StringToObj(api_data, result, resultLen, &exeMethodRecP->resultObjRef);
		}
	}

return err;
}

//===========================================================================================
static XErr	_RegisterListMembers(long api_data)
{
XErr	err = noErr;
BAPI_MemberRecord	clientMethod[TOT_METHODES] = 
					{	"GetIndSID",		kGetIndSID,			"static string GetIndSID(int index)",
						"SessionVariable",	kSessionVariable,	"static string SessionVariable(string SID, string name)"
					};

BAPI_MemberRecord	clientProperty[TOT_PROPRIETIES] = 
					{	"ipAddress",		kIPAddress,			"static string",
						"address",			kAddress,			"static string",
						"user",				kUser,				"static string",
						"password",			k_Password,			"static string",
						"fromUser",			kFromUser,			"static string",
						"userAgent",		kUserAgent,			"static string"
					};

	if (err = BAPI_NewProperties(api_data, clientClassID, clientProperty, TOT_PROPRIETIES, nil))
		return err;		
	if (err = BAPI_NewMethods(api_data, clientClassID, clientMethod, TOT_METHODES, nil))
		return err;

//out:
return err;
}

//===========================================================================================
/*static XErr	_GetHeaderField(long api_data, char *fieldName, ObjRef *objRefP)
{
ObjRef			pageIn, headIn;
XErr			err = noErr;
Boolean			isDef;
ParameterRec	fieldNameS;

	if NOT(err = BAPI_IsVariableDefined(api_data, "pageIn", GLOBAL, &isDef, &pageIn))
	{	if (isDef)
		{	ClearBlock(&fieldNameS, sizeof(ParameterRec));
			if NOT(err = BAPI_StringToConstObj(api_data, fieldName, CLen(fieldName), &fieldNameS.objRef))
			{	if NOT(err = BAPI_GetProperty(api_data, &pageIn, "head", 1, nil, &headIn))
				{	err = BAPI_ExecuteMethod(api_data, &headIn, &fieldNameS, 1, "GetField", objRefP);
					if (err)
						err = BAPI_StringToConstObj(api_data, "", 0, objRefP);
				}
			}
		}
	}

return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	Client_Register(Biferno_ParamBlockPtr pbPtr)
{
	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	gsApiVersion = pbPtr->param.registerRec.api_version;
	clientClassID = pbPtr->param.registerRec.pluginID;
	
return noErr;
}

//===========================================================================================
static XErr	Client_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	//initRecP->plugin_global_data = nil;
	//CEquStr(initRecP->constructor, "static void client(void)");
	err = _RegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	Client_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				api_data = pbPtr->api_data;

	switch(exeMethodRecP->methodID)
	{
		case kGetIndSID:
			err = _GetIndSID(exeMethodRecP, api_data);
			break;
		case kSessionVariable:
			err = _SessionVariable(exeMethodRecP, api_data, pbPtr->error);
			break;
	}
	
return err;
}

//===========================================================================================
static XErr	Client_GetProperty(Biferno_ParamBlockPtr pbPtr)
{
GetPropertyRec	*getPropertyRec = &pbPtr->param.getPropertyRec;
XErr			err = noErr;
long			api_data = pbPtr->api_data;

	switch(getPropertyRec->propertyID)
	{
		case kIPAddress:
			err = BAPI_GetHTTPParam(api_data, BAPI_IPAddress, &getPropertyRec->resultObjRef);
			break;
		case kAddress:
			err = BAPI_GetHTTPParam(api_data, BAPI_Address, &getPropertyRec->resultObjRef);
			break;
		case kUser:
			err = BAPI_GetHTTPParam(api_data, BAPI_Username, &getPropertyRec->resultObjRef);
			break;
		case k_Password:
			err = BAPI_GetHTTPParam(api_data, BAPI_Password, &getPropertyRec->resultObjRef);
			break;
		case kFromUser:
			err = GetHeaderField(api_data, "From", &getPropertyRec->resultObjRef);
			break;
		case kUserAgent:
			err = GetHeaderField(api_data, "User-Agent", &getPropertyRec->resultObjRef);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

//===========================================================================================
static XErr	Client_SetProperty(Biferno_ParamBlockPtr pbPtr)
{
SetPropertyRec	*setPropertyRec = &pbPtr->param.setPropertyRec;
XErr			err = noErr;

	switch(setPropertyRec->propertyID)
	{
		case kIPAddress:
		case kAddress:
		case kUser:
		case k_Password:
		case kFromUser:
		case kUserAgent:
			err = XError(kBAPI_Error, Err_PropertyIsOnlyRead);
			break;
		default:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	client_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = Client_Register(pbPtr);
			break;
		case kInit:
			err = Client_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kClone:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kDestructor:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = Client_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = Client_GetProperty(pbPtr);
			break;
		case kSetProperty:
			err = Client_SetProperty(pbPtr);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		/*case kGetErrDescr:
			break;*/
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


