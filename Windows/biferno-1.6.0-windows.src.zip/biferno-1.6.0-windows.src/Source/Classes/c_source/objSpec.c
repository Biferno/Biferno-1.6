/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: objSpec.c,v 1.11 2008-06-13 14:27:25 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include 	"BifernoAPI.h"
#include 	"StaticClasses.h"

// defines
#define	gsPlugName	"object"

// Methods
enum{
		kHide = 1,
		kShow,
		kLock,
		kUnlock,
		kIsInitialized,
		kIsHidden,
		//kIsRefInitialized,
		kConstructorString,
		kDebuggerString,
		kValueOfInput,
		kCreate,
		kGetSuper
	};
#define TOT_METHODES	11

static 	long	objSpecClassID;

				
//===========================================================================================
static XErr	_ObjSpecRegisterListMembers(long api_data)
{
XErr	err = noErr;

BAPI_MemberRecord	objSpecMethods[TOT_METHODES] = 
					{
						"Hide",					kHide,					"static void Hide(obj variable)",
						"Show",					kShow,					"static void Show(obj variable)",
						"Lock",					kLock,					"static void Lock(obj variable)",
						"Unlock",				kUnlock,				"static void Unlock(obj variable)",
						"IsInitialized",		kIsInitialized,			"static boolean IsInitialized(obj variable)",
						"IsHidden",				kIsHidden,				"static boolean IsHidden(obj variable)",
						//"IsRefInitialized",		kIsRefInitialized,		"static boolean IsRefInitialized(obj *variable)",
						"ConstructorString",	kConstructorString,		"static string ConstructorString(obj variable)",
						"DebuggerString",		kDebuggerString,		"static string DebuggerString(obj variable)",
						"ValueOfInput", 		kValueOfInput,			"static string ValueOfInput(obj variable)",						
						"Create", 				kCreate,				"static obj Create(string className)",
						"GetSuper", 			kGetSuper,				"static obj GetSuper(obj variable)"
					};

	if (err = BAPI_NewMethods(api_data, objSpecClassID, objSpecMethods, TOT_METHODES, nil))
		return err;

//out:
return err;
}

//===========================================================================================
static XErr	_LockObject(ExecuteMethodRec *exeMethodRecP, long api_data, Boolean toLock)
{
XErr		err = noErr;

	if (toLock)
		err = BAPI_LockObj(api_data, &exeMethodRecP->paramVarsP[0].objRef);
	else
		err = BAPI_UnlockObj(api_data, &exeMethodRecP->paramVarsP[0].objRef);

return err;
}

//===========================================================================================
static XErr	_Hide(ExecuteMethodRec *exeMethodRecP, Boolean toHide, long api_data)
{
	return BAPI_Hide(api_data, toHide, &exeMethodRecP->paramVarsP[0].objRef);
}

//===========================================================================================
static XErr	_IsInitialized(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
Boolean		isInitialized;

	if NOT(err = BAPI_IsVariableInitialized(api_data, &exeMethodRecP->paramVarsP[0].objRef, &isInitialized))
		err = BAPI_BooleanToObj(api_data, isInitialized, &exeMethodRecP->resultObjRef);
		
return err;
}

//===========================================================================================
static XErr	_IsHidden(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
Boolean		isHidden;

	if NOT(err = BAPI_IsVariableHidden(api_data, &exeMethodRecP->paramVarsP[0].objRef, &isHidden))
		err = BAPI_BooleanToObj(api_data, isHidden, &exeMethodRecP->resultObjRef);
		
return err;
}

//===========================================================================================
static XErr	_CreateVar(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr63		classStr;
long		classID;
Boolean		fixedSize;

	if NOT(err = BAPI_ObjToString(api_data, &exeMethodRecP->paramVarsP[0].objRef, classStr, nil, 64, kImplicitTypeCast))
	{	if (classID = BAPI_ClassIDFromName(api_data, classStr, false))
		{	if NOT(err = BAPI_FixedSize(api_data, classID, &fixedSize))
				err = BAPI_BufferToObj(api_data, "", 0, classID, fixedSize, nil, &exeMethodRecP->resultObjRef);
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchClass);
	}

return err;
}

//===========================================================================================
static XErr	_GetSuper(ExecuteMethodRec *exeMethodRecP, long api_data)
{
	XErr		err = noErr;
	
	err = BAPI_GetSuperObj(api_data, &exeMethodRecP->paramVarsP[0].objRef, &exeMethodRecP->resultObjRef);
	if (err == XError(kBAPI_Error, Err_VariableNotInitialized))
	{
		BAPI_InvalObjRef(api_data, &exeMethodRecP->resultObjRef);
		err = BAPI_StringToObj(api_data, "[]", 0, &exeMethodRecP->resultObjRef);
	}
	
	return err;
}

//===========================================================================================
static XErr	_ValueOfInput(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr			err = noErr;
long			classID, finalLen, classNameLen, textLen;
Ptr				finalP, textP;
BlockRef		finalBlock, ref, encodedStringBlock;
CStr255			aCStr;
CStr63			className;
ObjRef			*objP = &exeMethodRecP->paramVarsP[0].objRef;

	if NOT(err = BAPI_GetStringBlockExt(api_data, objP, aCStr, &textP, &textLen, &ref, kExplicitTypeCast, kForConstructor))
	{	if NOT(err = BAPI_GetObjClassIDExt(api_data, objP, &classID))
		{	if NOT(err = BAPI_NameFromClassID(api_data, classID, className))
			{	classNameLen = CLen(className);
				finalLen = classNameLen + 1 + textLen + 1;
				if (finalBlock = NewBlockLocked(finalLen, &err, &finalP))
				{	CopyBlock(finalP, className, classNameLen);
					CopyBlock(finalP + classNameLen, "(", 1);
					CopyBlock(finalP + classNameLen + 1, textP, textLen);
					CopyBlock(finalP + classNameLen + 1 + textLen, ")", 1);
					if NOT(err = BAPI_EncodeURL(api_data, (Byte*)finalP, finalLen, &encodedStringBlock, &textLen, false, nil))
					{	LockBlock(encodedStringBlock);
						textP = GetPtr(encodedStringBlock);
						err = BAPI_StringToObj(api_data, textP, textLen, &exeMethodRecP->resultObjRef);
						DisposeBlock(&encodedStringBlock);
					}
					DisposeBlock(&finalBlock);
				}
			}
		}
		BAPI_ReleaseBlock(&ref);
	}

return err;
}
//===========================================================================================
static XErr	_ConstructorString(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
long		strLen;
Ptr			stringP;
BlockRef	ref;

	if NOT(err = BAPI_GetStringBlockExt(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &strLen, &ref, kExplicitTypeCast, kForConstructor))
	{	err = BAPI_StringToObj(api_data, stringP, strLen, &exeMethodRecP->resultObjRef);		
		BAPI_ReleaseBlock(&ref);
	}
	
return err;
}

//===========================================================================================
static XErr	_DebuggerString(ExecuteMethodRec *exeMethodRecP, long api_data)
{
XErr		err = noErr;
CStr255		aCStr;
long		strLen;
Ptr			stringP;
BlockRef	ref;

	if NOT(err = BAPI_GetStringBlockExt(api_data, &exeMethodRecP->paramVarsP[0].objRef, aCStr, &stringP, &strLen, &ref, kExplicitTypeCast, kForDebug))
	{	err = BAPI_StringToObj(api_data, stringP, strLen, &exeMethodRecP->resultObjRef);		
		BAPI_ReleaseBlock(&ref);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	ObjSpec_Register(Biferno_ParamBlockPtr pbPtr)
{
XErr		err = noErr;

	pbPtr->param.registerRec.pluginType = kNewClassPlugin;
	CEquStr(pbPtr->param.registerRec.pluginName, gsPlugName);
	objSpecClassID = pbPtr->param.registerRec.pluginID;
	pbPtr->param.registerRec.fixedSize = true;
		
//out:
return err;
}

//===========================================================================================
static XErr	ObjSpec_Init(Biferno_ParamBlockPtr pbPtr)
{
//NewClassRec	*initRecP = &pbPtr->param.initRec.newClassRec;
XErr		err = noErr;
long		api_data = pbPtr->api_data;

	err = _ObjSpecRegisterListMembers(api_data);
		
return err;
}

//===========================================================================================
static XErr	ObjSpec_ExecuteMethod(Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
ExecuteMethodRec	*exeMethodRecP = &pbPtr->param.executeMethodRec;
long				/*tLen, */api_data = pbPtr->api_data;

	switch(exeMethodRecP->methodID)
	{
		case kHide:
			err = _Hide(exeMethodRecP, true, api_data);
			break;
		case kShow:
			err = _Hide(exeMethodRecP, false, api_data);
			break;
		case kLock:
			err = _LockObject(exeMethodRecP, api_data, true);
			break;
		case kUnlock:
			err = _LockObject(exeMethodRecP, api_data, false);
			break;
		case kIsInitialized:
			err = _IsInitialized(exeMethodRecP, api_data);
			break;
		case kIsHidden:
			err = _IsHidden(exeMethodRecP, api_data);
			break;
		/*case kIsRefInitialized:
			err = _IsInitialized(exeMethodRecP, api_data);
			break;*/
		case kConstructorString:
			err = _ConstructorString(exeMethodRecP, api_data);
			break;
		case kDebuggerString:
			err = _DebuggerString(exeMethodRecP, api_data);
			break;
		case kValueOfInput:		
			err = _ValueOfInput(exeMethodRecP, api_data);
			break;
		case kCreate:		
			err = _CreateVar(exeMethodRecP, api_data);
			break;
		case kGetSuper:		
			err = _GetSuper(exeMethodRecP, api_data);
			break;
			
		default:
			err = XError(kBAPI_Error, Err_NoSuchMethod);
			break;
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

#if __MWERKS__
#pragma export on
#endif

//===========================================================================================
XErr	objSpec_Dispatch(Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr	err = noErr;

	switch(message)
	{
		case kRegister:
			err = ObjSpec_Register(pbPtr);
			break;
		case kInit:
			err = ObjSpec_Init(pbPtr);
			break;
		case kShutDown:
			break;
		case kRun:
			break;
		case kExit:
			break;
		case kConstructor:
		case kTypeCast:
		case kClone:
			err = XError(kBAPI_Error, Err_ClassIsStatic);
			break;
		case kDestructor:
			break;
		case kExecuteOperation:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		case kExecuteMethod:
			err = ObjSpec_ExecuteMethod(pbPtr);
			break;
		case kExecuteFunction:
			break;
		case kGetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kSetProperty:
			err = XError(kBAPI_Error, Err_NoSuchProperty);
			break;
		case kPrimitive:
			err = XError(kBAPI_Error, Err_IllegalOperation);
			break;
		default:
			err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
			break;
	}

return err;
}
#if __MWERKS__
#pragma export off
#endif


