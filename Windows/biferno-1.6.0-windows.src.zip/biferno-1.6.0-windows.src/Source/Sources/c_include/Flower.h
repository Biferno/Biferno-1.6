/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Flower.h,v 1.30 2008-12-02 11:08:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef	_FLOWER_
	#define	_FLOWER_	1

#include "Compiler.h"

#define	MAX_PARCHECKS	128
#define	MAX_INCLUDES	12


#define	COMPILING(api_data)					(0)	// (((BifernoRecP)api_data)->application.compilerActive)
#define	SET_COMPILING(api_data, value)		(((BifernoRecP)api_data)->application.compilerActive = value)

enum {
	kNone = 0,
	kProcessingInclude,
	kProcessingFunction
	};

#define	MAX_FUNCTION_INSTACK	128
/*typedef struct {
				DLMRef			funcList;
				long			funcID;
				ParameterRec 	*paramVarsP;
				BlockRef		paramVarsBlock;
				long			totParams;
				CStr63			methodName;
				Ptr				lastStatementP;
				long			lastStatementLen;
				} StackItem;*/
				
typedef struct {
				uint32_t		plugin_run_data;
				XErr			plugin_error_on_run;
				} BRunThreadClassRec;
				
typedef struct {
				CStr255			name;					// application name
				XFilePath		basePath;				// application base Path
				CStr255			devIP;					// DEVELOPER_IP
				CStr255			webMaster;
				CStr255			fromMail;
				CStr255			mailHost;
				XFilePath		fnfPage;				// file not found page
				DLMRef			list;					// application list
				DLMRef			persistentList;			// persistent list of this application
				DLMRef			sessionsArrayList;		// array of session lists
				unsigned long	session_timeout;		// session timeout
				Boolean			sessionOK;				// session ok
				Boolean			cacheActive;			// cache active
				Boolean			pad2;					// javaActive;
				Boolean			compilerActive;
				unsigned long	totFilesSaved;
				unsigned long	maxFilesSaved;
				XFilePath		headerFilePath;
				XFilePath		footerFilePath;
				XFilePath		errorFolder;
				unsigned long	timeOut;
				DLMRef			funcsList;
				DLMRef			classList;
				XFilePath		errPagePath;
				XFilePath		debugPagePath;
				XFilePath		acPath;
				XFilePath		acNoAccessPath;
				CStr63			acRealmName;
				CStr63			adminPassword;
				CStr15			dateFormat;
				Byte			thousSep;
				Byte			decSep;
				Boolean			notifyMail;
				Byte			pad;//	applObjID;		// No More than 65000 applications
				//long			totParents;
				//BlockRef		parents;	// array of BAPI_Name
				} Application;

typedef struct {
				DLMRef				classList;
				DLMRef				funcsList;
				//DLMRef			funcsPrototypesList;
				} LocalRecord;

#define		MAX_BREAKS_IN_LOOP		128

// This contains all field that must be changed on function/method call
typedef struct {
				long			returnClassID;
				long			returnAeClass;
				long			returnAeLevel;
				long			curMethodList;
				long			defaultScope;
				long			currentLine;				// line of code actually processing
				long			currentOffset;				// offset in file
				long			methodInExecutionID;		// the id of the method/function in execution
				Boolean			inTag;
				Boolean			_stop;
				short			processing;					// can be kProcessingInclude or kProcessingFunction
				long			bisFunctionInitLine;
				long			leftMemberClass;
				ObjRecord		switchObject;
				short			lastMultiStrStart;
				short			lastMultiStrEnd;
				XFilePath		currentExecFile;			// file actually processing (differs from bRecP->curFile if executing function defined in another file)
				long			lastLoadLine;
				long			tot_graf_pars;				// total '{' opened
				short			toBalance[MAX_PARCHECKS];
				} CallerCtx;

typedef struct {
	// Current Application
	Application			application;
	LocalRecord			local;
	long				applicationObjID;
	
	// Compiler
	BICRecord			bicRecord;
	
	// Current File
	CacheResult			curFile;					// file actually processing
	
	CStr255				serverName;
	
	// User data (task id of the HTTP Controller)
	void				*userData;
	
	XFilePath			serverBaseDir;
	
	BAPI_OutputFunc 	outputFunc;			
	
	long				poolSlot;
	//long				poolBlock;
	
	uint32_t			poolThreadDataSlot;
	//long				poolThreadDataBlock;
	
	// user
	CStr63				username;
	CStr63				password;
	
	// Current Session
	DLMRef				sessionList;				// relativa alla sessione dell'utente
	CStr255				SID;						// user unique session ID (in Cookie)
	LONGLONG			XID;
	Boolean				sessionFirstTime;
	Boolean				setNewSID;
	
	// unique run id
	LONGLONG			uniqueID;
	
	// Local scripts
	Boolean				scriptIsLocal;
	Byte				applicationInitFailed;
	
	// Timeouts, yield and Aborts
	unsigned long		startTicks;
	//struct timeval		startTicksTV;
	//struct timeb 		startTimeB;
	unsigned long		finalTicks;
	//struct timeval		finalTicksTV;
	//struct timeb 		finalTimeB;
	unsigned long		timeOut;
	unsigned long		lastYield;
	
	long				curThreads;
	long				maxThreads;
	
	// The file (and dir) actually processed
	XFilePath			mainFilePath;
	XFilePath			curBasePath;
	//short				lastMultiExprStart;
	//short				lastMultiExprEnd;
	
	// Java Environment JNI Pointer
	//long				theEnvP;
	
	// Variables
	DLMRef				volatileList;
	long				volatileLevel;
	long				volatileMaxSize;
	long				volatileResets;
	DLMRef				localList;
	DLMRef				globalList;
	//long				globErrID;
	ObjRecord			globErrObjRef;
	//DLMRef				errorList;
	//DLMRef				errorListAtDebugPageStartup;
	//long				errorLine;
	//DLMRef				lastLocalErrorList;		// never dispose it (it's only a ref)
	
	// Errors
	//XErr				exceptionError;
	//long				exceptionErrorClassID;
	//long				exceptionClassID;
	//long				exceptionLine;
	ErrorMsgRecord		errMessageRec;
	CStr255				class_error_note;
	CStr63				onErrorFunc;
	long				lastClassIDErrorCalled;
	Boolean				outOfBoundary;
	Boolean				moreErrors;		// more than one error in a script
	
	//Boolean				errInInclude;
	//Boolean				errInFunction;
	/*short				processing;				// can be kProcessingInclude or kProcessingFunction
	 Boolean				assignment;
	 Boolean				pad45;	//errVarTableBlockValid;*/
	//BlockRef			errVarTableBlock;
	//long				errVarTableLength;
	
	// Preferences
	Byte				thousSep;
	Byte				decSep;
	
	// Thread data of the classes
	BlockRef			class_thread_dataBlock;		// BlockRef of class_thread_data of all plug-ins
	BRunThreadClassRec	*class_thread_dataP;		// class_thread_data of all plug-ins
	
	// Flower parameters
	long				methodInExecutionClass;		// the class owning the method in execution
	long				visibilityClass;			// the class from check the visibility (public etc...)
	//long				methodInExecutionList;		// the list of the method in execution
	Boolean				stopEval;
	Boolean				resumeAlwaysCaller;
	Boolean				mainPathContainsBifernoAdmin;
	Byte				totIncludes;
	CallerCtx			currentCtx;
	
	// { }
	long				lastLoopCurGraph;
	long				lastLoopFlags;
	
	long				lastSwitchCurGraph;
	short				lastSwitchFlags;
	Boolean				inSwitch;
	Boolean				noImmediate;
	
	// label
	CStr63				curLabelName;				// for goto
	
	// Prinf filter
	//CStr63				printFilterName;
	//long				printFilterObjID;
	BlockRef			printFilterDocBlock;
	
	// Flow controls
	Boolean				_return;
	Boolean				suspendMsgs;
	short				inLoop;						// we are in loop
	Boolean				_exit;						// exit flow control
	Boolean				_break;						// break flow control
	Boolean				_continue;					// continue flow control
	Boolean				_suspendResume;
	
	// Errors
	long				onErrorResume;				// On error stop process or resume (Incremental)
	
	// Bfr Stack
	BufferID			stackBufferID;
	long				stackPointer;
	BufferID			includeStackBufferID;
	long				includeStackPointer;
	//long				stackPointerAtDebugTime;
	
	// Flower
	Boolean				assignment;					// we are inside bis tags
	Boolean				sideEffect;
	short				locked;
	
	long				totBreakOffset;
	long				breakOffset[MAX_BREAKS_IN_LOOP];
	
	// Functions
	ObjRecord			lastFuncResultObj;
	//BAPI_Doc			*currentBisFunctionP;
	//long				lastFunctionReturnType;
	//long				lastFunctionReturnAeClass;
	//long				lastFunctionReturnAeLevel;
	//long				bisFunctionInitLine;
	
	// Loading a class
	Boolean				loadingClass;
	Boolean				fromUpdateObject;
	short				inOtherTag;
	long				lastScope;
	/*
	 CStr63				curLoadingClassName;
	 DLMRef				curLoadClassMethodList;
	 DLMRef				curLoadClassPropertyList;
	 DLMRef				curLoadClassPropertyTemporaneousStaticList;
	 DLMRef				curLoadClassStaticList;
	 DLMRef				curLoadClassPrototypeList;
	 DLMRef				curLoadClassErrorsList;
	 long				lastClassID;
	 Byte				lastVisibility;
	 Boolean				lastIsConstant;
	 Boolean				lastIsStatic;
	 Byte				pad45;
	 */
	// this, super or "in destruction" objects
	ObjRecord			thisObjRef;
	ObjRecord			superObjRef;
	ObjRecord			objRefInDestruction;
	
	Boolean				inEval;
	long				executingConstructor;
	
	// Ending procedures
	Boolean				flushApp;
	Boolean				closeApp;
	Boolean				flushAll;
	Boolean				exitEventCompleted;
	
	// Result block will have the length preponed
	Boolean				prefixLengthInResult;
	
	// we are in flow control
	Boolean				inFlow;
	
	// Mem full err
	Boolean				criticalMem;
	
	Boolean				noParamSmartRetry;
	Boolean				inDebugPageReset;			//callerInvalid;	// the DLM of caller has been disposed, debug table fails if has ref pointing to caller var
	Boolean				inDebugPage;
	Boolean				errUpdated;
	
	// Standard output resources
	long				alternativeBuffer;
	ObjRecord			pageOutObjRef;
	
	// C Stack
	unsigned long		stackBasePointer;
	long				stackSize;
	
	BlockRef			sessionCS;	// a session entered in critical section?
	
	// complete errors only after script init
	Boolean				errGettingInputParameters;
	Byte				pad1;
	short				pad2;
		
} BifernoRec, *BifernoRecP;

// Flow Control
enum {
		k_Exit = 1,
		k_Stop,
		k_For,
		k_Do,
		k_While,
		k_If,
		k_Else,
		k_Break,
		k_Continue,
		k_Switch,
		k_Case,
		k_Default,
		k_Include,
		k_Load,
		k_Lock,
		k_Unlock,
		k_Debug,
		k_Goto,
		k_Function,
		//k_Static,
		k_Class,
		k_Return
};

// Flags for ProcessBlock
#define		kOnlyOneStatement	1L
#define		kNoFlowControl		2L
#define		kStopOnCR			4L
#define		kStopOnDollar		8L
#define		kStopOnComma		16L
#define		kStopOnSemicolon	32L
#define		kInAssignment		64L
#define		kInCase				128L
#define		kLoadParamOnStack	256L
#define		kStopOnPeriod		512L
#define		kStopOnElse			1024L

#define		kCaseFound			1
#define		kDefaultFound		2

XErr	EvalFunction(long api_data, long requestedClassID, Ptr *expressPPtr, long *expressLenP, ObjRecordP resultVarRecP);

Boolean IsFlowControl(long api_data, char *fcName, Ptr *oldFilePPtr, long *lenP, long *fcIDP, long *entityLengthP, XErr *errP);
Boolean IsFlowControlExt(long api_data, Ptr *oldFilePPtr, long *lenP, long *fcIDP, long *entityLengthP);

#define	SKIP_FORCED	true

XErr 	DoFlowControl(long api_data, long fcID, Ptr *oldFilePPtr, long *lenP, long flags, Boolean skipForced);
void	ProcessMain(long api_data, Ptr textP, long textLen, Boolean checkPars, XErr *theErrorP);
XErr	EvalWithResume(long api_data, Ptr *expressPPtr, long *expressLenP, long flags, ObjRecordP resultVarRecP);
XErr	CheckIfResume(long api_data, XErr theError, Ptr *expressPPtr, long *expressLenP);
XErr 	IncludeFile(long api_data, XFilePathPtr filePath, Boolean neverCache, char *functionFromFile);
XErr	BifernoGetFile(BifernoRecP bRecP, XFilePathPtr filePath, CacheResult *cacheResP, Boolean neverCache);
XErr	SkipEntireBlock(long api_data, Ptr *oldFilePPtr, long *lenP, long flags, long curGraphPar, Boolean searchPar);
XErr	GotoWasFound(long api_data, Ptr *oldFilePPtr, long *lenP, Ptr startP, long startLen, long curGraphs, long flags, long saveLine, Boolean fromMain);
#endif
