/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Compiler.h,v 1.4 2008-12-02 11:08:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __BIFERNO_COMPILER__
	#define __BIFERNO_COMPILER__

#include "Variable.h"

// Extended opcodes have 10 for immediate
#define	BIC_MAX_SPACE_FOR_IMMEDIATE	10

// #define	NO_LOAD_OPCODE_BUFFER	0
/*
Al Compile time questo numero viene messo nella prima
short del type dell'ObjRef (quindi il BIC ObjRef contiene lo spec
nella prima short del type)
*/
enum {
		kCL_LIST = 1,
		kImmediateValue,
		kVL_LIST
		};

/*
Al Run time invece le costanti nelle variant sono:
*/
enum {
		kVariant2BytesInt = 7,	// last immediate class (kIntClassID=6) + 1
		kVariantCL_LIST,
		kVariantVL_LIST,
		kVariantNumber,
		kVariantSL
		};


#define		VARIANT_IS_EXT(pos)					((pos < kVariantCL_LIST) && (pos != kBooleanClassID) && (pos != kVariant2BytesInt))

#define		RESULT_IS_RELEVANT(api_data)		(((BifernoRecP)api_data)->bicRecord.resultRelevant)
#define		SMART_STORE_DISABLED(bicRecP)		(bicRecP->smartStoreDisabled)

// Check this to see the type of BIC object (kCL_LIST, kImmediateValue, kVL_LIST)
#define		BIC_OBJREF_SPEC(objP)		(*(short*)&OBJ_TYPE_P(objP))

// here put the immediate value ina BIC object
#define		BIC_IMM_P(objP)				((Ptr)&OBJ_TYPE_P(objP) + 2)
#define		BIC_IMMLEN_STRLEN_P(objP)	(*(Byte*)BIC_IMM_P(objP))

// Is the BIC object immediate
#define		BIC_IS_IMM(objRecP)			(BIC_OBJREF_SPEC(objRecP) != kVL_LIST)


/*
classID		->		classID of immediate or kVL_LIST, kLL_List id
id			->		VL: id in VL (SP = on stack)
					LL: id in LL (classid is in type)
					immediate: always IMMEDIATE_ID
type		->		(as short) kVL_LIST, kLL_List, kNumber etc..
*/

#define	COMP(api_data)	(&((BifernoRecP)api_data)->bicRecord)

// Static list of function static methods etc...
//#define	MAX_PARAMETERS		512

#define	INVALID_ABSOLUTE_BR_OFFSET		-1

#define	SP								-1

#define	PARAMS_INFO_FREE_FOR_RUNTIME	4
typedef struct {
				Boolean			paramHasName;
				Boolean			paramForAddress;
				short			paramPos;
				long			clID;		// needed at runtime if NOT_RESOLVED (DL)
				} ParamInfo;

// E' a lunghezza variabile (vedi campo offset in slRec)				
enum {
	kLocalFunc = 1,
	kAppFunc
};

/*typedef struct {
	CStr63			membName;
	long			pluginID;	// 0 for funcs, !=0 for methods/props
	long			membID;		// member id in class
	long			dim;		// for func/method is totParams, for property dim af array
	Boolean			isProperty;
	Boolean			isStatic;
	Boolean			forAddress;
	Byte			NOT_RESOLVED;
	ObjRecord	objRef;		// on runtime compare objRef.classID with incoming objRef to see if re-resolve is needed
} SL_SlotHead;*/

typedef struct {
	/*SL_SlotHead		head;					// for method/function/property
	 Boolean			noParamHasName;			// only for method/function
	 Boolean			noDirectNames;			// only for method/function
	 Boolean			dontCheckNames;			// only for method/function
	 Boolean			dontCheckNumParams;		// only for method/function
	 ParamInfo		paramInfo[1];			// only for method/function*/
	ObjRecord	objRef;
	BAPI_Doc	doc;
} SL_Slot, *SL_SlotP;

typedef struct {
				long		totSlots;
				BlockRef	offsets;
				BlockRef	block;
				long		blockSize;
				} SL_Record, *SL_RecordP;

// Goto - label
typedef struct {
				long		opcodeOffset;
				long		gotoLine;
				} GotoRec, *GotoRecP;

typedef struct {
				CStr63		labelName;
				Boolean		offsetIsValid;
				Byte		pad;
				short		pad2;
				long		branchOffset;
				long		totGotos;
				BlockRef	gotoBlock;
				} LabelRec, *LabelRecP;

typedef struct {
	CStr63		name;
	ObjRecord	objRef;
	/*
	 Boolean		resolved;
	 short		unused;
	 */
} VL_Slot, *VL_SlotP;

typedef struct {
				long		totSlots;
				BlockRef	block;
				} VL_Record, *VL_RecordP;

typedef struct {
				Byte		countStack;
				Byte		incr_stack;
				Byte		decr_stack;
				Byte		unused;
				long		opOffset;
				} OpStackInfo, *OpStackInfoP;

typedef struct {
				ObjRef		objRef;
				long		type;
				} IncrRecord;

// compilation header output
typedef struct {
				long		stack;
				long		totOpcodes;
				long		opcodesOffset;
				long		vlTotal;
				long		vlOffset;
				long		slTotal;
				long		slOffset;
				long		slOffsetsOffset;
				DLMRef		cl;
				} BICHeader;

typedef struct {
	// compile output
	long		stack;
	long		totOpcodes;
	BufferID	opcodesBufferID;
	VL_Record	vl;
	VL_Record	gl;		// global
	SL_Record	sl;
	DLMRef		cl;
	
	// used during the compilation
	long		actStack;
	long		opcodesStack;
	long		lastOpcodeSize;
	Byte		lastOpcode;
	Byte		lastOpVariant;
	Boolean		resultRelevant;
	Boolean		loadingOnStack;
	Boolean		smartStoreDisabled;
	Boolean		disposed;
	short		pad2;
	long		totLabels;
	BlockRef	labelsBlock;
	long		classOfParamDefault;
	long		totNops;
	long		totBrs;
} BICRecord, *BICRecordP;

XErr	BIC_Init(long api_data);
XErr	BIC_PostProcess(long api_data);
XErr	BIC_End(long api_data);
XErr	BIC_Output(long api_data, BlockRef *resultTextP, long *resultSizeP);

//XErr	BIC_SaveLastOpcode(long api_data, long loadOpcodeBuffer, Boolean lastWasName);

Boolean	BIC_IsLiteral(ObjRecordP objRefP);
void	BIC_GetRealObjRef(BICRecordP bicRecP, ObjRecordP objRecP, ObjRecordP resultP);
XErr	BIC_GetBicObjRef(long api_data, ObjRecordP objRecP, ObjRecordP resultP);

XErr	BIC_TypeCast(long api_data, ObjRecordP source, long requestedClassID, ObjRecordP dest);
XErr	BIC_Index(long api_data, ObjRecordP arrayObjrecP, ArrayIndexRec *mCoords, long dim, ObjRecordP resultP);
XErr	BIC_IdentifyObject(long api_data, char *varName, Ptr textP, long len, long theScope, Boolean *isFunctionP, ObjRecord *objRefP);
XErr	BIC_DoAssignment(long api_data, ObjRecordP objLeftP, char *varName, long assignmentType, ArrayIndexRec *mCoords, long mCoordDim, BlockRef propListBlock, ObjRecordP objRightP);
XErr	BIC_Opposite(long api_data, ObjRecordP objP, ObjRecordP resultP);
XErr	BIC_DoIncrement(long api_data, ObjRecordP objRefP, ArrayIndexRec *mCoords, long mCoordDim, BlockRef propListBlock, long incrType);
XErr	BIC_LiteralStringToObjRef(long api_data, char *saveStrP, long strLen, ObjRecordP resultObj);
Boolean	BIC_LiteralNumToObjRef(long api_data, long classID, StringPtr strP, ObjRecordP resultObj, XErr *errP);
void	BIC_LiteralBoolToObjRef(long api_data, Boolean value, ObjRecordP resultObj);
XErr	BIC_Ternary(long api_data, ObjRecord *obj1, ObjRecord *obj2, ObjRecord *obj3, ObjRecord *resultObj);
XErr	BIC_ExecuteOperation(long api_data, ObjRecordP item1, ObjRecordP item2, long operation, ObjRecordP resultP);
XErr	BIC_FlowControl(long api_data, long which, ObjRecordP param1);
XErr	BIC_StandardOutput(long api_data, char *textP, long len);
XErr	BIC_Branch(long api_data, Boolean notMode, Boolean absolute, ObjRecord *objRefP, long absoluteOffset, long *opcodeOffsetP, Boolean isBnse);
XErr	BIC_BranchUpdateOffset(long api_data, long opcodeOffset, long absoluteBranchOffset);
XErr	BIC_GetOffset(long api_data, long *offsetP);
XErr	BIC_LoadParam(long api_data, ObjRecordP objToLoad);
XErr	BIC_Print(long api_data, ObjRecordP objToPrint);

XErr	BIC_CallFunction(long api_data, MemberAction *membActionP, char *functionName, ParameterRec *paramVarsP, long totParams, ObjRecordP resultP, Boolean fromConstructor);

//XErr	FlushPostIncr(BICRecordP bicRecP);

XErr	BIC_GetProperty(long api_data, MemberAction *membIdentP, long propertyDim, ArrayIndexRec *propertyIndex, long assignmentType, ObjRecordP resultVarRecP, Boolean compilerAnyway);
XErr	BIC_SetProperty(long api_data, MemberAction *membIdentP, ArrayIndexRec *propertyIndex, long propertyDim, ObjRecordP value, Boolean putResultOnStack);

XErr	BIC_AddLabel(long api_data, char *labelName);
XErr	BIC_AddGoto(long api_data, char *labelName);
#endif
