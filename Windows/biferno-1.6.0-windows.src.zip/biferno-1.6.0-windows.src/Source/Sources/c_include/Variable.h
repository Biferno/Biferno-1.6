/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Variable.h,v 1.15 2008-03-11 14:21:39 tabasoft Exp $
	|______________________________________________________________________________
*/
#ifndef __VARIABLEH__
	#define __VARIABLEH__

#define	MAX_SUPERISCHANGED_NOTIFIES		12

typedef struct {
				ObjRecord		objRef;		// act on this objRef (invalid if function or static member)
				long			id;			// id of the BAPI_Doc in its list 
				long			slot;		// slot id of pool for this MemberAction (-1 = real block, no pool)
				BAPI_Doc		doc;		// this is variable length for methods and function, fixed for properties
				} MemberAction;
				
typedef struct {
				
				long		tot;
				long		slot;
				//BlockRef	block;
				Boolean		toNotify;
				Byte		pad1;
				short		pad2;
				CStr63		propertyName[MAX_SUPERISCHANGED_NOTIFIES];
				ObjRecord	objRef[MAX_SUPERISCHANGED_NOTIFIES];
				} SuperIsChangedNotify;

#define	POOL_PROPERTY_ACTION_SIZE	(sizeof(MemberAction) - sizeof(BAPI_ParameterDoc))

// ************** da levare ************ 
/*typedef struct {
				CStr63		memberName;			// name of the member
				long		memberType;			// kMethod, kProperty or kConstant,
				long		memberClassID;		// class of the member
				long		memberPluginID;		// the class owning the member
				long		memberObjID;		// the id of member in class list				(Biferno classe: < 0 is static properties)
				long		memberValue;		// for C classes: the value id of the members.	for Biferno classes: == memberObjID
				ObjRecord	memberObjRef;		// objRef on which apply member
				long		memberArrayElementClassID;
				Byte		memberArrayLevel;
				Boolean		memberIsStatic;
				Boolean		memberIsConstant;
				Byte		memberVisibility;
				Boolean		memberIsError;
				Boolean		notResolved;		// for compiler
				short		pad2;
				} MemberIdentification;*/

typedef struct {
				// MemberIdentification	membIdent;
				MemberAction			membIdent;
				long					propertyDim;
				BlockRef				propertyIDXBlockRef;
				ArrayIndexRec			*propertyIDXPtr;
				} PropertyItem;

typedef struct {
				long					totItems;
				PropertyItem			item[1];
				} PropertyListRec;

// ************** da levare ************ 
/*typedef struct {
				long		value;
				long		classID;
				short		type;				// method, property or constant
				Byte		returnAeLevel;		// how many [][][]... (max 255)
				Boolean		isStatic;
				Boolean		isConstant;
				Boolean		dontCheckNumParams;	// if prototype ens with ...
				Boolean		isError;
				Boolean		dontCheckNames;
				long		returnAeClassID;
				} MemberHeader;

// ************** da levare ************ 
typedef struct {
				CStr63			name;
				CStr63			defaultStr;
				long			classID;
				long			arraylevel;
				long			arrayElementClassID;
				Boolean			forAddress;
				Byte			pad;
				short			pad1;
				} ProtoParam;

// ************** da levare ************ 
typedef struct {
				MemberHeader	memberHeader;
				CStr255			prototype;
				long			returnClassID;
				long			totParams;
				DLMRef			protoParamList;
				long			protoParamObjID;	// in list gsDispatcherData.prototypes
				long			errorValue;
				} MemberRecord;
*/
// built-in properties
enum{
		TYPE = 1,
		SCOPE,
		CLASS
	};

enum{
		ASSIGN = 1,					// =
		ADDASSIGN,					// +=
		SUBASSIGN,					// -=
		MULTASSIGN,					// *=
		DIVASSIGN					// /=
		};

#ifdef __LITTLE_ENDIAN__
	#define	PLUS_EQUAL		'=+'
	#define	LESS_EQUAL		'=-'
	#define	MULT_EQUAL		'=*'
	#define	DIV_EQUAL		'=/'
#else
	#define	PLUS_EQUAL		'+='
	#define	LESS_EQUAL		'-='
	#define	MULT_EQUAL		'*='
	#define	DIV_EQUAL		'/='
#endif

enum{
		kNullIncr = 0,
		kPreIncrem,
		kPreDecrem,
		kPostIncrem,
		kPostDecrem
	};

/*typedef struct {
				long 	api_data;
				//DLMRef	newList;
				} CloneObjectRec;
*/
typedef struct {
				unsigned short 	arrayFlags;				// DLM flags
				DLMRef			arrayDLRef;			// DLM list of array
				long			arrayDim;			// tot elements
				long			arrayElemAeLevel;	// if is multidimensional this is > 0
				long			arrayElemClassID;	// class id of elements. If multidimensional classID of Last dimension
				} ArraySpecs;

XErr	GetVariableList(long api_data, long scope, DLMRef *listIDP, Boolean noError, int stackIndex);
XErr	EvalVariable(long api_data, Ptr *lineTextP, long *lineLenP, long typeCastType, ObjRecordP rightValue, Boolean pre_incr, Boolean pre_decr, long *numParP, ObjRecordP resultVarP, char *varName, Boolean *noPostIncrP, long flags, Boolean ternaryPending, BlockRef *propBlockP/*, Boolean *setErrMsgP*/);
XErr	GetMemberInfo(long api_data, char *memberName, long classID, ObjRecord *objRefP, BlockRef *membIdentBlockP, MemberAction **membActionP, int followChar, Boolean *memberExistsP, Boolean fromTryCurrent, SuperIsChangedNotify **notifyP, Boolean getInfo, Boolean gettingReference);

XErr	ResolveArryItem(long api_data, Ptr *textPPtr, long *lenP, ObjRecordP leftObjVarP, ArrayIndexRec *mCoordsP, long *dimP, Boolean fromInput, BlockRef *mCoordsBlockP, long *arrayElemReqClassIDP);
long	LookForObj(long api_data, char *varName, long *varListP, long *varTypeP, long *classIDP, long *scopeP, XErr *errP);
void	GetDocUrl(long api_data, char *docUrl);
XErr	FillVariableHTMLTable(long api_data, long list, long scope, char *scopeName, long replyID, int encodeMode, char *docUrl);

XErr	GetHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, char *filePath, long lastClassErrCalled, char *class_error_note, int encodeMode, char *ip, Boolean superuser);
XErr	GetUserHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, long lastClassErrCalled, char *error_code, char *host, char *appName);

XErr	CloneObject(long api_data, ObjRecord *sourceObjVarP, char *name, DLMRef list, long theScope, long requestedClassID, long arrayElemRequestedClassID, Boolean wantConst, Boolean wantFixed, long *destIDP, ArraySpecs *arSpecP, Boolean cloneTarget);
XErr	GetFinalObjFlag(long api_data, ObjRecordP objRef, Boolean wantConst, Boolean wantFixed, unsigned short *flagsP);
//XErr	CopyObject(long api_data, ObjRecordP sourceObjVar, char *varName, long scope, long type, ObjRecordP destObjVar, Boolean exists, BlockRef mCoordBlock, long mCoordDim);
XErr	ModifyVariable(long api_data, ObjRecordP varToSet, ObjRecordP value, long typeCastType, Boolean ignoreIfConstant, BAPI_ModifyHook _modCB);

XErr	GetScopeAndType(long api_data, Ptr *oldFilePPtr, long *lenP, DLMRef *varListP, long *typeP, long *scopeP, char *theName);

XErr	NewLiteralInList(char *name, DLMRef list, ObjRecord *literalObjRefP, long finalFlags, long *destObjIDP, long atPos);
XErr	AddLiteralToObj(ObjRecord *objRef, ObjRecord *literalP);
void	LiteralToDLMBuffer(ObjRecord *literalObjRefP, DLMBuffer *dlmBufferP);
//XErr	ModifyImmediate(long api_data, ObjRecord *literalObjRefP, ObjRecordP objRecP);

XErr	IsToDestruct(ObjRecord *objRefP, Boolean *toDestructP);
XErr	VariableDestructor(DLMRef dlRef, long objID, unsigned short flags, long classID, long api_data);
XErr	VariableDestructorExt(DLMRef dlRef, long objID, unsigned short flags, long classID, long api_data);
//XErr	GetProtoBlock(long api_data, long classID, long funcObjID, Boolean isBiferno, BlockRef *blockRefP, ProtoParam **tProtoParamP, long *totParamsP, char *prototype, Boolean *dontCheckNumParamsP, Boolean *dontCheckNamesP, Boolean fromConstructor, long *returnClassIDP, Boolean *visibilityP, Boolean *isStaticP);

XErr	ResolveArrayElement(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, short *lastResolvedP, Boolean *expandedP, ObjRef *elemToAdd, ObjRefP resultObjRef, long *arrayElementClassIDP);

typedef struct {
				ObjRecord	arrObjRef;
				long		reqElementClassID;
				long		reqElement_Ae_ClassID;
				long		reqElement_Ae_Level;
				DLMRef		arrayDLRef;
				long		arrayDim;
				Boolean		isArrayFixed;
				Boolean		isArrayConstant;
				short		pad2;
				} CloneArrayRecord;
				
XErr	GetArraySpecs(long api_data, ObjRecord *arrayObjP, ArraySpecs *specP);

XErr	AddElementToArray(long api_data, char *name, ObjRefP objRefP, long param);
XErr	CloneArray(long api_data, ObjRecord *source, DLMRef list, ObjRecord *dest, char *destName, long requestedElementClass, Boolean wantConst, Boolean wantFixed);

XErr	CClassHasMember(long api_data, char *memberName, long classID, ObjRecord *objRefP, BlockRef *membIdentBlockP, MemberAction **membActionP, int followChar, Boolean *memberExistsP, Boolean fromTryCurrent, SuperIsChangedNotify **notifyP, Boolean getInfo, Boolean gettingReference);

void	DisposePropListRec(BlockRef *propBlockP);
XErr	NotifySuperIsChanged(long api_data, SuperIsChangedNotify *notifyP);
XErr	FillNotifyItem(ObjRecord *objRefP, char *propName, SuperIsChangedNotify **notifyP, long visibility);

XErr	AvoidCriticalDestruct(long api_data, long theClassId, long theScope);

typedef struct {
	BlockRef 					*propListBlockP;
	ObjRecord 					*leftObjVarP;
	char 						*varName;
	long 						*incrTypeP;
	long 						*assignmentTypeP;
	ObjRecord 					*rightValue;
	long 						*numParP;
	long						flags;
	ObjRecord 					*result;
	BlockRef					mCoordBlock;
	Boolean 					isFunction;
	Boolean 					staticProperty;
	Boolean						sideEffectIfAssign;
	Byte						mCoordDim;
	Boolean 					*appearsOneMethodP;
	SuperIsChangedNotify 		**notifyP;
	} ProcessObjectCallRecord;
//XErr	ProcessObject(long api_data, Ptr *oldFilePtrP, long *oldFileLenP, ProcessObjectCallRecord *processObjectP, long typeCastType, Boolean entityWasFound, Boolean gettingReference);

typedef struct {
	ObjRecordP 				varRecP; 
	long 					*incrTypeP;
	long					*assignmentTypeP;
	Boolean 				*appearsOneMethodP;
	BlockRef 				*propListBlockP;
	CStr63 					memberName;
	Boolean 				isFunction; 
	Boolean 				dontCheckPeriod;
	short					pad;
	long					flags;
	SuperIsChangedNotify 	**notifyP;
	} MemberLoopCallRecord;
XErr	MemberLoop(long api_data, Ptr *oldFilePtrP, long *oldFileLenP, MemberLoopCallRecord *memberLoopP, Boolean fromTryCurrent, long *totLoopsP, Boolean gettingReference);

Boolean SameObj(DLMRef list1, long id1, DLMRef list2, long id2);
XErr 	DoConstructor(long api_data, long constructor, Ptr *oldFilePPtr, long *lenP, Boolean pre_incr, Boolean pre_decr, ObjRecordP result, long *numParP, Boolean isSuper, ObjRecordP rightValue, long flags, Boolean gettingReference, BlockRef *setPropBlockP);
XErr	StringToConstObj(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP);
XErr	UndefVariable(long api_data, ObjRef *varObjRefP, Boolean checkForVolatile);
XErr	LoadVariablesErrorTable(long api_data, long encodeMode, BlockRef *resultBlockP, long *resultBlockLenP);
XErr	CoercionToRequestedType(long api_data, ObjRecordP elem, /*long *operationP, */long requestedType, ObjRecordP newElem, long typeCastType);
#endif
