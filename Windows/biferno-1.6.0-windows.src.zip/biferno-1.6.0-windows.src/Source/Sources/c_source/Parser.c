/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Parser.c,v 1.52 2008-07-21 10:17:46 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"

#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Param.h"
#include "BfrParser.h"
#include "Volatile.h"
#include "BifernoErrors.h"
#include "Reference.h"
#include "Classes.h"
#include "Entity.h"

#if __UNIX_XLIB__
	#include <errno.h>
#endif

static const Byte	gChTypes[256] = {
//		0		1		2		3		4		5		6		7		8		9		A		B		C		D		E		F
/* 0 */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	kTab,	kLF,	stdCh,	stdCh,	kCR,	stdCh,	stdCh,
/* 1 */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* 2 */	kSpace,	kOp,	kDQuote,stdCh,	kDllr,	kOp,	kAnd,	kQuote,	kOBrk,	kCBrk,	kStar,	kOp,	kComm,	kOp,	kDecSep,kSlash,
/* 3 */	kNum,	kNum,	kNum,	kNum,	kNum,	kNum,	kNum,	kNum,	kNum,	kNum,	kSmcln,	kSmcmm,	kLess,	kOp,	kOp,	kQMrk,
/* 4 */	stdCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kOp,	kAcCh,
/* 5 */	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	stdCh,	kBSlash,stdCh,	stdCh,	kAcCh,
/* 6 */	stdCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kOp,	kAcCh,
/* 7 */	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kAcCh,	kOCurly,kOp,	kCCurly,stdCh,	stdCh,
/* 8 */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* 9 */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* A */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* B */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* C */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* D */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* E */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
/* F */	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,	stdCh,
};

static int	gsPriority[] = {
			-1,	//	0 (no noper)
			0,	//	EVAL_MULT
			0,	//	EVAL_DIV
			0,	//	EVAL_MOD
			1,	//	EVAL_ADD
			1,	//	EVAL_MINUS
			2,	//	EVAL_SHIFTR,				// -						2
			2,	//	EVAL_SHIFTL,				// -						2
			3,	//	EVAL_GTH
			3,	//	EVAL_LTH
			3,	//	EVAL_GEQ
			3,	//	EVAL_LEQ
			4,	//	EVAL_EQUA
			4,	//	EVAL_NEQUA
			5,	//	EVAL_ARAND
			6,	//	EVAL_AROR
			7,	//	EVAL_LOGIC_AND
			8	//	EVAL_LOGIC_OR
			/*9,	//	EVAL_TERNARY_QUESTIONMARK,
			9	//	EVAL_TERNARY_SEMICOLON*/
			};

#define		kToAdvance			1
#define		kFinished			2
#define		kFirstItem			4
#define		kNotMode			8
#define		kMinusMode			16

#define		OPERATOR_EXPECTED	1
#define		VARIABLE_EXPECTED	2
#define		TOT_OP				3

#define		MINIMAL_STACK		(1024L * 18L)


enum {
		kDoTypeCast = 1,
		kDoMinus,
		kDoNot
		};
		

extern 	DispatcherData					gsDispatcherData;
extern	Ref_NewReferenceCallBack		ref_NewReference;

typedef struct {
				long 	api_data;
				Ptr 	textP;
				long 	len;
				long 	flags;
				} _ProcessBlock_Params;

//===========================================================================================
// currentLen is the number of chars yet to be processed
long	BfrGetOffset(BifernoRecP bRecP, long currentLen)
{
long		res;
XErr		err = noErr;

	if (bRecP->currentCtx.methodInExecutionID && (bRecP->currentCtx.processing == kProcessingFunction))
	{	if (bRecP->currentCtx.curMethodList)
		{
		BlockRef	bisFunctionBl;
		Ptr			p;
		BAPI_Doc	*docP;
			
			bisFunctionBl = 0;
			if (bRecP->currentCtx.methodInExecutionID == kConstrID)
			{	if NOT(err = GetContructorDoc((long)bRecP, bRecP->methodInExecutionClass, &docP))
					p = (Ptr)docP;
			}
			else
			{	if NOT(err = GetBifernoFunctionRec(bRecP->currentCtx.curMethodList, bRecP->currentCtx.methodInExecutionID, &p, &bisFunctionBl, nil))
					docP = (BAPI_Doc*)GetPtr(bisFunctionBl);
			}
			if NOT(err)
			{	res = docP->ident.b.fileOffset + docP->ident.b.funcLength - currentLen;
				if (bisFunctionBl)
					DisposeBlock(&bisFunctionBl);
			}
		}
		else
			CDebugStr("??");
	}
	else
		res = bRecP->curFile.fileSize - currentLen;

return res + 1;
}

//===========================================================================================
XErr AddXLineOfFile(Ptr textP, long fileSize, long the_line, long buffer_id, int encodeMode, int startLine)
{
long		save_fileSize, line;
Ptr 		saveP;
int			i;
XErr		err = noErr;
Boolean		found;

	if (the_line)
	{	save_fileSize = fileSize;
		line = startLine;
		found = false;
		while (fileSize > 0)
		{	if (IsNewLineExt(&textP, &fileSize, nil))
				++line;
			else if (line == the_line)
			{	i = 1;
				saveP = textP;
				while (NOT(IsNewLineExt(&textP, &fileSize, nil)) && (i < 245) && fileSize)
				{	textP++;
					fileSize--;
				}
				found = true;
				break;
			}
			else
			{	textP++;
				fileSize--;
			}
		}
		if (found)
			err = BufferAddText(buffer_id, saveP, textP - saveP, encodeMode, kTagsVisible);		
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
int 	RemoveEndChar(Ptr *oldFilePPtr, long *lenP, long flags, long *curLineP, Boolean advance)
{
Byte	lastChar = 0;
Ptr		tempP;
long	len;
Byte	ch;

	tempP = *oldFilePPtr;
	len = *lenP;
	if (len)
	{	ch = *tempP;
		if ((flags & kStopOnCR) && IsNewLineExt(&tempP, &len, curLineP))
			;
		else if (((flags & kStopOnDollar) && (ch == '$')) ||
				((flags & kStopOnComma) && (ch == ',')) ||
				((flags & kStopOnSemicolon) && (ch == ':')) ||
				(ch == ';') ||
				(ch == ')'))
		{	lastChar = ch;
			if (advance)
			{	tempP++;
				len--;
			}
		}
	}
		
*oldFilePPtr = tempP;
*lenP = len;
return lastChar;
}

//===========================================================================================
Boolean IsNot(Ptr textP, long len)
{
	if ((len > 2) && (((*(short*)textP == NOT_STR1) && (*(textP + 2) == 'T')) || ((*(short*)textP == not_STR1) && (*(textP + 2) == 't'))))
	{	int		ch;
	
		if (len > 3)
		{	ch = *(textP+3);
			if ((ch == '(') || (ch == '\t') || (ch == ' '))
				return true;
			else
				return false;
		}
		else
			return false;
	}
	else
		return false;
}

//===========================================================================================
void		SkipSmart(BifernoRecP bRecP, Ptr *oldFilePPtr, long *lenP)
{
Ptr			tempP;
long		len;

	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
	while (IsCommentExt(bRecP, &tempP, &len, nil, nil, true))
	{
		SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
	}
	
*oldFilePPtr = tempP;
*lenP = len;
}

//===========================================================================================
Boolean IsCommentExt(BifernoRecP bRecP, Ptr *thePPtr, long *lenP, Boolean *newLineP, Boolean *bilateralP, Boolean noNewLine)
{
Ptr		theP = *thePPtr;
long	len = *lenP, *lineP;
Boolean	res;

	if (newLineP)
		*newLineP = false;
	if (bilateralP)
		*bilateralP = false;
	if ((len > 1) && (*(short*)theP == '//'))
	{	len -= 2;
		theP += 2;
		if (bRecP)
			lineP = &bRecP->currentCtx.currentLine;
		else
			lineP = nil;
		if (noNewLine)
		{	while (len > 0)
			{	if (IsNewLine(theP, len, nil))
				{	if (newLineP)
						*newLineP = true;
					break;
				}
				theP++;
				len--;
			};
		}
		else 
		{	while (len > 0)
			{	if (IsNewLineExt(&theP, &len, lineP))
				{	if (newLineP)
						*newLineP = true;
					break;
				}
				theP++;
				len--;
			};
		}
		res = true;
	}
	else if ((len > 1) && (*(short*)theP == INIT_COMMENT))
	{	len -= 2;
		theP += 2;
		if (bRecP)
			lineP = &bRecP->currentCtx.currentLine;
		else
			lineP = nil;
		while ((len > 0) && ((len < 2) || NOT(*(short*)theP == END_COMMENT)))
		{	if NOT(IsNewLineExt(&theP, &len, lineP))
			{	theP++;
				len--;
			}
		};
		if ((len > 1) && (*(short*)theP == END_COMMENT))
		{	len -= 2;
			theP += 2;
		}
		if (bilateralP)
			*bilateralP = true;
		res = true;
	}
	else
		res = false;

	if (res)
	{	
	// Others comment follow?
	Boolean		newLine, bilateral;
	long		saveLine, *lineP, saveLen;
	Ptr			saveP;
	
		saveLen = len;
		saveP = theP;
		if (bRecP)
		{	lineP = &bRecP->currentCtx.currentLine;
			saveLine = *lineP;
		}
		else
			lineP = nil;
		SkipSpaceAndTabCRLF(&theP, &len, lineP);
		if (IsCommentExt(bRecP, &theP, &len, &newLine, &bilateral, noNewLine))
		{	if (newLineP)
				*newLineP = newLine;
			if (bilateralP)
				*bilateralP = bilateral;
		}
		else
		{	theP = saveP;
			len = saveLen;
			if (lineP)
				*lineP = saveLine;
		}
	}
	
*thePPtr = theP;
*lenP = len;
return res;
}

//===========================================================================================
/*
	assumes first char is already checked and is '/'
	
		skipTheNewLine	<-	if true the ending new line (if any) is skipped
		newLineP		->	true if comment finished with new line
		bilateralP		->	true if comment was bilateral
		
	Note:
		IsCommentExt2 is not recursive (as IsCommentExt is, see last part of IsCommentExt)
*/
Boolean IsCommentExt2(BifernoRecP bRecP, Ptr *thePPtr, long *lenP, Boolean *newLineP, Boolean *bilateralP, Boolean preserveTheNewLine)
{
Ptr			theP = *thePPtr;
long		len = *lenP, *lineP;
Boolean		newLine, res;
const Byte	*chTypePtr;

	theP++;
	len--;
	if (bRecP)
		lineP = &bRecP->currentCtx.currentLine;
	else
		lineP = nil;
	if (len && (*theP == '/'))
	{	len--;
		theP++;
		res = true;
		if (bilateralP)
			*bilateralP = false;
		if (len)
		{	chTypePtr = gChTypes;
			do
			{	switch(chTypePtr[*(Byte*)theP])
				{
					case kBSlash:
					case kAnd:
					case kDQuote:
					case kQuote:
					case kSlash:
					case kSmcmm:
					case kCCurly:
					case kOCurly:
					case kComm:
					case kCBrk:
					case kOBrk:
					case kDllr:
						theP++;
						len--;
						break;
					case kCR:
					case kLF:
						if NOT(preserveTheNewLine)
							IsNewLineExt2(&theP, &len, lineP);
						newLine = true;
						goto out;
					case kQMrk:
					case kSmcln:
					case kSpace:
					case kTab:
					case kStar:
					case kLess:
					case kOp:
					case kNum:
					case kDecSep:
					case kAcCh:
					case stdCh:
						theP++;
						len--;
						break;
					default:
						CDebugStr("chtype: should never happen");
				}
			} while (len);
			newLine = false;	// if got here, new line was never encountered
		}
	}
	else if (len && (*theP == '*'))
	{	len--;
		theP++;
		res = true;
		if (bilateralP)
			*bilateralP = true;
		newLine = false;
		if (len)
		{	chTypePtr = gChTypes;
			do
			{	switch(chTypePtr[*(Byte*)theP])
				{
					case kBSlash:
					case kAnd:
					case kDQuote:
					case kQuote:
					case kSlash:
					case kSmcmm:
					case kCCurly:
					case kOCurly:
					case kComm:
					case kCBrk:
					case kOBrk:
					case kDllr:
						theP++;
						len--;
						break;
					case kCR:
					case kLF:
						IsNewLineExt2(&theP, &len, lineP);
						break;
					case kQMrk:
					case kSmcln:
					case kSpace:
					case kTab:
						theP++;
						len--;
						break;
					case kStar:
						theP++;
						len--;
						if (len && (*theP == '/'))
						{	theP++;
							len--;
							goto out;
						}
						break;
					case kLess:
					case kOp:
					case kNum:
					case kDecSep:
					case kAcCh:
					case stdCh:
						theP++;
						len--;
						break;
					default:
						CDebugStr("chtype: should never happen");
				}
			} while (len);
		}
	}
	else
	{	theP--;
		len++;
		res = false;
	}
	
out:	
if (newLineP)
	*newLineP = newLine;
*thePPtr = theP;
*lenP = len;
return res;
}

//===========================================================================================
Boolean IsComment(Ptr theP, long len)
{
Boolean	res;

	if ((len > 1) && (*(short*)theP == '//'))
		res = true;
	else if ((len > 1) && (*(short*)theP == INIT_COMMENT))
		res = true;
	else
		res = false;

return res;
}

//===========================================================================================
/*Boolean	IsInitTag(BifernoRecP bRecP, Ptr theP, long len)
{	
Boolean	res;

	if ((len > 1) && (*(short*)theP == INIT_TAG))
	{	theP += 2;
		len -= 2;
		if (Begins(theP, len, "biferno", 7))
		{	theP += 7;
			len -= 7;
			res = true;
		}
		else if (NOT(len) || (*theP == ' ') || StopEvaluating(theP, len, nil))
			res = true;
		else
			res = false;
		if (bRecP)
			bRecP->currentCtx.inTag = res;
	}
	else
		res = false;

return res;
}*/

//===========================================================================================
Boolean	IsInitTagExt(BifernoRecP bRecP, Ptr *thePPtr, long *lenP)
{	
Ptr		theP = *thePPtr;
long	len = *lenP;
Boolean	res;

	if ((len > 1) && (*(short*)theP == INIT_TAG))
	{	theP += 2;
		len -= 2;
		if (Begins(theP, len, "biferno", 7))
		{	res = true;
			theP += 7;
			len -= 7;
		}
		else if (NOT(len) || (*theP == ' ') || (*theP == '\t') || StopEvaluating(theP, len, nil))
			res = true;
		else
		{	if (bRecP)
				bRecP->inOtherTag++;	// xml, php etc...
			res = false;
		}
		if (bRecP)
			bRecP->currentCtx.inTag = res;
	}
	else
		res = false;

if (res)
{	*thePPtr = theP;
	*lenP = len;
}
return res;
}

//===========================================================================================
Boolean	IsInitTagExt2(BifernoRecP bRecP, Ptr *thePPtr, long *lenP)
{	
Ptr				theP = *thePPtr;
long			len = *lenP;
Boolean			res;
const Byte		*chTypePtr;

	if ((len > 1) && (theP[1] == '?'))
	{	theP += 2;
		len -= 2;
		if (len)
		{	chTypePtr = gChTypes;
			switch(chTypePtr[*(Byte*)theP])
			{
				case kBSlash:
				case kAnd:
				case kDQuote:
				case kQuote:
				case kSlash:
				case kSmcmm:
				case kCCurly:
				case kOCurly:
				case kComm:
				case kCBrk:
				case kOBrk:
				case kDllr:
				case kCR:
				case kLF:
				case kQMrk:
				case kSmcln:				
				case kSpace:
				case kTab:
				case kStar:
				case kLess:
					res = true;
					break;
				case kOp:
					if ((*theP == 'n') ||(*theP == 'N'))
						res = false;
					else
						res = true;
					break;
				case kNum:
				case kDecSep:
					res = true;
					break;
				case kAcCh:
				case stdCh:
				default:
					if (Begins(theP, len, "biferno", 7))
					{	res = true;
						theP += 7;
						len -= 7;
					}
					else
					{	if (bRecP)
							bRecP->inOtherTag++;	// xml, php etc...
						res = false;
					}
					break;
			}
		}
		else
			res = true;
	}
	else
		res = false;
	
if (res)
{	*thePPtr = theP;
	*lenP = len;
	if (bRecP)
		bRecP->currentCtx.inTag = res;
}
return res;
}

//===========================================================================================
Boolean	IsEndTag(Ptr theP, long len)
{	
Boolean	res;

	if ((len > 1) && (*(short*)theP == END_TAG))
	{	res = true;
		/*if (bRecP->currentCtx.inTag)
			bRecP->currentCtx.inTag = false;
		else if (errP)
			*errP = XError(kBAPI_Error, Err_BadSyntax);*/
	}
	else
		res = false;

return res;
}

//===========================================================================================
Boolean	IsEndTagExt(BifernoRecP bRecP, Ptr *thePPtr, long *lenP, XErr *errP)
{	
Ptr		theP = *thePPtr;
long	len = *lenP;
Boolean	res;

	if ((len > 1) && (*(short*)theP == END_TAG))
	{	theP += 2;
		len -= 2;
		res = true;
		if (bRecP)
		{	if (bRecP->currentCtx.inTag)
				bRecP->currentCtx.inTag = false;
			else// if NOT(bRecP->inOtherTag)
			{	if (errP)
					*errP = XError(kBAPI_Error, Err_BadSyntax);
			}
		}
	}
	else
		res = false;

if (res)
{	*thePPtr = theP;
	*lenP = len;
}
return res;
}

//===========================================================================================
Boolean StopEvaluating(Ptr theP, long len, long *advanceP)
{
Boolean	res;

	if (IsNewLine(theP, len, advanceP))
		res = true;
	else if (len && ((*theP == ';') || (*theP == ':') || (*theP == '}') || (*theP == '{') || (*theP == ')') || (*theP == '$')))
	{	if (advanceP)
			*advanceP = 1;
		res = true;
	}
	else if (IsEndTag(theP, len))
	{	if (advanceP)
			*advanceP = 2;
		res = true;
	}
	else if (IsComment(theP, len))
	{	if (advanceP)
			*advanceP = 2;
		res = true;
	}
	else
		res = false;

return res;
}

//===========================================================================================
Boolean	IsConstructor(long api_data, Ptr *oldFilePPtr, long *lenP, char *constrName, Boolean lookForTypeCast, long *constrP, Boolean fromInput, Boolean *isSuperP, XErr *errP)
{
Ptr				tempP;
long			constr, classID, objID, len;
int				i, ch;
PluginRecordP	plugRecP;
Boolean			result, perc = false;
BifernoRecP 	bRecP;
		
	*errP = noErr;
	if NOT(bRecP = (BifernoRecP)api_data)
	{	*errP = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
		return false;
	}
	tempP = *oldFilePPtr;
	len = *lenP;
	
	/*if NOT(*constrName)
	{	if (*errP = GetEntityName(api_data, &tempP, &len, constrName, false))
			goto out;
	}*/
	result = false;
	constr = 0;
	if NOT(*constrName)
	{	i = 0;
		if (len)
		{	ch = *tempP;
			while ( (((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z')) ||
					((ch >= '0') && (ch <= '9'))  || (ch == '_')) && /*len && */(i <= MAX_CLASS_ELEM_LENGTH) )
			{	
				constrName[i++] = ch;
				--len;
				++tempP;
				if (len)
					ch = *tempP;
				else
					break;
			}
			constrName[i] = 0;
		}
		if NOT(i)
			goto out;
		else if (i == MAX_CLASS_ELEM_LENGTH)
			goto out;
	}
	
	if (isSuperP && NOT(CCompareStrings("super", constrName)) && (len && (*tempP == '(')))
	{	if (classID = bRecP->superObjRef.classID)
		{	objID = 1;
			*isSuperP = true;
		}
		else
		{	*errP = XError(kBAPI_Error, Err_NotAnExtendingClass);
			result = true;
		}	
	}
	else
	{	if (isSuperP)
			*isSuperP = false;
		if (objID = -GetUserClassID(bRecP, constrName))
			plugRecP = nil;
		else
		{	if (objID = DLM_GetObjID(gsDispatcherData.classListRef, constrName, nil, &classID))
				plugRecP = GetPluginRecFromClassID(nil, classID);
		}
	}
	if NOT(*errP)
	{	if (objID)
		{	constr = classID;
			if (NOT(plugRecP) || (plugRecP->pluginType == kNewClassPlugin))
			{	SkipSpaceAndTab(&tempP, &len);
				if (lookForTypeCast)
				{	if (len && (*tempP == ')'))
					{	if (plugRecP)
							*constrP = constr;
						else
							*constrP = -objID;
						result = true;
					}
				}
				else
				{	if ((len && (*tempP == '(')) || (*tempP == '.') || (fromInput && (perc = (Begins(tempP, len, "%28", 3)))))
					{	if (plugRecP)
							*constrP = constr;
						else
							*constrP = -objID;
						result = true;
						if (perc)
						{	tempP += 3;
							len -= 3;
						}
						else if (fromInput)
						{	tempP++;
							len--;
						}
					}
				}
			}
		}
		// ex else if (objID = DLM_GetObjID(bRecP->application.classesList, constrName, nil, nil))
		/*else if (objID = -GetUserClassID(bRecP, constrName))
		{	SkipSpaceAndTab(&tempP, &len);
			if (lookForTypeCast)
			{	if (len && (*tempP == ')'))
				{	*constrP = -objID;
					result = true;
				}
			}
			else
			{	if ((len && (*tempP == '(')) || (*tempP == '.') || (fromInput && (perc = (Begins(tempP, len, "%28", 3)))))
				{	*constrP = -objID;
					result = true;
					if (perc)
					{	tempP += 3;
						len -= 3;
					}
					else if (fromInput)
					{	tempP++;
						len--;
					}
				}
			}
		}*/
	}
	
out:
if (result || fromInput)
{	*oldFilePPtr = tempP;
	*lenP = len;
}

return result;
}

//===========================================================================================
//&&, ||, !
//==,!=,>,<,>=,<=
//+, -, *, /, &, |
long	IsEvalOperator(Ptr *oldPtrPPtr, long *lenP, Boolean toAdvance, long nextExpected, long *advancePtr)
{	
long	res = 0, advance = 0, len = *lenP;
Ptr		p = *oldPtrPPtr;

	// if ((len > 2) && (*(short*)p == NOT_STR1) && (*(p + 2) == 'T'))
	if (IsNot(p, len))
	{	advance = 3;
		res = _NOT;
		goto out;
	}
	
	if (len > 1)
	{	switch(*(short*)p)
		{	case '&&':
				advance = 2;
				res = EVAL_LOGIC_AND;
				goto out;		
			case '||':
				advance = 2;
				res = EVAL_LOGIC_OR;
				goto out;
			case '==':
				advance = 2;
				res = EVAL_EQUA;
				goto out;		
			case EVAL_NEQUA_STR:
				advance = 2;
				res = EVAL_NEQUA;
				goto out;
			case EVAL_GEQ_STR:
				advance = 2;
				res = EVAL_GEQ;
				goto out;
			case EVAL_LEQ_STR:
				advance = 2;
				res = EVAL_LEQ;
				goto out;
			case '>>':
				advance = 2;
				res = EVAL_SHIFTR;
				goto out;
			case '<<':
				advance = 2;
				res = EVAL_SHIFTL;
				goto out;
		}
	}
	if (len)
	{	switch(*p)
		{	case '!':
				advance = 1;
				res = _NOT;
				goto out;
			case '>':
				advance = 1;
				res = EVAL_GTH;
				goto out;
			case '<':
				advance = 1;
				res = EVAL_LTH;
				goto out;
			case '+':
				advance = 1;
				res = EVAL_ADD;
				goto out;
			case '-':
				advance = 1;
				res = EVAL_MINUS;
				goto out;
			case '*':
				advance = 1;
				res = EVAL_MULT;
				goto out;
			case '/':
				advance = 1;
				res = EVAL_DIV;
				goto out;
			case '%':
				advance = 1;
				res = EVAL_MOD;
				goto out;
			case '&':
				switch(nextExpected)
				{	case 0:
						break;
					case OPERATOR_EXPECTED:
						advance = 1;
						res = EVAL_ARAND;
						break;
					case VARIABLE_EXPECTED:
						break;
					default:
						advance = 1;
						res = EVAL_ARAND;
						break;
				}
				goto out;
			case '|':
				advance = 1;
				res = EVAL_AROR;
				goto out;
		}
	}
	
out:
if (toAdvance)
{	(*oldPtrPPtr) += advance;
	(*lenP) -= advance;
}
if (advancePtr)
	*advancePtr = advance;
return res;
}

//===========================================================================================
Boolean IsFlowControlExt(long api_data, Ptr *oldFilePPtr, long *lenP, long *fcIDP, long *entityLengthP)
{
char		fcName[MAX_VARIABLE_NAME_LENGTH];
Boolean		res;
Ptr			tempP;
long		len;

	//totRecMsg = GetTotMsgRecords(api_data);
	tempP = *oldFilePPtr;
	len = *lenP;
	if NOT(GetEntityName(api_data, &tempP, &len, fcName, false))
		res = IsFlowControl(api_data, fcName, &tempP, &len, fcIDP, entityLengthP, nil);
	else
	{	//SetTotMsgRecords(api_data, totRecMsg);
		if (entityLengthP)
			*entityLengthP = 0;
		res = false;
	}

if (res)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return res;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
static XErr	_DoEntity(long api_data, Ptr *expressPPtr, long *expressLenP, EvalObjRef *operP, 
							long index, long *numParP, Boolean pre_incr, Boolean pre_decr, char *varName, long flags, Boolean ternaryPending, Boolean getReference/*, Boolean *setErrMsgP*/)
{
XErr			err = noErr;
Ptr				expressP;
long			expressLen;
Boolean			noPostIncr = false;
ObjRecord		*objP, tempObjRef;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
BlockRef 		*propP, propBlock;

	expressP = *expressPPtr;
	expressLen = *expressLenP;
	propBlock = 0;
	if (getReference)
	{	objP = &tempObjRef;
		propP = &propBlock;
		expressP++;		// skip '&'
		expressLen--;
	}
	else
	{	objP = &operP[index].objRef;
		propP = nil;
	}
	if NOT(err = EvalVariable(api_data, &expressP, &expressLen, kImplicitTypeCast, nil, pre_incr, pre_decr, numParP, objP, varName, &noPostIncr, flags, ternaryPending, propP/*, setErrMsgP*/))
	{	if (objP->id)
		{	if (expressLen > 1)
			{	if ((*(short*)expressP == '++') || (*(short*)expressP == '--'))
				{	if (noPostIncr)
						err = XError(kBAPI_Error, Err_BadSyntax);
					else
					{	expressP += sizeof(short);
						expressLen -= sizeof(short);
					}
				}
			}
			if (getReference)
				err = ref_NewReference(api_data, (ObjRefP)objP, propBlock, (ObjRefP)&operP[index].objRef);
		}
		else if (NOT(bRecP->currentCtx._stop) && NOT(bRecP->_exit))
		{	SkipSpaceAndTab(&expressP, &expressLen);
			if (getReference || (expressLen && NOT(StopEvaluating(expressP, expressLen, nil))))
				err = XError(kBAPI_Error, Err_BadSyntax);
		}
	}
	if (err && propBlock)
		DisposePropListRec(&propBlock);
	
// Important Note: Caller expect update of expressPPtr and expressLenP also if there was an error
// because the varName is loaded from code
*expressPPtr = expressP;
*expressLenP = expressLen;
return err;
}			
			
//===========================================================================================
static XErr	_DoOpenPar(long api_data, Ptr *expressPPtr, long *expressLenP, EvalObjRef *operP, 
						long *indexP, long *numParP, long *evalFlagsP, long *typeCastExplicityP)
{
XErr			err = noErr;
CStr63			constrName;
Ptr				expressP;
long			typCastType, expressLen, index = *indexP;
Boolean			isConstr;//, isTrue;
BifernoRecP		bRecP = (BifernoRecP)api_data;

	expressP = *expressPPtr;
	expressLen = *expressLenP;
	
	expressP++;
	expressLen--;
	(*numParP)++;
	*constrName = 0;
	isConstr = IsConstructor(api_data, &expressP, &expressLen, constrName, true, typeCastExplicityP, false, nil, &err);
	if (err)
		return err;
	if (isConstr)
	{	(*evalFlagsP) &= (0xFFFFFFFF ^ kToAdvance);		// off the bit
		SkipSpaceAndTab(&expressP, &expressLen);
	}
	else
	{	SkipSpaceAndTabCRLF(&expressP, &expressLen, &bRecP->currentCtx.currentLine);
		if (expressLen && (*expressP == ')'))
			err = XError(kBAPI_Error, Err_EmptyExpression);
		else
		{	if (*typeCastExplicityP)
				typCastType = kExplicitTypeCast;
			else
				typCastType = kImplicitTypeCast;
			if NOT(err = Evaluate(api_data, *typeCastExplicityP, typCastType, &expressP, &expressLen, nil, &operP[index].objRef, kNoFlowControl, numParP, true/*, nil*/))
				(*evalFlagsP) |= kToAdvance;
		}
	}
	if NOT(err)
	{	if (expressLen && (*expressP == ')'))
		{	expressP++;
			expressLen--;
			(*numParP)--;
		}
		else
			err = XError(kBAPI_Error, Err_BadSyntax);
	}

*expressPPtr = expressP;
*expressLenP = expressLen;
return err;
}
		
//===========================================================================================
// N.B. Per i double nella pagina di codice voglio sempre il punto (non decSep)
static Boolean _IsNumber(long api_data, Ptr *stringToCheckPPtr, long *lenP, ObjRecordP resultObj, long stopFlags, XErr *errP)
{
Ptr 		theP;
long		aLong, constructor, len;
int			i = 1;
Str255		tempStr;
XErr		err = noErr;
Byte		ch;
Boolean		isHex;

theP = *stringToCheckPPtr;
if NOT(len = *lenP)
	return false;

	if ((len > 2) && (*(short*)theP == ZERO_FOR))
	{	isHex = true;
		constructor = kIntClassID;
		theP += 2;
		len -= 2;	
		while(len && (i < 254) && (*theP != ' ') && (*theP != ')') && NOT(IsEvalOperator(&theP, &len, false, -1, nil)))
		{	ch = *theP;
			if (((ch >= '0') && (ch <= '9')) || ((ch >= 'A') && (ch <= 'F')) || ((ch >= 'a') && (ch <= 'f')))
			{	tempStr[i++] = *theP++;
				len--;
			}
			else if (StopEvaluating(theP, len, nil) || (ch == ' ') || (ch == '\t'))
				break;
			else if ((ch == ',') && (stopFlags & kStopOnComma))
				break;
			else if ((ch == ':') && (stopFlags & kStopOnSemicolon))
				break;
			else
				return false;
		}
		tempStr[0] = --i;
		goto out;
 	}
	else if (((*theP >= '0') && (*theP <= '9')) || (*theP == '.'))
	{	isHex = false;
		constructor = kIntClassID;	
		while(len && (i < 254) && (*theP != ' ') && (*theP != ')') && NOT(IsEvalOperator(&theP, &len, false, -1, nil)))
		{	ch = *theP;
			if (ch == '.')
			{	if (constructor == kDoubleClassID)
					return false;
				else
					constructor = kDoubleClassID;
			}
			else if (StopEvaluating(theP, len, nil) || (ch == ' ') || (ch == '\t') || (ch == '?'))	// ternary a?b:c
				break;
			else if ((ch == ',') && (stopFlags & kStopOnComma))
				break;
			else if ((ch == ':') && (stopFlags & kStopOnSemicolon))
				break;
			else if ((ch < '0') || (ch > '9'))
				return false;
			tempStr[i++] = *theP++;
			len--;
		}
		tempStr[0] = --i;
		goto out;
 	}
 	else
 		return false;

out:
if (resultObj)
{	if COMPILING(api_data)
	{	if NOT(BIC_LiteralNumToObjRef(api_data, constructor, tempStr, resultObj, &err))
			return false;
	}
	else
	{	
	LONGLONG	l;

		INVAL_P(resultObj);
		if (constructor == kIntClassID)
		{	if (isHex)
			{	if (tempStr[0] <= 8)
				{	aLong = HexStringToNum(tempStr, &err);
					if NOT(err)
						err = CL_IntToObj(api_data, aLong, resultObj);
				}
				else if (tempStr[0] <= 16)
				{	l = HexStringToNumLong(tempStr, &err);
					if NOT(err)
						err = CL_LongToObj(api_data, l, resultObj);
				}
				else
					err = XError(kBAPI_Error, Err_TooLongHexLiteral);
			}
			else if (i > 19)
			{	double r;
			
				r = PStrToReal(tempStr);
				err = CL_DoubleToObj(api_data, r, resultObj);
			}
			else if (i > 9)
			{	if NOT(err = PStringToLongNum(tempStr, &l))
					err = CL_LongToObj(api_data, l, resultObj);
			}
			else
			{	PStringToNum(tempStr, &aLong);
				err = CL_IntToObj(api_data, aLong, resultObj);
			}
		}
		else if (constructor == kDoubleClassID)
		{	Byte		*strP = tempStr;

			if ((*strP++ == 1) && (*strP == '.'))
				return false;
			else
				err = CL_DoubleToObj(api_data, PStrToReal(tempStr), resultObj);
		}
	}
}
*errP = err;
*stringToCheckPPtr = theP;
*lenP = len;
return true;
}

//===========================================================================================
static Boolean _IsString(long api_data, Ptr *stringToCheckPPtr, long *lenP, ObjRecordP resultObj, long *curLineP, int firstChar, XErr *errP)
{
Ptr 		saveP, theP;
long		back_slashCnt, curLine, strLen, len;
int			id = 0, oldCh, ch, i;
XErr		err = noErr;
CStr255		aCStr;
char		*strP, *saveStrP;
Boolean		isNew, isBS, res = false;
BlockRef	block;
long		initLine, newLineSize;
BifernoRecP	bRecP;

	if (api_data)
		bRecP = (BifernoRecP)api_data;
	else
		bRecP = nil;
	theP = *stringToCheckPPtr;
	if NOT(len = *lenP)
		return false;
	if NOT(firstChar)
	{	if (*theP == '\"')
			firstChar = '\"';
		else if (*theP == '\'')
			firstChar = '\'';
	}
	if (firstChar)
	{	id = curLine = 0;
		block = 0;
		res = true;
		strP = aCStr;
		saveStrP = strP;
		strLen = 0;
		theP++;
		len--;
		saveP = theP;
		i = 1;
		if (curLineP)
			curLine = *curLineP;
		ch = 0;
		back_slashCnt = 0;
		initLine = curLine;
		while ((len > 0) && NOT(err))
		{	oldCh = ch;
			if ((isBS = ((len > 1) && (*theP == '\\'))) && (ch = SpecialChar(*(theP+1))))
			{	theP++;
				len--;
			}
			else if (isBS)
			{	theP++;
				len--;
				isNew = false;
				if (NOT(len) || (isNew = IsNewLineExt(&theP, &len, nil)))
				{	if (isNew)
					{	if (bRecP && NOT(bRecP->currentCtx.lastMultiStrStart))
						{	bRecP->currentCtx.lastMultiStrStart = (short)initLine;
							bRecP->currentCtx.lastMultiStrEnd = (short)curLine;
						}
						curLine++;							
					}
					continue;
				}
				else
				{	err = XError(kBAPI_Error, Err_InvalidEscapeSequence);
					break;
				}
			}
			else if (*theP == firstChar)
				break;
			else if (IsNewLine(theP, len, &newLineSize))
			{	curLine++;
				if (bRecP && NOT(bRecP->currentCtx.lastMultiStrStart))
				{	bRecP->currentCtx.lastMultiStrStart = (short)initLine;
					bRecP->currentCtx.lastMultiStrEnd = (short)curLine;
				}
				ch = *theP;
				if (newLineSize == 2)	// to add cr and lf and only one "curLine++;"
				{	if (id)
						err = BufferAddChar(id, (char)ch);
					else if (strLen < 254)
					{	*strP++ = ch;
						strLen++;
					}
					else
					{	if (id = BufferCreate(strLen, &err))
						{	if NOT(err = BufferAddBuffer(id, saveStrP, strLen))
								err = BufferAddChar(id, (char)ch);
						}
					}
					theP++;
					len--;
					ch = *theP;
				}
			}
			else
			{	ch = *theP;
				if (ch == '\\')
					back_slashCnt++;
				else
					back_slashCnt = 0;
			}
			if (id)
				err = BufferAddChar(id, (char)ch);
			else if (strLen < 254)
			{	*strP++ = ch;
				strLen++;
			}
			else
			{	if (id = BufferCreate(strLen, &err))
				{	if NOT(err = BufferAddBuffer(id, saveStrP, strLen))
						err = BufferAddChar(id, (char)ch);
				}
			}
			if NOT(err)
			{	theP++;
				len--;
			}
		}
		if NOT(err)
		{	if (len && (*theP == firstChar) && NOT(back_slashCnt & 1))
			{	theP++;
				len--;
				if (curLineP)
					*curLineP = curLine;
			}
			else
			{	err = XError(kBAPI_Error, Err_QuotesExpected);
				NewMsgRecord(api_data, kDOING, *stringToCheckPPtr, *lenP, 0);
				goto out;
			}
		}
		else
			goto out;
	}
	else
		goto out;

*stringToCheckPPtr = theP;
*lenP = len;
if (id)
{	block = BufferGetBlockRef(id, &strLen);
	LockBlock(block);
	saveStrP = GetPtr(block);
}
if (resultObj)
{	if COMPILING(api_data)
		err = BIC_LiteralStringToObjRef(api_data, saveStrP, strLen, resultObj);
	else
	{	INVAL_P(resultObj);
		err = StringToConstObj(api_data, saveStrP, strLen, OBJREF_P(resultObj));
	}
}
out:
if (id)
{	if NOT(block)
		block = BufferGetBlockRef(id, &strLen);
	BufferClose(id);	
	DisposeBlock(&block);
}
*errP = err;
return res;
}


//===========================================================================================
static void* _ProcessBlock_Func(void* userdata)
{
_ProcessBlock_Params	*params = (_ProcessBlock_Params*)userdata;
XErr					err = noErr;

	err = ProcessBlock(params->api_data, &params->textP, &params->len, params->flags);

return (void*)err;
}

//===========================================================================================
static Boolean _BifernoCheckStackSpace(BifernoRecP bRecP)
{
long 	stackUsed;

	if (bRecP->stackBasePointer)
	{	stackUsed = bRecP->stackBasePointer - (long)&stackUsed;
		if (stackUsed < 0)
			stackUsed = -stackUsed;
		// if (diff > kMaxStackForThread)
		if ((bRecP->stackSize - stackUsed) < MINIMAL_STACK)
			return true;
		else
			return false;
	}
	else
	{	bRecP->stackBasePointer = XThreadsGetThreadInfo(&bRecP->stackSize, nil);
		return false;
	}
}

//===========================================================================================
static XErr	_InvertObj(long api_data, ObjRecordP objP, ObjRecordP resultP)
{
XErr		err = noErr;
Boolean		isImmediate = IS_IMMEDIATE_P(objP);

	if COMPILING(api_data)
		err = BIC_Opposite(api_data, objP, resultP);
	else
	{	if (isImmediate)
		{	resultP->id = IMMEDIATE_ID;
			resultP->classID = OBJ_CLASSID_P(objP);
			switch(OBJ_CLASSID_P(objP))
			{
				case kBooleanClassID:
					*(Boolean*)IMM_P(resultP) = -*(Boolean*)IMM_P(objP);
					break;
				case kStringClassID:
					err = XError(kBAPI_Error, Err_IllegalOperation);
					break;
				case kDoubleClassID:
					*(double*)IMM_P(resultP) = -*(double*)IMM_P(objP);
					break;
				case kLongClassID:
					*(LONGLONG*)IMM_P(resultP) = -*(LONGLONG*)IMM_P(objP);
					break;
				case kUnsignedClassID:
					*(unsigned long*)IMM_P(resultP) = /*-*/*(unsigned long*)IMM_P(objP);
					break;
				case kIntClassID:
					*(long*)IMM_P(resultP) = -*(long*)IMM_P(objP);
					break;
				case kCharClassID:
					CDebugStr("impossible char immediate");
					break;
			}
		}
		else
			err = CL_Opposite(api_data, objP, resultP);
	}
		
return err;
}

//===========================================================================================
static XErr	_IsVariableTrue(long api_data, ObjRecordP item, Boolean *isTrueP)
{
	return CL_GetBoolean(api_data, item, isTrueP, kImplicitTypeCast);
}

//===========================================================================================
static XErr	_PostEvalProcess(long api_data, Ptr *expressPPtr, long *expressLenP, EvalObjRefP operP, Boolean pre_incr, Boolean pre_decr, long *evalFlagsP,
							long *typeCastExplicityP, Byte *opOrder, long *actOrderP, long *nextExpectedP, long *indexP, long flags)
{	
long			evalFlags, i, expressLen;
Ptr				expressP;
XErr			err = noErr;
ObjRecordP		objRefP = &operP[*indexP].objRef;

	expressP = *expressPPtr;
	expressLen = *expressLenP;
	evalFlags = *evalFlagsP;
	if (expressLen && (*expressP == '['))
	{	if (objRefP->classID && objRefP->id)
		{	if NOT(err = ResolveArryItem(api_data, &expressP, &expressLen, objRefP, nil, nil, false, nil, nil))
				SkipSpaceAndTab(&expressP, &expressLen);
		}
		else
			err = XError(kBAPI_Error, Err_BadSyntax);
	}
	if NOT(err)
	{	if (expressLen && (*expressP == '.'))
		{	if (objRefP->classID && objRefP->id)
			{	Boolean					appearsOneMethod;
				long					assignmentType, incrType;
				SuperIsChangedNotify 	*notifyP = nil;
				MemberLoopCallRecord	*membLoopP;
				uint32_t				slot;
				
				if (pre_incr)
					incrType = kPreIncrem;
				else if (pre_decr)
					incrType = kPreDecrem;
				else
					incrType = kNullIncr;
				if NOT(err = PoolNewPtr(gsDispatcherData.memberLoopPool, (Ptr*)&membLoopP, &slot))
				{	
					membLoopP->varRecP = objRefP; 
					membLoopP->incrTypeP = &incrType; 
					assignmentType = -1;
					membLoopP->assignmentTypeP = &assignmentType; 
					membLoopP->appearsOneMethodP = &appearsOneMethod; 
					membLoopP->propListBlockP = nil; 
					membLoopP->isFunction = false;  
					membLoopP->dontCheckPeriod = false; 
					membLoopP->notifyP = &notifyP;
					membLoopP->flags = flags;
					if NOT(err = MemberLoop(api_data, &expressP, &expressLen, membLoopP, false, nil, false))
					{	if (notifyP)
						{	err = NotifySuperIsChanged(api_data, notifyP);
							PoolDisposePtr(gsDispatcherData.notifySuperIsChangedPool, notifyP->slot);
						}
					}
					else
						NewMsgRecord(api_data, kMEMBER, membLoopP->memberName, CLen(membLoopP->memberName), 0);
					PoolDisposePtr(gsDispatcherData.memberLoopPool, slot);
				}
			}
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
		}
		if (NOT(err) && (evalFlags & kToAdvance))
		{	for (i = *actOrderP - 1; (i >= 0) && NOT(err); i--)
			{
				switch(opOrder[i])
				{
					case kDoTypeCast:
						if (*typeCastExplicityP)
						{	if NOT(err = CoercionToRequestedType(api_data, objRefP, *typeCastExplicityP, objRefP, kExplicitTypeCast))
								*typeCastExplicityP = 0;
						}
						break;
						
					case kDoMinus:
						if (evalFlags & kMinusMode)
						{	if NOT(err = _InvertObj(api_data, objRefP, objRefP))
								evalFlags &= (0xFFFFFFFF ^ kMinusMode);
						}
						break;
						
					case kDoNot:
						if (evalFlags & kNotMode)
						{	Boolean	isTrue;
							
							if NOT(err = _IsVariableTrue(api_data, objRefP, &isTrue))
							{	INVAL_P(objRefP);
								err = BAPI_BooleanToObj(api_data, (Boolean)NOT(isTrue), OBJREF_P(objRefP));
							}
							evalFlags &= (0xFFFFFFFF ^ kNotMode);
						}
						break;
						
				}
			}
			*actOrderP = 0;
			if NOT(err)
			{	*nextExpectedP = OPERATOR_EXPECTED;
				(*indexP)++;
				if (*indexP < MAX_EXPRESSINPARENT)
				{	
					INVAL(operP[*indexP].objRef);
					operP[*indexP].operation = 101;		// invalidate it
				}
				else
					err = XError(kBAPI_Error, Err_BadSyntax);
			}
		}
	}
	if NOT(err)
	{	*expressPPtr = expressP;
		*expressLenP = expressLen;
		*evalFlagsP = evalFlags;
	}
	
return err;
}

//===========================================================================================
static XErr	_CheckLogic(long api_data, Ptr *expressPPtr, long *expressLenP, EvalObjRefP operP, long *totElemsP, long flags, Boolean *finishedP, long *nextExpectedP, Boolean firstItem, Boolean *skippedP, long which)
{
XErr		err = noErr;
ObjRecord	result;
Boolean		isTrue;
int			i, curTot;

	if ((*nextExpectedP == VARIABLE_EXPECTED) || firstItem)
		err = XError(kBAPI_Error, Err_BadSyntax);
	else
	{	if NOT(err = ResolveBisLine(api_data, operP, *totElemsP, &result, kBooleanClassID, kExplicitTypeCast))
		{	
			operP[0].objRef = result;
			operP[0].operation = which;
			curTot = *totElemsP;
			for (i = 1; i < curTot; i++)	// zero old values
				INVAL(operP[i].objRef);
			*totElemsP = 1;
			if NOT(err = BAPI_ObjToBoolean(api_data, (ObjRefP)&result, &isTrue, kExplicitTypeCast))
			{	if (which == EVAL_LOGIC_AND)
				{	if NOT(isTrue)
					{	// skip until end (or when meet '?', that has lower priority)
						//if NOT(err = SkipBisBlock(api_data, expressPPtr, expressLenP, flags | kOnlyOneStatement | kLeaveEndChar | kStopOnRoundBracket | kStopOnQuestionMark, nil, nil, nil, nil, numParP))
						if NOT(err = SkipBisLine(api_data, expressPPtr, expressLenP, flags, true, false))
						{	if (NOT(*expressLenP) || (**expressPPtr != '?'))
								*finishedP = true;
							*nextExpectedP = 0;
							*skippedP = true;
						}
					}
					else
						*skippedP = false;
				}
				else
				{	if (isTrue)
					{	if NOT(err = SkipBisLine(api_data, expressPPtr, expressLenP, flags, true, true))
						{	*nextExpectedP = 0;
							*skippedP = true;
						}
					}
					else
						*skippedP = false;
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_CheckTernary(long api_data, Ptr *expressPPtr, long *expressLenP, EvalObjRefP operP, long *totElemsP, long flags, long *nextExpectedP)
{
XErr		err = noErr;
ObjRecord	result;
Boolean		isTrue, ternaryFound;

	ternaryFound = false;
	if NOT(err = ResolveBisLine(api_data, operP, *totElemsP, &result, kBooleanClassID, kExplicitTypeCast))
	{	if NOT(err = BAPI_ObjToBoolean(api_data, (ObjRefP)&result, &isTrue, kExplicitTypeCast))
		{	if (isTrue)
			{	if NOT(err = Eval(api_data, 0, 0, expressPPtr, expressLenP, flags | kStopOnSemicolon, &operP[0].objRef))
				{	if (*expressLenP && (**expressPPtr == ':'))
					{	(*expressPPtr)++;
						(*expressLenP)--;
					}
					*totElemsP = 1;
					//if NOT(err = SkipBisBlock(api_data, expressPPtr, expressLenP, flags | kOnlyOneStatement | kStopOnRoundBracket | kLeaveEndChar, nil, nil, nil, nil, numParP))
					if NOT(err = SkipBisLine(api_data, expressPPtr, expressLenP, flags, false, false))
						*nextExpectedP = OPERATOR_EXPECTED;
				}
			}
			else
			{	// skip until next ':'
				//if NOT(err = SkipBisBlock(api_data, expressPPtr, expressLenP, flags | kOnlyOneStatement | kStopOnRoundBracket | kLeaveEndChar, nil, nil, nil, &ternaryFound, numParP))
				if NOT(err = SkipBisLine(api_data, expressPPtr, expressLenP, flags | kStopOnSemicolon, false, false))
				{	if (*expressLenP && (**expressPPtr == ':'))
					{	(*expressPPtr)++;
						(*expressLenP)--;
						if NOT(err = Eval(api_data, 0, 0, expressPPtr, expressLenP, flags, &operP[0].objRef))
							*totElemsP = 1;
					}
					else
						err = XError(kBAPI_Error, Err_BadSyntax);
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_DoVariable(long api_data, Ptr *expressPPtr, long *expressLenP, EvalObjRefP operP, long index, long flags, long *evalFlagsP, long *numParP, char *varName, Boolean *stopEvalP, Boolean getReference, Boolean noFlow/*, Boolean *setErrMsgP*/)
{
XErr			err = noErr;
long			fcID, evalFlags, expressLen;
Ptr				expressP;
BifernoRecP 	bRecP = (BifernoRecP)api_data;

	expressP = *expressPPtr;
	expressLen = *expressLenP;
	evalFlags = *evalFlagsP;
	if NOT(err = _DoEntity(api_data, &expressP, &expressLen, operP, index, numParP, false, false, varName, flags, false, getReference/*, &setErrMsg*/))
		evalFlags |= kToAdvance;
	else if (NOT(*stopEvalP) && NOT(noFlow) && (IsFlowControl(api_data, varName, &expressP, &expressLen, &fcID, nil, &err)))	// is a flow control?
	{	BAPI_ResetError(api_data);
		if (flags & kNoFlowControl)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	if (index || (evalFlags & kNotMode) || (evalFlags & kMinusMode))
				err = XError(kBAPI_Error, Err_BadSyntax);
			else
			{	err = DoFlowControl(api_data, fcID, &expressP, &expressLen, flags, false);
				evalFlags |= kFinished;
			}
		}
	}
	if NOT(err)
	{	*expressPPtr = expressP;
		*expressLenP = expressLen;
		*evalFlagsP = evalFlags;
		if (bRecP->currentCtx._stop || bRecP->_exit)
			evalFlags |= kFinished;
	}

return err;
}

//===========================================================================================
static XErr	_DoOperator(long api_data, Ptr *expressPPtr, long *expressLenP, EvalObjRefP operP, long *indexP, Byte *opOrder, long *actOrderP, long flags, long *evalFlagsP, long *nextExpectedP, long *numParP, char *varName, Boolean *noPostP, 
						Boolean *pre_incrP, Boolean *pre_decrP, Boolean *resP)
{
XErr		err = noErr;
long		evalFlags, actOrder, operat, index, nextExpected, expressLen;
Ptr			expressP;
Boolean		finished, skipped, pre_incr, pre_decr;

	expressP = *expressPPtr;
	expressLen = *expressLenP;
	nextExpected = *nextExpectedP;
	actOrder = *actOrderP;
	evalFlags = *evalFlagsP;
	index = *indexP;
	finished = false;
	if ((expressLen > 1) && ((pre_incr = (*(short*)expressP == '++')) || (pre_decr = (*(short*)expressP == '--'))))
	{	*resP = true;
		if (evalFlags & kMinusMode)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	expressP += sizeof(short);
			expressLen -= sizeof(short);
			if NOT(err = _DoEntity(api_data, &expressP, &expressLen, operP, index, numParP, pre_incr, pre_decr, varName, flags, false, false/*, nil*/))
				evalFlags |= kToAdvance;
		}
	}
	else if (operat = IsEvalOperator(&expressP, &expressLen, true, nextExpected, nil))
	{	*resP = true;
		switch(operat)
		{	
			case EVAL_LOGIC_AND:
			case EVAL_LOGIC_OR:
				if NOT(err = _CheckLogic(api_data, &expressP, &expressLen, operP, &index, flags, &finished, &nextExpected, (Boolean)((evalFlags & kFirstItem) != 0), &skipped, operat))
				{	if (finished)
						evalFlags |= kFinished;
					if (skipped)
					{	if (noPostP)
							*noPostP = true;
					}
					else
						goto op;
				}
				break;
		
			case _NOT:
				evalFlags |= kNotMode;
				opOrder[actOrder++] = kDoNot;
				break;
			
			case EVAL_MINUS:
				if ((nextExpected == VARIABLE_EXPECTED) || (evalFlags & kFirstItem))
				{	if (evalFlags & kMinusMode)
						err = XError(kBAPI_Error, Err_BadSyntax);
					else
					{	evalFlags |= kMinusMode;
						opOrder[actOrder++] = kDoMinus;
					}
				}
				else
					goto op;
				break;
			
			case EVAL_ADD:
				if (nextExpected == VARIABLE_EXPECTED)
					err = XError(kBAPI_Error, Err_BadSyntax);
				else
					goto op;
				break;
				
			default:
			op:	
				// added '&& (operat != EVAL_ADD)' to accept things like: a = +1
				if ((nextExpected == VARIABLE_EXPECTED) || ((evalFlags & kFirstItem) && (operat != EVAL_ADD)))
					err = XError(kBAPI_Error, Err_BadSyntax);
				else if ((operat < 0) || (operat > LAST_OP))
					err = XError(kBAPI_Error, Err_UnknownOperator);
				nextExpected = VARIABLE_EXPECTED;
				operP[index].operation = operat;
				break;
		}
		evalFlags &= (0xFFFFFFFF ^ kToAdvance);		// off the bit
	}
	else if (nextExpected == OPERATOR_EXPECTED)
		err = XError(kBAPI_Error, Err_BadSyntax);
	else
		*resP = false;

	if NOT(err)
	{	*expressPPtr = expressP;
		*expressLenP = expressLen;
		*nextExpectedP = nextExpected;
		*indexP = index;
		*actOrderP = actOrder;
		*evalFlagsP = evalFlags;
		*pre_incrP = pre_incr;
		*pre_decrP = pre_decr;
	}

return err;
}

//===========================================================================================
static Boolean _CheckFlowControl(long api_data, Ptr *textPPtr, long *lenP, long flags, XErr *errP)
{
XErr		err = noErr;
Ptr			textP;
long		entityLength, flowContrID, len;
Boolean		isFlow, blockDone;

	textP = *textPPtr;
	len = *lenP;
	blockDone = false;
	isFlow = IsFlowControlExt(api_data, &textP, &len, &flowContrID, &entityLength);
	if (isFlow)
	{	switch(flowContrID)
		{
			case k_For:
			case k_Do:
			case k_While:
			case k_If:
			case k_Switch:
				err = DoFlowControl(api_data, flowContrID, &textP, &len, 0, SKIP_FORCED);
				blockDone = true;
				break;
			case k_Else:
				if ((flags & kStopOnElse) && (flags & kOnlyOneStatement))
				{	blockDone = true;
					goto out;	// don't increment textP
				}
				break;
		}
	}
	else if (entityLength)
	{	textP += entityLength;
		len -= entityLength;
	}
	*textPPtr = textP;
	*lenP = len;

out:
*errP = err;
return blockDone;
}

//===========================================================================================
static XErr _SkipChecks(long api_data, Ptr *textPPtr, long *lenP, long flags, char *labelName, long labelNameLen, long *switchFlagP, Boolean *finishedP, Boolean *toContinueP)
{
XErr			err = noErr;
Ptr				textP;
long			len;
int				tempCh;
BifernoRecP 	bRecP = (BifernoRecP)api_data;

	textP = *textPPtr;
	len = *lenP;
	// looking for case or default label
	if (switchFlagP)
	{	if ((len > 3) && (*(long*)textP == CASE_LABEL))
		{	textP += sizeof(long);
			len -= sizeof(long);
			if (len)
			{	tempCh = *textP;
				if ((tempCh == '\t') || (tempCh == ' '))
				{	*finishedP = true;
					*switchFlagP = kCaseFound;
					goto out;
				}
			}
		}
		else if ((len > 6) && NOT(CompareBlock(textP, "default", 7)))
		{	textP += 7;
			len -= 7;
			SkipSpaceAndTab(&textP, &len);
			if (len && (*textP == ':'))
			{	textP++;
				len--;
				*finishedP = true;
				*switchFlagP = kDefaultFound;
				goto out;
			}
		}
	}						
	// flow control
	if ((flags & kOnlyOneStatement) && (*finishedP = _CheckFlowControl(api_data, &textP, &len, flags, &err)))
	{
		;
	}
	// labels
	else if (labelName && labelNameLen && (len > labelNameLen) && NOT(CompareBlock(labelName, textP, labelNameLen)))
	{	textP += labelNameLen;
		len -= labelNameLen;
		*labelName = 0;
		bRecP->_break = false;
		*finishedP = true;
	}

out:
	if NOT(err)
	{	*toContinueP = (*textPPtr != textP);
		*textPPtr = textP;
		*lenP = len;
	}
return err;
}

//===========================================================================================
static XErr _AfterStatement(BifernoRecP bRecP, Ptr *textPPtr, long *lenP, long flags, Boolean *blockDoneP, XErr *errP)
{	
XErr		err = noErr;
Ptr			textP;
long		tot_graf_pars, len;
Boolean		finished = false;

	textP = *textPPtr;
	len = *lenP;	
	if (NOT(bRecP->_exit) && NOT(bRecP->currentCtx._stop) && NOT(bRecP->_return) && NOT(bRecP->_break) && NOT(bRecP->_continue) && (bRecP->currentCtx.inTag))
	{	if (flags & kOnlyOneStatement)
		{	if (IsNewLineExt(&textP, &len, nil))
				bRecP->currentCtx.currentLine++;
			else if (IsEndTagExt(bRecP, &textP, &len, &err))
				;
			else if (len && (*textP == ';'))
			{	textP++;
				len--;
			}
			else if (NOT(flags & kOnlyOneStatement) && ((len && (*textP == '}')) && NOT(bRecP->_break)))
			{	textP++;
				len--;
				tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
				if (tot_graf_pars < MAX_PARCHECKS)
					bRecP->currentCtx.toBalance[tot_graf_pars] = 0;
				if (--tot_graf_pars < 0)
					err = XError(kBAPI_Error, Err_CurlyBracketNotBalanced);
				else
					bRecP->currentCtx.tot_graf_pars = (short)tot_graf_pars;
			}
			*blockDoneP = true;
			finished = true;
		}
	}
	else
		finished = true;

if NOT(err)
{	*lenP = len;
	*textPPtr = textP;
}
*errP = err;
return finished;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	ProcessBlock(long api_data, Ptr *textPPtr, long *lenP, long flags)
{
XErr			err = noErr;
Ptr				textP;
long			diff, saveCurrentLine, retSize, tot_graf_pars, len;
BifernoRecP 	bRecP;
Boolean			blockDone, checkResume;
const Byte		*chTypePtr;

	if NOT(len = *lenP)
		return noErr;
		
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	// Yields and abort/timeout checks
	if (err = BifernoYield(&bRecP->lastYield))
		return err;
	bRecP->finalTicks = XGetTicks();
	diff = bRecP->finalTicks - bRecP->startTicks;
	// if (diff > 0) because the precision of clock can generate diff -1 in very fast scripts
	if (bRecP->startTicks && bRecP->timeOut && (diff > 0) && ((unsigned long)diff > bRecP->timeOut))
		return XError(kBAPI_Error, Err_Timeout);

	if (_BifernoCheckStackSpace(bRecP))
	{	
	//_ProcessBlock_Params	params;
	//unsigned long			threadID;
	//unsigned long			saveStackPoint;
	CStr255					msg;
		
		// ------ debug
		sprintf(msg, "ProcessBlock DEBUG: Stack Overflow: %d\n", bRecP->locked);
		BAPI_Log(api_data, msg);
		// ------
		
		//if (bRecP->locked)
			err = XError(kBAPI_Error, Err_StackOverflow);
		/*else
		{	params.api_data = api_data;
			params.textP = *textPPtr;
			params.len = *lenP;
			params.flags = flags;
			saveStackPoint = bRecP->stackBasePointer;
			bRecP->stackBasePointer = 0;
			bRecP->curThreads++;
			bRecP->maxThreads++;
			err = XNewThread(&threadID, kWaitEndOfThread, _ProcessBlock_Func, 64L * 1024L, (void*)&params);
			bRecP->curThreads--;
			bRecP->stackBasePointer = saveStackPoint;
			if NOT(err)
			{	*textPPtr = params.textP;
				*lenP = params.len;
			}
		}*/
		return err;
	}
	
	checkResume = true;
	ResetVolatileList(bRecP);
	
	saveCurrentLine = bRecP->currentCtx.currentLine;
	textP = *textPPtr;
	if (len && bRecP->currentCtx.inTag && (*textP == '{'))
	{	textP++;
		len--;
		tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
		if (tot_graf_pars < MAX_PARCHECKS)
			bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
		bRecP->currentCtx.tot_graf_pars++;
	}	
	if (NOT(err) && len)
	{	blockDone = false;
		if (bRecP->currentCtx.inTag)
		{	err = ProcessBisBlock(api_data, &textP, &len, flags, &blockDone);
			if (err || bRecP->_exit || bRecP->currentCtx._stop || bRecP->_return || bRecP->_break || bRecP->_continue || blockDone)
				goto end;
		}
		if (NOT(err) && len)
		{	
		Ptr		pToAdd;
		long	lToAdd;
		
		pToAdd = textP;
		lToAdd = 0;
		chTypePtr = gChTypes;
		do {
				switch(chTypePtr[*(Byte*)textP])
				{
					case kBSlash:
					case kAnd:
					case kDQuote:
					case kQuote:
					case kSlash:
					case kSmcmm:
					case kCCurly:
					case kOCurly:
					case kComm:
					case kCBrk:
					case kOBrk:
						break;
						
					case kDllr:
						if ((len > 1) && (textP[1] == '$'))
						{	textP++;
							len--;
							lToAdd++;
							if NOT(err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false))
							{	textP++;
								len--;
								pToAdd = textP;
								lToAdd = 0;
							}
							else
								goto out;
						}
						else if NOT(err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false))
						{
						Byte	lastChar;
						Ptr		saveP;
						long	saveLen;
						
							saveP = textP;
							saveLen = len;
							textP++;
							len--;
							SkipOneParameter((BifernoRecP)api_data, &textP, &len, &lastChar, kStopOnDollar + kStopOnCR, true, false);
							if (lastChar == '$')
							{	saveLen = (saveLen - len);
								err = DoPrint(api_data, &saveP, &saveLen, true);
							}
							else
								err = BAPI_StandardOutput(api_data, saveP, (saveLen - len), false);
							if NOT(err)
							{	pToAdd = textP;
								lToAdd = 0;
							}
							else
								goto out;
						}
						else
							goto out;
						continue;
						
					case kCR:
					case kLF:
						IsNewLine2(textP, len, &retSize);
						lToAdd += retSize;			
						textP += retSize;
						len -= retSize;
						bRecP->currentCtx.currentLine++;
						if ((flags & kOnlyOneStatement) && (bRecP->currentCtx.currentLine == (saveCurrentLine + 1)))
							goto out;
						else
							continue;
						
					case kQMrk:
						if (NOT(bRecP->currentCtx.inTag) && (len > 1) && (textP[1] == '>'))
						{	if (bRecP->inOtherTag)
								bRecP->inOtherTag--;
							else
							{	err = XError(kBAPI_Error, Err_BadSyntax);
								goto out;
							}
						}
						break;

					case kSmcln:
					case kSpace:
					case kTab:
					case kStar:
						break;
						
					case kLess:
						if (IsInitTagExt2(bRecP, &textP, &len))
						{	if NOT(err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false))
							{	err = ProcessBisBlock(api_data, &textP, &len, flags, &blockDone);
								pToAdd = textP;
								lToAdd = 0;
								if (err || bRecP->_exit || bRecP->currentCtx._stop || bRecP->_return || bRecP->_break || bRecP->_continue || blockDone)
								{	checkResume = false;
									goto out;
								}
								else
									continue;
							}
							else
								goto out;
						}
						else
							break;
					
					case kOp:
					case kNum:
					case kDecSep:
					case kAcCh:
					case stdCh:
						break;
					
					default:
						CDebugStr("chtype: should never happen");
				}
				lToAdd++;
				textP++;
				len--;
			} while (len);
out:
			if NOT(err)
				err = BAPI_StandardOutput(api_data, pToAdd, lToAdd, false);
		}
	}
	
end:
if NOT(err)
{	*lenP = len;
	*textPPtr = textP;
}
else
{	if (checkResume)
	{	if NOT(bRecP->criticalMem)
			err = CheckIfResume(api_data, err, textPPtr, lenP);
	}
}
return err;
}

//===========================================================================================
XErr	SkipBlock(long api_data, Ptr *textPPtr, long *lenP, long flags, char *labelName, long *switchFlagP)
{
Ptr				textP;
long			tot_graf_pars, len;
BifernoRecP 	bRecP;
XErr			err = noErr;
Boolean			searchingLabel, blockDone;
long			saveCurrentLine, act_graf_pars, retSize;
const Byte		*chTypePtr;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	act_graf_pars = bRecP->currentCtx.tot_graf_pars;
	textP = *textPPtr;
	len = *lenP;	
	saveCurrentLine = bRecP->currentCtx.currentLine;
	if (len && bRecP->currentCtx.inTag && (*textP == '{'))
	{	textP++;
		len--;
		tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
		if (tot_graf_pars < MAX_PARCHECKS)
			bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
		bRecP->currentCtx.tot_graf_pars++;
	}
	if (len)
	{	blockDone = false;
		if (bRecP->currentCtx.inTag)
		{	if (labelName)
				searchingLabel = (*labelName != 0);
			else
				searchingLabel = false;
			err = SkipBisBlock(api_data, &textP, &len, flags, &blockDone, labelName, switchFlagP);
		}
		if (NOT(err) && len && NOT(blockDone))
		{	do {
				chTypePtr = gChTypes;
				switch(chTypePtr[*(Byte*)textP])
				{
					case kBSlash:
					case kAnd:
					case kDQuote:
					case kQuote:
					case kSlash:
					case kSmcmm:
					case kCCurly:
					case kOCurly:
					case kComm:
					case kCBrk:
					case kOBrk:
					case kDllr:
						break;
						
					case kCR:
					case kLF:
						IsNewLine2(textP, len, &retSize);
						bRecP->currentCtx.currentLine++;
						textP += retSize;
						len -= retSize;
						if ((flags & kOnlyOneStatement) && (bRecP->currentCtx.currentLine == (saveCurrentLine + 1)))
							goto out;
						else
							continue;
						
					case kQMrk:
					case kSmcln:				
					case kSpace:
					case kTab:
					case kStar:
						break;
						
					case kLess:
						if (IsInitTagExt2(bRecP, &textP, &len))
						{	if (labelName)
								searchingLabel = (*labelName != 0);
							else
								searchingLabel = false;
							err = SkipBisBlock(api_data, &textP, &len, flags, &blockDone, labelName, switchFlagP);
							if (err || blockDone)
								goto out;
							else
								continue;
						}
						else
							break;
							
					case kOp:
					case kNum:
					case kDecSep:
					case kAcCh:
					case stdCh:
						break;
						
					default:
						CDebugStr("chtype: should never happen");
						break;
				}
				textP++;
				len--;
			} while (len);	// > 0) && NOT(blockDone));
		}
	}

out:
if (err)
{	if NOT(bRecP->currentCtx.currentOffset)
		bRecP->currentCtx.currentOffset = BfrGetOffset(bRecP, len);
}
else
{	*lenP = len;
	*textPPtr = textP;
}
return err;
}

//===========================================================================================
XErr	SkipEntireBlock(long api_data, Ptr *oldFilePPtr, long *lenP, long flags, long curGraphPar, Boolean searchPar)
{
BifernoRecP		bRecP = (BifernoRecP)api_data;
XErr			err = noErr;
long			tot_graf_pars;

	if (searchPar)
	{	SkipSmart(bRecP, oldFilePPtr, lenP);
		if (*lenP && **oldFilePPtr == '{')
		{	(*oldFilePPtr)++;
			(*lenP)--;
			tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
			if (tot_graf_pars < MAX_PARCHECKS)
				bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
			bRecP->currentCtx.tot_graf_pars++;
		}
		else
			err = XError(kBAPI_Error, Err_BadSyntax);
	}
	if NOT(err)
	{	while((bRecP->currentCtx.tot_graf_pars != curGraphPar) && (*lenP > 0) && NOT(err))
			err = SkipBlock(api_data, oldFilePPtr, lenP, flags, nil, nil);
	}
	
return err;
}

//===========================================================================================
XErr ProcessBisBlock(long api_data, Ptr *textPPtr, long *lenP, long flags, Boolean *blockDoneP)
{
XErr			err = noErr;
Ptr				textP;
long			tot_graf_pars, len;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
ObjRecord		resultVarRec;
Boolean			blockDone;
const Byte		*chTypePtr;

	textP = *textPPtr;
	len = *lenP;	
	blockDone = false;
	if (len > 0)
	{	do {
			chTypePtr = gChTypes;
			switch(chTypePtr[*(Byte*)textP])
			{
				case kBSlash:
				case kAnd:
					err = XError(kBAPI_Error, Err_BadSyntax);
					goto out;				

				case kDQuote:
				case kQuote:
					INVAL(resultVarRec);
					if NOT(err = EvalWithResume(api_data, &textP, &len, flags, &resultVarRec))
					{	if (_AfterStatement(bRecP, &textP, &len, flags, &blockDone, &err))
							goto out;
						else
							continue;
					}
					else
						goto out;
				
				case kSlash:
					if (IsCommentExt2(bRecP, &textP, &len, nil, nil, true))
						continue;
					else
					{	err = XError(kBAPI_Error, Err_BadSyntax);
						goto out;				
					}
					
				case kSmcmm:
					textP++;
					len--;
					if (flags & kOnlyOneStatement)
					{	blockDone = true;
						goto out;
					}
					else
						continue;
				
				case kCCurly:
					if (NOT(flags & kOnlyOneStatement) && NOT(bRecP->_break))
					{	textP++;
						len--;
						tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
						if (tot_graf_pars < MAX_PARCHECKS)
							bRecP->currentCtx.toBalance[tot_graf_pars] = 0;
						if (--tot_graf_pars < 0)
							err = XError(kBAPI_Error, Err_CurlyBracketNotBalanced);
						else
							bRecP->currentCtx.tot_graf_pars = (short)tot_graf_pars;
						blockDone = true;
						goto out;
					}
					
				case kOCurly:
					textP++;
					len--;
					tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
					if (tot_graf_pars < MAX_PARCHECKS)
						bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
					bRecP->currentCtx.tot_graf_pars++;
					if (err = ProcessBlock(api_data, &textP, &len, 0))
						goto out;
					else
						continue;					
				
				case kComm:
				case kCBrk:
					err = XError(kBAPI_Error, Err_BadSyntax);
					goto out;
				
				case kOBrk:
					textP++;
					len--;
					tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
					if (tot_graf_pars < MAX_PARCHECKS)
						bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
					bRecP->currentCtx.tot_graf_pars++;
					err = ProcessBlock(api_data, &textP, &len, 0);
					continue;
					
				case kDllr:
					if (err = DoPrint(api_data, &textP, &len, false))
						goto out;
					else
					{	if (flags & kOnlyOneStatement)
						{	blockDone = true;
							goto out;
						}
						else
							continue;
					}
					
				case kCR:
				case kLF:
					IsNewLineExt2(&textP, &len, &bRecP->currentCtx.currentLine);
					if (flags & kOnlyOneStatement)
					{	blockDone = true;
						goto out;
					}
					else
						continue;

				case kQMrk:
					if ((len > 1) && (textP[1] == '>'))
					{	textP += 2;
						len -= 2;
						bRecP->currentCtx.inTag = false;
						if (flags & kOnlyOneStatement)
							blockDone = true;
						goto out;
					}
					else
						break;
					
				case kSmcln:
					err = XError(kBAPI_Error, Err_BadSyntax);
					goto out;
									
				case kSpace:
				case kTab:
					break;
					
				case kStar:
				case kLess:
					err = XError(kBAPI_Error, Err_BadSyntax);
					goto out;

				case kOp:
					INVAL(resultVarRec);
					if NOT(err = EvalWithResume(api_data, &textP, &len, flags, &resultVarRec))
					{	if (_AfterStatement(bRecP, &textP, &len, flags, &blockDone, &err))
							goto out;
						else
							continue;
					}
					else
						goto out;

				case kNum:
				case kDecSep:
					INVAL(resultVarRec);
					if NOT(err = EvalWithResume(api_data, &textP, &len, flags, &resultVarRec))
					{	if (_AfterStatement(bRecP, &textP, &len, flags, &blockDone, &err))
							goto out;
						else
							continue;
					}
					else
						goto out;
					
				case kAcCh:
					INVAL(resultVarRec);
					if NOT(err = EvalWithResume(api_data, &textP, &len, flags, &resultVarRec))
					{	if (_AfterStatement(bRecP, &textP, &len, flags, &blockDone, &err))
							goto out;
						else
							continue;
					}
					else
						goto out;

				case stdCh:
					err = XError(kBAPI_Error, Err_BadSyntax);
					goto out;
					
				default:
					CDebugStr("chtype: should never happen");
					break;
			}
			textP++;
			len--;
		} while (len);
	}

out:
if NOT(err)
{	if (blockDoneP)
		*blockDoneP = blockDone;
	*lenP = len;
	*textPPtr = textP;
}
return err;
}

//===========================================================================================
XErr SkipBisBlock(long api_data, Ptr *textPPtr, long *lenP, long flags, Boolean *blockDoneP, char *labelName, long *switchFlagP/*, int charToFind, Boolean stopOnBreak*/)
{
XErr			err = noErr;
Ptr				textP;
long			tot_graf_pars, len;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
Boolean			toContinue, inSingleApString, inDoubleApString, blockDone;
int				numPar, labelNameLen;
long			initLine;
const Byte		*chTypePtr;

	numPar = 0;
	blockDone = false;
	textP = *textPPtr;
	len = *lenP;
	inSingleApString = inDoubleApString = false;
	initLine = bRecP->currentCtx.currentLine;
	if (len)
	{	if (switchFlagP)
			*switchFlagP = 0;
		if (labelName)
			labelNameLen = CLen(labelName);
		else
			labelNameLen = 0;
		chTypePtr = gChTypes;
		do
		{	switch(chTypePtr[*(Byte*)textP])
			{
				case kBSlash:
					textP++;
					len--;
					SkipSpaceAndTab(&textP, &len);
					IsNewLineExt(&textP, &len, &bRecP->currentCtx.currentLine);
					continue;

				case kAnd:
					break;
				
				case kDQuote:
				case kQuote:
					_IsString(api_data, &textP, &len, nil, &bRecP->currentCtx.currentLine, *textP, &err);
					if (err)
						goto out;
					else
						continue;

				case kSlash:
					if (IsCommentExt2(bRecP, &textP, &len, nil, nil, true))
						continue;
					else
						break;

				case kSmcmm:
					textP++;
					len--;
					if (flags & kOnlyOneStatement)
					{	blockDone = true;
						goto out;
					}
					else
						continue;

				case kCCurly:
					textP++;
					len--;
					tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
					if (tot_graf_pars < MAX_PARCHECKS)
						bRecP->currentCtx.toBalance[tot_graf_pars] = 0;
					if (--tot_graf_pars < 0)
						err = XError(kBAPI_Error, Err_CurlyBracketNotBalanced);
					else
						bRecP->currentCtx.tot_graf_pars = (short)tot_graf_pars;
					blockDone = true;
					goto out;

				case kOCurly:
					textP++;
					len--;
					tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
					if (tot_graf_pars < MAX_PARCHECKS)
						bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
					bRecP->currentCtx.tot_graf_pars++;
					if NOT(err = SkipBlock(api_data, &textP, &len, 0, labelName, nil))
					{	if (labelNameLen && labelName && NOT(*labelName))		// found the label
						{	bRecP->_break = false;
							blockDone = true;
							goto out;
						}
						else
							continue;
					}
					else
						goto out;

				case kComm:
					break;

				case kCBrk:
					if (--numPar < 0)
					{	err = XError(kBAPI_Error, Err_RoundBracketNotBalanced);
						goto out;
					}
					else
						break;

				case kOBrk:
					numPar++;
					break;

				case kDllr:
					break;
					
				case kCR:
				case kLF:
					IsNewLineExt2(&textP, &len, &bRecP->currentCtx.currentLine);
					if (flags & kOnlyOneStatement)
					{	blockDone = true;
						goto out;
					}
					else
						continue;
						
				case kQMrk:
					// ex: if ((len > 1) && (textP[1] == '>'))
					if ((IsEndTagExt(bRecP, &textP, &len, &err)) || err)
						goto out;
					else
						break;
						
				case kSmcln:
				case kSpace:
				case kTab:
				case kStar:
				case kLess:
					break;
					
				case kOp:
					if ((*textP == 'n') || (*textP == 'N'))
					{	err = _SkipChecks(api_data, &textP, &len, flags, labelName, labelNameLen, switchFlagP, &blockDone, &toContinue);
						if (err || blockDone)
							goto out;
						else if (toContinue)
							continue;
						else
							break;
					}
					else
						break;

				case kNum:
				case kDecSep:
					break;
					
				case kAcCh:
					err = _SkipChecks(api_data, &textP, &len, flags, labelName, labelNameLen, switchFlagP, &blockDone, &toContinue);
					if (err || blockDone)
						goto out;
					else if (toContinue)
						continue;
					else
						break;
					
				case stdCh:
					break;

				default:
					CDebugStr("chtype: should never happen");
					
			}
			textP++;
			len--;
		} while (len);
	}

out:
if (NOT(err) && numPar)
{	if (numPar > 0)
		err = XError(kBAPI_Error, Err_RoundBracketExpected);
	else
		err = XError(kBAPI_Error, Err_RoundBracketNotBalanced);
}
if (err)
{	if NOT(bRecP->currentCtx.currentOffset)
		bRecP->currentCtx.currentOffset = BfrGetOffset(bRecP, len);
}
else
{	if (blockDoneP)
		*blockDoneP = blockDone;
	*lenP = len;
	*textPPtr = textP;
}
return err;
}

//===========================================================================================
// This is the core of the parser
XErr	ProcessBisLine(long api_data, EvalObjRefP operP, long *totElemsP, Ptr *expressPPtr, long *expressLenP, char *varNameP, long flags, long *numParP/*, Boolean *setErrMsgP*/)
{
XErr			err = noErr;
long			operat;
long			expressLen, index, nextExpected;
Ptr				expressP;
Boolean			newLine;
long			evalFlags, crSize, *curLineP, typeCastExplicity;
BifernoRecP 	bRecP;
char			varName[MAX_VARIABLE_NAME_LENGTH];
Boolean			noPost, noFlow = (Boolean)(flags & kNoFlowControl);
Boolean			pre_incr, pre_decr, isOp, stopEval = false, *stopEvalP;
Byte			opOrder[TOT_OP];
long			actOrder;
const Byte		*chTypePtr;

	if NOT(varNameP)
		varNameP = varName;
	if (bRecP = (BifernoRecP)api_data)
	{	curLineP = &bRecP->currentCtx.currentLine;
		stopEvalP = &bRecP->stopEval;
		if (*stopEvalP)
			*stopEvalP = false;
	}
	else
	{	curLineP = nil;
		stopEvalP = &stopEval;
	}
	expressP = *expressPPtr;
	expressLen = *expressLenP;
	//totRecMsg = GetTotMsgRecords(api_data);
	index = 0;
	operat = 0;
	operP[0].operation = EVAL_ADD;
	INVAL(operP[0].objRef);
	nextExpected = 0;
	typeCastExplicity = actOrder = 0;
	evalFlags = kFirstItem;
	pre_incr = pre_decr = kNullIncr;
	noPost = false;
	*varNameP = 0;
	if (expressLen)
	{	chTypePtr = gChTypes;
		do {
			switch(chTypePtr[*(Byte*)expressP])
			{
					case kBSlash:
						expressP++;
						expressLen--;
						SkipSpaceAndTab(&expressP, &expressLen);
						if (IsNewLineExt(&expressP, &expressLen, curLineP))
							continue;
						else
						{	err = XError(kBAPI_Error, Err_BadSyntax);
							goto out;
						}
					
					case kAnd:
						switch(nextExpected)
						{	case 0:
								err = _DoVariable(api_data, &expressP, &expressLen, operP, index, flags, &evalFlags, numParP, varNameP, stopEvalP, true, noFlow/*, setErrMsgP*/);
								break;
							case OPERATOR_EXPECTED:
								*varNameP = 0;
								err = _DoOperator(api_data, &expressP, &expressLen, operP, &index, opOrder, &actOrder, flags, &evalFlags, &nextExpected, numParP, varNameP, &noPost, &pre_incr, &pre_decr, &isOp);
								break;
							case VARIABLE_EXPECTED:
								err = _DoVariable(api_data, &expressP, &expressLen, operP, index, flags, &evalFlags, numParP, varNameP, stopEvalP, true, noFlow/*, setErrMsgP*/);
								break;
							default:
								*varNameP = 0;
								err = _DoOperator(api_data, &expressP, &expressLen, operP, &index, opOrder, &actOrder, flags, &evalFlags, &nextExpected, numParP, varNameP, &noPost, &pre_incr, &pre_decr, &isOp);
								break;
						}
						if (err || (evalFlags & kFinished))
							goto out;
						break;
						
					case kDQuote:
					case kQuote:
						if (nextExpected == OPERATOR_EXPECTED)
						{	err = XError(kBAPI_Error, Err_BadSyntax);
							goto out;
						}
						_IsString(api_data, &expressP, &expressLen, &operP[index].objRef, curLineP, *expressP, &err);
						if (err)
							goto out;
						else
						{	evalFlags |= kToAdvance;
							break;
						}
						
					case kSlash:
						if (IsCommentExt2(bRecP, &expressP, &expressLen, &newLine, nil, true))
						{	SkipSpaceAndTab(&expressP, &expressLen);
							if ((flags & kStopOnCR) && newLine)
								goto out;
							else
								continue;
						}
						else
						{	err = _DoOperator(api_data, &expressP, &expressLen, operP, &index, opOrder, &actOrder, flags, &evalFlags, &nextExpected, numParP, varNameP, &noPost, &pre_incr, &pre_decr, &isOp);
							if (err)
								goto out;
							else if NOT(isOp)
								err = XError(kBAPI_Error, Err_BadSyntax);
						}
						break;
						
					case kSmcmm:
						goto out;
					
					case kCCurly:
					case kOCurly:
						goto out;
						
					case kComm:
						if NOT(flags & kStopOnComma)
							err = XError(kBAPI_Error, Err_BadSyntax);
						goto out;
					
					case kCBrk:
						if (evalFlags & kFirstItem)
							err = XError(kBAPI_Error, Err_BadSyntax);
						goto out;
						
					case kOBrk:
						if (nextExpected == OPERATOR_EXPECTED)
						{	err = XError(kBAPI_Error, Err_BadSyntax);
							goto out;
						}
						else
						{	if NOT(err = _DoOpenPar(api_data, &expressP, &expressLen, operP, &index, numParP, &evalFlags, &typeCastExplicity))
							{	if (typeCastExplicity)
									opOrder[actOrder++] = kDoTypeCast;
							}
							else
								goto out;
						}
						break;
					
					case kDllr:
						if NOT(flags & kStopOnDollar)
						{	if (flags & kInAssignment)
								err = XError(kBAPI_Error, Err_IllegalAssignment);
							else
							{	if (evalFlags & kFirstItem)
									err = DoPrint(api_data, &expressP, &expressLen, false);
								else
									err = XError(kBAPI_Error, Err_BadSyntax);
							}
						}
						goto out;
					
					case kCR:
					case kLF:
						IsNewLine2(expressP, expressLen, &crSize);
						if (flags & kStopOnCR)
							goto out;
						else
						{	if (curLineP)
								(*curLineP)++;
							expressP += crSize;
							expressLen -= crSize;
							continue;
						}
						
					case kQMrk:
						if ((expressLen > 1) && (expressP[1] == '>'))
						{	// if (flags & kStopOnCR)
							goto out;
						}
						else
						{	if ((nextExpected == VARIABLE_EXPECTED) || (evalFlags & kFirstItem))
							{	err = XError(kBAPI_Error, Err_BadSyntax);
								goto out;
							}
							else
							{	expressP++;
								expressLen--;
								if NOT(err = _CheckTernary(api_data, &expressP, &expressLen, operP, &index, flags, &nextExpected))
									continue;
							}
						}
						break;
					
					case kSmcln:
						if NOT(flags & kStopOnSemicolon)
							err = XError(kBAPI_Error, Err_BadSyntax);
						goto out;
						
					case kSpace:
					case kTab:
						expressP++;
						expressLen--;
						noPost = true;
						break;
					
					case kStar:
					case kLess:
					case kOp:
						*varNameP = 0;
						err = _DoOperator(api_data, &expressP, &expressLen, operP, &index, opOrder, &actOrder, flags, &evalFlags, &nextExpected, numParP, varNameP, nil, &pre_incr, &pre_decr, &isOp);
						if (err || (evalFlags & kFinished))
							goto out;
						else
						{	if NOT(isOp)	// should happen for 'N' and 'n' that aren't: not NOT
							{	if (nextExpected == OPERATOR_EXPECTED)
								{	err = XError(kBAPI_Error, Err_BadSyntax);
									goto out;
								}
								err = _DoVariable(api_data, &expressP, &expressLen, operP, index, flags, &evalFlags, numParP, varNameP, stopEvalP, false, noFlow/*, setErrMsgP*/);
								if (err || (evalFlags & kFinished))
									goto out;
							}
						}
						break;
						
					case kNum:
					case kDecSep:
						if (nextExpected == OPERATOR_EXPECTED)
						{	err = XError(kBAPI_Error, Err_BadSyntax);
							goto out;
						}
						if (_IsNumber(api_data, &expressP, &expressLen, &operP[index].objRef, flags, &err))
						{	if (err)
								goto out;
							else
							{	evalFlags |= kToAdvance;
								break;
							}
						}
						else
						{	err = XError(kBAPI_Error, Err_BadSyntax);
							goto out;
						}
						
					case kAcCh:
						if (nextExpected == OPERATOR_EXPECTED)
						{	if ((expressLen <= 3) || (*(long*)expressP != ELSE_STR))
								err = XError(kBAPI_Error, Err_BadSyntax);
							goto out;
						}
						*varNameP = 0;
						err = _DoVariable(api_data, &expressP, &expressLen, operP, index, flags, &evalFlags, numParP, varNameP, stopEvalP, false, noFlow/*, setErrMsgP*/);
						if (err || (evalFlags & kFinished))
							goto out;
						else
							break;

					case stdCh:
						err = XError(kBAPI_Error, Err_BadSyntax);
						goto out;
					
					default:
						CDebugStr("chtype: should never happen");
			}
			if (noPost)
				noPost = false;
			else if NOT(err)
				err = _PostEvalProcess(api_data, &expressP, &expressLen, operP, pre_incr, pre_decr, &evalFlags, &typeCastExplicity, opOrder, &actOrder, &nextExpected, &index, flags);
			if NOT(err)
			{	if (evalFlags & kFirstItem)
					evalFlags &= (0xFFFFFFFF ^ kFirstItem);
				if (evalFlags & kToAdvance)
					evalFlags &= (0xFFFFFFFF ^ kToAdvance);
			}
			else
				break;
		} while (expressLen);
	}

out:			
	if NOT(err)
	{	if (nextExpected == VARIABLE_EXPECTED)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	*totElemsP = index;
			*expressPPtr = expressP;
			*expressLenP = expressLen;
		}
	}
	else
	{	*totElemsP = 0;
		if NOT(bRecP->currentCtx.currentOffset)
			bRecP->currentCtx.currentOffset = BfrGetOffset(bRecP, *expressLenP);
	}

return err;
}

//===========================================================================================
XErr	ResolveBisLine(long api_data, EvalObjRefP operP, long totItems, ObjRecordP resultVarRecP, long requestedType, long typeCastType)
{
int			i, k;
XErr		err = noErr;
int			processed, priority;
ObjRecord		oldItem;
long		op;

	if NOT(totItems)
	{	if (resultVarRecP)
			BAPI_InvalObjRef(api_data, OBJREF_P(resultVarRecP));
		return noErr;
	}
	
	if (operP[0].operation == EVAL_MINUS)
		err = _InvertObj(api_data, &operP[0].objRef, &oldItem);
	else
		oldItem = operP[0].objRef;

	if (totItems > 1)
	{	processed = 1;
		for (priority = 0; (priority <= MAX_OPER_PRIORITY) && (processed < totItems); priority++)
		{	oldItem = operP[0].objRef;
			for (i = 1; (i < totItems) && (processed < totItems); i++)
			{	if (operP[i].objRef.id)
				{	if (gsPriority[operP[i].operation] == priority)
					{	k = i-1;
						while(operP[k].operation == 101)
							k--;
						if (requestedType) 
							operP[k].objRef.classID = requestedType;
						op = operP[i].operation;
						/*if (op == EVAL_TERNARY_QUESTIONMARK)
						{	c = i + 1;
							if (c < totItems)
							{	while(operP[c].operation == 101)
									c++;
								if (operP[c].operation != EVAL_TERNARY_SEMICOLON)	
									err = XError(kBAPI_Error, Err_BadSyntax);
								else
								{	INVAL(operP[k].objRef);
									err = _DoTernary(api_data, &oldItem, &operP[i].objRef, &operP[c].objRef, &operP[k].objRef);
								}
							}
							else
								err = XError(kBAPI_Error, Err_BadSyntax);
							if (err)
								goto out;
							oldItem = operP[k].objRef;
							operP[i].operation = 101;
							operP[c].operation = 101;
							processed += 2;
						}
						else*/
						{	INVAL(operP[k].objRef);
							if (COMPILING(api_data))
								err = BIC_ExecuteOperation(api_data, &oldItem, &operP[i].objRef, operP[i].operation, &operP[k].objRef);
							else
								err = CL_ExecuteOperation(api_data, &oldItem, &operP[i].objRef, operP[i].operation, &operP[k].objRef);
							if (err)
								goto out;
							oldItem = operP[k].objRef;
							operP[i].operation = 101;
							processed++;
						}
					}
					else if (operP[i].operation != 101)
						oldItem = operP[i].objRef;
				}
				else
					return XError(kBAPI_Error, Err_IllegalOperation);
			}
		}
	}
	
	if NOT(err)
	{	if (NOT(COMPILING(api_data)) && requestedType)
		{	if ((oldItem.id && oldItem.classID))
				err = CoercionToRequestedType(api_data, &oldItem, /*nil, */requestedType, resultVarRecP, typeCastType);
			else
				err = XError(kBAPI_Error, Err_IllegalOperation);
		}
		else if (resultVarRecP)
			*resultVarRecP = oldItem;
	}

out:
return err;
}

//===========================================================================================
// Skip text in a line expression. Stops before the stop char(s)
XErr SkipBisLine(long api_data, Ptr *textPPtr, long *lenP, long flags, Boolean stopOnTernaryQMark, Boolean stopOnLogicAnd)
{
XErr			err = noErr;
Ptr				textP;
long			len;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
int				qMark;
const Byte		*chTypePtr;
	
	textP = *textPPtr;
	len = *lenP;
	if (len > 0)
	{	qMark = 0;
		chTypePtr = gChTypes;
		do {
			switch(chTypePtr[*(Byte*)textP])
			{	
				case kBSlash:	//'\\':
					textP++;
					len--;
					SkipSpaceAndTab(&textP, &len);
					IsNewLineExt(&textP, &len, &bRecP->currentCtx.currentLine);
					continue;

				case kAnd:		//'&':
					if (len && (textP[1] == '&') && stopOnLogicAnd)
						goto out;
					else
						break;
					
				case kDQuote:	//'\"':
				case kQuote:	//'\'':
					_IsString(api_data, &textP, &len, nil, &bRecP->currentCtx.currentLine, *textP, &err);
					if (err)
						goto out;
					else
						continue;
					
				case kSlash:	//'/':
					if (IsCommentExt2(bRecP, &textP, &len, nil, nil, true))
						continue;
					else
						break;
				
				case kSmcmm:	//';':
					goto out;
					
				case kCCurly:	//'}':
				case kOCurly:	//'{':
					err = XError(kBAPI_Error, Err_BadSyntax);
					goto out;
					
				case kComm:		//',':
					if (flags & kStopOnComma)
						goto out;
					else
						break;

				case kCBrk:		//')':
					goto out;
		
				case kOBrk:		//'(':
					textP++;
					len--;
					if (err = SkipBisLine(api_data, &textP, &len, 0, false, false))
						goto out;
					else
					{	if (len)
							break;
						else
							goto out;
					}
					
				case kDllr:		//'$':
					if (flags & kStopOnDollar)
						goto out;
					else
						break;
				
				case kCR:		//'\r':
				case kLF:		//'\n':
					if (flags & kStopOnCR)
						goto out;
					else
					{	IsNewLineExt2(&textP, &len, &bRecP->currentCtx.currentLine);
						continue;
					}
					
				case kQMrk:		//'?':
					if ((len > 1) && (textP[1] == '>'))
					{	if (flags & kStopOnCR)
							goto out;
					}
					else
					{	if (stopOnTernaryQMark)
							goto out;
						else
							qMark++;
					}
					break;

				case kSmcln:	//':':
					if (qMark)
						qMark--;
					else if (flags & kStopOnSemicolon)
						goto out;
					break;
				
				case kSpace:
				case kTab:
				case kStar:
				case kLess:
				case kOp:
				case kNum:
				case kDecSep:
				case kAcCh:
				case stdCh:		// all other chars
					break;

				default:
					CDebugStr("Should never happen");
			}
			textP++;
			len--;
		} while (len > 0);
	}

out:
if NOT(err)
{	*lenP = len;
	*textPPtr = textP;
}
return err;
}




