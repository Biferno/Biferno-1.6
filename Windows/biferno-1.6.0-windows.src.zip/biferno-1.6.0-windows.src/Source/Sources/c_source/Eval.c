/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Eval.c,v 1.22 2008-11-27 15:27:49 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Entity.h"
#include "BifernoErrors.h"
#include "Param.h"
#include "BfrParser.h"
#include "Load.h"
#include "Classes.h"

extern	DispatcherData					gsDispatcherData;	// in Dispatcher.c
extern	PluginRecord					*gClassRecordBlockP;

//===========================================================================================
XErr	DoPrint(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean fromOutOfTags)
{
XErr			err = noErr;
ParameterRec	param;
ObjRecord		result;
long			saveCurLine;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			saveInTag;

	(*oldFilePPtr)++;
	(*lenP)--;
	SkipSpaceAndTab(oldFilePPtr, lenP);
	if (IsNewLine(*oldFilePPtr, *lenP, nil))
		return noErr;

	saveCurLine = ((BifernoRecP)api_data)->currentCtx.currentLine;
	if (fromOutOfTags)
	{	saveInTag = bRecP->currentCtx.inTag;
		bRecP->currentCtx.inTag = true;
	}
	if NOT(err = GetOneParameter(api_data, oldFilePPtr, lenP, nil, &param, nil, false, false, kStopOnCR + kStopOnDollar/* + kLoadParamOnStack*/, nil, 0))
	{	if (bRecP->printFilterDocBlock)
		{	
		BlockRef		savePrintFilterDocBlock;
		MemberAction 	*membIdentP;
		
			savePrintFilterDocBlock = bRecP->printFilterDocBlock;
			membIdentP = (MemberAction*)GetPtr(bRecP->printFilterDocBlock);
			bRecP->printFilterDocBlock = 0;
			err = CL_ExecuteFunction(api_data, membIdentP, nil, &param, 1, &result);
			bRecP->printFilterDocBlock = savePrintFilterDocBlock;
			
		}
		else
		{	if COMPILING(api_data)
				err = BIC_Print(api_data, (ObjRecordP)&param.objRef);
			else
				err = CL_ExecuteFunction(api_data, (MemberAction*)GetPtr(gsDispatcherData.printDocBlock), nil, &param, 1, &result);
		}
	}
	// ex
	// to be tolerant with things like $ExecFunction()$ (outside tags) where ExecFunction is void
	// else if (fromOutOfTags && (err == XError(kBAPI_Error, Err_InvalidParameter)))
	//	err = noErr;
	if (fromOutOfTags)
		bRecP->currentCtx.inTag = saveInTag;

// qui oldFilePPtr pu� essere invalido (tipo se '$"a" + get()')
if (err)
{	if NOT(err = CheckIfResume(api_data, err, nil, nil))
		((BifernoRecP)api_data)->currentCtx.currentLine = saveCurLine;
}
return err;
}

//===========================================================================================
XErr	Evaluate(long api_data, long requestedType, long typeCastType, Ptr *expressPPtr, long *expressLenP, char *varNameP, ObjRecordP resultVarRecP, long flags, long *numParP, Boolean returnValueIsRelevant/*, Boolean *setErrMsgP*/)
{
XErr			err = noErr;
long			totElems;
EvalObjRefP		theOperRecP;
uint32_t		slot;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			saveRIR;

	if (*expressLenP)
	{	saveRIR = RESULT_IS_RELEVANT(api_data);
		RESULT_IS_RELEVANT(api_data) = returnValueIsRelevant;
		if NOT(err = PoolNewPtr(gsDispatcherData.evalPool, (Ptr*)&theOperRecP, &slot))
		{	if NOT(err = ProcessBisLine(api_data,theOperRecP,&totElems,expressPPtr,expressLenP,varNameP,flags,numParP/*,setErrMsgP*/))
			{	if (NOT(bRecP->currentCtx._stop) && NOT(bRecP->_exit))
					err = ResolveBisLine(api_data,theOperRecP,totElems,resultVarRecP,requestedType,typeCastType);
			}
			PoolDisposePtr(gsDispatcherData.evalPool, slot);
		}
		RESULT_IS_RELEVANT(api_data) = saveRIR;
	}
	else if (resultVarRecP)
	{	resultVarRecP->classID = 0;
		resultVarRecP->id = 0;
	}
	
//out:
return err;
}

//===========================================================================================
XErr	Eval(long api_data, long requestedType, long typeCastType, Ptr *expressPPtr, long *expressLenP, long flags, ObjRecordP resultVarRecP)
{
long	parNum;
XErr	err = noErr;

	parNum = 0;
	if NOT(err = Evaluate(api_data, requestedType, typeCastType, expressPPtr, expressLenP, nil, resultVarRecP, flags, &parNum, false/*, nil*/))
	{	if (parNum)
		{	if (parNum > 0)
				err = XError(kBAPI_Error, Err_RoundBracketExpected);
			else
				err = XError(kBAPI_Error, Err_RoundBracketNotBalanced);
		}
		else
			;//RemoveEndChar(expressPPtr, expressLenP, flags, &((BifernoRecP)api_data)->currentLine, true);
	}
	
return err;
}

