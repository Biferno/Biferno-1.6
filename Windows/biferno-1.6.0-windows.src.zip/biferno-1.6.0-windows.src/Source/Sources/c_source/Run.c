/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Run.c,v 1.60 2008-12-01 13:44:34 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "HTTPMgr.h"

#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Flower.h"
#include "BfrSession.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "BifernoErrors.h"
#include "Load.h"
//#include "BJNI.h"
#include "Input.h"
#include "Entity.h"
#include "Application.h"
#include "Classes.h"
#include "Run.h"
#include "XThreadsPrivate.h"
#include <stdio.h>
#include <string.h>

#include "HttpPage.h"
#include "SendMail.h"
#include "BfrError.h"

// Extern
extern XErr						gMemoryFullError;
extern unsigned long			gsBifernoCurrentUsers;
extern DispatcherData			gsDispatcherData;		// in Dispatcher.c
extern PluginRecord				*gClassRecordBlockP;
extern Page_GetOutputCallBack	page_GetOutput;
//extern Error_UpdateEMsgRecordCallBack	error_UpdateEMsgRecord; 
extern long						gRunID;
extern XFilePath				gBifernoSpoolPath;
extern CStr255					gPersistentFolder;

// Static
static Boolean			gsTryReload = false;
static char gsRedirFileText[]	= "<?																\r\n\
error.Resume();	\r\n\r\n\
noCook = false;	\r\n\
if (cookies = global pageIn.head.GetField(\"Cookie\"))			\r\n\
{	redir = \"\";	\r\n\
	arr = cookies.ToArray(\"; \");	\r\n\
	nCook = arr.dim;	\r\n\
	for (i = 1; i <= nCook; i++)								\r\n\
	{	arr2 = arr[i].ToArray(\"=\");	\r\n\
		if (arr2[1] == \"BIFERNO_TRY\")	\r\n\
		{	redir = arr2[2];	\r\n\
			break;	\r\n\
		}														\r\n\
	}															\r\n\
	if (redir)	\r\n\
	{	sa = request.searchArg;	\r\n\
		if (sa)													\r\n\
			redir += \"?\" + sa;	\r\n\
		if (request.method == \"POST\")	\r\n\
		{	global pageOut.head.SetField(\"\", \"HTTP/1.1 307 Temporary redirect\")	\r\n\
			global pageOut.head.AddField(\"Location\", redir)	\r\n\
			global pageOut.body = \"\"	\r\n\
			exit	\r\n\
		}	\r\n\
		else	\r\n\
			request.Redirect(redir);	\r\n\
	}															\r\n\
	else														\r\n\
		noCook = true;	\r\n\
}																\r\n\
else															\r\n\
	noCook = true;	\r\n\
if (noCook)														\r\n\
{	err.msg = \"Enable cookies in browser and retry\";	\r\n\
	error.ThrowException(Err_CookieDisabled);	\r\n\
	redir = false;	\r\n\
	if (curScript.IsDef(\"application ERROR_PAGE\"))						\r\n\
	{	if (application ERROR_PAGE)								\r\n\
			redir = true;	\r\n\
	}															\r\n\
		\r\n\
	if (redir)													\r\n\
	{	f = application ERROR_PAGE;	\r\n\
		if (f.Begins(\"file://\"))	\r\n\
		{	error.Suspend();	\r\n\
			include(application ERROR_PAGE);	\r\n\
			error.Resume();		\r\n\
		}		\r\n\
		else if (f.Begins(\"/\"))	\r\n\
		{	error.Suspend();	\r\n\
			include(application ERROR_PAGE);	\r\n\
			error.Resume();		\r\n\
		}		\r\n\
		else	\r\n\
		{	applBase = curApp.home;	\r\n\
			errFile = applBase + f;	\r\n\
			error.Suspend();	\r\n\
			include(errFile);	\r\n\
			error.Resume();		\r\n\
		}	\r\n\
	}	\r\n\
	else														\r\n\
	{															\r\n\
	?>															\r\n\
<h3>Cookies must be enabled in order to see this site:<br>		\r\n\
enable cookies in browser and retry ($global err.name$)</h3>	\r\n\
	<?															\r\n\
	}															\r\n\
}																\r\n\
error.Suspend();												\r\n\
?>";

static char gsDenyFileText[]	= "<?																\r\n\
error.Resume();	\r\n\r\n\
err.msg = \"Enable cookies in browser and retry\";	\r\n\
error.ThrowException(Err_CookieDisabled);	\r\n\
redir = false;	\r\n\
if (curScript.IsDef(\"application ERROR_PAGE\"))						\r\n\
{	if (application ERROR_PAGE)								\r\n\
		redir = true;	\r\n\
}															\r\n\
	\r\n\
if (redir)													\r\n\
{	f = application ERROR_PAGE;	\r\n\
	if (f.Begins(\"file://\"))	\r\n\
	{	error.Suspend();	\r\n\
		include(application ERROR_PAGE);	\r\n\
		error.Resume();		\r\n\
	}		\r\n\
	else if (f.Begins(\"/\"))	\r\n\
	{	error.Suspend();	\r\n\
		include(application ERROR_PAGE);	\r\n\
		error.Resume();		\r\n\
	}		\r\n\
	else	\r\n\
	{	applBase = curApp.home;	\r\n\
		errFile = applBase + f;	\r\n\
		error.Suspend();	\r\n\
		include(errFile);	\r\n\
		error.Resume();		\r\n\
	}	\r\n\
}	\r\n\
else														\r\n\
{															\r\n\
?>															\r\n\
	<h3>Cookies must be enabled in order to see this site:<br>		\r\n\
	enable cookies in browser and retry ($global err.name$)</h3>	\r\n\
<?															\r\n\
}															\r\n\
error.Suspend();												\r\n\
?>";

#define	SIMPLE_HEADER		"HTTP/1.1 200 OK\r\n%s%s%s%s%s%sContent-Type: text/html\r\nContent-length: %d\r\n\r\n"
#define	BADMIN_INDEX		"/index.bfr"
#define	BADMIN_INDEX_LEN	10
#define	NO_ACCESS_STRING_1	"HTTP/1.1 401 Unauthorized\r\nContent-Type: text/html\r\nWWW-Authenticate: Basic realm=\""
#define	NO_ACCESS_STRING_2	"\"\r\n\r\n"
#define	NO_ACCESS_MESSAGE	"<HTML><HEAD><TITLE>Biferno Access Denied</TITLE></HEAD><BODY BGCOLOR=\"#ffffff\"><H1>Access Denied</H1><P>Sorry, you have been denied access to a file on this server.</BODY>"
#ifdef __LITTLE_ENDIAN__
	#define	SLASH_SPACE		' /'
	#define	BASI			'isaB'
	#define	C_SPACE			' c'
	#define	CR_LF			0x0A0D		// '\n\r'
#else
	#define	SLASH_SPACE		'/ '
	#define	BASI			'Basi'
	#define	C_SPACE			'c '
	#define	CR_LF			'\r\n'
#endif

#define	ALLOW_CUSTOM_ERR_PAGE	false
#define	AVOID_CUSTOM_ERR_PAGE	true

static void	_GetErrorPage(BifernoRec *bRecP, BlockRef *resultTextP, long *resultSizeP, XFilePathPtr filePath, XErr theError, Boolean isLocalFile, BlockRef headInBlock, long headBlockLen, Boolean avoidErrPage, XErr *ioErrorP, XErr *localResultErrP, Boolean prefixLength, long lastClassIDErrorCalled, char *class_error_note, Boolean noHeader);

//===========================================================================================
static XErr	_RunExit(void)
{
XErr	err = noErr;

	gsBifernoCurrentUsers--;
	
return err;
}

//==================================================
static XErr	_UserPassFromHeader(Ptr headInPtr, long headLen, char *username, char *password)
{
register long		len;
register StringPtr	strP;
int					i, outBytes, inBytes;
Byte				*bufInPtr, *bufOutPtr;
BlockRef			bufOutBlock = 0;
XErr				err = noErr;

	*username = 0;
	*password = 0;
	bufInPtr = (Byte*)headInPtr;
	len = headLen;
	while (len > 0)
	{	if ((len > 3) && (*(long*)bufInPtr == BASI))
		{	bufInPtr += 4;
			len -= 4;
			if ((len > 1) && (*(short*)bufInPtr == C_SPACE))
			{	bufInPtr += 2;
				len -= 2;
				if (bufOutBlock = NewPtrBlock(len + 2, &err, (Ptr*)&bufOutPtr))
				{	//bufOutPtr = (Byte*)GetPtr(bufOutBlock);
					inBytes = len;
					outBytes = HTUU_decode((Ptr)bufInPtr, bufOutPtr, inBytes);	// stops when encounter '\r'
				}
				else
					CDebugStr("_UserPassFromHeader: memError");
				break;
			}
		}
		bufInPtr++;
		len--;
	}
	if NOT(len)
		return noErr;	// no user pass
	if (outBytes)
	{	strP = (Byte*)username;
		i = 0;
		while(outBytes > 0)
		{	if (outBytes && (*bufOutPtr == ':'))
			{	username[i] = 0;
				strP = (Byte*)password;
				i = 0;
				bufOutPtr++;	// skip ':'
			}
			else
			{	*strP++ = *bufOutPtr++;
				i++;
			}
			outBytes--;
		}
		password[i] = 0;
	}
	if (bufOutBlock)
		DisposeBlock(&bufOutBlock);

return noErr;
}

//===========================================================================================
static XErr	_InitRunRecordStuff(BifernoRecP	bRecP, char *serverName, void *userData, char *serverBaseDir, BAPI_OutputFunc outputFunc, char *filePath, BlockRef headInBlock, long headBlockLen)
{
char	*strP;
XErr	err = noErr;

	CEquStr(bRecP->serverName, serverName);
	bRecP->userData = userData;
	CEquStr(bRecP->serverBaseDir, serverBaseDir);
	bRecP->outputFunc = outputFunc;			
	CEquStr(bRecP->mainFilePath, filePath);
	CEquStr(bRecP->curBasePath, filePath);
	if (strP = strrchr(bRecP->curBasePath, '/'))
		bRecP->curBasePath[strP - bRecP->curBasePath + 1] = 0;
	else
		bRecP->curBasePath[0] = 0;
	if (bRecP->userData)
	{	LockBlock(headInBlock);
		err = _UserPassFromHeader(GetPtr(headInBlock), headBlockLen, bRecP->username, bRecP->password);
		UnlockBlock(headInBlock);
	}
	bRecP->curThreads = bRecP->maxThreads = 1;
	
//#ifdef JAVA_ENABLED
//	XThreadsGetThreadInfo(nil, &bRecP->theEnvP);
//#endif

return err;
}

//===========================================================================================
static XErr	_GetForbiddenMessage(BlockRef *resultTextP, long *resultSizeP, Boolean prefixLength)
{
CStr255		simplHead, contStr;
long		totLen, prelen, contLen, headLen;
XErr		err = noErr;
Ptr			p;

	CEquStr(contStr, "<html><body bgcolor=\"white\"><h2>Biferno: Forbidden</h2><p><h3>You are not allowed to read this file</h3></body></html>");
	contLen = CLen(contStr);
	sprintf(simplHead, SIMPLE_HEADER, "", "", "", "", "", "", (int)contLen);
	headLen = CLen(simplHead);
	if (prefixLength)
		prelen = sizeof(long);
	else
		prelen = 0;
	totLen = headLen + contLen;
	if (*resultTextP = NewBlock(prelen + totLen, &err, &p))
	{	if (prelen)
			*(long*)p = XHostToNetwork(totLen);
		CopyBlock(p + prelen, simplHead, headLen);
		CopyBlock(p + prelen + headLen, contStr, contLen);
		*resultSizeP = prelen + totLen;
	}

return noErr;
}

//===========================================================================================
/*
static XErr	_SetAppTreeItemName(long api_data, ObjRecord *appTreeObjRefP, long index)
{
XErr			err = noErr;
ArrayIndexRec	mCoords;
ObjRecord			tObjRef;
CStr63			applName;
long			tLen;
Boolean			isDef;

	tLen = 63;
	if (NOT(err = BAPI_GetConfig(api_data, "APPLICATION_NAME", applName, &tLen, &isDef)) && isDef)
	{	if (*applName)
		{	mCoords.ind = index;
			tObjRef = *appTreeObjRefP;
			//if NOT(err = ResolveArrayElement(api_data, OBJREF_P(&tObjRef), &mCoords, 1, nil, nil, nil, OBJREF_P(&tObjRef), nil))
			err = BAPI_SetArrayElemName(api_data, OBJREF_P(&tObjRef), &mCoords, 1, applName);
		}
	}
	
return err;	
}
*/
//===========================================================================================
static XErr	_IncludeConfigsFile(BifernoRecP	bRecP, BlockRef configFilePathBl, long configFilePathLen, Boolean dontIncludeServer)
{
XErr		err = noErr;
char		*pathP;
int			index;
XFilePath	aCStr;

	if NOT(dontIncludeServer)
	{	GetApplicationPerstPath(bRecP->application.name, nil, aCStr);
		bRecP->currentCtx.defaultScope = PERSISTENT;
		err = IncludeFile((long)bRecP, aCStr, true, nil);
		if (err == XError(kXLibError, ErrXFiles_FileNotFound))
			err = noErr;
	}
	if NOT(err)
	{	if (configFilePathLen && configFilePathBl)
		{	bRecP->currentCtx.defaultScope = APPLICATION;
			bRecP->application.cacheActive = false;
			LockBlock(configFilePathBl);
			pathP = GetPtr(configFilePathBl) + configFilePathLen - 1;	// Note: in config block paths are in reverse order
			bRecP->curFile.dontCache = true;							// dont cache these files
			index = 1;
			do {
				pathP--;				// skip the 0
				configFilePathLen--;
				while(configFilePathLen && *pathP)
				{	pathP--;
					configFilePathLen--;
				}
				err = IncludeFile((long)bRecP, pathP+1, true, nil);
			} while (configFilePathLen && NOT(err));
			if (bRecP->_exit)			// exit in BifernoConfig?
				bRecP->_exit = false;
			UnlockBlock(configFilePathBl);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_AppendFile(BifernoRecP bRecP, Application *applP, XFilePathPtr filePath, XErr *ioErrorP)
{
XErr	err = noErr, errhead = noErr;
char	*tempPathP;

	// Header
	if ((tempPathP = applP->headerFilePath) && *tempPathP)
		errhead = IncludeFile((long)bRecP, tempPathP, false, nil);
	
	// File
	err = IncludeFile((long)bRecP, filePath, false, nil);
		
	// Footer
	if (NOT(errhead) && (tempPathP = applP->footerFilePath) && *tempPathP)
		errhead = IncludeFile((long)bRecP, tempPathP, false, nil);
	
	/*
	if there is an error "IncludeFile" remains on the file calling, so this is to dispose
	*/
	if ((err || errhead) && ioErrorP)
		*ioErrorP = noErr;	// to make caller dispose files
	
return err;
}

//===========================================================================================
static XErr		_RequestAuth(BifernoRecP bRecP, Application *applP, long buffID, Boolean prefixResult)
{
XErr	err = noErr;
char	*tempPathP = applP->acPath;
char	*tempStrP;
long	saveBuff;

	if (prefixResult)
		err = BufferAddLong(buffID, 0);
	if NOT(err)
	{	if NOT(err = BufferAddCString(buffID, NO_ACCESS_STRING_1, NO_ENC, 0))
		{	tempPathP = applP->acRealmName;
			if (*tempPathP)
				tempStrP = tempPathP;
			else
				tempStrP = applP->name;
			if NOT(err = BufferAddCString(buffID, tempStrP, NO_ENC, 0))
			{	if NOT(err = BufferAddCString(buffID, NO_ACCESS_STRING_2, NO_ENC, 0))
				{	saveBuff = bRecP->alternativeBuffer;
					bRecP->alternativeBuffer = buffID;
					if (*applP->acNoAccessPath)
						err = _AppendFile(bRecP, applP, applP->acNoAccessPath, nil);
					else
						BufferAddCString(buffID, NO_ACCESS_MESSAGE, NO_ENC, 0);
					bRecP->alternativeBuffer = saveBuff;
				}
			}
		}
		if (prefixResult)
		{	
		Ptr		p;
		long	size;
		
			BufferGetBlockRefExtSize(buffID, &size, &p);
			*(long*)p = XHostToNetwork(size - 4);
		}
	}

return err;
}

//===========================================================================================
static XErr	_CallBifernoDestructors(BifernoRecP bRecP, Boolean alsoOnGlobals)
{
XErr				err = noErr;
Boolean				saveExit, saveStop; 
BfrDestructRec		destructRec;

	saveExit = bRecP->_exit;
	saveStop = bRecP->currentCtx._stop;
	bRecP->_exit = false;
	bRecP->currentCtx._stop = false;
	destructRec.api_data = (long)bRecP;
	if (bRecP->volatileList)
	{	destructRec.scope = TEMP;
		err = DLM_Loop(bRecP->volatileList, BifernoDestructorCallBack_CheckFlags, (long)&destructRec, true, true);
	}
	if NOT(err)
	{	if (bRecP->localList)
		{	destructRec.scope = LOCAL;
			err = DLM_Loop(bRecP->localList, BifernoDestructorCallBack_CheckFlags, (long)&destructRec, true, true);
		}
		if NOT(err)
		{	if (alsoOnGlobals && bRecP->globalList)
			{	destructRec.scope = GLOBAL;
				err = DLM_Loop(bRecP->globalList, BifernoDestructorCallBack_CheckFlags, (long)&destructRec, true, true);
			}
		}
	}
	bRecP->_exit = saveExit;
	bRecP->currentCtx._stop = saveStop;

return err;
}

//===========================================================================================
static void	_ProcessRunMain(long api_data, Ptr textP, long textLen, Boolean checkPars, XErr *theErrorP)
{
XErr			err = noErr;
BifernoRecP 	bRecP;
int				ch;

	//Compile(api_data, textP, textLen);
	if NOT(bRecP = (BifernoRecP)api_data)
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
	{	bRecP->stackBasePointer = XThreadsGetThreadInfo(&bRecP->stackSize, nil);
		// bRecP->stackBasePointer = (unsigned long)&err;
		ch = *textP;
		ProcessMain(api_data, textP, textLen, checkPars, &err);
		/*if (err && bRecP->stackBufferID)
		{	FillStack(bRecP, nil, bRecP->mainFilePath, bRecP->currentLine, nil, &stackRecord);
			AddStack(bRecP, &stackRecord);
		}*/
		if (theErrorP)
			*theErrorP = err;
	}
}

//===========================================================================================
static XErr _ToFile(Application *applP, XFilePathPtr filePath, BlockRef textBlock, long textBlockLen)
{
XFileRef		fileRef;
XErr			err = noErr, err2 = noErr;

	if (NOT(applP) || (applP->totFilesSaved < applP->maxFilesSaved))
	{	if NOT(err = OpenXFile(filePath, CREATE_FILE_ALWAYS, READ_WRITE_PERM, false, &fileRef))
		{	err = WriteXFile(fileRef, GetPtr(textBlock), &textBlockLen);
			err2 = CloseXFile(&fileRef);
			if (err2 && NOT(err))
				err = err2;
			if (applP)
				applP->totFilesSaved++;
		}
	}

return err;
}

//===========================================================================================
static XErr	_GetOneHeaderField(Ptr headerP, long headerLen, char *fieldName, long *offsetP, long *lenP)
{
XErr		err = noErr;
Boolean		first = true;
Ptr			saveHeaderP, itemP;
long		nameLen, itemLen;
CStr255		name;
char		*nameStr;

	if (headerLen)
	{	itemP = saveHeaderP = headerP;
		itemLen = 0;
		*offsetP = -1;
		*lenP = 0;
		do {
				if ((headerLen > 1) && (*headerP == '\r') && (*(headerP+1) == '\n'))
				{	headerP += 2;
					headerLen -= 2;
					if (first)
						first = false;
					else
					{	if (itemLen)
						{	nameStr = name;
							nameLen = 0;
							do {
								if (itemLen && (*itemP == ':'))
								{	itemP++;
									itemLen--;
									if (itemLen && (*itemP == ' '))
									{	itemP++;
										itemLen--;
									}
									break;
								}
								else if (nameLen < 255)
								{	*nameStr++ = *itemP;
									nameLen++;
								}
								else
									err = XError(kBAPI_Error, Err_BadSyntax);
								itemP++;
								itemLen--;
							} while ((itemLen > 0) && NOT(err));
							if NOT(err)
							{	name[nameLen] = 0;
								if NOT(CCompareStrings(name, fieldName))
								{	*offsetP = itemP - saveHeaderP;
									*lenP = itemLen;
									break;
								}
								else
								{	itemP = headerP;
									itemLen = 0;
								}
							}
						}
					}
				}
				else
				{	headerP++;
					headerLen--;
					itemLen++;
				}
			} while ((headerLen > 0) && NOT(err));
		}
	
return err;
}

//===========================================================================================
static void	_GetHeaderSubField(Ptr fieldP, long fieldLen, char *subName, char *value)
{
long	subNameLen = CLen(subName), tLen, saveFieldLen;
Ptr		saveFieldP;

	if (fieldLen)
	{	*value = 0;
		do {
			if NOT(CompareBlock(fieldP, subName, subNameLen))
			{	fieldP += subNameLen;
				fieldLen -= subNameLen;
				SkipUntilChar(&fieldP, &fieldLen, '=', nil);
				saveFieldP = ++fieldP;
				saveFieldLen = --fieldLen;
				SkipUntilChar(&fieldP, &fieldLen, ';', nil);
				tLen = saveFieldLen - fieldLen;
				if (tLen < 255)
				{	CopyBlock(value, saveFieldP, tLen);
					value[tLen] = 0;
				}
				break;
			}
			else
			{	SkipUntilChar(&fieldP, &fieldLen, ';', nil);
				if (fieldLen && (*fieldP == ';'))
				{	fieldP++;
					fieldLen--;
					SkipSpaceAndTab(&fieldP, &fieldLen);
				}	
			}
		} while (fieldLen > 0);
	}
}

//===========================================================================================
XErr	SendExitEvents(BifernoRecP bRecP, long totRuns)
{
XErr				err = noErr;
long				i, totClass;
uint32_t			slot;
//BlockRef			block;
PluginRecord		*plugRecP;
Biferno_ParamBlock 	*pbPtr;

	if (bRecP->class_thread_dataP)
	{	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
		{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
			plugRecP = gClassRecordBlockP;
			totClass = gsDispatcherData.totClass;
			for (i = 0; i < totRuns/*totClass*/; i++, plugRecP++)
			{	pbPtr->api_data = (long)bRecP;
				pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
				if NOT(bRecP->class_thread_dataP[i].plugin_error_on_run)
					err = CL_Exit(plugRecP, pbPtr);
			}
			PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
		}
	}

return err;
}

//===========================================================================================
XErr	SetScriptCache(BifernoRecP bRecP, CacheResult *cacheResP)
{
	if NOT(SCRIPT_APPLICATION(cacheResP->userDatas))
	{	SCRIPT_APPLICATION(cacheResP->userDatas) = bRecP->applicationObjID;

	}
	
return noErr;
}

//===========================================================================================
XErr	GetScriptCache(BifernoRecP bRecP, CacheResult *cacheResP)
{
	bRecP->applicationObjID = SCRIPT_APPLICATION(cacheResP->userDatas);

return noErr;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	AllocRunRecord(BifernoRecP *bRecPPtr, char *serverName, void *userData, char *serverBaseDir, BAPI_OutputFunc outputFunc, char *filePath, BlockRef headInBlock, long headInBlockLen)
{
BifernoRecP		bRecP;
//BlockRef		block;
uint32_t		slot;
XErr			err = noErr;

	//block = 0;
	*bRecPPtr = nil;
	if NOT(err = PoolNewPtr(gsDispatcherData.bifernoRecPool, (Ptr*)&bRecP, &slot))
	{	ClearBlock(bRecP, sizeof(BifernoRec));
		bRecP->poolSlot = slot;
		bRecP->currentCtx.defaultScope = LOCAL;
		//bRecP->poolBlock = block;
		if (bRecP->stackBufferID = BufferCreate(sizeof(StackRecord), &err))
		{	
			if (bRecP->includeStackBufferID = BufferCreate(sizeof(IncludeStackRecord), &err))
			{	
				// Volatile list
				if NOT(err = DLM_Create(&bRecP->volatileList, ID_LIST, LOCAL_LIST))
				{	
					// Local list
					if NOT(err = DLM_Create(&bRecP->localList, NAMECS_LIST, LOCAL_LIST))
					{	
						BfrMoreStack(bRecP, nil);
						// Global list
						if NOT(err = DLM_Create(&bRecP->globalList, NAMECS_LIST, LOCAL_LIST))
						{	
							// Local classes list
							if NOT(err = DLM_Create(&bRecP->local.classList, NAMECS_LIST, LOCAL_LIST))
							{	
								// Local functions list
								if NOT(err = DLM_Create(&bRecP->local.funcsList, NAMECS_LIST, LOCAL_LIST))
								{	
									// Local function's prototypes list
									//if NOT(err = DLM_Create(&bRecP->local.funcsPrototypesList, ID_LIST, LOCAL_LIST))
										err = _InitRunRecordStuff(bRecP, serverName, userData, serverBaseDir, outputFunc, filePath, headInBlock, headInBlockLen);
								}
							}
						}
					}
				}
			}
		}
		if (err)
		{	
			if (bRecP->stackBufferID)
				BufferFree(bRecP->stackBufferID);
			if (bRecP->includeStackBufferID)
				BufferFree(bRecP->includeStackBufferID);
			if (bRecP->volatileList)
				DLM_Dispose(&bRecP->volatileList, nil, 0);
			if (bRecP->localList)
				DLM_Dispose(&bRecP->localList, nil, 0);
			if (bRecP->globalList)
				DLM_Dispose(&bRecP->globalList, nil, 0);
			if (bRecP->local.classList)
				DLM_Dispose(&bRecP->local.classList, nil, 0);
			if (bRecP->local.funcsList)
				DLM_Dispose(&bRecP->local.funcsList, nil, 0);
			PoolDisposePtr(gsDispatcherData.bifernoRecPool, bRecP->poolSlot);
		}
		else
			*bRecPPtr = bRecP;
	}

return err;
}

// For debug
//#include "HttpPage.h"
//===========================================================================================
XErr	DisposeRunRecord(BifernoRecP bRecP, Application *applP, Boolean checkCFReload, long *lastClassCalledP, char *class_error_note, LONGLONG uniqueid, BlockRef *sessionCSP)
{
XErr			err = noErr, ioErr = noErr;	//, exitErr = noErr;
XErr			err1 = noErr, err2 = noErr, err3 = noErr, err4 = noErr, err5 = noErr, err6 = noErr;	//, err7 = noErr;
long			i, totLocked;
BfrDestructRec	destructRec;

	// Save the persistent list
	if (applP->persistentList)
		ioErr = DLM_SaveList(applP->persistentList);

	destructRec.api_data = (long)bRecP;
	
	// Dispose lists
	destructRec.scope = TEMP;
	err1 = DLM_Dispose(&bRecP->volatileList, VariableDestructor, (long)&destructRec);
	err2 = BfrStackDisposeLocals(bRecP);
	destructRec.scope = GLOBAL;
	err3 = DLM_Dispose(&bRecP->globalList, VariableDestructor, (long)&destructRec);

	destructRec.scope = GLOBAL;
	err5 = DLM_Dispose(&bRecP->local.classList, DisposeBifernoClass, (long)&destructRec);
	err6 = DLM_Dispose(&bRecP->local.funcsList, nil, 0);

	// Close the Session list
	Session_CloseList(bRecP);
		
	// Unlock mutex if needed
	if (bRecP->locked)
	{	totLocked = bRecP->locked;
		for (i = 0; i < totLocked; i++)
			XThreadsLeaveCriticalSectionExt();
	}

	// User command on the Cache and Flush Application
	if (bRecP->closeApp)
	{	if NOT(err = BifernoStop(HTTPControllerLog, bRecP->userData, 1, kReload, uniqueid))
		{	
			if NOT(err = FlushAppWithChildren(bRecP->application.basePath, true, &bRecP->sessionCS))
				err = CFReload();
			BifernoResume();
		}
	}
	else if (bRecP->flushApp)
	{	if NOT(err = BifernoStop(HTTPControllerLog, bRecP->userData, 1, kFlush, uniqueid))
		{
			if NOT(err = FlushAppWithChildren(bRecP->application.basePath, false, &bRecP->sessionCS))
				err = CFReload();
			BifernoResume();
		}
	}
	if (checkCFReload && NOT(gsTryReload) && CFNeedReload())
	{	gsTryReload = true;
		if NOT(err = BifernoStop(HTTPControllerLog, bRecP->userData, 1, kReload, uniqueid))
		{	err = CFReload();
			BifernoResume();
		}
		gsTryReload = false;
	}
	
	// Plugins Run Data
	if (bRecP->class_thread_dataP)
	{	if (gsDispatcherData.threadDataPool)
			PoolDisposePtr(gsDispatcherData.threadDataPool, bRecP->poolThreadDataSlot);
		else
			DisposeBlock(&bRecP->class_thread_dataBlock);
	}
	// Remember last class called and class_error_note
	if (lastClassCalledP)
		*lastClassCalledP = bRecP->lastClassIDErrorCalled;
	if (class_error_note)
		CEquStr(class_error_note, bRecP->class_error_note);
		
	// Stack Trace
	if (bRecP->stackBufferID)
		BufferFree(bRecP->stackBufferID);
	
	// Include Stack Trace
	if (bRecP->includeStackBufferID)
		BufferFree(bRecP->includeStackBufferID);
	
	// printFilterDocBlock
	if (bRecP->printFilterDocBlock)
		DisposeBlock(&bRecP->printFilterDocBlock);
	
	// session critical section?
	if (sessionCSP)
		*sessionCSP = bRecP->sessionCS;
	
	// Dispose BifernoRec
	PoolDisposePtr(gsDispatcherData.bifernoRecPool, bRecP->poolSlot);
	if NOT(err)
	{	if (err1)
			err = err1;
		else if (err2)
			err = err2;
		else if (err3)
			err = err3;
		else if (err4)
			err = err4;
		else if (err5)
			err = err5;
		else if (err6)
			err = err6;
	}
	
return err;
}

//===========================================================================================
XErr	SendRunEvents(BifernoRecP bRecP, BlockRef postBlock, long postBlockLen, BlockRef headInBlock, long headInBlockLen, Boolean shuttingDown, long *totRunsP, Boolean isPost)
{
XErr				err = noErr, errOnHttp = noErr, err2 = noErr;
Biferno_ParamBlock 	*pbPtr;
long				i, totClass;
uint32_t			slot;
Boolean				isDef;
PluginRecord		*plugRecP;
RunRec				*runRecP;
BRunThreadClassRec	*class_thread_dataP;

	bRecP->currentCtx.defaultScope = LOCAL;
	if (gsDispatcherData.threadDataPool)
	{	if NOT(err = PoolNewPtr(gsDispatcherData.threadDataPool, (Ptr*)&bRecP->class_thread_dataP, &bRecP->poolThreadDataSlot))
			ClearBlock(bRecP->class_thread_dataP, sizeof(BRunThreadClassRec) * gsDispatcherData.totClass);
	}
	else if (bRecP->class_thread_dataBlock = NewBlockClear(sizeof(BRunThreadClassRec) * gsDispatcherData.totClass, &err, (Ptr*)&bRecP->class_thread_dataP))
		LockBlock(bRecP->class_thread_dataBlock);
	if NOT(err)
	{	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
		{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
			plugRecP = gClassRecordBlockP;
			totClass = gsDispatcherData.totClass;
			pbPtr->api_data = (long)bRecP;
			runRecP = &pbPtr->param.runRec;
			runRecP->headInBlockLen = headInBlockLen;
			runRecP->headInBlock = headInBlock;
			if (isPost)
			{	runRecP->postBlock = postBlock;
				runRecP->postBlockLen = postBlockLen;
			}
			else
			{	runRecP->postBlock = 0;
				runRecP->postBlockLen = 0;
			}
			runRecP->shuttingDown = shuttingDown;
			class_thread_dataP = &bRecP->class_thread_dataP[0];
			for (i = 0; (i < totClass) && NOT(err); i++, plugRecP++, class_thread_dataP++)
			{	pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
				if (err = CL_Run(plugRecP, pbPtr))
				{	if (plugRecP->pluginID == gsDispatcherData.httpPageConstructor)
					{	if (err == XError(kBAPI_Error, Err_CookieDisabled))	// should never happen (throwed only by bifernoadmin redir or deny)
						{	errOnHttp = err;
							err = noErr;
						}
						else
							break;
					}
					else
					{	class_thread_dataP->plugin_error_on_run = err;
						err = noErr;
					}
				}
			}
			*totRunsP = i;
			if NOT(err)
			{	bRecP->lastClassIDErrorCalled = 0;
				if NOT(err = BAPI_IsVariableDefined((long)bRecP, "pageOut", GLOBAL, &isDef, OBJREF_P(&bRecP->pageOutObjRef)))
				{	if NOT(isDef)
						err = XError(kBAPI_Error, Err_PageOutNotDefined);
					else
						err = errOnHttp;
				}
			}
			PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
			err2 = UpdateErrObject((long)bRecP, err, &bRecP->globErrObjRef, nil);
			if (err2 && NOT(err))
				err = err2;
		}
	}
	
return err;
}

//===========================================================================================
static Boolean	_GeneralSecurity(char *filePath, BlockRef *resultTextP, long *resultSizeP, Boolean prefixLength, XErr *errP)
{
char		*strP;
long		filePathLen;
XFilePath	tStr;
Boolean		res = false;

	// Cant' serve Biferno.config.bfr
	if (strP = strrchr(filePath, '/'))
	{	CEquStr(tStr, strP);
		CUp2LowerStr(tStr, 0);
		if NOT(CCompareStrings("/biferno.config.bfr", tStr))
			res = true;
	}
	// Cant' serve .s.bfr and .s.bfr
	filePathLen = CLen(filePath);
	strP = filePath + filePathLen - 6;
	CEquStr(tStr, strP);
	CUp2LowerStr(tStr, 0);
	if (NOT(CCompareStrings_cs(tStr, ".s.bfr")) || NOT(CCompareStrings_cs(tStr, ".x.bfr")))
		res = true;

	if (res)
		*errP = _GetForbiddenMessage(resultTextP, resultSizeP, prefixLength);
	else
		*errP = noErr;
	
return res;
}

//===========================================================================================
static Boolean	_ApplicationSecurity(BifernoRecP bRecP, char *filePath, BlockRef *resultTextP, long *resultSizeP, XErr *errP)
{
char		*errFolderP = bRecP->application.errorFolder;
long		tLen;
Boolean		res = false;
CStr255		tPath;

	CEquStr(tPath, filePath);
	CheckPath(tPath, true);
	tLen = CLen(errFolderP);
	if (tLen && NOT(CompareBlock(errFolderP, tPath, tLen)))
	{	*errP = _GetForbiddenMessage(resultTextP, resultSizeP, bRecP->prefixLengthInResult);
		res = true;
	}
	else
	{	*errP = noErr;
		res = false;
	}
	
return res;
}

//===========================================================================================
static XErr	_FindAppl(BifernoRecP bRecP, char *filePath, BlockRef *configFilePathBlP, long *configFilePathLenP, CacheResult *cacheP)
{
XErr	err = noErr;

	if (cacheP && cacheP->wasInCache && SCRIPT_APPLICATION(cacheP->userDatas))
	{	*configFilePathBlP = 0L;
		GetScriptCache(bRecP, cacheP);
		//bRecP->applicationObjID = SCRIPT_APPLICATION(cacheP->userDatas);
		// CEquStr(bRecP->application.name, cacheP->userDataStr);
	}
	else
	{	if NOT(err = ScanTreeForConfig(filePath, configFilePathBlP, configFilePathLenP, bRecP->application.name, bRecP->application.basePath, false))
		{	if (*bRecP->application.name)
				bRecP->applicationObjID = DLM_GetObjID(gsDispatcherData.globApplicationListArray, bRecP->application.name, nil, nil);
			else
				err = XError(kBAPI_Error, Err_BadSyntaxInApplicationName);
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_GetTheApplication(BifernoRecP bRecP, BlockRef *configFilesBlockP, long configFilesBlockLen, Boolean *applicationInitFailedP, Boolean *toCloseP)
{
XErr		err = noErr, err2 = noErr;
Boolean		dontIncludeServer, applicationFirstTime;
CStr255		errorFilePath;
long		savebuff;//, aLong;

	*toCloseP = false;
	if NOT(err = GetApplication(bRecP, bRecP->application.name, &bRecP->applicationObjID, bRecP->application.basePath, *configFilesBlockP, /*configFilesBlockLen, */&applicationFirstTime, &dontIncludeServer, errorFilePath))
	{	*toCloseP = true;

		if (*configFilesBlockP && applicationFirstTime)
		{	
			DLM_SetGlobalOk(true);
			savebuff = bRecP->alternativeBuffer;
			bRecP->alternativeBuffer = -1;		// no output
			err = _IncludeConfigsFile(bRecP, *configFilesBlockP, configFilesBlockLen, dontIncludeServer);
			// if err Update anyway in order to show a better error
			err2 = UpdateApplicationRec(bRecP);
			if (NOT(err) && err2)
				err = err2;
			bRecP->alternativeBuffer = savebuff;
			DLM_SetGlobalOk(false);
		}
		if NOT(err)
		{	if NOT(err = BAPI_SetNumberFormat((long)bRecP, bRecP->application.thousSep, bRecP->application.decSep))
				err = BAPI_SetTimeout((long)bRecP, bRecP->application.timeOut);
		}
	}
	if (err)
		*applicationInitFailedP = bRecP->applicationInitFailed = true;
	else
		*applicationInitFailedP = false;
	if (*configFilesBlockP)
		DisposeBlock(configFilesBlockP);
	
return err;
}

//===========================================================================================
static XErr	_CloseApplication(BifernoRecP bRecP)
{
XErr	err = noErr;

	err = CloseApplication(&bRecP->application, true, nil, 0, &bRecP->sessionCS);
	ClearBlock(&bRecP->application, sizeof(Application));
	
return err;
}

//===========================================================================================
static Boolean	_ApplicationAdmin(BifernoRecP bRecP, BlockRef headInBlock, long headInBlockLen, XErr *errP, XErr *ioErrorP)
{
XErr		err = noErr;
Ptr			tempP, strP;
Boolean		isAdmin = false;
XFilePath	tempStr, filePath;
int			i;

	if (headInBlock)
	{	tempP = GetPtr(headInBlock);
		if (strP = strchr(tempP, '/'))
		{	headInBlockLen -= (strP-tempP);
			if (headInBlockLen)
			{	i = 0;
				do {
					if (NOT(isAdmin) && (headInBlockLen >= BADMIN_FOLDER_LEN) && NOT(CompareBlock(strP, BADMIN_FOLDER, BADMIN_FOLDER_LEN)))
					{	strP += BADMIN_FOLDER_LEN;
						headInBlockLen -= BADMIN_FOLDER_LEN;
						CEquStr(tempStr, BADMIN_FOLDER);
						isAdmin = true;
						if ((headInBlockLen && (*strP == ' ')) || ((headInBlockLen > 1) && (*(short*)strP == SLASH_SPACE)))
						{	i = BADMIN_FOLDER_LEN + BADMIN_INDEX_LEN;
							CAddStr(tempStr, BADMIN_INDEX);
							break;
						}
						else
							i = BADMIN_FOLDER_LEN;
					}
					else if (headInBlockLen && (*strP == ' '))
						break;
					tempStr[i++] = *strP++;
					headInBlockLen--;
				} while((headInBlockLen > 0) && (i < 255) && (*strP != '?'));
				tempStr[i] = 0;
			}
			if (isAdmin)
			{	CStr255		redirForCookiesPage, denyForCookiesPage;
			
				if NOT(err = XGetApplicationFolderPath(filePath))
				{	CEquStr(redirForCookiesPage, filePath);
					CAddStr(redirForCookiesPage, BIFERNO_REDIR + 1);
					CEquStr(denyForCookiesPage, filePath);
					CAddStr(denyForCookiesPage, BIFERNO_DENY + 1);
					CAddStr(filePath, tempStr);
					CEquStr(bRecP->curBasePath, filePath);
					if (strP = strrchr(bRecP->curBasePath, '/'))
						bRecP->curBasePath[strP - bRecP->curBasePath + 1] = 0;
					else
						bRecP->curBasePath[0] = 0;
					if NOT(err)
					{	if NOT(CCompareStrings(filePath, redirForCookiesPage))
						{	if NOT(CheckPath(filePath, false))
								err = CFGetFile(filePath, &bRecP->curFile);
							else
								err = CFGetFileSpecial(filePath, &bRecP->curFile, gsRedirFileText);
						}
						else if NOT(CCompareStrings(filePath, denyForCookiesPage))
						{	if NOT(CheckPath(filePath, false))
								err = CFGetFile(filePath, &bRecP->curFile);
							else
								err = CFGetFileSpecial(filePath, &bRecP->curFile, gsDenyFileText);
						}
						else
							err = CFGetFile(filePath, &bRecP->curFile);
						if (err)
							*ioErrorP = err;
						else
							bRecP->curFile.dontCache = true;
					}
				}
			}
		}
	}
	if (err)
		isAdmin = false;
	*errP = err;
			
return isAdmin;
}

//===========================================================================================
static Boolean		_ApplicationControlAccess(BifernoRecP bRecP, BlockRef *blockOutP, long *blockOutLenP, Boolean isLocalFile, Boolean prefixResult, XErr *errP)
{
XErr			err = noErr;
Application		*applP = &bRecP->application;
char			*tempPathP = applP->acPath;
long			saveBuff;
Boolean			promptUser;
Boolean			saveExit, *_exitP = &bRecP->_exit;
BfrDestructRec	destructRec;

	promptUser = false;
	*blockOutLenP = 0;
	saveExit = *_exitP;
	*_exitP = false;
	if (*tempPathP)
	{	if (NOT(isLocalFile) && (saveExit == false))	// if _exit is true, someone exited (a session try redirect happened?)
		{	if (*bRecP->username)
			{	saveBuff = bRecP->alternativeBuffer;
				bRecP->alternativeBuffer = -1;
				err = IncludeFile((long)bRecP, tempPathP, false, nil);
				bRecP->alternativeBuffer = saveBuff;
				if NOT(err)
				{	if (*_exitP)
						promptUser = true;
					else
					{	_CallBifernoDestructors(bRecP, false);
						destructRec.api_data = (long)bRecP;
						destructRec.scope = TEMP;
						DLM_ResetList(bRecP->volatileList, VariableDestructorExt, (long)&destructRec, 0, false);
						destructRec.scope = LOCAL;
						DLM_ResetList(bRecP->localList, VariableDestructorExt, (long)&destructRec, 0, false);
						promptUser = false;
					}
				}
			}
			else
				promptUser = true;
			if (NOT(err) && promptUser)
			{	
			long	id;
				
				if (id = BufferCreate(255, &err))	
				{	if (*_exitP)
						*_exitP = false;
					if NOT(err = _RequestAuth(bRecP, applP, id, prefixResult))
					{	*blockOutP = BufferGetBlockRef(id, blockOutLenP);
						LockBlock(*blockOutP);
						BufferClose(id);
					}
					else
					{	BufferFree(id);
						*_exitP = true;		// just in case
					}
				}
			}
		}
	}
	*_exitP = saveExit;
	*errP = err;
	
return NOT(promptUser);
}

//===========================================================================================
static XErr	_GetInputParameters(BifernoRecP bRecP, BlockRef *bodyBlockP, long bodyBlockLen, char *contentType, XErr errOnInput)
{
	ObjRecord		objRef;
	XErr			err = noErr;
	long			totInputs;
	StackRecord		*stackP;
	
	if (errOnInput)
		err = UpdateErrObject((long)bRecP, errOnInput, &objRef, nil);
	else
	{
		if (err = GetInputParameters((long)bRecP, bodyBlockP, bodyBlockLen, contentType))
			bRecP->errGettingInputParameters = true;
	}
	if not(err)
	{
		if not(err = DLM_GetTotObjs(bRecP->localList, &totInputs, false))
		{
			if (stackP = BfrGetIndStack(bRecP, 0))
				stackP->totInputs = totInputs;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_ProcessScript(BifernoRecP bRecP, Boolean isAdmin)
{
XErr	err = noErr;
char	*tempPathP;

	if (err = BAPI_GetBooleanConfig((long)bRecP, "COMPILER", &bRecP->application.compilerActive, nil))
		return err;
	if COMPILING(bRecP)
		err = BIC_Init((long)bRecP);
	if NOT(err)
	{	// Some Init
		// bRecP->startTicks = XGetTicksExt(&bRecP->startTicksTV, &bRecP->startTimeB);
		bRecP->startTicks = XGetTicks();
		
		// Header
		if (NOT(isAdmin) && (tempPathP = bRecP->application.headerFilePath) && *tempPathP)
			err = IncludeFile((long)bRecP, tempPathP, false, nil);
		if NOT(err)
		{	// Main
			_ProcessRunMain((long)bRecP, GetPtr(bRecP->curFile.fileData), bRecP->curFile.fileSize, true, &err);
			// Footer
			if (NOT(isAdmin) && NOT(err) && (tempPathP = bRecP->application.footerFilePath) && *tempPathP)
				err = IncludeFile((long)bRecP, tempPathP, false, nil);
		}
		if COMPILING(bRecP)
		{	if NOT(err)
				err = BIC_PostProcess((long)bRecP);
		}
	}
		
return err;
}

//===========================================================================================
static void	_ErrorOnDisc(BifernoRec *bRecP, char *errFoldP, char *ipAddress, BlockRef completeErrorBlock, long completeErrorBlockLength, char *note)
{
XErr		err = noErr;
//XFilePath	tempFilePath;
//long		filePathLen;

	*note = 0;
	if (errFoldP && *errFoldP)
	{	unsigned long	millisecs;
		long			filePathLen, errValue;
		CStr255			subErrStr;
		XFilePath		tempFilePath;
		CStr15			tStr;
		
		CEquStr(tempFilePath, errFoldP);
		filePathLen = CLen(tempFilePath);
		if (tempFilePath[filePathLen-1] != '/')
			CAddChar(tempFilePath, '/');
		// ip address
		CEquStr(note, ipAddress);
		CAddChar(note, '.');
		// milliseconds
		XGetMilliseconds(&millisecs);
		CNumToString(millisecs, tStr);
		CAddStr(note, tStr);
		CAddStr(tempFilePath, note);
		CAddStr(tempFilePath, ".err.bfr");
		if (bRecP)
			err = _ToFile(nil, tempFilePath, completeErrorBlock, completeErrorBlockLength);
		else
			err = _ToFile(&bRecP->application, tempFilePath, completeErrorBlock, completeErrorBlockLength);
		if (err)
		{	Err2BAPIErr((long)bRecP, &err, subErrStr);
			CEquStr(note, "[");
			XErrorGetTypeValue(err, &errValue, nil);
			CNumToString(errValue, tempFilePath);
			CAddStr(note, tempFilePath);
			CAddChar(note, ' ');
			BAPI_GetErrDescription((long)bRecP, err, tempFilePath, nil, nil, nil, nil, 0, nil);
			CAddStr(note, tempFilePath);
			CAddChar(note, ')');
			if (*subErrStr)
				CAddStr(note, subErrStr);
			CAddChar(note, ']');
			err = noErr;
		}
	}
	else
		CEquStr(note, "[No Errors Folder]");
}

//===========================================================================================
static XErr	_IncludeErrorPage(BifernoRec *bRecP, XErr theError, char *fileToInclude, BlockRef headInBlock, long headBlockLen, Boolean isLocalFile, BlockRef *resultTextP, long *resultSizeP, XErr *ioErrorP, XErr *localResultErrP)
{
XErr			err = noErr;
long			id;
long			api_data = (long)bRecP;
//ObjRecord		errRef;
//Boolean			exists;

	if (id = BufferCreate(255, &err))
	{	long			saveBuff;
		long			saveLastClassIDErrorCalled, saveVisibilityClass, saveBisFunctionInitLine, saveMethodInExecutionClass, saveMethodInExecutionID;
		
		if NOT(bRecP->errUpdated)
			CheckIfResume(api_data, theError, nil, nil);

		saveBuff = bRecP->alternativeBuffer;
		saveMethodInExecutionClass = bRecP->methodInExecutionClass;
		saveVisibilityClass = bRecP->visibilityClass;
		saveMethodInExecutionID = bRecP->currentCtx.methodInExecutionID;
		saveBisFunctionInitLine = bRecP->currentCtx.bisFunctionInitLine;
		saveLastClassIDErrorCalled = bRecP->lastClassIDErrorCalled;
		
		bRecP->alternativeBuffer = id;
		bRecP->methodInExecutionClass = 0;
		bRecP->visibilityClass = 0;
		bRecP->currentCtx.methodInExecutionID = 0;
		bRecP->currentCtx.bisFunctionInitLine = 0;
		bRecP->inDebugPage = true;
		bRecP->lastClassIDErrorCalled = 0;

		//	err = XError(kBAPI_Error, Err_LabelNotFound);
		//if NOT(err = BAPI_IsVariableDefined(api_data, "err", GLOBAL, &exists, OBJREF_P(&errRef)))
		{	//if NOT(err = error_UpdateEMsgRecord((long)bRecP, OBJREF_P(&errRef)))
			{	BAPI_ResetError(api_data);
				*bRecP->class_error_note = 0;
				*bRecP->curLabelName = 0;
				bRecP->_break = false;
				err = IncludeFile((long)bRecP, fileToInclude, false, DEBUG_FUNCTION_NAME);
			}
		}
		bRecP->inDebugPage = false;
		if (localResultErrP && err)
			*localResultErrP = err;
		if NOT(err)
		{	bRecP->methodInExecutionClass = saveMethodInExecutionClass;
			bRecP->visibilityClass = saveVisibilityClass;
			bRecP->currentCtx.methodInExecutionID = saveMethodInExecutionID;
			bRecP->currentCtx.bisFunctionInitLine = saveBisFunctionInitLine;
			bRecP->lastClassIDErrorCalled = saveLastClassIDErrorCalled;
		}
		bRecP->alternativeBuffer = saveBuff;
		if (err)
		{	BufferFree(id);
			_GetErrorPage(bRecP, resultTextP, resultSizeP, nil, err, isLocalFile, headInBlock, headBlockLen, AVOID_CUSTOM_ERR_PAGE, ioErrorP, localResultErrP, false, 0, nil, true);
			err = noErr;
		}
		else
		{	*resultTextP = BufferGetBlockRef(id, resultSizeP);
			BufferClose(id);
		}
	}

return err;
}

//===========================================================================================
static XErr	_AddAsBase64(long buffID, BlockRef blockIn, long blockInLength, Boolean htmlToText)
{
XErr		err = noErr;
BlockRef 	encBlock;
long 		encBlockLength;
//Ptr			encBlockP;
BlockRef	simpleTextBlock;
long		simpleTextLength;
Ptr			simpleTextPtr;

	simpleTextBlock = 0;
	if (htmlToText)
	{	if (simpleTextBlock = NewBlockLocked(blockInLength, &err, &simpleTextPtr))
		{	CopyBlock(simpleTextPtr, GetPtr(blockIn), blockInLength);
			simpleTextLength = blockInLength;
			if NOT(err = HTML2Txt(&simpleTextBlock, &simpleTextLength, false))
			{	blockInLength = simpleTextLength;
				blockIn = simpleTextBlock;
			}
		}
	}
	if NOT(err)
	{	if NOT(err = HTUU_encodeExt(GetPtr(blockIn), blockInLength, &encBlock, &encBlockLength, 48))
			err = BufferAddBuffer(buffID, GetPtr(encBlock), encBlockLength);
		DisposeBlock(&encBlock);
	}
	if (simpleTextBlock)
		DisposeBlock(&simpleTextBlock);
		
return err;
}

//===========================================================================================
/*
Message-ID: [inventato]\r\n
User-Agent: Biferno STMP\r\n
Date: GMT\r\n
Subject: \r\n
From: \r\n
To: \r\n
Mime-version: 1.0\r\n
Content-type: multipart/alternative;\r\n\tboundary=\"BIFERNO_MIME_Part\"\r\n
--BIFERNO_MIME_Part\r\n\r\n
Content-type: text/plain;\r\n charset=\"us-ascii\"; format=flowed\r\n
Content-transfer-encoding: quoted-printable\r\n\r\n
unavailable
--BIFERNO_MIME_Part\r\n
Content-type: text/html; charset=\"us-ascii\"\r\n
Content-transfer-encoding: quoted-printable\r\n\r\n
mailTextInHtml.Substitute("=", "=3D") + "\r\n\r\n
--BIFERNO_MIME_Part\r\n
		if attachment
Content-Type: text/html; name="[file_name]" 
Content-Transfer-Encoding: base64 
Content-Disposition: attachment; filename="[file_name]" 
--BIFERNO_MIME_Part--\r\n\r\n
*/
static XErr	_SendErrorMail(long api_data, XErr theError, char *host, char *fromaddress, char *toaddress, BlockRef textBlock, long textLen, char *filePath, unsigned long minutes, char *webHostName, Boolean asAttachment, char *resultString)
{
long			buffID;
XErr			err = noErr;
unsigned long	millisecs, secs;
CStr255			magicBoundaryString, aCStr, tStr;
BlockRef		block;
long			eNum, blockLen, eFileLineNum;
XDateTimeRec	xdtRec;
CStr255			eNameStr, eFilePath;
char			*strP;
BifernoRecP		bRecP = (BifernoRecP)api_data;
	
	if (buffID = BufferCreate(255, &err))
	{	// To
		CEquStr(aCStr, "To: ");
		CAddStr(aCStr, toaddress);
		CAddStr(aCStr, "\r\n");
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		// From
		CEquStr(aCStr, "From: ");
		CAddStr(aCStr, fromaddress);
		CAddStr(aCStr, "\r\n");
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		// Date
		CEquStr(aCStr, "Date: ");
		XGetSeconds(&secs);
		SecondsToXDateTime(secs, &xdtRec);
		XDateTimeToGMT(&xdtRec);
		GetUString(&xdtRec, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, "\r\n");
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		
		// Subject
		if (bRecP->errGettingInputParameters)
			CEquStr(aCStr, "Subject: Biferno bad url: ");
		else
			CEquStr(aCStr, "Subject: Biferno error: ");
		CAddStr(aCStr, webHostName);
		BAPI_GetErrDescription(api_data, theError, eNameStr, nil, nil, nil, nil, bRecP->lastClassIDErrorCalled, nil);
		BAPI_GetCurrentFilePath(api_data, eFilePath, &eFileLineNum, nil, nil);
		if (strP = strrchr(eFilePath, '/'))
			++strP;
		else
			strP = eFilePath;
		if (eFileLineNum)
			sprintf(tStr, " (%s line %d of %s)", eNameStr, eFileLineNum, strP);
		else
			sprintf(tStr, " (%s on %s)", eNameStr, strP);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, "\r\n");
		if (err = BufferAddCString(buffID, aCStr, NO_ENC, 0))
			goto out;
		// User-agent
		if (err = BufferAddCString(buffID, "User-Agent: Biferno SMTP\r\n", NO_ENC, 0))
			goto out;
		// Mime-version
		if (err = BufferAddCString(buffID, "Mime-version: 1.0\r\n", NO_ENC, 0))
			goto out;
		
		if (bRecP->errGettingInputParameters)
		{
			if (err = BufferAddCString(buffID, "\r\n", NO_ENC, 0))
				goto out;
			// only pageIn
			if NOT(err = HTTPControllerGetFullRequest(bRecP->userData, &block, &blockLen))
			{
				// header
				err = BufferAddBuffer(buffID, GetPtr(block), blockLen);
				DisposeBlock(&block);
				// body (POST)
				if not(err = HTTPControllerGetPostArgs(bRecP->userData, &block, &blockLen))
				{	
					if (blockLen)
					{
						Boolean			addPeriod;
						if (blockLen > (1024L * 1024L * 4))		// 4 Mb
						{
							blockLen = 10;
							addPeriod = true;
						}
						else
							addPeriod = false;
						err = BufferAddBuffer(buffID, GetPtr(block), blockLen);
						if (addPeriod)
						{	
							if (err = BufferAddCString(buffID, "...", NO_ENC, 0))
								goto out;
						}
					}
					DisposeBlock(&block);
				}
			}
		}
		else
		{
			// Content-type
			if (asAttachment)
				err = BufferAddCString(buffID, "Content-type: multipart/mixed; boundary=\"", NO_ENC, 0);
			else
				err = BufferAddCString(buffID, "Content-type: multipart/alternative; boundary=\"", NO_ENC, 0);
			if (err)
				goto out;
			XGetMilliseconds(&millisecs);
			sprintf(magicBoundaryString, "%d_%s_%d", (int)millisecs, "ABFR_BIFERNO_MIME_PART_25_FF", (int)millisecs);
			if (err = BufferAddCString(buffID, magicBoundaryString, NO_ENC, 0))
				goto out;		
			if (err = BufferAddCString(buffID, "\"\r\n\r\nThis is a multi-part message in MIME format.", NO_ENC, 0))
				goto out;		
			// Boundary
			if (err = BufferAddCString(buffID, "\r\n\r\n--", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, magicBoundaryString, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "\r\n", NO_ENC, 0))
				goto out;
			if (asAttachment)
			{
			BlockRef	encBlock;
			long		encBlockLength;
			
			
				// Plain message
				if (err = BufferAddCString(buffID, "Content-type: text/plain; charset=us-ascii\r\n", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, "Content-transfer-encoding: base64\r\n\r\n", NO_ENC, 0))
					goto out;
				XErrorGetTypeValue(theError, &eNum, nil);
				sprintf(aCStr, "Script error (%d) on site '%s'.\r\nSee attached file for details:\r\n\r\n", eNum, webHostName);
				if NOT(err = HTUU_encodeExt(aCStr, CLen(aCStr), &encBlock, &encBlockLength, 48))
				{	
					err = BufferAddBuffer(buffID, GetPtr(encBlock), encBlockLength);
					DisposeBlock(&encBlock);
				}
				if (err)
					goto out;
				// Boundary
				if (err = BufferAddCString(buffID, "\r\n\r\n--", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, magicBoundaryString, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, "\r\n", NO_ENC, 0))
					goto out;
				// Attachment
				if (err = BufferAddCString(buffID, "Content-type: text/html; name=\"BifernoError.html\"\r\n", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, "Content-transfer-encoding: base64\r\n", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, "Content-Disposition: attachment; filename=\"BifernoError.html\"\r\n\r\n", NO_ENC, 0))
					goto out;
				if (err = _AddAsBase64(buffID, textBlock, textLen, false))
					goto out;
			}
			else
			{	// Plain
				if (err = BufferAddCString(buffID, "Content-type: text/plain; charset=us-ascii\r\n", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, "Content-transfer-encoding: base64\r\n\r\n", NO_ENC, 0))
					goto out;
				if (err = _AddAsBase64(buffID, textBlock, textLen, true))
					goto out;
				// Boundary
				if (err = BufferAddCString(buffID, "\r\n\r\n--", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, magicBoundaryString, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, "\r\n", NO_ENC, 0))
					goto out;
				// HTML
				if (err = BufferAddCString(buffID, "Content-type: text/html; charset=us-ascii\r\n", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, "Content-transfer-encoding: base64\r\n\r\n", NO_ENC, 0))
					goto out;
				if (err = _AddAsBase64(buffID, textBlock, textLen, false))
					goto out;
			}
			// End Boundary
			if (err = BufferAddCString(buffID, "\r\n\r\n--", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, magicBoundaryString, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(buffID, "--\r\n", NO_ENC, 0))
				goto out;
		}
	
		// Send
		block = BufferGetBlockRef(buffID, &blockLen);
		if NOT(err = SetBlockSize(block, blockLen))		// to shrink
			err = SendAsyncronousMail(api_data, host, fromaddress, nil, toaddress, block, blockLen, filePath, minutes, resultString);
		
	out:	
		BufferFree(buffID);
	}

return err;
}

//===========================================================================================
static void	_GetErrorPage(BifernoRec *bRecP, BlockRef *resultTextP, long *resultSizeP, XFilePathPtr filePath, XErr theError, Boolean isLocalFile, BlockRef headInBlock, long headBlockLen, Boolean avoidErrPage, XErr *ioErrorP, XErr *localResultErrP, Boolean prefixLength, long lastClassIDErrorCalled, char *class_error_note, Boolean noHeader)
{
CStr255		moreErrStr, host, note, ipAddress, devIPStr, aCStr;
Boolean		full;
XErr		err = noErr;
long		ipAddressLen, devIPStrLen;
Boolean		notifyMail, administrator = false;
char		*devStrP, *errFoldP;
int			encodeMode;
long		api_data = (long)bRecP;
char		*webMastStr, *mailHostStr, *appName;
Application	*appP;

	if (localResultErrP)
		*localResultErrP = theError;
	if (bRecP && bRecP->criticalMem)
		BEngineAPI_Emergency(bRecP->userData);
	if (bRecP && COMPILING((long)bRecP))
		BIC_End((long)bRecP);
		
	if (bRecP)
	{	appP = &bRecP->application;
		webMastStr = appP->webMaster;
		mailHostStr = appP->mailHost;
		notifyMail = appP->notifyMail;
		appName = appP->name;
		HTTPControllerGetServerParam(bRecP->userData, kServerDomain, host, nil);
	}
	else
	{	appP = nil;
		webMastStr = nil;
		mailHostStr = nil;
		appName = nil;
		notifyMail = false;
		*host = 0;
	}
	
	*devIPStr = *moreErrStr = 0;
	*ipAddress = 0;
	full = false;
	if (isLocalFile)
		encodeMode = NO_ENC;
	else
		encodeMode = ISOLATIN_ENC;
	if (bRecP)
	{	if (err = HTTPControllerGetIPAddress(bRecP->userData, ipAddress))
			*ipAddress = 0;
		if NOT(*ipAddress)	// local files
			CEquStr(ipAddress, "local");
		CEquStr(devIPStr, appP->devIP);
		lastClassIDErrorCalled = bRecP->lastClassIDErrorCalled;
		errFoldP = appP->errorFolder;
	}
	else
	{	//lastClassIDErrorCalled = 0;
		*devIPStr = 0;
		errFoldP = nil;
	}
	if (ipAddressLen = CLen(ipAddress))
	{	devStrP = devIPStr;
		devIPStrLen = CLen(devStrP);
		SkipSpaceAndTab(&devStrP, &devIPStrLen);
		full = StringInText(ipAddress, ipAddressLen, devStrP, devIPStrLen, ',');
	}
	else
		full = true;	// note that this cauese local script to be "full"
	
	if (NOT(full) && headInBlock && bRecP && *appP->adminPassword)
	{	Ptr		p;
		long	tOffset, tLen;
	
		LockBlock(headInBlock);
		if NOT(err = _GetOneHeaderField(p = GetPtr(headInBlock), headBlockLen, "Cookie", &tOffset, &tLen))
		{	if (tOffset >= 0)
			{	p += tOffset;
				CEquStr(devIPStr, "ADMIN_PASSWORD");
				CAddChar(devIPStr, '_');
				CAddStr(devIPStr, appP->name);
				CSubstitute(devIPStr, ' ', '_');
				_GetHeaderSubField(p, tLen, devIPStr, aCStr);
				if NOT(CCompareStrings_cs(aCStr, appP->adminPassword))
				{	full = true;
					administrator = true;
				}
			}
		}
		UnlockBlock(headInBlock);
	}
	
	if (full)
	{	/**
		*	NOOO If the script is runned locally, then always the error page (if available)
		*	is showed, else show the complete error
		*/
		// if the user defined a custom debug page return it
		if (bRecP && NOT(isLocalFile) && *appP->debugPagePath && NOT(avoidErrPage))
			err = _IncludeErrorPage(bRecP, theError, appP->debugPagePath, headInBlock, headBlockLen, isLocalFile, resultTextP, resultSizeP, ioErrorP, localResultErrP);
		else
			err = GetHtmlError((long)bRecP, theError, resultTextP, resultSizeP, filePath, lastClassIDErrorCalled, class_error_note, encodeMode, ipAddress, administrator);
	}
	else
	{	
	BlockRef	completeErrorBlock = nil;
	long		completeErrorBlockLength = 0;
	Boolean		canSendMail = false;
	CStr255		mailPath, errMessage;
	
		// get the complete error
		if (bRecP && *appP->debugPagePath && NOT(avoidErrPage))
			err = _IncludeErrorPage(bRecP, theError, appP->debugPagePath, headInBlock, headBlockLen, isLocalFile, &completeErrorBlock, &completeErrorBlockLength, ioErrorP, localResultErrP);
		else
			err = GetHtmlError((long)bRecP, theError, &completeErrorBlock, &completeErrorBlockLength, filePath, lastClassIDErrorCalled, class_error_note, encodeMode, ipAddress, administrator);
		if NOT(err)
		{	if (webMastStr && *webMastStr && mailHostStr && *mailHostStr && notifyMail)
				canSendMail = true;
			// if there is an error page, show it
			if (bRecP && *appP->errPagePath && NOT(avoidErrPage))
				err = _IncludeErrorPage(bRecP, theError, appP->errPagePath, headInBlock, headBlockLen, isLocalFile, resultTextP, resultSizeP, ioErrorP, localResultErrP);
			else
			{	/*
				*	If there is not an error page defined, a little message is shown to the user.
				*	A file is also written to the disc (if no sendmail is possible)
				*/
				if (canSendMail)
					*note = 0;
				else
					_ErrorOnDisc(bRecP, errFoldP, ipAddress, completeErrorBlock, completeErrorBlockLength, note);
				err = GetUserHtmlError((long)bRecP, theError, resultTextP, resultSizeP, lastClassIDErrorCalled, note, host, appName);
			}
			/**
			*	Here, if WEBMASTER send error to WEBMASTER
			*/
			if (canSendMail)
			{	// Create folder "BifernoSpool" if needed
				CEquStr(mailPath, gBifernoSpoolPath);
				err = BAPI_RealPath(0, mailPath, true);
				if ((err == XError(kXLibError, ErrXFiles_FolderNotFound)) || (err == XError(kXLibError, ErrXFiles_FileNotFound)))
					err = CreateXFolder(mailPath);
				// now send
				if NOT(err)
				{
					CEquStr(mailPath, gBifernoSpoolPath);		// reload in local otherwise problems with sendmail multithread
					if (err = _SendErrorMail(api_data, theError, mailHostStr, appP->fromMail, webMastStr, completeErrorBlock, completeErrorBlockLength, mailPath, 10, host, true, errMessage))
					{	
						sprintf(moreErrStr, "<br><i>Error sending mail: %d</i>", (int)err);
						err = noErr;
					}
				}
			}
			DisposeBlock(&completeErrorBlock);
		}
	}

	if (NOT(err) && NOT(isLocalFile))
	{	
	long		simplHeadLen;
	Ptr			p;
	char		simplHead[1024];
	CStr31		tStr;
	long		moreErrStrLen, totLen, prelen;
		
		moreErrStrLen = CLen(moreErrStr);
		if (noHeader)
		{	simplHeadLen = 0;
			*simplHead = 0;
		}
		else
		{	if (bRecP && bRecP->SID && bRecP->sessionFirstTime && bRecP->setNewSID)
			{	CLongNumToString(bRecP->XID, tStr);
				sprintf(simplHead, SIMPLE_HEADER, "Set-Cookie: BIFERNO_SID=", bRecP->SID, ";\r\n", "Set-Cookie: BIFERNO_XID=", tStr, ";\r\n", (int)(*resultSizeP + moreErrStrLen));
			}
			else 
				sprintf(simplHead, SIMPLE_HEADER, "", "", "", "", "", "", (int)(*resultSizeP + moreErrStrLen));
			simplHeadLen = CLen(simplHead);
		}
		if (prefixLength)
			prelen = sizeof(long);
		else
			prelen = 0;
		totLen = *resultSizeP + simplHeadLen + moreErrStrLen;
		if NOT(err = SetBlockSize(*resultTextP, prelen + totLen))
		{	p = GetPtr(*resultTextP);
			// Copy the block *resultSize forward
			CopyBlock(p + prelen + simplHeadLen, p, *resultSizeP);
			// copy the header
			CopyBlock(p + prelen, simplHead, simplHeadLen);
			// copy the moreErr (if any)
			if (moreErrStrLen)
				CopyBlock(p + prelen + simplHeadLen + *resultSizeP, moreErrStr, moreErrStrLen);
			if (prelen)
				*(long*)p = XHostToNetwork(totLen);
			(*resultSizeP) += prelen + simplHeadLen + moreErrStrLen;
		}
	}
}

//===========================================================================================
static XErr	_GetResultPage(BifernoRec *bRecP, BlockRef *resultTextP, long *resultSizeP, Boolean prefixLength, Boolean onlyHead)
{
XErr	err = noErr;

	if COMPILING((long)bRecP)
		err = BIC_Output((long)bRecP, resultTextP, resultSizeP);
	else
	{	if NOT(err = page_GetOutput((long)bRecP, OBJREF_P(&bRecP->pageOutObjRef), prefixLength, onlyHead, resultTextP, resultSizeP))
		{	if NOT(err = DLM_TurnOnFlag(bRecP->pageOutObjRef.list, bRecP->pageOutObjRef.id, kNoDestructor, kDLMWhole))
				bRecP->pageOutObjRef.id = 0;
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_UndefBifernoVar(DLMRef dlRef, long objID, unsigned short flags, long classID, long userData)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
#endif
BfrDestructRec	*destructRecP = (BfrDestructRec*)userData;
ObjRecord		objRec;
XErr			err = noErr;

	if (classID < 0)
	{	objRec.id = objID;
		objRec.classID = classID;
		objRec.type = VARIABLE;
		objRec.scope = destructRecP->scope;
		objRec.list = dlRef;
		err = UndefVariable(destructRecP->api_data, (ObjRefP)&objRec, true);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//extern long gTotIsText, gTotIsEntity, gTotIsConstructor, gTotIsFlowControl;

//===========================================================================================
//void	BEngineAPI_Run(long userData, char *serverName, char *filePath, char *serverBaseDir, BlockRef headInBlock, long headInBlockLen, BlockRef *bodyBlockP, long bodyBlockLen, char *contentType, BlockRef *resultTextP, long *resultSizeP, BAPI_OutputFunc outputFunc, Boolean isLocalFile, XErr *theErrorP, Boolean pathContainsBifernoAdmin, Boolean isPost, Boolean prefixLengthInResult, Boolean onlyHead)
void	BEngineAPI_Run(void *userData, char *serverName, char *filePath, char *serverBaseDir, BlockRef headInBlock, long headInBlockLen, BlockRef *bodyBlockP, long bodyBlockLen, char *contentType, BlockRef *resultTextP, long *resultSizeP, BAPI_OutputFunc outputFunc, short flags, LONGLONG uniqueID, char *sid, char *appName, XErr *theErrorP)
{
XErr			err = noErr, err2 = noErr, ioError = noErr, errClosingApp = noErr, errOnInput = noErr, errOnExit = noErr;
BifernoRecP		bRecP;
BlockRef		bodyBlock, configFilesBlock;
long			totRuns, lastClassIDCalled = 0, configFilesBlockLen;
Boolean			saveResumeAlwaysOldLocal, toCloseApp, canAccess, pageResultFixed, applicationInitFailed;
Boolean			isAdmin = flags & kIsAdmin, isLocal = flags & kIsLocalFile, prefixLength = flags & kPrefixLengthInResult, flushAll = false;	//, reloadAll = false;
CStr255			class_error_note;
BfrDestructRec	destructRec;
BlockRef		csSession = nil;
	
	/*gTotIsText = 0;
	gTotIsEntity = 0;
	gTotIsConstructor = 0;
	gTotIsFlowControl = 0;
	*/
	gRunID++;
	if NOT(err = BifernoEnter())
	{	pageResultFixed = false;
		if NOT(_GeneralSecurity(filePath, resultTextP, resultSizeP, prefixLength, &err))
		{	if NOT(err = AllocRunRecord(&bRecP, serverName, userData, serverBaseDir, outputFunc, filePath, headInBlock, headInBlockLen))
			{	bRecP->uniqueID = uniqueID;
				applicationInitFailed = false;
				canAccess = true;
				//sendExitEvents = false;
				bRecP->scriptIsLocal = isLocal;
				bRecP->prefixLengthInResult = prefixLength;
				if (isAdmin)
				{	bRecP->mainPathContainsBifernoAdmin = true;
					err = _FindAppl(bRecP, filePath, &configFilesBlock, &configFilesBlockLen, nil);
				}
				else
				{	ioError = CFGetFile(filePath, &bRecP->curFile);
					err = _FindAppl(bRecP, filePath, &configFilesBlock, &configFilesBlockLen, &bRecP->curFile);
				}
				if NOT(err)
				{	if (appName)
						CEquStr(appName, bRecP->application.name);
					CEquStr(bRecP->currentCtx.currentExecFile, filePath);
					XThreadsEnterCriticalSection();
					bRecP->locked++;
					err = _GetTheApplication(bRecP, &configFilesBlock, configFilesBlockLen, &applicationInitFailed, &toCloseApp);
					if NOT(applicationInitFailed)
					{	bRecP->locked--;
						XThreadsLeaveCriticalSection();
					}
					if (bodyBlockLen == kInvalidPostLength)
					{	errOnInput = XError(kBAPI_Error, Err_HTTPBodyTooLong);
						bodyBlockLen = 0;
					}
					if NOT(err)
					{	if (ioError && *bRecP->application.fnfPage && ((ioError == XError(kXLibError, ErrXFiles_FileNotFound)) || (ioError == XError(kXLibError, ErrXFiles_FolderNotFound))))
							ioError = CFGetFile(bRecP->application.fnfPage, &bRecP->curFile);
						if NOT(ioError)
						{	SetScriptCache(bRecP, &bRecP->curFile);
							//if NOT(SCRIPT_APPLICATION(bRecP->curFile.userDatas))
							//	SCRIPT_APPLICATION(bRecP->curFile.userDatas) = bRecP->applicationObjID;
							// Set Cache state to the current application pref
							if (isAdmin)
								bRecP->curFile.dontCache = true;
							else
								bRecP->curFile.dontCache = NOT(bRecP->application.cacheActive);	
							if (bodyBlockP)
								bodyBlock = *bodyBlockP;
							else
								bodyBlock = 0;
							if NOT(err = SendRunEvents(bRecP, bodyBlock, bodyBlockLen, headInBlock, headInBlockLen, false, &totRuns, (Boolean)(flags & kIsPost)))
							{	if (sid)
									CEquStr(sid, bRecP->SID);
								if NOT(pageResultFixed = _ApplicationSecurity(bRecP, filePath, resultTextP, resultSizeP, &err))
								{	if (_ApplicationAdmin(bRecP, headInBlock, headInBlockLen, &err, &ioError))
										canAccess = true;
									else
									{	if (NOT(canAccess = _ApplicationControlAccess(bRecP, resultTextP, resultSizeP, isLocal, prefixLength, &err)) && NOT(err))
											pageResultFixed = true;
									}
									if (NOT(err) && canAccess && NOT(ioError))
									{	if NOT(err = _GetInputParameters(bRecP, bodyBlockP, bodyBlockLen, contentType, errOnInput))
										{	err = _ProcessScript(bRecP, isAdmin);
											if (err)
											{	_GetErrorPage(bRecP, resultTextP, resultSizeP, filePath, err, isLocal, headInBlock, headInBlockLen, ALLOW_CUSTOM_ERR_PAGE, &ioError, theErrorP, prefixLength, 0, nil, false);
												pageResultFixed = true;
												saveResumeAlwaysOldLocal = bRecP->resumeAlwaysCaller;
												bRecP->resumeAlwaysCaller = true;
											}	
											err2 = _CallBifernoDestructors(bRecP, true);
											if (err)
												bRecP->resumeAlwaysCaller = saveResumeAlwaysOldLocal;
											else if (err2)
											{	err = err2;
												destructRec.api_data = (long)bRecP;
												destructRec.scope = LOCAL;
												DLM_Loop(bRecP->localList, _UndefBifernoVar, (long)&destructRec, true, true);
												destructRec.scope = GLOBAL;
												DLM_Loop(bRecP->globalList, _UndefBifernoVar, (long)&destructRec, true, true);
												//bRecP->errVarTableBlockValid = false;	// old table contains the just destructed biferno vars
												_GetErrorPage(bRecP, resultTextP, resultSizeP, filePath, err, isLocal, headInBlock, headInBlockLen, ALLOW_CUSTOM_ERR_PAGE, &ioError, theErrorP, prefixLength, 0, nil, false);
												pageResultFixed = true;
											}
										}
									}
								}
							}
							else
							{	_GetErrorPage(bRecP, resultTextP, resultSizeP, filePath, err, isLocal, headInBlock, headInBlockLen, ALLOW_CUSTOM_ERR_PAGE, &ioError, theErrorP, prefixLength, 0, nil, false);
								pageResultFixed = true;
							}
							// send exit events
							errOnExit = SendExitEvents(bRecP, totRuns);
							// after exit C Class can receive only kDestructor or kPrimitive event
							bRecP->exitEventCompleted = true;
						}
						else
						{	err = ioError;
							ioError = noErr;
						}
					}
				}
				if NOT(pageResultFixed)
				{	if (err)
					{	if (theErrorP)
							*theErrorP = err;
						_GetErrorPage(bRecP, resultTextP, resultSizeP, filePath, err, isLocal, headInBlock, headInBlockLen, AVOID_CUSTOM_ERR_PAGE, &ioError, theErrorP, prefixLength, 0, nil, false);
					}
					else
					{	if (theErrorP)
							*theErrorP = noErr;
						err = _GetResultPage(bRecP, resultTextP, resultSizeP, prefixLength, (Boolean)(flags & kOnlyHead));
					}
					pageResultFixed = true;
				}
				if (applicationInitFailed)
				{	if (toCloseApp)
						errClosingApp = _CloseApplication(bRecP);
					bRecP->locked--;
					XThreadsLeaveCriticalSection();
				}
				// ex if NOT(ioError)
				/*
				10/1/2003: se ioError, per� esegui Config e config va in errore
				allora devi fare release del config
				*/
				if (*bRecP->curFile.filePath)
				{	if (err || (isAdmin) || NOT(canAccess))
						bRecP->curFile.dontCache = true;	// if err || admin dont cache
					if (bRecP->curFile.fileData)
						ioError = CFReleaseFile(&bRecP->curFile, 0L);
				}
				flushAll = bRecP->flushAll;
				//reloadAll = bRecP->reloadAll;
				err = DisposeRunRecord(bRecP, &bRecP->application, true, &lastClassIDCalled, class_error_note, uniqueID, &csSession);		// Usually zero the error
				if (NOT(err) && ioError)
					err = ioError;
				else if (NOT(err) && errClosingApp)
					err = errClosingApp;
				// Last chance to catch the error later
				if (err && pageResultFixed)
				{	pageResultFixed = false;
					DisposeBlock(resultTextP);
					*resultSizeP = 0;
				}
			}
		}
		if (err && NOT(pageResultFixed))
		{	if (theErrorP)
				*theErrorP = err;
			_GetErrorPage(nil, resultTextP, resultSizeP, filePath, err, isLocal, headInBlock, headInBlockLen, AVOID_CUSTOM_ERR_PAGE, nil, theErrorP, prefixLength, lastClassIDCalled, class_error_note, false);
			err = noErr;
		}
		err2 = _RunExit();
		if (NOT(err) && err2)
			err = err2;
	}
	else
	{	if (theErrorP)
			*theErrorP = err;
		_GetErrorPage(nil, resultTextP, resultSizeP, filePath, err, isLocal, headInBlock, headInBlockLen, AVOID_CUSTOM_ERR_PAGE, nil, theErrorP, prefixLength, lastClassIDCalled, class_error_note, false);
		err = noErr;
	}
	if NOT(err)
	{	
		if (csSession)
		{
			/*unsigned long threadID;
			
			XGetCurrentThread(&threadID);
			printf("thread %d exiting, leaving mutex %d \n", threadID, csSession);
			 */
			XExitCS(csSession);
		}
		if (flushAll)
			err = BEngineAPI_Flush(HTTPControllerLog, userData, uniqueID);
	}
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	RegisterApplication(char *applicationName, XFilePathPtr applicationPath, BlockRef *resultTextP, long *resultSizeP, Boolean zeroErr, void *userData)
{
XErr			err = noErr, err2 = noErr;
long			lastClassIDCalled, configFilesBlockLen;
BlockRef		configFilesBlock = 0;
Boolean			toCloseApp, applicationInitFailed = false;
BifernoRecP		bRecP;
CacheResult		*cacheP;
CStr255			class_error_note;

	XThreadsEnterCriticalSection();
	if (resultTextP)
		*resultTextP = 0;
	if (resultSizeP)
		*resultSizeP = 0;
	if NOT(DLM_GetObjID(gsDispatcherData.globApplicationListArray, applicationName, nil, nil))
	{	if NOT(err = AllocRunRecord(&bRecP, "", 0, "", nil, applicationPath, 0, 0))
		{	bRecP->userData = userData;
			if NOT(err = _FindAppl(bRecP, applicationPath, &configFilesBlock, &configFilesBlockLen, nil))
			{	applicationInitFailed = false;
				err = _GetTheApplication(bRecP, &configFilesBlock, configFilesBlockLen, &applicationInitFailed, &toCloseApp);
				if (err && zeroErr)
				{	_GetErrorPage(bRecP, resultTextP, resultSizeP, applicationPath, err, false, 0L, 0, ALLOW_CUSTOM_ERR_PAGE, nil, nil, false, 0, nil, false);
					err = noErr;
				}
				if (applicationInitFailed && toCloseApp)
				{	XErr	errClosingApp = noErr;
				
					errClosingApp = _CloseApplication(bRecP);
					if (NOT(err) && errClosingApp)
						err = errClosingApp;
				}
				cacheP = &bRecP->curFile;
				if (*cacheP->filePath)
				{	SetScriptCache(bRecP, cacheP);
					//if NOT(SCRIPT_APPLICATION(cacheP->userDatas))
					//	SCRIPT_APPLICATION(cacheP->userDatas) = bRecP->applicationObjID;
					if (cacheP->fileData)
						err2 = CFReleaseFile(cacheP, 0);
					if (NOT(err) && err2)
						err = err2;
				}
			}
			err2 = DisposeRunRecord(bRecP, &bRecP->application, true, &lastClassIDCalled, class_error_note, 0, nil);
			if (NOT(err) && err2)
				err = err2;
		}
		if (err && zeroErr)
			_GetErrorPage(0L, resultTextP, resultSizeP, applicationPath, err, false, 0L, 0, AVOID_CUSTOM_ERR_PAGE, nil, nil, true, lastClassIDCalled, class_error_note, false);
	}
	else
	{	BlockRef 		appBlock;
		Application 	*applP;
	
		if NOT(err = GetApplicationBlock(applicationName, &appBlock))
		{	applP = (Application*)GetPtr(appBlock);
			if (CCompareStrings_cs(applP->basePath, applicationPath))
				err = XError(kBAPI_Error, Err_ApplicationNameDuplicated);
			DisposeBlock(&appBlock);
		}
	}
	XThreadsLeaveCriticalSection();

if (err && zeroErr)
	err = noErr;
return err;
}


