/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoAPI_DLL.c,v 1.35 2008-09-08 14:02:05 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"BifernoAPI.h"
#include 	"BifernoAPI_DLL.h"

static CallBacksRec*	gsCallBacksPtr = nil;

EXP XErr	RegisterCallBacks(long callsBackPtr);

//===========================================================================================
static XErr	staticRegisterCallBacks(long callsBackPtr)
{
XErr	err = noErr;
	
	gsCallBacksPtr = (CallBacksRec*)callsBackPtr;

return err;
}
//===========================================================================================
static XErr	staticBAPI_InitJavaAPI(long callsBackPtr)
{
	return RegisterCallBacks(callsBackPtr);
}

//===========================================================================================
static long	staticBAPI_PluginBAPIVersion(XErr *errP)
{
	// Here you can check if the caller's BAPI version is satisfying and return error if not
	// Errors can be one of these: Err_BifernoTooOld, Err_BifernoTooNew
	*errP = noErr;
	return CUR_BIFERNO_API_VERSION;
}

#if __MWERKS__
#pragma export on
#endif
//#ifdef __MACOSX__
//===========================================================================================
EXP XErr	_X_RegisterCallBacks(long callsBackPtr)
{
	return staticRegisterCallBacks(callsBackPtr);
}
#ifdef JAVA_ENABLED
//===========================================================================================
EXP XErr	_X_BAPI_InitJavaAPI(long callsBackPtr)
{
	return staticBAPI_InitJavaAPI(callsBackPtr);
}
#endif
//===========================================================================================
EXP long	_X_BAPI_PluginBAPIVersion(XErr *errP)
{
	return staticBAPI_PluginBAPIVersion(errP);
}
/*#else
//===========================================================================================
EXP XErr	RegisterCallBacks(long callsBackPtr)
{
	return staticRegisterCallBacks(callsBackPtr);
}
//===========================================================================================
EXP XErr	BAPI_InitJavaAPI(long callsBackPtr)
{
	return staticBAPI_InitJavaAPI(callsBackPtr);
}

//===========================================================================================
EXP long	BAPI_PluginBAPIVersion(XErr *errP)
{
	return staticBAPI_PluginBAPIVersion(errP);
}
#endif*/
#if __MWERKS__
#pragma export off
#endif

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	BAPI_NewProperties(long api_data, long classID, BAPI_MemberRecord *nvRecP, long tots, char *owner)
{
XErr	(*p)(long api_data, long classID, BAPI_MemberRecord *nvRecP, long tots, char *owner) = (void*)gsCallBacksPtr->BAPI_NewProperties;

	return p(api_data, classID, nvRecP, tots, owner);
}
//===========================================================================================
XErr	BAPI_NewConstants(long api_data, long classID, BAPI_MemberRecord *nvRecP, long tots, char *owner)
{
XErr	(*p)(long api_data, long classID, BAPI_MemberRecord *nvRecP, long tots, char *owner) = (void*)gsCallBacksPtr->BAPI_NewConstants;

	return p(api_data, classID, nvRecP, tots, owner);
}
//===========================================================================================
XErr	BAPI_NewMethods(long api_data, long classID, BAPI_MemberRecord *nvRecP, long tots, char *owner)
{
XErr	(*p)(long api_data, long classID, BAPI_MemberRecord *nvRecP, long tots, char *owner) = (void*)gsCallBacksPtr->BAPI_NewMethods;

	return p(api_data, classID, nvRecP, tots, owner);
}
//===========================================================================================
XErr	BAPI_RegisterErrors(long api_data, long handlerID, long baseError, CStr63 *nameRecP, long tots)
{
XErr	(*p)(long api_data, long handlerID, long baseError, CStr63 *nameRecP, long tots) = (void*)gsCallBacksPtr->BAPI_RegisterErrors;

	return p(api_data, handlerID, baseError, nameRecP, tots);
}
//===========================================================================================
XErr	BAPI_NewFunctions(long api_data, long pluginID, BAPI_MemberRecord *nvRecP, long tots)
{
XErr	(*p)(long api_data, long pluginID, BAPI_MemberRecord *nvRecP, long tots) = (void*)gsCallBacksPtr->BAPI_NewFunctions;

	return p(api_data, pluginID, nvRecP, tots);
}
//===========================================================================================
XErr	BAPI_NewApplicationDefault(long api_data, char *name, char *value, char *comment)
{
XErr	(*p)(long api_data, char *name, char *value, char *comment) = (void*)gsCallBacksPtr->BAPI_NewApplicationDefault;

	return p(api_data, name, value, comment);
}

//===========================================================================================
XErr	BAPI_Accessor(long api_data, long classID, long message, Biferno_ParamBlockPtr paramBlockPtr)
{
XErr	(*p)(long api_data, long classID, long message, Biferno_ParamBlockPtr paramBlockPtr) = (void*)gsCallBacksPtr->BAPI_Accessor;

	return p(api_data, classID, message, paramBlockPtr);
}
//===========================================================================================
XErr	BAPI_Constructor(long api_data, long classID, ParameterRec *varRecsP, long totVars, ObjRef *resultObjRefP)
{
XErr	(*p)(long api_data, long classID, ParameterRec *varRecsP, long totVars, ObjRef *resultObjRefP) = (void*)gsCallBacksPtr->BAPI_Constructor;

	return p(api_data, classID, varRecsP, totVars, resultObjRefP);
}

//===========================================================================================
XErr	BAPI_Clone(long api_data, ObjRef *sourceP, ObjRef *destP, Boolean cloneTarget)
{
XErr	(*p)(long api_data, ObjRef *sourceP, ObjRef *destP, Boolean cloneTarget) = (void*)gsCallBacksPtr->BAPI_Clone;

	return p(api_data, sourceP, destP, cloneTarget);
}

//===========================================================================================
XErr	BAPI_Destructor(long api_data, ObjRefP varRecP)
{
XErr	(*p)(long api_data, ObjRefP varRecP) = (void*)gsCallBacksPtr->BAPI_Destructor;

	return p(api_data, varRecP);
}
//===========================================================================================
XErr	BAPI_ExecuteOperation(long api_data, ObjRefP item1, ObjRefP item2, long operation, ObjRefP resultVarRecP)
{
XErr	(*p)(long api_data, ObjRefP item1, ObjRefP item2, long operation, ObjRefP resultVarRecP) = (void*)gsCallBacksPtr->BAPI_ExecuteOperation;

	return p(api_data, item1, item2, operation, resultVarRecP);
}
//===========================================================================================
XErr	BAPI_Increment(long api_data, ObjRefP objRefP, Boolean toDecr)
{
XErr	(*p)(long api_data, ObjRefP objRefP, Boolean toDecr) = (void*)gsCallBacksPtr->BAPI_Increment;

	return p(api_data, objRefP, toDecr);
}
//===========================================================================================
/*XErr	BAPI_Increment(long api_data, ObjRefP elem, Boolean toDecr)
{
XErr	(*p)(long api_data, ObjRefP elem, Boolean toDecr) = (void*)gsCallBacksPtr->BAPI_Increment;

	return p(api_data, elem, toDecr);
}*/
//===========================================================================================
XErr	BAPI_ExecuteMethod(long api_data, ObjRefP objRef, ParameterRec *paramVarsP, long totParams, char *methodName, ObjRefP resultVarRecP, Boolean *sideEffectP)
{
XErr	(*p)(long api_data, ObjRefP objRef, ParameterRec *paramVarsP, long totParams, char *methodName, ObjRefP resultVarRecP, Boolean *sideEffectP) = (void*)gsCallBacksPtr->BAPI_ExecuteMethod;

	return p(api_data, objRef, paramVarsP, totParams, methodName, resultVarRecP, sideEffectP);
}
//===========================================================================================
XErr	BAPI_GetProperty(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP resultVarRecP)
{
XErr	(*p)(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP resultVarRecP) = (void*)gsCallBacksPtr->BAPI_GetProperty;

	return p(api_data, objRef, propertyName, propertyDim, propertyIndex, resultVarRecP);
}

//===========================================================================================
XErr	BAPI_SetProperty(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP value)
{
XErr	(*p)(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP value) = (void*)gsCallBacksPtr->BAPI_SetProperty;

	return p(api_data, objRef, propertyName, propertyDim, propertyIndex, value);
}

//===========================================================================================
/*XErr	BAPI_Modify(long api_data, ObjRefP varToSet, ObjRefP value)
{
XErr	(*p)(long api_data, ObjRefP varToSet, ObjRefP value) = (void*)gsCallBacksPtr->BAPI_Modify;

	return p(api_data, varToSet, value);
}*/

//===========================================================================================
XErr	BAPI_ExecuteFunction(long api_data, ParameterRec *paramVarsP, long totParams, char *functionName, ObjRefP resultVarRecP)
{
XErr	(*p)(long api_data, ParameterRec *paramVarsP, long totParams, char *functionName, ObjRefP resultVarRecP) = (void*)gsCallBacksPtr->BAPI_ExecuteFunction;

	return p(api_data, paramVarsP, totParams, functionName, resultVarRecP);
}

//===========================================================================================
XErr	BAPI_GetErrMessage(long api_data, long classID, short theError, char *errName, char *errMessage, char *errType)
{
XErr	(*p)(long api_data, long classID, short theError, char *errName, char *errMessage, char *errType) = (void*)gsCallBacksPtr->BAPI_GetErrMessage;

	return p(api_data, classID, theError, errName, errMessage, errType);
}

//===========================================================================================
/*XErr	BAPI_GetErrNumber(long api_data, long classID, char *errName, long *theErrorP)
{
XErr	(*p)(long api_data, long classID, char *errName, long *theErrorP) = (void*)gsCallBacksPtr->BAPI_GetErrNumber;

	return p(api_data, classID, errName, theErrorP);
}
*/
//===========================================================================================
XErr	BAPI_SuperIsChanged(long api_data, ObjRef *objRef, char *propertyName)
{
XErr	(*p)(long api_data, ObjRef *objRef, char *propertyName) = (void*)gsCallBacksPtr->BAPI_SuperIsChanged;

	return p(api_data, objRef, propertyName);
}

//===========================================================================================
XErr	BAPI_TypeCast(long api_data, ObjRefP objRef, long requestedClassID, ObjRefP resultVarRecP, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, long requestedClassID, ObjRefP resultVarRecP, long typeCastType) = (void*)gsCallBacksPtr->BAPI_TypeCast;

	return p(api_data, objRef, requestedClassID, resultVarRecP, typeCastType);
}
//===========================================================================================
XErr 	BAPI_IntToObj(long api_data, long value, ObjRefP objRefP)
{
XErr	(*p)(long api_data, long value, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_IntToObj;

	return p(api_data, value, objRefP);
}
//===========================================================================================
XErr 	BAPI_LongToObj(long api_data, LONGLONG lvalue, ObjRefP objRefP)
{
XErr	(*p)(long api_data, LONGLONG lvalue, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_LongToObj;

	return p(api_data, lvalue, objRefP);
}
//===========================================================================================
XErr 	BAPI_UnsignedToObj(long api_data, unsigned long value, ObjRefP objRefP)
{
XErr	(*p)(long api_data, unsigned long value, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_UnsignedToObj;

	return p(api_data, value, objRefP);
}
//===========================================================================================
XErr 	BAPI_DoubleToObj(long api_data, double doubleVal, ObjRefP objRefP)
{
XErr	(*p)(long api_data, double doubleVal, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_DoubleToObj;

	return p(api_data, doubleVal, objRefP);
}
//===========================================================================================
XErr 	BAPI_BooleanToObj(long api_data, Boolean isTrue, ObjRefP objRefP)
{
XErr	(*p)(long api_data, Boolean isTrue, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_BooleanToObj;

	return p(api_data, isTrue, objRefP);
}
//===========================================================================================
XErr	BAPI_StringToObj(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP)
{
XErr	(*p)(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_StringToObj;

	return p(api_data, dataP, dataLen, objRefP);
}

//===========================================================================================
/*XErr	BAPI_StringToConstObj(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP)
{
XErr	(*p)(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_StringToConstObj;

	return p(api_data, dataP, dataLen, objRefP);
}
*/
//===========================================================================================
XErr	BAPI_CharToObj(long api_data, char theChar, ObjRefP objRefP)
{
XErr	(*p)(long api_data, char theChar, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_CharToObj;

	return p(api_data, theChar, objRefP);
}
//===========================================================================================
XErr	BAPI_ArrayToObj(long api_data, Boolean fixedSize, ParameterRec *varRecsP, long totVars, long *errElemIDXP, long constructorPrivateData, ObjRefP objRefP)
{
XErr	(*p)(long api_data, Boolean fixedSize, ParameterRec *varRecsP, long totVars, long *errElemIDXP, long constructorPrivateData, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_ArrayToObj;

	return p(api_data, fixedSize, varRecsP, totVars, errElemIDXP, constructorPrivateData, objRefP);
}

/*//===========================================================================================
XErr 	BAPI_ReturnInt(long api_data, long value, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, long value, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnInt;

	return p(api_data, value, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnLong(long api_data, LONGLONG value, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, LONGLONG value, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnLong;

	return p(api_data, value, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnUnsigned(long api_data, unsigned long value, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, unsigned long value, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnUnsigned;

	return p(api_data, value, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnDouble(long api_data, double doubleVal, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, double doubleVal, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnDouble;

	return p(api_data, doubleVal, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnBoolean(long api_data, Boolean isTrue, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, Boolean isTrue, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnBoolean;

	return p(api_data, isTrue, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnString(long api_data, Ptr dataP, long dataLen, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, Ptr dataP, long dataLen, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnString;

	return p(api_data, dataP, dataLen, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnChar(long api_data, char theChar, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, char theChar, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnChar;

	return p(api_data, theChar, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnArray(long api_data, Boolean fixedSize, long arrayDim, ParameterRec *elementsP, long totElements, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, Boolean fixedSize, long arrayDim, ParameterRec *elementsP, long totElements, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnArray;

	return p(api_data, fixedSize, arrayDim, elementsP, totElements, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnObject(long api_data, ObjRefP theObjectP, ObjRefP resultObjRefP)
{
XErr	(*p)(long api_data, ObjRefP theObjectP, ObjRefP resultObjRefP) = (void*)gsCallBacksPtr->BAPI_ReturnObject;

	return p(api_data, theObjectP, resultObjRefP);
}*/
//===========================================================================================
XErr	BAPI_ObjToInt(long api_data, ObjRefP objRef, long *valueP, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, long *valueP, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToInt;

	return p(api_data, objRef, valueP, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToLong(long api_data, ObjRefP objRef, LONGLONG *lvalueP, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, LONGLONG *lvalueP, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToLong;

	return p(api_data, objRef, lvalueP, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToUnsigned(long api_data, ObjRefP objRef, unsigned long *valueP, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, unsigned long *valueP, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToUnsigned;

	return p(api_data, objRef, valueP, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToBoolean(long api_data, ObjRefP objRef, Boolean *valueP, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, Boolean *valueP, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToBoolean;

	return p(api_data, objRef, valueP, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToDouble(long api_data, ObjRefP objRef, double *valueP, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, double *valueP, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToDouble;

	return p(api_data, objRef, valueP, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToString;

	return p(api_data, objRef, strP, strLenP, maxLen, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToChar(long api_data, ObjRefP objRef, char *theChar, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, char *theChar, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToChar;

	return p(api_data, objRef, theChar, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToConstrString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToConstrString;

	return p(api_data, objRef, strP, strLenP, maxLen, typeCastType);
}
//===========================================================================================
XErr	BAPI_ObjToDebugString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType) = (void*)gsCallBacksPtr->BAPI_ObjToDebugString;

	return p(api_data, objRef, strP, strLenP, maxLen, typeCastType);
}
//===========================================================================================
XErr	BAPI_ReadObj(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP)
{
XErr	(*p)(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP) = (void*)gsCallBacksPtr->BAPI_ReadObj;

	return p(api_data, objRef, bufferP, lenP, offset, classIDP);
}
//===========================================================================================
XErr	BAPI_GetObj(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP)
{
XErr	(*p)(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP) = (void*)gsCallBacksPtr->BAPI_GetObj;

	return p(api_data, objRef, bufferP, lenP, offset, classIDP);
}
//===========================================================================================
XErr	BAPI_BufferToObj(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, long constructorPrivateData, ObjRefP objRefP)
{
XErr	(*p)(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, long constructorPrivateData, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_BufferToObj;

	return p(api_data, dataP, dataLen, classID, fixedSize, constructorPrivateData, objRefP);
}

//===========================================================================================
XErr	BAPI_BufferToObjWithSuper(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, ObjRefP superObj, long constructorPrivateData, ObjRefP objRefP)
{
XErr	(*p)(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, ObjRefP superObj, long constructorPrivateData, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_BufferToObjWithSuper;

	return p(api_data, dataP, dataLen, classID, fixedSize, superObj, constructorPrivateData, objRefP);
}

//===========================================================================================
XErr	BAPI_SetSuperObj(long api_data, ObjRefP obj, ObjRefP superObj, ObjRefP newSuperObjP)
{
XErr	(*p)(long api_data, ObjRefP obj, ObjRefP superObj, ObjRefP newSuperObjP) = (void*)gsCallBacksPtr->BAPI_SetSuperObj;

	return p(api_data, obj, superObj, newSuperObjP);
}

//===========================================================================================
XErr	BAPI_GetSuperObj(long api_data, ObjRef *objRef, ObjRef *superObjRef)
{
XErr	(*p)(long api_data, ObjRef *objRef, ObjRef *superObjRef) = (void*)gsCallBacksPtr->BAPI_GetSuperObj;

	return p(api_data, objRef, superObjRef);
}

//===========================================================================================
XErr	BAPI_ConcatObjs(long api_data, ObjRefP objref1, ObjRefP objref2)
{
XErr	(*p)(long api_data, ObjRefP objref1, ObjRefP objref2) = (void*)gsCallBacksPtr->BAPI_ConcatObjs;

	return p(api_data, objref1, objref2);
}
//===========================================================================================
XErr	BAPI_CopyObj(long api_data, ObjRefP sourceObj, long constructorPrivateData, ObjRefP destObj)
{
XErr	(*p)(long api_data, ObjRefP sourceObj, long constructorPrivateData, ObjRefP destObj) = (void*)gsCallBacksPtr->BAPI_CopyObj;

	return p(api_data, sourceObj, constructorPrivateData, destObj);
}
//===========================================================================================
/*XErr	BAPI_CloneObj(long api_data, ObjRefP sourceObj, char *destName, long destObjScope, long destObjType, ObjRefP destObj)
{
XErr	(*p)(long api_data, ObjRefP sourceObj, char *destName, long destObjScope, long destObjType, ObjRefP destObj) = (void*)gsCallBacksPtr->BAPI_CloneObj;

	return p(api_data, sourceObj, destName, destObjScope, destObjType, destObj);
}*/
//===========================================================================================
XErr	BAPI_Publish(long api_data, Boolean toPublish, ObjRef *objrefP)
{
XErr	(*p)(long api_data, Boolean toPublish, ObjRef *objrefP) = (void*)gsCallBacksPtr->BAPI_Publish;

	return p(api_data, toPublish, objrefP);
}
				
//===========================================================================================
XErr	BAPI_GetPublishedVar(long api_data, char *applicationName, long theScope, char *objName, ObjRef *resultObjRefP)
{
XErr	(*p)(long api_data, char *applicationName, long theScope, char *objName, ObjRef *resultObjRefP) = (void*)gsCallBacksPtr->BAPI_GetPublishedVar;

	return p(api_data, applicationName, theScope, objName, resultObjRefP);
}

//===========================================================================================
XErr	BAPI_AvoidDestructor(long api_data, ObjRefP objRef, long mode)
{
XErr	(*p)(long api_data, ObjRefP objRef, long mode) = (void*)gsCallBacksPtr->BAPI_AvoidDestructor;

	return p(api_data, objRef, mode);
}

//===========================================================================================
XErr	BAPI_ForceDestructor(long api_data, ObjRefP objRef, long mode)
{
XErr	(*p)(long api_data, ObjRefP objRef, long mode) = (void*)gsCallBacksPtr->BAPI_ForceDestructor;

	return p(api_data, objRef, mode);
}

//===========================================================================================
/*XErr	BAPI_NoDestructorOnObj(long api_data, Boolean *wasToDestructP, ObjRefP objRef)
{
XErr	(*p)(long api_data, Boolean *wasToDestructP, ObjRefP objRef) = (void*)gsCallBacksPtr->BAPI_NoDestructorOnObj;

	return p(api_data, wasToDestructP, objRef);
}*/
//===========================================================================================
XErr	BAPI_ReplaceObj(long api_data, ObjRefP objref, ObjRefP value, Boolean extended)
{
XErr	(*p)(long api_data, ObjRefP objref, ObjRefP value, Boolean extended) = (void*)gsCallBacksPtr->BAPI_ReplaceObj;

	return p(api_data, objref, value, extended);
}
//===========================================================================================
XErr	BAPI_ModifyObj(long api_data, ObjRefP objref, void* dataP, long dataLen)
{
XErr	(*p)(long api_data, ObjRefP objref, void* dataP, long dataLen) = (void*)gsCallBacksPtr->BAPI_ModifyObj;

	return p(api_data, objref, dataP, dataLen);
}

//===========================================================================================
XErr	BAPI_WriteObj(long api_data, ObjRefP objref, void* dataP, long dataLen, long atOffset)
{
XErr	(*p)(long api_data, ObjRefP objref, void* dataP, long dataLen, long atOffset) = (void*)gsCallBacksPtr->BAPI_WriteObj;

	return p(api_data, objref, dataP, dataLen, atOffset);
}

//===========================================================================================
/*XErr	BAPI_WriteObjChar(long api_data, ObjRefP objref, long index, Byte theChar)
{
XErr	(*p)(long api_data, ObjRefP objref, long index, Byte theChar) = (void*)gsCallBacksPtr->BAPI_WriteObjChar;

	return p(api_data, objref, index, theChar);
}*/

//===========================================================================================
XErr	BAPI_ModifyObjClassID(long api_data, ObjRefP objref, long newObjClassID)
{
XErr	(*p)(long api_data, ObjRefP objref, long newObjClassID) = (void*)gsCallBacksPtr->BAPI_ModifyObjClassID;

	return p(api_data, objref, newObjClassID);
}

//===========================================================================================
XErr	BAPI_LockObj(long api_data, ObjRefP objref)
{
XErr	(*p)(long api_data, ObjRefP objref) = (void*)gsCallBacksPtr->BAPI_LockObj;

	return p(api_data, objref);
}

//===========================================================================================
XErr	BAPI_UnlockObj(long api_data, ObjRefP objref)
{
XErr	(*p)(long api_data, ObjRefP objref) = (void*)gsCallBacksPtr->BAPI_UnlockObj;

	return p(api_data, objref);
}

//===========================================================================================
/*XErr	BAPI_FreeObj(long api_data, ObjRefP objref)
{
XErr	(*p)(long api_data, ObjRefP objref) = (void*)gsCallBacksPtr->BAPI_FreeObj;

	return p(api_data, objref);
}*/

//===========================================================================================
XErr	BAPI_SetArrayElemName(long api_data, ObjRefP arrayObjRef, ArrayIndexRec *mCoords, short dim, char *name)
{
XErr	(*p)(long api_data, ObjRefP arrayObjRef, ArrayIndexRec *mCoords, short dim, char *name) = (void*)gsCallBacksPtr->BAPI_SetArrayElemName;

	return p(api_data, arrayObjRef, mCoords, dim, name);
}
//===========================================================================================
XErr	BAPI_Eval(long api_data, char *strToEval, long strToEvalLen, ObjRefP resultObjRefP, Boolean onlyOneStatement, Boolean resume)
{
XErr	(*p)(long api_data, char *strToEval, long strToEvalLen, ObjRefP resultObjRefP, Boolean onlyOneStatement, Boolean resume) = (void*)gsCallBacksPtr->BAPI_Eval;

	return p(api_data, strToEval, strToEvalLen, resultObjRefP, onlyOneStatement, resume);
}

//===========================================================================================
XErr	BAPI_ResetError(long api_data)
{
XErr	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_ResetError;

	return p(api_data);
}

//===========================================================================================
/*XErr	BAPI_ClearObjRef(long api_data, ObjRefP varP)
{
XErr	(*p)(long api_data, ObjRefP varP) = (void*)gsCallBacksPtr->BAPI_ClearObjRef;

	return p(api_data, varP);
}*/
//===========================================================================================
/*XErr	BAPI_GetInfo(long api_data, char *name, long which, ObjRef *arrayObjRefP)
{
XErr	(*p)(long api_data, char *name, long which, ObjRef *arrayObjRefP) = (void*)gsCallBacksPtr->BAPI_GetInfo;

	return p(api_data, name, which, arrayObjRefP);
}*/
//===========================================================================================
/*XErr	BAPI_GetDocumentation(long api_data, char *name, ObjRef *arrayObjRefP)
{
XErr	(*p)(long api_data, char *name, ObjRef *arrayObjRefP) = (void*)gsCallBacksPtr->BAPI_GetDocumentation;

	return p(api_data, name, arrayObjRefP);
}*/

//===========================================================================================
XErr	BAPI_GetClassDoc(long api_data, char *className, BlockRef *xmlBlockRefP)
{
XErr	(*p)(long api_data, char *className, BlockRef *xmlBlockRefP) = (void*)gsCallBacksPtr->BAPI_GetClassDoc;

	return p(api_data, className, xmlBlockRefP);
}
//===========================================================================================
XErr	BAPI_GetMemberDoc(long api_data, char *className, char *memberName, BlockRef *docBlockRefP, Boolean extended)
{
XErr	(*p)(long api_data, char *className, char *memberName, BlockRef *docBlockRefP, Boolean extended) = (void*)gsCallBacksPtr->BAPI_GetMemberDoc;

	return p(api_data, className, memberName, docBlockRefP, extended);
}
//===========================================================================================
XErr	BAPI_ReleaseMemberDoc(long api_data, BlockRef *docBlockRefP)
{
XErr	(*p)(long api_data, BlockRef *docBlockRefP) = (void*)gsCallBacksPtr->BAPI_ReleaseMemberDoc;

	return p(api_data, docBlockRefP);
}
//===========================================================================================
XErr	BAPI_DuplicateMemberDoc(long api_data, BlockRef docBlockRef, BlockRef *newDocBlockRefP)
{
XErr	(*p)(long api_data, BlockRef docBlockRef, BlockRef *newDocBlockRefP) = (void*)gsCallBacksPtr->BAPI_DuplicateMemberDoc;

	return p(api_data, docBlockRef, newDocBlockRefP);
}

//===========================================================================================
XErr	BAPI_IsMemberDef(long api_data, char *className, char *memberName, Boolean *isDefP)
{
XErr	(*p)(long api_data, char *className, char *memberName, Boolean *isDefP) = (void*)gsCallBacksPtr->BAPI_IsMemberDef;

	return p(api_data, className, memberName, isDefP);
}

//===========================================================================================
/*XErr	BAPI_ExtendedClass(long api_data, long classID, long *extendedClassIDP)
{
XErr	(*p)(long api_data, long classID, long *extendedClassIDP) = (void*)gsCallBacksPtr->BAPI_ExtendedClass;

	return p(api_data, classID, extendedClassIDP);
}*/
//===========================================================================================
XErr	BAPI_NameFromClassID(long api_data, long pluginID, char *pluginName)
{
XErr	(*p)(long api_data, long pluginID, char *pluginName) = (void*)gsCallBacksPtr->BAPI_NameFromClassID;

	return p(api_data, pluginID, pluginName);
}
//===========================================================================================
long	BAPI_ClassIDFromName(long api_data, char *className, Boolean allExtensionsType)
{
XErr	(*p)(long api_data, char *className, Boolean allExtensionsType) = (void*)gsCallBacksPtr->BAPI_ClassIDFromName;

	return p(api_data, className, allExtensionsType);
}
//===========================================================================================
XErr	BAPI_ScopeAllowed(long api_data, ObjRefP objP, long scope, Boolean *allowedP)
{
XErr	(*p)(long api_data, ObjRefP objP, long scope, Boolean *allowedP) = (void*)gsCallBacksPtr->BAPI_ScopeAllowed;

	return p(api_data, objP, scope, allowedP);
}

//===========================================================================================
XErr	BAPI_GetObjInfo(long api_data, ObjRefP objRef, long *classIDP, char *name)
{
XErr	(*p)(long api_data, ObjRefP objRef, long *classIDP, char *name) = (void*)gsCallBacksPtr->BAPI_GetObjInfo;

	return p(api_data, objRef, classIDP, name);
}

//===========================================================================================
XErr	BAPI_LocateObj(long api_data, ObjRefP objRef, char *scope, long *stackIndex)
{
XErr	(*p)(long api_data, ObjRefP objRef, char *scope, long *stackIndex) = (void*)gsCallBacksPtr->BAPI_LocateObj;

	return p(api_data, objRef, scope, stackIndex);
}

//===========================================================================================
Boolean	BAPI_IsObjRefValid(long api_data, ObjRefP objRef)
{
Boolean	(*p)(long api_data, ObjRefP objRef) = (void*)gsCallBacksPtr->BAPI_IsObjRefValid;

	return p(api_data, objRef);
}

//===========================================================================================
XErr	BAPI_InvalObjRef(long api_data, ObjRefP objRef)
{
XErr	(*p)(long api_data, ObjRefP objRef) = (void*)gsCallBacksPtr->BAPI_InvalObjRef;

	return p(api_data, objRef);
}

//===========================================================================================
XErr	BAPI_IsObjRefToDestruct(long api_data, ObjRefP objRef, Boolean *isToDestructP)
{
XErr	(*p)(long api_data, ObjRefP objRef, Boolean *isToDestructP) = (void*)gsCallBacksPtr->BAPI_IsObjRefToDestruct;

	return p(api_data, objRef, isToDestructP);
}

//===========================================================================================
long	BAPI_GetObjClassID(long api_data, ObjRefP objRef)
{
long	(*p)(long api_data, ObjRefP objRef) = (void*)gsCallBacksPtr->BAPI_GetObjClassID;

	return p(api_data, objRef);
}

//===========================================================================================
void	BAPI_SetObjClassID(long api_data, ObjRefP objRef, long newClassID)
{
long	(*p)(long api_data, ObjRefP objRef, long newClassID) = (void*)gsCallBacksPtr->BAPI_SetObjClassID;

	p(api_data, objRef, newClassID);
}

//===========================================================================================
void	BAPI_SetObjScope(long api_data, ObjRefP objRef, long newScope)
{
long	(*p)(long api_data, ObjRefP objRef, long newScope) = (void*)gsCallBacksPtr->BAPI_SetObjScope;

	p(api_data, objRef, newScope);
}

//===========================================================================================
void	BAPI_SetObjType(long api_data, ObjRefP objRef, long newType)
{
long	(*p)(long api_data, ObjRefP objRef, long newType) = (void*)gsCallBacksPtr->BAPI_SetObjType;

	p(api_data, objRef, newType);
}

//===========================================================================================
long	BAPI_GetObjScope(long api_data, ObjRefP objRef)
{
long	(*p)(long api_data, ObjRefP objRef) = (void*)gsCallBacksPtr->BAPI_GetObjScope;

	return p(api_data, objRef);
}

//===========================================================================================
XErr	BAPI_NeedSerialize(long api_data, ObjRefP objRef, Boolean *needP)
{
long	(*p)(long api_data, ObjRefP objRef, Boolean *needP) = (void*)gsCallBacksPtr->BAPI_NeedSerialize;

	return p(api_data, objRef, needP);
}

//===========================================================================================
long	BAPI_GetObjType(long api_data, ObjRefP objRef)
{
long	(*p)(long api_data, ObjRefP objRef) = (void*)gsCallBacksPtr->BAPI_GetObjType;

	return p(api_data, objRef);
}

//===========================================================================================
XErr	BAPI_Hide(long api_data, Boolean toHide, ObjRef *objRef)
{
XErr	(*p)(long api_data, Boolean toHide, ObjRef *objRef) = (void*)gsCallBacksPtr->BAPI_Hide;

	return p(api_data, toHide, objRef);
}

//===========================================================================================
XErr	BAPI_Undef(long api_data, ObjRef *varObjRefP)
{
XErr	(*p)(long api_data, ObjRef *varObjRefP) = (void*)gsCallBacksPtr->BAPI_Undef;

	return p(api_data, varObjRefP);
}

//===========================================================================================
/*XErr	BAPI_IsClassDef(long api_data, char *name, Boolean *isDefP)
{
XErr	(*p)(long api_data, char *name, Boolean *isDefP) = (void*)gsCallBacksPtr->BAPI_IsClassDef;

	return p(api_data, name, isDefP);
}
*/
//===========================================================================================
XErr	BAPI_IsFuncDef(long api_data, char *name, Boolean *isDefP)
{
XErr	(*p)(long api_data, char *name, Boolean *isDefP) = (void*)gsCallBacksPtr->BAPI_IsFuncDef;

	return p(api_data, name, isDefP);
}

//===========================================================================================
XErr	BAPI_IsVariableDefined(long api_data, char *name, long theScope, Boolean *isDefP, ObjRef *varObjRefP)
{
XErr	(*p)(long api_data, char *name, long theScope, Boolean *isDefP, ObjRef *varObjRefP) = (void*)gsCallBacksPtr->BAPI_IsVariableDefined;

	return p(api_data, name, theScope, isDefP, varObjRefP);
}

//===========================================================================================
XErr	BAPI_IsVariableInitialized(long api_data, ObjRefP objrefP, Boolean *isInitP)
{
XErr	(*p)(long api_data, ObjRefP objrefP, Boolean *isInitP) = (void*)gsCallBacksPtr->BAPI_IsVariableInitialized;

	return p(api_data, objrefP, isInitP);
}

//===========================================================================================
XErr	BAPI_IsVariableHidden(long api_data, ObjRefP objrefP, Boolean *isHiddenP)
{
XErr	(*p)(long api_data, ObjRefP objrefP, Boolean *isHiddenP) = (void*)gsCallBacksPtr->BAPI_IsVariableHidden;

	return p(api_data, objrefP, isHiddenP);
}

//===========================================================================================
XErr	BAPI_GetClassInfo(long api_data, long classID, BAPI_ClassInfo *classInfoP)
{
XErr	(*p)(long api_data, long classID, BAPI_ClassInfo *classInfoP) = (void*)gsCallBacksPtr->BAPI_GetClassInfo;

	return p(api_data, classID, classInfoP);
}

//===========================================================================================
XErr	BAPI_FixedSize(long api_data, long classID, Boolean *fixedSize)
{
XErr	(*p)(long api_data, long classID, Boolean *fixedSize) = (void*)gsCallBacksPtr->BAPI_FixedSize;

	return p(api_data, classID, fixedSize);
}

//===========================================================================================
void	BAPI_ClearParameterRec(long api_data, ParameterRec *paramP)
{
void	(*p)(long api_data, ParameterRec *paramP) = (void*)gsCallBacksPtr->BAPI_ClearParameterRec;

	p(api_data, paramP);
}

//===========================================================================================
XErr	BAPI_GetCurrentBasePath(long api_data, char *currentBasePath, Boolean fromRoot)
{
XErr	(*p)(long api_data, char *currentBasePath, Boolean fromRoot) = (void*)gsCallBacksPtr->BAPI_GetCurrentBasePath;

	return p(api_data, currentBasePath, fromRoot);
}
//===========================================================================================
XErr	BAPI_GetCurrentScriptInfo(long api_data, unsigned long *timeoutP, long *currentThreadsP, long *maxThreadsP, XFilePathPtr basePath)
{
XErr	(*p)(long api_data, unsigned long *timeoutP, long *currentThreadsP, long *maxThreadsP, XFilePathPtr basePath) = (void*)gsCallBacksPtr->BAPI_GetCurrentScriptInfo;

	return p(api_data, timeoutP, currentThreadsP, maxThreadsP, basePath);
}

//===========================================================================================
XErr	BAPI_SetFileCacheState(long api_data, Boolean toCache)
{
XErr	(*p)(long api_data, Boolean toCache) = (void*)gsCallBacksPtr->BAPI_SetFileCacheState;

	return p(api_data, toCache);
}

//===========================================================================================
XErr	BAPI_RealPath(long api_data, char *path, Boolean resolveAlias)
{
XErr	(*p)(long api_data, char *path, Boolean resolveAlias) = (void*)gsCallBacksPtr->BAPI_RealPath;

	return p(api_data, path, resolveAlias);
}

//===========================================================================================
XErr	BAPI_NativePath(long api_data, char *path)
{
XErr	(*p)(long api_data, char *path) = (void*)gsCallBacksPtr->BAPI_NativePath;

	return p(api_data, path);
}

//===========================================================================================
XErr	BAPI_BifernoPath(long api_data, char *path)
{
XErr	(*p)(long api_data, char *path) = (void*)gsCallBacksPtr->BAPI_BifernoPath;

	return p(api_data, path);
}

//===========================================================================================
XErr	BAPI_GetHTTPParam(long api_data, BAPI_HTTPParam what, ObjRef *result)
{
XErr	(*p)(long api_data, BAPI_HTTPParam what, ObjRef *result) = (void*)gsCallBacksPtr->BAPI_GetHTTPParam;

	return p(api_data, what, result);
}

//===========================================================================================
void*	BAPI_HTTPTaskID(long api_data)
{
void*	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_HTTPTaskID;

	return p(api_data);
}

//===========================================================================================
XErr	BAPI_GetFilePath(long api_data, char *filePath)
{
XErr	(*p)(long api_data, char *filePath) = (void*)gsCallBacksPtr->BAPI_GetFilePath;

	return p(api_data, filePath);
}
//===========================================================================================
XErr	BAPI_GetCurrentFilePath(long api_data, char *currentFilePath, long *actLineP, Boolean *wasInCacheP, Boolean *willBeCachedP)
{
XErr	(*p)(long api_data, char *currentFilePath, long *actLineP, Boolean *wasInCacheP, Boolean *willBeCachedP) = (void*)gsCallBacksPtr->BAPI_GetCurrentFilePath;

	return p(api_data, currentFilePath, actLineP, wasInCacheP, willBeCachedP);
}

//===========================================================================================
XErr	BAPI_GetCurrentFileOffset(long api_data, long *actColP)
{
XErr	(*p)(long api_data, long *actColP) = (void*)gsCallBacksPtr->BAPI_GetCurrentFileOffset;

	return p(api_data, actColP);
}

//===========================================================================================
Boolean	BAPI_IsCacheActive(long api_data)
{
Boolean	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_IsCacheActive;

	return p(api_data);
}

//===========================================================================================
/*XErr	BAPI_NewArray(long api_data, Boolean fixedSize, unsigned long arrayDim, char *newObjName, long objScope, long objType, ParameterRec *varRecsP, long totVars, long *errElemIDXP, ObjRefP newObj)
{
XErr	(*p)(long api_data, Boolean fixedSize, unsigned long arrayDim, char *newObjName, long objScope, long objType, ParameterRec *varRecsP, long totVars, long *errElemIDXP, ObjRefP newObj) = (void*)gsCallBacksPtr->BAPI_NewArray;

	return p(api_data, fixedSize, arrayDim, newObjName, objScope, objType, varRecsP, totVars, errElemIDXP, newObj);
}
*/
//===========================================================================================
XErr	BAPI_GetArrayInfo(long api_data, ObjRefP objRef, long *arrayDimP, long *arrayClassIDP, long *dlmRefP)
{
XErr	(*p)(long api_data, ObjRefP objRef, long *arrayDimP, long *arrayClassIDP, long *dlmRefP) = (void*)gsCallBacksPtr->BAPI_GetArrayInfo;

	return p(api_data, objRef, arrayDimP, arrayClassIDP, dlmRefP);
}

//===========================================================================================
XErr	BAPI_SetArrayElemClass(long api_data, ObjRefP objRef, long classID)
{
XErr	(*p)(long api_data, ObjRefP objRef, long classID) = (void*)gsCallBacksPtr->BAPI_SetArrayElemClass;

	return p(api_data, objRef, classID);
}

//===========================================================================================
/*XErr	BAPI_ResolveArrayElem(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, short *lastResolvedP, Boolean *expandedP, ObjRef *elemToAdd, ObjRefP resultObjRef, long *arrayElementClassID)
{
XErr	(*p)(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, short *lastResolvedP, Boolean *expandedP, ObjRef *elemToAdd, ObjRefP resultObjRef, long *arrayElementClassID) = (void*)gsCallBacksPtr->BAPI_ResolveArrayElem;

	return p(api_data, objRef, mCoords, dim, lastResolvedP, expandedP, elemToAdd, resultObjRef, arrayElementClassID);
}
*/

//===========================================================================================
XErr	BAPI_ElementOfArray(long api_data, ObjRefP objRef, long index, ObjRefP resultObjRef)
{
XErr	(*p)(long api_data, ObjRefP objRef, long index, ObjRefP resultObjRef) = (void*)gsCallBacksPtr->BAPI_ElementOfArray;

	return p(api_data, objRef, index, resultObjRef);
}

//===========================================================================================
XErr	BAPI_ElementOfArrayExt(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, ObjRefP resultObjRef)
{
XErr	(*p)(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, ObjRefP resultObjRef) = (void*)gsCallBacksPtr->BAPI_ElementOfArrayExt;

	return p(api_data, objRef, mCoords, dim, resultObjRef);
}

//===========================================================================================
XErr	BAPI_ArrayLoop(long api_data, ObjRefP objRef, BAPI_ArrayLoopCallBack callBack, long param)
{
XErr	(*p)(long api_data, ObjRefP objRef, BAPI_ArrayLoopCallBack callBack, long param) = (void*)gsCallBacksPtr->BAPI_ArrayLoop;

	return p(api_data, objRef, callBack, param);
}

//===========================================================================================
XErr	BAPI_ArrayAddElement(long api_data, ObjRefP arrayObjRefP, char *name, ObjRef *objToAdd)
{
XErr	(*p)(long api_data, ObjRefP arrayObjRefP, char *name, ObjRef *objToAdd) = (void*)gsCallBacksPtr->BAPI_ArrayAddElement;

	return p(api_data, arrayObjRefP, name, objToAdd);
}

//===========================================================================================
XErr	BAPI_ArrayDelete(long api_data, ObjRefP objRef, long firstElem, long lastElem)
{
XErr	(*p)(long api_data, ObjRefP objRef, long firstElem, long lastElem) = (void*)gsCallBacksPtr->BAPI_ArrayDelete;

	return p(api_data, objRef, firstElem, lastElem);
}

//===========================================================================================
XErr	BAPI_ArraySwap(long api_data, ObjRefP objRef, long elem1, long elem2)
{
XErr	(*p)(long api_data, ObjRefP objRef, long elem1, long elem2) = (void*)gsCallBacksPtr->BAPI_ArraySwap;

	return p(api_data, objRef, elem1, elem2);
}

//===========================================================================================
XErr	BAPI_ArrayReverse(long api_data, ObjRefP arrayObjRefP)
{
XErr	(*p)(long api_data, ObjRefP arrayObjRefP) = (void*)gsCallBacksPtr->BAPI_ArrayReverse;

	return p(api_data, arrayObjRefP);
}

//===========================================================================================
XErr	BAPI_ArraySort(long api_data, ObjRefP arrayObjRefP, long mode, long alg, BAPI_ArraySortCallBack callBack, long param)
{
XErr	(*p)(long api_data, ObjRefP arrayObjRefP, long mode, long alg, BAPI_ArraySortCallBack callBack, long param) = (void*)gsCallBacksPtr->BAPI_ArraySort;

	return p(api_data, arrayObjRefP, mode, alg, callBack, param);
}

//===========================================================================================
XErr	BAPI_ArrayInsert(long api_data, ObjRefP arrayObjRefP, int pos, ParameterRec *paramVarsP, long totParams)
{
XErr	(*p)(long api_data, ObjRefP arrayObjRefP, int pos, ParameterRec *paramVarsP, long totParams) = (void*)gsCallBacksPtr->BAPI_ArrayInsert;

	return p(api_data, arrayObjRefP, pos, paramVarsP, totParams);
}

//===========================================================================================
XErr	BAPI_ArrayReset(long api_data, ObjRefP objRefP)
{
XErr	(*p)(long api_data, ObjRefP objRefP) = (void*)gsCallBacksPtr->BAPI_ArrayReset;

	return p(api_data, objRefP);
}

//===========================================================================================
XErr	BAPI_ArrayConcat(long api_data, ObjRefP objRef1, ObjRefP objRef2, ObjRefP result)
{
XErr	(*p)(long api_data, ObjRefP objRef1, ObjRefP objRef2, ObjRefP result) = (void*)gsCallBacksPtr->BAPI_ArrayConcat;

	return p(api_data, objRef1, objRef2, result);
}

//===========================================================================================
XErr	BAPI_SetArrayDim(long api_data, ObjRefP theObjRefP, long newDim)
{
XErr	(*p)(long api_data, ObjRefP theObjRefP, long newDim) = (void*)gsCallBacksPtr->BAPI_SetArrayDim;

	return p(api_data, theObjRefP, newDim);
}

//===========================================================================================
/*XErr	BAPI_ModifyObjWithArray(long api_data, ObjRefP objref, ObjRefP theArray, long objClassID)
{
XErr	(*p)(long api_data, ObjRefP objref, ObjRefP theArray, long objClassID) = (void*)gsCallBacksPtr->BAPI_ModifyObjWithArray;

	return p(api_data, objref, theArray, objClassID);
}*/
//===========================================================================================
XErr	BAPI_EncodeIsolatin(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR, Boolean encodeGthLth, Boolean useNames, Boolean extTags, long userTagList)
{
XErr	(*p)(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR, Boolean encodeGthLth, Boolean useNames, Boolean extTags, long userTagList) = (void*)gsCallBacksPtr->BAPI_EncodeIsolatin;

	return p(api_data, stringP, stringLen, resultStringP, resultLenP, alsoCR, encodeGthLth, useNames, extTags, userTagList);
}
//===========================================================================================
XErr	BAPI_DecodeIsolatin(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR)
{
XErr	(*p)(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR) = (void*)gsCallBacksPtr->BAPI_DecodeIsolatin;

	return p(api_data, stringP, stringLen, resultStringP, resultLenP, alsoCR);
}
//===========================================================================================
XErr	BAPI_EncodeURL(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean spaceToPlus, char *preStr)
{
XErr	(*p)(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean spaceToPlus, char *preStr) = (void*)gsCallBacksPtr->BAPI_EncodeURL;

	return p(api_data, stringP, stringLen, resultStringP, resultLenP, spaceToPlus, preStr);
}
//===========================================================================================
XErr	BAPI_DecodeURL(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean plusToSpace, char *preStr)
{
XErr	(*p)(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean plusToSpace, char *preStr) = (void*)gsCallBacksPtr->BAPI_DecodeURL;

	return p(api_data, stringP, stringLen, resultStringP, resultLenP, plusToSpace, preStr);
}

//===========================================================================================
XErr	BAPI_EncodeBase64(long api_data, char *stringP, long stringLen, char *resultStringP, long *resultStringLengthP)
{
XErr	(*p)(long api_data, char *stringP, long stringLen, char *resultStringP, long *resultStringLengthP) = (void*)gsCallBacksPtr->BAPI_EncodeBase64;

	return p(api_data, stringP, stringLen, resultStringP, resultStringLengthP);
}
//===========================================================================================
XErr	BAPI_DecodeBase64(long api_data, char *stringP, long stringLen, char *resultStringP, long *resultStringLengthP, long maxStorage)
{
XErr	(*p)(long api_data, char *stringP, long stringLen, char *resultStringP, long *resultStringLengthP, long maxStorage) = (void*)gsCallBacksPtr->BAPI_DecodeBase64;

	return p(api_data, stringP, stringLen, resultStringP, resultStringLengthP, maxStorage);
}
//===========================================================================================
/*XErr	BAPI_EncodeJavaScript(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP)
{
XErr	(*p)(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP) = (void*)gsCallBacksPtr->BAPI_EncodeJavaScript;

	return p(api_data, stringP, stringLen, resultStringP, resultLenP);
}
//===========================================================================================
XErr	BAPI_DecodeJavaScript(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP)
{
XErr	(*p)(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP) = (void*)gsCallBacksPtr->BAPI_DecodeJavaScript;

	return p(api_data, stringP, stringLen, resultStringP, resultLenP);
}*/

//===========================================================================================
XErr	BAPI_GetStringBlock(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType)
{
XErr	(*p)(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType) = (void*)gsCallBacksPtr->BAPI_GetStringBlock;

	return p(api_data, objRef, aCStr, stringP, stringLen, refP, typeCastType);
}
//===========================================================================================
XErr	BAPI_GetStringBlockExt(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType, short variant)
{
XErr	(*p)(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType, short variant) = (void*)gsCallBacksPtr->BAPI_GetStringBlockExt;

	return p(api_data, objRef, aCStr, stringP, stringLen, refP, typeCastType, variant);
}
//===========================================================================================
XErr	BAPI_GetObjBlock(long api_data, ObjRefP objRef, Ptr buffer, Ptr *stringP, long *stringLen, BlockRef *refP)
{
XErr	(*p)(long api_data, ObjRefP objRef, Ptr buffer, Ptr *stringP, long *stringLen, BlockRef *refP) = (void*)gsCallBacksPtr->BAPI_GetObjBlock;

	return p(api_data, objRef, buffer, stringP, stringLen, refP);
}
//===========================================================================================
void	BAPI_ReleaseBlock(BlockRef *refP)
{
XErr	(*p)(BlockRef *refP) = (void*)gsCallBacksPtr->BAPI_ReleaseBlock;

	p(refP);
}
//===========================================================================================
/*XErr	BAPI_IllegalTypeCastToErrMessage(long api_data, long type1, long type2)
{
XErr	(*p)(long api_data, long type1, long type2) = (void*)gsCallBacksPtr->BAPI_IllegalTypeCastToErrMessage;

	return p(api_data, type1, type2);
}*/

//===========================================================================================
XErr	BAPI_GetTotVariables(long api_data, long *totVarsP, long scope)
{
XErr	(*p)(long api_data, long *totVarsP, long scope) = (void*)gsCallBacksPtr->BAPI_GetTotVariables;

	return p(api_data, totVarsP, scope);
}

//===========================================================================================
XErr	BAPI_GetListTotVariables(long api_data, long scope, int stackIndex, long *totVarsP)
{	
	XErr	(*p)(long api_data, long scope, int stackIndex, long *totVarsP) = (void*)gsCallBacksPtr->BAPI_GetListTotVariables;
	
	return p(api_data, scope, stackIndex, totVarsP);
}

//===========================================================================================
XErr	BAPI_GetListTotVariablesExt(long api_data, long scope, int stackIndex, Boolean onlyArguments, long *totVarsP)
{	
	XErr	(*p)(long api_data, long scope, int stackIndex, Boolean onlyArguments, long *totVarsP) = (void*)gsCallBacksPtr->BAPI_GetListTotVariablesExt;
	
	return p(api_data, scope, stackIndex, onlyArguments, totVarsP);
}

//===========================================================================================
XErr	BAPI_GetIndVariable(long api_data, long index, long scope, Boolean sorted, char *name, ObjRef *objIDP)
{
XErr	(*p)(long api_data, long index, long scope, Boolean sorted, char *name, ObjRef *objIDP) = (void*)gsCallBacksPtr->BAPI_GetIndVariable;

	return p(api_data, index, scope, sorted, name, objIDP);
}

//===========================================================================================
XErr	BAPI_GetListIndVariable(long api_data, long index, long scope, Boolean sorted, char *name, int stackIndex, ObjRef *objIDP)
{	
XErr	(*p)(long api_data, long index, long scope, Boolean sorted, char *name, int stackIndex, ObjRef *objIDP) = (void*)gsCallBacksPtr->BAPI_GetListIndVariable;

	return p(api_data, index, scope, sorted, name, stackIndex, objIDP);
}

//===========================================================================================
XErr	BAPI_ScopeID(long api_data, char *scopeName, long *scopeP)
{
XErr	(*p)(long api_data, char *scopeName, long *scopeP) = (void*)gsCallBacksPtr->BAPI_ScopeID;

	return p(api_data, scopeName, scopeP);
}

//===========================================================================================
long	BAPI_ConstructorScope(long api_data, long constructorPrivateData)
{
long	(*p)(long api_data, long constructorPrivateData) = (void*)gsCallBacksPtr->BAPI_ConstructorScope;

	return p(api_data, constructorPrivateData);
}

//===========================================================================================
XErr	BAPI_GetClasses(long api_data, char *applicationName, BlockRef *classesArrayBlockP, long *totClassesP, long index)
{
XErr	(*p)(long api_data, char *applicationName, BlockRef *classesArrayBlockP, long *totClassesP, long index) = (void*)gsCallBacksPtr->BAPI_GetClasses;

	return p(api_data, applicationName, classesArrayBlockP, totClassesP, index);
}

//===========================================================================================
XErr	BAPI_GetMembers(long api_data, char *applicationName, char *className, long which, BlockRef *membersArrayBlockP, long *totMembersP, long index)
{
XErr	(*p)(long api_data, char *applicationName, char *className, long which, BlockRef *membersArrayBlockP, long *totMembersP, long index) = (void*)gsCallBacksPtr->BAPI_GetMembers;

	return p(api_data, applicationName, className, which, membersArrayBlockP, totMembersP, index);
}

//===========================================================================================
/*XErr	BAPI_GetApplicationFunctions(long api_data, BlockRef *blockP, long *lenP, char *separator, char *applicationName)
{
XErr	(*p)(long api_data, BlockRef *blockP, long *lenP, char *separator, char *applicationName) = (void*)gsCallBacksPtr->BAPI_GetApplicationFunctions;

	return p(api_data, blockP, lenP, separator, applicationName);
}*/

//===========================================================================================
/*XErr	BAPI_GetPrototype(long api_data, char *funcName, char *prototype, long maxStorage)
{
XErr	(*p)(long api_data, char *funcName, char *prototype, long maxStorage) = (void*)gsCallBacksPtr->BAPI_GetPrototype;

	return p(api_data, funcName, prototype, maxStorage);
}
*/
//===========================================================================================
XErr	BAPI_Exception(long api_data, long errType, long errNum, char *className, Boolean setClassException)
{
XErr	(*p)(long api_data, long errType, long errNum, char *className, Boolean setClassException) = (void*)gsCallBacksPtr->BAPI_Exception;

	return p(api_data, errType, errNum, className, setClassException);
}

//===========================================================================================
/*XErr	BAPI_GetErrNum(long api_data, char *errName, char *errClass, long *errNumP)
{
XErr	(*p)(long api_data, char *errName, char *errClass, long *errNumP) = (void*)gsCallBacksPtr->BAPI_GetErrNum;

	return p(api_data, errName, errClass, errNumP);
}*/

//===========================================================================================
XErr	BAPI_GetErrDescription(long api_data, XErr theError, char *eNameStr, char *classErrNotesP, char *errType, char *descr, Boolean *resumableP, long lastClassErrCalled, char *subErrStr)
{
XErr	(*p)(long api_data, XErr theError, char *eNameStr, char *classErrNotesP, char *errType, char *descr, Boolean *resumableP, long lastClassErrCalled, char *subErrStr) = (void*)gsCallBacksPtr->BAPI_GetErrDescription;

	return p(api_data, theError, eNameStr, classErrNotesP, errType, descr, resumableP, lastClassErrCalled, subErrStr);
}

//===========================================================================================
XErr	BAPI_NewMsgRecord(long api_data, char *title, char *msg, long msgLen, long flags)
{
XErr	(*p)(long api_data, char *title, char *msg, long msgLen, long flags) = (void*)gsCallBacksPtr->BAPI_NewMsgRecord;

	return p(api_data, title, msg, msgLen, flags);
}

//===========================================================================================
XErr	BAPI_GetMessageRecords(long api_data, CStr63 *title, CStr255 *msg, long *totP, long max)
{
XErr	(*p)(long api_data, CStr63 *title, CStr255 *msg, long *totP, long max) = (void*)gsCallBacksPtr->BAPI_GetMessageRecords;

	return p(api_data, title, msg, totP, max);
}

//===========================================================================================
XErr	BAPI_GetErrorMsgRecord(long api_data, ErrorMsgRecord *msgRecordP, long *lastMultiStrLineP)
{
XErr	(*p)(long api_data, ErrorMsgRecord *msgRecordP, long *lastMultiStrLineP) = (void*)gsCallBacksPtr->BAPI_GetErrorMsgRecord;

	return p(api_data, msgRecordP, lastMultiStrLineP);
}

//===========================================================================================
XErr	BAPI_GetStack(long api_data, BlockRef *stackBlockP, long *totItemsP, Boolean *stackFixedSize)
{
	XErr	(*p)(long api_data, BlockRef *stackBlockP, long *totItemsP, Boolean *stackFixedSize) = (void*)gsCallBacksPtr->BAPI_GetStack;
	
	return p(api_data, stackBlockP, totItemsP, stackFixedSize);
}

//===========================================================================================
XErr	BAPI_GetIncludeStack(long api_data, BlockRef *stackBlockP, long *totItemsP)
{
	XErr	(*p)(long api_data, BlockRef *stackBlockP, long *totItemsP) = (void*)gsCallBacksPtr->BAPI_GetIncludeStack;
	
	return p(api_data, stackBlockP, totItemsP);
}

//===========================================================================================
XErr	BAPI_GetHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, long lastClassErrCalled)
{
XErr	(*p)(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, long lastClassErrCalled) = (void*)gsCallBacksPtr->BAPI_GetHtmlError;

	return p(api_data, theError, errBlockP, sizeP, lastClassErrCalled);
}
//===========================================================================================
/*XErr	BAPI_SetError(long api_data, XErr *errP, long value)
{
XErr	(*p)(long api_data, XErr *errP, long value) = (void*)gsCallBacksPtr->BAPI_SetError;

	return p(api_data, errP, value);
}*/
//===========================================================================================
XErr	BAPI_GetStatus(long api_data, BlockRef *fileLineBlockP, long *fileLineLengthP, BlockRef *statusBlockP, long *statusBlockLengthP, BlockRef *stackBlockP, long *stackBlockLengthP)
{
XErr	(*p)(long api_data, BlockRef *fileLineBlockP, long *fileLineLengthP, BlockRef *statusBlockP, long *statusBlockLengthP, BlockRef *stackBlockP, long *stackBlockLengthP) = (void*)gsCallBacksPtr->BAPI_GetStatus;

	return p(api_data, fileLineBlockP, fileLineLengthP, statusBlockP, statusBlockLengthP, stackBlockP, stackBlockLengthP);
}

//===========================================================================================
XErr	BAPI_ScopeName(long api_data, long the_scope, char *scopeName)
{
XErr	(*p)(long api_data, long the_scope, char *scopeName) = (void*)gsCallBacksPtr->BAPI_ScopeName;

	return p(api_data, the_scope, scopeName);
}

//===========================================================================================
XErr	BAPI_GetErrorStrings(long api_data, long *startErrP, BAPIErrorRecord **errorStringsP, long *totErrorsP)
{
XErr	(*p)(long api_data, long *startErrP, BAPIErrorRecord **errorStringsP, long *totErrorsP) = (void*)gsCallBacksPtr->BAPI_GetErrorStrings;

	return p(api_data, startErrP, errorStringsP, totErrorsP);
}

//===========================================================================================
XErr	BAPI_StandardOutput(long api_data, char *textP, long len, Boolean useCustom)
{
XErr	(*p)(long api_data, char *textP, long len, Boolean useCustom) = (void*)gsCallBacksPtr->BAPI_StandardOutput;

	return p(api_data, textP, len, useCustom);
}

//===========================================================================================
XErr	BAPI_Log(long api_data, char *strLog)
{
XErr	(*p)(long api_data, char *strLog) = (void*)gsCallBacksPtr->BAPI_Log;

	return p(api_data, strLog);
}

//===========================================================================================
XErr	BAPI_SetCustomOutput(long api_data, char *functionName)
{
XErr	(*p)(long api_data, char *functionName) = (void*)gsCallBacksPtr->BAPI_SetCustomOutput;

	return p(api_data, functionName);
}

//===========================================================================================
XErr	BAPI_SetStandardOutput(long api_data)
{
XErr	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_SetStandardOutput;

	return p(api_data);
}

//===========================================================================================
XErr	BAPI_GetOutputFunction(long api_data, char *funcName)
{
XErr	(*p)(long api_data, char *funcName) = (void*)gsCallBacksPtr->BAPI_GetOutputFunction;

	return p(api_data, funcName);
}

//===========================================================================================
XErr	BAPI_Flush(long api_data)
{
XErr	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_Flush;

	return p(api_data);
}

//===========================================================================================
/*XErr	BAPI_Reload(long api_data)
{
XErr	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_Reload;

	return p(api_data);
}*/

//===========================================================================================
XErr	BAPI_FlushAppFiles(long api_data)
{
XErr	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_FlushAppFiles;

	return p(api_data);
}

//===========================================================================================
XErr	BAPI_FlushFile(long api_data, XFilePathPtr filePath)
{
XErr	(*p)(long api_data, XFilePathPtr filePath) = (void*)gsCallBacksPtr->BAPI_FlushFile;

	return p(api_data, filePath);
}

//===========================================================================================
XErr	BAPI_ReloadApp(long api_data)
{
XErr	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_ReloadApp;

	return p(api_data);
}

//===========================================================================================
XErr	BAPI_GetCurrentAppInfo(long api_data, char *name, char *home)
{
XErr	(*p)(long api_data, char *name, char *home) = (void*)gsCallBacksPtr->BAPI_GetCurrentAppInfo;

	return p(api_data, name, home);
}

//===========================================================================================
XErr	BAPI_GetGenericAppInfo(long api_data, char *appName, char *appHome)
{
XErr	(*p)(long api_data, char *appName, char *appHome) = (void*)gsCallBacksPtr->BAPI_GetGenericAppInfo;

	return p(api_data, appName, appHome);
}

//===========================================================================================
XErr	BAPI_RegisterApplication(long api_data, char *applicationName, XFilePathPtr applicationPath)
{
XErr	(*p)(long api_data, char *applicationName, XFilePathPtr applicationPath) = (void*)gsCallBacksPtr->BAPI_RegisterApplication;

	return p(api_data, applicationName, applicationPath);
}

//===========================================================================================
XErr	BAPI_GetApplications(long api_data, BlockRef *appsArrayBlockP, long *totAppsP, long index)
{
XErr	(*p)(long api_data, BlockRef *appsArrayBlockP, long *totAppsP, long index) = (void*)gsCallBacksPtr->BAPI_GetApplications;

	return p(api_data, appsArrayBlockP, totAppsP, index);
}

//===========================================================================================
XErr	BAPI_GetAppChildren(long api_data, char *applicationName, BlockRef *childrenArrayBlockP, long *totChildrenP, long index)
{
XErr	(*p)(long api_data, char *applicationName, BlockRef *childrenArrayBlockP, long *totChildrenP, long index) = (void*)gsCallBacksPtr->BAPI_GetAppChildren;

	return p(api_data, applicationName, childrenArrayBlockP, totChildrenP, index);
}

//===========================================================================================
XErr	BAPI_GetCache(long api_data, BlockRef *infoBlockP, long *totItemsP, unsigned long *totalBytesInCacheP, Boolean *cacheFixedSizeP)
{
XErr	(*p)(long api_data, BlockRef *infoBlockP, long *totItemsP, unsigned long *totalBytesInCacheP, Boolean *cacheFixedSizeP) = (void*)gsCallBacksPtr->BAPI_GetCache;

	return p(api_data, infoBlockP, totItemsP, totalBytesInCacheP, cacheFixedSizeP);
}

//===========================================================================================
XErr	BAPI_GetMaxUsers(long api_data, long *maxUsersP)
{
XErr	(*p)(long api_data, long *maxUsersP) = (void*)gsCallBacksPtr->BAPI_GetMaxUsers;

	return p(api_data, maxUsersP);
}
//===========================================================================================
XErr	BAPI_GetPoolFactor(long api_data, long *poolFactorP)
{
XErr	(*p)(long api_data, long *poolFactorP) = (void*)gsCallBacksPtr->BAPI_GetPoolFactor;

	return p(api_data, poolFactorP);
}

//===========================================================================================
XErr	BAPI_GetVersions(long api_data, char *versionStr, char *versionAPIStr, char *xlibVersStr)
{
XErr	(*p)(long api_data, char *versionStr, char *versionAPIStr, char *xlibVersStr) = (void*)gsCallBacksPtr->BAPI_GetVersions;

	return p(api_data, versionStr, versionAPIStr, xlibVersStr);
}

//===========================================================================================
XErr	BAPI_GetNumVersions(long api_data, unsigned long *version, unsigned long *versionBAPI, unsigned long *xlibVers)
{
XErr	(*p)(long api_data, unsigned long *version, unsigned long *versionBAPI, unsigned long *xlibVers) = (void*)gsCallBacksPtr->BAPI_GetNumVersions;

	return p(api_data, version, versionBAPI, xlibVers);
}

//===========================================================================================
XErr	BAPI_GetServerUpSince(long api_data, ObjRef *timeObjP)
{
XErr	(*p)(long api_data, ObjRef *timeObjP) = (void*)gsCallBacksPtr->BAPI_GetServerUpSince;

	return p(api_data, timeObjP);
}

//===========================================================================================
XErr	BAPI_GetBifernoHome(long api_data, XFilePathPtr homeStr)
{
XErr	(*p)(long api_data, XFilePathPtr homeStr) = (void*)gsCallBacksPtr->BAPI_GetBifernoHome;

	return p(api_data, homeStr);
}

//===========================================================================================
XErr	BAPI_Platform(long api_data, char *cStr, char *compilationFlags, long strSize)
{
XErr	(*p)(long api_data, char *cStr, char *compilationFlags, long strSize) = (void*)gsCallBacksPtr->BAPI_Platform;

	return p(api_data, cStr, compilationFlags, strSize);
}

//===========================================================================================
XErr	BAPI_OnError(long api_data, long mode, char *onErrorFunc, Boolean *stateP)
{
XErr	(*p)(long api_data, long mode, char *onErrorFunc, Boolean *stateP) = (void*)gsCallBacksPtr->BAPI_OnError;

	return p(api_data, mode, onErrorFunc, stateP);
}

//===========================================================================================
XErr	BAPI_Exit(long api_data)
{
XErr	(*p)(long api_data) = (void*)gsCallBacksPtr->BAPI_Exit;

	return p(api_data);
}

//===========================================================================================
XErr	BAPI_JavaGetCurrentJNIEnv(long api_data, void **envPPtr)
{
XErr	(*p)(long api_data, void **envPPtr) = (void*)gsCallBacksPtr->BAPI_JavaGetCurrentJNIEnv;

	return p(api_data, envPPtr);
}

//===========================================================================================
XErr	BAPI_JavaLoadJVM(long api_data)
{
XErr			(*p)(long api_data), err = noErr;
unsigned long	biferno_version;

	if NOT(err = BAPI_GetNumVersions(api_data, &biferno_version, nil, nil))
	{	if (biferno_version < 0x00010002)
			err = XError(kBAPI_Error, Err_NotImplemented);
		else
		{	p = (void*)gsCallBacksPtr->BAPI_JavaLoadJVM;
			err = p(api_data);
		}
	}

return err;
}

//===========================================================================================
/*XErr	BAPI_Super(long message, Biferno_ParamBlockPtr pbPtr, ObjRef *thisObjRefP, long classIDOfSuper)
{
XErr	(*p)(long message, Biferno_ParamBlockPtr pbPtr, ObjRef *thisObjRefP, long classIDOfSuper) = (void*)gsCallBacksPtr->BAPI_Super;

	return p(message, pbPtr, thisObjRefP, classIDOfSuper);
}
*/
//===========================================================================================
/*XErr	BAPI_Divert(long message, Biferno_ParamBlockPtr pbPtr, ObjRef *superObjRef)
{
XErr	(*p)(long message, Biferno_ParamBlockPtr pbPtr, ObjRef *superObjRef) = (void*)gsCallBacksPtr->BAPI_Divert;

	return p(message, pbPtr, superObjRef);
}
*/
//===========================================================================================
/*XErr	BAPI_DivertAll(long message, Biferno_ParamBlockPtr pbPtr, char *newClassName, long *newClassIDP, char *classToCloneName, long *classToCloneIDP)
{
XErr	(*p)(long message, Biferno_ParamBlockPtr pbPtr, char *newClassName, long *newClassIDP, char *classToCloneName, long *classToCloneIDP) = (void*)gsCallBacksPtr->BAPI_DivertAll;

	return p(message, pbPtr, newClassName, newClassIDP, classToCloneName, classToCloneIDP);
}*/

//===========================================================================================
XErr	BAPI_RegisterSymbol(long api_data, long classID, char *symbolName, long address)
{
XErr	(*p)(long api_data, long classID, char *symbolName, long address) = (void*)gsCallBacksPtr->BAPI_RegisterSymbol;

	return p(api_data, classID, symbolName, address);
}

//===========================================================================================
XErr	BAPI_GetSymbol(long api_data, long classID, char *symbolName, long *addressP)
{
XErr	(*p)(long api_data, long classID, char *symbolName, long *addressP) = (void*)gsCallBacksPtr->BAPI_GetSymbol;

	return p(api_data, classID, symbolName, addressP);
}
//===========================================================================================
/*XErr	BAPI_GetHeaderIn(long api_data, ObjRef *headObjRefP)
{
XErr	(*p)(long api_data, ObjRef *headObjRefP) = (void*)gsCallBacksPtr->BAPI_GetHeaderIn;

	return p(api_data, headObjRefP);
}
//===========================================================================================
XErr	BAPI_GetHeaderOut(long api_data, ObjRef *headObjRefP)
{
XErr	(*p)(long api_data, ObjRef *headObjRefP) = (void*)gsCallBacksPtr->BAPI_GetHeaderOut;

	return p(api_data, headObjRefP);
}

//===========================================================================================
XErr	BAPI_GetHeaderField(long api_data, char *fieldName, ObjRef *headObjRefP, Boolean out)
{
XErr	(*p)(long api_data, char *fieldName, ObjRef *headObjRefP, Boolean out) = (void*)gsCallBacksPtr->BAPI_GetHeaderField;

	return p(api_data, fieldName, headObjRefP, out);
}

//===========================================================================================
XErr	BAPI_AddHeaderField(long api_data, char *fieldName, char *value, long valueLen)
{
XErr	(*p)(long api_data, char *fieldName, char *value, long valueLen) = (void*)gsCallBacksPtr->BAPI_AddHeaderField;

	return p(api_data, fieldName, value, valueLen);
}
//===========================================================================================
XErr	BAPI_SetHeaderField(long api_data, char *fieldName, char *value, long valueLen)
{
XErr	(*p)(long api_data, char *fieldName, char *value, long valueLen) = (void*)gsCallBacksPtr->BAPI_SetHeaderField;

	return p(api_data, fieldName, value, valueLen);
}
//===========================================================================================
XErr	BAPI_RemoveHeaderField(long api_data, char *fieldName)
{
XErr	(*p)(long api_data, char *fieldName) = (void*)gsCallBacksPtr->BAPI_RemoveHeaderField;

	return p(api_data, fieldName);
}
*/
//===========================================================================================
XErr	BAPI_GetPluginRunData(long api_data, long classID, long *class_thread_dataP)
{
XErr	(*p)(long api_data, long classID, long *class_thread_dataP) = (void*)gsCallBacksPtr->BAPI_GetPluginRunData;

	return p(api_data, classID, class_thread_dataP);
}

//===========================================================================================
XErr	BAPI_SetPluginRunData(long api_data, long classID, long plugin_run_data)
{
XErr	(*p)(long api_data, long classID, long plugin_run_data) = (void*)gsCallBacksPtr->BAPI_SetPluginRunData;

	return p(api_data, classID, plugin_run_data);
}

//===========================================================================================
XErr	BAPI_GetConfig(long api_data, char *configName, char *result, long *resultLenP, Boolean *isDefP)
{
XErr	(*p)(long api_data, char *configName, char *result, long *resultLenP, Boolean *isDef) = (void*)gsCallBacksPtr->BAPI_GetConfig;

	return p(api_data, configName, result, resultLenP, isDefP);
}

//===========================================================================================
XErr	BAPI_GetBooleanConfig(long api_data, char *configName, Boolean *resultP, Boolean *isDefP)
{
XErr	(*p)(long api_data, char *configName, Boolean *resultP, Boolean *isDef) = (void*)gsCallBacksPtr->BAPI_GetBooleanConfig;

	return p(api_data, configName, resultP, isDefP);
}

//===========================================================================================
XErr	BAPI_GetIntConfig(long api_data, char *configName, long *resultP, Boolean *isDefP)
{
XErr	(*p)(long api_data, char *configName, long *resultP, Boolean *isDefP) = (void*)gsCallBacksPtr->BAPI_GetIntConfig;

	return p(api_data, configName, resultP, isDefP);
}

//===========================================================================================
XErr	BAPI_GetUnsignedConfig(long api_data, char *configName, unsigned long *resultP, Boolean *isDefP)
{
XErr	(*p)(long api_data, char *configName, unsigned long *resultP, Boolean *isDef) = (void*)gsCallBacksPtr->BAPI_GetUnsignedConfig;

	return p(api_data, configName, resultP, isDefP);
}

//===========================================================================================
XErr	BAPI_GetSID(long api_data, char *SIDStr, char *XIDStr)
{
XErr	(*p)(long api_data, char *SIDStr, char *XIDStr) = (void*)gsCallBacksPtr->BAPI_GetSID;

	return p(api_data, SIDStr, XIDStr);
}

//===========================================================================================
XErr	BAPI_SetSID(long api_data, char *SIDStr, char *XIDStr, Boolean isNew)
{
XErr	(*p)(long api_data, char *SIDStr, char *XIDStr, Boolean isNew) = (void*)gsCallBacksPtr->BAPI_SetSID;

	return p(api_data, SIDStr, XIDStr, isNew);
}

//===========================================================================================
XErr	BAPI_CheckSID(long api_data, char *SIDStr, char *XIDStr, Boolean *validP)
{
XErr	(*p)(long api_data, char *SIDStr, char *XIDStr, Boolean *validP) = (void*)gsCallBacksPtr->BAPI_CheckSID;

	return p(api_data, SIDStr, XIDStr, validP);
}

//===========================================================================================
XErr	BAPI_GetIndSID(long api_data, long index, char *SIDStr)
{
XErr	(*p)(long api_data, long index, char *SIDStr) = (void*)gsCallBacksPtr->BAPI_GetIndSID;

	return p(api_data, index, SIDStr);
}

//===========================================================================================
XErr	BAPI_SessionVariableToString(long api_data, char *SIDStr, char *varName, char *strP, long *strLenP, long maxLen)
{
XErr	(*p)(long api_data, char *SIDStr, char *varName, char *strP, long *strLenP, long maxLen) = (void*)gsCallBacksPtr->BAPI_SessionVariableToString;

	return p(api_data, SIDStr, varName, strP, strLenP, maxLen);
}

//===========================================================================================
/*XErr	BAPI_GetTimeout(long api_data, unsigned long *timeOutP)
{
XErr	(*p)(long api_data, unsigned long *timeOutP) = (void*)gsCallBacksPtr->BAPI_GetTimeout;

	return p(api_data, timeOutP);
}
*/
//===========================================================================================
XErr	BAPI_GetCurrentScriptStatus(long api_data, long *statusP)
{
XErr	(*p)(long api_data, long *statusP) = (void*)gsCallBacksPtr->BAPI_GetCurrentScriptStatus;

	return p(api_data, statusP);
}

//===========================================================================================
XErr	BAPI_SetTimeout(long api_data, unsigned long newTimeOut)
{
XErr	(*p)(long api_data, unsigned long newTimeOut) = (void*)gsCallBacksPtr->BAPI_SetTimeout;

	return p(api_data, newTimeOut);
}

//===========================================================================================
XErr	BAPI_Yield(long api_data, unsigned long *lastTicksP)
{
XErr	(*p)(long api_data, unsigned long *lastTicksP) = (void*)gsCallBacksPtr->BAPI_Yield;

	return p(api_data, lastTicksP);
}

//===========================================================================================
XErr	BAPI_SetNumberFormat(long api_data, Byte thousSep, Byte decSep)
{
XErr	(*p)(long api_data, Byte thousSep, Byte decSep) = (void*)gsCallBacksPtr->BAPI_SetNumberFormat;

	return p(api_data, thousSep, decSep);
}

//===========================================================================================
XErr	BAPI_GetNumberFormat(long api_data, Byte *thousSepP, Byte *decSepP)
{
XErr	(*p)(long api_data, Byte *thousSepP, Byte *decSepP) = (void*)gsCallBacksPtr->BAPI_GetNumberFormat;

	return p(api_data, thousSepP, decSepP);
}

//===========================================================================================
XErr	BAPI_GetDateFormat(long api_data, char *formatStr)
{
XErr	(*p)(long api_data, char *formatStr) = (void*)gsCallBacksPtr->BAPI_GetDateFormat;

	return p(api_data, formatStr);
}

//===========================================================================================
XErr	BAPI_GetReference(long api_data, char *targetStr, ObjRef *targetObjRefP, BlockRef *targetPropListP)
{
XErr	(*p)(long api_data, char *targetStr, ObjRef *targetObjRefP, BlockRef *targetPropListP) = (void*)gsCallBacksPtr->BAPI_GetReference;

	return p(api_data, targetStr, targetObjRefP, targetPropListP);
}

//===========================================================================================
XErr	BAPI_DisposePropertyList(long api_data, BlockRef *targetPropListP)
{
XErr	(*p)(long api_data, BlockRef *targetPropListP) = (void*)gsCallBacksPtr->BAPI_DisposePropertyList;

	return p(api_data, targetPropListP);
}

//===========================================================================================
XErr	BAPI_ClonePropertyList(long api_data, BlockRef source, BlockRef *destP)
{
XErr	(*p)(long api_data, BlockRef source, BlockRef *destP) = (void*)gsCallBacksPtr->BAPI_ClonePropertyList;

	return p(api_data, source, destP);
}

//===========================================================================================
XErr	BAPI_ApplyPropertyList(long api_data, ObjRef *targetP, BlockRef targetPropList, long mode, Boolean skipLast, ObjRef *obj2P)
{
XErr	(*p)(long api_data, ObjRef *targetP, BlockRef targetPropList, long mode, Boolean skipLast, ObjRef *obj2P) = (void*)gsCallBacksPtr->BAPI_ApplyPropertyList;

	return p(api_data, targetP, targetPropList, mode, skipLast, obj2P);
}

//===========================================================================================
XErr	BAPI_GetPropertyListNames(long api_data, BlockRef targetPropList, BlockRef *resultP, long *resultLenP)
{
XErr	(*p)(long api_data, BlockRef targetPropList, BlockRef *resultP, long *resultLenP) = (void*)gsCallBacksPtr->BAPI_GetPropertyListNames;

	return p(api_data, targetPropList, resultP, resultLenP);
}

//===========================================================================================
XErr	BAPI_GetPropertyListClassID(long api_data, BlockRef targetPropList, long *classIDP)
{
XErr	(*p)(long api_data, BlockRef targetPropList, long *classIDP) = (void*)gsCallBacksPtr->BAPI_GetPropertyListClassID;

	return p(api_data, targetPropList, classIDP);
}

//===========================================================================================
XErr	BAPI_MakeRef(long api_data, ObjRef *objRefP, ObjRef *targetP)
{
XErr	(*p)(long api_data, ObjRef *objRefP, ObjRef *targetP) = (void*)gsCallBacksPtr->BAPI_MakeRef;

	return p(api_data, objRefP, targetP);
}

//===========================================================================================
Boolean	BAPI_IsReference(long api_data, ObjRef *objRefP)
{
Boolean	(*p)(long api_data, ObjRef *objRefP) = (void*)gsCallBacksPtr->BAPI_IsReference;

	return p(api_data, objRefP);
}

//===========================================================================================
XErr	BAPI_GetReferenceTarget(long api_data, ObjRefP objRef, ObjRefP targetP)
{
XErr	(*p)(long api_data, ObjRefP objRef, ObjRefP targetP) = (void*)gsCallBacksPtr->BAPI_GetReferenceTarget;

	return p(api_data, objRef, targetP);
}

