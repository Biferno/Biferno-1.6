/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoErrors.c,v 1.29 2008-11-27 15:25:37 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "BifernoErrors.h"
#include "Entity.h"
#include "Load.h"
#include "BfrParser.h"
#include "Classes.h"

#include <string.h>

extern 	DispatcherData		gsDispatcherData;
extern	BAPIErrorRecord		gBifernoErrorsRec[];

#define	ERR_MAX	255 - 5		// -5 for \r\n or ... etc.. (just in case)

//===========================================================================================
static Boolean	_CanResume(long eType, long eValue)
{
Boolean	res;

	if (eType == kBAPI_ClassError)
		res = true;
	else if (eValue)
	{	int	idx = eValue - BIFERNO_BASE_ERROR;
		
		if ((idx >= 0) && (idx < Err_LastErr))
			res = gBifernoErrorsRec[idx].resumable;
		else
			res = false;
	
		/*switch(eValue)
		{
			case Err_OSError:
			case Err_VariableNotPublished:
			case Err_StringTooLong:
			case Err_OutOfBoundary:
			case Err_IllegalTypeCast:
			case Err_VariableNotDefined:
			case Err_HTTPBodyTooLong:
			case Err_FileNotFound:
			case Err_FolderNotFound:
			
			case Err_WalkFolderAbort:
			case Err_DuplicatedFile:
		
			case Err_CookieDisabled:
			case Err_InvalidSessionCookie:
				res = true;
				break;
		
			default:
				res = false;
				break;
		}*/
	}
	else
		res = true;

return res;
}

//===========================================================================================
XErr	UpdateErrObject(long api_data, XErr theError, ObjRecord *resultErrObjRefP, Boolean *canResumeP)
{	
ParameterRec	errParams[3];
XErr			err = noErr;	//, err2 = noErr;
Boolean			saveFromUpdateObject, canResume, exists;
CStr255			subErrStr, aCStr;
long 			actualValue, eNum, eType;
ObjRecord		errRef;
BifernoRecP		bRecP = (BifernoRecP)api_data;
CStr63			className;
ObjRecord		tempObjRef;

	*subErrStr = 0;
	Err2BAPIErr(api_data, &theError, subErrStr);
	XErrorGetTypeValue(theError, &eNum, &eType);
	canResume = _CanResume(eType, eNum);
	if (canResumeP)
		*canResumeP = canResume;
	if (err = BAPI_IsVariableDefined(api_data, "err", GLOBAL, &exists, OBJREF_P(&errRef)))
		goto out;
	if (exists)
	{	bRecP->errUpdated = true;
		err = BAPI_ObjToInt(api_data, OBJREF_P(&errRef), &actualValue, kExplicitTypeCast);
	}
	else
		actualValue = 0;
	if (err)
		goto out;
	else if (bRecP->resumeAlwaysCaller && bRecP->inDebugPage)
	{	*resultErrObjRefP = errRef;
		goto out;
	}
	BAPI_ClearParameterRec(api_data, &errParams[0]);
	BAPI_ClearParameterRec(api_data, &errParams[1]);
	BAPI_ClearParameterRec(api_data, &errParams[2]);
	if (err = BAPI_IntToObj(api_data, eNum, &errParams[0].objRef))
		goto out;
	sprintf(aCStr, ":%s", subErrStr);
	if (err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &errParams[1].objRef))
		goto out;
	if (eType == kBAPI_ClassError)
	{	if (bRecP->lastClassIDErrorCalled)
			err = BAPI_NameFromClassID(api_data, bRecP->lastClassIDErrorCalled, className);
		else
			*className = 0;
	}
	else
		*className = 0;
	if NOT(err)
		err = BAPI_StringToObj(api_data, className, CLen(className), &errParams[2].objRef);
	if (err)
		goto out;
	
	saveFromUpdateObject = bRecP->fromUpdateObject;
	bRecP->fromUpdateObject = true;
	if (exists)
	{	INVAL(tempObjRef);
		if NOT(err = CL_Constructor(api_data, TEMP, VARIABLE, nil, gsDispatcherData.errConstructor, errParams, 3, nil, &tempObjRef))
		{	if NOT(err = BAPI_ExecuteMethod(api_data, OBJREF_P(&tempObjRef), nil, 0, "Update", nil, nil))
			{	if NOT(err = ModifyVariable(api_data, &errRef, &tempObjRef, kExplicitTypeCast, false, nil))
					*resultErrObjRefP = errRef;
			}
		}
	}
	else
	{	if NOT(err = CL_Constructor(api_data, GLOBAL, VARIABLE, "err", gsDispatcherData.errConstructor, errParams, 1, nil, resultErrObjRefP))
		{	if (eNum)
				err = BAPI_ExecuteMethod(api_data, OBJREF_P(resultErrObjRefP), nil, 0, "Update", nil, nil);
		}
	}
	bRecP->fromUpdateObject = saveFromUpdateObject;
	/*}
	else
	{	bRecP->moreErrors = true;
		*resultErrObjRefP = errRef;
	}*/

out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
XErr	BfrStackDisposeLocals(BifernoRecP bRecP)
{
StackRecord		*stackP;
int				i, curSP;
BfrDestructRec	destructRec;
XErr			err = noErr, err2 = noErr;

	destructRec.api_data = (long)bRecP;
	curSP = bRecP->stackPointer;
	BufferGetBlockRefExt(bRecP->stackBufferID, (Ptr*)&stackP);
	destructRec.scope = LOCAL;
	for (i = 0; i < curSP; i++, stackP++)
	{	if (err = DLM_Dispose(&stackP->localList, VariableDestructor, (long)&destructRec))
		{	
			// return the first error
			if NOT(err2)
				err = err2;
		}
	}
	
return err;
}

//===========================================================================================
StackRecord*	BfrGetIndStack(BifernoRecP bRecP, int index)
{
	StackRecord		*baseStackP, *resStackP;
	
	BufferGetBlockRefExt(bRecP->stackBufferID, (Ptr*)&baseStackP);
	if (index)
	{	
		if (index < 0)
			resStackP = nil;
		else
			resStackP = &baseStackP[index-1];
	}
	else
		resStackP = &baseStackP[bRecP->stackPointer-1];

	return resStackP;
}

//===========================================================================================
DLMRef	BfrGetIndStackList(BifernoRecP bRecP, int index)
{
	StackRecord		*stackP;

	BufferGetBlockRefExt(bRecP->stackBufferID, (Ptr*)&stackP);
	
return stackP[index-1].localList;
}

//===========================================================================================
XErr	BfrLessStack(BifernoRecP bRecP, BAPI_Doc *bisFunctionP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(bisFunctionP)
#endif

	if (--(bRecP->stackPointer) < 0)
		CDebugStr("impossible stack");
	//printf("removed %s\n", bisFunctionP->prototype);

return noErr;
}

//===========================================================================================
// ex XErr	FillStack(BifernoRecP bRecP, BAPI_Doc *bisFunctionP, char *filePath, long line, char *altName)
XErr	BfrMoreStack(BifernoRecP bRecP, BAPI_Doc *bisFunctionP)
{
XErr			err = noErr;
StackRecord		*stackP;
int				curSP;

	curSP = bRecP->stackPointer;
	if NOT(err = BufferCheck(bRecP->stackBufferID, sizeof(StackRecord) * (curSP + 1), nil))
	{	
		BufferGetBlockRefExt(bRecP->stackBufferID, (Ptr*)&stackP);
		stackP += curSP;
		if (bisFunctionP)
		{	
			CEquStr(stackP->prototype, bisFunctionP->prototype);
			stackP->classOwner = bisFunctionP->info.method.classID;
			stackP->line = bRecP->currentCtx.currentLine + bRecP->currentCtx.bisFunctionInitLine;
			stackP->bisFunctionInitLine = 1 + bisFunctionP->ident.b.fileLine;
		}
		else // main
		{	
			CEquStr(stackP->prototype, "__main()");
			stackP->classOwner = 0;
			stackP->line = 1;
			stackP->bisFunctionInitLine = 1;
		}
		stackP->includeStackPointer = bRecP->includeStackPointer;
		stackP->thisObjRef = *(ObjRef*)&bRecP->thisObjRef;
		DLM_GetTotObjs(bRecP->localList, &stackP->totInputs, false);
		
		//printf("added %s\n", stackP->prototype);
		CEquStr(stackP->filePath, bRecP->currentCtx.currentExecFile);
		stackP->localList = bRecP->localList;
		bRecP->stackPointer++;
	}

return err;
}

//===========================================================================================
XErr	BfrLessIncludeStack(BifernoRecP bRecP)
{
#if __C_HAS_PRAGMA_UNUSED__
#pragma unused(bisFunctionP)
#endif
	
	if (--(bRecP->includeStackPointer) < 0)
		CDebugStr("impossible include stack");
	
	return noErr;
}

//===========================================================================================
XErr	BfrMoreIncludeStack(BifernoRecP bRecP, char *includeFile, int curLine)
{
	XErr					err = noErr;
	IncludeStackRecord		*stackP;
	int						curSP;
	StackRecord				*curStackP;
	
	curSP = bRecP->includeStackPointer;
	if NOT(err = BufferCheck(bRecP->includeStackBufferID, sizeof(IncludeStackRecord) * (curSP + 1), nil))
	{	
		BufferGetBlockRefExt(bRecP->includeStackBufferID, (Ptr*)&stackP);
		stackP += curSP;
		CEquStr(stackP->filePath, includeFile);
		curStackP = BfrGetIndStack(bRecP, bRecP->stackPointer);
		stackP->line = curStackP->bisFunctionInitLine - 1 + curLine;
		bRecP->includeStackPointer++;
	}
	
	return err;
}

//===========================================================================================
XErr	PrintStack(BifernoRecP bRecP, BufferID output)
{
XErr		err = noErr;
BlockRef	blockRef;
Ptr			tempP;
long		totStacks, size;
StackRecord	*stackP;
CStr255		aCStr;
int			i;

	if (bRecP->stackBufferID)
	{	if (err = BufferAddCString(output, "<p><p>\r\n\r\n<p><a name=\"Stack\"><p></a><TABLE CELLPADDING=4 BORDER=2 WIDTH=\"100%\" BGCOLOR=\"#CCCCCC\">", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(output, "<tr><th colspan=\"3\"><font face=\"monaco\" color=\"red\" size=\"2\">Stack Trace</font></th></tr>", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(output, "<tr><th><font face=\"monaco\" size=\"2\">File</font></th><th><font face=\"monaco\" size=\"2\">Line</font></th><th><font face=\"monaco\" size=\"2\">Call</font></th></tr>", NO_ENC, 0))
			goto out;
		blockRef = BufferGetBlockRefExtSize(bRecP->stackBufferID, &size, &tempP);
		LockBlock(blockRef);
		stackP = (StackRecord*)tempP;
		totStacks = bRecP->stackPointer;	//size / sizeof(StackRecord);
		stackP += totStacks - 1;
		for (i = 0; i < totStacks; i++, stackP--)
		{	
			if (err = BufferAddCString(output, "<tr><td><font face=\"monaco\" size=\"2\">", NO_ENC, 0))
				goto out;
			CNumToString(totStacks-i, aCStr);
			if (err = BufferAddCString(output, aCStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(output, ") ", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(output, stackP->filePath, NO_ENC, 0))
				goto out;
			/*if (err = BufferAddCString(output, "<b>", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(output, stackP->fileName, NO_ENC, 0))
				goto out;*/
			if (err = BufferAddCString(output, "</b>", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(output, "</font></td><td><font face=\"monaco\" size=\"2\"><b>", NO_ENC, 0))
				goto out;
			CNumToString(stackP->line, aCStr);
			if (err = BufferAddCString(output, aCStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(output, "</b></font></td><td><font face=\"monaco\" size=\"2\">", NO_ENC, 0))
				goto out;
			if (*stackP->prototype)
			{	/*if (*stackP->type)
				{	if (err = BufferAddCString(output, stackP->type, NO_ENC, 0))
						goto out;
				}*/
				if (err = BufferAddCString(output, " <b>", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(output, stackP->prototype, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(output, "</b>", NO_ENC, 0))
					goto out;
				if (stackP->classOwner)
				{	if NOT(err = BAPI_NameFromClassID((long)bRecP, stackP->classOwner, aCStr))
					{	if (err = BufferAddCString(output, " of class <b>", NO_ENC, 0))
							goto out;
						if (err = BufferAddCString(output, aCStr, NO_ENC, 0))
							goto out;
						if (err = BufferAddCString(output, "</b> ", NO_ENC, 0))
							goto out;
					}
				}
			}
			if (err = BufferAddCString(output, "</font></td></tr>", NO_ENC, 0))
				goto out;
		}
		if (err = BufferAddCString(output, "</table>", NO_ENC, 0))
			goto out;
		//BufferFree(bRecP->stackBufferID);
		//bRecP->stackBufferID = 0;
		if (err = BufferAddCString(output, "</td></tr></table>", NO_ENC, 0))
			goto out;
	}

out:
return err;
}

//===========================================================================================
/*long	GetTotMsgRecords(long api_data)
{
BifernoRec	*bRecP;
long		tot;

	printf("GetTotMsgRecords\n");
	if (bRecP = (BifernoRecP)api_data)
		tot = bRecP->errMessageRec.totMsg;
	else
		tot = 0;

return tot;
}

//===========================================================================================
void	SetTotMsgRecords(long api_data, long msgRecLevel)
{
BifernoRec	*bRecP;

	printf("SetTotMsgRecords\n");
	if (bRecP = (BifernoRecP)api_data)
		bRecP->errMessageRec.totMsg = msgRecLevel;
}

//===========================================================================================
XErr	GetMsgRecords(long api_data, ErrorMsgRecord *errMessageRecP)
{
BifernoRec		*bRecP;
XErr			err = noErr;

	printf("GetMsgRecords\n");
	if (bRecP = (BifernoRecP)api_data)
		CopyBlock(errMessageRecP, &bRecP->errMessageRec, sizeof(ErrorMsgRecord));
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	SetMsgRecords(long api_data, ErrorMsgRecord *errMessageRecP)
{
BifernoRec		*bRecP;
XErr			err = noErr;

	printf("SetMsgRecords\n");
	if (bRecP = (BifernoRecP)api_data)
		CopyBlock(&bRecP->errMessageRec, errMessageRecP, sizeof(ErrorMsgRecord));
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	GetTheLastMsgRecord(long api_data, char *title, char *msg)
{
XErr			err = noErr;
BifernoRec		*bRecP;
ErrorMsgRecord	*msgRecP;
ErrorMsgItem	*msgItemP;
int				totMsgRecord;//, i;

	printf("GetTheLastMsgRecord\n");
	if (bRecP = (BifernoRecP)api_data)
	{	msgRecP = &bRecP->errMessageRec;
		if (totMsgRecord = GetTotMsgRecords(api_data))
		{	msgItemP = &msgRecP->msg[0];
			CEquStr(title, msgItemP->title);
			CEquStr(msg, msgItemP->msg);
		}
		else
			*title = *msg = 0;
	}

return err;
}

//===========================================================================================
XErr	ResetMsgRecords(long api_data)
{
BifernoRec		*bRecP;
XErr			err = noErr;

	printf("ResetMsgRecords\n");
	if (bRecP = (BifernoRecP)api_data)
	{	bRecP->errMessageRec.totMsg = 0;
		bRecP->errMessageRec.varNameSet = false;
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
return err;
}
*/

//===========================================================================================
XErr	PrintMsgRecords(long api_data, long bufferID, long encodeMode)
{
XErr			err = noErr;
BifernoRec		*bRecP;
ErrorMsgRecord	*msgRecP;
ErrorMsgItem	*msgItemP;
int				totMsgRecord, i;
CStr255			tempStr;

	if (bRecP = (BifernoRecP)api_data)
	{	msgRecP = &bRecP->errMessageRec;
		if (totMsgRecord = bRecP->errMessageRec.totMsg/*GetTotMsgRecords(api_data)*/)
		{	msgItemP = &msgRecP->msg[0];
			for (i = 0; i < totMsgRecord; i++, msgItemP++)
			{	if (err = BufferAddCString(bufferID, "<p><font face=\"monaco\" size=\"2\"><b>", NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(bufferID, msgItemP->title, NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(bufferID, "</b><br>", NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(bufferID, msgItemP->msg, encodeMode, kTagsVisible+kAlsoCR))
					goto out;
				if (err = BufferAddCString(bufferID, "</font><br>\r\n", NO_ENC, 0))
					goto out;
			}
		}

		if (bRecP->currentCtx.lastMultiStrStart && bRecP->currentCtx.lastMultiStrEnd && (bRecP->currentCtx.lastMultiStrStart < bRecP->currentCtx.lastMultiStrEnd))
		{	if (err = BufferAddCString(bufferID, "<p><font face=\"monaco\" size=\"2\"><b>Warning:</b><br>", NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(bufferID, "Possible unwanted multiline string from line ", NO_ENC, 0))
				goto out;			
			CNumToString(bRecP->currentCtx.lastMultiStrStart, tempStr);
			if (err = BufferAddCString(bufferID, tempStr, NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(bufferID, "</font><br>\r\n", NO_ENC, 0))
				goto out;
		}
	}

out:
return err;
}

//===========================================================================================
static XErr	_Complete_NameFromClassID(long api_data, long classID, char *className)
{	
XErr		err = noErr;
CStr255		tempStr;

	if NOT(err = BAPI_NameFromClassID(api_data, classID, tempStr))
	{	if IS_LOCAL(classID)
			CEquStr(className, "local ");
		else if (classID < 0)
			CEquStr(className, "application ");
		else
			*className = 0;
		CAddStr(className, tempStr);
	}
	
return err;
}

//===========================================================================================
static XErr	_GetAlternativeToName(long api_data, ObjRefP objRefP, long classID, char *result)
{
BifernoRec	*bRecP;
XErr		err = noErr;
long		totLen;
CStr63		tempStr;
Boolean		saveSuspendMsgs;

	bRecP = (BifernoRecP)api_data;
	saveSuspendMsgs = bRecP->suspendMsgs;
	bRecP->suspendMsgs = true;
	err = BAPI_ObjToString(api_data, objRefP, tempStr, &totLen, 32, kImplicitTypeCast);
	if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
	{	CAddStr(tempStr, "...");
		err = noErr;
	}
	if (err)
		err = _Complete_NameFromClassID(api_data, classID, result);
	else
	{	CEquStr(result, "\"");
		CAddStr(result, tempStr);
		CAddStr(result, "\"");
	}
	bRecP->suspendMsgs = saveSuspendMsgs;

return err;
}


//===========================================================================================
/*
in test, per ora un solo messaggio
*/
XErr	NewMsgRecord(long api_data, char *title, char *msg, long msgLen, long flags)
{
BifernoRec		*bRecP;
ErrorMsgRecord	*msgRecP;
ErrorMsgItem	*msgItemP;
int				idx, tot;
int				sourceLen;
int				max, titleLen;
XErr			err = noErr;
Boolean			addPeriods;
CStr63			class1, class2, name;
long			classID1;

	if (bRecP = (BifernoRecP)api_data)
	{	if (bRecP->suspendMsgs)
			return noErr;
		msgRecP = &bRecP->errMessageRec;
		if (bRecP->inDebugPage && NOT(bRecP->inDebugPageReset))
		{	msgRecP->totMsg = 0;	// reset
			bRecP->inDebugPageReset = true;
		}
		if (((tot = msgRecP->totMsg) < MAX_ERR_MSG) && (flags || (msg && *msg)))
		{	// Debug
			/*if NOT(flags)
				printf(" -------------------- NewMsgRecord %s %s\n", title, msg);
			else
				printf(" -------------------- NewMsgRecord %s %d\n", title, msg);*/
			// --
			msgItemP = &msgRecP->msg[tot];
			idx = tot;
			titleLen = CLen(title);
			if (titleLen > 63)
				titleLen = 63;
			CopyBlock(msgItemP->title, title, titleLen);
			msgItemP->title[titleLen] = 0;
			if (flags & kInputIsClassName)
				err = BAPI_NameFromClassID(api_data, msgLen, msgItemP->msg);
			else if (flags & kInputIsClassID)
			{	if NOT(err = _Complete_NameFromClassID(api_data, (long)msg, class1))
				{	if NOT(err = _Complete_NameFromClassID(api_data, msgLen, class2))
					{	CEquStr(msgItemP->msg, class1);
						CAddStr(msgItemP->msg, " -> ");
						CAddStr(msgItemP->msg, class2);
					}
				}
			}
			else if (flags & kInputIsObj)
			{	if NOT(err = BAPI_GetObjInfo(api_data, (ObjRefP)msg, &classID1, name))
				{	if NOT(err = _Complete_NameFromClassID(api_data, msgLen, class2))
					{	if NOT(*name)
							err = _GetAlternativeToName(api_data, (ObjRefP)msg, classID1, name);
						if NOT(err)
						{	CEquStr(msgItemP->msg, name);
							CAddStr(msgItemP->msg, " -> ");
							CAddStr(msgItemP->msg, class2);
						}
					}
				}
			}
			else
			{	if NOT(msgLen)
					msgLen = CLen(msg);
				sourceLen = msgLen;
				max = MAX_ERROR_MSG_LENGTH - 3;	// for 3 periods
				if (sourceLen > max)
				{	sourceLen = max;
					addPeriods = true;
				}
				else
					addPeriods = false;
				CopyBlock(msgItemP->msg, msg, sourceLen);
				msgItemP->msg[sourceLen] = 0;
				if (addPeriods)
					CAddStr(msgItemP->msg, "...");
				msgLen = CLen(msgItemP->msg);
				// Can give you more info?
				/*if (msgLen < 63)
				{	
				Boolean		isClass, isFunc, isVar;
				
					isClass = isFunc = isVar = false;
					// is a class?
					{	if (BAPI_ClassIDFromName(api_data, msgItemP->msg, false))
							isClass = true;
					}
					// is a function?
					{
					Boolean	exists;
					
						if (NOT(GetFunctionInfo(api_data, nil, nil, msgItemP->msg, nil, &exists)) && exists)
							isFunc = true;
					}
					// is a variable?
					{
					long	varClassID, tScope, varList, save2, found;
					Boolean	save1;

						save1 = bRecP->loadingClass;
						save2 = bRecP->currentCtx.methodInExecutionID;
						bRecP->loadingClass = bRecP->currentCtx.methodInExecutionID == 0;
						varList = tScope = 0;
						found = LookForObj(api_data, msgItemP->msg, &varList, nil, &varClassID, &tScope, nil);
						bRecP->loadingClass = save1;
						bRecP->currentCtx.methodInExecutionID = save2;
						if (found && varClassID)
							isVar = true;
					}
					if (isClass)
						CAddStr(msgItemP->msg, " (is the name of a class)");
					if (isFunc)
						CAddStr(msgItemP->msg, " (is the name of a function)");
					if (isVar)
						CAddStr(msgItemP->msg, " (is the name of a variable)");
				}*/
			}
			// If message was added increment totMsg (Note: don't add if it is the identical to previous)
			if (*msgItemP->title && *msgItemP->msg)
				msgRecP->totMsg++;
			else
			{	*msgItemP->title = 0;
				*msgItemP->msg = 0;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static void		_OSErrToBAPIErr(long theError, long *eNumP, char *subErrStr, char *eNameStr, char *errType)
{
long		eType;
long		subErr;
CStr255		tempStr;
int			idx;

	eType = kBAPI_Error;
	subErr = *eNumP;
	*eNumP = Err_OSError;
	if (subErrStr)
	{	*subErrStr = 0;
		CNumToString(subErr, subErrStr);
		CAddStr(subErrStr, ": ");
		ErrorGetDescr(theError, tempStr, nil);
		CAddStr(subErrStr, tempStr);
	}
	idx = *eNumP - BIFERNO_BASE_ERROR;
	if (eNameStr)
	{	if ((idx >= 0) && (idx < Err_LastErr))
			CEquStr(eNameStr, gBifernoErrorsRec[idx].name);
		else
			CEquStr(eNameStr, "Unknown Error");
	}
	if (errType)
		CEquStr(errType, "BIFERNO ERROR");
}

//===========================================================================================
static void		_XLibErrToBAPIErr(long *eNumP, char *eNameStr, char *errType)
{
int			idx;

	switch(*eNumP)
	{
		case ErrXFiles_FileNotFound:
			*eNumP = Err_FileNotFound;
			break;
		case ErrXFiles_FolderNotFound:
			*eNumP = Err_FolderNotFound;
			break;
		case ErrXFiles_PathTooLong:
			*eNumP = Err_PathTooLong;
			break;
		case ErrXFiles_LockNotSupported:
			*eNumP = Err_LockNotSupported;
			break;
		case ErrXFiles_FolderIsNotEmpty:
			*eNumP = Err_FolderIsNotEmpty;
			break;
		case ErrXFiles_EndOfFile:
			*eNumP = Err_EndOfFile;
			break;
		case ErrXFiles_WalkFolderAbort:
			*eNumP = Err_WalkFolderAbort;
			break;
		case ErrXFiles_DuplicatedFile:
			*eNumP = Err_DuplicatedFile;
			break;
		case ErrXFiles_UnknownUser:
			*eNumP = Err_UnknownUser;
			break;
		case ErrXFiles_UnknownGroup:
			*eNumP = Err_UnknownGroup;
			break;
		case ErrXFiles_BadFileRef:
			*eNumP = Err_BadFileRef;
			break;
			
		case ErrXMemory_BadRef:
			*eNumP = Err_BadMemoryRef;
			break;
		case ErrXMemory_NullSize:
			*eNumP = Err_NullSizeBlock;
			break;
		case ErrXMemory_BadBlockSize:
			*eNumP = Err_BadBlockSize;
			break;
		case ErrXMemory_Full:
			*eNumP = Err_MemoryFull;
			break;
		case ErrXMemory_SlotsFull:
			*eNumP = Err_MemorySlotsFull;
			break;
		case ErrXMemory_SlotMgrUninitialized:
			*eNumP = Err_SlotMgrUnavailable;
			break;
		case ErrXMemory_AttemptToDisposeTwice:
			*eNumP = Err_FreeBlock;
			break;
		
		/*case ErrDNRFailed:
			*eNumP = Err_DNRFailed;
			break;*/
		
		case ErrXThreads_Timeout:
			*eNumP = Err_ThreadTimeout;
			break;
		case ErrXThreads_InternalErr:
			*eNumP = Err_ThreadsInternalErr;
			break;
		/*case ErrXThreads_RefAlredyUsed:
			*eNumP = Err_ThreadsRefAlreadyUsed;
			break;*/
		case ErrXThreads_NotFound:
			*eNumP = Err_ThreadNotFound;
			break;
		/*case ErrXThreads_CantInitializeJava:
			*eNumP = Err_CantInitializeJavaThread;
			break;*/
			
		case ErrXDateTimeFormatError:
			*eNumP = Err_DateTimeFormatError;
			break;
			
		case ErrXDLLCantLoadObject:
			*eNumP = Err_CantLoadShObject;
			break;
		case ErrXDLLCantFindSymbol:
			*eNumP = Err_CantFindShLibSymbol;
			break;
		case ErrXDLLCantCloseObject:
			*eNumP = Err_CantCloseShLib;
			break;		
		
		case ErrXConvertingStringToLong:
			*eNumP = Err_ConvertingStringToLong;
			break;
		case ErrXConversion:
			*eNumP = Err_BadSyntax;
			break;
			
		case ErrXLibNumOverFlow:
			*eNumP = Err_Overflow;
			break;		
		
		case ErrNotImplementedInXLib:
			*eNumP = Err_NotImplemented;
			break;

		case ErrConnectionBroken:
			*eNumP = Err_ConnectionBroken;
			break;
			
		case ErrXLibTooOld:
			*eNumP = Err_XLibTooOld;
			break;
		case ErrXLibTooNew:
			*eNumP = Err_XLibTooNew;
			break;
		case ErrXLibCallerTooOld:
			*eNumP = Err_XLibCallerTooOld;
			break;
		case ErrXLibCallerTooNew:
			*eNumP = Err_XLibCallerTooNew;
			break;

		case ErrThreadAborted:
			*eNumP = Err_ProcessShutDown;
			break;


		default:
			*eNumP = Err_UnknownXLibError;
			break;
	}
	
	if (eNameStr)
	{	idx = *eNumP - BIFERNO_BASE_ERROR;
		if ((idx >= 0) && (idx < Err_LastErr))
			CEquStr(eNameStr, gBifernoErrorsRec[idx].name);
		else
			CEquStr(eNameStr, "Unknown Error");
	}
	if (errType)
		CEquStr(errType, "BIFERNO ERROR");
}

//===========================================================================================
static void		_XLibHelpersErrToBAPIErr(long *eNumP, char *eNameStr, char *errType)
{
int			idx;

	switch(*eNumP)
	{
		case Buffers_Err_NotInitialized:
			*eNumP = Err_BuffersNotInitialized;
			break;
		case Buffers_Err_BadID:
			*eNumP = Err_BuffersBadID;
			break;
		
		case Cache_Err_NotInitialized:
			*eNumP = Err_CacheNotInitialized;
			break;
		case Cache_Err_PathTooLong:
			*eNumP = Err_CachePathTooLong;
			break;
		/*case Cache_Err_UserDataTooLong:
			*eNumP = Err_CacheUserDataTooLong;
			break;*/

		case DLM_Err_InvalidListRef:
			*eNumP = Err_InvalidListRef;
			break;
		//case DLM_Err_ObjNameRequired:
		//	*eNumP = Err_ObjNameRequired;
		//	break;
		case DLM_Err_ListDontAcceptNames:
			*eNumP = Err_ListDontAcceptNames;
			break;
		case DLM_Err_DuplicatedObject:
			*eNumP = Err_DuplicatedObject;
			break;
		case DLM_Err_OutOfBoundary:
			*eNumP = Err_OutOfBoundary;
			break;
		case DLM_Err_BufferToSmall:
			*eNumP = Err_ListBufferTooSmall;
			break;
		case DLM_Err_ObjectNotFound:
			*eNumP = Err_ObjectNotFound;
			break;
		case DLM_Err_CantModifyLength:
			*eNumP = Err_CantModifyLength;
			break;
		case DLM_Err_ObjectIsConstant:
			*eNumP = Err_IllegalOperationOnConstant;
			break;
		case DLM_Err_ObjectIsLocked:
			*eNumP = Err_ObjectIsLocked;
			break;
		case DLM_Err_ListIsLocked:
			*eNumP = Err_ListIsLocked;
			break;			
		case DLM_Err_ObjectIsNotArray:
			*eNumP = Err_ArrayRequired;
			break;
		/*case DLM_Err_BadArrayDimension:
			*eNumP = Err_BadArrayDimension;
			break;*/
		case DLM_Err_ArrayElemWrongType:
			*eNumP = Err_IllegalTypeCast;
			break;
		case DLM_Err_InvalidArrayIndex:
			*eNumP = Err_InvalidArrayIndex;
			break;
		case DLM_Err_InvalidPos:
			*eNumP = Err_InvalidPosition;
			break;
		
		case DLM_Err_InvalidLength:
			*eNumP = Err_InvalidLength;
			break;
		case DLM_Err_NoMoreDataInObject:
			*eNumP = Err_BAPI_EndOfObject;
			break;
		/*case DLM_Err_CantDeleteObject:
			*eNumP = Err_CantDeleteObject;
			break;*/
		case DLM_Err_NoResolveOnDupList:
			*eNumP = Err_NoResolveOnDupList;
			break;
		case DLM_Err_NameTooLong:
			*eNumP = Err_NameTooLong;
			break;
		case DLM_Err_InvalidListType:
			*eNumP = Err_InvalidListType;
			break;
		case DLM_Err_IllegalOperation:
			*eNumP = Err_IllegalOperation;
			break;
		case DLM_Err_CantDisposeRef:
			*eNumP = Err_IllegalDestructor;
			break;
			

		case TextUtils_Err_NotInitialized:
			*eNumP = Err_TextUtilsNotInitialized;
			break;
		
		case ErrJavaHelperJVMLoadFailed:
			*eNumP = Err_JVMLoadFailed;
			break;
		case ErrJavaHelperAttachCurrentThreadException:
			*eNumP = Err_AttachCurrentThreadException;
			break;
		
		//case JavaError:
		//	*eNumP = Err_JavaError;
		//	break;

	/*#ifdef JAVA_ENABLED
		case JNIUtils_JavaError:
			*eNumP = Err_JNIError;
			break;
		case JNIUtils_StringTooLong:
			*eNumP = Err_JNIStringTooLong;
			break;
		case JNIUtils_FieldNotFound:
			*eNumP = Err_JNIFieldNotFoundInClass;
			break;
	#endif*/

		default:
			*eNumP = Err_UnknownXLibHelpersError;
			break;
	}
	
	if (eNameStr)
	{	idx = *eNumP - BIFERNO_BASE_ERROR;
		if ((idx >= 0) && (idx < Err_LastErr))
			CEquStr(eNameStr, gBifernoErrorsRec[idx].name);
		else
			CEquStr(eNameStr, "Unknown Error");
	}
	if (errType)
		CEquStr(errType, "BIFERNO ERROR");
}

//===========================================================================================
static void		_FillBAPIRecord(long eNum, char *descr, Boolean *resumableP)
{
BAPIErrorRecord		*bapiRecP;
int					idx;

	idx = eNum - BIFERNO_BASE_ERROR;
	if ((idx >= 0) && (idx < Err_LastErr))
	{	bapiRecP = &gBifernoErrorsRec[idx];
		if (descr)
			CEquStr(descr, bapiRecP->descr);
		if (resumableP)
			*resumableP = bapiRecP->resumable;
	}
	else
	{	if (descr)
			*descr = 0;
		if (resumableP)
			*resumableP = false;
	}
}

//===========================================================================================
void		FillErrorStrings(long api_data, long lastClassErrCalled, XErr theError, char *errNumStr, char *eNameStr, char *errType, char *subErrStr, char *errLineStr, char *descr, Boolean *resumableP)
{
long		eNum, eType;
BifernoRec	*bRecP;
XErr		err = noErr;
int			idx;
Boolean		saveResumeAlwaysOldLocal;

	XErrorGetTypeValue(theError, &eNum, &eType);
	if NOT(eNum)
	{	if (errNumStr)
			CEquStr(errNumStr, "0");
		if (eNameStr)
			CEquStr(eNameStr, "noError");
		if (errType)
			*errType = 0;
		if (subErrStr)
			*subErrStr = 0;
		if (errLineStr)
			*errLineStr = 0;
		if (descr)
			*descr = 0;
		if (resumableP)
			*resumableP = true;
		return;
	}
	
	bRecP = (BifernoRecP)api_data;
	if (bRecP)
	{	saveResumeAlwaysOldLocal = bRecP->resumeAlwaysCaller;
		bRecP->resumeAlwaysCaller = true;
	}
	if (eNameStr)
		*eNameStr = 0;
	if (descr)
		*descr = 0;
	if (errNumStr)
		*errNumStr = 0;
	if (errType)
		*errType = 0;
	if (subErrStr)
		*subErrStr = 0;
	if (errLineStr)
		*errLineStr = 0;
	switch(eType)
	{
		case kOSError:
	#ifdef __MAC_XLIB__
		case kOSError2:
	#endif
			_OSErrToBAPIErr(theError, &eNum, subErrStr, eNameStr, errType);
			_FillBAPIRecord(eNum, descr, resumableP);
			break;
		case kXLibError:
			_XLibErrToBAPIErr(&eNum, eNameStr, errType);
			_FillBAPIRecord(eNum, descr, resumableP);
			break;
		case kXHelperError:
			_XLibHelpersErrToBAPIErr(&eNum, eNameStr, errType);
			_FillBAPIRecord(eNum, descr, resumableP);
			break;
		case kBAPI_Error:
			idx = eNum - BIFERNO_BASE_ERROR;
			if (eNameStr)
			{	if ((idx >= 0) && (idx < Err_LastErr))
					CEquStr(eNameStr, gBifernoErrorsRec[idx].name);
				else
					CEquStr(eNameStr, "Unknown Error");
			}
			if (errType)
				CEquStr(errType, "");
			_FillBAPIRecord(eNum, descr, resumableP);
			break;
		case kBAPI_ClassError:
			if (lastClassErrCalled)
				err = CL_GetErrMessage(api_data, lastClassErrCalled, theError, eNameStr, descr, errType);
			else if (bRecP)
				err = CL_GetErrMessage(api_data, bRecP->lastClassIDErrorCalled, theError, eNameStr, descr, errType);
			if (resumableP)
				*resumableP = true;
			break;
		default:
			if (errType)
				CEquStr(errType, "BIFERNO ERROR");
			if (eNameStr)
				CEquStr(eNameStr, "Unknown Error");
			//if (eMsg)
			//	*eMsg = 0;
			eNum = Err_UnknownError;
			break;
	}
	if (errNumStr)
		CNumToString(eNum, errNumStr);	
	if (bRecP)
	{	/*if (eMsg)
		{	if (CLen(bRecP->errMessage) && (theError != XError(kBAPI_Error, Err_Debug)))
				CEquStr(eMsg, bRecP->errMessage);
			else
			{	
			Boolean		exists;
			ObjRef		errRef;
			
				if NOT(err = BAPI_IsVariableDefined(api_data, "err", GLOBAL, &exists, &errRef))
				{	if (exists)
					{	if NOT(err = BAPI_GetProperty(api_data, &errRef, "msg", 1, nil, &errRef))
							err = BAPI_ObjToString(api_data, &errRef, eMsg, nil, 255, kExplicitTypeCast);
					}
				}
			}
		}*/
		if (errLineStr)
			CNumToString(bRecP->currentCtx.currentLine + bRecP->currentCtx.bisFunctionInitLine, errLineStr);
	}
	//else if (eMsg)
	//	*eMsg = 0;*/
	if (bRecP)
		bRecP->resumeAlwaysCaller = saveResumeAlwaysOldLocal;
}

//===========================================================================================
void	Err2BAPIErr(long api_data, XErr *theErrorP, char *subErrStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
long		eNum, eType;
XErr		/*err = noErr, */theError = *theErrorP;

	if (theError)
	{	XErrorGetTypeValue(theError, &eNum, &eType);
		if (subErrStr)
			*subErrStr = 0;
		switch(eType)
		{
			case kOSError:
		#ifdef __MAC_XLIB__
			case kOSError2:
		#endif
				_OSErrToBAPIErr(theError, &eNum, subErrStr, nil, nil);
				*theErrorP = XError(kBAPI_Error, eNum);
				break;
			case kXLibError:
				_XLibErrToBAPIErr(&eNum, nil, nil);
				*theErrorP = XError(kBAPI_Error, eNum);
				break;
			case kXHelperError:
				_XLibHelpersErrToBAPIErr(&eNum, nil, nil);
				*theErrorP = XError(kBAPI_Error, eNum);
				break;
			case kBAPI_Error:
				break;
			case kBAPI_ClassError:
				break;
			default:
				eNum = Err_UnknownError;
				break;
		}
	}
	else
		*subErrStr = 0;
}



