/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: BifernoAPI.c,v 1.104 2008-11-27 15:27:48 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "HTTPMgr.h"
#include 	"HTTPMrgNet.h"

#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "BfrVersion.h"
#include "Variable.h"
#include "BifernoErrors.h"
#include "Dispatcher.h"
#include "Flower.h"
#include "Eval.h"
#include "Entity.h"
#include "Load.h"
#include "BfrParser.h"
#include "Classes.h"
#include "Param.h"
#include "BfrSession.h"
#include "Application.h"
#include "Volatile.h"

#include "File.h"
#include "BfrTime.h"
#include "Reference.h"

#include <stdio.h>
#include <string.h>

extern DispatcherData			gsDispatcherData;	// in Dispatcher.c
extern PluginRecord				*gClassRecordBlockP;
extern long						gMaxUsers, gPoolFactor;
extern XErr						(*page_Print)(long api_data, ObjRef *pageOutObjRef, char *stringP, long stringLen);
extern BlockRef					gDefaultsBlock;
extern long						gTotDefaults;
extern BAPIErrorRecord			gBifernoErrorsRec[];
extern XDateTimeRec				gUpSinceXDT;
extern Ref_GetTargetCallBack	ref_GetTarget;
extern Ref_NewReferenceCallBack	ref_NewReference;
extern BAPI_ModifyHook 			gsRefModifyHook;

BAPIErrorRecord	gBifernoErrorsRec[] = 
	{	
		// OS
		// Name										// Descr																	// Resumable, pad1, pad2,
		"Err_OSError",								"Operating System error",1,0,0,

		// Generic
		"Err_FileNotFound",							"The requested file was not found",1,0,0,
		"Err_FolderNotFound",						"The requested path doesn't exist",1,0,0,
		"Err_BadSyntax",							"Invalid syntax",0,0,0,
		//"Err_UselessStatement",						"This statement is redundant",0,0,0,
		
		"Err_UndefinedIdentifier",					"An identifier with this name doesn't exist",1,0,0,
		"Err_InvalidIndex",							"The specified index is invalid",1,0,0,
		"Err_NoSuchClassOrFunction",				"A class or function with this name doesn't exist",1,0,0,
		"Err_StringTooLong",						"The string is too long",1,0,0,
		"Err_InvalidScope",							"The scope is invalid",1,0,0,
		"Err_IllegalScopeForObject",				"The class doesn't allow the requested scope for this object",1,0,0,
		"Err_ScopeConflict",						"Application classes (or functions) can't reference local classes",1,0,0,
		"Err_Timeout",								"The script duration exceeded the timeout period",1,0,0,
		"Err_IllegalFlowControl",					"The flow control is inappropriate here",1,0,0,
		"Err_IllegalConstantExpression",			"Invalid constant expression",1,0,0,
		"UserBreak",								"Programmer stopped execution to debug script",0,0,0,
		"Err_AbsolutePathRequired",					"An absolute (not relative) path is required",1,0,0,
		"Err_InvalidEscapeSequence",				"The character following \'\\\' is invalid",1,0,0,
		
		//"Err_FileNameRequired",						"A name for the file is required",1,0,0,
		//"Err_InvalidParameter",						"The parameter is not initialized",1,0,0,
		
		// Error on requests
		"Err_BadSyntaxInURL",						"Invalid syntax in url",1,0,0,
		"Err_HTTPBodyTooLong",						"The size of POST data is greater then MAX specified in form action",1,0,0,
		"Err_MultipartObjectDuplicated",			"A multipart objects with this name already exists from POST data",1,0,0,
				
		// Expressions parsing
		"Err_CommaOrRoundSquareExpected",			"Character \",\" or \")\" was expected",1,0,0,
		"Err_OperatorExpected",						"An operator (and not an identifier) was expected",1,0,0,
		"Err_EndOfLineOrSemicolonExpected",			"End of line or \";\" was expected",1,0,0,
		"Err_QuotesExpected",						"Quotas (' or \" ) expected",1,0,0,
		"Err_UnknownOperator",						"Biferno doesn't recognize this operator ",1,0,0,
		"Err_TooManyVariablesInExpression",			"An experession can't contain more than 32 items",1,0,0,
		"Err_EmptyExpression",						"The expression can't be empty",1,0,0,
		
		// Expressions
		"Err_IllegalOperation",						"Operation not permitted",1,0,0,
		"Err_IllegalOperationOnConstant",			"Constant variables cannot be modified",1,0,0,
		"Err_IllegalOperationOnMethod",				"Can't operate on a method",1,0,0,
		"Err_IllegalAssignment",					"Assignment of a void object",1,0,0,

		// Arrays
		"Err_BadArrayIndex",						"The index of the array is invalid (<= 0 or inappropriate string)",1,0,0,
		"Err_ArrayRequired",						"Variable must be an array",1,0,0,
		"Err_ArrayElementNotFound",					"An array element with this name doesn't exist",1,0,0,
		"Err_OutOfBoundary",						"The index exceeds the limits of the array",1,0,0,
		"Err_DuplicatedArrayElemName",				"An array element with this name already exists",1,0,0,
		"Err_ArrayElementsTypeCastFailed",			"The typecast of the object to the array elem class failed",1,0,0,
		"Err_IllegalArrayInURL",					"Multidimensional arrays cannot be declared in URL",1,0,0,	// never used
		
		// Published Vars
		"Err_VariableNotPublished",					"The variable with this name was not published",1,0,0,
		"Err_VariableNotDefined",					"A variable with this name was not found",1,0,0,
		"Err_VariableNotInitialized",				"The variable exists but was never initialized",0,0,0,
		
		// Application
		"Err_BifernoConfigNotFound",				"A \"Biferno.config.bfr\" file was not found",1,0,0,
		"Err_ApplicationNameNotFoundInConfig",		"The \"Biferno.config.bfr\" file didn't declare the APPLICATION_NAME variable",1,0,0,
		"Err_ApplicationNameTooLong",				"The name of the application is too long (> 255)",1,0,0,
		"Err_ApplicationNameDuplicated",			"An application with this name already exist",1,0,0,
		"Err_BadSyntaxInApplicationName",			"The \"Biferno.config.bfr\" declaration of \"APPLICATION_NAME\" was not correct",1,0,0,			
		"Err_NoSuchApplication",					"An application with this name doesn't exist",1,0,0,
		
		// Session
		"Err_BadBifernoSID",						"The BifernoSID string contains invalid character (valid chars are: '.', '-', ':' and numbers)",1,0,0,
		"Err_SessionIsDisabled",					"Session variables are disabled (set application SESSION to true)",1,0,0,
		"Err_InvalidSessionCookie",					"The cookie sent from the user agent (BIFERNO_SID) is invalid",1,0,0,
		"Err_CookieDisabled",						"The user agent has cookie disabled",1,0,0,
		
		// Persistent
		"Err_ObjectCantBePersistent",				"The variable belong to a class incompatible with persistent scope",1,0,0,
		
		// Run error (should never happen)
		"Err_PageOutNotDefined",					"Variable global pageOut is not correctly initialized",1,0,0,
		"Err_PageInNotDefined",						"Variable global pageIn is not correctly initialized",1,0,0,
		//"Err_GlobalErrNotDefined",					"Variable global err is not correctly initialized",1,0,0,
		
		// Goto
		"Err_LabelNotFound",						"The requested label to go was not found",1,0,0,
		"Err_DuplicatedLabel",						"A label with this name already exists",1,0,0,

		// Include
		"Err_TooManyIncludes",						"Too many nested includes (max is 12)",0,0,0,
		
		// Functions
		"Err_ReturnValueRequired",					"The function requires a return value",1,0,0,
		"Err_ArrayMismatch",						"Multidimensional array mismatch",1,0,0,
		"Err_FunctionIsVoid",						"Invalid return value in void function",1,0,0,
		"Err_DuplicatedParameter",					"Function's parameters name or position must be unique",1,0,0,
		"Err_InvalidParameter",						"A parameter was not accepted by the method or function",1,0,0,
		"Err_InvalidRefParameter",					"Prototype mismatch: unwanted ref parameter",1,0,0,
		"Err_RefParameterRequired",					"Prototype mismatch: ref parameter required",1,0,0,
		
		//"Err_TooManyParameters",					"Can't pass more than 512 parameters to a function",1,0,0,
		"Err_NoSuchFunction",						"A function with this name doesn't exist",1,0,0,
		"Err_PrototypeMismatch",					"The call doesn't match the function/method prototype",1,0,0,
		"Err_InvalidParameterName",					"A parameter with this name doesn't exist",1,0,0,
		"Err_IllegalConstantParameter",				"A constant cannot be passed as reference",1,0,0,				
			
		// Function prototypes declaration
		"Err_TooLongDefault",						"The default string for a parameter is too long (max is 63 for parameters, 255 for properties)",1,0,0,
		"Err_BadPrototype",							"There was a sintax error in function/method prototype declaration",1,0,0,
		"Err_IllegalRef",							"Illegal reference declaration",1,0,0,
		"Err_FunctionRedeclared",					"The name of the function conflicts with a previously defined function",1,0,0,
	
		// Undef
		"Err_IllegalUndef",							"Can't undef a literal or operation resulting variable",1,0,0,
		
		// Variable names
		//"Err_BadName",							"A generic identifier contains invalid characters or is too long (> 63)",1,0,0,
		"Err_InvalidCharacter",						"A generic entity contains an invalid character",1,0,0,
		"Err_InvalidName",							"A generic entity is not valid",1,0,0,
		"Err_TooLongName",							"A generic entity is too long (> 63)",1,0,0,
		"Err_EmptyName",							"A generic entity is empty (0 chars)",1,0,0,
		"Err_ReservedKeyword",						"Can't use this name for a variable because it is a reserved keyword",1,0,0,
				
		// Class Execution
		"Err_SuperConstructorRequired",				"A call to \"super\" is required inside the constructor",1,0,0,
		"Err_NotAllowedInDestructor",				"This expression is not allowed in Destructor method",1,0,0,
		"Err_NoSuchClass",							"A class with this name doesn't exist",1,0,0,
		"Err_MemberIsStatic",						"Trying to call a static member using an instance",1,0,0,
		"Err_MemberIsNotStatic",					"Trying to call a non static member without an instance",1,0,0,
		"Err_ThisIsUndefined",						"Using the keyword \"this\" is inappropriate here",1,0,0,
		"Err_SuperIsUndefined",						"Using the keyword \"super\" is inappropriate here",1,0,0,
		"Err_NotAnExtendingClass",					"The class doesn't extend another class, so it has no super object",1,0,0,
		"Err_ClassIsStatic",						"The class is completely static and refuses to instance objects",1,0,0,
		"Err_IllegalSetProperty",					"Can't set a property of a initialized instance",1,0,0,

		// Class Declaration
		"Err_InvalidErrorValue",					"The value of an error in a class declaration is invalid (=0)",1,0,0,
		"Err_MethodNameConflict",					"A method with this name already exists in the class",1,0,0,
		"Err_ClassRedeclared",						"The name of the class conflicts with a previously defined class",1,0,0,
		"Err_DuplicatedPropertyName",				"Property names must be univoque",1,0,0,
		"Err_IllegalDeclaration",					"Class and function can't be declared inside a flow control",1,0,0,
		"Err_DuplicatedConstructor",				"Classes can declare only one constructor method",1,0,0,
		
		// Class calling
		"Err_MemberOnUndefinedIdentifier",			"Can't apply a member to an undefined identifier",1,0,0,
		"Err_NoSuchProperty",						"The object has not a property with this name",1,0,0,
		"Err_NoSuchConstant",						"The object has not a constant property with this name",1,0,0,
		"Err_NoSuchMethod",							"The object has not a method with this name",1,0,0,
		"Err_NoSuchMember",							"The object has not a member with this name",1,0,0,
		"Err_CantAccessThisMember",					"The member is private or protected from external access",1,0,0,
		"Err_PropertyIsOnlyRead",					"The property can only be accessed for read, not write, operation",1,0,0,
				
		// TypeCast
		"Err_IllegalTypeCast",						"TypeCast between classes failed",1,0,0,
		"Err_ExplicitTypeCastRequired",				"An explicit typeCast is required",1,0,0,
		
		// OnErrorResume
		"Err_OnErrorNotBalanced",					"Calls to OnErrorSuspend didn't match calls to OnErrorResume",0,0,0,
				
		// Parenthesis
		//"Err_ParenthesisExpected",					"A parenthesis was expected",1,0,0,
		//"Err_CloseParenthesisExpected",				"This parenthesis was never closed",1,0,0,
		//"Err_ParenthesisNotBalanced",				"The close parenthesis was never open",1,0,0,
		"Err_RoundBracketExpected",					"A round bracket was expected",1,0,0,
		"Err_RoundBracketNotBalanced",				"The close round bracket was never open",1,0,0,
		"Err_SquareBracketExpected",				"A square bracket was expected",1,0,0,
		//"Err_SquareBracketsNotBalanced",				"A square bracket was expected",1,0,0,
		"Err_CurlyBracketExpected",					"A curly bracket was expected",1,0,0,
		"Err_CurlyBracketNotBalanced",				"A curly bracket was expected",1,0,0,
		
		// Overflow
		"Err_Overflow",								"The variable can\'t contain this value (see limits for numeric classes)",1,0,0,
		"Err_TooLongHexLiteral",					"The hex string is too long (max is \'0x\' followed by 16 chars)",1,0,0,
		
		// Java
	/*#ifdef JAVA_ENABLED
		"Err_JavaError",							"A generic Java error occurred",1,0,0,
		"Err_JavaClassNotFound",					"The requested Java class was not found",1,0,0,
		"Err_JavaException",						"A Java exception occurred",1,0,0,
		"Err_JavaFrameworkNotAvailable",			"The application couldn't activate the Java support",1,0,0,
		"Err_JavaDisabled",							"The version of Biferno doesn't support Java",1,0,0,
	#endif*/

		// Error returned only to BAPI C classes (never return this to users)
		"Err_BAPI_ExtensionTooOld",					"The extension is too old to run in this Biferno context",0,0,0,
		"Err_BAPI_ExtensionTooNew",					"The extension is too new to run in this Biferno context",0,0,0,
		"Err_BAPI_BifernoTooOld",					"Biferno context is too old to correctly load this extension",0,0,0,
		"Err_BAPI_BifernoTooNew",					"Biferno context is too new to correctly load this extension",0,0,0,
		"Err_BAPI_MessageNotHandled",				"The extension didn't handle the message",0,0,0,
		"Err_BAPI_BufferTooSmall",					"The storage for the request object is too small to contain it",0,0,0,
		"Err_BAPI_ObjNotPrintable",					"The object can't be printable (method tostring not found)",0,0,0,
		"Err_BAPI_InvalidAPIData",					"An invalid api_data was passed to a BAPI call",0,0,0,
		"Err_BAPI_InvalidParameter",				"Invalid parameters were passed to a BAPI call",0,0,0,
		"Err_BAPI_ExtensionNameRequired",			"The name of the extension was not filled",0,0,0,
		"Err_BAPI_ObjNotToDestruct",				"BAPI_AvoidDestructor was called twice on an object",0,0,0,
		"Err_BAPI_ObjAlreadyToDestruct",			"BAPI_ForceDestructor was called twice on an object",0,0,0,
		"Err_BAPI_ErrorsAlreadyRegistered",			"BAPI_RegisterErrors was called twice",0,0,0,
		"Err_BAPI_EndOfObject",						"BAPI_ReadObj reached the end of the object data",0,0,0,
		"Err_BAPI_LoopAbort",						"Error sed to stop the BAPI_ArrayLoop",0,0,0,
		"Err_BAPI_SymbolNotFound",					"BAPI_GetSymbol couldn't find the requested symbol",0,0,0,
		"Err_BAPI_UnknowExtensionType",				"The extension is not a C or Biferno extension (should never happen)",0,0,0,
		//"Err_BAPI_DollarNotFound",					"The internal parser didn' match a final $ (internal error, should never happen)",0,0,0,
		
		// XLib Errors
		"Err_PathTooLong",							"The path is too long (> 255)",0,0,0,
		"Err_LockNotSupported",						"The lock of files is not supported",0,0,0,
		"Err_FolderIsNotEmpty",						"The operation failed because he directory is not empty",0,0,0,
		"Err_EndOfFile",							"The end of file was reached",0,0,0,
		"Err_WalkFolderAbort",						"WalkFolder interrupted by user",0,0,0,
		"Err_DuplicatedFile",						"A file with the same name exists in this location",1,0,0,
		"Err_UnknownUser",							"User unknown",0,0,0,
		"Err_UnknownGroup",							"Group is unknown",0,0,0,
		"Err_BadFileRef",							"The file ref passed to XLib function is invalid",0,0,0,
		"Err_BadMemoryRef",							"The memory ref passed to XLib function is invalid",0,0,0,
		"Err_NullSizeBlock",						"Can't allocate a null size block of memory",0,0,0,
		"Err_BadBlockSize",							"The size of the block is invalid (<= 0)",0,0,0,
		"Err_MemoryFull",							"Not enough memory to perform operation",0,0,0,
		"Err_FreeBlock",							"Attempt to dispose a memory block twice",0,0,0,
		//"Err_DNRFailed",							"TCP/IP Domain Name Resolver Error",1,0,0,
		"Err_ThreadTimeout",						"The threads timed out waiting for a semaphore",0,0,0,
		"Err_ThreadsInternalErr",					"The TLS (Thread Local Storage) manager failed",0,0,0,
		"Err_ThreadNotFound",						"The TLS (Thread Local Storage) couldn't find the thread id",0,0,0,
		"Err_DateTimeFormatError",					"The format string for date/time record is invalid",0,0,0,
		"Err_CantLoadShObject",						"The DLL can't be loaded",0,0,0,
		"Err_CantFindShLibSymbol",					"The DLL symbol can't be found",0,0,0,
		"Err_CantCloseShLib",						"Close of DLL failed",0,0,0,
		"Err_ConvertingStringToLong",				"Conversion from string to long long failed",0,0,0,
		"Err_NotImplemented",						"The function is not implemented",0,0,0,
		"Err_ConnectionBroken",						"The connection was reset by the server",0,0,0,
		"Err_XLibTooOld",							"The XLib version is too old to run in this context",0,0,0,
		"Err_XLibTooNew",							"The XLib version is too new to run in this context",0,0,0,
		"Err_XLibCallerTooOld",						"The context is too old to correctly load this XLib version",0,0,0,
		"Err_XLibCallerTooNew",						"The context is too new to correctly load this XLib version",0,0,0,
		"Err_ProcessShutDown",						"The operation failed because Biferno is reloading or shutting down",0,0,0,
	
		// XLib Helpers Errors
		"Err_BuffersNotInitialized",				"The Buffer manager is not initialized",0,0,0,
		"Err_BuffersBadID",							"The buffer id is invalid",0,0,0,
		"Err_CacheNotInitialized",					"The Cache manager is not initialized",0,0,0,
		"Err_CachePathTooLong",						"The path passed to the cache is too long (> 255)",0,0,0,
		//"Err_CacheUserDataTooLong",					"The user data for cache is too long",0,0,0,
		"Err_InvalidListRef",						"The DLM list ref is invalid",0,0,0,
		"Err_ListDontAcceptNames",					"The list doesn't accept object names",0,0,0,
		"Err_DuplicatedObject",						"A DLM object with this name already exists",0,0,0,
		"Err_ListOutOfBoundary",					"The id of the object is out of list boundary",0,0,0,
		"Err_ListBufferTooSmall",					"The storage passed to DLM is too small to contain the requested object",0,0,0,
		"Err_ObjectNotFound",						"An object with this name was not found",0,0,0,
		"Err_CantModifyLength",						"Attempt to change a size of a fixed size object failed",0,0,0,
		//"Err_ObjectIsConstant",						"Attempt to change a constant object failed",0,0,0,
		"Err_ObjectIsLocked",						"Attempt to change a locked object failed",0,0,0,
		"Err_ListIsLocked",							"Attempt to change an object in a locked list",0,0,0,
		//"Err_BadArrayDimension",					"The dimension of the array is invalid (< 0)",0,0,0,
		"Err_InvalidArrayIndex",					"The index of the array is invalid",0,0,0,
		"Err_InvalidPosition",						"The position of the new object is invalid",0,0,0,
		"Err_InvalidLength",						"The length of the object to add is invalid",0,0,0,
		"Err_NoResolveOnDupList",					"DLM_ResolveArrayElem can't be called on a list with duplicated names",0,0,0,
		"Err_NameTooLong",							"the name of the object is too long (> 255)",0,0,0,
		"Err_InvalidListType",						"The list type is invalid (possible values are: ID_LIST, NAME_LIST, NAMECS_LIST)",0,0,0,
		"Err_TextUtilsNotInitialized",				"The XLib Text Manager manager is not initialized",0,0,0,
	/*#ifdef JAVA_ENABLED
		"Err_JNIError",								"XLib JNI generic error",0,0,0,
		"Err_JNIStringTooLong",						"The Java string to convert is too long",0,0,0,
		"Err_JNIFieldNotFoundInClass",				"the requested Java class was not found",0,0,0,
	#endif*/
	
		"Err_UnknownError",							"Unknown error",0,0,0,
		"Err_UnknownXLibError",						"Unknown XLib error",0,0,0,
		"Err_UnknownXLibHelpersError",				"Unknown XLib Helpers error",0,0,0,
					
		// Java errors
		"Err_JVMLoadFailed",						"Loading of the Java Virtual Machine failed",0,0,0,
		"Err_AttachCurrentThreadException",			"Loading of the Java Virtual Machine failed for this run",0,0,0,
		"Err_JavaNotAvailable",						"The Java Virtual Machine is not available",0,0,0,
		
		"Err_ParameterNameTooLong",					"A name of a parameter is too long (can't be > 63 chars)",1,0,0,
		
		"Err_MemorySlotsFull",						"Not enough memory slots to perform operation",0,0,0,
		"Err_SlotMgrUnavailable",					"Biferno slot manager uninitialized (should never happen)",0,0,0,
		
		"Err_ClassError",							"An error occurred while executing a class member",1,0,0,
		
		"Err_VariableDuplicatedInURL",				"Illegal multiple declaration in URL",1,0,0,
		"Err_StackOverflow",						"The script used too much stack space",0,0,0,
		"Err_InvalidVariableType",					"The type of the variable is neither 'const' nor 'var'",0,0,0,
		
		"Err_IllegalDestructor",					"Variables of this scope can be undef or reinitialized only in Biferno config",0,0,0,

		"Err_LastErr"								"The last err (never used)",1,0,0
	};

// Tot types of lists
#define 	NUM_LIST		6
static long		scope[NUM_LIST] = {LOCAL, GLOBAL, APPLICATION, SESSION, PERSISTENT, TEMP};


//===========================================================================================
long GetScope(int i)
{
	return scope[i];
}

//===========================================================================================
long GetTotScopes(void)
{
	return NUM_LIST;
}

//#define	_1Block	32
//===========================================================================================
static void _Bubble(BAPI_Name *membP, long tot)
{
register int 	i, j;
BAPI_Name		temp;

	j = tot;
	if (--j <= 0)
	{	
		return;
	}
	do
	{	for (i=0; i<j; i++)
		{	if (CCompareStrings_cs(membP[i].name, membP[i+1].name) == -1)
			{	temp = membP[i+1];
				membP[i+1] = membP[i];
				membP[i] = temp;
			}
		}
	} while(--j);
}

//===========================================================================================
/*static Boolean	_IsClassMember(char *memberStr, long *plugIDP, long *objIDP, long *maxP)
{
PluginRecord	*plugRecP;
int				i, totClass;
long			totFound, max, objID;
Boolean			res = false;

	if (maxP)
		max = *maxP;
	else
		max = 0;
	plugRecP = gClassRecordBlockP;
	totClass = gsDispatcherData.totClass;
	totFound = 0;
	for (i = 0; i < totClass; i++, plugRecP++)
	{	if (objID = DLM_GetObjID(plugRecP->membersList, memberStr, nil, nil))
		{	if NOT(res)
				res = true;
			totFound++;
			if (max && (i < max))
			{	if (plugIDP)
					*plugIDP++ = i+1;
				if (objIDP)
					*objIDP++ = objID;
				//if (typeP)
				//	*typeP++ = VARIABLE;
			}
			else
				break;
		}
	}
if NOT(res)
	*plugIDP = *objIDP = 0;
*maxP = totFound;
return res;
}
*/
//===========================================================================================
static Boolean _Unacceptable(char *name)
{
	return NOT(CCompareStrings_cs(name, "type"));
/*
	if ((which == 0) || (which == FUNC))
		return (DLM_GetObjID(gsDispatcherData.reservedKeyword, name, nil, nil) != 0);
	else
		return NOT(CCompareStrings_cs(name, "type"));
*/
}

//===========================================================================================
static XErr	_AddMembers(DLMRef list, BlockRef *blockRefP, long *totItemsP, long which, long index)
{
XErr			err = noErr;
int				j_index, j, totItems;
long			totSize, tLen, objID, totObjs;
CStr63			name;
BAPI_Name		*nameRecP;
BAPI_Doc		doc;

	*blockRefP = 0;
	totItems = 0;
	if (list)
	{	if (NOT(err = DLM_GetTotObjs(list, &totObjs, false)) && totObjs)
		{	if (index)
			{	if ((index > 0) && (index <= totObjs))
					totSize = sizeof(BAPI_Name);
				else
					err = XError(kBAPI_Error, Err_OutOfBoundary);
			}
			else
				totSize = totObjs * sizeof(BAPI_Name);
			if NOT(err)
			{	if (*blockRefP = NewBlockLocked(totSize, &err, (Ptr*)&nameRecP))
				{	j_index = 1;
					for (j = 1; (j <= totObjs) && NOT(err); j++)
					{	if NOT(err = DLM_GetIndObj(list, j, nil, 0, nil, nil, &objID, name, false, false))
						{	tLen = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
							if NOT(err = DLM_GetObj(list, objID, (Ptr)&doc, &tLen, 0, nil))
							{	if (which != doc.type)
									continue;
								if ((which == kMethod) || (which == kFunction))
								{	if (doc.info.method.visibility != kPublic)
										continue;
								}
								else
								{	if (doc.info.property.visibility != kPublic)
										continue;
									if (which == kError)			// want only errors
									{	if NOT(doc.type == kError)
											continue;	
									}
									else if (which == kConstant)	// want only constants
									{	if (NOT(doc.info.property.isConst) || (doc.type == kError))
											continue;	
									}
									else if (doc.info.property.isConst || (doc.type == kError))			// want only non constant
										continue;	
								}
								if (index)
								{	if (j_index++ == index)
									{	CEquStr(nameRecP->name, name);
										break;
									}
								}
								else
								{	CEquStr(nameRecP->name, name);
									totItems++;
									nameRecP++;
								}
							}
						}
					}
					if (index)
						totItems = 1;
				}
			}
		}
	}

if (err)
{	if (*blockRefP)
		DisposeBlock(blockRefP);
}
else
	*totItemsP = totItems;
return err;
}

//===========================================================================================
/*static XErr	_AddCMembers(PluginRecord *plugRecP, DLMRef list, BlockRef	blockRef, long *actSizeP, long *totItemsP, long which, long index)
{
XErr			err = noErr;
int				j, totItems;
long			tLen, objID, totObjs;
CStr63			name;
BAPI_Name		*membP;
BAPI_Doc		doc;

	actSize = *actSizeP;
	*blockRefP = 0;
	if (list)
	{	if NOT(err = DLM_GetTotObjs(list, &totObjs, false))
		{	for (j = 1; (j <= totObjs) && NOT(err); j++)
			{	if NOT(err = DLM_GetIndObj(list, j, nil, 0, nil, nil, &objID, name, false, false))
				{	tLen = sizeof(BAPI_Doc);
					if NOT(err = DLM_GetObj(list, objID, (Ptr)&doc, &tLen, 0, nil))
					{	if (doc.type == which)
						{	if (which == kError)			// want only errors
							{	if NOT(doc.type == kError)
									continue;	
							}
							else if (which == kConstant)	// want only constants
							{	if (NOT(doc.info.property.isConst) || (doc.type == kError))
									continue;	
							}
							else if (doc.info.property.isConst || (doc.type == kError))			// want only non constant
								continue;	
							if (totItems >= actSize)
							{	actSize += _1Block;
								err = SetBlockSize(blockRef, sizeof(BAPI_Name) * actSize);
								membP = (BAPI_Name*)GetPtr(blockRef);
							}
							if NOT(err)
							{	if (plugRecP)
								{	CEquStr(membP[totItems].name, plugRecP->pluginName);
									CAddStr(membP[totItems].name, ".");
								}
								else
									*membP[totItems].name = 0;
								CAddStr(membP[totItems].name, name);
								totItems++;
							}
						}
					}
				}
			}
		}
	}
	*actSizeP = actSize;
	*totItemsP = totItems;
	
if (err)
{	if (*blockRefP)
		DisposeBlock(blockRefP);
}
else
	*totItemsP = totItems;
return err;
}*/

//===========================================================================================
static XErr	_GetPropertyName(char *name, char *propName, long *arrayLevelP)
{
Ptr			tempP = name;
long		len = CLen(name);
XErr		err = noErr;
Byte		arrayLevel;

	SkipSpaceAndTab(&tempP, &len);
	GetEntityName(0L, &tempP, &len, propName, true);
	SkipSpaceAndTab(&tempP, &len);
	arrayLevel = 0;
	while (len >= 2)
	{	if (*(short*)tempP == ONE_ARRY_LEVEL)
		{	len -= 2;
			tempP += 2;
			arrayLevel++;
			if (arrayLevel > MAX_PROTO_ARRAY_LEVEL)
			{	err = XError(kBAPI_Error, Err_BadPrototype);
				break;
			}
			//if (arrayLevel > 200)
			//	return XError(kBAPI_Error, Err_NoSuchClass);
		}
		else
			break;
	}
	if (arrayLevelP)
		*arrayLevelP = arrayLevel;
		
return err;
}

//===========================================================================================
static XErr	_NewMember(long api_data, long handlerID, BAPI_MemberRecord *nvRecP, long tots, char *owner, long which)
{
XErr					err = noErr;
PluginRecord			*plugRecP;
long					oldValue, objID, ownerID;
BAPI_MemberRecord		*cur_nvRecP;
int						i;
CStr63					tStr, cName;
CStr255					cLogStr, handlerName;
DLMRef					list;
BifernoRecP				bRecP = (BifernoRecP)api_data;
LogCallBack 			logCallBack;
void 					*userData;
BlockRef				memberDocBlock;
BAPI_Doc				*memberDocP;
Ptr						tempP;
long					tempLen;

	logCallBack = HTTPControllerLog;
	if (bRecP)
		userData = bRecP->userData;
	else
		userData = 0;
	
	if (owner && *owner)
	{	objID = DLM_GetObjID(gsDispatcherData.classListRef, owner, nil, &ownerID);
		if NOT(objID)
			return XError(kBAPI_Error, Err_NoSuchClass);
	}
	else
		ownerID = handlerID;
	
	cur_nvRecP = nvRecP;
	plugRecP = &gClassRecordBlockP[ownerID-1];
	for (i = 0; (i < tots) && NOT(err); i++, cur_nvRecP++)
	{	if (memberDocBlock = NewBlockLocked(sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc), &err, (Ptr*)&memberDocP))
		{	ClearBlock(memberDocP, sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc));
			if (CLen(cur_nvRecP->name) < 63)
			{	if ((which == kProperty) || (which == kConstant))
					err = _GetPropertyName(cur_nvRecP->name, cName, &memberDocP->returnAeLevel);
				else
					CEquStr(cName, cur_nvRecP->name);
			}
			else 
				err = XError(kBAPI_Error, Err_TooLongName);
			if NOT(err)
			{	// Is a reserved keyword?
				if (_Unacceptable(cName))
				{	logCallBack(userData, cName);
					err = XError(kBAPI_Error, Err_ReservedKeyword);
				}
				else if NOT(err = IsEntityNameValid(cName))
				{	/*ex: (boh?) if ((which == kConstant) && (plugRecP->pluginType != kNewClassPlugin))
						err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					else
					{	*/
					if (which == kFunction)
						list = gsDispatcherData.functionsList;
					else
						list = plugRecP->membersList;
					memberDocP->type = which;
					memberDocP->implem = kCImplementation;
					memberDocP->ident.c.val = cur_nvRecP->value;
					memberDocP->ident.c.pluginID = handlerID;
					CEquStr(memberDocP->name, cName);
					tempP = cur_nvRecP->prototype;
					tempLen = CLen(tempP);
					if NOT(err = PrototypeToBAPI_Doc(0, &tempP, &tempLen, memberDocBlock, nil, false, which))
					{	memberDocP = (BAPI_Doc*)GetPtr(memberDocBlock);		// reload it
						memberDocP->info.method.classID = ownerID;
						memberDocP->len = sizeof(BAPI_Doc) + (sizeof(BAPI_ParameterDoc) * (memberDocP->totParams - 1));
						CEquStr(memberDocP->prototype, cur_nvRecP->prototype);
						if ((which == kProperty) || (which == kConstant))
						{	CAddStr(memberDocP->prototype, " ");
							CAddStr(memberDocP->prototype, cName);
							FillMemberPrototype(api_data, memberDocP, nil);
						}
						if (objID = DLM_GetObjID(list, cName, nil, nil))
						{	
						BAPI_Doc	oldMembRec;
						long		tLen;
							
							// se gi� esisteva mi salvo il vecchio valore
							tLen = sizeof(BAPI_Doc);
							err = DLM_GetObj(list, objID, (Ptr)&oldMembRec, &tLen, 0, nil);
							if (err == XError(kXHelperError, DLM_Err_ObjectNotFound))
								err = noErr;
							oldValue = oldMembRec.ident.c.val;
							if NOT(err = DLM_ModifyObj(list, objID, (Ptr)memberDocP, memberDocP->len, handlerID, nil, 0, nil))
							{	if NOT(err = BAPI_NameFromClassID(api_data, handlerID, handlerName))
								{	CEquStr(cLogStr, "Member ");
									CAddStr(cLogStr, handlerName);
									CAddStr(cLogStr, ".");
									CAddStr(cLogStr, cur_nvRecP->name);
									CAddStr(cLogStr, " (value = ");
									CNumToString(cur_nvRecP->value, tStr);
									CAddStr(cLogStr, tStr);
									CAddStr(cLogStr, ") overrides ");
									if (owner)
										CAddStr(cLogStr, owner);
									else
										CAddStr(cLogStr, handlerName);
									CAddStr(cLogStr, ".");
									CAddStr(cLogStr, cur_nvRecP->name);
									CAddStr(cLogStr, " (old value = ");
									CNumToString(oldValue, tStr);
									CAddStr(cLogStr, tStr);
									CAddStr(cLogStr, ")");
									logCallBack(userData, cLogStr);
								}
							}
						}
						else
							DLM_NewObj(list, cName, (Ptr)memberDocP, memberDocP->len, handlerID, kFixedSize, &err);
					}
				}
			}
			DisposeBlock(&memberDocBlock);
		}
	}

	if (err && logCallBack)
	{	CStr255	errStr;
		
		CEquStr(errStr, "\tError Registering Member: \"");
		CAddStr(errStr, cName);
		CAddStr(errStr, "\"");
		logCallBack(userData, errStr);
	}
	
return err;
}

typedef struct {
				ObjRefP		arrayObjRefP;
				//long		index;
				long		arrClassID;
				} _ArrayConcatRec;

//===========================================================================================
static XErr	_ArrayConcatCallBack(long api_data, char *elemName, ObjRefP element, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(elemName)
#endif
_ArrayConcatRec		*arrConcatRecP;
XErr				err = noErr;
//long				arrayClassID;

	arrConcatRecP = (_ArrayConcatRec*)param;
	err = BAPI_ArrayAddElement(api_data, arrConcatRecP->arrayObjRefP, elemName, element);
	if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
	{	//BAPI_GetArrayInfo(api_data, arrConcatRecP->arrayObjRefP, nil, &arrayClassID, nil);
		NewMsgRecord(api_data, kTYPECAST, (char*)arrConcatRecP->arrayObjRefP, OBJ_CLASSID(element), kInputIsObj);
	}

return err;
}

typedef struct {
				long						api_data;
				BAPI_ArraySortCallBack		callBack;
				long						callBackParam;
				long						mode;
				long						index;
				} ArraySortRec;

//===========================================================================================
static Boolean	_arraySortCallBackFast_string(Ptr value1, long len1, Ptr value2, long len2, long param)
{
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;

	if (arraySortRecP->mode == kArraySortAsc)
		return CCompareStringsExt(value1, len1, value2, len2) < 0;
	else
		return CCompareStringsExt(value1, len1, value2, len2) > 0;
}

//===========================================================================================
static Boolean	_arraySortCallBackFast_char(Ptr value1, long len1, Ptr value2, long len2, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(len1, len2)
#endif
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;

	if (arraySortRecP->mode == kArraySortAsc)
		return CharToLower(*value1) > CharToLower(*value2);
	else
		return CharToLower(*value1) < CharToLower(*value2);
}

//===========================================================================================
static Boolean	_arraySortCallBackFast_bool(Ptr value1, long len1, Ptr value2, long len2, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(len1, len2)
#endif
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;

	if (arraySortRecP->mode == kArraySortAsc)
		return *(Boolean*)value1 > *(Boolean*)value2;
	else
		return *(Boolean*)value1 < *(Boolean*)value2;
}

//===========================================================================================
static Boolean	_arraySortCallBackFast_double(Ptr value1, long len1, Ptr value2, long len2, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(len1, len2)
#endif
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;

	if (arraySortRecP->mode == kArraySortAsc)
		return *(double*)value1 > *(double*)value2;
	else
		return *(double*)value1 < *(double*)value2;
}

//===========================================================================================
static Boolean	_arraySortCallBackFast_long(Ptr value1, long len1, Ptr value2, long len2, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(len1, len2)
#endif
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;

	if (arraySortRecP->mode == kArraySortAsc)
		return *(LONGLONG*)value1 > *(LONGLONG*)value2;
	else
		return *(LONGLONG*)value1 < *(LONGLONG*)value2;
}

//===========================================================================================
static Boolean	_arraySortCallBackFast_int(Ptr value1, long len1, Ptr value2, long len2, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(len1, len2)
#endif
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;

	if (arraySortRecP->mode == kArraySortAsc)
		return *(long*)value1 > *(long*)value2;
	else
		return *(long*)value1 < *(long*)value2;
}

//===========================================================================================
static Boolean	_arraySortCallBackFast_unsigned(Ptr value1, long len1, Ptr value2, long len2, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(len1, len2)
#endif
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;

	if (arraySortRecP->mode == kArraySortAsc)
		return *(unsigned long*)value1 > *(unsigned long*)value2;
	else
		return *(unsigned long*)value1 < *(unsigned long*)value2;
}

//===========================================================================================
static Boolean	_ArraySortCallBack(DLMRef dlRef, long objID1, long userData1, long objID2, long userData2, long param, XErr *errP)
{
ArraySortRec	*arraySortRecP = (ArraySortRec*)param;
Boolean			res = false;
ObjRef			obj1, obj2, result;
XErr			err = noErr;
long			api_data = arraySortRecP->api_data;

	OBJ_LIST(obj1) = OBJ_LIST(obj2) = dlRef;
	OBJ_ID(obj1) = objID1;
	OBJ_CLASSID(obj1) = userData1;
	OBJ_TYPE(obj1) = OBJ_SCOPE(obj1) = 0;
	OBJ_ID(obj2) = objID2;
	OBJ_CLASSID(obj2) = userData2;
	OBJ_TYPE(obj2) = OBJ_SCOPE(obj2) = 0;
	if (arraySortRecP->callBack)
		res = arraySortRecP->callBack(api_data, &obj1, &obj2, arraySortRecP->callBackParam, &err);
	else
	{	if NOT(err = BAPI_ExecuteOperation(api_data, &obj1, &obj2, EVAL_GTH, &result))
		{	if NOT(err = BAPI_ObjToBoolean(api_data, &result, &res, kImplicitTypeCast))
			{	if (arraySortRecP->mode == kArraySortDesc)
					res = NOT(res);
			}
		}
	}
	if NOT(err)
	{	if (arraySortRecP->index >= 500)
		{	err = ResetVolatileList((BifernoRecP)api_data);
			arraySortRecP->index = 0;
		}
		else
			arraySortRecP->index++;
	}
	*errP = err;

return res;
}

//===========================================================================================
static XErr	_ReadObj(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP, Boolean noEOO)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
long		tLen, maxStorage = *lenP, objLen;
Boolean		isImmediate = IS_IMMEDIATE_P(objRef);

	if (isImmediate)
	{	switch(OBJ_CLASSID_P(objRef))
		{
			case kBooleanClassID:
				objLen = sizeof(Boolean);
				if (bufferP && (maxStorage >= objLen))
					*(Boolean*)bufferP = *(Boolean*)IMM_P(objRef);
				break;
			case kStringClassID:
				objLen = tLen = IMMLEN_STRLEN_P(objRef);
				if (bufferP)
				{	if (maxStorage < tLen)
						tLen = maxStorage;
					CopyBlock(bufferP, IMM_P(objRef) + 1, tLen);
				}
				break;
			case kDoubleClassID:
				objLen = sizeof(double);
				if (bufferP && (maxStorage >= objLen))
					*(double*)bufferP = *(double*)IMM_P(objRef);
				break;
			case kLongClassID:
				objLen = sizeof(LONGLONG);
				if (bufferP && (maxStorage >= objLen))
					*(LONGLONG*)bufferP = *(LONGLONG*)IMM_P(objRef);
				break;
			case kUnsignedClassID:
				objLen = sizeof(unsigned long);
				if (bufferP && (maxStorage >= objLen))
					*(unsigned long*)bufferP = *(unsigned long*)IMM_P(objRef);
				break;
			case kIntClassID:
				objLen = sizeof(long);
				if (bufferP && (maxStorage >= objLen))
					*(long*)bufferP = *(long*)IMM_P(objRef);
				break;
			case kCharClassID:
				CDebugStr("impossible char literal");
				break;
		}
		if (maxStorage > objLen)
			err = XError(kXHelperError, DLM_Err_NoMoreDataInObject);
	}
	else
	{	if NOT(OBJ_ID_P(objRef))
		{	if (noEOO && bufferP && maxStorage)
			{	CEquStr(bufferP, "");
				if (lenP)
					*lenP = 0;
				if (classIDP)
					*classIDP = 0;
				return noErr;
			}
			else
				return XError(kBAPI_Error, Err_BAPI_InvalidParameter);
		}
		if (lenP)
			objLen = *lenP;
		err = DLM_GetObj(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), bufferP, &objLen, offset, classIDP);
	}
	if (lenP)
		*lenP = objLen;
	if (err == XError(kXHelperError, DLM_Err_NoMoreDataInObject))
	{	if (noEOO)
		{	long	objLen = *lenP;
		
			if (bufferP)
				ClearBlock(bufferP + objLen, maxStorage - objLen);
			err = noErr;
		}
		else
		{	if NOT(objLen)
				err = XError(kBAPI_Error, Err_VariableNotInitialized);
			else
				err = XError(kBAPI_Error, Err_BAPI_EndOfObject);
		}
	}
	
return err;													
}

/*

//===========================================================================================
static XErr 	_GetNextTag(Ptr *textPPtr, long *lenP, long *tagP, Ptr *fromPPtr, long *contentLengthP)
{
XErr		err = noErr;
long		compLen, tLen, len, tagID = 0;
Ptr			saveP, textP;
CStr63		compareStr, tagStr;
Boolean		found;

	textP = *textPPtr;
	len = *lenP;
	SkipUntilChar(&textP, &len, '<', nil);
	*fromPPtr = nil;
	*contentLengthP = 0;
	if (len)
	{	textP++;
		len--;
		saveP = textP;
		SkipUntilChar(&textP, &len, '>', nil);
		tLen = textP - saveP;
		if (tLen > 63)
			tLen = 63;
		CopyBlock(tagStr, saveP, tLen);
		tagStr[tLen] = 0;
		if NOT(CCompareStrings_cs(tagStr, DESCR_TAG))
			tagID = kDESCR;
		else if NOT(CCompareStrings_cs(tagStr, PARAM_TITLE_TAG))
			tagID = kPARAM_TITLE;
		else if NOT(CCompareStrings_cs(tagStr, PARAM_DESCR_TAG))
			tagID = kPARAM_DESCR;
		else if NOT(CCompareStrings_cs(tagStr, RETURNS_TAG))
			tagID = kRETURNS;
		else if NOT(CCompareStrings_cs(tagStr, NOTE_TAG))
			tagID = kNOTE;
		else if NOT(CCompareStrings_cs(tagStr, SEE_ALSO_TAG))
			tagID = kSEE_ALSO;
		else if NOT(CCompareStrings_cs(tagStr, ERRORS_TAG))
			tagID = kERRORS;
		if (len)
		{	textP++;
			len--;
			*fromPPtr = textP;
			CEquStr(compareStr, "</");
			CAddStr(compareStr, tagStr);
			CAddStr(compareStr, ">");
			compLen = CLen(compareStr);
			while ((len >= compLen) && NOT(found = NOT(CompareBlock(textP, compareStr, compLen))))
			{	textP++;
				len--;
			}
			if (found)
			{	*contentLengthP = textP - *fromPPtr;
				textP += compLen;
				len -= compLen;
			}
			else
				err = XError(kBAPI_Error, Err_BadSyntax);
		}
	}
	if (tagP)
		*tagP = tagID;

	*textPPtr = textP;
	*lenP = len;

return err;
}

//===========================================================================================
static XErr	_DocToArray(long api_data, Ptr textP, long len, ObjRef *arrayObjRefP)
{
XErr		err = noErr;
long		tagID, length, param_title_index, param_descr_index;
Ptr			fromP;
ObjRef		tObjRef;
char		*strP;
CStr63		name;

	param_title_index = 1;
	param_descr_index = 1;
	if NOT(err = BAPI_ArrayToObj(api_data, false, 0, nil, 0, nil, nil, arrayObjRefP))
	{	while (len && NOT(err))
		{	if NOT(err = _GetNextTag(&textP, &len, &tagID, &fromP, &length))
			{	switch(tagID)
				{
					case kDESCR:
						strP = DESCR_TAG;
						break;
					case kPARAM_TITLE:
						sprintf(name, "%s_%d", PARAM_TITLE_TAG, param_title_index++);
						strP = name;
						break;
					case kPARAM_DESCR:
						sprintf(name, "%s_%d", PARAM_DESCR_TAG, param_descr_index++);
						strP = name;
						break;
					case kRETURNS:
						strP = RETURNS_TAG;
						break;
					case kSEE_ALSO:
						strP = SEE_ALSO_TAG;
						break;
					case kNOTE:
						strP = NOTE_TAG;
						break;
					case kERRORS:
						strP = ERRORS_TAG;
						break;
					default:
						strP = nil;
						break;
				}
				if (strP)
				{	INVAL(tObjRef);
					if NOT(err = BAPI_StringToObj(api_data, fromP, length, &tObjRef))
						err = BAPI_ArrayAddElement(api_data, arrayObjRefP, strP, &tObjRef);
				}
			}
		}
		if NOT(err)
		{	INVAL(tObjRef);
			if NOT(err = BAPI_IntToObj(api_data, param_title_index - 1, &tObjRef))
				err = BAPI_ArrayAddElement(api_data, arrayObjRefP, "TOT_PARAMS", &tObjRef);
		}
	}
	
return err;
}
*/
//===========================================================================================
static XErr	_CreateArray(long api_data, Boolean fixedSize, char *newObjName, long objScope, long objType, ParameterRec *varRecsP, long totVars, long *errElemIDXP, Boolean createNew, ObjRecordP resultObjP)
{
XErr				err = noErr;
long				flags;
CloneArrayRecord	csRec;
int					i;
long				theArrayClassID = gsDispatcherData.arrayConstructor;
BifernoRecP			bRecP;
CStr255				aStr;
char				*strP;
long				listID;
ObjRecord			tempArrayObjRef;
BfrDestructRec		destructRec;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	flags = 0;
	if (fixedSize)
		flags |= kFixedSize;
	if (createNew)
	{	if (err = GetVariableList(api_data, objScope, &listID, false, 0))
			return err;
		if (listID == -1)
			return -1;
		if (objScope == TEMP)
			strP = nil;
		else
		{	if (newObjName)
			{	CEquStr(aStr, newObjName);
				strP = aStr;
			}
			else
				strP = nil;
		}
		if (objType == CONSTANT)
			flags |= kCostant;
	}
	else
	{	objType = VARIABLE;
		objScope = TEMP;
		listID = bRecP->volatileList;
		strP = nil;
	}
	tempArrayObjRef.id = DLM_NewArray(listID, strP, theArrayClassID, (unsigned short)flags, /*totVars, */0L,  &csRec.arrayDLRef, &err);
	if NOT(err)
	{	
	long	newElemsClassID;
	
		tempArrayObjRef.list = listID;
		tempArrayObjRef.classID = theArrayClassID;
		tempArrayObjRef.scope = objScope;
		tempArrayObjRef.type = objType;
		if (totVars)
		{	//csRec.requestedElementClassID = OBJ_CLASSID(varRecsP->objRef);
			newElemsClassID = OBJ_CLASSID(varRecsP->objRef);
			if (newElemsClassID == gsDispatcherData.arrayConstructor)	// multi dimens
			{
			ArraySpecs	arSpec;
			
				if NOT(err = GetArraySpecs(api_data, OBJRECORD_P(&varRecsP->objRef), &arSpec))
				{	csRec.reqElement_Ae_Level = arSpec.arrayElemAeLevel + 1;
					csRec.reqElementClassID = gsDispatcherData.arrayConstructor;
					csRec.reqElement_Ae_ClassID = arSpec.arrayElemClassID;
				}
			}			
			else
			{	csRec.reqElement_Ae_Level = 0;
				csRec.reqElementClassID = newElemsClassID;
				csRec.reqElement_Ae_ClassID = 0;
			}
			if NOT(err)
			{	csRec.isArrayConstant = (objType == CONSTANT);
				csRec.arrObjRef = tempArrayObjRef;
				if NOT(csRec.reqElementClassID)
					csRec.isArrayFixed = false;
				else
					err = BAPI_FixedSize(api_data, csRec.reqElementClassID, &csRec.isArrayFixed);
				if NOT(err)
				{	csRec.arrayDim = 0;
					for (i = 0; (i < totVars) && NOT(err); i++, varRecsP++)
						err = AddElementToArray(api_data, varRecsP->name, &varRecsP->objRef, (long)&csRec);
				}
			}
		}
		if NOT(err)
		{	if (createNew)
				*resultObjP = tempArrayObjRef;
			else
			{	if (resultObjP->classID == theArrayClassID)
					err = ModifyObjCheckDestructors(api_data, resultObjP->list, resultObjP->id, resultObjP->classID, resultObjP->scope, tempArrayObjRef.list, tempArrayObjRef.id, tempArrayObjRef.classID);
				else
					err = CL_TypeCast(api_data, &tempArrayObjRef, resultObjP->classID, resultObjP, kExplicitTypeCast);
			}
		}
		if (err)
		{	if (errElemIDXP)
				*errElemIDXP = i;
			if ((err == XError(kBAPI_Error, Err_ArrayElementsTypeCastFailed)) && (i < totVars))
				NewMsgRecord(api_data, kTYPECAST, (char*)varRecsP, csRec.reqElementClassID, kInputIsObj);
			if (createNew)
			{	destructRec.api_data = api_data;
				destructRec.scope = tempArrayObjRef.scope;
				UndefVariable(api_data, OBJREF_P(&tempArrayObjRef), false);
				//ex DLM_DeleteObj(tempArrayObjRef.list, tempArrayObjRef.id, VariableDestructorExt, (long)&destructRec);
				INVAL_P(resultObjP);
			}
		}
	}
	
return err;
}

//===========================================================================================
/*static XErr	_CopyResult(long api_data, ObjRefP tempObjRefP, ObjRefP resultObjP)
{	
XErr	err = noErr;

	if (VALID_P(resultObjP))
	{	if (OBJ_CLASSID_P(resultObjP) == OBJ_CLASSID_P(tempObjRefP))
			err = ModifyObjCheckDestructors(api_data, OBJ_LIST_P(resultObjP), OBJ_ID_P(resultObjP), OBJ_CLASSID_P(resultObjP), OBJ_SCOPE_P(resultObjP), OBJ_LIST_P(tempObjRefP), OBJ_ID_P(tempObjRefP), OBJ_CLASSID_P(tempObjRefP));
		else
			err = CL_TypeCast(api_data, OBJRECORD_P(tempObjRefP), OBJ_CLASSID_P(resultObjP), OBJRECORD_P(resultObjP), kExplicitTypeCast);
	}
	else
		*resultObjP = *tempObjRefP;

return err;
}*/

//===========================================================================================
/*static XErr	ex_CreateArray(long api_data, Boolean fixedSize, unsigned long arrayDim, char *newObjName, long objScope, long objType, ParameterRec *varRecsP, long totVars, long *errElemIDXP, Boolean createNew, ObjRecordP resultObjP)
{
XErr				err = noErr;
long				flags;
CloneArrayRecord	csRec;
int					i;
long				theArrayClassID = gsDispatcherData.arrayConstructor;
ObjRecord			saveResultObj;
BifernoRecP			bRecP;
Boolean				setOffNoDestr = false, doTypeCast = false;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	flags = 0;
	if (fixedSize)
		flags |= kFixedSize;
	INVAL(saveResultObj);
	if (createNew)
	{	
	CStr255		aStr;
	char		*strP;
	long		listID;
	
		if (err = GetVariableList(api_data, objScope, &listID))
			return err;
		if (listID == -1)
			return -1;
		if (objScope == TEMP)
			strP = nil;
		else
		{	if (newObjName)
			{	CEquStr(aStr, newObjName);
				strP = aStr;
			}
			else
				strP = nil;
		}
		if (objType == CONSTANT)
			flags |= kCostant;
		resultObjP->id = DLM_NewArray(listID, strP, theArrayClassID, flags, arrayDim, 0,  &csRec.arrayDLRef, &err);
		if NOT(err)
		{	resultObjP->list = listID;
			resultObjP->classID = theArrayClassID;
			resultObjP->scope = objScope;
			resultObjP->type = objType;
		}
	}
	else
	{	if IS_IMMEDIATE_P(resultObjP)
			CDebugStr("� un immediate, vedere cosa fare");
		
		if NOT(err = BeforeModify(api_data, resultObjP->list, resultObjP->id))
		{	setOffNoDestr = true;
			if (resultObjP->classID == theArrayClassID)
				err = DLM_NewArrayInObject(resultObjP->list, resultObjP->id, theArrayClassID, flags, arrayDim, 0,  &csRec.arrayDLRef, VariableDestructorExt, api_data);
			else
			{	saveResultObj = *resultObjP;
				resultObjP->id = DLM_NewArray(bRecP->volatileList, nil, theArrayClassID, flags, arrayDim, 0,  &csRec.arrayDLRef, &err);
				if NOT(err)
				{	resultObjP->list = bRecP->volatileList;
					resultObjP->scope = TEMP;
					resultObjP->type = VARIABLE;
					resultObjP->classID = theArrayClassID;
					doTypeCast = true;
				}
			}
		}
	}
	if NOT(err)
	{	if (totVars)
		{	csRec.requestedClassID = OBJ_CLASSID(varRecsP->objRef);
			csRec.isArrayConstant = (objType == CONSTANT);
			csRec.arrObjRef = *resultObjP;
			if NOT(csRec.requestedClassID)
				csRec.isArrayFixed = false;
			else
				err = BAPI_FixedSize(api_data, csRec.requestedClassID, &csRec.isArrayFixed);
			if NOT(err)
			{	for (i = 0; (i < totVars) && NOT(err); i++, varRecsP++)
					err = AddElementToArray(api_data, varRecsP->name, &varRecsP->objRef, (long)&csRec);
			}
			if (err)
			{	if (errElemIDXP)
					*errElemIDXP = i;
				if ((err == XError(kBAPI_Error, Err_ArrayElementsTypeCastFailed)) && (i < totVars))
					NewMsgRecord(api_data, kTYPECAST, (char*)OBJ_CLASSID(varRecsP->objRef), csRec.requestedClassID, kUseForTypeCast);
			}
		}
		if (err)
		{	if (createNew)
			{	DLM_DeleteObj(resultObjP->list, resultObjP->id, VariableDestructorExt, api_data);
				INVAL_P(resultObjP);
			}
		}
		else if (doTypeCast)
			err = CL_TypeCast(api_data, resultObjP, saveResultObj.classID, resultObjP, kImplicitTypeCast);
		if (err)
		{	if (saveResultObj.id)
				*resultObjP = saveResultObj;
		}
		else if (setOffNoDestr)	// BeforeModify set no destr
			err = DLM_TurnOffFlag(resultObjP->list, resultObjP->id, kNoDestructor, kDLMMain);
	}
	if (err == XError(kXHelperError, DLM_Err_DuplicatedObject))
		err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
	
return err;
}
*/
//===========================================================================================
/*XErr	BAPI_Register(long callsBackPtr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(callsBackPtr)

	// This is implemented only in BifernoAPI_DLL.c
	return noErr;
}
*/
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_ResetError(long api_data)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	//printf("------------------- BAPI_ResetError\n");
	if NOT(bRecP = (BifernoRecP)api_data)
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
	{	//bRecP->errVarTableBlockValid = false;
		//err = ResetMsgRecords(api_data);
		if NOT(bRecP->suspendMsgs)
			bRecP->errMessageRec.totMsg = 0;
		//bRecP->errMessageRec.varNameSet = false;
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_Eval(long api_data, char *strToEval, long strToEvalLen, ObjRefP resultObjRefP, Boolean onlyOneStatement, Boolean resume)
{
XErr		err = noErr;
long		id, len;
BlockRef	bl;
BifernoRec	*bRecP;
Boolean		saveResumeAlwaysCaller, saveInEval;
CallerCtx	saveCurrentCtx;
CStr255		errNote;

	if (resultObjRefP)
		CHECK_RES(resultObjRefP)
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	saveCurrentCtx = bRecP->currentCtx;
	bRecP->currentCtx.currentLine = 0;
	bRecP->currentCtx.tot_graf_pars = 0;
	bRecP->currentCtx.inTag = true;
	bRecP->currentCtx._stop = false;
	saveInEval = bRecP->inEval;
	bRecP->inEval = true;
	saveResumeAlwaysCaller = bRecP->resumeAlwaysCaller;
	bRecP->resumeAlwaysCaller = resume;
	if (onlyOneStatement)
		err = Eval(api_data, 0, 0, &strToEval, &strToEvalLen, kOnlyOneStatement + kNoFlowControl, OBJRECORD_P(resultObjRefP));
	else
	{	if (id = BufferCreate(0, &err))
		{	long	saveReplyID;
		
			saveReplyID = bRecP->alternativeBuffer;
			bRecP->alternativeBuffer = id;
			ProcessMain(api_data, strToEval, strToEvalLen, true, &err);
			bRecP->alternativeBuffer = saveReplyID;
			if NOT(err)
			{	bl = BufferGetBlockRef(id, &len);
				LockBlock(bl);
				if (resultObjRefP)
					err = BAPI_StringToObj(api_data, GetPtr(bl), len, resultObjRefP);
			}
			BufferFree(id);
		}	
	}
	bRecP->resumeAlwaysCaller = saveResumeAlwaysCaller;
	if (err && NOT(resume))
	{	BAPI_ResetError(api_data);
		sprintf(errNote, "while evaluating at line %d of file %s", saveCurrentCtx.bisFunctionInitLine + saveCurrentCtx.currentLine, saveCurrentCtx.currentExecFile);
		NewMsgRecord(api_data, kNote, errNote, 0, 0);
	}		
	else
	{	bRecP->currentCtx = saveCurrentCtx;
		bRecP->inEval = saveInEval;
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*XErr	BAPI_InvalObjRef(long api_data, ObjRefP varP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
	
	OBJ_LIST_P(varP) = 0;				// the list it belongs to
	OBJ_ID_P(varP) = 0;					// the id in the list
	OBJ_CLASSID_P(varP) = 0;			// the type (class) of obj
	OBJ_SCOPE_P(varP) = 0;	
	OBJ_TYPE_P(varP) = 0;	
	
return noErr;
}
*/

//===========================================================================================
XErr BAPI_SetPageOut(long api_data, ObjRefP pageObjRef)
{
BifernoRecP		bRecP;

	if (api_data)
	{
		bRecP = (BifernoRecP)api_data;
		bRecP->pageOutObjRef = *(ObjRecord*)pageObjRef;
	}

return noErr;
}

//===========================================================================================
XErr	BAPI_LocateObj(long api_data, ObjRefP objRef, char *theScope, long *stackIndex)
{
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
long			objList = OBJ_LIST_P(objRef);
StackRecord		*stackP;
int				i, curSP;

	if (stackIndex)
		*stackIndex = 0;
	if (theScope)
		*theScope = 0;
	// look for list
	if (bRecP)
	{	if (objList == (long)bRecP->volatileList)
			CEquStr(theScope, "volatile");
		else if (objList == (long)bRecP->globalList)
			CEquStr(theScope, "global");
		else if (objList == (long)bRecP->application.list)
			CEquStr(theScope, "application");
		else if (objList == (long)bRecP->sessionList)
			CEquStr(theScope, "session");
		else if (objList == (long)bRecP->application.persistentList)
			CEquStr(theScope, "persistent");
		else
		{	curSP = bRecP->stackPointer;
			BufferGetBlockRefExt(bRecP->stackBufferID, (Ptr*)&stackP);
			for (i = 1; i <= curSP; i++, stackP++)
			{	if (stackP->localList == objList)
				{	if (stackIndex)
						*stackIndex = i;
					CEquStr(theScope, "local");
					break;
				}
			}
		}
	}	
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_GetObjInfo(long api_data, ObjRefP objRef, long *classIDP, char *name)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;

	if (IS_IMMEDIATE_P(objRef))
	{	if (classIDP)
			*classIDP = OBJ_CLASSID_P(objRef);
		if (name)
			*name = 0;
	}
	else
		err = DLM_GetInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), nil, classIDP, name);

return err;
}	

//===========================================================================================
Boolean	BAPI_IsObjRefValid(long api_data, ObjRefP objRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	return VALID_P(objRef);
}	

//===========================================================================================
XErr	BAPI_InvalObjRef(long api_data, ObjRefP objRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;

	INVAL_P(objRef);

return err;
}	

//===========================================================================================
XErr	BAPI_IsObjRefToDestruct(long api_data, ObjRefP objRef, Boolean *isToDestructP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err = noErr;
unsigned short		flags;

	if NOT(err = DLM_GetInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), &flags, nil, nil))
		*isToDestructP = ((flags & kNoDestructor) == 0);
		
return err;
}	

//===========================================================================================
long	BAPI_GetObjClassID(long api_data, ObjRefP objRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	return OBJ_CLASSID_P(objRef);
}	

//===========================================================================================
long	BAPI_GetObjClassIDExt(long api_data, ObjRefP objRef, long *classIDP)
{
ObjRecord	result;
XErr		err = noErr;

	if (OBJ_CLASSID_P(objRef) == gsDispatcherData.refConstructor)
	{	if NOT(err = ref_GetTarget(api_data, objRef, (ObjRefP)&result, true))
			*classIDP = result.classID;
	}
	else
		*classIDP = OBJ_CLASSID_P(objRef);
		
return err;
}	

//===========================================================================================
void	BAPI_SetObjClassID(long api_data, ObjRefP objRef, long newClassID)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	OBJ_CLASSID_P(objRef) = newClassID;
}

//===========================================================================================
void	BAPI_SetObjScope(long api_data, ObjRefP objRef, long newScope)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	OBJ_SCOPE_P(objRef) = newScope;
}

//===========================================================================================
void	BAPI_SetObjType(long api_data, ObjRefP objRef, long newType)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	OBJ_TYPE_P(objRef) = newType;
}

//===========================================================================================
long	BAPI_GetObjScope(long api_data, ObjRefP objRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	if (IS_IMMEDIATE_P(objRef))
		return TEMP;
	else
		return OBJ_SCOPE_P(objRef);
}	

//===========================================================================================
XErr	BAPI_NeedSerialize(long api_data, ObjRefP objRef, Boolean *needP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
long		sc;

#ifdef MEM_DEBUG
	if NOT(OBJ_ID_P(objRef))
		return XError(kBAPI_Error, Err_IllegalOperation);
#endif

	if (IS_IMMEDIATE_P(objRef))
		sc = TEMP;
	else
		sc = OBJ_SCOPE_P(objRef);
	if ((sc < TEMP) || (sc > PERSISTENT))
		err = XError(kBAPI_Error, Err_IllegalOperation);
	else if (needP)
		*needP = (sc > GLOBAL);
	
return err;
}

//===========================================================================================
long	BAPI_GetObjType(long api_data, ObjRefP objRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	if (IS_IMMEDIATE_P(objRef))
		return CONSTANT;
	else
		return OBJ_TYPE_P(objRef);
}	

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_NewProperties(long api_data, long handlerID, BAPI_MemberRecord *nvRecP, long tots, char *owner)
{
	return _NewMember(api_data, handlerID, nvRecP, tots, owner, kProperty);
}
//===========================================================================================
XErr	BAPI_NewMethods(long api_data, long handlerID, BAPI_MemberRecord *nvRecP, long tots, char *owner)
{
	return _NewMember(api_data, handlerID, nvRecP, tots, owner, kMethod);
}
//===========================================================================================
XErr	BAPI_NewConstants(long api_data, long handlerID, BAPI_MemberRecord *nvRecP, long tots, char *owner)
{
	return _NewMember(api_data, handlerID, nvRecP, tots, owner, kConstant);
}
//===========================================================================================
XErr	BAPI_RegisterErrors(long api_data, long handlerID, long baseError, CStr63 *nameRecP, long tots)
{
XErr					err = noErr;
PluginRecord			*plugRecP;
long					oldValue, objID, ownerID;
CStr63					*cur_nameRecP;
int						i;
CStr63					tStr, cName;
CStr255					cLogStr, handlerName;
DLMRef					list;
BifernoRecP				bRecP = (BifernoRecP)api_data;
//MemberRecord			membRec;
LogCallBack 			logCallBack;
void 					*userData;
BlockRef				memberDocBlock;
BAPI_Doc				*memberDocP;
long					tLen;

	logCallBack = HTTPControllerLog;
	if (bRecP)
		userData = bRecP->userData;
	else
		userData = 0;
	
	ownerID = handlerID;
	
	cur_nameRecP = nameRecP;
	plugRecP = &gClassRecordBlockP[ownerID-1];
	if (plugRecP->errorRegistered)
		return Err_BAPI_ErrorsAlreadyRegistered;
	
	plugRecP->baseError = baseError;
	list = plugRecP->membersList;
	if (err = DLM_GetTotObjs(list, &plugRecP->objBaseError, false))
		return err;
	for (i = 0; (i < tots) && NOT(err); i++, cur_nameRecP++)
	{	if (memberDocBlock = NewBlockLocked(sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc), &err, (Ptr*)&memberDocP))
		{	ClearBlock(memberDocP, sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc));
			if (CLen(*cur_nameRecP) < 63)
				err = _GetPropertyName(*cur_nameRecP, cName, &memberDocP->returnAeLevel);
			else 
				err = XError(kBAPI_Error, Err_TooLongName);
			if (err)
				return err;
			// Is a reserved keyword?
			if (_Unacceptable(cName))
			{	logCallBack(userData, cName);
				return XError(kBAPI_Error, Err_ReservedKeyword);
			}
			if NOT(err = IsEntityNameValid(cName))
			{	memberDocP->type = kError;
				memberDocP->ident.c.val = baseError++;
				memberDocP->isStatic = true;
				memberDocP->returnClassID = kIntClassID;
				memberDocP->returnAeLevel = 0;
				memberDocP->implem = kCImplementation;
				memberDocP->info.property.classID = ownerID;
				CEquStr(memberDocP->prototype, "static const error");
				CEquStr(memberDocP->name, cName);
				memberDocP->info.property.isConst = true;
				//memberDocP->isError = true;
				tLen = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
				if (objID = DLM_GetObjID(list, cName, nil, nil))
				{	
				BAPI_Doc	oldMembRec;
					
					// se gi� esisteva mi salvo il vecchio valore
					err = DLM_GetObj(list, objID, (Ptr)&oldMembRec, &tLen, 0, nil);
					if (err == XError(kXHelperError, DLM_Err_ObjectNotFound))
						err = noErr;
					oldValue = oldMembRec.ident.c.val;
					if NOT(err = DLM_ModifyObj(list, objID, (Ptr)memberDocP, tLen, handlerID, nil, 0, nil))
					{	if NOT(err = BAPI_NameFromClassID(api_data, handlerID, handlerName))
						{	CEquStr(cLogStr, "Member ");
							CAddStr(cLogStr, handlerName);
							CAddStr(cLogStr, ".");
							CAddStr(cLogStr, *cur_nameRecP);
							CAddStr(cLogStr, " (value = ");
							CNumToString(baseError-1, tStr);
							CAddStr(cLogStr, tStr);
							CAddStr(cLogStr, ") overrides ");
							CAddStr(cLogStr, handlerName);
							CAddStr(cLogStr, ".");
							CAddStr(cLogStr, *cur_nameRecP);
							CAddStr(cLogStr, " (old value = ");
							CNumToString(oldValue, tStr);
							CAddStr(cLogStr, tStr);
							CAddStr(cLogStr, ")");
							logCallBack(userData, cLogStr);
						}
					}
				}
				else
					DLM_NewObj(list, cName, (Ptr)memberDocP, tLen, handlerID, kFixedSize, &err);
			}
			DisposeBlock(&memberDocBlock);
		}
	}

	if (err && logCallBack)
	{	CStr255	errStr;
		
		CEquStr(errStr, "\tError Registering Member: \"");
		CAddStr(errStr, cName);
		CAddStr(errStr, "\"");
		logCallBack(userData, errStr);
	}
	else
	{	plugRecP->errorRegistered = true;
		plugRecP->totErrors = (short)tots;
	}
	
return err;
}
//===========================================================================================
XErr	BAPI_NewFunctions(long api_data, long handlerID, BAPI_MemberRecord *nvRecP, long tots)
{
	return _NewMember(api_data, handlerID, nvRecP, tots, nil, kFunction);
}

//===========================================================================================
XErr	BAPI_NewApplicationDefault(long api_data, char *name, char *value, char *comment)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err = noErr;
ApplVarDefaultRec	*applDefaultsP;
	
	if NOT(err = SetBlockSize(gDefaultsBlock, sizeof(ApplVarDefaultRec) * (gTotDefaults + 1)))
	{	LockBlock(gDefaultsBlock);
		applDefaultsP = (ApplVarDefaultRec*)GetPtr(gDefaultsBlock);
		CEquStr(applDefaultsP[gTotDefaults].name, name);
		CEquStr(applDefaultsP[gTotDefaults].value, value);
		CEquStr(applDefaultsP[gTotDefaults].comment, comment);
		gTotDefaults++;
		UnlockBlock(gDefaultsBlock);
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// Moves memory
/*XErr	BAPI_NewObj(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize,
													char *newObjName, long objScope, long objType, ObjRefP newObj)
{
XErr		err = noErr;
CStr255		aStr;
char		*strP;
long		newID, flags, listID;

	if NOT(api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (err = GetVariableList(api_data, objScope, &listID))
		return err;

	if (listID == -1)
		return -1;
	if (objScope == TEMP)
	{	if (newObjName && *newObjName)
			return XError(kBAPI_Error, Err_ListDontAcceptNames);
		else
			strP = nil;
	}
	else
	{	if (newObjName)
		{	CEquStr(aStr, newObjName);
			strP = aStr;
		}
		else
			strP = nil;
	}

	flags = 0;
	if (fixedSize)
		flags |= kFixedSize;
	if (objType == CONSTANT)
		flags |= kCostant;
	newID = DLM_NewObj(listID, strP, dataP, dataLen, classID, flags, &err);
	if (NOT(err) && newObj)
	{	OBJ_ID_P(newObj) = newID;
		OBJ_LIST_P(newObj) = listID;
		OBJ_CLASSID_P(newObj) = classID;
		OBJ_TYPE_P(newObj) = objType;
		OBJ_SCOPE_P(newObj) = objScope;
	}
	
return err;
}
*/
//===========================================================================================
long	BAPI_ConstructorScope(long api_data, long constructorPrivateData)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	if (constructorPrivateData)
		return ((ConstructorAPIdataRec*)constructorPrivateData)->scope;
	else
		return 0;
}

//===========================================================================================
XErr	BAPI_ScopeID(long api_data, char *scopeName, long *scopeP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;
long	objID, aLong;

	objID = DLM_GetObjID(gsDispatcherData.reservedKeyword, scopeName, nil, &aLong);
	if (objID && ((aLong == TEMP) || (aLong == LOCAL) || (aLong == GLOBAL) || /*(aLong == STATIC) ||*/ (aLong == APPLICATION) || (aLong == SESSION) || (aLong == PERSISTENT)))
		*scopeP = aLong;
	else
	{	*scopeP = 0;
		err = XError(kBAPI_Error, Err_InvalidScope);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_SetSuperObj(long api_data, ObjRefP obj, ObjRefP superObj, ObjRefP newSuperObjP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused (api_data)
#endif
XErr	err = noErr;
long	newID;
unsigned short	flags;
DLMRef	newList;

	if NOT(err = DLM_NewSuperObj(OBJ_LIST_P(obj), OBJ_ID_P(obj), OBJ_LIST_P(superObj), OBJ_ID_P(superObj), &newList, &newID))
	{	if (newSuperObjP)
		{	OBJ_ID_P(newSuperObjP) = newID;
			OBJ_LIST_P(newSuperObjP) = newList;
			if NOT(err = DLM_GetInfo(newList, newID, &flags, &OBJ_CLASSID_P(newSuperObjP), nil))
			{	if (flags & kCostant)
					OBJ_TYPE_P(newSuperObjP) = CONSTANT;
				else
					OBJ_TYPE_P(newSuperObjP) = VARIABLE;
				OBJ_SCOPE_P(newSuperObjP) = OBJ_SCOPE_P(obj);
			}
		}
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetSuperObj(long api_data, ObjRef *objRef, ObjRef *superObjRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;
long	objLen, superID;
unsigned short	flags;
DLMRef	superList;

	if (superID = DLM_GetSuperObjID(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), &superList))
	{	OBJ_ID_P(superObjRef) = superID;
		OBJ_LIST_P(superObjRef) = superList;
		if NOT(err = DLM_GetInfo(OBJ_LIST_P(superObjRef), OBJ_ID_P(superObjRef), &flags, &OBJ_CLASSID_P(superObjRef), nil))
		{	if (flags & kCostant)
				OBJ_TYPE_P(superObjRef) = CONSTANT;
			else
				OBJ_TYPE_P(superObjRef) = VARIABLE;
			OBJ_SCOPE_P(superObjRef) = OBJ_SCOPE_P(objRef);
		}
	}
	else
	{	if NOT(err = DLM_GetObj(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), nil, &objLen, 0, nil))
		{	if (objLen)
				err = XError(kBAPI_Error, Err_ObjectNotFound);
			else
				err = XError(kBAPI_Error, Err_VariableNotInitialized);
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr 	BAPI_IntToObj(long api_data, long value, ObjRefP objRefP)
{
	return CL_IntToObj(api_data, value, OBJRECORD_P(objRefP));
}

//===========================================================================================
XErr 	BAPI_LongToObj(long api_data, LONGLONG value, ObjRefP objRefP)
{
	return CL_LongToObj(api_data, value, OBJRECORD_P(objRefP));
}

//===========================================================================================
XErr 	BAPI_UnsignedToObj(long api_data, unsigned long value, ObjRefP objRefP)
{
	return CL_UnsignedToObj(api_data, value, OBJRECORD_P(objRefP));
}

//===========================================================================================
XErr 	BAPI_DoubleToObj(long api_data, double doubleVal, ObjRefP objRefP)
{
	return CL_DoubleToObj(api_data, doubleVal, OBJRECORD_P(objRefP));
}

//===========================================================================================
XErr 	BAPI_BooleanToObj(long api_data, Boolean isTrue, ObjRefP objRefP)
{
	return CL_BooleanToObj(api_data, isTrue, OBJRECORD_P(objRefP));
}

//===========================================================================================
XErr	BAPI_StringToObj(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP)
{
	return CL_StringToObj(api_data, dataP, dataLen, VARIABLE, OBJRECORD_P(objRefP));
}

//===========================================================================================
/*XErr	BAPI_StringToConstObj(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP)
{
	return CL_StringToObj(api_data, dataP, dataLen, CONSTANT, OBJRECORD_P(objRefP));
}*/

//===========================================================================================
XErr	BAPI_CharToObj(long api_data, char theChar, ObjRefP objRefP)
{
	return CL_CharToObj(api_data, theChar, OBJRECORD_P(objRefP));
}

//===========================================================================================
XErr	BAPI_ArrayToObj(long api_data, Boolean fixedSize, ParameterRec *varRecsP, long totVars, long *errElemIDXP, long constructorPrivateData, ObjRefP objRefP)
{
XErr		err = noErr;

	if VALID_P(objRefP)
		err = _CreateArray(api_data, fixedSize, nil, 0, 0, varRecsP, totVars, errElemIDXP, false, OBJRECORD_P(objRefP));
	else
	{	
	char	*strP;
	long	objScope, objType;
	
		if (constructorPrivateData)
		{	
		ConstructorAPIdataRec	*constrDataP = (ConstructorAPIdataRec*)constructorPrivateData;
		
			objScope = constrDataP->scope;
			objType = constrDataP->type;
			if (objScope == TEMP)
			{	if (*constrDataP->resultObjName)
					return XError(kBAPI_Error, Err_ListDontAcceptNames);
				else
					strP = nil;
			}
			else
			{	if (*constrDataP->resultObjName)
					strP = constrDataP->resultObjName;
				else
					strP = nil;
			}
		}
		else
		{	objScope = TEMP;
			objType = VARIABLE;
			strP = nil;
		}
		if NOT(err)
			err = _CreateArray(api_data, fixedSize, strP, objScope, objType, varRecsP, totVars, errElemIDXP, true, OBJRECORD_P(objRefP));
	}
	if (err && (err == XError(kXHelperError, DLM_Err_DuplicatedObject)))
		err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
	
return err;
}

//===========================================================================================
XErr	BAPI_BufferToObj(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, long constructorPrivateData, ObjRefP objRefP)
{
XErr			err = noErr;
char			*strP;
long			newID, flags, listID, objScope, objType;
BifernoRecP		bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (objRefP && VALID_P(objRefP))
	{	if IS_IMMEDIATE_P(objRefP)
			return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
		else
		{	// if, added 11/2/2005, i the obj is a ref the target must be modified (see CL_IntToObj as an example)
			if (((ObjRecord*)objRefP)->classID == gsDispatcherData.refConstructor)
			{
			ObjRecord	tObjRef;
			
				INVAL(tObjRef);
				if NOT(err = BAPI_BufferToObj(api_data, dataP, dataLen, classID, fixedSize, 0, (ObjRef*)&tObjRef))
					err = gsRefModifyHook(api_data, (ObjRefP)objRefP, (ObjRefP)&tObjRef);
			}
			else
				err = ModifyObjBufferCheckDestructors(api_data, OBJ_LIST_P(objRefP), OBJ_ID_P(objRefP), OBJ_CLASSID_P(objRefP), OBJ_SCOPE_P(objRefP), dataP, dataLen, classID);
		}
	}
	else
	{	if (constructorPrivateData)
		{	
		ConstructorAPIdataRec	*constrDataP = (ConstructorAPIdataRec*)constructorPrivateData;
		
			objScope = constrDataP->scope;
			objType = constrDataP->type;
			if (err = GetVariableList(api_data, objScope, &listID, false, 0))
				return err;
			if (listID == -1)
				return -1;
			if (objScope == TEMP)
			{	if (*constrDataP->resultObjName)
					return XError(kBAPI_Error, Err_ListDontAcceptNames);
				else
					strP = nil;
			}
			else
			{	if (*constrDataP->resultObjName)
					strP = constrDataP->resultObjName;
				else
					strP = nil;
			}
		}
		else
		{	objScope = TEMP;
			objType = VARIABLE;
			strP = nil;
			listID = bRecP->volatileList;
		}
		flags = 0;
		if (fixedSize)
			flags |= kFixedSize;
		if (objType == CONSTANT)
			flags |= kCostant;
		newID = DLM_NewObj(listID, strP, dataP, dataLen, classID, (unsigned short)flags, &err);
		if (NOT(err) && objRefP)
		{	OBJ_ID_P(objRefP) = newID;
			OBJ_LIST_P(objRefP) = listID;
			OBJ_CLASSID_P(objRefP) = classID;
			OBJ_TYPE_P(objRefP) = objType;
			OBJ_SCOPE_P(objRefP) = objScope;
		}
	}
	
return err;
}
		
//===========================================================================================
// Il super va solo copiato
XErr	BAPI_BufferToObjWithSuper(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, ObjRefP superObj, long constructorPrivateData, ObjRefP objRefP)
{
XErr			err = noErr;
//CStr255			aStr;
char			*strP;
long			objScope, objType, newID, flags, listID;
BifernoRecP		bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	//if (err = GetVariableList(api_data, objScope, &listID))
	//	return err;
	if (objRefP && VALID_P(objRefP))
	{	if IS_IMMEDIATE_P(objRefP)
			return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
		else
		{	if (IS_IMMEDIATE_P(superObj))
			{	if NOT(err = NewLiteralInList(nil, ((BifernoRecP)api_data)->volatileList, OBJRECORD_P(superObj), 0, &OBJ_ID_P(superObj), 0))
					OBJ_LIST_P(superObj) = ((BifernoRecP)api_data)->volatileList;
			}
			if NOT(err)
			{	
			ObjRef	actualSuperObjRef;
			
				if (classID != OBJ_CLASSID_P(objRefP))
				{	NewMsgRecord(api_data, kTYPECAST, (char*)objRefP, classID, kInputIsObj);
					// ex NewMsgRecord(api_data, kTYPECAST, (char*)classID, OBJ_CLASSID_P(objRefP), kUseForTypeCast);
					err = XError(kBAPI_Error, Err_IllegalTypeCast); 
				}
				else
				{	if NOT(err = BAPI_GetSuperObj(api_data, objRefP, &actualSuperObjRef))
					{	if NOT(err = ModifyObjBufferCheckDestructors(api_data, OBJ_LIST_P(objRefP), OBJ_ID_P(objRefP), OBJ_CLASSID_P(objRefP), OBJ_SCOPE_P(objRefP), dataP, dataLen, classID))
							err = ModifyObjCheckDestructors(api_data, OBJ_LIST(actualSuperObjRef), OBJ_ID(actualSuperObjRef), OBJ_CLASSID(actualSuperObjRef), OBJ_SCOPE(actualSuperObjRef), OBJ_LIST_P(superObj), OBJ_ID_P(superObj), OBJ_CLASSID_P(superObj));
					}
				}
			}
		}
	}
	else
	{	if (constructorPrivateData)
		{	
		ConstructorAPIdataRec	*constrDataP = (ConstructorAPIdataRec*)constructorPrivateData;
		
			objScope = constrDataP->scope;
			objType = constrDataP->type;
			if (err = GetVariableList(api_data, objScope, &listID, false, 0))
				return err;
			if (listID == -1)
				return -1;
			if (objScope == TEMP)
			{	if (*constrDataP->resultObjName)
					return XError(kBAPI_Error, Err_ListDontAcceptNames);
				else
					strP = nil;
			}
			else
			{	if (*constrDataP->resultObjName)
					strP = constrDataP->resultObjName;
				else
					strP = nil;
			}
		}
		else
		{	objScope = TEMP;
			objType = VARIABLE;
			strP = nil;
			listID = bRecP->volatileList;
		}
		flags = 0;
		if (fixedSize)
			flags |= kFixedSize;
		if (objType == CONSTANT)
			flags |= kCostant;
		if (IS_IMMEDIATE_P(superObj))
		{	if NOT(err = NewLiteralInList(nil, ((BifernoRecP)api_data)->volatileList, OBJRECORD_P(superObj), 0, &OBJ_ID_P(superObj), 0))
				OBJ_LIST_P(superObj) = ((BifernoRecP)api_data)->volatileList;
		}
		if NOT(err)
		{	newID = DLM_NewObjWithSuper(listID, strP, dataP, dataLen, classID, (unsigned short)flags, OBJ_LIST_P(superObj), OBJ_ID_P(superObj), &err);
			if NOT(err)
			{	if NOT(err = DLM_TurnOnFlag(OBJ_LIST_P(superObj), OBJ_ID_P(superObj), kNoDestructor, kDLMElements))
				{	if (objRefP)
					{	OBJ_ID_P(objRefP) = newID;
						OBJ_LIST_P(objRefP) = listID;
						OBJ_CLASSID_P(objRefP) = classID;
						OBJ_TYPE_P(objRefP) = objType;
						OBJ_SCOPE_P(objRefP) = objScope;
					}
				}
			}
		}
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*XErr 	BAPI_ReturnInt(long api_data, long value, ObjRefP resultObjRefP)
{
	return BAPI_IntToObj(api_data, value, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnLong(long api_data, LONGLONG value, ObjRefP resultObjRefP)
{
	return BAPI_LongToObj(api_data, value, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnUnsigned(long api_data, unsigned long value, ObjRefP resultObjRefP)
{
	return BAPI_UnsignedToObj(api_data, value, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnDouble(long api_data, double doubleVal, ObjRefP resultObjRefP)
{
	return BAPI_DoubleToObj(api_data, doubleVal, resultObjRefP);
}
//===========================================================================================
XErr 	BAPI_ReturnBoolean(long api_data, Boolean isTrue, ObjRefP resultObjRefP)
{
	return BAPI_BooleanToObj(api_data, isTrue, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnString(long api_data, Ptr dataP, long dataLen, ObjRefP resultObjRefP)
{
	return BAPI_StringToConstObj(api_data, dataP, dataLen, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnChar(long api_data, char theChar, ObjRefP resultObjRefP)
{
	return BAPI_CharToObj(api_data, theChar, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnArray(long api_data, Boolean fixedSize, long arrayDim, ParameterRec *elementsP, long totElements, ObjRefP resultObjRefP)
{
	return BAPI_NewArray(api_data, fixedSize, arrayDim, nil, TEMP, VARIABLE, elementsP, totElements, nil, resultObjRefP);
}
//===========================================================================================
XErr	BAPI_ReturnObject(long api_data, ObjRefP theObjectP, ObjRefP resultObjRefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)

	*resultObjRefP = *theObjectP;
	
return noErr;
}

#if __MWERKS__
#pragma mark-
#endif
*/
//===========================================================================================
XErr	BAPI_ModifyObj(long api_data, ObjRefP objref, void* dataP, long dataLen)
{
XErr				err = noErr;
BfrDestructRec		destructRec;

	if IS_IMMEDIATE_P(objref)
		err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
	else
	{	destructRec.api_data = api_data;
		destructRec.scope = OBJ_SCOPE_P(objref);
		err = DLM_ModifyObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), dataP, dataLen, DLM_USERDATA_DEFAULT, VariableDestructorExt, (long)&destructRec, nil);
		if (err)
		{	if (err == XError(kXHelperError, DLM_Err_ObjectIsConstant))
				err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
		}
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_WriteObj(long api_data, ObjRefP objref, void* dataP, long dataLen, long atOffset)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;

	if IS_IMMEDIATE_P(objref)
		err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
	else
	{	err = DLM_WriteObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), dataP, dataLen, atOffset);
		if (err)
		{	if (err == XError(kXHelperError, DLM_Err_ObjectIsConstant))
				err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
		}
	}

return err;
}

//===========================================================================================
// requires value to be a TEMP object
XErr	BAPI_ReplaceObj(long api_data, ObjRefP objref, ObjRefP value, Boolean extended)
{
XErr				err = noErr;
BfrDestructRec		destructRec;

	if (extended)
		err = ModifyVariable(api_data, (ObjRecordP)objref, (ObjRecordP)value, kExplicitTypeCast, false, GetModifyHook(OBJ_CLASSID_P(objref)));
	else
	{	/*if (value->classID == gsDispatcherData.arrayConstructor)
			err = DLM_ModifyObjWithArray(objref->list, objref->id, value->list, value->id, value->classID, VariableDestructorExt, api_data);
		else*/
		if (IS_IMMEDIATE_P(objref))
			return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
			
		destructRec.api_data = api_data;
		if (IS_IMMEDIATE_P(value))
		{	destructRec.scope = 0;
			switch(OBJ_CLASSID_P(value))
			{
				case kBooleanClassID:
					err = DLM_ModifyObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), IMM_P(value), sizeof(Boolean), kBooleanClassID, VariableDestructorExt, (long)&destructRec, nil);
					break;
				case kStringClassID:
					err = DLM_ModifyObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), IMM_P(value) + 1, IMMLEN_STRLEN_P(value), kStringClassID, VariableDestructorExt, (long)&destructRec, nil);
					break;
				case kDoubleClassID:
					err = DLM_ModifyObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), IMM_P(value), sizeof(double), kDoubleClassID, VariableDestructorExt, (long)&destructRec, nil);
					break;
				case kLongClassID:
					err = DLM_ModifyObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), IMM_P(value), sizeof(LONGLONG), kLongClassID, VariableDestructorExt, (long)&destructRec, nil);
					break;
				case kUnsignedClassID:
					err = DLM_ModifyObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), IMM_P(value), sizeof(unsigned long), kUnsignedClassID, VariableDestructorExt, (long)&destructRec, nil);
					break;
				case kIntClassID:
					err = DLM_ModifyObj(OBJ_LIST_P(objref), OBJ_ID_P(objref), IMM_P(value), sizeof(long), kIntClassID, VariableDestructorExt, (long)&destructRec, nil);
					break;
				case kCharClassID:
					CDebugStr("impossible char literal");
					break;
			}
		}
		else
		{	destructRec.scope = OBJ_SCOPE_P(objref);
			err = DLM_ModifyObjExt(OBJ_LIST_P(objref), OBJ_ID_P(objref), OBJ_LIST_P(value), OBJ_ID_P(value), VariableDestructorExt, (long)&destructRec, nil);
		}
		if (err)
		{	if (err == XError(kXHelperError, DLM_Err_ObjectIsConstant))
				err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
		}
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_ModifyObjClassID(long api_data, ObjRefP objref, long newObjClassID)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;

	if (IS_IMMEDIATE_P(objref) || (OBJ_SCOPE_P(objref) == TEMP))
		return XError(kBAPI_Error, Err_IllegalOperation);
	if NOT(err = DLM_SetUserData(OBJ_LIST_P(objref), OBJ_ID_P(objref), newObjClassID))
		OBJ_CLASSID(objref) = newObjClassID;
	
return err;
}

//===========================================================================================
XErr	BAPI_LockObj(long api_data, ObjRefP objref)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;

	if NOT(IS_IMMEDIATE_P(objref))
		err = DLM_TurnOnFlag(OBJ_LIST_P(objref), OBJ_ID_P(objref), kLocked, kDLMWhole);
	
return err;
}

//===========================================================================================
XErr	BAPI_UnlockObj(long api_data, ObjRefP objref)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;

	if NOT(IS_IMMEDIATE_P(objref))
		err = DLM_TurnOffFlag(OBJ_LIST_P(objref), OBJ_ID_P(objref), kLocked, kDLMWhole);
	
return err;
}

//===========================================================================================
// questa � pericolosa, andrebbe levata
/*XErr	BAPI_FreeObj(long api_data, ObjRefP objref)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
XErr	err = noErr;

	if (objref->scope == GLOBAL)
		err = XError(kBAPI_Error, Err_CantDeleteGlobalVariable);
	else
		err = DLM_DeleteObj(objref->list, objref->id, VariableDestructor, api_data);
	
return err;
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_ObjToInt(long api_data, ObjRefP objRef, long *valueP, long typeCastType)
{
	return CL_GetInt(api_data, OBJRECORD_P(objRef), valueP, typeCastType);
}

//===========================================================================================
XErr	BAPI_ObjToLong(long api_data, ObjRefP objRef, LONGLONG *lvalueP, long typeCastType)
{
	return CL_GetLong(api_data, OBJRECORD_P(objRef), lvalueP, typeCastType);
}

//===========================================================================================
XErr	BAPI_ObjToUnsigned(long api_data, ObjRefP objRef, unsigned long *ulongP, long typeCastType)
{
	return CL_GetUnsigned(api_data, OBJRECORD_P(objRef), ulongP, typeCastType);
}

//===========================================================================================
XErr	BAPI_ObjToDouble(long api_data, ObjRefP objRef, double *doubleP, long typeCastType)
{
	return CL_GetDouble(api_data, OBJRECORD_P(objRef), doubleP, typeCastType);
}

//===========================================================================================
XErr	BAPI_ObjToBoolean(long api_data, ObjRefP objRef, Boolean *valueP, long typeCastType)
{
	return CL_GetBoolean(api_data, OBJRECORD_P(objRef), valueP, typeCastType);
}

//===========================================================================================
XErr	BAPI_ObjToString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType)
{
	return CL_GetString(api_data, OBJRECORD_P(objRef), strP, strLenP, maxLen, typeCastType, kNormal);
}

//===========================================================================================
XErr	BAPI_ObjToChar(long api_data, ObjRefP objRef, char *theChar, long typeCastType)
{
	return CL_GetChar(api_data, OBJRECORD_P(objRef), theChar, typeCastType);
}

//===========================================================================================
XErr	BAPI_ObjToConstrString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType)
{
	return CL_GetString(api_data, OBJRECORD_P(objRef), strP, strLenP, maxLen, typeCastType, kForConstructor);
}

//===========================================================================================
XErr	BAPI_ObjToDebugString(long api_data, ObjRefP objRef, Ptr strP, long *strLenP, long maxLen, long typeCastType)
{
	return CL_GetString(api_data, OBJRECORD_P(objRef), strP, strLenP, maxLen, typeCastType, kForDebug);
}

//===========================================================================================
XErr	BAPI_ReadObj(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP)
{
	return _ReadObj(api_data, objRef, bufferP, lenP, offset, classIDP, false);
}

//===========================================================================================
XErr	BAPI_GetObj(long api_data, ObjRefP objRef, Ptr bufferP, long *lenP, long offset, long *classIDP)
{
	return _ReadObj(api_data, objRef, bufferP, lenP, offset, classIDP, true);
}

//===========================================================================================
XErr	BAPI_GetStringBlockExt(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType, short variant)
{		
XErr		err = noErr;
long		saveLastClassIDErrorCalled, dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock = 0L;
BifernoRec	*bRecP = (BifernoRecP)api_data;
CStr255		saveClass_error_note;

	if (aCStr)
	{	*refP = 0;
		dataP = aCStr;
		saveLastClassIDErrorCalled = bRecP->lastClassIDErrorCalled;
		if (*bRecP->class_error_note)
			CEquStr(saveClass_error_note, bRecP->class_error_note);
		else
			*saveClass_error_note = 0;
		if (err = CL_GetString(api_data, OBJRECORD_P(objRef), dataP, &dataLen, 256, typeCastType, variant))
		{	if (err == XError(kBAPI_Error, Err_BAPI_BufferTooSmall))
			{	bRecP->lastClassIDErrorCalled = saveLastClassIDErrorCalled;
				if (*saveClass_error_note)
					CEquStr(bRecP->class_error_note, saveClass_error_note);
				if (dataBlock = NewBlockLocked(dataLen + 1, &err, &dataP))
					err = CL_GetString(api_data, OBJRECORD_P(objRef), dataP, &dataLen, dataLen+1, typeCastType, variant);
			}
		}
	}
	else
	{	if NOT(err = CL_GetString(api_data, OBJRECORD_P(objRef), nil, &dataLen, 0, typeCastType, variant))
		{	++dataLen;	// 0-final
			if (dataBlock = NewBlockLocked(dataLen, &err, &dataP))
				err = CL_GetString(api_data, OBJRECORD_P(objRef), dataP, &dataLen, dataLen, typeCastType, variant);
		}
	}
	if NOT(err)
	{	if (stringP)
			*stringP = dataP;
		if (stringLen)
			*stringLen = dataLen;
		*refP = dataBlock;
	}
	else
	{	if (dataBlock)
			DisposeBlock(&dataBlock);
		*refP = 0;
	}
	
return err;
}

//===========================================================================================
/*ex
XErr	BAPI_GetStringBlockExt(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType, short variant)
{		
XErr		err = noErr;
long		dataLen = 0;
Ptr			dataP = nil;
BlockRef	dataBlock;

	*refP = 0;
	if NOT(err = CL_GetString(api_data, OBJRECORD_P(objRef), nil, &dataLen, 0, typeCastType, variant))
	{	++dataLen;	// 0-final
		if (aCStr && (dataLen < 255))
		{	dataP = aCStr;
			*refP = 0;
			if (stringP)
				*stringP = dataP;
		}
		else
		{	if (dataBlock = NewBlockLocked(dataLen, &err, &dataP))
			{	//LockBlock(dataBlock);
				//dataP = GetPtr(dataBlock);
				if (stringP)
					*stringP = dataP;
				*refP = dataBlock;
			}
		}
		if NOT(err)
		{	if NOT(err = CL_GetString(api_data, OBJRECORD_P(objRef), dataP, &dataLen, dataLen-1, typeCastType, variant))
			{	if (stringLen)
					*stringLen = dataLen;
			}
		}	
	}
	
if (err && *refP)
{	DisposeBlock(&dataBlock);
	*refP = 0;
}
return err;
}
*/
//===========================================================================================
XErr	BAPI_GetStringBlock(long api_data, ObjRefP objRef, char *aCStr, Ptr *stringP, long *stringLen, BlockRef *refP, long typeCastType)
{
	return BAPI_GetStringBlockExt(api_data, objRef, aCStr, stringP, stringLen, refP, typeCastType, kNormal);
}

//===========================================================================================
XErr	BAPI_GetObjBlock(long api_data, ObjRefP objRef, Ptr buffer, Ptr *stringP, long *stringLen, BlockRef *refP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
Boolean		isImmediate = IS_IMMEDIATE_P(objRef);
long		objID, objLen;
XErr		err = noErr;
BlockRef	block = 0L;
Ptr			dataP;

	if (isImmediate)
	{	if (buffer)
			dataP = buffer;	// always < 256 bytes
		else
			block = NewBlockLocked(MAX_SPACE_FOR_IMMEDIATE, &err, &dataP);
		if NOT(err)
		{	switch(OBJ_CLASSID_P(objRef))
			{
				case kBooleanClassID:
					objLen = sizeof(Boolean);
					*(Boolean*)dataP = *(Boolean*)IMM_P(objRef);
					break;
				case kStringClassID:
					objLen = IMMLEN_STRLEN_P(objRef);
					CopyBlock(dataP, IMM_P(objRef) + 1, objLen);
					dataP[objLen] = 0;
					break;
				case kDoubleClassID:
					objLen = sizeof(double);
					*(double*)dataP = *(double*)IMM_P(objRef);
					break;
				case kLongClassID:
					objLen = sizeof(LONGLONG);
					*(LONGLONG*)dataP = *(LONGLONG*)IMM_P(objRef);
					break;
				case kUnsignedClassID:
					objLen = sizeof(unsigned long);
					*(unsigned long*)dataP = *(unsigned long*)IMM_P(objRef);
					break;
				case kIntClassID:
					objLen = sizeof(long);
					*(long*)dataP = *(long*)IMM_P(objRef);
					break;
				case kCharClassID:
					CDebugStr("impossible char literal");
					break;
			}
			if (stringLen)
				*stringLen = objLen;
			if (stringP)
				*stringP = dataP;
			if (refP)
				*refP = block;
		}
	}
	else
	{	if (objID = OBJ_ID_P(objRef))
			err = DLM_GetObjBlock(OBJ_LIST_P(objRef), objID, buffer, stringP, stringLen, refP);
		else
			err = XError(kBAPI_Error, Err_BAPI_InvalidParameter);
	}

if (err && block)
	DisposeBlock(&block);	
return err;
}

//===========================================================================================
void	BAPI_ReleaseBlock(BlockRef *refP)
{
	if (*refP)
		DisposeBlock((BlockRef*)refP);
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_ConcatObjs(long api_data, ObjRefP objref1, ObjRefP objref2)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
Boolean		isImmediate;

	if (IS_IMMEDIATE_P(objref1))
		return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
	if (isImmediate = (IS_IMMEDIATE_P(objref2)))
		err = AddLiteralToObj(OBJRECORD_P(objref1), OBJRECORD_P(objref2));
	else
		err = DLM_ConcatObjs(OBJ_LIST_P(objref1), OBJ_ID_P(objref1), OBJ_LIST_P(objref2), OBJ_ID_P(objref2));
	if (err)
	{	if (err == XError(kXHelperError, DLM_Err_ObjectIsConstant))
			err = XError(kBAPI_Error, Err_IllegalOperationOnConstant);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_CopyObj(long api_data, ObjRefP sourceObj, long constructorPrivateData, ObjRefP destObj)
{
XErr			err = noErr;
CStr255			aStr;
char			*strP;
long			listID;
unsigned short	flags;
Boolean			isImmediate = IS_IMMEDIATE_P(sourceObj);
long			destObjScope, destObjType;
char			*destName;

	if NOT(api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if (constructorPrivateData)
	{	
	ConstructorAPIdataRec	*constrDataP = (ConstructorAPIdataRec*)constructorPrivateData;
	
		destObjScope = constrDataP->scope;
		destObjType = constrDataP->type;
		destName = constrDataP->resultObjName;
		/*if (destObjScope > GLOBAL)
		{	clID = OBJ_CLASSID_P(sourceObj);
			if ((clID < 0) || (gClassRecordBlockP[clID-1].instanceIsDLM))
				isDLM = true;
		}*/
	}
	else
	{	destObjScope = TEMP;
		destObjType = VARIABLE;
		destName = nil;
	}

	if (err = GetVariableList(api_data, destObjScope, &listID, false, 0))
		return err;

	if (listID == -1)
		return -1;
	
	if (destObjScope == TEMP)
		strP = nil;
	else
	{	if (destName)
		{	CEquStr(aStr, destName);
			strP = aStr;
		}
		else
			strP = nil;
	}
	
	if (isImmediate)
	{	if (destObjType == CONSTANT)
			flags = kCostant;
		else
			flags = 0;
		err = NewLiteralInList(strP, listID, OBJRECORD_P(sourceObj), flags, &OBJ_ID_P(destObj), 0);
	}
	else if NOT(err = DLM_GetInfo(OBJ_LIST_P(sourceObj), OBJ_ID_P(sourceObj), &flags, nil, nil))
	{	if (destObjType == CONSTANT)
			flags |= kCostant;				// alzo il bit kCostant	
		else
			flags &= (0xFFFF ^ kCostant);	// spengo il bit kCostant
		if NOT(err = DLM_CopyObj(OBJ_LIST_P(sourceObj), OBJ_ID_P(sourceObj), listID, strP, flags, &OBJ_ID_P(destObj)))
		{	if ((flags & kIsArray) && (flags & kCostant))
				err = DLM_TurnOnFlag(listID, OBJ_ID_P(destObj), kCostant, kDLMElements);
		}
	}
	if NOT(err)
	{	OBJ_LIST_P(destObj) = listID;
		OBJ_CLASSID_P(destObj) = OBJ_CLASSID_P(sourceObj);
		OBJ_TYPE_P(destObj) = destObjType;
		OBJ_SCOPE_P(destObj) = destObjScope;
	}

return err;
}

//===========================================================================================
/*XErr	BAPI_CloneObj(long api_data, ObjRefP sourceObj, char *destName, long destObjScope, long destObjType, ObjRefP destObj)
{
XErr			err = noErr;
ParameterRec	paramRec;

	ClearBlock(&paramRec, sizeof(ParameterRec));
	paramRec.objRef = *sourceObj;
	err = CL_Clone(api_data, destObjScope, destObjType, destName, OBJ_CLASSID_P(sourceObj), &paramRec, 1, 0, OBJRECORD_P(destObj));

return err;
}*/
				
//===========================================================================================
XErr	BAPI_GetPublishedVar(long api_data, char *applicationName, long theScope, char *objName, ObjRef *resultObjRefP)
{
XErr			err = noErr;
BlockRef		appBlock = 0;
Application 	*applP = nil;
BifernoRec		*bRecP;
ObjRef			result;
long			flags;
DLMRef			list;

	CHECK_RES(resultObjRefP)
	bRecP = (BifernoRecP)api_data;
	if (*applicationName)
	{	if NOT(err = GetApplicationBlock(applicationName, &appBlock))
		{	LockBlock(appBlock);
			applP = (Application*)GetPtr(appBlock);
		}
	}
	else
	{	if NOT(bRecP)
			err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
		else
			applP = &bRecP->application;
	}
	if NOT(err)
	{	switch(theScope)
		{
			case TEMP:
			case LOCAL:
			case GLOBAL:
				err =  XError(kBAPI_Error, Err_InvalidScope);
				break;		
			case APPLICATION:
				list = applP->list;
				break;		
			case SESSION:
				if NOT(err = ListFromSID(applP, bRecP->SID, &list))
				{	if NOT(list)
						err = XError(kBAPI_Error, Err_VariableNotDefined);
				}
				//err =  XError(kBAPI_Error, Err_InvalidScope);
				break;		
			case PERSISTENT:
				list = applP->persistentList;
				break;		
			default:
				err =  XError(kBAPI_Error, Err_InvalidScope);
				break;		
		}
		if NOT(err)
		{	if NOT(err = IsEntityNameValid(objName))
			{	if (OBJ_ID(result) = DLM_GetObjID(list, objName, &flags, &OBJ_CLASSID(result)))
				{	OBJ_LIST(result) = list;
					OBJ_TYPE(result) = OBJ_SCOPE(result) = 0;
					if (flags & kPublished)
						err = BAPI_Clone(api_data, &result, resultObjRefP, true);
					else
						err = XError(kBAPI_Error, Err_VariableNotPublished);
				}
				else
					err = XError(kBAPI_Error, Err_VariableNotDefined);
			}
		}
	}
	if (appBlock)
		DisposeBlock(&appBlock);
		
return err;
}
				
//===========================================================================================
XErr	BAPI_AvoidDestructor(long api_data, ObjRefP objRef, long mode)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;
unsigned short	flags;
Boolean	wasToDestruct;

	if (IS_IMMEDIATE_P(objRef))
		return noErr;
	switch(mode)
	{	case kMain:
			mode = kDLMMain;
			break;
		case kElements:
			mode = kDLMElements;
			break;
		case kWhole:
			mode = kDLMWhole;
			break;
	}
	if NOT(err = DLM_GetInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), &flags, nil, nil))
	{	wasToDestruct = (flags & kNoDestructor) == 0;
		if (wasToDestruct)
			err = DLM_TurnOnFlag(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), kNoDestructor, mode);
		else
			err = XError(kBAPI_Error, Err_BAPI_ObjNotToDestruct);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_ForceDestructor(long api_data, ObjRefP objRef, long mode)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;
unsigned short	flags;
Boolean	wasToDestruct;

	if (IS_IMMEDIATE_P(objRef))
		return noErr;
	switch(mode)
	{	case kMain:
			mode = kDLMMain;
			break;
		case kElements:
			mode = kDLMElements;
			break;
		case kWhole:
			mode = kDLMWhole;
			break;
	}
	if NOT(err = DLM_GetInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), &flags, nil, nil))
	{	wasToDestruct = (flags & kNoDestructor) == 0;
		if NOT(wasToDestruct)
			err = DLM_TurnOffFlag(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), kNoDestructor, mode);	// spengo il bit kNoDestructor
		else
			err = XError(kBAPI_Error, Err_BAPI_ObjAlreadyToDestruct);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_SetArrayElemName(long api_data, ObjRefP arrayObjRef, ArrayIndexRec *mCoords, short dim, char *name)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;
ObjRef	tObjRef, objref;

	tObjRef = *arrayObjRef;
	if NOT(err = BAPI_ElementOfArrayExt(api_data, &tObjRef, mCoords, dim, &objref))
	{	if (IS_IMMEDIATE(objref))
			return XError(kBAPI_Error, Err_IllegalOperation);
		err = DLM_SetName(OBJ_LIST(objref), OBJ_ID(objref), name);
		if (err)
		{	if (err == XError(kXHelperError, DLM_Err_ListDontAcceptNames))
				err = XError(kBAPI_Error, Err_IllegalOperation);
		}
	}
	
return err;
}

//===========================================================================================
/*XErr	BAPI_SetObjName(long api_data, ObjRefP objref, char *name)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
XErr	err = noErr;

	if (IS_IMMEDIATE_P(objref))
		return XError(kBAPI_Error, Err_IllegalOperation);
	err = DLM_SetName(OBJ_LIST_P(objref), OBJ_ID_P(objref), name);
	if (err)
	{	if (err == XError(kXHelperError, DLM_Err_ListDontAcceptNames))
			err = XError(kBAPI_Error, Err_IllegalOperation);
	}

return err;
}*/	

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*XErr	BAPI_NewArray(long api_data, Boolean fixedSize, unsigned long arrayDim, char *newObjName, 
												long objScope, long objType, 
												ParameterRec *varRecsP, long totVars,
												long *errElemIDXP, ObjRefP objRefP)
{
XErr				err = noErr;*/
/*CStr255				aStr;
char				*strP;
long				flags, listID;
CloneArrayRecord	csRec;
int					i;
*/

	/*if VALID_P(objRefP)
		err = _CreateArray(api_data, fixedSize, arrayDim, nil, 0, 0, varRecsP, totVars, errElemIDXP, false, OBJRECORD_P(objRefP));
	else
		err = _CreateArray(api_data, fixedSize, arrayDim, newObjName, objScope, objType, varRecsP, totVars, errElemIDXP, true, OBJRECORD_P(objRefP));
	}*/
	/*
	if NOT(api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (err = GetVariableList(api_data, objScope, &listID))
		return err;
	
	if (listID == -1)
		return -1;
	if (objScope == TEMP)
		strP = nil;
	else
	{	if (newObjName)
		{	CEquStr(aStr, newObjName);
			strP = aStr;
		}
		else
			strP = nil;
	}

	flags = 0;
	if (fixedSize)
		flags |= kFixedSize;
	if (objType == CONSTANT)
		flags |= kCostant;
	
	OBJ_ID(csRec.arrObjRef) = DLM_NewArray(listID, strP, gsDispatcherData.arrayConstructor, flags, arrayDim, 0,  &csRec.arrayDLRef, &err);
	OBJ_LIST(csRec.arrObjRef) = listID;
	if NOT(err)
	{	if (totVars)
		{	csRec.requestedClassID = OBJ_CLASSID(varRecsP->objRef);
			csRec.isArrayConstant = (objType == CONSTANT);
			if NOT(csRec.requestedClassID)
				csRec.isArrayFixed = false;
			else
				err = BAPI_FixedSize(api_data, csRec.requestedClassID, &csRec.isArrayFixed);
			if NOT(err)
			{	for (i = 0; (i < totVars) && NOT(err); i++, varRecsP++)
					err = AddElementToArray(api_data, varRecsP->name, &varRecsP->objRef, (long)&csRec);
			}
			if (err)
			{	if (errElemIDXP)
					*errElemIDXP = i;
				if ((err == XError(kBAPI_Error, Err_ArrayElementsTypeCastFailed)) && (i < totVars))
					NewMsgRecord(api_data, kTYPECAST, (char*)OBJ_CLASSID(varRecsP->objRef), csRec.requestedClassID, kUseForTypeCast);
			}
		}
		if NOT(err)
		{	OBJ_CLASSID(csRec.arrObjRef) = gsDispatcherData.arrayConstructor;
			OBJ_TYPE(csRec.arrObjRef) = objType;
			OBJ_SCOPE(csRec.arrObjRef) = objScope;
		}
		else
			DLM_DeleteObj(listID, OBJ_ID(csRec.arrObjRef), VariableDestructorExt, api_data);
	}
	if (NOT(err) && newObj)
		*newObj = OBJREF(csRec.arrObjRef);
	
	if (err == XError(kXHelperError, DLM_Err_DuplicatedObject))
		err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
	*/
	
//return err;
//}

//===========================================================================================
XErr	BAPI_GetArrayInfo(long api_data, ObjRefP objRef, long *arrayDimP, long *arrayClassIDP, long *dlmRefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err;
DLMRef		arrayDLRef;

	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), nil, &arrayDLRef, arrayDimP, arrayClassIDP))
	{	if (dlmRefP)
			*dlmRefP = arrayDLRef;
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_SetArrayElemClass(long api_data, ObjRefP objRef, long classID)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	return DLM_SetArrayElemClass(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), classID);
}

//===========================================================================================
XErr	BAPI_ArrayDelete(long api_data, ObjRefP objRef, long firstElem, long lastElem)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err = noErr;
DLMRef				arrayDLRef;
long				oldDim;
BfrDestructRec		destructRec;

	if (lastElem >= firstElem)
	{	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), nil,&arrayDLRef, &oldDim, nil))
		{	destructRec.api_data = api_data;
			destructRec.scope = OBJ_SCOPE_P(objRef);
			if NOT(err = DLM_DeleteObjects(arrayDLRef, firstElem, lastElem, VariableDestructorExt, (long)&destructRec))
				err = DLM_SetArrayDim(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), oldDim - (lastElem - firstElem + 1), true, nil, 0);
		}
	}
	else
		err = XError(kBAPI_Error, Err_OutOfBoundary);
		
return err;													
}

//===========================================================================================
XErr	BAPI_ArraySwap(long api_data, ObjRefP objRef, long elem1, long elem2)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
DLMRef		arrayDLRef;
long		oldDim;

	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), nil,&arrayDLRef, &oldDim, nil))
		err = DLM_SwapObjects(arrayDLRef, elem1, elem2);
		
return err;													
}

//===========================================================================================
XErr	BAPI_SetArrayDim(long api_data, ObjRefP theObjRefP, long newDim)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err;
BfrDestructRec		destructRec;

	destructRec.api_data = api_data;
	destructRec.scope = OBJ_SCOPE_P(theObjRefP);
	err = DLM_SetArrayDim(OBJ_LIST_P(theObjRefP), OBJ_ID_P(theObjRefP), newDim, false, VariableDestructorExt, (long)&destructRec);
	
return err;													
}

//===========================================================================================
XErr	BAPI_ElementOfArray(long api_data, ObjRefP objRef, long index, ObjRefP resultObjRef)
{
ArrayIndexRec	mCoord;
	
	mCoord.ind = index;
	*mCoord.ind_name = 0;
	
return ResolveArrayElement(api_data, objRef, &mCoord, 1, nil, nil, nil, resultObjRef, nil);
}

//===========================================================================================
XErr	BAPI_ElementOfArrayExt(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, ObjRefP resultObjRef)
{
return ResolveArrayElement(api_data, objRef, mCoords, dim, nil, nil, nil, resultObjRef, nil);
}

//===========================================================================================
XErr	BAPI_ArrayLoop(long api_data, ObjRefP objRef, BAPI_ArrayLoopCallBack callBack, long param)
{
CStr63		name;
XErr		err = noErr;
DLMRef 		arrayDLRef;
long		arrayDim;
int			i;
ObjRef		tObjRef;

	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), nil,&arrayDLRef, &arrayDim, &OBJ_CLASSID(tObjRef)))
	{	OBJ_LIST(tObjRef) = arrayDLRef;
		OBJ_TYPE(tObjRef) = 0;
		OBJ_SCOPE(tObjRef) = OBJ_SCOPE_P(objRef);
		for (i = 1; (i <= arrayDim) && NOT(err); i++)
		{	if NOT(err = DLM_GetIndObj(arrayDLRef, i, nil, nil, 0, nil, &OBJ_ID(tObjRef), name, false, false))
				err = callBack(api_data, name, &tObjRef, param);
		}
	}
	if (err == XError(kBAPI_Error, Err_BAPI_LoopAbort))
		err = noErr;
	
return err;
}

//===========================================================================================
XErr	BAPI_ArrayAddElement(long api_data, ObjRefP arrayObjRefP, char *name, ObjRef *objToAdd)
{
long				arrayDim, requestedClassID;
XErr				err = noErr;
CloneArrayRecord	csRec;
unsigned short		arrayFlags;
ArraySpecs			arSpec;

	//ex if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), &arrayFlags, &csRec.arrayDLRef, &arrayDim, &requestedClassID))
	if NOT(err = GetArraySpecs(api_data, OBJRECORD_P(arrayObjRefP), &arSpec))
	{	csRec.arrObjRef = OBJRECORD(*arrayObjRefP);
		//csRec.requestedElementClassID = requestedClassID;
		csRec.reqElement_Ae_Level = arSpec.arrayElemAeLevel;	//arrayDim - 1;
		arrayDim = arSpec.arrayDim;
		requestedClassID = arSpec.arrayElemClassID;
		arrayFlags = arSpec.arrayFlags;
		csRec.arrayDLRef = arSpec.arrayDLRef;
		if (arSpec.arrayElemAeLevel)	// multi dimens
		{	csRec.reqElementClassID = gsDispatcherData.arrayConstructor;
			csRec.reqElement_Ae_ClassID = requestedClassID;
		}
		else
		{	csRec.reqElementClassID = requestedClassID;
			csRec.reqElement_Ae_ClassID = 0;
		}
		if NOT(err)
		{	csRec.isArrayConstant = (arrayFlags & kCostant) != 0;
			if NOT(requestedClassID)
				csRec.isArrayFixed = false;
			else
				err = BAPI_FixedSize(api_data, requestedClassID, &csRec.isArrayFixed);
			if NOT(err)
			{	csRec.arrayDim = arrayDim;
				if NOT(err = AddElementToArray(api_data, name, objToAdd, (long)&csRec))
					;//err = DLM_SetArrayDim(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), arrayDim+1, true, nil, 0);
			}
		}
	}
	if (err == XError(kXHelperError, DLM_Err_DuplicatedObject))
		err = XError(kBAPI_Error, Err_DuplicatedArrayElemName);
	
return err;
}

//===========================================================================================
XErr	BAPI_ArrayReverse(long api_data, ObjRefP arrayObjRefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;
DLMRef	dlRef;

	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), nil,&dlRef, nil, nil))
	{	if NOT(err = DLM_ReverseList(&dlRef))
			err = DLM_UpdateArrayDLRef(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), dlRef);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_ArrayGetElementIndex(long api_data, ObjRef *arrayObjRef, ObjRefP objRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data, arrayObjRef)
#endif
	
	return OBJ_ID_P(objRef);
}

//===========================================================================================
XErr	BAPI_ArraySort(long api_data, ObjRefP arrayObjRefP, long mode, long alg, BAPI_ArraySortCallBack callBack, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err = noErr;
long				elemClass;
DLMRef				dlRef;
ArraySortRec		arraySortRec;
DLMSortCallBackFast	_arraySortCallBackFast;

	switch(alg)
	{	case kSortChoose:
			alg = kChoose;
			break;
		case kSortBubble:
			alg = kBubble;
			break;
		case kSortShell:
			alg = kShell;
			break;
		default:
			alg = kChoose;
			break;
	}
	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), nil,&dlRef, nil, &elemClass))
	{	arraySortRec.api_data = api_data;
		arraySortRec.callBack = callBack;
		arraySortRec.callBackParam = param;
		arraySortRec.mode = mode;
		arraySortRec.index = 0;
		if (callBack)
			_arraySortCallBackFast = nil;
		else switch(elemClass)
		{
			case kBooleanClassID:
				_arraySortCallBackFast = _arraySortCallBackFast_bool;
				break;
			case kStringClassID:
				_arraySortCallBackFast = _arraySortCallBackFast_string;
				break;
			case kDoubleClassID:
				_arraySortCallBackFast = _arraySortCallBackFast_double;
				break;
			case kLongClassID:
				_arraySortCallBackFast = _arraySortCallBackFast_long;
				break;
			case kUnsignedClassID:
				_arraySortCallBackFast = _arraySortCallBackFast_unsigned;
				break;
			case kIntClassID:
				_arraySortCallBackFast = _arraySortCallBackFast_int;
				break;
			case kCharClassID:
				_arraySortCallBackFast = _arraySortCallBackFast_char;
				break;
			default:
				_arraySortCallBackFast = nil;
				break;
		}		
		BAPI_LockObj(api_data, arrayObjRefP);
		if (_arraySortCallBackFast)
			err = DLM_SortList(&dlRef, nil, _arraySortCallBackFast, (long)&arraySortRec, alg);
		else
			err = DLM_SortList(&dlRef, _ArraySortCallBack, nil, (long)&arraySortRec, alg);
		if NOT(err)
			err = DLM_UpdateArrayDLRef(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), dlRef);
		BAPI_UnlockObj(api_data, arrayObjRefP);
	}
	
return err;
}

//===========================================================================================
/*XErr	_AddObjAtPos(DLMRef dlRef, char *nameP, ObjRefP objRefP)
{
XErr		err = noErr;

	switch(OBJ_CLASSID_P(objRefP))
	{
		case kBooleanClassID:
			destId = DLM_NewObjAtPos(dlRef, nameP, IMM_P(objRefP), sizeof(Boolean), kBooleanClassID, kFixedSize, pos++, &err);
			break;
		case kStringClassID:
			destId = DLM_NewObjAtPos(dlRef, nameP, IMM_P(objRefP) + 1, IMMLEN_STRLEN_P(objRefP), kStringClassID, 0, pos++, &err);
			break;
		case kDoubleClassID:
			destId = DLM_NewObjAtPos(dlRef, nameP, IMM_P(objRefP), sizeof(double), kDoubleClassID, kFixedSize, pos++, &err);
			break;
		case kLongClassID:
			destId = DLM_NewObjAtPos(dlRef, nameP, IMM_P(objRefP), sizeof(LONGLONG), kLongClassID, kFixedSize, pos++, &err);
			break;
		case kUnsignedClassID:
			destId = DLM_NewObjAtPos(dlRef, nameP, IMM_P(objRefP), sizeof(unsigned long), kUnsignedClassID, kFixedSize, pos++, &err);
			break;
		case kIntClassID:
			destId = DLM_NewObjAtPos(dlRef, nameP, IMM_P(objRefP), sizeof(long), kIntClassID, kFixedSize, pos++, &err);
			break;
		case kCharClassID:
			CDebugStr("impossible char literal");
			break;
	}

return err;
}*/

//===========================================================================================
XErr	BAPI_ArrayInsert(long api_data, ObjRefP arrayObjRefP, int pos, ParameterRec *paramVarsP, long totParams)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
DLMRef		dlRef;
long		destID, arrClassID, i, dim, destId;
char		*nameP;
CStr15		tStr;
BifernoRecP	bRecP;
DLMRef		list;
Boolean		contRef, isImm, fixedSize;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), nil, &dlRef, &dim, &arrClassID))
	{	for (i = 0; (i < totParams) && NOT(err); i++, paramVarsP++)
		{	if (*paramVarsP->name)
				nameP = paramVarsP->name;
			else
			{	*tStr = 0;
				nameP = tStr;
			}
			if NOT(isImm = IS_IMMEDIATE(paramVarsP->objRef))
				contRef = ContainsReference(OBJRECORD_P(&paramVarsP->objRef));
			else
				contRef = false;
			if ((OBJ_CLASSID(paramVarsP->objRef) != arrClassID) || contRef)
			{	list = bRecP->volatileList;
				if NOT(arrClassID)
					fixedSize = false;
				else
					err = BAPI_FixedSize(api_data, arrClassID, &fixedSize);
				if NOT(err)
				{	if NOT(err = CloneObject(api_data, OBJRECORD_P(&paramVarsP->objRef), nil, list, TEMP, arrClassID, 0, false, fixedSize, &destID, nil, true))
						err = DLM_InsertObj(list, destID, dlRef, nameP, -1, &destId, pos++);
				}
			}
			else
			{	if (isImm)
					err = NewLiteralInList(nameP, list, (ObjRecordP)&paramVarsP->objRef, 0, &destId, pos++);
				else
				{	destID = OBJ_ID(paramVarsP->objRef);
					list = OBJ_LIST(paramVarsP->objRef);
					err = DLM_InsertObj(list, destID, dlRef, nameP, -1, &destId, pos++);
				}
			}
			/*if NOT(err)
			{	if (isImm = IS_IMMEDIATE(paramVarsP->objRef))
					err = _AddObjAtPos(list, nameP, ObjRefP objRefP)
				else
					err = DLM_InsertObj(list, destID, dlRef, nameP, -1, &destId, pos++);
			}*/
		}
		if NOT(err)
			err = DLM_SetArrayDim(OBJ_LIST_P(arrayObjRefP), OBJ_ID_P(arrayObjRefP), dim + totParams, true, nil, 0);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_ArrayReset(long api_data, ObjRefP objRefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
DLMRef			dlRef;
BfrDestructRec	destructRec;

	if NOT(err = DLM_GetArrayInfo(OBJ_LIST_P(objRefP), OBJ_ID_P(objRefP), nil, &dlRef, nil, nil))
	{	destructRec.api_data = api_data;
		destructRec.scope = OBJ_SCOPE_P(objRefP);
		DLM_ResetList(dlRef, VariableDestructorExt, (long)&destructRec, 0, true);
		DLM_SetArrayDim(OBJ_LIST_P(objRefP), OBJ_ID_P(objRefP), 0, true, nil, 0);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_ArrayConcat(long api_data, ObjRefP objRef1, ObjRefP objRef2, ObjRefP result)
{
XErr				err = noErr;
//ObjRef				newArrayObjRef;
long				classID1, classID2;
Boolean				fixedSize1, fixedSize2;
_ArrayConcatRec		arrConcatRec;

	if (err = DLM_GetArrayInfo(OBJ_LIST_P(objRef1), OBJ_ID_P(objRef1), nil, nil, nil, &classID1))
		goto out;
	if (err = BAPI_FixedSize(api_data, classID1, &fixedSize1))
		goto out;
	if (err = DLM_GetArrayInfo(OBJ_LIST_P(objRef2), OBJ_ID_P(objRef2), nil, nil, nil, &classID2))
		goto out;
	if (err = BAPI_FixedSize(api_data, classID2, &fixedSize2))
		goto out;
//XErr	BAPI_ArrayToObj(long api_data, Boolean fixedSize, ParameterRec *varRecsP, long totVars, long *errElemIDXP, long constructorPrivateData, ObjRefP objRefP)
	if NOT(err = BAPI_ArrayToObj(api_data, (Boolean)(fixedSize1 && fixedSize2), nil, 0L, nil, 0L, result))
	{	arrConcatRec.arrayObjRefP = result;
		//arrConcatRec.index = 1;
		arrConcatRec.arrClassID = classID2;
		if NOT(err = BAPI_ArrayLoop(api_data, objRef1, _ArrayConcatCallBack, (long)&arrConcatRec))
		{	err = BAPI_ArrayLoop(api_data, objRef2, _ArrayConcatCallBack, (long)&arrConcatRec);
			//*result = newArrayObjRef;
		}
	}

out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_Accessor(long api_data, long classID, long message, Biferno_ParamBlockPtr paramBlockPtr)
{
	return CL_Accessor(api_data, classID, message, paramBlockPtr);
}

//===========================================================================================
XErr	BAPI_Constructor(long api_data, long classID, ParameterRec *varRecsP, long totVars, ObjRef *resultObjRefP)
{
BAPI_Doc 	*docP;
XErr	err = noErr;
	
	if NOT(err = GetContructorDoc(api_data, classID, &docP))
		err = CL_Constructor(api_data, TEMP, VARIABLE, nil, classID, varRecsP, totVars, docP, OBJRECORD_P(resultObjRefP));

return err;
}

//===========================================================================================
XErr	BAPI_Clone(long api_data, ObjRef *sourceP, ObjRef *destP, Boolean cloneTarget)
{
ParameterRec	param;
long			objType;

	BAPI_ClearParameterRec(api_data, &param);
	param.objRef = *sourceP;
	if (IS_IMMEDIATE_P(sourceP))
		objType = CONSTANT;
	else
		objType = OBJ_TYPE_P(sourceP);

return CL_Clone(api_data, TEMP, objType/*VARIABLE*/, nil, OBJ_CLASSID_P(sourceP), &param, 1, 0, cloneTarget, OBJRECORD_P(destP));
}

//===========================================================================================
XErr	BAPI_Destructor(long api_data, ObjRefP varRecP)
{
XErr	err = noErr;

	err = CL_Destructor(api_data, OBJRECORD_P(varRecP));

return err;
}

//===========================================================================================
XErr	BAPI_ExecuteOperation(long api_data, ObjRefP item1, ObjRefP item2, long operation, ObjRefP resultVarRecP)
{
XErr	err = noErr;

	err = CL_ExecuteOperation(api_data, OBJRECORD_P(item1), OBJRECORD_P(item2), operation, OBJRECORD_P(resultVarRecP));

return err;
}

//===========================================================================================
XErr	BAPI_Increment(long api_data, ObjRefP objRefP, Boolean toDecr)
{
	return CL_Increment(api_data, (ObjRecordP)objRefP, toDecr);
}

//===========================================================================================
/*XErr	BAPI_Increment(long api_data, ObjRefP elem, Boolean toDecr)
{
	return CL_Increment(api_data, OBJRECORD_P(elem), toDecr);
}*/

//===========================================================================================
XErr	BAPI_ExecuteMethod(long api_data, ObjRefP objRef, ParameterRec *paramVarsP, long totParams, char *methodName, ObjRefP resultVarRecP, Boolean *sideEffectP)
{
XErr					err = noErr;
BlockRef				membIdentBlock;
SuperIsChangedNotify 	*notifyP = nil;
MemberAction			*membIdentP;
Boolean					memberExists;

	//CEquStr(membIdent.memberName, methodName);
	if NOT(err = GetMemberInfo(api_data, methodName, OBJ_CLASSID_P(objRef), OBJRECORD_P(objRef), &membIdentBlock, &membIdentP, '(', &memberExists, false, &notifyP, false, false))
	{	if (memberExists)
		{	//membIdentP = (MemberAction*)GetPtr(membIdentBlock);
			if (membIdentP->doc.type == kMethod)
				err = CL_ExecuteMethod(api_data, membIdentP, paramVarsP, totParams, OBJRECORD_P(resultVarRecP), sideEffectP);
			else
				err = XError(kBAPI_Error, Err_NoSuchMethod);
			if (notifyP)
			{	if NOT(err)
					err = NotifySuperIsChanged(api_data, notifyP);
				PoolDisposePtr(gsDispatcherData.notifySuperIsChangedPool, notifyP->slot/*, notifyP->block*/);
			}
			if (membIdentBlock)
				DisposeBlock(&membIdentBlock);
			else
				PoolDisposePtr(gsDispatcherData.propertyActionPool, membIdentP->slot);
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchMethod);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_GetProperty(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP resultVarRecP)
{
XErr			err = noErr;
BlockRef		membIdentBlock;
MemberAction	*membIdentP;
Boolean			memberExists;

	//CEquStr(membIdent.memberName, propertyName);
	if NOT(err = GetMemberInfo(api_data, propertyName, OBJ_CLASSID_P(objRef), OBJRECORD_P(objRef), &membIdentBlock, &membIdentP, 0, &memberExists, false, nil, false, false))
	{	if (memberExists)
		{	//membIdentP = (MemberAction*)GetPtr(membIdentBlock);
			if (membIdentP->doc.type == kProperty)
				err = CL_GetProperty(api_data, membIdentP, propertyDim, propertyIndex, OBJRECORD_P(resultVarRecP));
			else
			{	err = XError(kBAPI_Error, Err_NoSuchProperty);
				NewMsgRecord(api_data, kMEMBER, propertyName, 0, 0);
			}
			if (membIdentBlock)
				DisposeBlock(&membIdentBlock);
			else
				PoolDisposePtr(gsDispatcherData.propertyActionPool, membIdentP->slot);
		}
		else
		{	err = XError(kBAPI_Error, Err_NoSuchProperty);
			NewMsgRecord(api_data, kMEMBER, propertyName, 0, 0);
		}
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_SetProperty(long api_data, ObjRefP objRef, char *propertyName, long propertyDim, ArrayIndexRec *propertyIndex, ObjRefP value)
{
XErr					err = noErr;
BlockRef				membIdentBlock;
SuperIsChangedNotify 	*notifyP = nil;
MemberAction			*membIdentP;
Boolean					memberExists;

	//CEquStr(membIdent.memberName, propertyName);
	if NOT(err = GetMemberInfo(api_data, propertyName, OBJ_CLASSID_P(objRef), OBJRECORD_P(objRef), &membIdentBlock, &membIdentP, 0, &memberExists, false, &notifyP, false, false))
	{	if (memberExists)
		{	//membIdentP = (MemberAction*)GetPtr(membIdentBlock);
			if (membIdentP->doc.type == kProperty)
				err = CL_SetProperty(api_data, membIdentP, propertyDim, propertyIndex, OBJRECORD_P(value));
			else
				err = XError(kBAPI_Error, Err_NoSuchProperty);
			if (notifyP)
			{	if NOT(err)
					err = NotifySuperIsChanged(api_data, notifyP);
				PoolDisposePtr(gsDispatcherData.notifySuperIsChangedPool, notifyP->slot/*, notifyP->block*/);
			}
			if (membIdentBlock)
				DisposeBlock(&membIdentBlock);
			else
				PoolDisposePtr(gsDispatcherData.propertyActionPool, membIdentP->slot);
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchProperty);
	}

return err;
}

//===========================================================================================
/*XErr	BAPI_Modify(long api_data, ObjRefP varToSet, ObjRefP value)
{
	return CL_Modify(api_data, varToSet, value);
}*/

//===========================================================================================
XErr	BAPI_TypeCast(long api_data, ObjRefP objRef, long requestedClassID, ObjRefP resultVarRecP, long typeCastType)
{
XErr	err = noErr;

	err = CL_TypeCast(api_data, OBJRECORD_P(objRef), requestedClassID, OBJRECORD_P(resultVarRecP), typeCastType);

return err;
}

//===========================================================================================
XErr	BAPI_ExecuteFunction(long api_data, ParameterRec *paramVarsP, long totParams, char *functionName, ObjRefP resultVarRecP)
{
XErr		err = noErr;
//long	funcPlugID, funcID, funcObjID;
BlockRef	membIdentBlock;
Boolean		exists;

	if (NOT(err = GetFunctionInfo(api_data, nil, nil, functionName, &membIdentBlock, &exists)) && exists)
	{	err = CL_ExecuteFunction(api_data, (MemberAction*)GetPtr(membIdentBlock), nil, paramVarsP, totParams, OBJRECORD_P(resultVarRecP));
		DisposeBlock(&membIdentBlock);
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchFunction);

return err;
}

//===========================================================================================
XErr	BAPI_GetErrMessage(long api_data, long classID, short theError, char *errName, char *errMessage, char *errType)
{
	return CL_GetErrMessage(api_data, classID, theError, errName, errMessage, errType);
}

//===========================================================================================
/*XErr	BAPI_GetErrNumber(long api_data, long classID, char *errName, long *theErrorP)
{
	return CL_GetErrNumber(api_data, classID, errName, theErrorP);
}*/

//===========================================================================================
XErr	BAPI_SuperIsChanged(long api_data, ObjRef *objRef, char *propertyName)
{
	return CL_SuperIsChanged(api_data, OBJRECORD_P(objRef), propertyName);
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_EncodeIsolatin(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR, Boolean encodeGthLth, Boolean useNames, Boolean extTags, long userTagList)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	return EncodeIsolatin(stringP, stringLen, resultStringP, resultLenP, alsoCR, encodeGthLth, useNames, extTags, userTagList);
}

//===========================================================================================
XErr	BAPI_DecodeIsolatin(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean alsoCR)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	return DecodeIsolatin(stringP, stringLen, resultStringP, resultLenP, alsoCR);
}

//===========================================================================================
XErr	BAPI_EncodeURL(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean spaceToPlus, char *preStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	return EncodeURL(stringP, stringLen, resultStringP, resultLenP, spaceToPlus, preStr);
}

//===========================================================================================
XErr	BAPI_DecodeURL(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, Boolean plusToSpace, char *preStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	return DecodeURL(stringP, stringLen, resultStringP, resultLenP, plusToSpace, preStr);
}

//===========================================================================================
XErr	BAPI_EncodeBase64(long api_data, char *stringP, long stringLen, char *resultStringP, long *resultStringLengthP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	*resultStringLengthP = HTUU_encode((Byte*)stringP, stringLen, resultStringP);
	
return noErr;
}

//===========================================================================================
XErr	BAPI_DecodeBase64(long api_data, char *stringP, long stringLen, char *resultStringP, long *resultStringLengthP, long maxStorage)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data, stringLen)
#endif

	*resultStringLengthP = HTUU_decode(stringP, (Byte*)resultStringP, maxStorage);
	
return noErr;
}

//===========================================================================================
/*XErr	BAPI_EncodeJavaScript(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP, )
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
	return EncodeEsa(stringP, stringLen, resultStringP, resultLenP);
}

//===========================================================================================
XErr	BAPI_DecodeJavaScript(long api_data, Byte *stringP, long stringLen, BlockRef *resultStringP, long *resultLenP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
	return DecodeEsa(stringP, stringLen, resultStringP, resultLenP);
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_GetTotVariables(long api_data, long *totVarsP, long scope, int stackIndex, Boolean onlyArguments)
{	
	long			listID;
	XErr			err = noErr;
	BifernoRecP		bRecP;
	StackRecord		*stackP;
	
	if (api_data)
		bRecP = (BifernoRecP)api_data;
	else
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (err = GetVariableList(api_data, scope, &listID, false, stackIndex))
		return err;
	if (onlyArguments)
	{	
		if (stackP = BfrGetIndStack(bRecP, stackIndex))
			*totVarsP = stackP->totInputs;
	}
	else
		err = DLM_GetTotObjs(listID, totVarsP, true);
	
return err;
}

//===========================================================================================
XErr	BAPI_GetTotVariables(long api_data, long *totVarsP, long scope)
{	
	return _GetTotVariables(api_data, totVarsP, scope, 0, false);
}

//===========================================================================================
XErr	BAPI_GetListTotVariables(long api_data, long scope, int stackIndex, long *totVarsP)
{	
	return _GetTotVariables(api_data, totVarsP, scope, stackIndex, false);
}

//===========================================================================================
XErr	BAPI_GetListTotVariablesExt(long api_data, long scope, int stackIndex, Boolean onlyArguments, long *totVarsP)
{	
	return _GetTotVariables(api_data, totVarsP, scope, stackIndex, onlyArguments);
}

//===========================================================================================
static XErr	_GetIndVariable(long api_data, long index, long scope, Boolean sorted, char *name, ObjRef *objIDP, int stackIndex)
{	
long			listID;
XErr			err = noErr;
unsigned short	flags;

	CHECK_RES(objIDP)

	if NOT(api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (err = GetVariableList(api_data, scope, &listID, false, stackIndex))
		return err;
	if NOT(err = DLM_GetIndObj(listID, index, nil, nil, 0, &OBJ_CLASSID_P(objIDP), &OBJ_ID_P(objIDP), name, sorted, true))
	{	OBJ_LIST_P(objIDP) = listID;
		OBJ_SCOPE_P(objIDP) = scope;
		if NOT(err = DLM_GetInfo(listID, index, &flags, nil, nil))
		{	if (flags & kCostant)
				OBJ_TYPE_P(objIDP) = CONSTANT;
			else
				OBJ_TYPE_P(objIDP) = VARIABLE;
			if NOT(OBJ_CLASSID_P(objIDP))
			{	err = BAPI_StringToObj(api_data, name, CLen(name), objIDP);
				*name = 0;
			}
		}
	}
	if (err == XError(kXHelperError, DLM_Err_ObjectNotFound))
		err = XError(kBAPI_Error, Err_InvalidIndex);

return err;
}

//===========================================================================================
XErr	BAPI_GetIndVariable(long api_data, long index, long scope, Boolean sorted, char *name, ObjRef *objIDP)
{	
	return _GetIndVariable(api_data, index, scope, sorted, name, objIDP, 0);
}

//===========================================================================================
XErr	BAPI_GetListIndVariable(long api_data, long index, long scope, Boolean sorted, char *name, int stackIndex, ObjRef *objIDP)
{	
	return _GetIndVariable(api_data, index, scope, sorted, name, objIDP, stackIndex);
}

//===========================================================================================
XErr	BAPI_Publish(long api_data, Boolean toPublish, ObjRef *objrefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;

	switch(OBJ_SCOPE_P(objrefP))
	{
		case TEMP:
		case LOCAL:
		case GLOBAL:
			err =  XError(kBAPI_Error, Err_IllegalOperation);
			break;		
		case APPLICATION:
			// ok
			break;		
		case SESSION:
			// ok
			//err =  XError(kBAPI_Error, Err_IllegalOperation);
			break;		
		case PERSISTENT:
			// ok
			break;		
		default:
			err =  XError(kBAPI_Error, Err_IllegalOperation);
			break;		
	}
	if NOT(err)
	{	// if ((objrefP->scope == LOCAL) || (objrefP->scope == GLOBAL))
		// 	return XError(kBAPI_Error, Err_IllegalOperation);
		if (toPublish)
			err = DLM_TurnOnFlag(OBJ_LIST_P(objrefP), OBJ_ID_P(objrefP), kPublished, kDLMWhole);
		else
			err = DLM_TurnOffFlag(OBJ_LIST_P(objrefP), OBJ_ID_P(objrefP), kPublished, kDLMWhole);
	}
	
return err;
}
				
//===========================================================================================
XErr	BAPI_Undef(long api_data, ObjRef *varObjRefP)
{
XErr		err = noErr;
//ObjRef		*objP, target;

	/*if (OBJ_CLASSID_P(varObjRefP) == gsDispatcherData.refConstructor)
	{	if NOT(err = ref_GetTarget(api_data, varObjRefP, &target))
			objP = &target;
	}
	else
		objP = varObjRefP;
	if NOT(err)*/
	err = UndefVariable(api_data, varObjRefP, true);
	
return err;
}

//===========================================================================================
XErr	BAPI_Hide(long api_data, Boolean toHide, ObjRef *objRef)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
//ObjRef		*objP, target;

	if (IS_IMMEDIATE_P(objRef) || (OBJ_SCOPE_P(objRef) == TEMP))
		return XError(kBAPI_Error, Err_IllegalOperation);
	/*if (OBJ_CLASSID_P(objRef) == gsDispatcherData.refConstructor)
	{	if NOT(err = ref_GetTarget(api_data, objRef, &target))
			objP = &target;
	}
	else
		objP =  objRef;*/
	if (toHide)
		err = DLM_TurnOnFlag(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), kHidden, kDLMWhole);
	else
		err = DLM_TurnOffFlag(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), kHidden, kDLMWhole);

return err;
}

//===========================================================================================
XErr	BAPI_IsVariableInitialized(long api_data, ObjRefP objrefP, Boolean *isInitP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
long		classID, objLen;

	if (IS_IMMEDIATE_P(objrefP))
		*isInitP = true;
	else
	{	classID = OBJ_CLASSID_P(objrefP);
		if NOT(classID)
			*isInitP = false;
		else if (classID == kStringClassID)
			*isInitP = true;
		else if NOT(err = DLM_GetObj(OBJ_LIST_P(objrefP), OBJ_ID_P(objrefP), nil, &objLen, 0, nil))
			*isInitP = (objLen != 0);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_IsVariableHidden(long api_data, ObjRefP objRef, Boolean *isHidden)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err = noErr;
unsigned short		flags;

	if (IS_IMMEDIATE_P(objRef))
	{	if (isHidden)
			*isHidden = false;
	}
	else
	{	if NOT(err = DLM_GetInfo(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), &flags, nil, nil))
		{	if (isHidden)
				*isHidden = (Boolean)(flags & kHidden);
		}
	}
return err;


}

//===========================================================================================
/*XErr	BAPI_IsClassDef(long api_data, char *name, Boolean *isDefP)
{
XErr			err = noErr;
Boolean			res = false;
BifernoRecP		bRecP = (BifernoRecP)api_data;

	if (DLM_GetObjID(gsDispatcherData.classListRef, name, nil, nil))
		res = true;
	else if (bRecP)
	{	if (DLM_GetObjID(bRecP->local.classList, name, nil, nil))
			res = true;
		else if (DLM_GetObjID(bRecP->application.classList, name, nil, nil))
			res = true;
	}
	*isDefP = res;

return err;
}
*/
//===========================================================================================
XErr	BAPI_IsFuncDef(long api_data, char *name, Boolean *isDefP)
{
XErr			err = noErr;
Boolean			res = false;
BifernoRecP		bRecP = (BifernoRecP)api_data;

	if (DLM_GetObjID(gsDispatcherData.functionsList, name, nil, nil))
		res = true;
	else if (bRecP)
	{	if (DLM_GetObjID(bRecP->local.funcsList, name, nil, nil))
			res = true;
		else if (DLM_GetObjID(bRecP->application.funcsList, name, nil, nil))
			res = true;
	}
	*isDefP = res;

return err;
}

//===========================================================================================
XErr	BAPI_IsVariableDefined(long api_data, char *name, long theScope, Boolean *isDefP, ObjRef *varObjRefP)
{
XErr		err = noErr;
long		objID, varList, classID;
long		type, scope;
CStr63		varName;
ObjRef		varObjRef;
char		*textP;
long		len;

	if (theScope)
	{	scope = theScope;
		if (err = GetVariableList(api_data, scope, &varList, false, 0))
			return err;
		type = 0;
		CEquStr(varName, name);
		textP = nil;
	}
	else
	{	varList = 0;
		scope = 0;
		textP = name;
		len = CLen(name);
		// Scope & Type
		if NOT(err = GetScopeAndType(api_data, &textP, &len, &varList, &type, &scope, varName))
		{	// Var name
			if NOT(varName[0])
				err = GetEntityName(api_data, &textP, &len, varName, false);
		}
	}	
	if NOT(err)
	{	objID = classID = 0;
		objID = LookForObj(api_data, varName, &varList, &type, &classID, &scope, &err);
		if NOT(err)
		{	OBJ_LIST(varObjRef) = varList;
			OBJ_ID(varObjRef) = objID;
			OBJ_CLASSID(varObjRef) = classID;
			OBJ_SCOPE(varObjRef) = scope;
			OBJ_TYPE(varObjRef) = type;
			if (objID && textP && len)
			{	if NOT(err = ResolveArryItem(api_data, &textP, &len, OBJRECORD_P(&varObjRef), nil, nil, false, nil, nil))
				{	if (len)
						err = XError(kBAPI_Error, Err_BadSyntax);
					else if NOT(OBJ_CLASSID(varObjRef))
						objID = 0;
				}
			}
			if NOT(err)
			{	if (varObjRefP)
					*varObjRefP = varObjRef;
				*isDefP = (objID != 0) && (classID != 0);
			}
		}
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_GetClassInfo(long api_data, long classID, BAPI_ClassInfo *classInfoP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
Boolean			wantDestructor, wantClone;
long			implem, tLen;
PluginRecord	*plugRecP;

	if (classID > 0)
	{	if (classID <= gsDispatcherData.totClass)
		{	wantDestructor = WantDestructorFromClass(classID);
			plugRecP = &gClassRecordBlockP[classID-1];
			classInfoP->extendedClassID = plugRecP->extendedPluginID;
			wantClone = WantCloneEvent(plugRecP, nil);
			implem = kCImplementation;
			*classInfoP->sourceFilePath = 0;
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchClass);
	}
	else if ((classID < 0) && api_data)
	{	
	BifernoClass	bClass;
	
		wantDestructor = true;
		wantClone = true;
		tLen = sizeof(BifernoClass);
		if NOT(err = GetUserClassRecord((BifernoRecP)api_data, classID, (Ptr)&bClass, &tLen, 0, nil))
		{	classInfoP->extendedClassID = bClass.extendedClassID;
			implem = kBifernoImplementation;
			CEquStr(classInfoP->sourceFilePath, bClass.sourceFilePath);
		}
	}
	else
		err = XError(classID, Err_NoSuchClass);
	
	if NOT(err)
	{	classInfoP->wantDestructor = wantDestructor;
		classInfoP->canHavePersistent = NOT(wantDestructor);
		classInfoP->cloneObjects = wantClone;	//wantDestructor;
		classInfoP->id = classID;
		BAPI_NameFromClassID(api_data, classID, classInfoP->name);
		classInfoP->implem = implem;
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_FixedSize(long api_data, long classID, Boolean *fixedSize)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
PluginRecord	*plugRecP;
int				totClass;
XErr			err = noErr;

	if (classID > 0)
	{	totClass = gsDispatcherData.totClass;
		if (--classID < totClass)
		{	plugRecP = &gClassRecordBlockP[classID];
			*fixedSize = plugRecP->fixedSize;
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchClass);
	}
	else if (classID < 0)
		*fixedSize = true;
	else
		err = XError(kBAPI_Error, Err_NoSuchClass);
	
return err;
}

//===========================================================================================
void	BAPI_ClearParameterRec(long api_data, ParameterRec *paramP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	*(long*)paramP->name = 0;		// serve azzerare i primi quattro bytes nel caso del compil
	OBJ_ID(paramP->objRef) = 0;
	OBJ_CLASSID(paramP->objRef) = 0;
	paramP->privateData = 0;
	//paramP->expLen = 0;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_Log(long api_data, char *strLog)
{
BifernoRec	*bRecP;
XErr		err = noErr;
void		*taskID;
char		message[MAX_LOG_STRING+1];
LONGLONG	uID;
char		*appNameP, *sidP;

	if (bRecP = (BifernoRecP)api_data)
	{	taskID = bRecP->userData;
		uID = bRecP->uniqueID;
		sidP = bRecP->SID;
		appNameP = bRecP->application.name;
	}
	else
	{	taskID = 0;
		uID = 0;
		sidP = appNameP = nil;
	}
	CEquStrCK(message, strLog, MAX_LOG_STRING);
	CSubstitute(message, '\r', ' ');
	CSubstitute(message, '\n', ' ');
	LogFormatted(taskID, uID, sidP, message, appNameP);
	
return err;
}

//===========================================================================================
XErr	BAPI_StandardOutput(long api_data, char *textP, long len, Boolean useCustom)
{
BifernoRec	*bRecP;
XErr		err = noErr;
//long		savePrintFilterObjID;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if COMPILING(api_data)
		err = BIC_StandardOutput(api_data, textP, len);
	else
	{	if (bRecP->alternativeBuffer)
		{	if (bRecP->alternativeBuffer != -1)		// no output
				err = BufferAddText(bRecP->alternativeBuffer, textP, len, NO_ENC, 0);
		}
		else if (OBJ_ID(bRecP->pageOutObjRef))
		{	if (useCustom)
			{	
				//if (savePrintFilterObjID = bRecP->printFilterObjID)
				if (bRecP->printFilterDocBlock)
				{	
				ParameterRec	param;	
				//CStr63		saveFilterName;
				//BlockRef	membIdentBlock;
				//Boolean		exists;
				BlockRef		savePrintFilterDocBlock;
				MemberAction 	*membIdentP;
				
					BAPI_ClearParameterRec(api_data, &param);
					if NOT(err = BAPI_StringToObj(api_data, textP, len, &param.objRef))
					{	
						//CEquStr(saveFilterName, bRecP->printFilterName);
						//*bRecP->printFilterName = 0;
						//bRecP->printFilterObjID = 0;
						savePrintFilterDocBlock = bRecP->printFilterDocBlock;
						membIdentP = (MemberAction*)GetPtr(bRecP->printFilterDocBlock);
						bRecP->printFilterDocBlock = 0;
						err = CL_ExecuteFunction(api_data, membIdentP, nil, &param, 1, nil);
						bRecP->printFilterDocBlock = savePrintFilterDocBlock;
						//CEquStr(bRecP->printFilterName, saveFilterName);
						//bRecP->printFilterObjID = savePrintFilterObjID;
					}
				}
				else if NOT(bRecP->scriptIsLocal)
					err = page_Print(api_data, OBJREF_P(&bRecP->pageOutObjRef), textP, len);
			}
			else if NOT(bRecP->scriptIsLocal)
				err = page_Print(api_data, OBJREF_P(&bRecP->pageOutObjRef), textP, len);
			if NOT(err)
			{	if (bRecP->outputFunc)
					err = bRecP->outputFunc(bRecP->userData, textP, len);
			}
		}
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_SetCustomOutput(long api_data, char *functionName)
{
BifernoRec	*bRecP;
XErr		err = noErr;
//long		funcPlugID, funcID, funcObjID;
Boolean		exists;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
	if (NOT(err = GetFunctionInfo(api_data, nil, nil, functionName, &bRecP->printFilterDocBlock, &exists)) && exists)
	{	//bRecP->printFilterObjID = funcObjID;
		//CEquStr(bRecP->printFilterName, functionName);
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchFunction);

return err;
}

//===========================================================================================
XErr	BAPI_SetStandardOutput(long api_data)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	//bRecP->printFilterObjID = 0;
	//*bRecP->printFilterName = 0;
	if (bRecP->printFilterDocBlock)
	{	DisposeBlock(&bRecP->printFilterDocBlock);
		bRecP->printFilterDocBlock = 0;
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_GetOutputFunction(long api_data, char *funcName)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (bRecP->printFilterDocBlock)
	{	
	MemberAction 	*membIdentP;
	
		membIdentP = (MemberAction*)GetPtr(bRecP->printFilterDocBlock);
		CEquStr(funcName, membIdentP->doc.name);
	}
	else
		CEquStr(funcName, "print");

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_Exception(long api_data, long errType, long errNum, char *className, Boolean setClassException)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data, className, setClassException)
#endif

	return XError(errType, errNum);

/*XErr		err = noErr;
//BifernoRec	*bRecP;

	if (className && NOT(CCompareStrings(className, "error")))
	{	*className = 0;
		errType = kBAPI_Error;
	}
	if (bRecP = (BifernoRecP)api_data)
	{	//bRecP->exceptionError = XError(errType, errNum);
		//bRecP->exceptionLine = bRecP->currentCtx.currentLine;
		//if (setClassException)
		//	bRecP->exceptionErrorClassID = bRecP->methodInExecutionClass;
		if (className && *className)
		{	//if NOT(bRecP->exceptionClassID = BAPI_ClassIDFromName(api_data, className, false))
			//	err = XError(kBAPI_Error, Err_NoSuchClass);
			//else
				bRecP->lastClassIDErrorCalled = 0;	// reload it in _CallEntryPoint
		}
		//bRecP->errVarTableBlockValid = false;
	}
		
return err;*/
}

//===========================================================================================
/*XErr	BAPI_GetErrNum(long api_data, char *errName, char *errClass, long *errNumP)
{
XErr		err = noErr;
long		classID, tLen, objID;

	if (errClass && *errClass)
	{	if (classID = BAPI_ClassIDFromName(api_data, errClass))
			err = CL_GetErrNumber(api_data, classID, errName, errNumP);
	}
	else
	{	if (objID = DLM_GetObjID(gsDispatcherData.errorList, errName, nil, nil))
		{	tLen = sizeof(long);
			err = DLM_GetObj(gsDispatcherData.errorList, objID, (Ptr)errNumP, &tLen, 0, nil);
		}
	}

return err;
}*/

//===========================================================================================
XErr	BAPI_GetErrDescription(long api_data, XErr theError, char *eNameStr, char *classErrNotesP, char *errType, char *descr, Boolean *resumableP, long lastClassErrCalled, char *subErrStr)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	FillErrorStrings(api_data, lastClassErrCalled, theError, nil, eNameStr, errType, subErrStr, nil, descr, resumableP);
	bRecP = (BifernoRecP)api_data;
	if (classErrNotesP)
	{	if (*bRecP->class_error_note)
			CEquStr(classErrNotesP, bRecP->class_error_note);
		else
			*classErrNotesP = 0;
		if (errType && NOT(*errType))
		{	if (bRecP->lastClassIDErrorCalled)
				err = BAPI_NameFromClassID(api_data, bRecP->lastClassIDErrorCalled, errType);
			else
				*errType = 0;
		}
	}

return err;
}

//===========================================================================================
XErr	BAPI_NewMsgRecord(long api_data, char *title, char *msg, long msgLen, long flags)
{
	return NewMsgRecord(api_data, title, msg, msgLen, flags);
}

//===========================================================================================
static XErr	_GetTheLastMsgRecord(long api_data, char *title, char *msg)
{
XErr			err = noErr;
BifernoRec		*bRecP;
ErrorMsgRecord	*msgRecP;
ErrorMsgItem	*msgItemP;
int				totMsgRecord;//, i;

	if (bRecP = (BifernoRecP)api_data)
	{	msgRecP = &bRecP->errMessageRec;
		if (totMsgRecord = bRecP->errMessageRec.totMsg)
		{	msgItemP = &msgRecP->msg[0];
			CEquStr(title, msgItemP->title);
			CEquStr(msg, msgItemP->msg);
		}
		else
			*title = *msg = 0;
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetMessageRecords(long api_data, CStr63 *title, CStr255 *msg, long *totP, long max)
{
XErr	err = noErr;

	if (max >= 1)
	{	if NOT(err = _GetTheLastMsgRecord(api_data, *title, *msg))
		{	if (totP)
			{	if (**title)
					*totP = 1;	//GetTotMsgRecords(api_data);
				else
					*totP = 0;
			}
		}
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetErrorMsgRecord(long api_data, ErrorMsgRecord *msgRecordP, long *lastMultiStrLineP)
{
BifernoRecP		bRecP;

	if (api_data)
	{	bRecP = (BifernoRecP)api_data;
		if (msgRecordP)
			CopyBlock(msgRecordP, &bRecP->errMessageRec, sizeof(ErrorMsgRecord));
		if (lastMultiStrLineP)
		{	if (bRecP->currentCtx.lastMultiStrStart && bRecP->currentCtx.lastMultiStrEnd && (bRecP->currentCtx.lastMultiStrStart < bRecP->currentCtx.lastMultiStrEnd))
				*lastMultiStrLineP = bRecP->currentCtx.lastMultiStrStart;
			else
				*lastMultiStrLineP = 0;
		}
	}
	else
	{	if (msgRecordP)
			ClearBlock(msgRecordP, sizeof(ErrorMsgRecord));
		if (lastMultiStrLineP)
			*lastMultiStrLineP = 0;
	}
		
return noErr;
}

//===========================================================================================
XErr	BAPI_GetIncludeStack(long api_data, BlockRef *stackBlockP, long *totItemsP)
{
	XErr		err = noErr;
	BifernoRec	*bRecP;
	Ptr			sourceP, destP;
	long		tSize, tot;
	
	if ((bRecP = (BifernoRec*)api_data) && bRecP->includeStackBufferID && bRecP->includeStackPointer)
	{	
		BufferGetBlockRefExt(bRecP->includeStackBufferID, &sourceP);
		tot = bRecP->includeStackPointer;
		if (*stackBlockP = NewBlock(tSize = tot * sizeof(IncludeStackRecord), &err, &destP))
		{	
			CopyBlock(destP, sourceP, tSize);
			*totItemsP = tot;
		}
	}
	else
	{	*stackBlockP = 0;
		*totItemsP = 0;
	}
	return err;
}

//===========================================================================================
XErr	BAPI_GetStack(long api_data, BlockRef *stackBlockP, long *totItemsP, Boolean *stackFixedSize)
{
XErr		err = noErr;
BifernoRec	*bRecP;
Ptr			sourceP, destP;
long		tSize, tot;

	if ((bRecP = (BifernoRec*)api_data) && bRecP->stackBufferID && bRecP->stackPointer)
	{	
		BufferGetBlockRefExt(bRecP->stackBufferID, &sourceP);
		tot = bRecP->stackPointer;
		if (*stackBlockP = NewBlock(tSize = tot * sizeof(StackRecord), &err, &destP))
		{	
			CopyBlock(destP, sourceP, tSize);
			*totItemsP = tot;
		}
	}
	else
	{	*stackBlockP = 0;
		*totItemsP = 0;
	}
	if NOT(err)
		*stackFixedSize = gsDispatcherData.stackItemIsFixed;
	
return err;
}

//===========================================================================================
XErr	BAPI_GetHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, long lastClassErrCalled)
{
	return GetHtmlError(api_data, theError, errBlockP, sizeP, nil, lastClassErrCalled, nil, ISOLATIN_ENC, nil, false);
}

//===========================================================================================
XErr	BAPI_GetStatus(long api_data, BlockRef *fileLineBlockP, long *fileLineLengthP, BlockRef *statusBlockP, long *statusBlockLengthP, BlockRef *stackBlockP, long *stackBlockLengthP)
{	
long		size, id;
XErr		err = noErr;
BifernoRec	*bRecP;
//CStr255		scopeName;
Boolean		saveSuspendResume;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if (bRecP->criticalMem)
		return XError(kBAPI_Error, Err_MemoryFull);
	
	//if NOT(*bRecP->errCacheFileRec.filePath)
	//	bRecP->errCacheFileRec = bRecP->curFile;

	saveSuspendResume = bRecP->_suspendResume;
	bRecP->_suspendResume = true;
	if (fileLineBlockP)
	{	if (id = BufferCreate(255, &err))
		{	if NOT(bRecP->inEval)
			{	if (bRecP->currentCtx.methodInExecutionID && (bRecP->currentCtx.processing == kProcessingFunction) /*bRecP->errInFunction*/)
				{	BlockRef	bisFunctionBl;
					Ptr			p;
					//long		totalLen;
					BAPI_Doc	*docP;
					
					bisFunctionBl = 0;
					if (bRecP->currentCtx.methodInExecutionID == kConstrID)
					{	if NOT(err = GetContructorDoc(api_data, bRecP->methodInExecutionClass, &docP))
							p = (Ptr)docP;
					}
					else
					{	if NOT(err = GetBifernoFunctionRec(bRecP->currentCtx.curMethodList, bRecP->currentCtx.methodInExecutionID, &p, &bisFunctionBl, nil))
							docP = (BAPI_Doc*)GetPtr(bisFunctionBl);
					}
					
					if NOT(err)
					{	err = AddXLineOfFile(p + docP->len, docP->ident.b.funcLength/*totalLen - docP->len*/, bRecP->currentCtx.currentLine, id, ISOLATIN_ENC, 0);
						if (bisFunctionBl)
							DisposeBlock(&bisFunctionBl);
					}
				}
				else
					err = AddXLineOfFile(GetPtr(bRecP->curFile.fileData), bRecP->curFile.fileSize, bRecP->currentCtx.currentLine, id, ISOLATIN_ENC, 1);
			}
			if NOT(err)
			{	if NOT(err = BufferAddChar(id, 0))
				{	*fileLineBlockP = BufferGetBlockRef(id, &size);
					if (fileLineLengthP)
						*fileLineLengthP = size - 1;	// Added 0 final
					// SetBlockSize(*fileLineBlockP, size);
					BufferSetLength(id, size);
					BufferClose(id);
				}
				else
					BufferFree(id);
			}
			else
				BufferFree(id);
		}
	}
	if (NOT(err) && statusBlockP)
	{	
		err = LoadVariablesErrorTable(api_data, ISOLATIN_ENC, statusBlockP, statusBlockLengthP);
		/*long		nList, listID;
		int			i;
		CStr255		docUrl;
		
		if (id = BufferCreate(255, &err))
		{	nList = NUM_LIST - 1; 	// no temp
			GetDocUrl(api_data, docUrl);
			for (i = 0; (i < nList) && NOT(err); i++)
			{	if (err = GetVariableList(api_data, scope[i], &listID))
				{	listID = 0;
					err = noErr;
				}
				if (listID)
				{	if NOT(err = BAPI_ScopeName(api_data, scope[i], scopeName))
						err = FillVariableHTMLTable(api_data, listID, scope[i], scopeName, id, ISOLATIN_ENC, docUrl);
				}
			}		
			if NOT(err)
			{	if NOT(err = BufferAddChar(id, 0))
				{	*statusBlockP = BufferGetBlockRef(id, &size);
					//SetBlockSize(*statusBlockP, size);
					if (statusBlockLengthP)
						*statusBlockLengthP = size - 1;
					BufferSetLength(id, size);
					BufferClose(id);
				}
				else
					BufferFree(id);
			}
			else
				BufferFree(id);
		}*/
	}
	if (NOT(err) && stackBlockP)
	{	if (id = BufferCreate(255, &err))
		{	if NOT(err = PrintStack(bRecP, id))
			{	if NOT(err = BufferAddChar(id, 0))
				{	*stackBlockP = BufferGetBlockRef(id, &size);
					if (stackBlockLengthP)
						*stackBlockLengthP = size - 1;
				}
			}
			if (err)
				BufferFree(id);
			else
				BufferClose(id);
		}
	
	}
	bRecP->_suspendResume = saveSuspendResume;

return err;
}

//===========================================================================================
/*XErr	BAPI_SetError(long api_data, XErr *errP, long value)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)

	*errP = XError(kBAPI_ClassError, value);

return noErr;
}
*/
//===========================================================================================
XErr	BAPI_ScopeName(long api_data, long the_scope, char *scopeName)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	bRecP = (BifernoRecP)api_data;
	switch(the_scope)
	{
		case LOCAL:
			CEquStr(scopeName, "Local");
			break;
		case GLOBAL:
			CEquStr(scopeName, "Global");
			break;
		case APPLICATION:
			if (bRecP)
			{	CEquStr(scopeName, "Application (");
				if (bRecP->applicationInitFailed)
					CAddStr(scopeName, "?");
				else
					CAddStr(scopeName, bRecP->application.name);
				CAddChar(scopeName, ')');
			}
			else
				err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
			break;
		case SESSION:
			CEquStr(scopeName, "Session");
			if (bRecP)
			{	if (bRecP->SID)
				{	CAddStr(scopeName, " (SID = ");
					CAddStr(scopeName, bRecP->SID);
					CAddChar(scopeName, ')');
				}
			}
			else
				err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
			break;
		case PERSISTENT:
			CEquStr(scopeName, "Persistent");
			break;
		case TEMP:
			CEquStr(scopeName, "Volatile");
			break;
		default:
			CEquStr(scopeName, "unknown");
			break;
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_GetErrorStrings(long api_data, long *startErrP, BAPIErrorRecord **errorStringsP, long *totErrorsP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	// *errorStringsP = (Ptr)gBifernoErrorsStr;
	*errorStringsP = gBifernoErrorsRec;
	*startErrP = BIFERNO_BASE_ERROR;
	*totErrorsP = Err_LastErr - BIFERNO_BASE_ERROR;

return noErr;
}

#if __MWERKS__
#pragma mark-
#endif

/*#ifdef __MAC_XLIB__
	extern CStr63	gSysVersion, gMachineDescr;
#endif*/
//===========================================================================================
XErr	BAPI_GetCache(long api_data, BlockRef *infoBlockP, long *totItemsP, unsigned long *totalBytesInCacheP, Boolean *cacheFixedSizeP)
{
XErr			err = noErr;
BifernoRec		*bRecP = (BifernoRecP)api_data;
	
	if (bRecP)
	{	if (cacheFixedSizeP)
			*cacheFixedSizeP = gsDispatcherData.cacheItemIsFixed;
		*infoBlockP = 0;
		err = CFGetCacheInfo(infoBlockP, totItemsP, totalBytesInCacheP, bRecP->applicationObjID);
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
return err;
}

//===========================================================================================
/*XErr	BAPI_GetCache(long api_data, ObjRef *resultObjRefP, unsigned long *totalBytesInCacheP)
{
XErr			err = noErr;
long			totItems, i;
BlockRef 		cacheItemInfoBlock = 0;
BifernoRec		*bRecP = (BifernoRecP)api_data;
CacheItemInfoP	infosP;
ParameterRec	param[2];
ObjRef			objRefToAdd;
XFilePath		aCStr;
ObjRef			arTempObj;

	CHECK_RES(resultObjRefP)
	INVAL(arTempObj);
	if NOT(err = CFGetCacheInfo(&cacheItemInfoBlock, &totItems, totalBytesInCacheP, bRecP->applicationObjID))
	{	if NOT(err = BAPI_ArrayToObj(api_data, gsDispatcherData.cacheItemIsFixed, 0, nil, 0, nil, nil, &arTempObj))
		{	LockBlock(cacheItemInfoBlock);
			infosP = (CacheItemInfoP)GetPtr(cacheItemInfoBlock);
			*param[0].name = 0;
			param[0].expP = nil;
			param[0].expLen = 0;
			*param[1].name = 0;
			param[1].expP = nil;
			param[1].expLen = 0;
			for (i = 0; (i < totItems) && NOT(err); i++, infosP++)
			{	CEquStr(aCStr, "file:/");
				CAddStr(aCStr, infosP->path);
				INVAL(param[0].objRef);
				if NOT(err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), &param[0].objRef))
				{	INVAL(param[1].objRef);
					if NOT(err = BAPI_IntToObj(api_data, DONT_OPEN, &param[1].objRef))
					{	INVAL(objRefToAdd);
						if NOT(err = CL_Constructor(api_data, TEMP, VARIABLE, nil, gsDispatcherData.cacheItemConstructor, param, 2, OBJRECORD_P(&objRefToAdd)))
						{	err = BAPI_ArrayAddElement(api_data, &arTempObj, "", &objRefToAdd);
							// lo fa la BAPI_ArrayAddElement: if NOT()
							//	DLM_ObjTurnOnFlag(objRefToAdd.list, objRefToAdd.id, kNoDestructor, true);
						}
					}
				}
			}
			if NOT(err)
				err = _CopyResult(api_data, &arTempObj, resultObjRefP);
		}
		DisposeBlock(&cacheItemInfoBlock);
	}

return err;
}
*/
//===========================================================================================
XErr	BAPI_GetMaxUsers(long api_data, long *maxUsersP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	*maxUsersP = gMaxUsers;

return noErr;
}

//===========================================================================================
XErr	BAPI_GetPoolFactor(long api_data, long *poolFactorP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	*poolFactorP = gPoolFactor;

return noErr;
}

//===========================================================================================
XErr	BAPI_GetNumVersions(long api_data, unsigned long *version, unsigned long *versionBAPI, unsigned long *xlibVers)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;

	if (version)
		*version = CUR_BIFERNO_VERSION;
	if (versionBAPI)
		*versionBAPI = CUR_BIFERNO_API_VERSION;
	if (xlibVers)
		*xlibVers = CUR_XLIB_VERSION;
	/*
	if (xlibHelpersVersStr)
		VersionToString(CUR_XLIB_HELPERS_VERSION, xlibHelpersVersStr);
	*/

return err;
}

//===========================================================================================
XErr	BAPI_GetVersions(long api_data, char *versionStr, char *versionBAPIStr, char *xlibVersStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr	err = noErr;

	if (versionStr)
		VersionToString(CUR_BIFERNO_VERSION, versionStr, DEVELOPMENT_VERS_STR);	
	if (versionBAPIStr)
		VersionToString(CUR_BIFERNO_API_VERSION, versionBAPIStr, nil);	
	if (xlibVersStr)
		VersionToString(CUR_XLIB_VERSION, xlibVersStr, nil);	
	/*
	if (xlibHelpersVersStr)
		VersionToString(CUR_XLIB_HELPERS_VERSION, xlibHelpersVersStr);
	*/

return err;
}

//===========================================================================================
XErr	BAPI_GetServerUpSince(long api_data, ObjRef *timeObjP)
{	
	INVAL_P(timeObjP);
	return time_TimeRecToObjRef(api_data, &gUpSinceXDT, timeObjP);
}

//===========================================================================================
XErr	BAPI_GetBifernoHome(long api_data, XFilePathPtr homeStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
CStr255		appFolderPath;

	if NOT(err = XGetApplicationFolderPath(appFolderPath))
	{	CEquStr(homeStr, FILE_HD_PREFIX);
		CAddStr(homeStr, appFolderPath);
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_Platform(long api_data, char *cStr, char *compilationFlags, long strSize)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
CStr255	sysStr;
char	allCompFlags[1024];
XErr	err = noErr;

	#if __MAC_XLIB__
		CEquStr(cStr, "MacOS");
	#elif __UNIX_XLIB__
		CEquStr(cStr, "Unix");
	#elif __WIN_XLIB__
		CEquStr(cStr, "Windows");
	#endif

	CAddStr(cStr, ": ");
	XGetSysInfo(sysStr);
	CAddStr(cStr, sysStr);
	if (compilationFlags)
	{	*allCompFlags = 0;
		#ifdef __MAC_XLIB__
			CAddStr(allCompFlags, "__MAC_XLIB__ ");
		#endif
		#ifdef __UNIX_XLIB__
			CAddStr(allCompFlags, "__UNIX_XLIB__ ");
		#endif
		#ifdef __WIN_XLIB__
			CAddStr(allCompFlags, "__WIN_XLIB__ ");
		#endif
		#ifdef __BIG_ENDIAN__
			CAddStr(allCompFlags, "__BIG_ENDIAN__ ");
		#endif
		#ifdef __LITTLE_ENDIAN__
			CAddStr(allCompFlags, "__LITTLE_ENDIAN__ ");
		#endif
		#ifdef __MAC_ACGI__
			CAddStr(allCompFlags, "__MAC_ACGI__ ");
		#endif
		#ifdef __MAC_WSAPI__
			CAddStr(allCompFlags, "__MAC_WSAPI__ ");
		#endif
		#ifdef __MEM_CANMOVE__
			CAddStr(allCompFlags, "__MEM_CANMOVE__ ");
		#endif
		#ifdef MODULE_FULL
			CAddStr(allCompFlags, "MODULE_FULL ");
		#endif
		#ifdef __XLIB_WITH_HELPERS__
			CAddStr(allCompFlags, "__XLIB_WITH_HELPERS__ ");
		#endif
		#ifdef __XLIB_CLIENT__
			CAddStr(allCompFlags, "__XLIB_CLIENT__ ");
		#endif
		//#ifdef JAVA_ENABLED
		//	CAddStr(allCompFlags, "JAVA_ENABLED ");
		//#endif
		#ifdef MEM_DEBUG
			CAddStr(allCompFlags, "MEM_DEBUG ");
		#endif
		#ifdef CHECK_LEAKING
			CAddStr(allCompFlags, "CHECK_LEAKING ");
		#endif
		#ifdef MEM_DEBUG_DUMP_LEAK
			CAddStr(allCompFlags, "MEM_DEBUG_DUMP_LEAK ");
		#endif
		#ifdef WITH_MACSBUG
			CAddStr(allCompFlags, "WITH_MACSBUG ");
		#endif
		#ifdef MEM_DEBUG_ALWAYS_REALLOC
			CAddStr(allCompFlags, "MEM_DEBUG_ALWAYS_REALLOC ");
		#endif
		#ifdef PROFILE_ACTIVE
			CAddStr(allCompFlags, "PROFILE_ACTIVE ");
		#endif
		#ifdef ON_ERROR_EXIT
			CAddStr(allCompFlags, "ON_ERROR_EXIT ");
		#endif
		#ifdef DEBUG_TRACE
			CAddStr(allCompFlags, "DEBUG_TRACE ");
		#endif
		#ifdef NUM_STRING_TYPECAST_EXPLICIT
			CAddStr(allCompFlags, "NUM_STRING_TYPECAST_EXPLICIT ");
		#endif
		#ifdef MYSQL_BUILT_IN
			CAddStr(allCompFlags, "MYSQL_BUILT_IN ");
		#endif
		#ifdef WITH_SENDMAIL
			CAddStr(allCompFlags, "WITH_SENDMAIL ");
		#endif
		#ifdef ODBC_BUILT_IN
			CAddStr(allCompFlags, "ODBC_BUILT_IN ");
		#endif
		#ifdef POSTGRES_BUILT_IN
			CAddStr(allCompFlags, "POSTGRES_BUILT_IN ");
		#endif
		#ifdef CONVERTIMAGE_BUILT_IN
			CAddStr(allCompFlags, "CONVERTIMAGE_BUILT_IN ");
		#endif
		#ifdef WITH_OPENDIR
			CAddStr(allCompFlags, "WITH_OPENDIR ");
		#endif
		#ifdef TARGET_API_MAC_CARBON
			CAddStr(allCompFlags, "TARGET_API_MAC_CARBON ");
		#endif
		
		// Compilator
		#ifdef PRJBUILDER
			CAddStr(allCompFlags, "PRJBUILDER ");
		#endif
		#ifdef __MWERKS__
			CAddStr(allCompFlags, "__MWERKS__ ");
		#endif
		#ifdef __VISUALCPP__
			CAddStr(allCompFlags, "__VISUALCPP__ ");
		#endif
		
		#ifdef __USE_CARBON_FRAMEWORK__
			CAddStr(allCompFlags, "__USE_CARBON_FRAMEWORK__ ");
		#endif
		if (strSize < (CLen(allCompFlags) + 1))
			err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
		else
			CEquStr(compilationFlags, allCompFlags);
	}

return err;
}

//===========================================================================================
XErr	BAPI_Flush(long api_data)
{
XErr			err = noErr;
BifernoRecP		bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
		bRecP->flushAll = true;
	
return err;
}

//===========================================================================================
/*XErr	BAPI_Reload(long api_data)
{
XErr			err = noErr;
BifernoRecP		bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
		bRecP->reloadAll = true;
	
return err;
}*/

//===========================================================================================
XErr	BAPI_FlushAppFiles(long api_data)
{
XErr			err = noErr;
BifernoRecP		bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
		bRecP->flushApp = true;
	
return err;
}

//===========================================================================================
XErr	BAPI_FlushFile(long api_data, XFilePathPtr path)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
XFilePath	tempStr;
long		pathLen;

	pathLen = CLen(path);
	if NOT(pathLen)
		return XError(kBAPI_Error, Err_FileNotFound);
	if ((pathLen > 6) && NOT(CompareBlock(path, "file://", 7)))
		CEquStr(path, path + 6);
	else
	{
	Boolean		fromRoot;
	
		if (*path == '/')
			fromRoot = true;
		else
			fromRoot = false;
		if NOT(err = BAPI_GetCurrentBasePath(api_data, tempStr, fromRoot))
		{	if (fromRoot)
				CAddStr(tempStr, path + 1);		// remove '/'
			else
				CAddStr(tempStr, path);
			CEquStr(path, tempStr);
		}
	}
	if NOT(err)
		err = CFFlushFile(path);
	
return err;
}

//===========================================================================================
XErr	BAPI_ReloadApp(long api_data)
{
XErr			err = noErr;
BifernoRecP		bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
		bRecP->closeApp = true;
		
return err;
}

//===========================================================================================
XErr	BAPI_RegisterApplication(long api_data, char *applicationName, XFilePathPtr applicationPath)
{
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
void			*userData;

	if (NOT(bRecP) || CCompareStrings_cs(applicationName, bRecP->application.name))
	{	if NOT(err = BAPI_RealPath(api_data, applicationPath, true))
		{	if (bRecP)
				userData = bRecP->userData;
			else
				userData = 0;
			err = RegisterApplication(applicationName, applicationPath, nil, nil, false, userData);
		}
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_GetGenericAppInfo(long api_data, char *appName, char *appHome)
{
XErr			err = noErr;
long			tLen, appObjId;
DLMRef			app_list;
Application 	applRec;

	app_list = gsDispatcherData.globApplicationListArray;
	if (appObjId = DLM_GetObjID(app_list, appName, nil, nil))
	{
		tLen = sizeof(Application);
		if NOT(err = DLM_GetObj(app_list, appObjId, (Ptr)&applRec, &tLen, 0, nil))
		{
			CEquStr(appHome, applRec.basePath);
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchApplication);

return err;
}

//===========================================================================================
XErr	BAPI_GetCurrentAppInfo(long api_data, char *name, char *home)
{
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;

	if NOT(bRecP)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (name)
		CEquStr(name, bRecP->application.name);
	if (home)
		CEquStr(home, bRecP->application.basePath);

return err;
}

//===========================================================================================
XErr	BAPI_GetApplications(long api_data, BlockRef *appsArrayBlockP, long *totAppsP, long index)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
int				k;
long			tLen, totObjs;
DLMRef			app_list;
Application 	applRec;
BlockRef		blockRef;
BAPI_Name		*nameRecP, *tempRecP;

	blockRef = 0;
	app_list = gsDispatcherData.globApplicationListArray;
	if (NOT(err = DLM_GetTotObjs(app_list, &totObjs, false)) && totObjs)
	{	if (index)
		{	if ((index < 0) || (index > totObjs))
				err = XError(kBAPI_Error, Err_OutOfBoundary);
			else
			{	if (blockRef = NewBlock(sizeof(BAPI_Name), &err, (Ptr*)&nameRecP))
				{	tLen = sizeof(Application);
					if NOT(err = DLM_GetIndObj(app_list, index, (Ptr)&applRec, &tLen, 0, nil, nil, nil, true, false))
					{	CEquStr(nameRecP->name, applRec.name);	//err = BAPI_StringToObj(api_data, applRec.name, CLen(applRec.name), result);
						totObjs = 1;
					}
				}
			}
		}
		else
		{	if (blockRef = NewBlockLocked(totObjs * sizeof(BAPI_Name), &err, (Ptr*)&nameRecP))
			{	tempRecP = nameRecP;
				for (k = 0; (k < totObjs) && NOT(err); k++, tempRecP++)
				{	tLen = sizeof(Application);
					if NOT(err = DLM_GetIndObj(app_list, k+1, (Ptr)&applRec, &tLen, 0, nil, nil, nil, true, false))
						CEquStr(tempRecP->name, applRec.name);
				}
				//if NOT(err)
				//	_Bubble(nameRecP, totObjs);
			}
		}
	}

if (err)
{	if (blockRef)
		DisposeBlock(&blockRef);
}
else
{	*appsArrayBlockP = blockRef;
	*totAppsP = totObjs;
}
return err;
}

//===========================================================================================
XErr	BAPI_GetAppChildren(long api_data, char *applicationName, BlockRef *childrenArrayBlockP, long *totChildrenP, long index)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
int				i;
BAPI_Name		*nameRecP;
BlockRef		blockRef;
Application 	*applP;
BlockRef		appBlock = 0;
Boolean			all, cs;
DLMRef			app_list;
long			totChildren, tidx, size, tLen, totObjs;
Application 	applRec;
CStr255			homeStr;

#ifdef __UNIX_XLIB__
	cs = true;
#else
	cs = false;
#endif

	blockRef = 0;	
	if (applicationName && *applicationName)
	{	if NOT(err = GetApplicationBlock(applicationName, &appBlock))
		{	LockBlock(appBlock);
			applP = (Application*)GetPtr(appBlock);
			app_list = gsDispatcherData.globApplicationListArray;
			if (NOT(err = DLM_GetTotObjs(app_list, &totObjs, false)) && totObjs)
			{	if (index)
					size = sizeof(BAPI_Name);
				else
					size = sizeof(BAPI_Name) * totObjs;
				blockRef = NewBlockLocked(size, &err, (Ptr*)&nameRecP);
				if NOT(err)
				{	tidx = 1;
					totChildren = 0;
					XGetApplicationFolderPath(homeStr);
					all = NOT(ComparePaths(applP->basePath, homeStr));
					for (i = 1; (i <= totObjs) && NOT(err); i++)
					{	tLen = sizeof(Application);
						if NOT(err = DLM_GetIndObj(app_list, i, (Ptr)&applRec, &tLen, 0, nil, nil, nil, false, false))
						{	if ((all || CBegins(applRec.basePath, applP->basePath, cs)) && ComparePaths(applRec.basePath, applP->basePath))
							{	if (index)
								{	if (tidx == index)
										CEquStr(nameRecP->name, applRec.name);
								}
								else
								{	CEquStr(nameRecP->name, applRec.name);
									nameRecP++;
								}
								totChildren++;
								tidx++;
							}
						}
					}
				}
			}
			DisposeBlock(&appBlock);
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchApplication);

if (NOT(err) && index)
{	if ((index <= 0) || (index > totChildren))
		err = XError(kBAPI_Error, Err_OutOfBoundary);
}
if (err)
{	if (blockRef)
		DisposeBlock(&blockRef);
}
else
{	if (index)
		*totChildrenP = 1;
	else
		*totChildrenP = totChildren;
	*childrenArrayBlockP = blockRef;
}
return err;
}

//===========================================================================================
XErr	BAPI_GetClasses(long api_data, char *applicationName, BlockRef *classesArrayBlockP, long *totClassesP, long index)
{
PluginRecord	*plugRecP;
XErr			err = noErr;
long			totClass;
int				i;
BAPI_Name		*tNameRecP, *nameRecP;
BlockRef		blockRef;

	blockRef = 0;	
	if (applicationName && *applicationName)
	{	Application 	*applP;
		BifernoRecP		bRecP;
		BlockRef		appBlock = 0;
		
		if (*applicationName)
		{	if NOT(err = GetApplicationBlock(applicationName, &appBlock))
			{	LockBlock(appBlock);
				applP = (Application*)GetPtr(appBlock);
			}
		}
		else
		{	if NOT(bRecP = (BifernoRecP)api_data)
				err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
			else
				applP = &bRecP->application;
		}
		if NOT(err)
		{	DLMRef	list = applP->classList;
			CStr63	className;
			
			if (NOT(err = DLM_GetTotObjs(list, &totClass, false)) && totClass)
			{	if (index)
				{	if ((index > 0) && (index <= totClass))
					{	if (blockRef = NewBlockLocked(sizeof(BAPI_Name), &err, (Ptr*)&nameRecP))
						{	if NOT(err = DLM_GetIndObj(list, index, nil, nil, 0, nil, nil, className, true, false))
							{	CEquStr(nameRecP->name, className);
								totClass = 1;
							}
						}
					}
					else
						err = XError(kBAPI_Error, Err_OutOfBoundary);
				}
				else
				{	if (blockRef = NewBlockLocked(totClass * sizeof(BAPI_Name), &err, (Ptr*)&nameRecP))
					{	tNameRecP = nameRecP;
						for (i = 1; i <= totClass; i++, tNameRecP++)
						{	if NOT(err = DLM_GetIndObj(list, i, nil, nil, 0, nil, nil, className, true, false))
								CEquStr(tNameRecP->name, className);
						}
					}
				}
			}
		}
		if (appBlock)
			DisposeBlock(&appBlock);
	}
	else
	{	
	long	realTotClass;
	
		totClass = gsDispatcherData.totClass;
		if (blockRef = NewBlockLocked(totClass * sizeof(BAPI_Name), &err, (Ptr*)&nameRecP))
		{	realTotClass = 0;
			tNameRecP = nameRecP;
			for (i = 0; i < totClass; i++)
			{	if ((plugRecP = &gClassRecordBlockP[i]) && plugRecP->successfull && (plugRecP->pluginType == kNewClassPlugin))
				{	CEquStr(tNameRecP->name, plugRecP->pluginName);
					tNameRecP++;
					realTotClass++;
				}
			}
			totClass = realTotClass;
		}
	}

if (err)
{	if (blockRef)
		DisposeBlock(&blockRef);
}
else
{	if (blockRef)
	{	_Bubble(nameRecP, totClass);
		if (index)
		{	if (totClass > 1)
				CEquStr(nameRecP->name, nameRecP[index-1].name);
			*totClassesP = 1;
		}
		else
			*totClassesP = totClass;
	}
	else
		*totClassesP = 0;
	*classesArrayBlockP = blockRef;
}
return err;
}

//===========================================================================================
/*XErr	BAPI_GetClasses(long api_data, char *applicationName, ObjRefP resultArray)
{
PluginRecord	*plugRecP;
XErr			err = noErr;
long			actSize, totClass;
int				k, i;
BAPI_Name		*membP;
BlockRef		blockRef;
ObjRef			arTempObj;

	INVAL(arTempObj);
	CHECK_RES(resultArray)

	totClass = gsDispatcherData.totClass;
	actSize = _1Block;
	k = 0;
	if (blockRef = NewBlock(sizeof(MembStruct) * actSize, &err, (Ptr*)&membP))
	{	//membP = (MembStruct*)GetPtr(blockRef);
		if (applicationName && *applicationName)
		{	Application 	*applP;
			BifernoRecP		bRecP;
			BlockRef		appBlock = 0;
			
			if (*applicationName)
			{	if NOT(err = GetApplicationBlock(applicationName, &appBlock))
				{	LockBlock(appBlock);
					applP = (Application*)GetPtr(appBlock);
				}
			}
			else
			{	if NOT(bRecP = (BifernoRecP)api_data)
					err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
				else
					applP = &bRecP->application;
			}
			if NOT(err)
			{	DLMRef	list = applP->classList;
				CStr63	className;
				
				if NOT(err = DLM_GetTotObjs(list, &totClass, false))
				{	for (i = 1; i <= totClass; i++)
					{	if NOT(err = DLM_GetIndObj(list, i, nil, nil, 0, nil, nil, className, true, false))
						{	if (k >= actSize)
							{	actSize += _1Block;
								err = SetBlockSize(blockRef, sizeof(MembStruct) * actSize);
								//if (err)
								//	CEquStr(globalErrStr, "in BAPI_GetClasses (1)");
								membP = (MembStruct*)GetPtr(blockRef);
							}
							if NOT(err)
							{	CEquStr(membP[k].name, className);
								k++;
							}
						}
					}
				}
			}
			if (appBlock)
				DisposeBlock(&appBlock);
		}
		else
		{	for (i = 0; i < totClass; i++)
			{	if ((plugRecP = &gClassRecordBlockP[i]) && plugRecP->successfull)
				{	if (plugRecP->pluginType == kNewClassPlugin)
					{	if (k >= actSize)
						{	actSize += _1Block;
							err = SetBlockSize(blockRef, sizeof(MembStruct) * actSize);
							//if (err)
							//	CEquStr(globalErrStr, "in BAPI_GetClasses (1)");
							membP = (MembStruct*)GetPtr(blockRef);
						}
						if NOT(err)
						{	CEquStr(membP[k].name, plugRecP->pluginName);
							k++;
						}
					}
				}
			}
		}
		if NOT(err)
		{	_Bubble(&membP[0], k);
			
			if NOT(err = BAPI_ArrayToObj(api_data, false, 0, nil, 0, nil, nil, &arTempObj))
			{	ObjRef	tObjRef;
			
				LockBlock(blockRef);
				membP = (MembStruct*)GetPtr(blockRef);
				for (i = 0; (i < k) && NOT(err); i++)
				{	INVAL(tObjRef);
					if NOT(err = BAPI_StringToObj(api_data, membP[i].name, CLen(membP[i].name), &tObjRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, nil, &tObjRef);
				}
				if NOT(err)
					err = _CopyResult(api_data, &arTempObj, resultArray);
			}
		}
		DisposeBlock(&blockRef);
	}
	
return err;
}
*/

//===========================================================================================
/*static XErr	_GetApplicationFunctions(long api_data, BlockRef *blockP, long *lenP, char *separator, char *applicationName)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
PluginRecord	*plugRecP = nil;
XErr			err = noErr;
long			actSize, k, id, totClass;
int				i;
MembStruct		*membP;
DLMRef			list = 0;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Application 	*applP;
BlockRef		blockRef, appBlock = 0;
		
	actSize = _1Block;
	k = 0;
	if (applicationName && *applicationName)
	{	if NOT(err = GetApplicationBlock(applicationName, &appBlock))
		{	LockBlock(appBlock);
			applP = (Application*)GetPtr(appBlock);
		}
	}
	else
	{	if NOT(bRecP = (BifernoRecP)api_data)
			err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
		else
			applP = &bRecP->application;
	}
	if NOT(err)
	{	if (blockRef = NewBlockLocked(sizeof(MembStruct) * actSize, &err, (Ptr*)&membP))
		{	DLMRef	list = applP->funcsList;
			CStr63	funcName;
			
			//LockBlock(blockRef);
			//membP = (MembStruct*)GetPtr(blockRef);
			if NOT(err = DLM_GetTotObjs(list, &totClass, false))
			{	for (i = 1; i <= totClass; i++)
				{	if NOT(err = DLM_GetIndObj(list, i, nil, nil, 0, nil, nil, funcName, true, false))
					{	if (k >= actSize)
						{	actSize += _1Block;
							err = SetBlockSize(blockRef, sizeof(MembStruct) * actSize);
							//if (err)
							//	CEquStr(globalErrStr, "in BAPI_GetApplicationFunctions (1)");
							membP = (MembStruct*)GetPtr(blockRef);
						}
						if NOT(err)
						{	CEquStr(membP[k].name, funcName);
							k++;
						}
					}
				}
			}
			if NOT(err)
			{	_Bubble(&membP[0], k);	
				if (id = BufferCreate(512, &err))
				{	LockBlock(blockRef);
					membP = (MembStruct*)GetPtr(blockRef);
					for (i = 0; (i < k) && NOT(err); i++)
					{	if NOT(err = BufferAddCString(id, membP[i].name, NO_ENC, 0))
						{	if (i != k-1)
								err = BufferAddCString(id, separator, NO_ENC, 0);
						}
					}
					if NOT(err)
					{	*blockP = BufferGetBlockRef(id, lenP);
						BufferClose(id);
					}
					else
						BufferFree(id);
				}
			}
			DisposeBlock(&blockRef);
		}
	}
	if (appBlock)
		DisposeBlock(&appBlock);

	
return err;
}
*/
//===========================================================================================
XErr	BAPI_GetMembers(long api_data, char *applicationName, char *className, long which, BlockRef *membersArrayBlockP, long *totMembersP, long index)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
PluginRecord	*plugRecP = nil;
XErr			err = noErr;
long			totItems;
int				classID = 0;
//BAPI_Name		*membP;
BlockRef		blockRef;
DLMRef			list = 0;
BifernoRecP		bRecP = (BifernoRecP)api_data;
BifernoClass	bifernoClass;

	blockRef = 0;
	if (which != kFunction)
	{	if (className)
		{	if NOT(classID = BAPI_ClassIDFromName(api_data, className, false))
				return XError(kBAPI_Error, Err_NoSuchClass);
			if (classID > 0)
				plugRecP = &gClassRecordBlockP[classID-1];
			else
			{	plugRecP = nil;
				err = GetBifernoClassRec(bRecP, -classID, &bifernoClass);
			}
		}
	}
	if NOT(err)
	{	//totClass = gsDispatcherData.totClass;
		switch(which)
		{
			case kMethod:
				if (classID)
				{	if (plugRecP)
						list = plugRecP->membersList;
					else
						list = bifernoClass.methods;
				}
				else
					err = XError(kBAPI_Error, Err_NoSuchClass);
				break;
			case kProperty:
			case kConstant:
			case kError:
				if (classID)
				{	if (plugRecP)
						list = plugRecP->membersList;
					else
						list = bifernoClass.properties;
				}
				else
					err = XError(kBAPI_Error, Err_NoSuchClass);
				break;
			case kFunction:
				if (applicationName && *applicationName)
				{	Application 	*applP;
					BlockRef		appBlock = 0;
					
					if NOT(err = GetApplicationBlock(applicationName, &appBlock))
					{	applP = (Application*)GetPtr(appBlock);
						list = applP->funcsList;
						DisposeBlock(&appBlock);
					}
				}
				else
					list = gsDispatcherData.functionsList;
				break;
			default:
				err = XError(kBAPI_Error, Err_BadSyntax); 
				break;
		}
		if NOT(err)
		{	//if (plugRecP || isFunc)
			err = _AddMembers(list, &blockRef, &totItems, which, index);
			//else
			//	err = _AddBifernoMembers(nil, list, &blockRef, &actSize, which, index);
			/*if NOT(err)
			{	membP = (BAPI_Name*)GetPtr(blockRef);		// reload
				_Bubble(&membP[0], totItems);	
			}*/
		}
	}
	
if (err)
{	if (blockRef)
		DisposeBlock(&blockRef);
}
else
{	*membersArrayBlockP = blockRef;
	*totMembersP = totItems;
}
return err;
}

//===========================================================================================
/*XErr	BAPI_GetPrototype(long api_data, char *funcName, char *prototype, long maxStorage)
{
XErr			err = noErr;
PluginRecord	*plugRecP = nil;
Boolean			res;
long			tLen, textLen, fLen, theObjID, thePluginID;
CStr255			the_prototype, tempStr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
BifernoClass	bifernoClass;
MemberRecord	membRec;
BifernoProperty	bifernoProp;
long			arrayLevel = 0;

	fLen = CLen(funcName);
	if (res = FindStringInText(".", 1, funcName, fLen, nil, true, false))
	{	if NOT(err = GetEntityName(api_data, &funcName, &fLen, tempStr, false))
		{	funcName++;
			fLen--;
			if (thePluginID = BAPI_ClassIDFromName(api_data, tempStr, false))
			{	if (thePluginID > 0)
				{	plugRecP = &gClassRecordBlockP[thePluginID-1];
					if (theObjID = DLM_GetObjID(plugRecP->membersList, funcName, nil, nil))
					{	tLen = sizeof(MemberRecord);
						if NOT(err = DLM_GetObj(plugRecP->membersList, theObjID, (Ptr)&membRec, &tLen, 0, nil))
						{	arrayLevel = membRec.memberHeader.returnAeLevel;
							if ((arrayLevel == MAX_ARRAY_LEVEL) && (membRec.memberHeader.classID == gsDispatcherData.arrayConstructor))
								arrayLevel = 0;
							textLen = CLen(membRec.prototype);
							if (textLen < maxStorage)
							{	CopyBlock(prototype, membRec.prototype, textLen);
								prototype[textLen] = 0;
							}
							else
								err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
						}
					}
					else
					{	NewMsgRecord(api_data, kMEMBER_BAD, funcName, 0, 0);
						//CStringToErrMessage(api_data, funcName);
						err = XError(kBAPI_Error, Err_NoSuchMember);
					}
				}
				else
				{
				biferno_class:
					plugRecP = nil;
					if NOT(err = GetBifernoClassRec(bRecP, -thePluginID, &bifernoClass))
					{	if (theObjID = DLM_GetObjID(bifernoClass.methods, funcName, nil, nil))
						{	tLen = 256;
							if NOT(err = DLM_GetObj(bifernoClass.methods, theObjID, (Ptr)the_prototype, &tLen, offsetof(BifernoFunc, prototype)+1, nil))
							{	textLen = CLen(the_prototype);
								if (textLen < maxStorage)
								{	CopyBlock(prototype, the_prototype, textLen);
									prototype[textLen] = 0;
								}
								else
									err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
							}
						}
						else if (theObjID = DLM_GetObjID(bifernoClass.properties, funcName, nil, nil))
						{	tLen = sizeof(BifernoProperty);
							if NOT(err = DLM_GetObj(bifernoClass.properties, theObjID, (Ptr)&bifernoProp, &tLen, 0, nil))
							{	arrayLevel = bifernoProp.header.arrayLevel;
								if ((arrayLevel == MAX_ARRAY_LEVEL) && (bifernoProp.classID == gsDispatcherData.arrayConstructor))
									arrayLevel = 0;
								textLen = CLen(bifernoProp.prototype);
								if (textLen < maxStorage)
								{	CopyBlock(prototype, bifernoProp.prototype, textLen);
									prototype[textLen] = 0;
								}
								else
									err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
							}
						}
						else
						{	if NOT(CCompareStrings_cs(funcName, bifernoClass.className))	// is constructor
								*prototype = 0;
							else
							{	NewMsgRecord(api_data, kMEMBER_BAD, funcName, 0, 0);
								//CStringToErrMessage(api_data, funcName);
								err = XError(kBAPI_Error, Err_NoSuchMember);
							}
						}
					}
				}
			}
			else
			{	//CStringToErrMessage(api_data, tempStr);
				NewMsgRecord(api_data, kCLASS_BAD, funcName, 0, 0);
				err = XError(kBAPI_Error, Err_NoSuchClass);
			}
		}
	}
	else
	{	Ptr				textP;
		
		if (thePluginID = BAPI_ClassIDFromName(api_data, funcName, false))
		{	if (thePluginID > 0)
			{	plugRecP = &gClassRecordBlockP[thePluginID-1];
				textP = plugRecP->constructor.prototype;
				textLen = CLen(textP);
			}
			else
				goto biferno_class;
		}
		else if (theObjID = DLM_GetObjID(gsDispatcherData.functionsList, funcName, nil, nil))
		{	tLen = sizeof(membRec);
			if NOT(err = DLM_GetObj(gsDispatcherData.functionsList, theObjID, (Ptr)&membRec, &tLen, 0, nil))
			{	textP = membRec.prototype;
				textLen = CLen(membRec.prototype);
			}
		}
		else if (theObjID = DLM_GetObjID(bRecP->application.funcsList, funcName, nil, nil))
		{	tLen = 255;
			if NOT(err = DLM_GetObj(bRecP->application.funcsList, theObjID, (Ptr)the_prototype, &tLen, offsetof(BifernoFunc, prototype)+1, nil))
			{	textLen = CLen(the_prototype);
				textP = the_prototype;
			}
		}
		else
		{	NewMsgRecord(api_data, kFUNCTION_BAD, funcName, 0, 0);
			//CStringToErrMessage(api_data, funcName);
			err = XError(kBAPI_Error, Err_NoSuchFunction);
		}
		if NOT(err)
		{	if (textLen < maxStorage)
			{	CopyBlock(prototype, textP, textLen);
				prototype[textLen] = 0;
			}
			else
				err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
		}
	}
	if NOT(err)
	{	if (arrayLevel)
		{	if ((textLen + (2*arrayLevel)) < maxStorage)
			{	while (arrayLevel--)
					CAddStr(prototype, "[]");
			}
			else
				err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
		}
	}
	
return err;
}
*/
//===========================================================================================
/*
XErr	BAPI_GetInfo(long api_data, char *name, long which, ObjRef *arrayObjRefP)
{
XErr			err = noErr, err2 = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
long			returnClassID = 0, totParamsInProto = 0, funcID, fLen, funcObjID = 0, funcPlugID = 0, classID = 0;
CStr255			prototype, className;
Boolean			res;
BlockRef		protoParamBlock = nil;
ProtoParam		*protoParamP = nil;
Boolean			dontCheckNumParams, dontCheckNames, isStatic = false, isConstant = false, isConstr = false, isProp = false;
int				i;
Byte			visibility = kPublic;
CStr63			returnArrayLevel, returnArrayClass, visStr, returnClass;
ObjRef			arTempObj;

	INVAL(arTempObj);
	CHECK_RES(arrayObjRefP)
	
	CEquStr(returnArrayLevel, "0");
	CEquStr(returnArrayClass, "0");
	*className = 0;
	*visStr = 0;
	*returnClass = 0;
	dontCheckNumParams = dontCheckNames = false;
	if NOT(bRecP)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	fLen = CLen(name);
	if (res = FindStringInText(".", 1, name, fLen, nil, true, false))
	{	if NOT(err = GetEntityName(api_data, &name, &fLen, className, false))
		{	name++;
			fLen--;
			classID = BAPI_ClassIDFromName(api_data, className, false);
		}
	}
	else
	{	if NOT(classID = BAPI_ClassIDFromName(api_data, name, false))
			*className = 0;
		else
		{	CEquStr(className, name);	// Is constructor
			isConstr = true;
		}
	}
	
	if NOT(err)
	{	if (*className)	// is method
		{	MemberIdentification	membIdent;
			SuperIsChangedNotify 	*notifyP = nil;
			Boolean					memberExists;
			int						followChar;
			
			if (isConstr || NOT(which))
			{	
				err = GetProtoBlock(api_data, classID, 0, classID > 0, &protoParamBlock, &protoParamP, &totParamsInProto, prototype, &dontCheckNumParams, &dontCheckNames, true, nil, nil, &isStatic);
			}
			else
			{	ClearBlock(&membIdent, sizeof(MemberIdentification));
				CEquStr(membIdent.memberName, name);
				membIdent.memberType = which;
				if (which == kProperty)
				{	followChar = 0;	// ex  = '(';
					err = GetMemberInfo(api_data, classID, nil, &membIdent, followChar, &memberExists, false, &notifyP, true);
				}
				else
				{	followChar = '('; // ex = 0;
					err = GetMemberInfo(api_data, classID, nil, &membIdent, followChar, &memberExists, false, &notifyP, true);
				}
				if NOT(err)
				{	if (memberExists)
					{	if (membIdent.memberType == kProperty)
						{	isProp = true;
							if NOT(err = BAPI_NameFromClassID(api_data, membIdent.memberClassID, returnClass))
							{	CEquStr(prototype, returnClass);
								isConstant = membIdent.memberIsConstant;
								visibility = membIdent.memberVisibility;
								CNumToString(membIdent.memberArrayLevel, returnArrayLevel);
								CNumToString(membIdent.memberArrayElementClassID, returnArrayClass);
								
							}
						}
						else
						{	if NOT(err = GetProtoBlock(api_data, membIdent.memberClassID, membIdent.memberObjID, classID < 0, &protoParamBlock, &protoParamP, &totParamsInProto, prototype, &dontCheckNumParams, &dontCheckNames, false, &returnClassID, &visibility, nil))
							{	if (returnClassID)
									err = BAPI_NameFromClassID(api_data, returnClassID, returnClass);
							}
						}
						if NOT(err)
						{	if (visibility == kPublic)
								CEquStr(visStr, "public");
							else if (visibility == kPrivate)
								CEquStr(visStr, "private");
							else if (visibility == kProtected)
								CEquStr(visStr, "protected");
							isStatic = membIdent.memberIsStatic;
						}
					}
					else
						err = XError(kBAPI_Error, Err_NoSuchMember);
				}
			}
		}
		else
		{	if (funcPlugID = GetFunctionInfo(api_data, nil, nil, name, &funcID, &funcObjID))
			{	Boolean isBiferno = (funcPlugID == -1);
			
				if NOT(err = GetProtoBlock(api_data, 0, funcObjID, isBiferno, &protoParamBlock, &protoParamP, &totParamsInProto, prototype, &dontCheckNumParams, &dontCheckNames, false, &returnClassID, nil, nil))
				{	if (returnClassID)
						err = BAPI_NameFromClassID(api_data, returnClassID, returnClass);
				}					
			}
			else
				err = XError(kBAPI_Error, Err_NoSuchClassOrFunction);
		}
		
		if NOT(err)
		{	ObjRef	objRef;
			CStr63	elName;
			
			if (arrayObjRefP)
			{	if NOT(err = BAPI_ArrayToObj(api_data, false, 0, nil, 0, nil, nil, &arTempObj))
				{	INVAL(objRef);
					if NOT(err = BAPI_StringToObj(api_data, prototype, CLen(prototype), &objRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "PROTOTYPE", &objRef);
					if (err)
						goto out;
					INVAL(objRef);
					if NOT(err = BAPI_StringToObj(api_data, returnClass, CLen(returnClass), &objRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "RETURN", &objRef);
					if (err)
						goto out;
					INVAL(objRef);
					if NOT(err = BAPI_StringToObj(api_data, returnArrayLevel, CLen(returnArrayLevel), &objRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "RETURN_ARRAY_LEVEL", &objRef);
					if (err)
						goto out;
					INVAL(objRef);
					if NOT(err = BAPI_StringToObj(api_data, returnArrayClass, CLen(returnArrayClass), &objRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "RETURN_ARRAY_CLASS", &objRef);
					if (err)
						goto out;
					INVAL(objRef);
					if NOT(err = BAPI_BooleanToObj(api_data, isStatic, &objRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "STATIC", &objRef);
					if (err)
						goto out;
					INVAL(objRef);
					if NOT(err = BAPI_BooleanToObj(api_data, isConstant, &objRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "CONST", &objRef);
					if (err)
						goto out;
					INVAL(objRef);
					if NOT(err = BAPI_StringToObj(api_data, visStr, CLen(visStr), &objRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "VISIBILITY", &objRef);
					if (err)
						goto out;
					if NOT(isProp)
					{	INVAL(objRef);
						if NOT(err = BAPI_IntToObj(api_data, totParamsInProto, &objRef))
							err = BAPI_ArrayAddElement(api_data, &arTempObj, "TOT_PARAMS", &objRef);
						if (err)
							goto out;
						INVAL(objRef);
						if NOT(err = BAPI_BooleanToObj(api_data, dontCheckNumParams, &objRef))
							err = BAPI_ArrayAddElement(api_data, &arTempObj, "NO_CHECK_NUM_PARAMS", &objRef);
						if (err)
							goto out;
						INVAL(objRef);
						if NOT(err = BAPI_BooleanToObj(api_data, dontCheckNames, &objRef))
							err = BAPI_ArrayAddElement(api_data, &arTempObj, "NO_CHECK_NAME_PARAMS", &objRef);
					}
					if (protoParamP)
					{	for (i = 1; (i <= totParamsInProto) && NOT(err); i++, protoParamP++)
						{
							sprintf(elName, "P_NAME_%d", i);
							INVAL(objRef);
							if NOT(err = BAPI_StringToObj(api_data, protoParamP->name, CLen(protoParamP->name), &objRef))
								err = BAPI_ArrayAddElement(api_data, &arTempObj, elName, &objRef);
							if (err)
								goto out;
							sprintf(elName, "P_CLASS_%d", i);
							if NOT(err = BAPI_NameFromClassID(api_data, protoParamP->classID, prototype))
							{	INVAL(objRef);
								if NOT(err = BAPI_StringToObj(api_data, prototype, CLen(prototype), &objRef))
									err = BAPI_ArrayAddElement(api_data, &arTempObj, elName, &objRef);
							}
							if (err)
								goto out;
							sprintf(elName, "P_FOR_ADDRESS_%d", i);
							INVAL(objRef);
							if NOT(err = BAPI_BooleanToObj(api_data, protoParamP->forAddress, &objRef))
								err = BAPI_ArrayAddElement(api_data, &arTempObj, elName, &objRef);
							if (err)
								goto out;
							if (err)
								goto out;
							sprintf(elName, "P_DEFAULT_%d", i);
							INVAL(objRef);
							if NOT(err = BAPI_StringToObj(api_data, protoParamP->defaultStr, CLen(protoParamP->defaultStr), &objRef))
								err = BAPI_ArrayAddElement(api_data, &arTempObj, elName, &objRef);
							if (err)
								goto out;
							sprintf(elName, "P_ARELEM_LEVEL_%d", i);
							INVAL(objRef);
							if NOT(err = BAPI_IntToObj(api_data, protoParamP->arraylevel, &objRef))
								err = BAPI_ArrayAddElement(api_data, &arTempObj, elName, &objRef);
							if (err)
								goto out;
							sprintf(elName, "P_ARELEM_CLASS_%d", i);
							if (protoParamP->arrayElementClassID)
								err = BAPI_NameFromClassID(api_data, protoParamP->arrayElementClassID, prototype);
							else
								*prototype = 0;
							if NOT(err)
							{	INVAL(objRef);
								if NOT(err = BAPI_StringToObj(api_data, prototype, CLen(prototype), &objRef))
									err = BAPI_ArrayAddElement(api_data, &arTempObj, elName, &objRef);
							}
						}
					}
				}
				if NOT(err)
					err = _CopyResult(api_data, &arTempObj, arrayObjRefP);
			}
		}
	}

out:
	if (protoParamBlock)
		DisposeBlock(&protoParamBlock);

return err;
}*/

//===========================================================================================
XErr	BAPI_IsMemberDef(long api_data, char *className, char *memberName, Boolean *isDefP)
{
XErr					err = noErr;
Boolean					isDef = false;
long					classID;	//, funcPlugID, funcObjID, funcID;
//MemberIdentification	membIdent;
Boolean					exists, memberExists;
SuperIsChangedNotify 	*notifyP = nil;
BAPI_Doc				*docP;

	if NOT(CCompareStrings_cs(className, "function"))	// function
	{	if (NOT(err = GetFunctionInfo(api_data, nil, nil, memberName, nil, &exists)) && exists)
			isDef = true;
	}
	else
	{	if (classID = BAPI_ClassIDFromName(api_data, className, false))
		{	if NOT(CCompareStrings_cs(className, memberName))	// constructor
			{	if NOT(err = GetContructorDoc(api_data, classID, &docP))
				{	if (docP)	
						isDef = true;
					else
						isDef = false;
				}
			}
			else
			{	if NOT(err = GetMemberInfo(api_data, memberName, classID, nil, nil, nil, 0, &memberExists, false, &notifyP, true, false))
				{	if (memberExists)
						isDef = true;
				}
			}
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchClass);
	}

if NOT(err)
{	if (isDefP)
		*isDefP = isDef;
}
return err;
}

//===========================================================================================
static void	_MemberActionToBAPI_Doc(BlockRef membBlock)
{
MemberAction	*membP = (MemberAction*)GetPtr(membBlock);
long			totSizeDoc = sizeof(BAPI_Doc) + ((membP->doc.totParams - 1) * sizeof(BAPI_ParameterDoc));

	CopyBlock(membP, &membP->doc, totSizeDoc);
}

//#define	DOC_FOLDER			"Man"
#define	XML_SUFFIX			".xml"
#define	XML_SUFFIX_LEN		4
#define	XML_SHORT_NAMES		"shortfiles.txt"
#define	XML_SHORT_CNT		4	// like #002

//===========================================================================================
static XErr	_CheckXMLTooLongName(char *name, char *manFolder)
{
int			i, limit, nameLen;
CStr255		indexStr, suffix, shortNameFilePath;
CacheResult	cacheRes;
XErr		err = noErr;
Ptr			saveP, textP;
long		offset, textLen;
int			saveChar, endOfWord, diff, n, endChar;

	nameLen = CLen(name);
	limit = nameLen - (31 - XML_SUFFIX_LEN);
	if (limit > 0)
	{	limit += XML_SHORT_CNT;
		n = nameLen - limit;
		*suffix = '\t';
		CopyBlock(suffix + 1, name + n, limit);
		saveChar = name[n];		// reset later if error
		name[n] = 0;
		XGetApplicationFolderPath(shortNameFilePath);
		CAddStr(shortNameFilePath, manFolder);
		CAddStr(shortNameFilePath, "/");
		CAddStr(shortNameFilePath, XML_SHORT_NAMES);
		if NOT(err = CFGetFile(shortNameFilePath, &cacheRes))
		{	textP = GetPtr(cacheRes.fileData);
			textLen = cacheRes.fileSize;
			offset = 0;
			// limit + 1 for the tab preceedings
		redo:
			if (FindStringInText(suffix, limit + 1, textP, textLen, &offset, true, false))
			{	endOfWord = offset + limit + 1 - 1;
				diff = textLen - endOfWord;
				if (diff > 0)
				{	endChar = *(textP + endOfWord);
					if ((endChar != '\r') && (endChar != '\n'))
					{	textP += offset + limit + 1;
						textLen -= offset + limit + 1;
						goto redo;
					}
				}
				textP += --offset - 1;
				saveP = textP;
				//i = 0;
				do
				{	if ((*textP == '\r') || (*textP == '\n'))
						break;
					//else
					//	indexStr[i++] = *textP;
					textP--;
					offset--;
				} while (offset > 0);
				i = saveP - textP;
				if (i < 255)
				{	CopyBlock(indexStr, textP+1, i);
					indexStr[i] = 0;
				}
				else
					CEquStr(indexStr, "???");
				CAddStr(name, "#");
				PadString((Byte*)indexStr, (short)i, XML_SHORT_CNT-1, '0', true);
				CAddStr(name, indexStr);
			}
			cacheRes.dontCache = true;
			CFReleaseFile(&cacheRes, 0);
		}
		if (err)
			 name[n] = saveChar;
	}

return err;
}

//===========================================================================================
static XErr	_GetXMLPath_Try(long api_data, char *className, char *memberName, Boolean isBiferno, char *manFile, char *manName)
{
XFilePath		finalPath;
XErr			err = noErr;
long			classID;
BAPI_ClassInfo	classInfo;
char			*strP;

	if (_CheckXMLTooLongName(memberName, manName))
	{	*manFile = 0;
		return noErr;
	}
	if (isBiferno)
		CEquStr(finalPath, "BfrMan/");
	else
	{	CEquStr(finalPath, manName);
		CAddChar(finalPath, '/');
	}
	CAddStr(finalPath, className);
	CAddStr(finalPath, "/");
	CAddStr(finalPath, memberName);
	CAddStr(finalPath, XML_SUFFIX);
	if (isBiferno)
	{	if (NOT(*className) || NOT(CCompareStrings_cs(className, "function")))
		{	
		BlockRef	docBlockRef;
		
			if NOT(err = BAPI_GetMemberDoc(api_data, className, memberName, &docBlockRef, false))
			{	
			BAPI_Doc	*docP = (BAPI_Doc*)GetPtr(docBlockRef);
				
				if (strP = strrchr(docP->ident.b.sourceFile.filePath, '/'))
				{	*(strP + 1) = 0;
					CEquStr(manFile, docP->ident.b.sourceFile.filePath);
					CAddStr(manFile, finalPath);
				}
				BAPI_ReleaseMemberDoc(api_data, &docBlockRef);
			}
		}
		else if (classID = BAPI_ClassIDFromName(api_data, className, false))
		{	if NOT(err = BAPI_GetClassInfo(api_data, classID, &classInfo))
			{	if (strP = strrchr(classInfo.sourceFilePath, '/'))
				{	*(strP + 1) = 0;
					CEquStr(manFile, classInfo.sourceFilePath);
					CAddStr(manFile, finalPath);
				}
			}
		}
		else
			*manFile = 0;
	}
	else if NOT(err = XGetApplicationFolderPath(manFile))	// man are in BIFERNOHOME
		CAddStr(manFile, finalPath);
	if (CheckPath(manFile, true))
		*manFile = 0;	// doesn't exists
	
	// Try if there is One in application folder
	/*CEquStr(manFile, bRecP->application.basePath);
	CAddStr(manFile, subPath);
	if (CheckPath(manFile, true))	// it is not .. see in BIFERNOHOME
	{	if NOT(err = XGetApplicationFolderPath(manFile))
		{	CAddStr(manFile, subPath);
			if (CheckPath(manFile, true))
				*manFile = 0;	// doesn't exists
		}
	}*/
	
return err;
}

//===========================================================================================
static XErr	_GetXMLPath(long api_data, char *className, char *memberName, Boolean isBiferno, char *manFile)
{
XErr			err = noErr;

	if NOT(err = _GetXMLPath_Try(api_data, className, memberName, isBiferno, manFile, "Man2"))
	{	if NOT(*manFile)	// doesn't exists
			err = _GetXMLPath_Try(api_data, className, memberName, isBiferno, manFile, "Man");	
	}

return err;
}

#define	PARAM_TAG			"param"
#define	PURPOSE_TAG			"purpose"
#define	DESCR_TAG			"descr"
#define	RETURNS_TAG			"returns"
#define	SEE_ALSO_TAG		"see_also"
#define	NOTE_TAG			"note"
#define	ERRORS_TAG			"errors"

enum {
		kPARAM = 10,
		kDESCR,
		kPURPOSE,
		kRETURNS,
		kSEE_ALSO,
		kNOTE,
		kERRORS
	};
//===========================================================================================
static XErr 	_GetDocNextTag(Ptr *textPPtr, long *lenP, long *tagP, Ptr *fromPPtr, long *contentLengthP, Boolean isMemberInfo)
{
XErr		err = noErr;
long		compLen, tLen, len, tagID = 0;
Ptr			saveP, textP;
CStr63		compareStr, tagStr;
Boolean		found;
int			ch;

	textP = *textPPtr;
	len = *lenP;
	SkipUntilChar(&textP, &len, '<', nil);
	*fromPPtr = nil;
	*contentLengthP = 0;
	if (len)
	{	textP++;
		len--;
		saveP = textP;
		while(len)
		{	ch = *textP;
			if ((ch == ' ') || (ch == '\t') || (ch == '\r') || (ch == '\n') || (ch == '>'))
				break;
			else
			{	textP++;
				len--;
			}
		}
		tLen = textP - saveP;
		if (tLen > 63)
			tLen = 63;
		CopyBlock(tagStr, saveP, tLen);
		tagStr[tLen] = 0;
		if (NOT(CCompareStrings_cs(tagStr, "class")) && isMemberInfo)
		{	// skip until </class>
			compLen = CLen("</class>");
			found = false;
			while ((len >= compLen) && NOT(found = NOT(CompareBlock(textP, "</class>", compLen))))
			{	textP++;
				len--;
			}
			if (found)
			{	textP += compLen;
				len -= compLen;
			}
			goto out1;
		}
		else if (NOT(isMemberInfo) && (NOT(CCompareStrings_cs(tagStr, "function")) || NOT(CCompareStrings_cs(tagStr, "method")) || NOT(CCompareStrings_cs(tagStr, "property")) || NOT(CCompareStrings_cs(tagStr, "error")) || NOT(CCompareStrings_cs(tagStr, "constant"))))
		{	// skip until </[tag]>
			CEquStr(compareStr, "</");
			CAddStr(compareStr, tagStr);
			CAddStr(compareStr, ">");
			compLen = CLen(compareStr);
			found = false;
			while ((len >= compLen) && NOT(found = NOT(CompareBlock(textP, compareStr, compLen))))
			{	textP++;
				len--;
			}
			if (found)
			{	textP += compLen;
				len -= compLen;
			}
			goto out1;
		}
		else if NOT(CCompareStrings_cs(tagStr, PARAM_TAG))
		{	compLen = CLen("<descr>");
			found = false;
			while ((len >= compLen) && NOT(found = NOT(CompareBlock(textP, "<descr>", compLen))))
			{	textP++;
				len--;
			}
			if (found)
			{	CEquStr(tagStr, "descr");
				textP += compLen - 1;	// To balance another ++ following
				len -= compLen - 1;
			}
			tagID = kPARAM;
		}
		else if NOT(CCompareStrings_cs(tagStr, DESCR_TAG))
			tagID = kDESCR;
		else if NOT(CCompareStrings_cs(tagStr, PURPOSE_TAG))
			tagID = kPURPOSE;
		else if NOT(CCompareStrings_cs(tagStr, RETURNS_TAG))
			tagID = kRETURNS;
		else if NOT(CCompareStrings_cs(tagStr, SEE_ALSO_TAG))
			tagID = kSEE_ALSO;
		else if NOT(CCompareStrings_cs(tagStr, NOTE_TAG))
			tagID = kNOTE;
		else if NOT(CCompareStrings_cs(tagStr, ERRORS_TAG))
			tagID = kERRORS;
		else
			tagID = 0;
		if (len)
		{	if (tagID)
			{	textP++;
				len--;
				*fromPPtr = textP;
				CEquStr(compareStr, "</");
				CAddStr(compareStr, tagStr);
				CAddStr(compareStr, ">");
				compLen = CLen(compareStr);
				found = false;
				while ((len >= compLen) && NOT(found = NOT(CompareBlock(textP, compareStr, compLen))))
				{	textP++;
					len--;
				}
				if (found)
				{	*contentLengthP = textP - *fromPPtr;
					textP += compLen;
					len -= compLen;
				}
				else
					err = XError(kBAPI_Error, Err_BadSyntax);
			}
			else
			{	SkipUntilChar(&textP, &len, '>', nil);
				if (len)
				{	textP++;
					len--;
				}
			}
		}
	}
	if (tagP)
		*tagP = tagID;

out1:
	*textPPtr = textP;
	*lenP = len;

return err;
}

//===========================================================================================
static XErr	_FillDescrP(BlockRef fileData, long len, BAPI_Descr *docBlockP, long headLen, Boolean isMemberInfo)
{
XErr		err = noErr;
long		compLen, curOff, tagID, length, param_descr_index;
Ptr			textP, destP, fromP;
Boolean		found = 0;

	param_descr_index = 0;
	textP = GetPtr(fileData);
	destP = (Ptr)docBlockP;
	curOff = headLen;
	compLen = CLen("<bifdoc>");
	while ((len >= compLen) && NOT(found = NOT(CompareBlock(textP, "<bifdoc>", compLen))))
	{	textP++;
		len--;
	}
	if (found)
	{	textP += compLen;
		len -= compLen;
		while (len && NOT(err))
		{	if NOT(err = _GetDocNextTag(&textP, &len, &tagID, &fromP, &length, isMemberInfo))
			{	switch(tagID)
				{	case kPARAM:
						CopyBlock(destP + curOff, fromP, length);
						docBlockP->params[param_descr_index].off = curOff;
						docBlockP->params[param_descr_index].len = length;
						curOff += length;
						param_descr_index++;
						break;
					case kDESCR:
						CopyBlock(destP + curOff, fromP, length);
						docBlockP->descr.off = curOff;
						docBlockP->descr.len = length;
						curOff += length;
						break;
					case kPURPOSE:
						CopyBlock(destP + curOff, fromP, length);
						docBlockP->purpose.off = curOff;
						docBlockP->purpose.len = length;
						curOff += length;
						break;
					case kRETURNS:
						CopyBlock(destP + curOff, fromP, length);
						docBlockP->returns.off = curOff;
						docBlockP->returns.len = length;
						curOff += length;
						break;
					case kSEE_ALSO:
						CopyBlock(destP + curOff, fromP, length);
						docBlockP->seeAlso.off = curOff;
						docBlockP->seeAlso.len = length;
						curOff += length;
						break;
					case kNOTE:
						CopyBlock(destP + curOff, fromP, length);
						docBlockP->note.off = curOff;
						docBlockP->note.len = length;
						curOff += length;
						break;
					case kERRORS:
						CopyBlock(destP + curOff, fromP, length);
						docBlockP->errors.off = curOff;
						docBlockP->errors.len = length;
						curOff += length;
						break;
					default:
						break;
				}
			}
		}
	}
	if NOT(err)
		docBlockP->totlen = curOff;

return err;
}

//===========================================================================================
// return a BAPI_Descr + text
XErr	BAPI_GetClassDoc(long api_data, char *className, BlockRef *xmlBlockRefP)
{
XErr		err = noErr;
BAPI_Descr	*descrP;
CStr255		manFile;
CacheResult cacheRes;
long		tLen, headLen;
BlockRef	xmlStuff;
long		classID;

	*xmlBlockRefP = 0;
	if (classID = BAPI_ClassIDFromName(api_data, className, false))
	{	if NOT(err = _GetXMLPath(api_data, className, className, (Boolean)(classID < 0), manFile))
		{	if (*manFile)
			{	if NOT(err = CFGetFile(manFile, &cacheRes))
				{	headLen = sizeof(BAPI_Descr) - sizeof(BAPI_Pos);
					tLen = headLen + cacheRes.fileSize;
					if (xmlStuff = NewBlockLocked(tLen, &err, (Ptr*)&descrP))
					{	ClearBlock(descrP, tLen);
						err = _FillDescrP(cacheRes.fileData, cacheRes.fileSize, descrP, headLen, false);
					}
					cacheRes.dontCache = true;
					CFReleaseFile(&cacheRes, 0);
					if (err)
						DisposeBlock(&xmlStuff);
					else
						*xmlBlockRefP = xmlStuff;
				}
			}
		}
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetMemberDoc(long api_data, char *className, char *memberName, BlockRef *docBlockRefP, Boolean extended)
{
XErr		err = noErr;
Boolean		memberExists, toConvert;
long 		tLen, classID;
BAPI_Doc	*docBlockP;

	*docBlockRefP = 0;
	if (NOT(className) || NOT(*className) || NOT(CCompareStrings_cs(className, "function")))
	{	err = GetFunctionInfo(api_data, nil, nil, memberName, docBlockRefP, &memberExists);
		if (NOT(err) && NOT(memberExists))
			err = XError(kBAPI_Error, Err_NoSuchFunction);
		if NOT(err)
			toConvert = true;
	}
	else
	{	if NOT(classID = BAPI_ClassIDFromName(api_data, className, false))
			err = XError(kBAPI_Error, Err_NoSuchClass);
		else
		{	
		BAPI_Doc	*returnP, *docP;
		
			if NOT(CCompareStrings_cs(className, memberName))
			{	if NOT(err = GetContructorDoc(api_data, classID, &docP))
				{	if (docP)
					{	tLen = docP->len;
						if (*docBlockRefP = NewBlockLocked(tLen, &err, (Ptr*)&returnP))
						{	CopyBlock(returnP, docP, tLen);
							toConvert = false;
						}
					}
					else
						err = XError(kBAPI_Error, Err_NoSuchMember);
					/*{	tLen = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
						if (*docBlockRefP = NewBlockLocked(tLen, &err, (Ptr*)&returnP))
						{	ClearBlock(returnP, tLen);
							returnP->info.method.classID = classID;
							returnP->len = tLen;
						}
					}*/
				}
			}
			else
			{	// if pass nil to GetMemberInfo as membActionP always a BlockRef is allocated
				err = GetMemberInfo(api_data, memberName, classID, nil, docBlockRefP, nil, 0, &memberExists, false, nil, true, false);
				if (NOT(err) && NOT(memberExists))
					err = XError(kBAPI_Error, Err_NoSuchMember);
				if NOT(err)
					toConvert = true;
			}
		}
	}
	if NOT(err)
	{	if (toConvert)
			_MemberActionToBAPI_Doc(*docBlockRefP);	// MemberAction -> BAPI_Doc

		if (extended)
		{	
		BAPI_Descr	*descrP;
		CStr255		manFile;
		CacheResult cacheRes;
		long		headLen;
		
			docBlockP = (BAPI_Doc*)GetPtr(*docBlockRefP);
			if NOT(err = _GetXMLPath(api_data, className, memberName, (Boolean)(docBlockP->implem == kBifernoImplementation), manFile))
			{	if (*manFile)
				{	if NOT(err = CFGetFile(manFile, &cacheRes))
					{	headLen = sizeof(BAPI_Descr) + (sizeof(BAPI_Pos) * (docBlockP->totParams - 1));
						tLen = headLen + cacheRes.fileSize;
						if (docBlockP->xmlStuff = NewBlockLocked(tLen, &err, (Ptr*)&descrP))
						{	ClearBlock(descrP, tLen);
							err = _FillDescrP(cacheRes.fileData, cacheRes.fileSize, descrP, headLen, true);
						}
						cacheRes.dontCache = true;
						CFReleaseFile(&cacheRes, 0);
						if (err)
							DisposeBlock(&docBlockP->xmlStuff);
					}
				}
			}
		}
	}

if (err && *docBlockRefP)
	DisposeBlock(docBlockRefP);	
return err;
}

//===========================================================================================
XErr	BAPI_DuplicateMemberDoc(long api_data, BlockRef docBlockRef, BlockRef *newDocBlockRefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
BAPI_Doc	*docP, *newDocP;
BAPI_Descr	*descrP, *newDescrP;
	
	docP = (BAPI_Doc*)GetPtr(docBlockRef);
	if (*newDocBlockRefP = NewBlockLocked(docP->len, &err, (Ptr*)&newDocP))
	{	CopyBlock(newDocP, docP, docP->len);
		if (docP->xmlStuff)
		{	descrP = (BAPI_Descr*)GetPtr(docP->xmlStuff);
			if (newDocP->xmlStuff = NewBlockLocked(descrP->totlen, &err, (Ptr*)&newDescrP))
				CopyBlock(newDescrP, descrP, descrP->totlen);
		}
		if (err)
			DisposeBlock(newDocBlockRefP);
	}

return err;
}

//===========================================================================================
/*
XErr	BAPI_GetMemberDoc(long api_data, char *className, char *memberName, BlockRef *docBlockRefP)
{
XErr					err = noErr;
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data, className, memberName, docBlockRefP)		// #if __MWERKS__
	#pragma unused temporaneo
BlockRef				protoParamBlock = nil;
ProtoParam				*protoParamP = nil;
long					i, totParams;
BAPI_ParameterDoc		*paramP;
BAPI_Doc 				*docBlockP;

	if NOT(*docBlockRefP = NewBlockLocked(sizeof(BAPI_Doc), &err, (Ptr*)&docBlockP))
		return err;
		
	ClearBlock(docBlockP, sizeof(BAPI_Doc));
	CEquStr(docBlockP->name, memberName);
	if NOT(CCompareStrings_cs(className, "function"))	// function
	{	
	long				funcPlugID, funcObjID, funcID;
	BAPI_MethodDoc		*functionInfoP;
		
		if NOT(err = GetFunctionInfo(api_data, nil, nil, memberName, &funcID, &funcObjID))
		{	
		Boolean isBiferno = (funcPlugID == -1);
			
			functionInfoP = &docBlockP->info.function;
			if NOT(err = GetProtoBlock(api_data, 0, funcObjID, isBiferno, &protoParamBlock, &protoParamP, &totParams, functionInfoP->prototype, &functionInfoP->varArgs, &functionInfoP->noNames, false, &docBlockP->returnClassID, nil, nil))
			{	docBlockP->type = kFunction;
				docBlockP->returnAeClass = 0;	// non ancora implementato
				docBlockP->returnAeLevel = 0;	// non ancora implementato
				functionInfoP->totParams = totParams;
				if (totParams && (functionInfoP->params = NewBlockLocked(sizeof(BAPI_ParameterDoc) * totParams, &err, (Ptr*)&paramP)))
				{	ClearBlock(paramP, sizeof(BAPI_ParameterDoc) * totParams);
					for (i = 0; i < totParams; i++, paramP++, protoParamP++)
					{	CEquStr(paramP->name, protoParamP->name);
						CEquStr(paramP->defaultStr, protoParamP->defaultStr);
						paramP->classID = protoParamP->classID;
						paramP->aelevel = protoParamP->arraylevel;
						paramP->aeClassID = protoParamP->arrayElementClassID;
						paramP->byRef = protoParamP->forAddress;
						// paramP->descr;	prendere da xml
					}
				}
			}					
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchFunction);
	}
	else	// method, property, constant, error
	{	
		long					classID;
		BAPI_MethodDoc			*methodInfoP;
		
		if (classID = BAPI_ClassIDFromName(api_data, className, false))
		{	methodInfoP = &docBlockP->info.method;
			if NOT(CCompareStrings_cs(className, memberName))	// constructor
			{	if NOT(err = GetProtoBlock(api_data, classID, 0, classID > 0, &protoParamBlock, &protoParamP, &totParams, methodInfoP->prototype, &methodInfoP->varArgs, &methodInfoP->noNames, true, nil, nil, &methodInfoP->isStatic))
				{	docBlockP->type = kMethod;
					docBlockP->returnClassID = 0;
					docBlockP->returnAeClass = 0;	// non ancora implementato
					docBlockP->returnAeLevel = 0;	// non ancora implementato
					methodInfoP->classID = classID;
					methodInfoP->totParams = totParams;
					if (totParams && (methodInfoP->params = NewBlockLocked(sizeof(BAPI_ParameterDoc) * totParams, &err, (Ptr*)&paramP)))
					{	ClearBlock(paramP, sizeof(BAPI_ParameterDoc) * totParams);
						for (i = 0; i < totParams; i++, paramP++, protoParamP++)
						{	CEquStr(paramP->name, protoParamP->name);
							CEquStr(paramP->defaultStr, protoParamP->defaultStr);
							paramP->classID = protoParamP->classID;
							paramP->aelevel = protoParamP->arraylevel;
							paramP->aeClassID = protoParamP->arrayElementClassID;
							paramP->byRef = protoParamP->forAddress;
							// paramP->descr;	prendere da xml
						}
					}
				}
			}
			else
			{	
			SuperIsChangedNotify 	*notifyP = nil;
			MemberIdentification	membIdent;
			Boolean					memberExists;
			BAPI_PropertyDoc		*propInfoP;
			
				ClearBlock(&membIdent, sizeof(MemberIdentification));
				CEquStr(membIdent.memberName, memberName);
				if (classID > 0)
					err = GetMemberInfo(api_data, classID, nil, &membIdent, 0, &memberExists, false, &notifyP, true);
				else
				{	membIdent.memberType = kMethod;
					if NOT(err = GetMemberInfo(api_data, classID, nil, &membIdent, '(', &memberExists, false, &notifyP, true))
					{	if NOT(memberExists)
						{	membIdent.memberType = kProperty;
							err = GetMemberInfo(api_data, classID, nil, &membIdent, 0, &memberExists, false, &notifyP, true);
						}
					}
				}
				if NOT(err)
				{	if (memberExists)
					{	if (membIdent.memberType == kProperty)
						{	if (membIdent.memberIsError)
								docBlockP->type = kError;
							else
							{	if (membIdent.memberIsConstant)
									docBlockP->type = kConstant;
								else
									docBlockP->type = kProperty;
							}
							docBlockP->returnClassID = membIdent.memberClassID;
							docBlockP->returnAeClass = membIdent.memberArrayElementClassID;
							docBlockP->returnAeLevel = membIdent.memberArrayLevel;
							propInfoP = &docBlockP->info.property;
							propInfoP->classID = classID;
							propInfoP->isConst = membIdent.memberIsConstant;
							propInfoP->isStatic = membIdent.memberIsStatic;
							propInfoP->visibility = membIdent.memberVisibility;
						}
						else
						{	if NOT(err = GetProtoBlock(api_data, membIdent.memberClassID, membIdent.memberObjID, classID < 0, &protoParamBlock, &protoParamP, &totParams, methodInfoP->prototype, &methodInfoP->varArgs, &methodInfoP->noNames, false, &docBlockP->returnClassID, &methodInfoP->visibility, nil))
							{	docBlockP->type = kMethod;
								methodInfoP->totParams = totParams;
								methodInfoP->classID = classID;
								methodInfoP->isStatic = membIdent.memberIsStatic;
								docBlockP->returnAeClass = membIdent.memberArrayElementClassID;
								docBlockP->returnAeLevel = membIdent.memberArrayLevel;
								if (totParams && (methodInfoP->params = NewBlockLocked(sizeof(BAPI_ParameterDoc) * totParams, &err, (Ptr*)&paramP)))
								{	ClearBlock(paramP, sizeof(BAPI_ParameterDoc) * totParams);
									for (i = 0; i < totParams; i++, paramP++, protoParamP++)
									{	CEquStr(paramP->name, protoParamP->name);
										CEquStr(paramP->defaultStr, protoParamP->defaultStr);
										paramP->classID = protoParamP->classID;
										paramP->aelevel = protoParamP->arraylevel;
										paramP->aeClassID = protoParamP->arrayElementClassID;
										paramP->byRef = protoParamP->forAddress;
										// paramP->descr;	prendere da xml
									}
								}
							}
						}
					}
					else
						err = XError(kBAPI_Error, Err_NoSuchMember);
				}
			}
		}
		else
			err = XError(kBAPI_Error, Err_NoSuchClass);
	}
	
	if NOT(err)
	{
		// qui riempire questi per tutti (da xml)
		//BlockRef			purpose;
		//BlockRef			descr;
		//BlockRef			errors;
		//BlockRef			see_also;
		//BlockRef			note;
	}

if (protoParamBlock)
	DisposeBlock(&protoParamBlock);
if (err)
	BAPI_ReleaseMemberDoc(api_data, docBlockRefP);
else
	UnlockBlock(*docBlockRefP);

return err;
}*/

//===========================================================================================
XErr	BAPI_ReleaseMemberDoc(long api_data, BlockRef *docBlockRefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
BlockRef	tBlock;
BAPI_Doc	*docBlockP;

	docBlockP = (BAPI_Doc*)GetPtr(*docBlockRefP);
	if (tBlock = docBlockP->xmlStuff)
		DisposeBlock(&tBlock);
	DisposeBlock(docBlockRefP);
		
/*BAPI_Doc 			*docBlockP;
//long				i, totParams;
//BAPI_ParameterDoc	*paramP;

	LockBlock(*docBlockRefP);
	docBlockP = (BAPI_Doc*)GetPtr(*docBlockRefP);
	switch(docBlockP->type)
	{
		case kMethod:
			if (docBlockP->info.method.params)
			{	DisposeBlock(&docBlockP->info.method.params);
			}
			break;
		case kProperty: 
			break;
		case kFunction: 
			if (docBlockP->info.function.params)
			{	DisposeBlock(&docBlockP->info.function.params);
			}
			break;
		case kError: 
			break;
		case kConstant:
			break;	
	}
	if (docBlockP->xmlStuff)
		DisposeBlock(&docBlockP->xmlStuff);
	
	DisposeBlock(docBlockRefP);
*/
return err;
}

//===========================================================================================
/*XErr	BAPI_GetDocumentation(long api_data, char *name, ObjRef *arrayObjRefP)
{
XErr			err = noErr, err2 = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
//BlockRef		bl = 0;
long			classID = 0, funcPlugID = 0, fLen, res;
CStr255			className;
ObjRef			arTempObj;
XFilePath		manFile;

	CHECK_RES(arrayObjRefP)
	INVAL(arTempObj);
	
	*manFile = 0;
	*className = 0;
	if NOT(bRecP)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	fLen = CLen(name);
	if (res = FindStringInText(".", 1, name, fLen, nil, true, false))
	{	if NOT(err = GetEntityName(api_data, &name, &fLen, className, false))
		{	name++;
			fLen--;
		}
	}
	else
	{	if NOT(BAPI_ClassIDFromName(api_data, name, false))
			*className = 0;
		else
			CEquStr(className, name);
	}
	
	// doc?
	if (arrayObjRefP)
	{
	XFilePath	startPath;
	
		CEquStr(startPath, "Man/");
		if (*className)
		{	CAddStr(startPath, className);
			CAddStr(startPath, "/");
		}
		CAddStr(startPath, name);
		CEquStr(manFile, bRecP->application.basePath);
		CAddStr(manFile, startPath);
		if (CheckPath(manFile, true))
		{	if NOT(err = XGetApplicationFolderPath(manFile))
				CAddStr(manFile, startPath);
		}
		if NOT(err)
		{	CacheResult		cacheRes;
		
			if NOT(err = BifernoGetFile(bRecP, manFile, &cacheRes, false))
			{	
				err = _DocToArray(api_data, GetPtr(cacheRes.fileData), cacheRes.fileSize, &arTempObj);
				err2 = CFReleaseFile(&cacheRes, 0);
				if (NOT(err) && err2)
					err = err2;
			}
		}

		if (err && *manFile)
		{	long		eNum, eType, tLen, filePathLen, initLen, endLen;
			CStr255		initStr, eNameStr, endStr;
			BlockRef	bl;
			Ptr			p;
			ObjRef		tObjRef;
			
			BAPI_GetErrDescription(api_data, err, eNameStr, nil, nil, nil, nil, bRecP->lastClassIDErrorCalled);
			XErrorGetTypeValue(err, &eNum, &eType);
			sprintf(initStr, "%s (%d - %d) for file: ", eNameStr, eNum, eType);
			initLen = CLen(initStr);
			CEquStr(endStr, "");
			endLen = CLen(endStr);
			filePathLen = CLen(manFile);
			tLen = initLen + filePathLen + endLen;
			if (bl = NewBlockLocked(tLen, &err, &p))
			{	//p = GetPtr(bl);
				CopyBlock(p, initStr, initLen);
				CopyBlock(p + initLen, manFile, filePathLen);
				CopyBlock(p + initLen + filePathLen, endStr, endLen);
				if NOT(err = BAPI_ArrayToObj(api_data, false, 0, nil, 0, nil, nil, &arTempObj))
				{	INVAL(tObjRef);
					if NOT(err = BAPI_StringToObj(api_data, p, tLen, &tObjRef))
						err = BAPI_ArrayAddElement(api_data, &arTempObj, "Err", &tObjRef);
					//*docBlockLenP = initLen + filePathLen + endLen;
					//*docBlockP = bl;
				}
				DisposeBlock(&bl);
			}
		}
		if NOT(err)
			err = _CopyResult(api_data, &arTempObj, arrayObjRefP);
	}
	
return err;
}
*/
//===========================================================================================
/*
XErr	BAPI_ExtendedClass(long api_data, long classID, long *extendedClassIDP)
{
XErr			err = noErr;
PluginRecord	*plugRecP;
BifernoRecP		bRecP;
long			tLen;

	if (classID > 0)
	{	plugRecP = &gClassRecordBlockP[classID-1];
		*extendedClassIDP = plugRecP->extendedPluginID;
	}
	else if (classID && (bRecP = (BifernoRecP)api_data))
	{	tLen = sizeof(long);
		err = GetUserClassRecord(bRecP, classID, (Ptr)extendedClassIDP, &tLen, offsetof(BifernoClass, extendedClassID)+1, nil);
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchClass);

return err;
}
*/
//===========================================================================================
XErr	BAPI_NameFromClassID(long api_data, long pluginID, char *pluginName)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
PluginRecord	*plugRecP;
int				totClass;
XErr			err = noErr;

	*pluginName = 0;
	if (pluginID == CLASSID_UNSPECIFIED)
		CEquStr(pluginName, "obj");
	else
	{	if (pluginID > 0)
		{	totClass = gsDispatcherData.totClass;
			if (--pluginID < totClass)
			{	plugRecP = &gClassRecordBlockP[pluginID];
				CEquStr(pluginName, plugRecP->pluginName);
			}
		}
		else if (pluginID < 0)
		{	BifernoRec		*bRecP;
			BifernoClass	bifernoClass;
			
			if (bRecP = (BifernoRecP)api_data)
			{	if NOT(err = GetBifernoClassRec(bRecP, -pluginID, &bifernoClass))
					CEquStr(pluginName, bifernoClass.className);
			}
		}
		else
			CEquStr(pluginName, "[undefined]");
	}
	
	if (NOT(*pluginName) && NOT(err))
		err = XError(kBAPI_Error, Err_NoSuchClass);
	
return err;
}

//===========================================================================================
long	BAPI_ClassIDFromName(long api_data, char *className, Boolean allExtensionsType)
{
long			classObjID = 0;

	if (api_data)
		classObjID = GetUserClassID((BifernoRecP)api_data, className);
	if NOT(classObjID)
	{	if (classObjID = DLM_GetObjID(gsDispatcherData.classListRef, className, nil, nil))
		{	
		PluginRecord*	plugRecP;
		
			plugRecP = &gClassRecordBlockP[classObjID-1];
			if (NOT(plugRecP->successfull) || ((plugRecP->pluginType != kNewClassPlugin) && NOT(allExtensionsType)))
				classObjID = 0;
		}
		else if NOT(CCompareStrings_cs(className, "obj"))
				classObjID = CLASSID_UNSPECIFIED;
	}
	
return classObjID;
}

//===========================================================================================
/*long	BAPI_ClassIDFromName(long api_data, char *className, Boolean allExtensionsType)
{
long			classObjID = 0;

	if NOT(classObjID = DLM_GetObjID(gsDispatcherData.classListRef, className, nil, nil))
	{	BifernoRecP		bRecP;
		
		if (bRecP = (BifernoRecP)api_data)
		{	//ex if NOT(classObjID = -DLM_GetObjID(bRecP->application.classesList, className, nil, nil))
			if NOT(classObjID = GetUserClassID(bRecP, className))
			{	if NOT(CompareBlock(className, "obj", 3))
					classObjID = CLASSID_UNSPECIFIED;
			}
		}
	}
	else
	{	PluginRecord*	plugRecP;
	
		plugRecP = &gClassRecordBlockP[classObjID-1];
		if (NOT(plugRecP->successfull) || ((plugRecP->pluginType != kNewClassPlugin) && NOT(allExtensionsType)))
			classObjID = 0;
	}
	
return classObjID;
}*/

//===========================================================================================
XErr	BAPI_ScopeAllowed(long api_data, ObjRefP objP, long scope, Boolean *allowedP)
{
XErr						err = noErr;
PluginRecord*				plugRecP;
long						classID = OBJ_CLASSID_P(objP);
BAPI_ScopeAllowedHook	func;
	
	*allowedP = true;
	if (classID > 0)
	{	plugRecP = &gClassRecordBlockP[classID-1];
		if (func = plugRecP->scopeAllowedHook)
			err = func(api_data, objP, scope, allowedP);
	}
	// Volendo in futuro si pu� pensare a classi utente solo locali (non application etcc..)
	// allora in quel caso qui si deve tornare false

return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void*	BAPI_HTTPTaskID(long api_data)
{
	return ((BifernoRecP)api_data)->userData;

}

//===========================================================================================
XErr	BAPI_GetHTTPParam(long api_data, BAPI_HTTPParam what, ObjRef *result)
{
BifernoRec	*bRecP;
XErr		err = noErr;
CStr255		aCStr;
BlockRef	block;
long		/*aLong, */len;
uint32_t	portNumber;

	CHECK_RES(result)
	
	*aCStr = 0;
	if (bRecP = (BifernoRecP)api_data)
	{	switch(what)
		{
			case BAPI_Method:
				if NOT(err = HTTPControllerGetMethod(bRecP->userData, aCStr))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;
			case BAPI_URL:
				if NOT(err = HTTPControllerGetFullRequest(bRecP->userData, &block, &len))
				{	Ptr			phisURL = GetPtr(block);
					BlockRef	urlDecoded;
					long		urlDecodedLength;
					
					URLFromFullRequest(&phisURL, &len);
					if NOT(err = DecodeURL((Byte*)phisURL, len, &urlDecoded, &urlDecodedLength, false, nil))
					{	LockBlock(urlDecoded);
						err = BAPI_StringToObj(api_data, GetPtr(urlDecoded), urlDecodedLength, result);
						DisposeBlock(&urlDecoded);
					}
					DisposeBlock(&block);
				}
				
				/*
				if NOT(err = HTTPControllerGetPhysURL(bRecP->userData, &block, &len))
				{	if (len < 249)
					{	CEquStr(aCStr, "file:/");
						CopyBlock(aCStr + 6, GetPtr(block), len);
						aCStr[len+6] = 0;
						err = BAPI_StringToObj(api_data, aCStr, len+6, result);
					}
					else
						err = XError(kBAPI_Error, Err_PathTooLong);
					DisposeBlock(&block);
				}
				*/
				break;
			/*case BAPI_PathArg:
				if NOT(err = HTTPControllerGetPathArgs(bRecP->userData, aCStr))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;*/
			case BAPI_SearchArg:
				if NOT(err = HTTPControllerGetSearchArgs(bRecP->userData, &block, &len))
				{	err = BAPI_StringToObj(api_data, GetPtr(block), len, result);
					DisposeBlock(&block);
				}
				break;
			case BAPI_IPAddress:
				if NOT(err = HTTPControllerGetIPAddress(bRecP->userData, aCStr))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;
			case BAPI_Address:
				if NOT(err = HTTPControllerGetAddress(bRecP->userData, aCStr))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;
			case BAPI_Username:
				err = BAPI_StringToObj(api_data, bRecP->username, CLen(bRecP->username), result);
				break;
			case BAPI_Password:
				err = BAPI_StringToObj(api_data, bRecP->password, CLen(bRecP->password), result);
				break;
			case BAPI_Domain:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerDomain, aCStr, nil))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;
			case BAPI_Protocol:
				if NOT(err = HTTPControllerGetFullRequest(bRecP->userData, &block, &len))
				{	Ptr			prot = GetPtr(block);
					
					ProtocolFromFullRequest(&prot, &len);
					err = BAPI_StringToObj(api_data, prot, len, result);
					DisposeBlock(&block);
				}
				break;
			case BAPI_Scheme:				
				if NOT(err = HTTPControllerGetProtocol(bRecP->userData, aCStr))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;
			case BAPI_Port:
				if NOT(err = HTTPControllerGetPort(bRecP->userData, &portNumber))
					err = BAPI_IntToObj(api_data, portNumber, result);
				break;
			
			/*case BAPI_DirectoryPath:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerDirectoryPath, aCStr, nil))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;
			case BAPI_VersionNumber:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerVersionNumber, aCStr, nil))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;
			case BAPI_TotalConnections:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerTotalConnections, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_CurrentUserLevel:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerCurrentUserLevel, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_HighestUserLevel:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerHighestUserLevel, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_CurrentFreeMemory:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerCurrentFreeMemory, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_MinimumFreeMemory:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerMinimumFreeMemory, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_TotalConnTimeouts:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerTotalConnTimeouts, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_TotalConBusies:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerTotalConBusies, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_TotalConDenied:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerTotalConDenied, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;
			case BAPI_TotalBytesSent:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerTotalBytesSent, nil, &aLong))
					err = BAPI_IntToObj(api_data, aLong, result);
				break;*/
			/*case BAPI_UpSinceDate:
				if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerUpSinceDate, aCStr, nil))
					err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), result);
				break;*/
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_GetFilePath(long api_data, XFilePathPtr filePath)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	if (bRecP = (BifernoRecP)api_data)
	{	if (filePath)
		{	CEquStr(filePath, "file:/");
			CAddStr(filePath, bRecP->mainFilePath);
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_GetCurrentFileOffset(long api_data, long *offP)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	if (bRecP = (BifernoRecP)api_data)
		*offP = bRecP->currentCtx.currentOffset;
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_GetCurrentFilePath(long api_data, XFilePathPtr currentFilePath, long *actLineP, Boolean *wasInCacheP, Boolean *willBeCachedP)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	if (bRecP = (BifernoRecP)api_data)
	{	if (currentFilePath)
		{	if (bRecP->currentCtx.currentExecFile)
			{	CEquStr(currentFilePath, bRecP->currentCtx.currentExecFile);
				if (wasInCacheP)
					*wasInCacheP = false;
				if (willBeCachedP)
					*willBeCachedP = false;
			}
			else
			{	CEquStr(currentFilePath, bRecP->curFile.filePath);
				if (wasInCacheP)
					*wasInCacheP = bRecP->curFile.wasInCache;
				if (willBeCachedP)
					*willBeCachedP = NOT(bRecP->curFile.dontCache);
			}
		}
		if (actLineP)
			*actLineP = bRecP->currentCtx.currentLine + bRecP->currentCtx.bisFunctionInitLine;
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
Boolean	BAPI_IsCacheActive(long api_data)
{
BifernoRec	*bRecP;
	
	if (bRecP = (BifernoRecP)api_data)
		return bRecP->application.cacheActive;

return 0;
}

//===========================================================================================
XErr	BAPI_GetCurrentBasePath(long api_data, XFilePathPtr currentBasePath, Boolean fromRoot)
{
BifernoRec	*bRecP;
XErr		err = noErr;
	
	if (bRecP = (BifernoRecP)api_data)
	{	if (fromRoot)
		{	if (*bRecP->serverBaseDir)
				CEquStr(currentBasePath, bRecP->serverBaseDir);
			else
				*currentBasePath = 0;
		}
		else
			CEquStr(currentBasePath, bRecP->curBasePath);
		if NOT(err)
			CSubstitute(currentBasePath, ':', '/');
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (NOT(err) && *currentBasePath)
		err = CheckPath(currentBasePath, true);

return err;
}

//===========================================================================================
XErr	BAPI_GetCurrentScriptInfo(long api_data, unsigned long *timeoutP, long *currentThreadsP, long *maxThreadsP, XFilePathPtr basePath)
{
BifernoRec	*bRecP;
XErr		err = noErr;
char		*strP;

	if (bRecP = (BifernoRecP)api_data)
	{	if (timeoutP)
			*timeoutP = bRecP->timeOut;
		if (currentThreadsP)
			*currentThreadsP = bRecP->curThreads;
		if (maxThreadsP)
			*maxThreadsP = bRecP->maxThreads;
		if (basePath)
		{	CEquStr(basePath, bRecP->mainFilePath);
			if (strP = strrchr(basePath, '/'))
				basePath[strP - basePath + 1] = 0;
			else
				basePath[0] = 0;
			CSubstitute(basePath, ':', '/');
			err = CheckPath(basePath, true);
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_SetFileCacheState(long api_data, Boolean toCache)
{
BifernoRec	*bRecP;
XErr		err = noErr;
	
	if (bRecP = (BifernoRecP)api_data)
	{	if (toCache)
			bRecP->curFile.dontCache = false;
		else
			bRecP->curFile.dontCache = true;
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
// path must be absolute without file:// behind (call BAPI_RealPath before)
XErr	BAPI_NativePath(long api_data, XFilePathPtr path)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;

	if (*path == '/')
	{	
	#ifdef __MAC_XLIB__
		CEquStr(path, path + 1);
		CSubstitute(path, '/', ':');
	#elif __UNIX_XLIB__
		
	#else
		FilePathXLibToWin32(path);
	#endif
	}
	else
		err = XError(kBAPI_Error, Err_AbsolutePathRequired);

return err;
}

//===========================================================================================
// path must be absolute
XErr	BAPI_BifernoPath(long api_data, XFilePathPtr path)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
int			pLen;

	#ifdef __MAC_XLIB__
		{
		int		t = FILE_HD_PREFIX_LEN + 1;
		
		pLen = CSubstitute(path, ':', '/');
		CopyBlock(path + t, path, pLen);
		CopyBlock(path, FILE_HD_PREFIX, FILE_HD_PREFIX_LEN);
		*(path + FILE_HD_PREFIX_LEN) = '/';
		*(path + pLen + t) = 0;
		}
	#elif __UNIX_XLIB__
		pLen = CLen(path);
		CopyBlock(path + FILE_HD_PREFIX_LEN, path, pLen);
		CopyBlock(path, FILE_HD_PREFIX, FILE_HD_PREFIX_LEN);
		*(path + pLen + FILE_HD_PREFIX_LEN) = 0;
	#else
		pLen = FilePathWin32ToXLib(path);
		CopyBlock(path + FILE_HD_PREFIX_LEN, path, pLen);
		CopyBlock(path, FILE_HD_PREFIX, FILE_HD_PREFIX_LEN);
		*(path + pLen + FILE_HD_PREFIX_LEN) = 0;
	#endif

return err;
}

//===========================================================================================
XErr	BAPI_RealPath(long api_data, XFilePathPtr path, Boolean resolveAlias)
{
XErr		err = noErr;
XFilePath	tempStr;
long		pathLen;

	pathLen = CLen(path);
	if ((pathLen > 6) && NOT(CompareBlock(path, "file://", 7)))
		CEquStr(path, path + 6);
	else
	{
	Boolean		fromRoot;
	
		if (pathLen && (*path == '/'))
			fromRoot = true;
		else
			fromRoot = false;
		if NOT(err = BAPI_GetCurrentBasePath(api_data, tempStr, fromRoot))
		{	if (fromRoot && *tempStr)
				CAddStr(tempStr, path + 1);		// remove '/'
			else
				CAddStr(tempStr, path);
			CEquStr(path, tempStr);
		}
	}
	if NOT(err)
		err = CheckPath(path, resolveAlias);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_Exit(long api_data)
{
BifernoRec	*bRecP;

	if (bRecP = (BifernoRecP)api_data)
	{	
		bRecP->_exit = true;
	}
		
return noErr;
}

//===========================================================================================
XErr	BAPI_OnError(long api_data, long mode, char *onErrorFunc, Boolean *stateP)
{
BifernoRec	*bRecP;
XErr		err = noErr;
	
	if (bRecP = (BifernoRecP)api_data)
	{	if (gsDispatcherData.errConstructor)
		{	switch (mode)
			{
				case kResume:
					bRecP->onErrorResume++;
					if (onErrorFunc && *onErrorFunc)
						CEquStr(bRecP->onErrorFunc, onErrorFunc);
					break;
				case kSuspend:
					if (--bRecP->onErrorResume < 0)
					{	err = XError(kBAPI_Error, Err_OnErrorNotBalanced);
						bRecP->onErrorResume = 0;
					}
					break;
				case kGetState:
					*stateP = (bRecP->onErrorResume != 0);
					break;
				case kGetFunction:
					CEquStr(onErrorFunc, bRecP->onErrorFunc);
					break;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_JavaLoadJVM(long api_data)
{
//#ifdef JAVA_ENABLED
BifernoRec	*bRecP;
void		*taskID;
XErr		err = noErr;

	if (bRecP = (BifernoRecP)api_data)
		taskID = bRecP->userData;
	else
		taskID = 0;
	err = XLibInit_JVM_API(HTTPControllerLog, taskID, gsDispatcherData.javaHelperRef);
	
return err;
//#else
//	return XError(kBAPI_Error, Err_JavaUnavailable);
//#endif
}

//===========================================================================================
XErr	BAPI_JavaGetCurrentJNIEnv(long api_data, void **envPPtr)
{
XErr		err = noErr;
BifernoRec	*bRecP;
		
	if (bRecP = (BifernoRecP)api_data)
	{	XThreadsGetThreadInfo(nil, (long*)envPPtr);
		if NOT(*envPPtr)
			err = XLibGetMainJVM_API(envPPtr);	// we are not in a thread?
	}
	else
		err = XLibGetMainJVM_API(envPPtr);
	
	if (NOT(*envPPtr) && NOT(err))
		err = XError(kBAPI_Error, Err_JavaNotAvailable);
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_RegisterSymbol(long api_data, long classID, char *symbolName, long address)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr					err = noErr;
PluginRecord			*plugRecP;
long					objID;
DLMRef					list;

	if (classID)
	{	plugRecP = &gClassRecordBlockP[classID-1];
		if NOT(plugRecP->symbolList)
			err = DLM_Create(&plugRecP->symbolList, NAMECS_LIST, true);
		if NOT(err)
		{	list = plugRecP->symbolList;
			if (objID = DLM_GetObjID(list, symbolName, nil, nil))
				DLM_SetUserData(list, objID, address);
			else
				DLM_NewObj(list, symbolName, nil, 0, address, kFixedSize, &err);
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchClass);

return err;
}

//===========================================================================================
XErr	BAPI_GetSymbol(long api_data, long classID, char *symbolName, long *addressP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr					err = noErr;
PluginRecord			*plugRecP;
long					objID;
DLMRef					list;

	if (classID)
	{	plugRecP = &gClassRecordBlockP[classID-1];
		if (list = plugRecP->symbolList)
		{	if (objID = DLM_GetObjID(list, symbolName, nil, nil))
				err = DLM_GetInfo(list, objID, nil, addressP, nil);
			else
				err = XError(kBAPI_Error, Err_BAPI_SymbolNotFound);
		}
		else
			err = XError(kBAPI_Error, Err_BAPI_SymbolNotFound);
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchClass);

return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_GetPluginRunData(long api_data, long classID, long *class_thread_dataP)
{
XErr		err = noErr;
BifernoRec	*bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if ((classID > 0) && (classID <= gsDispatcherData.totClass))
		*class_thread_dataP = bRecP->class_thread_dataP[classID-1].plugin_run_data;
	else
		err = XError(kBAPI_Error, Err_NoSuchClass);

return err;
}

//===========================================================================================
XErr	BAPI_SetPluginRunData(long api_data, long classID, long plugin_run_data)
{
XErr		err = noErr;
BifernoRec	*bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if ((classID > 0) && (classID <= gsDispatcherData.totClass))
		 bRecP->class_thread_dataP[classID-1].plugin_run_data = plugin_run_data;
	else
		err = XError(kBAPI_Error, Err_NoSuchClass);

return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_GetConfig(long api_data, char *configName, char *result, long *resultLenP, Boolean *isDefP)
{
XErr		err = noErr;
ObjRef		objRef;
Boolean		isDef;
	
	if (resultLenP)
		*resultLenP = 0;
	if NOT(err = BAPI_IsVariableDefined(api_data, configName, APPLICATION, &isDef, &objRef))
	{	if NOT(OBJ_CLASSID(objRef))
			isDef = false;
		if (isDef)
			err = BAPI_ObjToString(api_data, &objRef, result, resultLenP, 255, kExplicitTypeCast);
		if (isDefP)
			*isDefP = isDef;
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetBooleanConfig(long api_data, char *configName, Boolean *resultP, Boolean *isDefP)
{
XErr		err = noErr;
ObjRef		objRef;
Boolean		isDef;

	if NOT(err = BAPI_IsVariableDefined(api_data, configName, APPLICATION, &isDef, &objRef))
	{	if NOT(OBJ_CLASSID(objRef))
			isDef = false;
		if (isDef)
			err = BAPI_ObjToBoolean(api_data, &objRef, resultP, kExplicitTypeCast);
		if (isDefP)
			*isDefP = isDef;
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetIntConfig(long api_data, char *configName, long *resultP, Boolean *isDefP)
{
XErr		err = noErr;
ObjRef		objRef;
Boolean		isDef;

	if NOT(err = BAPI_IsVariableDefined(api_data, configName, APPLICATION, &isDef, &objRef))
	{	if NOT(OBJ_CLASSID(objRef))
			isDef = false;
		if (isDef)
			err = BAPI_ObjToInt(api_data, &objRef, resultP, kExplicitTypeCast);
		if (isDefP)
			*isDefP = isDef;
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetUnsignedConfig(long api_data, char *configName, unsigned long *resultP, Boolean *isDefP)
{
XErr		err = noErr;
ObjRef		objRef;
Boolean		isDef;

	if NOT(err = BAPI_IsVariableDefined(api_data, configName, APPLICATION, &isDef, &objRef))
	{	if NOT(OBJ_CLASSID(objRef))
			isDef = false;
		if (isDef)
			err = BAPI_ObjToUnsigned(api_data, &objRef, resultP, kExplicitTypeCast);
		if (isDefP)
			*isDefP = isDef;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_GetSID(long api_data, char *SIDStr, char *XIDStr)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	if (bRecP = (BifernoRecP)api_data)
	{	if (bRecP->application.sessionOK)
		{	if (SIDStr)
				CEquStr(SIDStr, bRecP->SID);
			if (XIDStr)
				CLongNumToString(bRecP->XID, XIDStr);
		}
		else
		{	if (SIDStr)
				*SIDStr = 0;
			if (XIDStr)
				*XIDStr = 0;
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_SetSID(long api_data, char *SIDStr, char *XIDStr, Boolean isNew)
{
BifernoRec	*bRecP;
XErr		err = noErr;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
	if (bRecP->application.sessionOK)
	{	if NOT(*bRecP->SID)
		{	long	tLen;
			char	*tP;
			int		ch;
			
			if (tLen = CLen(SIDStr))
			{	tP = SIDStr;
				do {
					if (((ch = *tP) != '.') && (ch != '-') && (ch != ':') && ((ch < '0') || (ch > '9')) && ((ch < 'a') || (ch > 'f')) && ((ch < 'A') || (ch > 'F')))
					{	err = XError(kBAPI_Error, Err_BadBifernoSID);
						break;
					}
					tP++;
				} while (--tLen);
			}
			if NOT(err)
			{	CEquStr(bRecP->SID, SIDStr);
				err = Session_SetList(bRecP, SIDStr, XIDStr);
			}
		}
		bRecP->setNewSID = isNew;
	}
	
return err;
}

//===========================================================================================
XErr	BAPI_CheckSID(long api_data, char *SIDStr, char *XIDStr, Boolean *validP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
LONGLONG	xid;
Boolean		valide = false;
XErr		err = noErr;
//CStr255		ipAddress;

	if (*XIDStr)
	{	//if NOT(err = HTTPControllerGetIPAddress(((BifernoRecP)api_data)->userData, ipAddress))
		{	CStringToLongNum(XIDStr, CLen(XIDStr), &xid);
			if (SIDCheckSum(SIDStr) == xid)
			{	//if (CBegins(SIDStr, ipAddress))
					valide = true;
			}
		}
	}
	
*validP = valide;
return err;
}

//===========================================================================================
XErr	BAPI_GetIndSID(long api_data, long index, char *SIDStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
BifernoRec	*bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	err = GetIndSessionSID(bRecP, index, SIDStr);

return err;
}

//===========================================================================================
XErr	BAPI_SessionVariableToString(long api_data, char *SIDStr, char *varName, char *strP, long *strLenP, long maxLen)
{
XErr		err = noErr;
BifernoRec	*bRecP;
ObjRef		objRef;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if NOT(err = ListFromSID(&bRecP->application, SIDStr, &OBJ_LIST(objRef)))
	{	if (OBJ_ID(objRef) = DLM_GetObjID(OBJ_LIST(objRef), varName, nil, &OBJ_CLASSID(objRef)))
			err = BAPI_ObjToString(api_data, &objRef, strP, strLenP, maxLen, kExplicitTypeCast);
		else if (strLenP)
			*strLenP = 0;
	}

return err;
}
#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
/*XErr	BAPI_GetTimeout(long api_data, unsigned long *timeOutP)
{
XErr		err = noErr;
BifernoRec	*bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if (timeOutP)
		*timeOutP = bRecP->timeOut;

return err;
}
*/
//===========================================================================================
XErr	BAPI_GetCurrentScriptStatus(long api_data, long *statusP)
{
BifernoRec	*bRecP = (BifernoRec*)api_data;

	if (bRecP->currentCtx._stop)
		*statusP = kSTOPPED;
	else if (bRecP->_exit)
		*statusP = kEXITED;
	if (bRecP->currentCtx._stop)
		*statusP = kRUNNING;

return noErr;
}

//===========================================================================================
XErr	BAPI_SetTimeout(long api_data, unsigned long newTimeOut)
{
XErr		err = noErr;
BifernoRec	*bRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
	bRecP->timeOut = newTimeOut;	// * (60L * 60L);	// minutes to ticks

return err;
}

//===========================================================================================
// Note that this is called with null api_data (i.e. by SendMail)
XErr	BAPI_Yield(long api_data, unsigned long *lastTicksP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	return BifernoYield(lastTicksP);
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BAPI_SetNumberFormat(long api_data, Byte thousSep, Byte decSep)
{
XErr			err = noErr;
BifernoRecP		bRecP;

	if (bRecP = (BifernoRecP)api_data)
	{	if (thousSep != 0xFF)
			bRecP->thousSep = thousSep;
		if (decSep)
			bRecP->decSep = decSep;
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_GetNumberFormat(long api_data, Byte *thousSepP, Byte *decSepP)
{
XErr			err = noErr;
BifernoRecP		bRecP;

	if (bRecP = (BifernoRecP)api_data)
	{	if (thousSepP)
			*thousSepP = bRecP->thousSep;
		if (decSepP)
			*decSepP = bRecP->decSep;
	}
	else
	{	if (thousSepP)
			*thousSepP = 0;
		if (decSepP)
			*decSepP = '.';
	}

return err;
}

//===========================================================================================
XErr	BAPI_GetDateFormat(long api_data, char *formatStr)
{
XErr			err = noErr;
BifernoRecP		bRecP;

	if (bRecP = (BifernoRecP)api_data)
	{	
		CEquStr(formatStr, bRecP->application.dateFormat);
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	BAPI_GetReference(long api_data, char *targetStr, ObjRef *targetObjRefP, BlockRef *targetPropListP)
{
XErr	err = noErr;
Ptr		tempP;
long	tempLen;
CStr63	varName;

	tempP = targetStr;
	tempLen = CLen(targetStr);
	if (targetPropListP)
		*targetPropListP = 0;
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);
	if NOT(err)
		err = EvalVariable(api_data, &tempP, &tempLen, 0, nil, false, false, nil, (ObjRecordP)targetObjRefP, varName, nil, 0, false, targetPropListP/*, nil*/);

return err;
}

//===========================================================================================
XErr	BAPI_DisposePropertyList(long api_data, BlockRef *targetPropListP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	DisposePropListRec(targetPropListP);
	*targetPropListP = 0L;
	
return noErr;
}

//===========================================================================================
XErr	BAPI_ClonePropertyList(long api_data, BlockRef source, BlockRef *destP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
PropertyItem		*sourceItemP, *destItemP;
PropertyListRec 	*sourceListP, *destListP;
int					propSize, tot, i;
long				indexsLen;
XErr			err = noErr;

	sourceListP = (PropertyListRec*)GetPtr(source);
	propSize = sizeof(PropertyListRec) + (sizeof(PropertyItem) * (sourceListP->totItems - 1));
	if (*destP = NewBlockClear(propSize, &err, (Ptr*)&destListP))
	{	LockBlock(*destP);
		CopyBlock(destListP, sourceListP, propSize);
		tot = sourceListP->totItems;
		sourceItemP = &sourceListP->item[0];
		destItemP = &destListP->item[0];
		for (i = 0; i < tot; i++, sourceItemP++, destItemP++)		// right to left!
		{	if (sourceItemP->propertyIDXBlockRef)
			{	destItemP->propertyDim = sourceItemP->propertyDim;
				indexsLen = sizeof(ArrayIndexRec) * destItemP->propertyDim;
				if (destItemP->propertyIDXBlockRef = NewBlock(indexsLen, &err, (Ptr*)&destItemP->propertyIDXPtr))
					CopyBlock(destItemP->propertyIDXPtr, sourceItemP->propertyIDXPtr, indexsLen);
				else
					break;
			}
		}
		if (err)
			DisposePropListRec(destP);
		else
			UnlockBlock(*destP);
	}
	
return err;
}

//===========================================================================================
static long	_GetPropertyClassID(PropertyItem *propItemP)
{
//XErr	err = noErr;
long	arLevel, propClassID;

	if (propItemP->membIdent.doc.returnClassID == gsDispatcherData.arrayConstructor)
	{	arLevel = propItemP->membIdent.doc.returnAeLevel;
		if (propItemP->propertyDim == arLevel)
			propClassID = propItemP->membIdent.doc.returnAeClass;
		else
			propClassID = gsDispatcherData.arrayConstructor;
	}
	else
		propClassID = propItemP->membIdent.doc.returnClassID;

return propClassID;
}

//===========================================================================================
XErr	BAPI_ApplyPropertyList(long api_data, ObjRef *targetP, BlockRef targetPropList, long mode, Boolean skipLast, ObjRef *obj2P)
{	
XErr			err = noErr;
PropertyListRec *propertyList;
long			t, i, totProperties;
PropertyItem	*propertyItemP;
ObjRecord		valObj, tempObjRef;

	LockBlock(targetPropList);
	propertyList = (PropertyListRec*)GetPtr(targetPropList);
	if (propertyList && (totProperties = propertyList->totItems))
	{	if (mode == GET)
		{	propertyItemP = &propertyList->item[0];
			if (skipLast)
				totProperties--;
			tempObjRef = *(ObjRecordP)targetP;
			for (i = 0; i < totProperties; i++, propertyItemP++)		// left to right
			{	propertyItemP->membIdent.objRef = tempObjRef;
				INVAL(tempObjRef);
				err = CL_GetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyDim, propertyItemP->propertyIDXPtr, &tempObjRef);
			}
			if NOT(err)
			{	if (skipLast)
					propertyItemP->membIdent.objRef = tempObjRef;
				*obj2P = *(ObjRef*)&tempObjRef;
			}
		}
		else
		{	tempObjRef = *(ObjRecordP)obj2P;
			propertyItemP = &propertyList->item[totProperties-1];
			for (i = (totProperties-1); (i >= 0) && NOT(err); i--, propertyItemP--)	// right to left!
			{	if (tempObjRef.classID != (t = _GetPropertyClassID(propertyItemP)))
				{	INVAL(valObj);
					err = CL_TypeCast(api_data, &tempObjRef, t, &valObj, kImplicitTypeCast);
				}
				else
					valObj = tempObjRef;
				if NOT(err)
				{	if (err = CL_SetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyDim, propertyItemP->propertyIDXPtr, &valObj))
						NewMsgRecord(api_data, kSETPROPERTY, propertyItemP->membIdent.doc.name, 0, 0);
					else
						tempObjRef = propertyItemP->membIdent.objRef;
				}
			}
		}
	}
	else
		*obj2P = *targetP;
	UnlockBlock(targetPropList);
	
return err;
}

//===========================================================================================
XErr	BAPI_GetPropertyListNames(long api_data, BlockRef targetPropList, BlockRef *resultP, long *resultLenP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
PropertyListRec *propertyList;
long			propertyDim, id, i, j, totProperties;
PropertyItem	*propertyItemP;
CStr63			idStr;
BufferID		buffID;

	LockBlock(targetPropList);
	propertyList = (PropertyListRec*)GetPtr(targetPropList);
	if (buffID = BufferCreate(256, &err))
	{	if (propertyList && (totProperties = propertyList->totItems))
		{	propertyItemP = &propertyList->item[0];
			for (i = 0; i < totProperties; i++, propertyItemP++)
			{	if (err = BufferAddCString(buffID, ".", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(buffID, propertyItemP->membIdent.doc.name, NO_ENC, 0))
					goto out;
				if (propertyDim = propertyItemP->propertyDim)
				{	for (j = 0; j < propertyDim; j++)
					{	if (err = BufferAddCString(buffID, "[", NO_ENC, 0))
							goto out;
						if (id = propertyItemP->propertyIDXPtr[j].ind)
						{	CNumToString(id, idStr);
							if (err = BufferAddCString(buffID, idStr, NO_ENC, 0))
								goto out;
						}
						else
						{	if (err = BufferAddCString(buffID, "\"", NO_ENC, 0))
								goto out;
							if (err = BufferAddCString(buffID, propertyItemP->propertyIDXPtr[j].ind_name, NO_ENC, 0))
								goto out;
							if (err = BufferAddCString(buffID, "\"", NO_ENC, 0))
								goto out;
						}
						if (err = BufferAddCString(buffID, "]", NO_ENC, 0))
							goto out;
					}
				}
			}
			if (err = BufferAddChar(buffID, 0))
				goto out;
		}
	}
	UnlockBlock(targetPropList);

out:
if (err)
	BufferFree(buffID);
else
{	*resultP = BufferGetBlockRef(buffID, resultLenP);
	BufferClose(buffID);
	(*resultLenP)--;	// 0 termination		
}
return err;
}

//===========================================================================================
XErr	BAPI_GetPropertyListClassID(long api_data, BlockRef targetPropList, long *classIDP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
long			returnAeLevel, totProperties;
PropertyListRec *propertyList;
PropertyItem	*propertyItemP;

	propertyList = (PropertyListRec*)GetPtr(targetPropList);
	if (totProperties = propertyList->totItems)
	{	propertyItemP = &propertyList->item[totProperties-1];
		*classIDP = propertyItemP->membIdent.doc.returnClassID;
		returnAeLevel = propertyItemP->membIdent.doc.returnAeLevel;
		if (returnAeLevel && (returnAeLevel == propertyItemP->propertyDim))
			*classIDP = propertyItemP->membIdent.doc.returnAeClass;
		else
			*classIDP = propertyItemP->membIdent.doc.returnClassID;
	}
	else
		*classIDP = 0;	
	
return err;
}

//===========================================================================================
XErr	BAPI_MakeRef(long api_data, ObjRef *objRefP, ObjRef *targetP)
{
XErr	err = noErr;
//CStr255	name;

	if (ref_NewReference)
	{	//if NOT(err = BAPI_GetObjInfo(api_data, objRefP, nil, name))
		//{	if (*name)
		err = ref_NewReference(api_data, objRefP, nil, targetP);
		//	else
		//		err = XError(kBAPI_Error, Err_IllegalRef);
		//}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalOperation);
		
return err;
}

//===========================================================================================
Boolean	BAPI_IsReference(long api_data, ObjRef *objRefP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
	return (Boolean)(OBJ_CLASSID_P(objRefP) == gsDispatcherData.refConstructor);
}

//===========================================================================================
XErr	BAPI_GetReferenceTarget(long api_data, ObjRefP objRef, ObjRefP targetP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;

	if (OBJ_CLASSID_P(objRef) == gsDispatcherData.refConstructor)
		err = ref_GetTarget(api_data, objRef, targetP, true);
	else
		*targetP = *objRef;

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*XErr	BAPI_GetArguments(long api_data, int stackIndex, ObjRefP resultArray)
{
	XErr			err = noErr;
	DLMRef			listID;
	BifernoRecP		bRecP;
	int				i, totInputs;
	ObjRecord		objRec;
	ObjRef			tempObjRef;
	CStr255			name;
	Boolean			sorted = false;
	
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	INVAL_P(resultArray);
	if NOT(err = BAPI_ArrayToObj(api_data, true, nil, 0, nil, nil, resultArray))
	{
		if not(err = GetVariableList(api_data, LOCAL, &listID, false, 1))
		{
			totInputs = bRecP->totInputs;			
			objRec.list = listID;
			objRec.type = VARIABLE;
			objRec.scope = LOCAL;
			for (i = 1; (i <= totInputs) && not(err); i++)
			{
				if NOT(err = DLM_GetIndObj(listID, i, nil, nil, 0, &objRec.classID, nil, name, sorted, false))
				{
					objRec.id = i;
					INVAL(tempObjRef);
					if not(err = ref_NewReference(api_data, (ObjRefP)&objRec, nil, &tempObjRef))
					{
						err = BAPI_ArrayAddElement(api_data, resultArray, name, &tempObjRef);
					}
				}
			}
		}	
	}
	return err;
}*/
