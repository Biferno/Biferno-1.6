/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: biferno_server_unix.c,v 1.24 2006-10-09 10:41:57 valfer Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#include "XFilesUnixPrivate.h"

#include 	"HTTPMgr.h"
#include 	"HTTPMrgNet.h"

#include <signal.h>
#include <syslog.h>
#include <errno.h>
#include <pwd.h>
#include <sys/time.h> 
#include <sys/resource.h> 
#include <unistd.h> 
#include <stdlib.h>

XFileRef	gLogRefNum, gExtraLogRefNum, gCurrentLogRefNum;

static HTTPControllerP	gHttpControllerP;
static BlockRef			gHttpControllerBlock;

static Boolean	gsSilent;
static long		gMaxUsers;

CStr255		gsUpSinceStr;

#define	MAXFD				64
#define	BIFERNO_USER		"biferno"
#define	PROGRAM_NAME		"bifernod"

extern	Boolean		gExitForced;

//===========================================================================================
static void _ToOEM(Byte *textP, long len)
{
	if (len)
	{	do {
			if (*textP == 0xA0)
				*textP = ' ';	// nbsp
			textP++;
			len--;
		} while (len > 0);
	}
}

//===========================================================================================
static void	_write_stop_ok(void)
{
char		aCStr[MAX_LOG_STRING+1];

	if (gExtraLogRefNum)
	{	FormatLogString(aCStr, kQuit, 'o', "", "", "graceful", 0, nil, nil);
		gCurrentLogRefNum = gLogRefNum;
		HTTPControllerLog(0, aCStr);
	}
	DeletePID(PROGRAM_NAME);
}

//===========================================================================================
static void _PrintUsage(void)
{
	printf("Usage:\n");
	printf("bifernod\t\t\tStart biferno server as daemon\n");
	printf("bifernod -i \t\t\tStart biferno server in terminal mode\n");
	printf("bifernod -f filePath\t\tProcess filePath and exit\n");
	printf("bifernod -p \t\t\tProcesses from stdin and exit\n");
	printf("bifernod -v \t\t\tBiferno version\n");
	printf("bifernod --help\t\t\tThis message\n");
}

//===========================================================================================
static void	_DaemonInit(char *pname, char *bifernohomePath)
{
pid_t	pid;
int		i;

	if ((pid = fork()) != 0)
		exit(0);		// parent terminates
	setsid();
	signal(SIGHUP, SIG_IGN);
	if ((pid = fork()) != 0)
		exit(0);		// 1st child terminates
		
	chdir(bifernohomePath);
	umask(0);
	for (i = 0; i < MAXFD; i++)
		close(i);
	openlog(pname, LOG_PID, LOG_DAEMON);
}

//===========================================================================================
static XErr	_Terminate(Boolean toShutDown, XErr theError, long threadsToRemain, Boolean xInited)
{
XErr		err = noErr;
	
	if (toShutDown)
	{	if (gHttpControllerP->ShutDown)
			err = gHttpControllerP->ShutDown(0);
		if (err && NOT(theError))
			theError = err;
	}
	if NOT(gsSilent)
		HTTPControllerLog(0, "Exiting...\n");
	if (theError)
	{	CStr255	errStr;

		XErrorGetDescr(theError, errStr, nil);
		HTTPControllerLog(0, errStr);
		
	}
	_write_stop_ok();
	if (gLogRefNum)
	{	UnlockXFile(gLogRefNum, 0, -1);
		EndLog(&gLogRefNum);
	}
	if (gExtraLogRefNum)
		EndLog(&gExtraLogRefNum);
	if (gHttpControllerBlock)
		DisposeBlock(&gHttpControllerBlock);
	if (xInited)
		XEnd(threadsToRemain);

return err;
}

#pragma mark-
//===========================================================================================
/*static void	MonitorRequest(long socketRef, BlockRef block, long totLen, long userData)
{
Ptr		requestP;
	
	requestP = GetPtr(block);
	printf(requestP);
}

//===========================================================================================
static void*	MonitorThread(void* paramData)
{
CStr255		errString;
XErr		err = noErr;

	err = XServerLoop(BIFERNO_MONITOR_PORT, gMaxUsers, MonitorRequest, 0L, true, false, nil, errString);
}

//===========================================================================================
static XErr	StartMonitorThread(void)
{
XErr			err = noErr;
unsigned long 	monitorThreadID;

	err = XNewThread(&monitorThreadID, 0, MonitorThread, 1024L * 256L, nil);
}
*/
#pragma mark-
//===========================================================================================
static XErr	_MyPrintf(char *aCStr)
{	
BlockRef	resultStringBlock;
long		resultLen;
Ptr			p;
XErr		err = noErr;
	
	if NOT(err = SubstituteExt(aCStr, CLen(aCStr), &resultStringBlock, &resultLen, "%", 1, "%%", 2, true, false))
	{	p = GetPtr(resultStringBlock);
		p[resultLen] = 0;
		printf(p);
		DisposeBlock(&resultStringBlock);
	}
	
return err;
}

//===========================================================================================
XErr	HTTPControllerLog(void *taskID, char *outPutStr)
{
XErr		err = noErr;
CStr255		aCStr;
long		tLen;
HTTPRecord	*httpRecordP;

	XThreadsEnterCriticalSection();
	tLen = CLen(outPutStr);
	if (tLen > 254)
	{	CopyBlock(aCStr, outPutStr, 251);
		aCStr[251] = '.';
		aCStr[252] = '.';
		aCStr[253] = '.';
		aCStr[254] = 0;
	}
	else
	{	CopyBlock(aCStr, outPutStr, tLen);
		aCStr[tLen] = 0;
	}
	CAddChar(aCStr, '\n');
	if NOT(gsSilent)
	{	if (taskID)
		{	httpRecordP = (HTTPRecord*)taskID;
			if (httpRecordP->param)
				err = BufferAddCString(httpRecordP->param, aCStr, NO_ENC, 0);
			else
				err = _MyPrintf(aCStr);
		}
		else
			err = _MyPrintf(aCStr);
	}
	if (gCurrentLogRefNum)
		err = CStringToLog(gCurrentLogRefNum, aCStr, false);
	XThreadsLeaveCriticalSection();
	
return err;
}

//===========================================================================================
XErr HTTPControllerWindowOutput(void *taskID, Ptr textP, long len)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(taskID)
#endif
XErr		err = noErr;
BlockRef	resultStringBlock;
long		resultLen;
Ptr			tempP, resultP;
	
	if (len)
	{	if NOT(err = SubstituteExt(textP, len, &resultStringBlock, &resultLen, "%", 1, "%%", 2, true, false))
		{	resultP = GetPtr(resultStringBlock);
			if (resultLen)
			{	// Unix printf doesn't like CRs
				tempP = resultP;
				do {
					if (*tempP == '\r')
						*tempP = '\n';
					tempP++;
				} while (--resultLen);
				printf(resultP);
			}
			DisposeBlock(&resultStringBlock);
		}
	}

return err;
}

//===========================================================================================
XErr HTTPControllerWindowOutputExt(void *taskID, BlockRef bufferH, long len)
{
Ptr			textP = GetPtr(bufferH);
XErr		err = noErr;

	if (len)
	{	textP = GetPtr(bufferH);
		ZapNewLines((Byte*)textP, &len);
		if (len)
		{	_ToOEM((Byte*)textP, len);
			err = HTTPControllerWindowOutput(taskID, textP, len);
		}
	}
	DisposeBlock(&bufferH);
	
return err;
}

//===========================================================================================
static XErr	_ReloadHook(long uData)
{
#pragma unused(uData)
XErr		err = noErr;
char		aCStr[MAX_LOG_STRING+1];

	FormatLogString(aCStr, kReload, 'i', "", "", "previously posted", 0, nil, nil);
	HTTPControllerLog(0, aCStr);
	err = gHttpControllerP->ServerStateChanged(0, kReload, nil);
	FormatLogString(aCStr, kReload, 'o', "", "", "previously posted", 0, nil, nil);
	HTTPControllerLog(0, aCStr);
	
return err;
}

//===========================================================================================
static void	ProcessClientRequest(long socketRef, BlockRef block, long totLen, long userData)
{
HTTPRecord		httpRecord, *httpRecordP;
XErr			err = noErr;
CStr255			aCStr;
CStr63			appName;
Boolean			wasSilent, toQuit;
BlockRef		tblock;
long			tLen;
LONGLONG		uniqueTag;
CStr255			ip_addr, host, sid;

	toQuit = false;
	if NOT(err = GetClientRequest(0, socketRef, block, totLen, userData, &httpRecord, &uniqueTag, ip_addr, host))
	{	httpRecordP = &httpRecord;
		if (httpRecord.command)
		{	*aCStr = 0;
			if (wasSilent = gsSilent)
				gsSilent = false;
			switch(httpRecord.command)
			{	case kFlush:
					httpRecord.param = BufferCreate(255, &err);
					BufferAddLong(httpRecord.param, 0);		// final length (fill it later)
					gHttpControllerP->ServerStateChanged(&httpRecord, httpRecord.command, nil);
					break;
				case kReload:
					httpRecord.param = BufferCreate(255, &err);
					BufferAddLong(httpRecord.param, 0);			// final length (fill it later)
					BufferAddCString(httpRecord.param, "Reload posted\n", NO_ENC, 0);
					// Note: reload must happen in the main thread
					XServerSetOnceHook(_ReloadHook, 0);
					break;
				case kQuit:
					toQuit = true;
					CEquStr(aCStr, "Ok, biferno stopped");
					break;
				/*case kQuitForced:
					gExitForced = true;
					toQuit = true;
					CEquStr(aCStr, "Ok, biferno stopped (forced)");
					break;*/
				case kGetVersion:
					httpRecord.param = BufferCreate(255, &err);
					BufferAddLong(httpRecord.param, 0);		// final length (fill it later)
					gHttpControllerP->ServerStateChanged(&httpRecord, httpRecord.command, nil);
					break;
				case kCheck:
					CEquStr(aCStr, "Biferno running");
					break;
				default:
					CEquStr(aCStr, "Err, unknown command sent to biferno");
					break;
			}
			if (wasSilent)
				gsSilent = true;
			if (NOT(*aCStr) && NOT(httpRecord.param))
				CEquStr(aCStr, "Err, can't display output");
			if (*aCStr)
			{	Ptr		p;
			
				tLen = CLen(aCStr);
				if (tblock = NewBlockLocked(4 + tLen, &err, &p))
				{	*(long*)p = XHostToNetwork(tLen);
					CopyBlock(p + 4, aCStr, tLen);
					HTTPControllerSendReply(&httpRecord, tblock, 4 + tLen);
				}
			}
			else if (httpRecord.param)
			{	
			Ptr			dataPtr;
				
				tblock = BufferGetBlockRefExtSize(httpRecord.param, &tLen, &dataPtr);
				*(long*)dataPtr = XHostToNetwork(tLen - 4);	// prefixed final length
				HTTPControllerSendReply(&httpRecord, tblock, tLen);
				BufferClose(httpRecord.param);
			}
			FormatLogString(aCStr, httpRecord.command, 'o', "", "", "", uniqueTag, nil, nil);
			HTTPControllerLog(0, aCStr);
		}
		else if (gHttpControllerP->Run)
		{	err = gHttpControllerP->Run(&httpRecord, true, uniqueTag, sid, aCStr, appName);
			LogExitRun(&httpRecord, ip_addr, host, aCStr, uniqueTag, sid, appName);
		}
	}
	else
		httpRecordP = nil;

	if (err)
	{	CStr255	errStr;

		XErrorGetDescr(err, errStr, nil);
		HTTPControllerLog(httpRecordP, errStr);
	}
	
	if (toQuit)
		XStopServer();
}

//===========================================================================================
static void	catch_term_signal(int signo)
{
CStr255		aCStr;
char		logString[MAX_LOG_STRING+1];

	sprintf(aCStr, "signal: %d", signo);
	FormatLogString(logString, kQuit, 'o', "", "", aCStr, 0, nil, nil);
	HTTPControllerLog(0, logString);
	
	printf("\nCleaning biferno...\n");
	_write_stop_ok();
	exit(0);
}

//===========================================================================================
static void	catch_generic_signal(int signo)
{
CStr255		aCStr;
char		logString[MAX_LOG_STRING+1];

	//sprintf(aCStr, "------------------------> signal: %d\n", signo);
	//HTTPControllerLog(0, aCStr);
	sprintf(aCStr, "signal: %d", signo);
	FormatLogString(logString, kQuit, '-', "", "", aCStr, 0, nil, nil);
	HTTPControllerLog(0, logString);
	switch(signo)
	{
		case SIGCHLD:
		case SIGALRM:
		case SIGUSR1:
		case SIGUSR2:
		case SIGTTIN:
		case SIGTTOU:
			break;
			
		default:
			exit(1);
	}
}

//===========================================================================================
/*static void	catch_EXC_BAD_ACCESS_signal(int signo)
{
long	bytesWritten, tLen;
	
	bytesWritten = 1000;
}
*/
//===========================================================================================
static void	catch_pipe_signal(int signo)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(signo)
#endif
}

#define	IN_SIZE	4096
//===========================================================================================
static XErr	_PipeToFile(char *fileToProcess, int *tempFDP)
{
static char	inBuffer[IN_SIZE];

XErr	err = noErr;

	getcwd(fileToProcess, 255);
	CAddStr(fileToProcess, "/temp.XXXXXX");
	errno = 0;
	*tempFDP = mkstemp(fileToProcess);
	if (*tempFDP == -1)
		err = errno;
	else
	{	while(fgets(inBuffer, IN_SIZE-1, stdin))
		{
			write(*tempFDP, inBuffer, CLen(inBuffer));
		}
	}
	
return err;
}

//===========================================================================================
int main(int argc, char *argv[])
{
XErr				err = 0;
CStr255				logFilePath, logExtraFilePath, serverPathCStr, fileToProcess;
Boolean				toShutDown;
struct sigaction	sa_old;
struct sigaction	sa_new;
struct passwd		*ent;
CStr255				bifernoHomeStr;
Boolean				deleteTempFile = false, xInited = false, initLogFile, interactive = false;
int					tempFD;
char				aCStr[MAX_LOG_STRING+1];
uid_t				euid;

	gLogRefNum = gExtraLogRefNum = gCurrentLogRefNum = 0;

	if NOT(ent = getpwnam(BIFERNO_USER))
	{	printf("Bad user name %s\n", BIFERNO_USER);
		exit(1);
	}

	euid = geteuid();
	if (euid && (euid != ent->pw_uid))
	{	printf("Only root can launch biferno: %d (e=%d)\n", getuid(), geteuid());
		exit(1);
	}
	
	gLogRefNum = 0;
	gsSilent = false;
	*fileToProcess = 0;
	toShutDown = false;
	gHttpControllerBlock = 0;
	
	if NOT(GetBifernoHome(bifernoHomeStr))
	{	printf(bifernoHomeStr);
		exit(1);
	}
	
	if (CheckPath(bifernoHomeStr, true))
	{	printf("Biferno Error: BIFERNOHOME is not a valid path\n");
		printf(bifernoHomeStr);
		printf("\n");
		exit(1);
	}
	
	errno = noErr;
	if (setgid(ent->pw_gid) == -1)
		err = errno;	
	if (err)
		goto out;
	
	errno = noErr;
	if (setuid(ent->pw_uid) == -1)
		err = errno;	
	if (err)
		goto out;
	
	switch(argc)
	{
		case 1:
			initLogFile = true;
			gsSilent = true;
			_DaemonInit(argv[0], bifernoHomeStr);
			break;
			
		case 2:
			if NOT(CCompareStrings_cs(argv[1], "-i"))	// interactive
			{	initLogFile = true;
				interactive = true;
			}
			else if NOT(CCompareStrings_cs(argv[1], "-v"))
			{	initLogFile = false;
				CEquStr(fileToProcess, "Biferno version: ");
				BEngineAPI_GetVersions(aCStr, nil, nil);
				CAddStr(fileToProcess, aCStr);
				CAddChar(fileToProcess, '\n');
				printf(fileToProcess);
				return 0;
			}
			else if NOT(CCompareStrings_cs(argv[1], "-p"))
			{	if (err = _PipeToFile(fileToProcess, &tempFD))
					goto out;
				gsSilent = true;
				deleteTempFile = true;
			}
			else
			{	_PrintUsage();
				return 0;
			}
			break;
	
		case 3:
			initLogFile = false;
			if NOT(CCompareStrings_cs(argv[1], "-f"))
			{	if (*(argv[2]) == '/')
					CEquStr(fileToProcess, argv[2]);
				else
				{	getcwd(fileToProcess, 255);
					CAddChar(fileToProcess, '/');
					CAddStr(fileToProcess, argv[2]);
				}
				gsSilent = true;
			}
			else
			{	_PrintUsage();
				return 0;
			}
			break;
			
		default:
			initLogFile = false;
			_PrintUsage();
			return 0;
	}
	
	// Catch dei segnali
 	// SIGINT (for Ctrl-C)
 	sa_new.sa_handler = catch_term_signal;
	sigfillset(&sa_new.sa_mask);
	sa_new.sa_flags = 0;
	sigaction(SIGINT, &sa_new, &sa_old);	

 	// SIGTERM (for kill from console)
 	sa_new.sa_handler = catch_term_signal;
	sigfillset(&sa_new.sa_mask);
	sa_new.sa_flags = 0;
	sigaction(SIGTERM, &sa_new, &sa_old);	

 	// SIGPIPE (for broken pipe signal)
 	sa_new.sa_handler = catch_pipe_signal;
	sigfillset(&sa_new.sa_mask);
	sa_new.sa_flags = 0;
	sigaction(SIGPIPE, &sa_new, &sa_old);	

	// Init XLib	
	xInited = false;
#ifdef __UNIX_XLIB__
	if (err = XInit(bifernoHomeStr))
		goto out;
#else
	if (err = XInit(nil))
		goto out;
#endif
	xInited = true;

	if NOT(err = XGetApplicationFolderPath(logFilePath))
	{	CEquStr(logExtraFilePath, logFilePath);
		CAddStr(logFilePath, "BifernoServer.log");
		CAddStr(logExtraFilePath, "BifernoServer.extra.log");
	}
	else
    {	printf("XGetApplicationFolderPath error %s\n", err);
		exit(1);
    }

	XCurrentDateTimeToString(gsUpSinceStr, kComplete);
	
	if (initLogFile)
	{
	Boolean	isLocked;
	
		CheckLogFile(logFilePath, &isLocked);
		if (isLocked)
		{
		XFileRef	tLogRefNum;
			
			if (interactive)
				printf("biferno is already running!\n");
			else
			{	CAddStr(logFilePath, "_CANT_INIT_BIFERNO_TWICE");
				err = OpenXFile(logFilePath, CREATE_FILE_ALWAYS, READ_WRITE_PERM, false, &tLogRefNum);
			}
			goto out;
		}
		err = InitLog(logFilePath, &gLogRefNum);
		if (err)
			goto out;
		if (gLogRefNum)
		{	if (err = LockXFile(gLogRefNum, 0, -1, false))
				goto out;
		}
		// Extra log (used for startup, reload and flush)
		// if (err = OpenXFile(logExtraFilePath, CREATE_FILE_ALWAYS, READ_WRITE_PERM, false, &gExtraLogRefNum))
		if (err = InitLog(logExtraFilePath, &gExtraLogRefNum))
			goto out;
		gCurrentLogRefNum = gExtraLogRefNum;
	}
	else
		gLogRefNum = 0;
	
	if NOT(gsSilent)
	{	HTTPControllerLog(0, "=------------------------------------------------------------------------------=");
		HTTPControllerLog(0, "Starting Biferno Server...\n");
	}

	gHttpControllerBlock = 0;
	GetXApplicationCurrentDir(serverPathCStr);

	HTTPControllerLog(0, "Initializing...\n");
	
	// bifernoHomeStr[56899] = 0;
	
	gMaxUsers = 32;	// default
	WritePID(PROGRAM_NAME, getpid());
	if (gHttpControllerBlock = NewPtrBlock(sizeof(HTTPController), &err, (Ptr*)&gHttpControllerP))
	{	ClearBlock(gHttpControllerP, sizeof(HTTPController));
		if NOT(err = HTTPControllerRegister(gHttpControllerP))
		{	if (gHttpControllerP->Init)
			{	if NOT(err = gHttpControllerP->Init(0, &gMaxUsers, ((*fileToProcess) != 0), logFilePath))
				{	toShutDown = true;
					if (*fileToProcess)
					{	gsSilent = false;
						err = gHttpControllerP->Process(0L, fileToProcess);
					}
					else
					{	/*sprintf(aCStr, "Starting Monitor on port %d...", BIFERNO_MONITOR_PORT);
						HTTPControllerLog(0, aCStr);
						if (err = StartMonitorThread())
						{	sprintf(aCStr, "Could not start monitor thread, Error:%d", err);
							HTTPControllerLog(0, aCStr);
							err = noErr;
						}
						else
							HTTPControllerLog(0, "ok");*/
						HTTPControllerLog(0, "Accepting connections (AF_LOCAL)...\n");
						gCurrentLogRefNum = gLogRefNum;
						FormatLogString(aCStr, kStartup, '-', "", "", "--------------------------------------------", 0, nil, nil);
						HTTPControllerLog(0, aCStr);
						err = XServerLoop(0L, gMaxUsers, ProcessClientRequest, 0L, true, true, BIFERNO_UNIX_FILE, aCStr);
						FormatLogString(aCStr, kQuit, '-', "", "", "from bifernoctl", 0, nil, nil);
						HTTPControllerLog(0, aCStr);
						gCurrentLogRefNum = gExtraLogRefNum;
						if (err)
						{	if (*aCStr)
							{	HTTPControllerLog(0, aCStr);
								HTTPControllerLog(0, "\n");
							}
							goto out;
						}
					}
				}
			}
		}
	}
	
out:
	_Terminate(toShutDown, err, 0, xInited);
if (deleteTempFile)
{	close(tempFD);
	unlink(fileToProcess);
}
return 0;
}
