/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Application.c,v 1.22 2008-04-21 12:37:01 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"

#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Flower.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Param.h"
#include "Entity.h"
#include "BfrParser.h"
#include "Load.h"
#include "Application.h"
#include "BfrSession.h"
#include "Classes.h"
#include "BifernoErrors.h"
//#include "BJNI.h"
#include "Run.h"

extern DispatcherData	gsDispatcherData;
extern CStr255			gPersistentFolder;

#include <stdio.h>
#include <string.h>

#define	APPL_NAMESTR 		"APPLICATION_NAME"
#define	APPL_NAMESTR_LEN 	16

#define	PRE_FILE 		"file:/"
#define	PRE_FILE_LEN 	6



//===========================================================================================
void	GetApplicationPerstPath(char *appName, char *xName, char *sName)
{
CStr255		baseP, appNameForFile;

#define		PERSISTENT_FILE_DUMP_EXT		".s.bfr"
#define		PERSISTENT_FILE_INTERNAL_EXT	".x.bfr"

	// process appName
	CEquStr(appNameForFile, appName);
	CSubstitute(appNameForFile, ' ', '_');
	CSubstitute(appNameForFile, '/', '-');
	CSubstitute(appNameForFile, ':', '-');
	CSubstitute(appNameForFile, '\t', '-');
	CSubstitute(appNameForFile, '\r', '-');
	CSubstitute(appNameForFile, '\n', '-');
	CSubstitute(appNameForFile, '.', '_');
	CSubstitute(appNameForFile, ',', '_');
	
	CEquStr(baseP, gPersistentFolder);
	CAddStr(baseP, appNameForFile);
	if (xName)
	{	CEquStr(xName, baseP);
		CAddStr(xName, PERSISTENT_FILE_INTERNAL_EXT);
	}
	if (sName)
	{	CEquStr(sName, baseP);
		CAddStr(sName, PERSISTENT_FILE_DUMP_EXT);
	}
}

//===========================================================================================
static XErr	_InitBRecP(Application *applP, long *api_dataP, long *totRunsP)
{
XErr				err = noErr;
BifernoRec			*bRecP;

	*api_dataP = 0L;
	if NOT(err = AllocRunRecord(&bRecP, "", 0, "", 0, "", 0, 0))
	{	bRecP->application = *applP;	
		if NOT(err = SendRunEvents(bRecP, 0, 0, 0, 0, true, totRunsP, false))
			*api_dataP = (long)bRecP;
		else
		{	err = SendExitEvents(bRecP, *totRunsP);
			DisposeRunRecord(bRecP, applP, false, nil, nil, 0, nil);
		}
	}

return err;
}

//===========================================================================================
static XErr	_EndBRecP(long api_data, Application *applP, long totRuns)
{
XErr		err = noErr, err2 = noErr;
BifernoRec	*bRecP;
	
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	else
	{	err2 = SendExitEvents(bRecP, totRuns);
		err = DisposeRunRecord(bRecP, applP, false, nil, nil, 0, nil);
		if (NOT(err) && err2)
			err = err2;
	}
	
return err;
}

//===========================================================================================
static XErr	_DumpList(long api_data, DLMRef serverList, char *applName, LogCallBack logCallBack, void *userData)
{
XErr			err = noErr;
BlockRef		ref;
char			*stringP;
long			constrLen, tot, count, endStrLen, totVarsInServer, stringLen;
XFilePath		filePath;
CStr255			aCStr, eNameStr;
ObjRecord		objRef;
CStr255			name;
int				i;
XFileRef		fileRef;
CStr15			endStr;
CStr63			constructor;
long			eNum, eType;

	if (NOT(err = DLM_GetTotObjs(serverList, &totVarsInServer, false)) && totVarsInServer)
	{	/*CEquStr(filePath, gPersistentFolder);
		CAddStr(filePath, applName);
		CAddStr(filePath, PERSISTENT_FILE_DUMP_EXT);*/
		GetApplicationPerstPath(applName, nil, filePath);
		if NOT(err = OpenXFile(filePath, OPEN_FILE_ALWAYS, READ_WRITE_PERM, false, &fileRef))
		{	LockXFile(fileRef, 0, -1, true);
			count = 4;
			tot = 4;
			if NOT(err = WriteXFile(fileRef, "<?\r\n", &count))
			{	if (totVarsInServer)
				{	ClearBlock(&objRef, sizeof(ObjRecord));
					objRef.list = serverList;
					objRef.scope = PERSISTENT;
					for (i = 1; (i <= totVarsInServer) && NOT(err); i++)
					{	if NOT(err = DLM_GetIndObj(serverList, i, nil, nil, 0, &objRef.classID, &objRef.id, name, true, false))
						{	if NOT(err = BAPI_GetStringBlockExt(api_data, (ObjRefP)&objRef, aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast, kForConstructor))
							{	CAddStr(name, " = ");
								count = CLen(name);
								if NOT(err = WriteXFile(fileRef, name, &count))
								{	tot += count;
									BAPI_NameFromClassID(api_data, objRef.classID, constructor);
									constrLen = CLen(constructor);
									if (CompareBlock(stringP, constructor, constrLen))
									{	CAddStr(constructor, "(");
										constrLen++;
										err = WriteXFile(fileRef, constructor, &constrLen);
										tot += constrLen;
										CEquStr(endStr, ");\r\n");
										endStrLen = CLen(endStr);
									}
									else
									{	CEquStr(endStr, ";\r\n");
										endStrLen = CLen(endStr);
									}
									if NOT(err)
									{	if NOT(err = WriteXFile(fileRef, stringP, &stringLen))
										{	tot += stringLen;
											if NOT(err = WriteXFile(fileRef, endStr, &endStrLen))
												tot += endStrLen;
										}
									}
								}
								BAPI_ReleaseBlock(&ref);
							}
							if (err)
							{	FillErrorStrings(0, 0L, err, nil, eNameStr, nil, nil, nil, nil, nil);
								XErrorGetTypeValue(err, &eNum, &eType);
								sprintf(aCStr, "// Error writing var: %s (%d type %d): %s)\r\n", name, (int)eNum, (int)eType, eNameStr);
								count = CLen(aCStr);
								tot += count;
								err = WriteXFile(fileRef, aCStr, &count);
							}
						}
					}
				}
				if NOT(err)
				{	count = 4;
					if NOT(err = WriteXFile(fileRef, "\r\n?>", &count))
					{	tot += 4;
						if NOT(err)
							SetXEOF(fileRef, tot);
					}
				}
			}
			UnlockXFile(fileRef, 0, -1);
			CloseXFile(&fileRef);
		}
	}

if (err)
{	FillErrorStrings(0, 0L, err, nil, eNameStr, nil, nil, nil, nil, nil);
	XErrorGetTypeValue(err, &eNum, &eType);
	sprintf(aCStr, "Error dumping persistent list: %s (%d type %d): %s)\r\n", name, (int)eNum, (int)eType, eNameStr);
	if (logCallBack)
	{	logCallBack(userData, aCStr);
		err = noErr;
	}
}
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*Boolean	DontServeErrorsFile(BifernoRecP bRecP, XFilePathPtr filePath)
{
char		*errFolderP = bRecP->errFolder;
long		tLen;

	tLen = CLen(errFolderP);
	if (tLen && NOT(CompareBlock(errFolderP, filePath, tLen)))
	{
		return true;
	}

return false;
}
*/
//===========================================================================================
static XErr	_RealPath(BifernoRecP bRecP, XFilePathPtr basePath, XFilePathPtr path, long pathLen, XFilePathPtr resultPath)
{
XErr		err = noErr;

	if ((pathLen > 6) && NOT(CompareBlock(path, "file://", 7)))
		CEquStr(resultPath, path + 6);
	else
	{	if (*path == '/')
			CEquStr(resultPath, bRecP->serverBaseDir);
		else
			CEquStr(resultPath, basePath);
		CAddStr(resultPath, path);
	}
	if NOT(err)
		err = CheckPath(resultPath, true);
	
return err;
}

//===========================================================================================
XErr	FlushAppWithChildren(char *curAppBasePath, Boolean doReload, BlockRef *curSessionCSP)
{
XErr			err = noErr;
long			appObjID, tLen, totObjs;
DLMRef			app_list;
Application 	applRec;
Boolean			all, cs;
Application		*tApplP;
BufferID		buffID;
long			totFlushs, i, size;
BlockRef		blockRef;
CStr255			homeStr;

#ifdef __UNIX_XLIB__
	cs = true;
#else
	cs = false;
#endif

	if (doReload)
		buffID = BufferCreate(sizeof(Application) * 2, &err);
	else
		buffID = 0;
	if NOT(err)
	{	app_list = gsDispatcherData.globApplicationListArray;
		if (NOT(err = DLM_GetTotObjs(app_list, &totObjs, false)) && totObjs)
		{	XGetApplicationFolderPath(homeStr);
			all = NOT(ComparePaths(curAppBasePath, homeStr));
			for (i = 1; (i <= totObjs) && NOT(err); i++)
			{	tLen = sizeof(Application);
				if NOT(err = DLM_GetIndObj(app_list, i, (Ptr)&applRec, &tLen, 0, nil, &appObjID, nil, false, false))
				{	if (all || CBegins(applRec.basePath, curAppBasePath, cs))
					{	if NOT(err = CFFlushFilesMatching(appObjID))
						{	if (doReload)
								err = BufferAddBuffer(buffID, (Ptr)&applRec, sizeof(Application));
						}
					}
				}
			}
		}
		if (NOT(err) && doReload)
		{	blockRef = BufferGetBlockRefExtSize(buffID, &size, (Ptr*)&tApplP);
			LockBlock(blockRef);
			totFlushs = size / sizeof(Application);
			for (i = 0; (i < totFlushs) && NOT(err); i++, tApplP++)
				err = CloseApplication(tApplP, true, nil, 0, curSessionCSP);
		}
		if (buffID)
			BufferFree(buffID);
	}
	
return err;
}

//===========================================================================================
static XErr	GetAConfigPath(BifernoRecP bRecP, char *confName, XFilePathPtr basePath, XFilePathPtr result, Boolean createIfNeeded)
{
XErr			err = noErr;
XFilePath		tempFilePath;
Boolean			isDef;
long			tempFilePathLen;
char			errStr[512];

	*tempFilePath = 0;
	if NOT(err = BAPI_GetConfig((long)bRecP, confName, tempFilePath, &tempFilePathLen, &isDef))
	{	if (isDef && *tempFilePath)
		{	if (err = _RealPath(bRecP, basePath, tempFilePath, tempFilePathLen, result))
			{	if (createIfNeeded && ((err == XError(kXLibError, ErrXFiles_FolderNotFound)) || (err == XError(kXLibError, ErrXFiles_FileNotFound))))
					err = CreateXFolder(result);
				if (err)
				{	CEquStr(errStr, "Cannot find path: \"");
					CAddStr(errStr, tempFilePath);
					CAddStr(errStr, "\" for Application: ");
					CAddStr(errStr, bRecP->application.name);
					NewMsgRecord((long)bRecP, kBIFERNOCONFIG, errStr, 0, 0);
					//TextToErrMessage((long)bRecP, errStr, CLen(errStr), false);
				}
			}
		}
	}

return err;
}

//===========================================================================================
XErr	UpdateApplicationRec(BifernoRecP bRecP)
{
Application *applP = &bRecP->application;
XErr		err = noErr;
long		rest, tLen, objID;
CStr255		tempCStr;
Byte		tStr[2];
Boolean		isDef;

	if NOT(err = BAPI_GetUnsignedConfig((long)bRecP, "SESSION_TIMEOUT", &applP->session_timeout, nil))
	{	
		applP->session_timeout *= 60;	// minute -> seconds
		if (applP->session_timeout < SESSION_GARBAGE_COLLECTION_INTERVAL)
			applP->session_timeout = SESSION_GARBAGE_COLLECTION_INTERVAL;
		if (err = BAPI_GetBooleanConfig((long)bRecP, "SESSION", &applP->sessionOK, nil))
			goto out;
		if (err = BAPI_GetUnsignedConfig((long)bRecP, "MAX_ERRFILES", &applP->maxFilesSaved, nil))
			goto out;
		if (err = BAPI_GetConfig((long)bRecP, "DEVELOPER_IP", applP->devIP, &tLen, nil))
			goto out;
		if (err = BAPI_GetConfig((long)bRecP, "ADMIN_PASSWORD", applP->adminPassword, &tLen, nil))
			goto out;
		rest = 3 - (tLen % 3);
		if ((tLen + rest) <= 48)
		{	BlockRef	resultBlock;
			Ptr			resultP;
			long		resultLen;
		
			if (resultBlock = NewBlockLocked(5 + (4*tLen)/3, &err, (Ptr*)&resultP))
			{	
				resultLen = HTUU_encode((Byte*)applP->adminPassword, tLen, resultP);
				if (resultLen < 255)
					CopyBlock(applP->adminPassword, resultP, resultLen);
				DisposeBlock(&resultBlock);
			}
		}
		else
		{	err = XError(kBAPI_Error, Err_BadSyntax);
			CEquStr(tempCStr, "ADMIN_PASSWORD too long (> 48 chars)");
			NewMsgRecord((long)bRecP, kBIFERNOCONFIG, tempCStr, 0, 0);
			goto out;
		}
		if (err = GetAConfigPath(bRecP, "ERRORS_FOLDER", applP->basePath, applP->errorFolder, true))
			goto out;
		if (err = GetAConfigPath(bRecP, "ERROR_PAGE", applP->basePath, applP->errPagePath, false))
			goto out;
		if (err = GetAConfigPath(bRecP, "DEBUG_PAGE", applP->basePath, applP->debugPagePath, false))
			goto out;

		if (err = GetAConfigPath(bRecP, "FILE_NOT_FOUND_PAGE", applP->basePath, applP->fnfPage, false))
			goto out;
		if (err = BAPI_GetBooleanConfig((long)bRecP, "CACHE", &applP->cacheActive, nil))
			goto out;
		if (err = GetAConfigPath(bRecP, "HEADER", applP->basePath, applP->headerFilePath, false))
			goto out;
		if (err = GetAConfigPath(bRecP, "FOOTER", applP->basePath, applP->footerFilePath, false))
			goto out;
		if (err = GetAConfigPath(bRecP, "ACCESS_CONTROL", applP->basePath, applP->acPath, false))
			goto out;
		if (err = GetAConfigPath(bRecP, "ACCESS_CONTROL_NOACCESS", applP->basePath, applP->acNoAccessPath, false))
			goto out;
		
		// Date Format
		*tempCStr = 0;
		tLen = 255;
		if (err = BAPI_GetConfig((long)bRecP, "DATE_FORMAT", tempCStr, &tLen, nil))
			goto out;
		if (tLen > 15)
		{	tLen = 15;
			tempCStr[tLen] = 0;
		}
		if (*tempCStr)
			CEquStr(applP->dateFormat, tempCStr);
		else
			CEquStr(applP->dateFormat, "d-m-y");
		
		tLen = 255;
		if (err = BAPI_GetConfig((long)bRecP, "WEBMASTER", applP->webMaster, &tLen, nil))
			goto out;
		tLen = 255;
		if (err = BAPI_GetConfig((long)bRecP, "MAIL_HOST", applP->mailHost, &tLen, nil))
			goto out;
		if (err = BAPI_GetBooleanConfig((long)bRecP, "NOTIFY_MAIL_ERR", &applP->notifyMail, nil))
			goto out;
		tLen = 255;
		if (err = BAPI_GetConfig((long)bRecP, "FROM_MAIL", applP->fromMail, &tLen, nil))
			goto out;
		if NOT(*applP->fromMail)
			CEquStr(applP->fromMail, applP->webMaster);
		
		*tempCStr = 0;
		if (err = BAPI_GetConfig((long)bRecP, "ACCESS_CONTROL_REALM", tempCStr, &tLen, nil))
			goto out;
		if (tLen > 63)
		{	tLen = 63;
			tempCStr[tLen] = 0;
		}
		CEquStr(applP->acRealmName, tempCStr);
		if (err = BAPI_GetUnsignedConfig((long)bRecP, "TIMEOUT", &applP->timeOut, nil))
			goto out;
		//if (applP->timeOut && (applP->timeOut < 2))
		//	applP->timeOut = 2;
		applP->timeOut *= (60 * 60);	// minute -> ticks

		tLen = 2;
		if NOT(err = BAPI_GetConfig((long)bRecP, "DECIMAL_SEP", (char*)tStr, &tLen, &isDef))
		{	if (isDef)
				applP->decSep = *tStr;
			else
				applP->decSep = '.';
			tLen = 2;
			if NOT(err = BAPI_GetConfig((long)bRecP, "THOUSAND_SEP", (char*)tStr, &tLen, &isDef))
			{	if (isDef)
				{	if (tLen)
						applP->thousSep = *tStr;
					else
						applP->thousSep = 0;
				}
				else
					applP->thousSep = 0;
			}
		}
		if (err)
			goto out;
		if (objID = DLM_GetObjID(gsDispatcherData.globApplicationListArray, applP->name, nil, nil))
			err = DLM_ModifyObj(gsDispatcherData.globApplicationListArray, objID, (Ptr)applP, sizeof(Application), 0, nil, 0, nil);
	}
	
out:
return err;
}

//===========================================================================================
static void	_RescaleAppId(Byte *userData, long appID)
{
long	*myP;

	myP = &SCRIPT_APPLICATION(userData);
	if (*myP > appID)
		(*myP)--;
}

//===========================================================================================
XErr	CloseApplication(Application *applP, Boolean deleteAlsoObj, LogCallBack logCallBack, void *userData, BlockRef *curSessionCSP)
{				
XErr			err = noErr;
long			appObjID, totSessions, totRuns;
int				j;
DLMRef			dlmRef;
XFilePath		aCStr;
BifernoRecP		bRecP;
BfrDestructRec	destructRec;
CStr255			listName;

	if NOT(err = _InitBRecP(applP, (long*)&bRecP, &totRuns))
	{	destructRec.api_data = (long)bRecP;
		BAPI_SetNumberFormat((long)bRecP, applP->thousSep, applP->decSep);
		if (applP->sessionsArrayList)
		{	if (NOT(err = DLM_GetTotObjs(applP->sessionsArrayList, &totSessions, false)) && totSessions)
			{	destructRec.scope = bRecP->currentCtx.defaultScope = SESSION;
				for (j = 1; (j <= totSessions) && NOT(err); j++)
				{	if (NOT(err = DLM_GetIndObj(applP->sessionsArrayList, j, nil, nil, 0, &dlmRef, nil, listName, false, false)) && *listName)
					{	DLM_Loop(dlmRef, BifernoDestructorCallBack_CheckFlags, (long)&destructRec, true, true);	// destruct biferno objects
						Session_FreeList(&dlmRef, nil, curSessionCSP);
					}
				}
			}
		}
		DLM_DisposeGlobal(&applP->sessionsArrayList, nil, 0L);
		
		destructRec.scope = bRecP->currentCtx.defaultScope = APPLICATION;
		DLM_Loop(applP->list, BifernoDestructorCallBack_CheckFlags, (long)&destructRec, true, true);		// destruct biferno objects
		DLM_DisposeGlobal(&applP->list, VariableDestructor, (long)&destructRec/*0L*/);

		if (applP->persistentList)
		{	err = _DumpList((long)bRecP, applP->persistentList, applP->name, logCallBack, userData);
			destructRec.scope = bRecP->currentCtx.defaultScope = PERSISTENT;
			err = DLM_Close(&applP->persistentList, VariableDestructor, (long)&destructRec/*0*/, true);		// can't have biferno objects inside
		}
		
		DLM_DisposeGlobal(&applP->funcsList, nil, 0);
		destructRec.scope = bRecP->currentCtx.defaultScope = APPLICATION;
		DLM_DisposeGlobal(&applP->classList, DisposeBifernoClass, (long)&destructRec);
		
		/*CEquStr(aCStr, gPersistentFolder);
		CAddStr(aCStr, applP->name);
		CAddStr(aCStr, PERSISTENT_FILE_INTERNAL_EXT);*/
		GetApplicationPerstPath(applP->name, aCStr, nil);
		//CEquStr(aCStr, applP->basePath);
		//CAddStr(aCStr, PERSISTENT_FILE_INTERNAL);
		err = DeleteXFile(aCStr);
		if (err)	// don't stop execution
			err = noErr;

		if (deleteAlsoObj)
		{	if (appObjID = DLM_GetObjID(gsDispatcherData.globApplicationListArray, applP->name, nil, nil))
			{	if NOT(err = DLM_DeleteObj(gsDispatcherData.globApplicationListArray, appObjID, nil, 0))
				{	// nei files in cache c'� scritto l'objID della app e quindi vanno riscalati
					CFLoop(_RescaleAppId, appObjID);
				}
			}
		}
		
		//if (applP->parents)
		//	DisposeBlock(&applP->parents);
		
		_EndBRecP((long)bRecP, applP, totRuns);
	}
	
return err;
}

//===========================================================================================
// old versions of Biferno had perst files in app, not in BifernoHome
// compatibility
static XErr	__CompatibMovePerstFiles(char *basePath, char *appName)
{
XFilePath	old_x_perst, old_s_perst, new_x_perst, new_s_perst;
XErr		err = noErr, err2 = noErr;
Boolean		old_x_perst_exists, old_s_perst_exists;

	// old .x
	CEquStr(old_x_perst, basePath);
	CAddStr(old_x_perst, "biferno_pst.x.bfr");
	old_x_perst_exists = NOT(CheckPath(old_x_perst, true));
	// old .s
	CEquStr(old_s_perst, basePath);
	CAddStr(old_s_perst, "biferno_pst.s.bfr");
	old_s_perst_exists = NOT(CheckPath(old_s_perst, true));
	// new
	GetApplicationPerstPath(appName, new_x_perst, new_s_perst);
	
	// esiste il vecchio e non il nuovo
	if (NOT(CheckPath(old_s_perst, true)) && CheckPath(new_s_perst, true))
	{	err = MoveXFile(old_s_perst, new_s_perst, false);
		if (old_x_perst_exists)
			err2 = MoveXFile(old_x_perst, new_x_perst, false);
	}
	
return err;
}

//===========================================================================================
XErr	GetApplication(BifernoRecP bRecP, char *applicationName, long *applicationObjIDP, XFilePathPtr appBasePath, BlockRef configFilePathBl, Boolean *applicationFirstTimeP, Boolean *dontIncludeServerP, XFilePathPtr filePathErr)
{
long			objID;
XErr			err = noErr;
long			tLen;
Ptr				thisFolderPathP, stringP;
Application 	*applP = &bRecP->application;
XFilePath		aCStr, serverListFilePath;
char			*strP;
DLMRef			globalAppList = gsDispatcherData.globApplicationListArray;

	objID = *applicationObjIDP;
	if (objID)
	{	*applicationFirstTimeP = false;
		tLen = sizeof(Application);
		if (appBasePath)
			CEquStr(aCStr, appBasePath);
		else
			*aCStr = 0;
		if NOT(err = DLM_GetObj(globalAppList, objID, (Ptr)applP, &tLen, 0, nil))
		{	if (*aCStr)
			{	if (strP = strrchr(aCStr, '/'))
				{	*(strP+1) = 0;
					if (CCompareStrings(aCStr, applP->basePath))
						err = XError(kBAPI_Error, Err_ApplicationNameDuplicated);
				}
			}
		}
	}
	else
	{	*applicationFirstTimeP = true;
		*dontIncludeServerP = false;
		applP->totFilesSaved = 0;
		applP->maxFilesSaved = DEFAULT_MAX_ERRFILES;
		if NOT(err = DLM_Create(&applP->list, NAMECS_LIST, true))
		{	if NOT(err = DLM_Create(&applP->sessionsArrayList, NAMECS_LIST, true))
			{	
				// function list
				if NOT(err = DLM_Create(&applP->funcsList, NAMECS_LIST, GLOBAL_LIST))
				{	
					// classesList
					if NOT(err = DLM_Create(&applP->classList, NAMECS_LIST, GLOBAL_LIST))
					{	
						// persistent list
						LockBlock(configFilePathBl);
						thisFolderPathP = GetPtr(configFilePathBl);
						CEquStr(serverListFilePath, thisFolderPathP);
						if (stringP = strrchr(serverListFilePath, '/'))
						{	*(stringP+1) = 0;
							CEquStr(applP->basePath, serverListFilePath);	// path dell'applicazione
							__CompatibMovePerstFiles(applP->basePath, applP->name);
							GetApplicationPerstPath(applP->name, serverListFilePath, nil);
							if NOT(CheckPath(serverListFilePath, true))		// exists
								*dontIncludeServerP = true;
							err = DLM_Load(serverListFilePath, NAMECS_LIST, true, &applP->persistentList);
							if (err)
							{	*dontIncludeServerP = false;
								err = noErr;
							}
							if (err)
								CEquStr(filePathErr, serverListFilePath);
						}
						UnlockBlock(configFilePathBl);
					}
				}
			}
		}
		if (err)
			CloseApplication(applP, true, nil, 0, &bRecP->sessionCS);
		else
		{	*applicationObjIDP = DLM_NewObj(globalAppList, applicationName, (Ptr)applP, sizeof(Application), 0, 0, &err);
			if (err)
				CloseApplication(applP, true, nil, 0, &bRecP->sessionCS);
		}
	}

return err;
}

//===========================================================================================
XErr	ApplNameFromFile(XFilePathPtr filePath, char *applName)
{
XFileRef		fileRef;
long			eof;
BlockRef		block = nil;
XErr			err = noErr, err2 = noErr;
char			*textP;
Boolean			inString, inTag;
int				i, back_slashCnt, ch;

	*applName = 0;
	if NOT(err = OpenXFile(filePath, OPEN_FILE_EXISTING, READ_PERM, false, &fileRef))
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof)
			{	if (block = NewBlockLocked(eof, &err, &textP))
				{	//LockBlock(block);
					//textP = GetPtr(block);
					if NOT(err = ReadXFile(fileRef, GetPtr(block), &eof))
					{	back_slashCnt = 0;
						inTag = false;
						inString = false;
						do {
							ch = eof ? *textP : 0;
							if (inTag)
							{	if (ch == '\\')
									back_slashCnt++;
								else if ((ch != '\"') && (ch != '\''))
									back_slashCnt = 0;
								if (ch == '\"')
								{	if NOT(back_slashCnt & 1)
										inString = inString ? false : true;
									back_slashCnt = 0;
								}
								if (IsCommentExt(nil, &textP, &eof, nil, nil, false))
									continue;
								else if (IsEndTagExt(nil, &textP, &eof, nil))
									inTag = false;
								else if (NOT(inString) && (eof >= APPL_NAMESTR_LEN) && NOT(CompareBlock(textP, APPL_NAMESTR, APPL_NAMESTR_LEN)))
								{	SkipUntilChar(&textP, &eof, '=', nil);
									textP++;
									eof--;
									SkipSpaceAndTab(&textP, &eof);
									if (eof && ((*textP == '\"') || (*textP == '\'')))
									{	textP++;
										eof--;
									}
									else
										err = XError(kBAPI_Error, Err_BadSyntaxInApplicationName);
									if NOT(err)
									{	i = 0;
										while ((eof > 0) && ((ch = *textP) != '\"'))
										{	if (i > MAX_APPLICATION_NAME_LEN)
											{	err = XError(kBAPI_Error, Err_ApplicationNameTooLong);
												break;
											}
											if (ch == '\\')
											{	err = XError(kBAPI_Error, Err_BadSyntaxInApplicationName);
												break;
											}
											applName[i++] = ch;
											textP++;
											eof--;
										}
										applName[i] = 0;
									}
									break;
								}
								else
								{	textP++;
									eof--;
								}
							}
							else if (IsInitTagExt(nil, &textP, &eof))
								inTag = true;
							else
							{	textP++;
								eof--;
							}
						} while (NOT(err) && (eof > 0));
					}
					DisposeBlock(&block);
				}
			}
		}
		if (NOT(err) && NOT(*applName))
			err = XError(kBAPI_Error, Err_ApplicationNameNotFoundInConfig);
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
	}

return err;
}

//===========================================================================================
XErr	ScanTreeForConfig(XFilePathPtr filePath, BlockRef *configPathsP, long *configPathsLenP, char *applicationName, XFilePathPtr applicationBasePath, Boolean mustFind)
{	
XErr		tErr;
XFilePath	tempStr, tempFilePath, bifernoHomeConfig, forAppNameStr;
CStr255		tempApplicationName;
char		*strP, *appFStrP;
XErr		err = noErr;
long		appFStrLen, buffID;
Boolean		foundHome = false;

	if (err = XGetApplicationFolderPath(bifernoHomeConfig))
		return err;
	CAddStr(bifernoHomeConfig, BIFERNO_CONFIG);
	
	*applicationName = 0;
	appFStrP = BIFERNO_CONFIG;
	appFStrLen = CLen(BIFERNO_CONFIG);
	*configPathsP = 0;
	*configPathsLenP = 0;
	CEquStr(tempFilePath, filePath);
	if (buffID = BufferCreate(255, &err))
	{	if (strP = strrchr(tempFilePath, '/'))	// begin from end
		{	CEquStr(strP+1, appFStrP);
			if (mustFind && (tErr = CheckPath(tempFilePath, true)))
				err = XError(kBAPI_Error, Err_NoSuchApplication);
			else
			{	while (strP && NOT(err))
				{	CEquStr(tempStr, tempFilePath);
					if NOT(tErr = CheckPath(tempStr, true))
					{	err = BufferAddBuffer(buffID, tempStr, CLen(tempStr)+1);
						CEquStr(forAppNameStr, tempStr);
						// check for APPLICATION_NAME
						if (err = ApplNameFromFile(tempStr, tempApplicationName))
							CEquStr(applicationName, tempStr);
						else if NOT(*applicationName)
						{	CEquStr(applicationName, tempApplicationName);
							if (applicationBasePath)
								CEquStr(applicationBasePath, tempStr);
						}
						if NOT(CCompareStrings(tempStr, bifernoHomeConfig))
						{	foundHome = true;
							break;
						}
					}
					if (NOT(err))
					{	*strP = 0;
						if (strP = strrchr(tempFilePath, '/'))
							CEquStr(strP+1, appFStrP);
					}
				}
				if NOT(err)
				{	if NOT(foundHome)
					{	if NOT(err = CheckPath(bifernoHomeConfig, true))
						{	if NOT(err = BufferAddBuffer(buffID, bifernoHomeConfig, CLen(bifernoHomeConfig)+1))
								CEquStr(forAppNameStr, bifernoHomeConfig);
						}
						else
						{	if ((err == XError(kXLibError, ErrXFiles_FileNotFound)) || (err == XError(kXLibError, ErrXFiles_FolderNotFound)))
							{	CEquStr(applicationName, bifernoHomeConfig);
								err = XError(kBAPI_Error, Err_BifernoConfigNotFound);
							}
						}
					}
					if NOT(err)
					{	if (err = ApplNameFromFile(forAppNameStr, tempApplicationName))
							CEquStr(applicationName, forAppNameStr);
						else if NOT(*applicationName)
						{	CEquStr(applicationName, tempApplicationName);
							if (applicationBasePath)
								CEquStr(applicationBasePath, bifernoHomeConfig);
						}
					}
				}
			}
		}
		else	// Biferno Main
		{	if NOT(err = BufferAddBuffer(buffID, bifernoHomeConfig, CLen(bifernoHomeConfig)+1))
			{	// check for APPLICATION_NAME
				if (err = ApplNameFromFile(bifernoHomeConfig, tempApplicationName))
					CEquStr(applicationName, bifernoHomeConfig);
				else if NOT(*applicationName)
					CEquStr(applicationName, tempApplicationName);
			}
		}
		if (err)
			BufferFree(buffID);
		else
		{	// if NOT(err = _ReverseOrder(buffID, &newBuffID))
			*configPathsP = BufferGetBlockRef(buffID, configPathsLenP);
			BufferClose(buffID);
		}
	}

return err;
}

//===========================================================================================
/*XErr	ScanTreeForConfig(char *filePath, BlockRef *configPathsP, long *configPathsLenP, char *applicationName)
{	
XErr		tErr;
CStr255		forAppNameStr, tempFilePath, bifernoHomeConfig;
char		*strP, *appFStrP;
XErr		err = noErr;
long		buffID;
Boolean		found = false;

	if (err = XGetApplicationFolderPath(bifernoHomeConfig))
		return err;
	CAddStr(bifernoHomeConfig, BIFERNO_CONFIG);
	
	*applicationName = 0;
	appFStrP = BIFERNO_CONFIG;
	*configPathsP = 0;
	*configPathsLenP = 0;
	CEquStr(tempFilePath, filePath);
	if (buffID = BufferCreate(255, &err))
	{	if (strP = strrchr(tempFilePath, '/'))	// begin from end
		{	CAddStr(tempFilePath, appFStrP);
			while (strP && NOT(err))
			{	if NOT(tErr = CheckPath(tempFilePath))
				{	if (first && CCompareStrings(tempFilePath, bifernoHomeConfig))
					{	err = BufferAddBuffer(buffID, bifernoHomeConfig, CLen(bifernoHomeConfig)+1);
						first = false;
						// check for APPLICATION_NAME
						if (err = ApplNameFromFile(bifernoHomeConfig, applicationName))
							CEquStr(applicationName, bifernoHomeConfig);
					}
					if NOT(err)
					{	err = BufferAddBuffer(buffID, tempFilePath, CLen(tempFilePath)+1);
						CEquStr(forAppNameStr, tempFilePath);
						found = true;
						// check for APPLICATION_NAME
						if (err = ApplNameFromFile(tempFilePath, applicationName))
							CEquStr(applicationName, tempFilePath);
					}
				}
				if (NOT(err))
				{	CEquStr(tempFilePath, filePath);
					if (strP = strchr(strP+1, '/'))
					{	*(strP+1) = 0;
						CAddStr(tempFilePath, appFStrP);
					}
				}
				else
					break;
			}
			
			if NOT(err)
			{	if NOT(found)
				{	if NOT(err = CheckPath(bifernoHomeConfig))
					{	if NOT(err = BufferAddBuffer(buffID, bifernoHomeConfig, CLen(bifernoHomeConfig)+1))
							CEquStr(forAppNameStr, bifernoHomeConfig);
					}
					else
					{	CEquStr(applicationName, bifernoHomeConfig);
						err = XError(kBAPI_Error, Err_BifernoConfigNotFound);
					}
				}
				if NOT(err)
				{	if (err = ApplNameFromFile(forAppNameStr, applicationName))
						CEquStr(applicationName, forAppNameStr);
				}
			}
		}
		else	// Biferno Main
		{	if NOT(err = BufferAddBuffer(buffID, bifernoHomeConfig, CLen(bifernoHomeConfig)+1))
			{	// check for APPLICATION_NAME
				if (err = ApplNameFromFile(bifernoHomeConfig, applicationName))
					CEquStr(applicationName, bifernoHomeConfig);
			}
		}
		if (err)
			BufferFree(buffID);
		else
		{	*configPathsP = BufferGetBlockRef(buffID, configPathsLenP);
			BufferClose(buffID);
		}
	}

return err;
}
*/
//===========================================================================================
XErr	GetApplicationBlock(char *applicationName, BlockRef *appBlockP)
{
DLMRef			app_list;
Application 	*applRecP;
long			tLen, objID;
BlockRef		blockRef = 0;
XErr			err = noErr;

	app_list = gsDispatcherData.globApplicationListArray;
	if (objID = DLM_GetObjID(app_list, applicationName, nil, nil))
	{	tLen = sizeof(Application);
		if (blockRef = NewPtrBlock(sizeof(Application), &err, (Ptr*)&applRecP))
		{	//applRecP = (Application*)GetPtr(blockRef);
			err = DLM_GetObj(app_list, objID, (Ptr)applRecP, &tLen, 0, nil);
		}
		if (err)
		{	if (blockRef)
				DisposeBlock(&blockRef);
			*appBlockP = blockRef;
		}
		else
			*appBlockP = blockRef;
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchApplication);

return err;
}

//===========================================================================================
XErr	CloseAllApplications(LogCallBack logCallBack, void *userData)
{
XErr		err = noErr;
int			k;
long		tLen, totObjs;
DLMRef		app_list;
Application applRec;
	
	app_list = gsDispatcherData.globApplicationListArray;
	if (NOT(err = DLM_GetTotObjs(app_list, &totObjs, false)) && totObjs)
	{	for (k = 1; k <= totObjs; k++)
		{	tLen = sizeof(Application);
			if NOT(err = DLM_GetIndObj(app_list, k, (Ptr)&applRec, &tLen, 0, nil, nil, nil, false, false))
				err = CloseApplication(&applRec, false, logCallBack, userData, nil);
		}
	}

return err;
}	

//===========================================================================================
/*XErr	DumpServersLists(LogCallBack logCallBack, long userData)
{
XErr		err = noErr;
int			k;
long		tLen, totObjs;
DLMRef		app_list;
Application applRec;
	
	app_list = gsDispatcherData.globApplicationListArray;
	if (NOT(err = DLM_GetTotObjs(app_list, &totObjs, false)) && totObjs)
	{	for (k = 1; (k <= totObjs) && NOT(err); k++)
		{	tLen = sizeof(Application);
			if NOT(err = DLM_GetIndObj(app_list, k, (Ptr)&applRec, &tLen, 0, nil, nil, nil, false, false))
				err = _DumpList(applRec.persistentList, applRec.basePath, logCallBack, userData);
		}
	}

return err;
}*/


