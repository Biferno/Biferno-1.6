/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Compiler.c,v 1.13 2008-12-02 11:04:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Load.h"
#include "Flower.h"
#include "Eval.h"
#include "BfrParser.h"
#include "Dispatcher.h"
#include "BifernoErrors.h"
#include "Param.h"
#include "Classes.h"
#include "Variable.h"

#include "Compiler.h"
#include "Opcodes.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern DispatcherData			gsDispatcherData;

#define	kPreStr		"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n<html><body bgcolor=white><pre>"
#define	kPostStr	"</pre></body></html>"

/*typedef struct {
				long			opcodesLength;
				B_OpcodeExt		opcode;
				OpStackInfo		opcodeStackInfo;
				long			name_opcodesLength;
				B_OpcodeExt		name_opcode;
				OpStackInfo		name_opcodeStackInfo;
				} SavedOpcode, *SavedOpcodeP;
*/

//===========================================================================================
static void		_ObjOnStack(ObjRecordP stackResultP)
{	
	stackResultP->type = 0;
	BIC_OBJREF_SPEC(stackResultP) = kVL_LIST;
	stackResultP->classID = 0;
	stackResultP->id = SP;
	stackResultP->scope = 0;
	stackResultP->list = 0;
}

//===========================================================================================
static XErr	_GetFirstOperand(BICRecord *bicRecP, ObjRecordP objLeftP, ObjRecordP firstOperandP, ArrayIndexRec *mCoords, long mCoordDim)
{
XErr	err = noErr;

	if (mCoords && mCoordDim)
	{	if NOT(err = Opcode_index(bicRecP, objLeftP, mCoords, mCoordDim, kIndexLeaveOnStack_o, SP))
			_ObjOnStack(firstOperandP);
	}
	else
		*firstOperandP = *objLeftP;

return err;
}

//===========================================================================================
static Boolean	_IndexSetPreviousOpcode(BICRecord *bicRecP, long opcode, long moreStack, long *vlparamP)
{	
long			totSize;
Ptr				opcodesPtr;
OpcodeHead		*headP;
OpStackInfoP	opStackP;

	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
	headP = &((B_Opcode*)(opcodesPtr + totSize - bicRecP->lastOpcodeSize))->head;
	if ((headP->opCode == kIndex_o) || (headP->opCode == kIndexN_o))
	{	if ((opcode == kIndexLeaveOnStack_o) && ((headP->opVariant.pos2 != kVariantVL_LIST) || (PARAM_2_SHORT(headP) != SP)))
			opcode = kIndex_o;
		headP->opCode = (Byte)opcode;
		BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
		opStackP += bicRecP->totOpcodes - 1;
		if (opStackP->decr_stack)
		{	opStackP->decr_stack -= (Byte)moreStack;
			bicRecP->actStack += moreStack;
		}
		if (vlparamP)
			*vlparamP = PARAM_1_SHORT(headP);
		return true;
	}
	else
		return false;
}

//===========================================================================================
static Boolean	_PropertySetPreviousOpcode(BICRecord *bicRecP, long opcode, long moreStack, long *vlparamP, long propertyDim)
{	
long			totSize;
Ptr				opcodesPtr;
OpcodeHead		*headP;
OpStackInfoP	opStackP;

	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
	headP = &((B_Opcode*)(opcodesPtr + totSize - bicRecP->lastOpcodeSize))->head;
	if (headP->opCode == kGet_o)
	{	if ((opcode == kGetLeaveOnStack_o) && (propertyDim == 1) && ((headP->opVariant.pos2 != kVariantVL_LIST) || (PARAM_2_SHORT(headP) != SP)))
			opcode = kGet_o;
		headP->opCode = (Byte)opcode;
		BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
		opStackP += bicRecP->totOpcodes - 1;
		if (opStackP->decr_stack)
		{	opStackP->decr_stack -= (Byte)moreStack;
			bicRecP->actStack += moreStack;
		}
		if (vlparamP)
			*vlparamP = PARAM_1_SHORT(headP);
		return true;
	}
	else
		return false;
}

typedef struct {
				long	offset;
				long	jump;
				long	diff;
				} BrInfo;

//===========================================================================================
static void	_UpdateBrs(BrInfo *brInfosP, long totBrs, long nopOffset, long nopSize)
{
long			brRelativeOff, brAbsOff;
//XErr			err = noErr;

	if (totBrs)
	{	do {
			brRelativeOff = brInfosP->jump;
			brAbsOff = brInfosP->offset + brRelativeOff;
			// nop compreso fra br e brjumpoffset?
			if (brRelativeOff > 0)
			{	if ((nopOffset > brInfosP->offset) && (nopOffset < brAbsOff))
					brInfosP->diff -= nopSize;
			}
			else
			{	if ((nopOffset > brAbsOff) && (nopOffset < brInfosP->offset))
					brInfosP->diff += nopSize;
			}
			brInfosP++;
		} while (--totBrs);
	}
}

//===========================================================================================
static XErr	_Optim2(BICRecord *bicRecP)
{
BlockRef		brInfosBlock, nopInfosBlock, opStackBlockRef, block;
long			totBrs, totNops, sizeRemoved, opStackSize, opcodeSize, totOpcodes, totSize;
Ptr				saveOpcodePtr, opcodesPtr;
OpStackInfoP 	saveOpStackP, opStackP;
OpcodeHead		*opHeadP;
XErr			err = noErr;
Ptr				readP, writeP;
BrInfo			*saveBrInfosP, *brInfosP, *nopInfosP, *saveNopInfosP;
Byte			opCode;

	if NOT(bicRecP->totNops)
		return noErr;
	if (totOpcodes = bicRecP->totOpcodes)
	{	
		block = BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
		LockBlock(block);
		saveOpcodePtr = opcodesPtr;
		opStackBlockRef = BufferGetBlockRefExtSize(bicRecP->opcodesStack, &opStackSize, (Ptr*)&opStackP);
		saveOpStackP = opStackP;
		LockBlock(opStackBlockRef);
		sizeRemoved = 0;
		if (bicRecP->totBrs)
		{	if (nopInfosBlock = NewBlockLocked(sizeof(BrInfo) * bicRecP->totNops, &err, (Ptr*)&nopInfosP))
			{	if (brInfosBlock = NewBlockLocked(sizeof(BrInfo) * bicRecP->totBrs, &err, (Ptr*)&brInfosP))
				{	saveNopInfosP = nopInfosP;
					saveBrInfosP = brInfosP;
					// save nops and br
					totNops = totBrs = 0;
					do {
						opHeadP = &((B_Opcode*)opcodesPtr)->head;
						opcodeSize = opStackP[1].opOffset - opStackP->opOffset;
						opCode = opHeadP->opCode;
						if NOT(opCode)
						{	nopInfosP->offset = opStackP->opOffset;
							nopInfosP->diff = 0;
							nopInfosP->jump = opcodeSize;
							nopInfosP++;
							sizeRemoved += opcodeSize;
							totNops++;
						}
						else if ((opCode == kBra_o) || (opCode == kBet_o) || (opCode == kBef_o) || (opCode == kBnse_o))
						{	brInfosP->offset = opStackP->opOffset;
							brInfosP->diff = 0;
							brInfosP->jump = BRANCH_OFFSET(opHeadP);
							brInfosP++;
							totBrs++;
						}
						opcodesPtr += opcodeSize;
						opStackP++;
					} while (NOT(err) && --totOpcodes);
					if (bicRecP->totNops != totNops)
						CDebugStr("totNops doesn't match");
					if (bicRecP->totBrs != totBrs)
						CDebugStr("totBrs doesn't match");
					// Update br
					nopInfosP = saveNopInfosP;
					do {
						_UpdateBrs(saveBrInfosP, totBrs, nopInfosP->offset, nopInfosP->jump);
						nopInfosP++;
					} while (--totNops);
					// Move Brs again in list
					totBrs = bicRecP->totBrs;
					opcodesPtr = saveOpcodePtr;
					brInfosP = saveBrInfosP;
					do {
						opHeadP = (OpcodeHead*)(opcodesPtr + brInfosP->offset);
						BRANCH_OFFSET(opHeadP) += brInfosP->diff;
						brInfosP++;
					} while (--totBrs);
					DisposeBlock(&brInfosBlock);
				}
				DisposeBlock(&nopInfosBlock);
			}
		}
		if NOT(err)
		{	//=== remove
		OpStackInfoP 	readStackP, writeStackP;

			totOpcodes = bicRecP->totOpcodes;
			opStackP = saveOpStackP;
			writeP = readP = saveOpcodePtr;
			readStackP = writeStackP = saveOpStackP;
			do {
				opHeadP = &((B_Opcode*)readP)->head;
				opcodeSize = opStackP[1].opOffset - opStackP->opOffset;
				if (opHeadP->opCode)
				{	CopyBlock(writeP, readP, opcodeSize);
					writeP += opcodeSize;
					*writeStackP++ = *readStackP;
				}
				readP += opcodeSize;
				readStackP++;
				opStackP++;
			} while (NOT(err) && --totOpcodes);
			bicRecP->totOpcodes -= bicRecP->totNops;
			BufferSetLength(bicRecP->opcodesBufferID, totSize - sizeRemoved);
		}
		UnlockBlock(block);
		UnlockBlock(opStackBlockRef);
	}

return err;
}

//===========================================================================================
static Boolean	_DontNop(Byte opcode)
{	
	switch(opcode)
	{
		case kCall_o:
		//case kInvoke_o:
		case kIncr_o:
		case kIncrIndex_o:
		case kIncrIndexN_o:
		case kDecr_o:
		case kDecrIndex_o:
		case kDecrIndexN_o:
			return true;
	}
	
return false;
}

//===========================================================================================
static long	_CalcMaxStack(OpStackInfoP opStackP, long totOpcodes)
{
long	curStack, maxStack, i;

	maxStack = curStack = 0;
	for (i  = 0; i < totOpcodes; i++, opStackP++)
	{	curStack += opStackP->incr_stack;
		curStack -= opStackP->decr_stack;
		if (curStack > maxStack)
			maxStack = curStack;
	}

return maxStack;
}

//===========================================================================================
static XErr	_AdjustGotos(long api_data, BICRecord *bicRecP)
{
XErr			err = noErr;
long			totGotos, totLabels;
LabelRecP		labelP;
GotoRecP		gotoP;

	// Check on labels definition
	totLabels = bicRecP->totLabels;
	if (totLabels)
	{	labelP = (LabelRecP)GetPtr(bicRecP->labelsBlock);
		do {
			if (totGotos = labelP->totGotos)
			{	gotoP = (GotoRecP)GetPtr(labelP->gotoBlock);
				// ex if (labelP->branchOffset != INVALID_BR_OFFSET)
				if (labelP->offsetIsValid)
				{	do {
						if (err = BIC_BranchUpdateOffset(api_data, gotoP->opcodeOffset, labelP->branchOffset))
							break;
						else
							gotoP++;
					} while (--totGotos);
				}
				else
				{	err = XError(kBAPI_Error, Err_LabelNotFound);
					((BifernoRecP)api_data)->currentCtx.currentLine = gotoP->gotoLine;
					NewMsgRecord(api_data, kLABEL_BAD, labelP->labelName, 0, 0);
					break;
				}
			}
			labelP++;
		} while (--totLabels && NOT(err));
	}

return err;
}

//===========================================================================================
static XErr	_Optim1(BICRecord *bicRecP)
{
XErr			err = noErr;
long			offset, totSize, totOpcodes;
BlockRef		block;
Ptr				opcodesPtr;
OpcodeHead		*opHeadP;
long			opcodeIndex, tOff, branchOffset;
BlockRef		opStackBlockRef;
OpStackInfoP	opStackP;
Ptr				saveOpcodePtr;

	if (totOpcodes = bicRecP->totOpcodes)
	{	
		block = BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
		LockBlock(block);
		saveOpcodePtr = opcodesPtr;
		opStackBlockRef = BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
		LockBlock(opStackBlockRef);
		offset = 0;
		opcodeIndex = 1;
		do {
			opHeadP = &((B_Opcode*)opcodesPtr)->head;
			if (opStackP->countStack)
			{	
				if (_DontNop(opHeadP->opCode))
				{	opHeadP->dest = 0;
					opStackP->countStack--;
					opStackP->incr_stack--;
				}
				else
					NopUnusedOpcode(bicRecP, saveOpcodePtr, opcodeIndex);
					//err = XError(kBAPI_Error, Err_UselessStatement);
				bicRecP->actStack--;
			}
			else
			{	switch (opHeadP->opCode)
				{
					case kBra_o:
					case kBet_o:
					case kBef_o:
						branchOffset = *(long*)&opHeadP->dest;
						if ((branchOffset == 0) || (branchOffset == SMALL))	// branch su se stesso o all'opcode dopo?
						{	
							ClearBlock(opHeadP, sizeof(OpcodeHead));
							bicRecP->totNops++;
							bicRecP->totBrs--;
						}
						else if ((offset + branchOffset) == totSize && opHeadP->opCode == kBra_o)					// branch alla fine
						{	
							opHeadP->opCode = kStop_o;
							opHeadP->dest = 0;
							bicRecP->totBrs--;
						}
						break;
				}
			}
			tOff = GetOpcodeSize((B_Opcode*)opcodesPtr);
			opcodesPtr += tOff;
			offset += tOff;
			opStackP++;
			opcodeIndex++;
		} while (NOT(err) && --totOpcodes);
		UnlockBlock(block);
		UnlockBlock(opStackBlockRef);
	}

return err;
}

//===========================================================================================
static XErr	_CompactCompilation(BICRecord *bicRecP, long *totSizeP, BlockRef *codeBlockP)
{
long		opcodesSize, totalSize, vlSize, slSize, slOffsetsSize;
BICHeader	bicHeader;
XErr		err = noErr;
Ptr			mainBlockP, opcodesPtr;
BlockRef	mainBlock;

	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &opcodesSize, &opcodesPtr);
	vlSize = bicRecP->vl.totSlots * sizeof(VL_Slot);
	slSize = bicRecP->sl.blockSize;
	slOffsetsSize = bicRecP->sl.totSlots * sizeof(long);
	totalSize = *totSizeP = sizeof(BICHeader) + opcodesSize + vlSize + slSize + slOffsetsSize;
	if (mainBlock = NewBlockLocked(totalSize, &err, &mainBlockP))
	{	
		bicHeader.stack = bicRecP->stack;
		bicHeader.totOpcodes = bicRecP->totOpcodes;
		bicHeader.opcodesOffset = sizeof(BICHeader);
		bicHeader.vlTotal = bicRecP->vl.totSlots;
		bicHeader.vlOffset = bicHeader.opcodesOffset + opcodesSize;
		bicHeader.slTotal = bicRecP->sl.totSlots;
		bicHeader.slOffset = bicHeader.vlOffset + vlSize;
		bicHeader.slOffsetsOffset = bicHeader.slOffset + slSize;		
		bicHeader.cl = bicRecP->cl;
		// Header
		CopyBlock(mainBlockP, &bicHeader, sizeof(BICHeader));
		// Opcodes
		BufferGetBlockRefExt(bicRecP->opcodesBufferID, &opcodesPtr);	// reload
		CopyBlock(mainBlockP + bicHeader.opcodesOffset, opcodesPtr, opcodesSize);
		// vl
		CopyBlock(mainBlockP + bicHeader.vlOffset, GetPtr(bicRecP->vl.block), vlSize);
		// sl
		CopyBlock(mainBlockP + bicHeader.slOffset, GetPtr(bicRecP->sl.block), slSize);
		// sl offsets
		CopyBlock(mainBlockP + bicHeader.slOffsetsOffset, GetPtr(bicRecP->sl.offsets), slOffsetsSize);
		
		// momentaneamente
		*codeBlockP = mainBlock;
		// DisposeBlock(&mainBlock);
	}
	
return err;
}

//===========================================================================================
static XErr	_ArrayIncrement(BICRecordP bicRecP, ObjRecordP objRefP, ArrayIndexRec *mCoords, long mCoordDim, long incrType)
{
Byte		opcode;
XErr		err = noErr;
long		vlIndex;

	switch(incrType)
	{
		case kPreIncrem:
			if (mCoordDim > 1)
				opcode = kIncrIndexN_o;
			else
				opcode = kIncrIndex_o;
			if NOT(_IndexSetPreviousOpcode(bicRecP, opcode, 0, nil))
				err = Opcode_index(bicRecP, objRefP, mCoords, mCoordDim, kIncrIndex_o, 0);
			break;
		case kPreDecrem:
			if (mCoordDim > 1)
				opcode = kDecrIndexN_o;
			else
				opcode = kDecrIndex_o;
			if NOT(_IndexSetPreviousOpcode(bicRecP, opcode, 0, nil))
				err = Opcode_index(bicRecP, objRefP, mCoords, mCoordDim, kDecrIndex_o, 0);
			break;
		case kPostIncrem:
			if (mCoordDim > 1)
				opcode = kIndexLeaveOnStackN_o;
			else
				opcode = kIndexLeaveOnStack_o;
			if (_IndexSetPreviousOpcode(bicRecP, opcode, mCoordDim, &vlIndex))
			{	if (BIC_OBJREF_SPEC(objRefP) == kVL_LIST)
					objRefP->id = vlIndex;
				else
					CDebugStr("impossible");
			}
			err = Opcode_index(bicRecP, objRefP, mCoords, mCoordDim, kIncrIndex_o, 0);
			break;
		case kPostDecrem:
			if (mCoordDim > 1)
				opcode = kIndexLeaveOnStackN_o;
			else
				opcode = kIndexLeaveOnStack_o;
			if (_IndexSetPreviousOpcode(bicRecP, opcode, mCoordDim, &vlIndex))
			{	if (BIC_OBJREF_SPEC(objRefP) == kVL_LIST)
					objRefP->id = vlIndex;
				else
					CDebugStr("impossible");
			}
			err = Opcode_index(bicRecP, objRefP, mCoords, mCoordDim, kDecrIndex_o, 0);
			break;
	}
	if NOT(err)
	{	objRefP->type = 0;
		BIC_OBJREF_SPEC(objRefP) = kVL_LIST;
		objRefP->classID = 0;
		objRefP->id = SP;
		objRefP->scope = 0;
		objRefP->list = 0;
	}

return err;
}

extern 	DispatcherData		gsDispatcherData;
extern	PluginRecord		*gClassRecordBlockP;

//===========================================================================================
static XErr	_DumpClasses(long api_data, BufferID outputID)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr			err = noErr;
int				totClass, i;
PluginRecord	*plugRecP;
CStr63			tStr;

	if (err = BufferAddCString(outputID, "&nbsp;<p><b>Classes state:</b><p><table border=0 cellpadding=2 cellspacing=2>\r\n", NO_ENC, 0))
		goto out;
	totClass = gsDispatcherData.totClass;
	for (i = 0; i < totClass; i++)
	{	if ((plugRecP = &gClassRecordBlockP[i]) && plugRecP->successfull)
		{	if (plugRecP->pluginType == kNewClassPlugin)
			{	
				if (err = BufferAddCString(outputID, "<tr><td>", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(outputID, plugRecP->pluginName, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(outputID, "</td><td>", NO_ENC, 0))
					goto out;
				CNumToString(i+1, tStr);
				if (err = BufferAddCString(outputID, tStr, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(outputID, "</td></tr>", NO_ENC, 0))
					goto out;
			}
		}
	}
	if (err = BufferAddCString(outputID, "</table>\r\n", NO_ENC, 0))
		goto out;

out:
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_ParamFindPos(long api_data, ParameterRec *paramVarsP, BAPI_ParameterDoc *protoParamP, long totParamsInProto, short *paramPosP)
{
ObjRecordP		objNameP;
CStr63			paramName;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
XErr			err = noErr;

	objNameP = (ObjRecordP)&paramVarsP->name;
	if (BIC_IsLiteral(objNameP))
	{	
	ObjRecord	tempObjRef;
	int			j;
	BAPI_ParameterDoc	*tempProtoParamP;
	
		INVAL(tempObjRef);
		BIC_GetRealObjRef(&bRecP->bicRecord, objNameP, &tempObjRef);
		if NOT(err = BAPI_ObjToString(api_data, OBJREF_P(&tempObjRef), paramName, nil, 63, kExplicitTypeCast))
		{	tempProtoParamP = protoParamP;
			for (j = 0; j < totParamsInProto; j++, tempProtoParamP++)
			{	if NOT(CCompareStrings_cs(paramName, tempProtoParamP->name))
					break;
			}
			if (j >= totParamsInProto)
				err = XError(kBAPI_Error, Err_InvalidParameterName);
			else
				*paramPosP = j + 1;
		}
	}
	else
		*paramPosP = 0;

return err;
}

//===========================================================================================
static XErr	_ParamPosExists(ParamInfo *paramInfoP, short paramPos, long totParams)
{
	if (totParams)
	{
		do {
			if (paramInfoP->paramPos == paramPos)
				return true;
			else
				paramInfoP++;
		} while (--totParams);
	}

return false;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_LabelAdd(long api_data, char *labelName, Ptr *labelPPtr, Boolean updateBranchOff)
{
XErr		err = noErr;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
long		totLabels;
LabelRecP	labelP;
Boolean		expand = true;

	if (totLabels = bicRecP->totLabels)
	{	labelP = (LabelRecP)GetPtr(bicRecP->labelsBlock);
		do {
			if NOT(CCompareStrings_cs(labelName, labelP->labelName))	// label already exists
			{	// ex if (labelP->branchOffset != INVALID_BR_OFFSET)
				if (labelP->offsetIsValid)
				{	err = XError(kBAPI_Error, Err_DuplicatedLabel);
					NewMsgRecord(api_data, kDOING, labelName, 0, 0);
				}
				else
				{	err = BIC_GetOffset(api_data, &labelP->branchOffset);
					labelP->offsetIsValid = true;
					expand = false;
				}
				break;
			}
			else
				labelP++;
		} while (--totLabels && NOT(err));
	}
	if (NOT(err) && expand)
	{	totLabels = bicRecP->totLabels + 1;
		if NOT(err = SetBlockSize(bicRecP->labelsBlock, totLabels * sizeof(LabelRec)))
		{	labelP = (LabelRecP)GetPtr(bicRecP->labelsBlock) + bicRecP->totLabels;
			bicRecP->totLabels++;
			CEquStr(labelP->labelName, labelName);
			if (updateBranchOff)
			{	if NOT(err = BIC_GetOffset(api_data, &labelP->branchOffset))
					labelP->offsetIsValid = true;
			}
			else
			{	labelP->branchOffset = 0;
				labelP->offsetIsValid = false;
			}
			if NOT(err)
			{	labelP->totGotos = 0;
				labelP->gotoBlock = NewBlock(1 * sizeof(GotoRec), &err, nil);
				if NOT(err)
				{	if (labelPPtr)
						*labelPPtr = (Ptr)labelP;
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_LabelDispose(BICRecord *bicRecP)
{
XErr		err = noErr;
long		totLabels;
LabelRecP	labelP;

	totLabels = bicRecP->totLabels;
	LockBlock(bicRecP->labelsBlock);
	if (totLabels)
	{	labelP = (LabelRecP)GetPtr(bicRecP->labelsBlock);
		do {
			DisposeBlock(&labelP->gotoBlock);
			labelP++;
		} while (--totLabels && NOT(err));
	}
	DisposeBlock(&bicRecP->labelsBlock);
	
return noErr;
}

//===========================================================================================
/*static XErr		_InvokeAnalyzePrototype(long api_data, Boolean isBiferno, long classID, long funcObjID, ParameterRec *paramVarsP, long *totParamsP, long *lessStackP, SL_SlotP slSlotP)
{
XErr			err = noErr;
ParameterRec 	*tParamVarsP;
int				i;
ProtoParam		*tempProtoParamP;
BifernoRecP		bRecP = (BifernoRecP)api_data;
ProtoParam 		*protoParamP;
long 			totParamsInProto;
CStr255			prototype;
Boolean 		dontCheckNumParams;
Boolean 		dontCheckNames;
BlockRef		protoParamBlock;
long			returnClassID, totParams,saveCurMethodClass;
Boolean 		thereAreNames = slSlotP->names;

	totParams = *totParamsP;
	if NOT(err = GetProtoBlock(api_data, classID, funcObjID, isBiferno, &protoParamBlock, &protoParamP, &totParamsInProto, prototype, &dontCheckNumParams, &dontCheckNames, true, &returnClassID, nil, nil))
	{	if (*prototype)
		{	if (NOT(dontCheckNumParams) && (totParams > totParamsInProto))
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
			if (NOT(err) && totParamsInProto && NOT(thereAreNames))
			{	tParamVarsP = paramVarsP;
				tempProtoParamP = protoParamP;
				saveCurMethodClass = bRecP->methodInExecutionClass;
				bRecP->methodInExecutionClass = classID;
				for (i = 0; (i < totParamsInProto) && NOT(err); i++, tParamVarsP++, tempProtoParamP++)
				{	if ((i >= totParams) || NOT(OBJ_ID(tParamVarsP->objRef)))
					{	if NOT(err = SetDefault(api_data, tParamVarsP, tempProtoParamP->defaultStr, tempProtoParamP))
						{	if (i >= totParams)
							{	slSlotP->paramPos[i] = *totParamsP - 1;
								(*totParamsP)++;
							}
							(*lessStackP)++;
						}
					}
					slSlotP->paramPos[i] = i;
				}
				bRecP->methodInExecutionClass = saveCurMethodClass;
			}
		}
		if (protoParamBlock)
			DisposeBlock(&protoParamBlock);
	}
	if (err)
		NewMsgRecord(api_data, kFUNCTION, prototype, 0, 0);

return err;
}
*/
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr		_SLAdd(SL_Record *slRecP, SL_SlotP slSlotP, long slotToAddSize, long *indexP)
{
long		totSlots = slRecP->totSlots;
XErr		err = noErr;
Ptr			tSlotP;
long		newDim, newOffDim, *tOffP;

	newDim = slRecP->blockSize + slotToAddSize;
	if NOT(err = SetBlockSize(slRecP->block, newDim))
	{	newOffDim = sizeof(long) * (totSlots + 1);
		if NOT(err = SetBlockSize(slRecP->offsets, newOffDim))
		{	tOffP = (long*)(GetPtr(slRecP->offsets) + (totSlots * sizeof(long)));
			*tOffP = slRecP->blockSize;
			tSlotP = GetPtr(slRecP->block) + *tOffP;
			CopyBlock(tSlotP, slSlotP, slotToAddSize);
		}
		slRecP->blockSize = newDim;
		slRecP->totSlots++;
		*indexP = slRecP->totSlots;
	}
	
return err;
}

//===========================================================================================
static Boolean	_AreBICObjsEqual(ObjRecordP objRef1P, ObjRecordP objRef2P)
{
Boolean		res = false;
long		spec1 = BIC_OBJREF_SPEC(objRef1P), spec2 = BIC_OBJREF_SPEC(objRef2P);

	if (spec1 == spec2)
	{	switch(spec1)
		{
			case kCL_LIST:
				res = (objRef1P->id == objRef2P->id);
				break;
			
			case kImmediateValue:
				if (objRef1P->classID == objRef2P->classID)
				{	switch(objRef1P->classID)
					{	case kBooleanClassID:
							res = (*(Boolean*)BIC_IMM_P(objRef1P) == *(Boolean*)BIC_IMM_P(objRef2P));
							break;
						case kStringClassID:
							if (BIC_IMMLEN_STRLEN_P(objRef1P) == BIC_IMMLEN_STRLEN_P(objRef2P))
								res = NOT(CompareBlock(BIC_IMM_P(objRef1P), BIC_IMM_P(objRef2P), BIC_IMMLEN_STRLEN_P(objRef1P)));
							break;
						case kDoubleClassID:
							res = (*(double*)BIC_IMM_P(objRef1P) == *(double*)BIC_IMM_P(objRef2P));
							break;
						case kLongClassID:
							res = (*(LONGLONG*)BIC_IMM_P(objRef1P) == *(LONGLONG*)BIC_IMM_P(objRef2P));
							break;
						case kUnsignedClassID:
							res = (*(unsigned long*)BIC_IMM_P(objRef1P) == *(unsigned long*)BIC_IMM_P(objRef2P));
							break;
						case kIntClassID:
							res = (*(long*)BIC_IMM_P(objRef1P) == *(long*)BIC_IMM_P(objRef2P));
							break;
					}
				}
				break;
			
			case kVL_LIST:
				if ((objRef1P->id == -1) || (objRef2P->id == -1))
					res = false;
				else
					res = (objRef1P->id == objRef2P->id);
				break;
		
		}
	}

return res;
}

//===========================================================================================
static Boolean	_SLAreEqual(SL_SlotP slSlotP1, long size1, SL_SlotP slSlotP2, long size2)
{
Boolean		res = false;

	res = not(CompareBlock(&slSlotP1->doc, &slSlotP2->doc, sizeof(BAPI_Doc)));
	if (res)
	{	
		if (slSlotP1->objRef.id)
			res = _AreBICObjsEqual(&slSlotP1->objRef, &slSlotP2->objRef);
		else if (slSlotP2->objRef.id)
			res = false;
	}

return res;
}

//===========================================================================================
static int	_SLFind(SL_RecordP slRecP, SL_SlotP slotToFindP, long slotToFindSize)
{
long		tot = slRecP->totSlots;
long		s, index = 0, *offP;
Ptr			startSlotP, slSlotP;

	if (tot)
	{	LockBlock(slRecP->block);
		slSlotP = startSlotP = GetPtr(slRecP->block);
		offP = (long*)GetPtr(slRecP->offsets);
		do {
			if (tot > 1)
				s = offP[1] - *offP;
			else
				s = GetBlockSize(slRecP->block, nil) - *offP;
			if (_SLAreEqual(slotToFindP, slotToFindSize, (SL_SlotP)slSlotP, s))
			{	index = slRecP->totSlots - tot + 1;
				break;
			}
			else
			{	offP++;
				slSlotP = startSlotP + *offP;
			}
		} while (--tot);
		UnlockBlock(slRecP->block);
	}

return index;
}

//===========================================================================================
static XErr	_SLDumpOne(long outputID, SL_SlotP sl_SlotP, long index, long slotSize)
{
CStr255			dumpStr;
CStr15			tStr;
XErr			err = noErr;
// int				i;

	*dumpStr = 0;
	CAddStr(dumpStr, "SL");
	CNumToString(index, tStr);
	CAddStr(dumpStr, tStr);
	CAddStr(dumpStr, ": ");
	
	CAddStr(dumpStr, sl_SlotP->doc.name);
	
	if (sl_SlotP->objRef.id)
	{	
	ObjRecordP	objRecP;
	
		CAddStr(dumpStr, " on ");
		objRecP = &sl_SlotP->objRef;
		switch(BIC_OBJREF_SPEC(&sl_SlotP->objRef))
		{
			case kCL_LIST:
				CNumToString(objRecP->id, tStr);
				CAddStr(dumpStr, "CL");
				CAddStr(dumpStr, tStr);
				break;
			case kVL_LIST:
				if (objRecP->id == SP)
					CEquStr(tStr, "SP");
				else
				{	CNumToString(objRecP->id, tStr);
					CAddStr(dumpStr, "VL");
				}
				CAddStr(dumpStr, tStr);
				break;
			
			case kImmediateValue:
				*tStr = 0;
				switch(objRecP->classID)
				{	case kBooleanClassID:
						DumpBool(tStr, *(Boolean*)BIC_IMM_P(objRecP));
						break;
					case kStringClassID:
						DumpStr(tStr, (Byte*)BIC_IMM_P(objRecP));
						break;
					case kDoubleClassID:
						DumpDouble(tStr, (double*)BIC_IMM_P(objRecP));
						break;
					case kLongClassID:
						DumpLong(tStr, *(LONGLONG*)BIC_IMM_P(objRecP));
						break;
					case kUnsignedClassID:
						DumpUnsigned(tStr, *(unsigned long*)BIC_IMM_P(objRecP));
						break;
					case kIntClassID:
						DumpInt(tStr, *(long*)BIC_IMM_P(objRecP));
						break;
				}
				CAddStr(dumpStr, tStr);
				break;
			
			default:
				break;
		}
		CAddStr(dumpStr, " ");
	}
	
	CAddStr(dumpStr, "\r\n");
	err = BufferAddCString(outputID, dumpStr, ISOLATIN_ENC, kTagsVisible);

return err;
}

//===========================================================================================
static XErr	_SLDumpList(long api_data, long outputID, SL_RecordP slRecP, long *slSizeP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
long		tot = slRecP->totSlots;
long		size, index = 0, *offP;
Ptr			startSlotP, slSlotP;
//BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
XErr		err = noErr;
CStr255		tStr, aCStr;

	if (tot)
	{	LockBlock(slRecP->block);
		slSlotP = startSlotP = GetPtr(slRecP->block);
		offP = (long*)GetPtr(slRecP->offsets);
		index = 1;
		do {
			if (tot > 1)
				size = offP[1] - *offP;
			else
				size = GetBlockSize(slRecP->block, nil) - *offP;
			if (err = _SLDumpOne(outputID, (SL_SlotP)slSlotP, index++, size))
				break;
			else
			{	offP++;
				slSlotP = startSlotP + *offP;
			}
		} while (--tot);
		UnlockBlock(slRecP->block);
	}
	*slSizeP = slRecP->blockSize + (slRecP->totSlots * sizeof(long));
	if (NOT(err) && *slSizeP)
	{	CEquStr(aCStr, "<br><b>Total: ");
		CNumToString(*slSizeP, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, "</b>\r\n");
		err = BufferAddCString(outputID, aCStr, NO_ENC, 0);
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static int	_VLFind(VL_RecordP vlRecP, char *varName, long theScope, long *classIDP)
{
long		tot = vlRecP->totSlots;
long		index = 0;
VL_SlotP	vslotP;

	if (classIDP)
		*classIDP = 0;
	if (tot)
	{	
		vslotP = (VL_SlotP)GetPtr(vlRecP->block);
		do {
			if (NOT(CCompareStrings_cs(varName, vslotP->name)) && (theScope == vslotP->objRef.scope))
			{	
				index = vlRecP->totSlots - tot + 1;
				if (classIDP)
					*classIDP = vslotP->objRef.classID;
				break;
			}
			else
				vslotP++;
		} while (--tot);
	}

return index;
}

//===========================================================================================
static XErr	_VLDumpOne(long api_data, long outputID, VL_SlotP vlSlotP, long index)
{
CStr255		dumpStr;
CStr63		tStr;
XErr		err = noErr;

	CEquStr(dumpStr, "VL");
	CNumToString(index, tStr);
	CAddStr(dumpStr, tStr);
	CAddStr(dumpStr, ": ");
	/*if (vlSlotP->objRef.scope)
	{	
		BAPI_ScopeName(api_data, vlSlotP->objRef.scope, tStr);
		CAddChar(dumpStr, '[');
		CAddStr(dumpStr, tStr);
		CAddStr(dumpStr, "] ");
	}*/
	if not(err = BAPI_NameFromClassID(api_data, vlSlotP->objRef.classID, tStr))
	{
		CAddStr(dumpStr, tStr);
		CAddChar(dumpStr, ' ');
	}
	CAddStr(dumpStr, vlSlotP->name);
	CAddStr(dumpStr, "\r\n");
	err = BufferAddCString(outputID, dumpStr, ISOLATIN_ENC, kTagsVisible);

return err;
}

//===========================================================================================
static XErr	_VLDumpList(long api_data, long outputID, VL_RecordP vlRecP, long *vlSizeP)
{
long		tot = vlRecP->totSlots;
long		index = 0;
VL_SlotP	vslotP;
//BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
XErr		err = noErr;
CStr255		aCStr, tStr;

	if (tot)
	{	LockBlock(vlRecP->block);
		vslotP = (VL_SlotP)GetPtr(vlRecP->block);
		index = 1;
		do {
			if (err = _VLDumpOne(api_data, outputID, vslotP, index++))
				break;
			else
				vslotP++;
		} while (--tot);
		UnlockBlock(vlRecP->block);
	}
	*vlSizeP = vlRecP->totSlots * sizeof(VL_Slot);
	if (NOT(err) && *vlSizeP)
	{	CEquStr(aCStr, "<br><b>Total: ");
		CNumToString(*vlSizeP, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, "</b>\r\n");
		err = BufferAddCString(outputID, aCStr, NO_ENC, 0);
	}

return err;
}

//===========================================================================================
static XErr	_VLAdd(VL_RecordP vlRecP, char *varName, long theScope, long theClassID, long *indexP)
{
long		totSlots = vlRecP->totSlots;
XErr		err = noErr;
VL_SlotP	tSlotP;

	if NOT(err = SetBlockSize(vlRecP->block, sizeof(VL_Slot) * (totSlots + 1)))
	{	
		tSlotP = (VL_SlotP)GetPtr(vlRecP->block) + totSlots;
		
		CEquStr(tSlotP->name, varName);
		ClearBlock(&tSlotP->objRef, sizeof(ObjRecord));
		tSlotP->objRef.scope = theScope;
		tSlotP->objRef.classID = theClassID;

		vlRecP->totSlots++;
		*indexP = vlRecP->totSlots;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_CLDumpOne(long api_data, long outputID, char *strP, long strLen, long classID, long ll_ID)
{
CStr255		dumpStr;
CStr63		className;
CStr15		tStr;
XErr		err = noErr;
BlockRef	resBlock = 0, resBlock2 = 0;
long		resBlockLen, resBlockLen2;

	BAPI_NameFromClassID(api_data, classID, className);
	CEquStr(dumpStr, "CL");
	CNumToString(ll_ID, tStr);
	CAddStr(dumpStr, tStr);
	CAddStr(dumpStr, " (");
	CAddStr(dumpStr, className);
	CAddStr(dumpStr, "): ");
	if NOT(err = BufferAddCString(outputID, dumpStr, NO_ENC, 0))
	{	if NOT(err = SubstituteExt(strP, strLen, &resBlock, &resBlockLen, "\"", 1, "\\\"", 2, true, false))
		{	LockBlock(resBlock);
			if NOT(err = SubstituteExt(GetPtr(resBlock), resBlockLen, &resBlock2, &resBlockLen2, "\r", 1, "\\r", 2, true, false))
			{	DisposeBlock(&resBlock);
				LockBlock(resBlock2);
				if NOT(err = SubstituteExt(GetPtr(resBlock2), resBlockLen2, &resBlock, &resBlockLen, "\n", 1, "\\n", 2, true, false))
				{	LockBlock(resBlock);
					if NOT(err = BufferAddCString(outputID, GetPtr(resBlock), ISOLATIN_ENC, kTagsVisible))
						err = BufferAddCString(outputID, "\r\n", NO_ENC, 0);
				}
			}
		}			
	}

if (resBlock)
	DisposeBlock(&resBlock);
if (resBlock2)
	DisposeBlock(&resBlock2);

return err;
}

//===========================================================================================
static XErr	_CLDumpList(long api_data, long outputID, DLMRef llDLRef, long *totalSizeP)
{
XErr		err = noErr;
long		stringLen, totObjs;
CStr255		aCStr;
Ptr			stringP;
BlockRef	ref;
ObjRecord	objRef;
int			i;
//BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
CStr255		errStr;
CStr255		tStr;

	if NOT(err = DLM_GetTotObjs(llDLRef, &totObjs, false))
	{	objRef.list = llDLRef;
		//objRef.classID = kStringClassID;
		objRef.scope = TEMP;
		objRef.type = VARIABLE;
		for (i = 1; i <= totObjs; i++)
		{	objRef.id = i;
			if NOT(err = DLM_GetInfo(llDLRef, i, nil, &objRef.classID, nil))
			{	err = BAPI_GetStringBlockExt(api_data, OBJREF_P(&objRef), aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast, kNormal);
				if (err)
				{	if (err == XError(kBAPI_Error, Err_VariableNotInitialized))
						*errStr = 0;
					else
						BAPI_GetErrDescription(api_data, err, errStr, nil, nil, nil, nil, 0, nil);
					stringP = errStr;
					stringLen = CLen(errStr);
				}
				err = _CLDumpOne(api_data, outputID, stringP, stringLen, objRef.classID, i);
				BAPI_ReleaseBlock(&ref);
			}
		}	
	}
	DLM_ListInfo(llDLRef, nil, nil, nil, totalSizeP);
	if (NOT(err) && totObjs && *totalSizeP)
	{	CEquStr(aCStr, "<br><b>Total: ");
		CNumToString(*totalSizeP, tStr);
		CAddStr(aCStr, tStr);
		CAddStr(aCStr, "</b>\r\n");
		err = BufferAddCString(outputID, aCStr, NO_ENC, 0);
	}
	
return err;
}

//===========================================================================================
static Boolean	_CLExists(long api_data, Ptr f_dataP, long f_dataLen, long f_classID, Boolean fixedSize)
{
XErr			err = noErr;
long			dataLen, classID, totObjs;
int				i;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
unsigned short	flags, f_flags;
long			result;
DLMRef			llDLRef = bicRecP->cl;
Ptr				dataP;
BlockRef		block;

	result = 0;
	if (fixedSize)
		f_flags = kFixedSize;
	else
		f_flags = 0;
	if NOT(err = DLM_GetTotObjs(llDLRef, &totObjs, false))
	{	for (i = 1; (i <= totObjs) && NOT(result); i++)
		{	if NOT(err = DLM_GetInfo(llDLRef, i, &flags, &classID, nil))
			{	if ((flags == f_flags) && (classID == f_classID))
				{	if NOT(err = DLM_GetObj(llDLRef, i, nil, &dataLen, 0, nil))
					{	if (NOT(dataLen) && NOT(f_dataLen))
							result = i;
						else if (block = NewBlockLocked(dataLen, &err, &dataP))
						{	if NOT(err = DLM_GetObj(llDLRef, i, dataP, &dataLen, 0, nil))
							{	if ((dataLen == f_dataLen) && NOT(CompareBlock(dataP, f_dataP, dataLen)))
									result = i;
							}
							DisposeBlock(&block);
						}
					}
				}
			}
		}	
	}
	
return (Boolean)result;
}

//===========================================================================================
static XErr	_CLAdd(long api_data, char *strP, long strLen, ObjRecordP resultObj)
{
XErr		err = noErr;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	if NOT(resultObj->id = _CLExists(api_data, strP, strLen, kStringClassID, false))
		resultObj->id = DLM_NewObj(bicRecP->cl, nil, strP, strLen, kStringClassID, 0L, &err);
	if NOT(err)
	{	resultObj->type = 0;
		BIC_OBJREF_SPEC(resultObj) = kCL_LIST;
		resultObj->classID = kStringClassID;
	}
	
return err;
}

//===========================================================================================
static XErr	_CLAddGeneric(long api_data, Ptr dataP, long dataLen, long classID, Boolean fixedSize, ObjRecordP resultObj)
{
XErr		err = noErr;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
short		flags;

	if NOT(resultObj->id = _CLExists(api_data, dataP, dataLen, classID, fixedSize))
	{	if (fixedSize)
			flags = fixedSize;
		else
			flags = 0;
		resultObj->id = DLM_NewObj(bicRecP->cl, nil, dataP, dataLen, classID, flags, &err);
	}
	if NOT(err)
	{	BIC_OBJREF_SPEC(resultObj) = kCL_LIST;
		resultObj->classID = classID;
	}
		
return err;
}
#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	_GetProperty(long api_data, MemberAction *membActionP, long propertyDim, ArrayIndexRec *propertyIndex, long assignmentType, long incrType, ObjRecordP resultVarRecP, long dest)
{
XErr		err = noErr;
ObjRecord	tempObj;
long		totLessStack, sl_index, slotSize;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
Byte		opCode, param[MAX_PARAM2_SIZE];
Byte		opVariant2 = 0;
Boolean		isExt;

	totLessStack = 0;
	if (membActionP->doc.isStatic && membActionP->doc.info.property.isConst)
	{	
		err = CL_GetProperty(api_data, membActionP, propertyDim, propertyIndex, &tempObj);
		if NOT(err)
			err = BIC_GetBicObjRef(api_data, &tempObj, resultVarRecP);
	}
	else
	{	
		SL_Slot		slot;
	
		ClearBlock(&slot, sizeof(SL_Slot));
		opCode = kGet_o;
		slot.doc = membActionP->doc;
		if (propertyDim > 1)
		{	
			*(short*)param = 0;
			if (assignmentType && (assignmentType != -1))
				opCode = kGetLeaveOnStack_o;
			else
			{	totLessStack += propertyDim;
				if (incrType)
				{	if ((incrType == kPreIncrem) || (incrType == kPostIncrem))
						opCode = kIncrProperty_o;
					else
						opCode = kDecrProperty_o;
				}
			}
		}
		else
		{	
		Ptr				opcodesPtr;
		OpcodeHead		*opHeadP;
		long			size, totSize;
		
			BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
			opHeadP = (OpcodeHead*)(opcodesPtr + totSize - bicRecP->lastOpcodeSize);
			if (opHeadP->opCode == kLoad_o)
			{	
				size = GetOpcodeSize((B_Opcode*)opHeadP);
				if (size == SMALL)
				{	
					isExt = false;
					CopyBlock(param, ((B_Opcode*)opHeadP)->params, sizeof(short));
				}
				else
				{	
					isExt = true;
					CopyBlock(param, ((B_OpcodeExt*)opHeadP)->params, MAX_PARAM2_SIZE);
				}
				opVariant2 = opHeadP->opVariant.pos1;
				NopUnusedOpcode(bicRecP, opcodesPtr, bicRecP->totOpcodes);
				bicRecP->actStack--;
				if (incrType)
				{	if ((incrType == kPreIncrem) || (incrType == kPostIncrem))
						opCode = kIncrProperty_o;
					else
						opCode = kDecrProperty_o;
				}
			}
			else
			{	
				*(short*)param = 0;
				isExt = false;
				if ((assignmentType && (assignmentType != -1)) && propertyDim)
					opCode = kGetLeaveOnStack_o;
				else
				{	totLessStack += propertyDim;
					if (incrType)
					{	if ((incrType == kPreIncrem) || (incrType == kPostIncrem))
							opCode = kIncrProperty_o;
						else
							opCode = kDecrProperty_o;
					}
				}
			}
		}
		if NOT(sl_index = _SLFind(&bicRecP->sl, &slot, slotSize))
			err = _SLAdd(&bicRecP->sl, &slot, slotSize, &sl_index);
		if NOT(err)
		{	
			if NOT(err = Opcode_get(bicRecP, sl_index, totLessStack, param, isExt, opVariant2, opCode, dest))
			{	resultVarRecP->classID = 0;
				resultVarRecP->id = SP;
				resultVarRecP->type = 0;
				BIC_OBJREF_SPEC(resultVarRecP) = kVL_LIST;
				resultVarRecP->scope = 0;
				resultVarRecP->list = 0;
			}
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_SetProperty(long api_data, MemberAction *membActionP, ArrayIndexRec *propertyIndex, long propertyDim, ObjRecordP value, Boolean putResultOnStack, long *sl_indexP)
{
XErr		err = noErr;
long		sl_index, slotSize;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
ObjRecordP	indexObjP;
SL_Slot		slot;
int			totLessStack = 0;

	if (err = CheckSetProperty(membActionP))
		return err;

	if (sl_indexP && (sl_index = *sl_indexP))
		totLessStack = -1;
	else
	{	
		slot.doc = membActionP->doc;
		if (membActionP->doc.isStatic)
		{	
		}
		else
		{	
			if ((BIC_OBJREF_SPEC(&membActionP->objRef) == kVL_LIST) && (membActionP->objRef.id == SP))
				totLessStack++;
		}
		indexObjP = (ObjRecordP)propertyIndex;
		if NOT(sl_index = _SLFind(&bicRecP->sl, &slot, slotSize))
			err = _SLAdd(&bicRecP->sl, &slot, slotSize, &sl_index);
	}
	if NOT(err)
	{	if NOT(err = Opcode_set(bicRecP, sl_index, propertyIndex, propertyDim, totLessStack, value, putResultOnStack))
		{	//if (putResultOnStack)
			//	err = Opcode_load(bicRecP, value);
			if (sl_indexP)
				*sl_indexP = sl_index;	
		}
	}
	
return err;
}

//===========================================================================================
static XErr	_PropertyIncrement(long api_data, BICRecordP bicRecP, PropertyListRec *propertyList, ObjRecordP objRefP, long incrType)
{
XErr		err = noErr;
Boolean		saveRIR;
long		propertyDim, vlIndex;

	propertyDim = propertyList->item[0].propertyDim;
	switch(incrType)
	{
		case kPreIncrem:
			if NOT(_PropertySetPreviousOpcode(bicRecP, kIncrProperty_o, 0, nil, propertyDim))
			{	saveRIR = RESULT_IS_RELEVANT(api_data);
				RESULT_IS_RELEVANT(api_data) = true;
				err = _GetProperty(api_data, &propertyList->item[0].membIdent, propertyDim, propertyList->item[0].propertyIDXPtr, 0, incrType, objRefP, 0);
				RESULT_IS_RELEVANT(api_data) = saveRIR;
			}
			break;
		case kPreDecrem:
			if NOT(_PropertySetPreviousOpcode(bicRecP, kDecrProperty_o, 0, nil, propertyDim))
			{	saveRIR = RESULT_IS_RELEVANT(api_data);
				RESULT_IS_RELEVANT(api_data) = true;
				err = _GetProperty(api_data, &propertyList->item[0].membIdent, propertyDim, propertyList->item[0].propertyIDXPtr, 0, incrType, objRefP, 0);
				RESULT_IS_RELEVANT(api_data) = saveRIR;
			}
			break;
		case kPostIncrem:
		case kPostDecrem:
			if (_PropertySetPreviousOpcode(bicRecP, kGetLeaveOnStack_o, propertyDim, &vlIndex, propertyDim))
			{	if (BIC_OBJREF_SPEC(objRefP) == kVL_LIST)
					objRefP->id = vlIndex;
				else
					CDebugStr("impossible");
			}
			saveRIR = RESULT_IS_RELEVANT(api_data);
			RESULT_IS_RELEVANT(api_data) = true;
			err = _GetProperty(api_data, &propertyList->item[0].membIdent, propertyDim, propertyList->item[0].propertyIDXPtr, 0, incrType, objRefP, 0);
			RESULT_IS_RELEVANT(api_data) = saveRIR;
			break;
	}
	if NOT(err)
	{	objRefP->type = 0;
		BIC_OBJREF_SPEC(objRefP) = kVL_LIST;
		objRefP->classID = 0;
		objRefP->id = SP;
		objRefP->scope = 0;
		objRefP->list = 0;
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BIC_GetBicObjRef(long api_data, ObjRecordP objRecP, ObjRecordP resultP)
{
long		stringLen;
CStr255		aCStr;
Ptr			stringP;
BlockRef	ref;
XErr		err = noErr;
long		strLen;
//BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	if IS_IMMEDIATE_P(objRecP)
	{	resultP->id = IMMEDIATE_ID;
		switch(OBJ_CLASSID_P(objRecP))
		{
			case kBooleanClassID:
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kBooleanClassID;
				*(Boolean*)BIC_IMM_P(resultP) = *(Boolean*)IMM_P(objRecP);
				break;
			case kStringClassID:
				strLen = IMMLEN_STRLEN_P(objRecP);
				if (strLen < MAX_PARAM2_SIZE)
				{	BIC_OBJREF_SPEC(resultP) = kImmediateValue;
					resultP->classID = kStringClassID;
					CopyBlock(BIC_IMM_P(resultP) + 1, IMM_P(objRecP) + 1, strLen);
					BIC_IMMLEN_STRLEN_P(resultP) = (Byte)strLen;
				}
				else
					goto addLL;
				break;
			case kDoubleClassID:
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kDoubleClassID;
				*(double*)BIC_IMM_P(resultP) = *(double*)IMM_P(objRecP);
				break;
			case kLongClassID:
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kLongClassID;
				*(LONGLONG*)BIC_IMM_P(resultP) = *(LONGLONG*)IMM_P(objRecP);
				break;
			case kUnsignedClassID:
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kUnsignedClassID;
				*(unsigned long*)BIC_IMM_P(resultP) = *(unsigned long*)IMM_P(objRecP);
				break;
			case kIntClassID:
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kIntClassID;
				*(long*)BIC_IMM_P(resultP) = *(long*)IMM_P(objRecP);
				break;
			case kCharClassID:
			default:
				goto addGeneric;
				break;
		}
	}
	else
	{	
	long			tLen;
	Boolean			aBool;
	double			aDouble;
	LONGLONG		l;
	unsigned long	uLong;
	long			aLong;
	
	addLL:
		switch(objRecP->classID)
		{
			case kBooleanClassID:
				resultP->id = IMMEDIATE_ID;
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kBooleanClassID;
				tLen = sizeof(Boolean);
				if NOT(err = BAPI_GetObj(api_data, OBJREF_P(objRecP), (Ptr)&aBool, &tLen, 0, nil))
					*(Boolean*)BIC_IMM_P(resultP) = aBool;
				break;
			case kStringClassID:
				if NOT(err = BAPI_GetStringBlock(api_data, OBJREF_P(objRecP), aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast))
				{	err = _CLAdd(api_data, stringP, stringLen, resultP);
					BAPI_ReleaseBlock(&ref);
				}
				break;
			case kDoubleClassID:
				resultP->id = IMMEDIATE_ID;
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kDoubleClassID;
				tLen = sizeof(double);
				if NOT(err = BAPI_GetObj(api_data, OBJREF_P(objRecP), (Ptr)&aDouble, &tLen, 0, nil))
					*(double*)BIC_IMM_P(resultP) = aDouble;
				break;
			case kLongClassID:
				resultP->id = IMMEDIATE_ID;
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kLongClassID;
				tLen = sizeof(LONGLONG);
				if NOT(err = BAPI_GetObj(api_data, OBJREF_P(objRecP), (Ptr)&l, &tLen, 0, nil))
					*(LONGLONG*)BIC_IMM_P(resultP) = l;
				break;
			case kUnsignedClassID:
				resultP->id = IMMEDIATE_ID;
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kUnsignedClassID;
				tLen = sizeof(unsigned long);
				if NOT(err = BAPI_GetObj(api_data, OBJREF_P(objRecP), (Ptr)&uLong, &tLen, 0, nil))
					*(unsigned long*)BIC_IMM_P(resultP) = uLong;
				break;
			case kIntClassID:
				resultP->id = IMMEDIATE_ID;
				BIC_OBJREF_SPEC(resultP) = kImmediateValue;
				resultP->classID = kIntClassID;
				tLen = sizeof(long);
				if NOT(err = BAPI_GetObj(api_data, OBJREF_P(objRecP), (Ptr)&aLong, &tLen, 0, nil))
					*(long*)BIC_IMM_P(resultP) = aLong;
				break;
			case kCharClassID:			
			default:
				{
				Boolean		fixedSize;
				addGeneric:
				
					if NOT(err = BAPI_FixedSize(api_data, OBJ_CLASSID_P(objRecP), &fixedSize))
						err = _CLAddGeneric(api_data, "", 0, OBJ_CLASSID_P(objRecP), fixedSize, resultP);
					// err = Opcode_void(bicRecP, OBJ_CLASSID_P(objRecP), resultP);
				}
				break;
		}
	}

return err;
}

//===========================================================================================
void	BIC_GetRealObjRef(BICRecordP bicRecP, ObjRecordP objRecP, ObjRecordP resultP)
{
int		strLen;

	switch(BIC_OBJREF_SPEC(objRecP))
	{
		case kVL_LIST:
			CDebugStr("da fare");
			break;
		
		case kImmediateValue:
			resultP->id = IMMEDIATE_ID;
			switch(OBJ_CLASSID_P(objRecP))
			{
			case kBooleanClassID:
				resultP->classID = kBooleanClassID;
				*(Boolean*)IMM_P(resultP) = *(Boolean*)BIC_IMM_P(objRecP);
				break;
			case kStringClassID:
				strLen = BIC_IMMLEN_STRLEN_P(objRecP);
				if (strLen < MAX_SPACE_FOR_IMMEDIATE)
				{	resultP->classID = kStringClassID;
					CopyBlock(IMM_P(resultP) + 1, BIC_IMM_P(objRecP) + 1, strLen);
					IMMLEN_STRLEN_P(resultP) = strLen;
				}
				else
					CDebugStr("BIC_GetRealObjRef: impossible");
				break;
			case kDoubleClassID:
				resultP->classID = kDoubleClassID;
				*(double*)IMM_P(resultP) = *(double*)BIC_IMM_P(objRecP);
				break;
			case kLongClassID:
				resultP->classID = kLongClassID;
				*(LONGLONG*)IMM_P(resultP) = *(LONGLONG*)BIC_IMM_P(objRecP);
				break;
			case kUnsignedClassID:
				resultP->classID = kUnsignedClassID;
				*(unsigned long*)IMM_P(resultP) = *(unsigned long*)BIC_IMM_P(objRecP);
				break;
			case kIntClassID:
				resultP->classID = kIntClassID;
				*(long*)IMM_P(resultP) = *(long*)BIC_IMM_P(objRecP);
				break;
			case kCharClassID:
			default:
				CDebugStr("BIC_GetRealObjRef: impossible");
				break;
			}
			break;
			
		case kCL_LIST:
			resultP->type = 0;
			resultP->list = bicRecP->cl;
			resultP->id = objRecP->id;
			resultP->classID = objRecP->classID;
			resultP->scope = 0;
			break;
		
		default:
			CDebugStr("BIC_GetRealObjRef: impossible");
			// *resultP = *objRecP;
			//resultP->classID = objRecP->id;
			//resultP->id = IMMEDIATE_ID;
			break;

	}
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BIC_TypeCast(long api_data, ObjRecordP source, long requestedClassID, ObjRecordP resultP)
{
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
XErr			err = noErr;

	if RESULT_IS_RELEVANT(api_data)
		err = Opcode_typeCast(bicRecP, source, requestedClassID, resultP, api_data);
	
return err;
}

//===========================================================================================
XErr	BIC_Index(long api_data, ObjRecordP arrayObjrecP, ArrayIndexRec *mCoords, long dim, ObjRecordP resultP)
{
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
XErr			err = noErr;

	if RESULT_IS_RELEVANT(api_data)
	{	if NOT(err = Opcode_index(bicRecP, arrayObjrecP, mCoords, dim, kIndex_o, SP))
		{	resultP->type = 0;
			BIC_OBJREF_SPEC(resultP) = kVL_LIST;
			resultP->classID = 0;
			resultP->id = SP;
			resultP->scope = 0;
			resultP->list = 0;
		}
	}
	
return err;
}

//===========================================================================================
Boolean	BIC_IsLiteral(ObjRecordP objRefP)
{
	return (BIC_IS_IMM(objRefP));
	// objRefP->classID != kVL_LIST;
}

//===========================================================================================
XErr	BIC_LoadParam(long api_data, ObjRecordP objToLoad)
{
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
XErr			err = noErr;

	err = Opcode_load(bicRecP, objToLoad);

return err;
}

//===========================================================================================
XErr	BIC_SetProperty(long api_data, MemberAction *membIdentP, ArrayIndexRec *propertyIndex, long propertyDim, ObjRecordP value, Boolean putResultOnStack)
{
	return _SetProperty(api_data, membIdentP, propertyIndex, propertyDim, value, putResultOnStack, nil);
}

//===========================================================================================
XErr	BIC_GetProperty(long api_data, MemberAction *membIdentP, long propertyDim, ArrayIndexRec *propertyIndex, long assignmentType, ObjRecordP resultVarRecP, Boolean compilerAnyway)
{
	if (NOT(RESULT_IS_RELEVANT(api_data)) && NOT(compilerAnyway))
		return noErr;
	else
		return _GetProperty(api_data, membIdentP, propertyDim, propertyIndex, assignmentType, 0, resultVarRecP, SP);
}

//===========================================================================================
/*
- la call, al runtime, dovra' mettere sullo stack prima i parametri per address e poi il return value
- functionName contiene il nome della func (membActionP puo' essere null (not found quindi dinamica, DL)) 
*/
/*
 XErr	BIC_CallFunction(long api_data, MemberAction *membActionP, char *functionName, ParameterRec *paramVarsP, long totParams, ObjRecordP resultP, Boolean fromConstructor)
{
	XErr				err = noErr;
	BICRecord			*bicRecP = &((BifernoRecP)api_data)->bicRecord;
	long				totLessStack, sl_index;
	Byte				opCode;
	long				initialTotParams, slotSize, returnClassID;
	SL_Slot				*slSlotPtr = nil;
	BlockRef			slSlotBlockRef;
	long				moreStacks;
	Boolean				ssd, isBiferno;
	long				pluginID;
	//long				funcObjID = 0;
	
	if (membActionP)
	{
		pluginID = membActionP->doc.info.method.classID;
		isBiferno = membActionP->doc.implem == kBifernoImplementation;
	}
	else
	{
		pluginID = 0;
		isBiferno = false;
	}
	
	opCode = kCall_o;
	initialTotParams = totParams;
	if NOT(err = _ParamPreprocess(api_data, membActionP, paramVarsP, &totParams, &totLessStack, &returnClassID, &slSlotBlockRef, &slotSize, &moreStacks, fromConstructor))
	{	
		slSlotPtr = (SL_Slot*)GetPtr(slSlotBlockRef);
		if (slSlotPtr->head.forAddress)
			opCode = kCallini_o;
		slSlotPtr->head.dim = totParams;
		if (functionName)
			CEquStr(slSlotPtr->head.membName, functionName);
		else if (membActionP)
			CEquStr(slSlotPtr->head.membName, membActionP->doc.name);
		else
			err = BAPI_NameFromClassID(api_data, pluginID, slSlotPtr->head.membName);
		if NOT(err)
		{	
			slSlotPtr->head.pluginID = pluginID;
			slSlotPtr->head.isProperty = false;
			if (membActionP && membActionP->objRef.id)
			{	
				slSlotPtr->head.objRef = membActionP->objRef;
				if ((BIC_OBJREF_SPEC(&membActionP->objRef) == kVL_LIST) && (membActionP->objRef.id == SP))
					totLessStack++;
			}
			if NOT(sl_index = _SLFind(&bicRecP->sl, slSlotPtr, slotSize))
				err = _SLAdd(&bicRecP->sl, slSlotPtr, slotSize, &sl_index);
			if NOT(err)
			{	
				if NOT(RESULT_IS_RELEVANT(api_data))
					returnClassID = 0;					
				else if (slSlotPtr->head.NOT_RESOLVED)
					returnClassID = 1;	// put always on stack
				if (opCode == kCallini_o)
				{	
					ssd = SMART_STORE_DISABLED(bicRecP);
					SMART_STORE_DISABLED(bicRecP) = true;
				}
				if (slSlotPtr->head.NOT_RESOLVED)
					sl_index = -sl_index;
				if NOT(err = Opcode_invoke(bicRecP, sl_index, opCode, totLessStack, moreStacks, returnClassID))
				{	
					BAPI_ParameterDoc	*protoParamP;
					int					totParamsInProto;
					if (membActionP)
					{	
						protoParamP = membActionP->doc.params;
						totParamsInProto = membActionP->doc.totParams;
					}
					else
					{	
						protoParamP = nil;
						totParamsInProto = totParams;
					}
					if NOT(err = _AddressOnStack(api_data, nil, protoParamP, totParamsInProto, paramVarsP, initialTotParams, slSlotPtr->paramInfo, nil, membActionP != nil))
					{	// also if we didn't put on stack (returnClassID == 0), return SP as result for better error checking
						resultP->type = 0;
						BIC_OBJREF_SPEC(resultP) = kVL_LIST;
						resultP->classID = 0;
						resultP->id = SP;
						resultP->scope = 0;
						resultP->list = 0;
					}
				}
				if (opCode == kCallini_o)
					SMART_STORE_DISABLED(bicRecP) = ssd;
			}
		}
		DisposeBlock(&slSlotBlockRef);
		//if (protoParamBlock)
		//	DisposeBlock(&protoParamBlock);
	}
	if NOT(err)
	{	
		if (opCode == kCallini_o)
			Opcode_NoParams(bicRecP, kCallend_o);
	}
	
	return err;
}
*/

//===========================================================================================
XErr	BIC_CallFunction(long api_data, MemberAction *membActionP, char *functionName, ParameterRec *paramVarsP, long totParams, ObjRecordP resultP, Boolean fromConstructor)
{
	XErr		err = noErr;
	SL_Slot		*slSlotPtr = nil;
	BlockRef	slSlotBlockRef;
	long		returnClassID, sl_index, totLessStack, moreStacks = 0;
	BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
	long		slotSize = sizeof(SL_Slot);
	
	if not(membActionP)
		return XError(kBAPI_Error, Err_NoSuchFunction);
	if (slSlotBlockRef = NewBlockLocked(slotSize, &err, (Ptr*)&slSlotPtr))
	{
		ClearBlock(slSlotPtr, slotSize);
		slSlotPtr->doc = membActionP->doc;
		
		totLessStack = totParams;	// membActionP->doc.totParams;
		if (membActionP->objRef.id)
		{	
			slSlotPtr->objRef = membActionP->objRef;
			if ((BIC_OBJREF_SPEC(&membActionP->objRef) == kVL_LIST) && (membActionP->objRef.id == SP))
				totLessStack++;
		}
		if NOT(sl_index = _SLFind(&bicRecP->sl, slSlotPtr, slotSize))
			err = _SLAdd(&bicRecP->sl, slSlotPtr, slotSize, &sl_index);
		if NOT(err)
		{	
			if NOT(RESULT_IS_RELEVANT(api_data))
				returnClassID = 0;
			if NOT(err = Opcode_invoke(bicRecP, sl_index, kCall_o, totLessStack, moreStacks, returnClassID))
			{	
				// also if we didn't put on stack (returnClassID == 0), return SP as result for better error checking
				resultP->type = 0;
				BIC_OBJREF_SPEC(resultP) = kVL_LIST;
				if (fromConstructor)
					resultP->classID = membActionP->doc.info.method.classID;
				else
					resultP->classID = membActionP->doc.returnClassID;
				resultP->id = SP;
				resultP->scope = 0;
				resultP->list = 0;
			}
		}
		DisposeBlock(&slSlotBlockRef);
	}
	
	return err;
}
	
//===========================================================================================
XErr	BIC_AddLabel(long api_data, char *labelName)
{
	return _LabelAdd(api_data, labelName, nil, true);
}

//===========================================================================================
XErr	BIC_AddGoto(long api_data, char *labelName)
{
XErr		err = noErr;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
long		totGotos, totLabels;
LabelRecP	labelP;
GotoRecP	gotoP;

	totLabels = bicRecP->totLabels;
	if (totLabels)
	{	labelP = (LabelRecP)GetPtr(bicRecP->labelsBlock);
		do {
			if NOT(CCompareStrings_cs(labelName, labelP->labelName))
				break;
			else
				labelP++;
		} while (--totLabels && NOT(err));
		if NOT(err)
		{	if NOT(totLabels)
				err = _LabelAdd(api_data, labelName, (Ptr*)&labelP, false);
		}
	}
	else
		err = _LabelAdd(api_data, labelName, (Ptr*)&labelP, false);
	if NOT(err)
	{	LockBlock(bicRecP->labelsBlock);
		totGotos = labelP->totGotos + 1;
		if NOT(err = SetBlockSize(labelP->gotoBlock, totGotos * sizeof(GotoRec)))
		{	gotoP = (GotoRecP)GetPtr(labelP->gotoBlock) + labelP->totGotos;
			labelP->totGotos++;
			gotoP->gotoLine = ((BifernoRecP)api_data)->currentCtx.currentLine;
			err = BIC_GetOffset(api_data, &gotoP->opcodeOffset);
		}
		UnlockBlock(bicRecP->labelsBlock);
	}

return err;
}
//===========================================================================================
XErr	BIC_Ternary(long api_data, ObjRecord *obj1, ObjRecord *obj2, ObjRecord *obj3, ObjRecord *resultP)
{
XErr		err = noErr;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	if NOT(err = Opcode_tern(bicRecP, obj1, obj2, obj3, resultP, api_data))
	{	if NOT(VALID_P(resultP))
		{	resultP->type = 0;
			BIC_OBJREF_SPEC(resultP) = kVL_LIST;
			resultP->classID = 0;
			resultP->id = SP;
			resultP->scope = 0;
			resultP->list = 0;
		}
	}
	
//out:
return err;
}

//===========================================================================================
XErr	BIC_ExecuteOperation(long api_data, ObjRecordP item1, ObjRecordP item2, long operation, ObjRecordP resultP)
{
XErr		err = noErr;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	switch(operation)
	{
		case EVAL_MULT:
			err = Opcode_operation(bicRecP, item1, item2, kMul_o, operation, resultP, api_data);
			break;
		case EVAL_DIV:
			err = Opcode_operation(bicRecP, item1, item2, kDiv_o, operation, resultP, api_data);
			break;
		case EVAL_MOD:
			err = Opcode_operation(bicRecP, item1, item2, kMod_o, operation, resultP, api_data);
			break;
		case EVAL_ADD:
			err = Opcode_operation(bicRecP, item1, item2, kAdd_o, operation, resultP, api_data);
			break;
		case EVAL_MINUS:
			err = Opcode_operation(bicRecP, item1, item2, kSub_o, operation, resultP, api_data);
			break;
		case EVAL_SHIFTR:
			err = Opcode_operation(bicRecP, item1, item2, kShiftL_o, operation, resultP, api_data);
			break;
		case EVAL_SHIFTL:
			err = Opcode_operation(bicRecP, item1, item2, kShiftR_o, operation, resultP, api_data);
			break;
		case EVAL_GTH:
			err = Opcode_operation(bicRecP, item1, item2, kGreat_o, operation, resultP, api_data);
			break;
		case EVAL_LTH:
			err = Opcode_operation(bicRecP, item1, item2, kLess_o, operation, resultP, api_data);
			break;
		case EVAL_GEQ:
			err = Opcode_operation(bicRecP, item1, item2, kGreatE_o, operation, resultP, api_data);
			break;
		case EVAL_LEQ:
			err = Opcode_operation(bicRecP, item1, item2, kLessE_o, operation, resultP, api_data);
			break;
		case EVAL_EQUA:
			err = Opcode_operation(bicRecP, item1, item2, kEqua_o, operation, resultP, api_data);
			break;
		case EVAL_NEQUA:
			err = Opcode_operation(bicRecP, item1, item2, kNotEqua_o, operation, resultP, api_data);
			break;
		case EVAL_ARAND:
			err = Opcode_operation(bicRecP, item1, item2, kArAnd_o, operation, resultP, api_data);
			break;
		case EVAL_AROR:
			err = Opcode_operation(bicRecP, item1, item2, kArOr_o, operation, resultP, api_data);
			break;
		case EVAL_LOGIC_AND:
			err = Opcode_operation(bicRecP, item1, item2, kLogicAnd_o, operation, resultP, api_data);
			break;
		case EVAL_LOGIC_OR:
			err = Opcode_operation(bicRecP, item1, item2, kLogicOr_o, operation, resultP, api_data);
			break;
	}
	/*if NOT(err)		// result always on the stack
	{	resultP->classID = kVL_LIST;
		resultP->id = SP;
	}*/

return err;
}

//===========================================================================================
XErr	BIC_Opposite(long api_data, ObjRecordP objP, ObjRecordP resultP)
{
XErr		err = noErr;
ObjRecord	tempObjRef1, resultVarRec;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	if (BIC_OBJREF_SPEC(objP) == kVL_LIST)
	{
		err = Opcode_opposite(bicRecP, objP, resultP);
	}
	else
	{	BIC_GetRealObjRef(bicRecP, objP, &tempObjRef1);
		if (IS_IMMEDIATE(tempObjRef1))
		{	resultVarRec.id = IMMEDIATE_ID;
			resultVarRec.classID = OBJ_CLASSID(tempObjRef1);
			switch(OBJ_CLASSID(tempObjRef1))
			{
				case kBooleanClassID:
					*(Boolean*)IMM(resultVarRec) = -*(Boolean*)IMM(tempObjRef1);
					break;
				case kStringClassID:
					err = XError(kBAPI_Error, Err_IllegalOperation);
					break;
				case kDoubleClassID:
					*(double*)IMM(resultVarRec) = -*(double*)IMM(tempObjRef1);
					break;
				case kLongClassID:
					*(LONGLONG*)IMM(resultVarRec) = -*(LONGLONG*)IMM(tempObjRef1);
					break;
				case kUnsignedClassID:
					*(unsigned long*)IMM(resultVarRec) = /*-*/*(unsigned long*)IMM(tempObjRef1);
					break;
				case kIntClassID:
					*(long*)IMM(resultVarRec) = -*(long*)IMM(tempObjRef1);
					break;
				case kCharClassID:
					CDebugStr("impossible char immediate");
					break;
			}
		}
		else
			err = CL_Opposite(api_data, &tempObjRef1, &resultVarRec);
		if NOT(err)
			err = BIC_GetBicObjRef(api_data, &resultVarRec, resultP);
	}

return err;
}

//===========================================================================================
/*
objLeftP is anyway a VL
objRightP can be SP, LL, VL or immediate
*/
XErr	BIC_DoAssignment(long api_data, ObjRecordP objLeftP, char *varName, long assignmentType, ArrayIndexRec *mCoords, long mCoordDim, BlockRef propListBlock, ObjRecordP objRightP)
{
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
ObjRecord		firstOperand, result;
int				totProperties;
PropertyListRec *propertyList;

	propertyList = (PropertyListRec*)GetPtr(propListBlock);
	if (propertyList)
		totProperties = propertyList->totItems;
	else
		totProperties = 0;
	switch(assignmentType)
	{
		case ASSIGN:
			if NOT(totProperties)
			{
				if not(objLeftP->id)
					err = _VLAdd(&bicRecP->vl, varName, objLeftP->scope, objRightP->classID, &objLeftP->id);
				if not(err)
					err = Opcode_store(bicRecP, objLeftP, objRightP, mCoords, mCoordDim);
			}
			break;
		case ADDASSIGN:
			if NOT(err = _GetFirstOperand(bicRecP, objLeftP, &firstOperand, mCoords, mCoordDim))
			{	if NOT(err = Opcode_operation(bicRecP, &firstOperand, objRightP, kAdd_o, EVAL_ADD, &result, api_data))
				{	if NOT(totProperties)
						err = Opcode_store(bicRecP, objLeftP, &result, mCoords, mCoordDim);
				}
			}
			break;
		case SUBASSIGN:
			if NOT(err = _GetFirstOperand(bicRecP, objLeftP, &firstOperand, mCoords, mCoordDim))
			{	if NOT(err = Opcode_operation(bicRecP, &firstOperand, objRightP, kSub_o, EVAL_MINUS, &result, api_data))
				{	if NOT(totProperties)
						err = Opcode_store(bicRecP, objLeftP, &result, mCoords, mCoordDim);
				}
			}
			break;
		case MULTASSIGN:
			if NOT(err = _GetFirstOperand(bicRecP, objLeftP, &firstOperand, mCoords, mCoordDim))
			{	if NOT(err = Opcode_operation(bicRecP, &firstOperand, objRightP, kMul_o, EVAL_MULT, &result, api_data))
				{	if NOT(totProperties)
						err = Opcode_store(bicRecP, objLeftP, &result, mCoords, mCoordDim);
				}
			}
			break;
		case DIVASSIGN:
			if NOT(err = _GetFirstOperand(bicRecP, objLeftP, &firstOperand, mCoords, mCoordDim))
			{	if NOT(err = Opcode_operation(bicRecP, &firstOperand, objRightP, kDiv_o, EVAL_DIV, &result, api_data))
				{	if NOT(totProperties)
						err = Opcode_store(bicRecP, objLeftP, &result, mCoords, mCoordDim);
				}
			}
			break;
	}
	if NOT(err)
	{	if (propertyList && (totProperties = propertyList->totItems))
		{	
		PropertyItem	*propertyItemP;
		int				i;
		Boolean			putResultOnStack;
		long			slIndex, *slIndexP, bnseOff, elseOffset;
		ObjRecord		saveObj;
		
			if (totProperties > 1)
				err = BIC_Branch(api_data, false, true, nil, INVALID_ABSOLUTE_BR_OFFSET, &bnseOff, true);
			if NOT(err)
			{	LockBlock(propListBlock);
				*objLeftP = *objRightP;
				saveObj = *objRightP;
				propertyItemP = &propertyList->item[totProperties-1];
				slIndex = 0;
				slIndexP = &slIndex;
				for (i = (totProperties-1); (i >= 0) && NOT(err); i--, propertyItemP--)		// right to left!
				{	if NOT(i)
						putResultOnStack = false;
					else
						putResultOnStack = true;
					if (err = _SetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyIDXPtr, propertyItemP->propertyDim, objRightP, putResultOnStack, slIndexP))
						NewMsgRecord(api_data, kSETPROPERTY, propertyItemP->membIdent.doc.name, 0, 0);
					else
					{	slIndexP = nil;
						*objRightP = propertyItemP->membIdent.objRef;
					}
				}
				UnlockBlock(propListBlock);
				if NOT(err)
				{	if (totProperties > 1)
					{	if NOT(err = BIC_Branch(api_data, false, true, nil, INVALID_ABSOLUTE_BR_OFFSET, &elseOffset, false))
						{	if (err = BIC_BranchUpdateOffset(api_data, bnseOff, INVALID_ABSOLUTE_BR_OFFSET))
								goto out;
							propertyItemP = &propertyList->item[totProperties-1];
							if (err = _SetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyIDXPtr, propertyItemP->propertyDim, &saveObj, false, &slIndex))
								goto out;
							if (err = BIC_BranchUpdateOffset(api_data, elseOffset, INVALID_ABSOLUTE_BR_OFFSET))
								goto out;
						}
					}
				}
			}
		}
	}

out:
return err;
}

//===========================================================================================
/*XErr	FlushPostIncr(BICRecordP bicRecP)
{
XErr			err = noErr;

	// C'era un post decr da mettere
	if (bicRecP->postIncrType)
	{	err = Opcode_OneParam(bicRecP, &bicRecP->postIncrObjRef, bicRecP->postIncrType, true);
		bicRecP->postIncrType = 0;
	}

return err;
}*/

//===========================================================================================
XErr	BIC_DoIncrement(long api_data, ObjRecordP objRefP, ArrayIndexRec *mCoords, long mCoordDim, BlockRef propListBlock, long incrType)
{
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
PropertyListRec *propertyList;
long			totProperties = 0;

	if (propListBlock)
	{	propertyList = (PropertyListRec*)GetPtr(propListBlock);
		if (propertyList)
			totProperties = propertyList->totItems;
	}
	if (mCoords && mCoordDim)
		err = _ArrayIncrement(bicRecP, objRefP, mCoords, mCoordDim, incrType);
	else if (totProperties)
	{	LockBlock(propListBlock);
		err = _PropertyIncrement(api_data, bicRecP, propertyList, objRefP, incrType);
		UnlockBlock(propListBlock);
	}
	else
	{	switch(incrType)
		{
			case kPreIncrem:
				err = Opcode_OneParam(bicRecP, objRefP, kIncr_o);
				break;
			case kPreDecrem:
				err = Opcode_OneParam(bicRecP, objRefP, kDecr_o);
				break;
			case kPostIncrem:
				if NOT(err = BIC_LoadParam(api_data, objRefP))
				{	if NOT(err = Opcode_OneParam(bicRecP, objRefP, kIncr_o))
					{	objRefP->type = 0;
						BIC_OBJREF_SPEC(objRefP) = kVL_LIST;
						objRefP->classID = 0;
						objRefP->id = SP;
						objRefP->scope = 0;
						objRefP->list = 0;
					}
				}
				break;
			case kPostDecrem:
				if NOT(err = BIC_LoadParam(api_data, objRefP))
				{	if NOT(err = Opcode_OneParam(bicRecP, objRefP, kDecr_o))
					{	objRefP->type = 0;
						BIC_OBJREF_SPEC(objRefP) = kVL_LIST;
						objRefP->classID = 0;
						objRefP->id = SP;
						objRefP->scope = 0;
						objRefP->list = 0;
					}
				}
				break;
		}
	}

return err;
}

//===========================================================================================
void	BIC_LiteralBoolToObjRef(long api_data, Boolean value, ObjRecordP resultObj)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif

	BIC_OBJREF_SPEC(resultObj) = kImmediateValue;
	resultObj->id = IMMEDIATE_ID;
	resultObj->classID = kBooleanClassID;
	*(Boolean*)BIC_IMM_P(resultObj) = value;
}

//===========================================================================================
Boolean	BIC_LiteralNumToObjRef(long api_data, long classID, StringPtr tempStr, ObjRecordP resultObj, XErr *errP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
int		strlen = *tempStr;
XErr	err = noErr;
long	aLong;

	BIC_OBJREF_SPEC(resultObj) = kImmediateValue;
	resultObj->id = IMMEDIATE_ID;
	if (errP)
		*errP = noErr;
	if (classID == kIntClassID)
	{	if (strlen > 19)
		{	double r;
		
			resultObj->classID = kDoubleClassID;
			r = PStrToReal(tempStr);
			*(double*)BIC_IMM_P(resultObj) = r;
		}
		else if (strlen > 9)
		{	LONGLONG	l;
		
			if NOT(err = PStringToLongNum(tempStr, &l))
			{	resultObj->classID = kLongClassID;
				*(LONGLONG*)BIC_IMM_P(resultObj) = l;
			}
		}
		else
		{	PStringToNum(tempStr, &aLong);
			resultObj->classID = kIntClassID;
			*(long*)BIC_IMM_P(resultObj) = aLong;
		}
	}
	else if (classID == kDoubleClassID)
	{	Byte		*strP = tempStr;

		if ((*strP++ == 1) && (*strP == '.'))
			return false;
		else
		{	resultObj->classID = kDoubleClassID;
			*(double*)BIC_IMM_P(resultObj) = PStrToReal(tempStr);
		}
	}
	if (errP)
		*errP = err;

return true;
}

//===========================================================================================
XErr	BIC_LiteralStringToObjRef(long api_data, char *strP, long strLen, ObjRecordP resultObj)
{	
XErr		err = noErr;
//BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	if (strLen <= (BIC_MAX_SPACE_FOR_IMMEDIATE - 1))	// create a pascal immediate string
	{	
	Byte	*byteP;

		BIC_OBJREF_SPEC(resultObj) = kImmediateValue;
		resultObj->classID = kStringClassID;
		resultObj->id = IMMEDIATE_ID;
		byteP = (Byte*)BIC_IMM_P(resultObj);
		*byteP = (Byte)strLen;
		CopyBlock(byteP + 1, strP, strLen);
	}
	else
		err = _CLAdd(api_data, strP, strLen, resultObj);

return err;
}

//===========================================================================================
XErr	BIC_IdentifyObject(long api_data, char *varName, Ptr textP, long len, long theScope, Boolean *isFunctionP, ObjRecord *objRefP)
{	
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			isApplication, exists, isFunction;

	isFunction = false;
	ClearBlock(objRefP, sizeof(ObjRecord));
	if (BAPI_ClassIDFromName(api_data, varName, true))
		return noErr;
	else if (DLM_GetObjID(gsDispatcherData.functionsList, varName, nil, nil))
		return noErr;
	else if (NOT(err = GetUserFunctionInfo(bRecP, varName, nil, &exists, &isApplication)) && exists && not(isApplication))		// da rivedere
		return noErr;
	else if (DLM_GetObjID(gsDispatcherData.reservedKeyword, varName, nil, nil) || DLM_GetObjID(gsDispatcherData.flowControls, varName, nil, nil))
	{	
		err = XError(kBAPI_Error, Err_ReservedKeyword);
		NewMsgRecord(api_data, kDOING, varName, 0, 0);
	}
	else
	{	
		if (bicRecP->classOfParamDefault)
		{
		BlockRef	 		membIdent;
		ObjRecord			nullObj;
		Boolean				memberExists;
		
			INVAL(nullObj);
			//CEquStr(membIdent.doc.name, varName);
			if NOT(err = GetMemberInfo(api_data, varName, bicRecP->classOfParamDefault, &nullObj, &membIdent, nil, 0, &memberExists, true, nil, false, false))
			{	
			//#ifdef _to_avoid_a_warning_of_logical_tests_reinsert_when_get_compiler
				MemberAction 		*membActionP;
				ObjRecord			tObjRecord;
				membActionP = (MemberAction*)GetPtr(membIdent);
				if NOT(memberExists)
					err = XError(kBAPI_Error, Err_BadPrototype);
				else if (NOT(membActionP->doc.isStatic) || ((membActionP->doc.type == kProperty) && NOT(membActionP->doc.info.property.isConst)) || NOT(membActionP->doc.type == kConstant) || NOT(membActionP->doc.type == kError))
					err = XError(kBAPI_Error, Err_BadPrototype);
				else
				{	err = CL_GetProperty(api_data, membActionP, 0, nil, &tObjRecord);
					if NOT(err)
						err = BIC_GetBicObjRef(api_data, &tObjRecord, objRefP);
				}
			//#endif	
				DisposeBlock(&membIdent);
			}
		}
		else
		{	
			// is a function (or constructor)?
			SkipSpaceAndTab(&textP, &len);
			if (len && (*textP == '('))
				isFunction = true;
			else
				isFunction = false;
			
			// Is the object in the VL?
			objRefP->id = _VLFind(&bicRecP->vl, varName, theScope, &objRefP->classID);
			if (isFunction)
			{
				if (objRefP->id)
					err = XError(kBAPI_Error, Err_BadSyntax);
			}
			else	
			{
				//if NOT(objRefP->id)
				//	err = _VLAdd(&bicRecP->vl, varName, theScope, &objRefP->id);
			}
			if (not(err) && not(isFunction))
			{
				objRefP->type = 0;
				BIC_OBJREF_SPEC(objRefP) = kVL_LIST;
				objRefP->scope = theScope;
				objRefP->list = 0;
			}
		}
	}
	if (isFunctionP)
		*isFunctionP = isFunction;
	
return err;
}

//===========================================================================================
XErr	BIC_FlowControl(long api_data, long which, ObjRecordP param1)
{
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	switch(which)
	{
		case k_Exit:
			err = Opcode_NoParams(bicRecP, kExit_o);
			break;
		case k_Stop:
			err = Opcode_NoParams(bicRecP, kStop_o);
			break;
		case k_For:
			break;
		case k_Do:
			break;
		case k_While:
			break;
		case k_If:
			break;
		case k_Else:
			break;
		case k_Break:
			break;
		case k_Continue:
			break;
		case k_Switch:
			break;
		case k_Case:
			break;
		case k_Default:
			break;
		case k_Include:
			err = Opcode_OneParam(bicRecP, param1, k_Include_o);
			break;
		case k_Lock:
			err = Opcode_NoParams(bicRecP, k_Lock_o);
			break;
		case k_Unlock:
			err = Opcode_NoParams(bicRecP, k_Unlock_o);
			break;
		case k_Debug:
			err = Opcode_NoParams(bicRecP, kDebug_o);
			break;
		case k_Goto:
			break;
		case k_Function:
			break;
		case k_Class:
			break;
		case k_Return:
			break;
		default:
			err = -1;
	}

return err;
}

//===========================================================================================
XErr	BIC_StandardOutput(long api_data, char *textP, long len)
{
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
ObjRecord		resultObj;
long			llIndex, totSize;
Ptr				opcodesPtr;
OpcodeHead		*opHeadP;
VariantRec		*variantP = (VariantRec*)&bicRecP->lastOpVariant;

	if (len)
	{	if ((bicRecP->lastOpcode == kPrint_o) && (variantP->pos1 == kVariantCL_LIST))
		{	// Get last opcode
			BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
			opHeadP = (OpcodeHead*)(opcodesPtr + totSize - bicRecP->lastOpcodeSize);
			llIndex = PARAM_1_SHORT(opHeadP);
			//ex *(short*)&((B_Opcode*)opHeadP)->param2;
			err = DLM_AddToObj(bicRecP->cl, llIndex, textP, len);
		}
		else
		{	if NOT(err = _CLAdd(api_data, textP, len, &resultObj))
				err = Opcode_OneParam(bicRecP, &resultObj, kPrint_o);
		}
	}
	
return err;
}

//===========================================================================================
XErr	BIC_Print(long api_data, ObjRecordP objToPrint)
{
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	err = Opcode_OneParam(bicRecP, objToPrint, kPrint_o);
	
return err;
}

//===========================================================================================
XErr	BIC_Branch(long api_data, Boolean notMode, Boolean absolute, ObjRecord *objRefP, long absoluteOffset, long *opcodeOffsetP, Boolean isBnse)
{
XErr		err = noErr;
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
Byte		op;
long		opcodeOffset, relativeOffset;

	if (absolute)
	{	if (isBnse)
			op = kBnse_o;
		else
			op = kBra_o;
	}
	else
	{	if (notMode)
			op = kBet_o;
		else
			op = kBef_o;
	}
	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &opcodeOffset, nil);
	//if (bicRecP->postIncrType)
	//	opcodeOffset += SMALL;
	if (opcodeOffsetP)
		*opcodeOffsetP = opcodeOffset;
	if (absoluteOffset == INVALID_ABSOLUTE_BR_OFFSET)
		relativeOffset = 0;
	else
		relativeOffset = absoluteOffset - opcodeOffset;
	err = Opcode_branch(bicRecP, objRefP, relativeOffset, op, api_data);
	
return err;
}

//===========================================================================================
XErr	BIC_BranchUpdateOffset(long api_data, long opcodeOffset, long absoluteBranchOffset)
{
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
long			actualOffset;
B_OpcodeExt		*opcodeP;
Ptr				opcodesPtr;

	//FlushPostIncr(bicRecP);
	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &actualOffset, &opcodesPtr);
	if (absoluteBranchOffset >= 0)
		actualOffset = absoluteBranchOffset - opcodeOffset;
	else
		actualOffset -= opcodeOffset;
	opcodeP = (B_OpcodeExt*)(opcodesPtr + opcodeOffset);
	if (BRANCH_OFFSET(opcodeP) == 0)
		BRANCH_OFFSET(opcodeP) = actualOffset;
	else
		CDebugStr("Invalid Branch offset Update");
	
return err;
}

//===========================================================================================
XErr	BIC_GetOffset(long api_data, long *offsetP)
{
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;

	//FlushPostIncr(bicRecP);
	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, offsetP, nil);

return noErr;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	BIC_End(long api_data)
{	
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
XErr		err = noErr;
	
	if not(bicRecP->disposed)
	{
		//	Dispose this
		if (bicRecP->labelsBlock)
			_LabelDispose(bicRecP);
		if (bicRecP->opcodesStack)
			BufferFree(bicRecP->opcodesStack);

		//	In a future don't dispose these and save them in cache
		if (bicRecP->sl.block)
			DisposeBlock(&bicRecP->sl.block);
		if (bicRecP->sl.offsets)
			DisposeBlock(&bicRecP->sl.offsets);
		if (bicRecP->vl.block)
			DisposeBlock(&bicRecP->vl.block);
		if (bicRecP->gl.block)
			DisposeBlock(&bicRecP->gl.block);
		if (bicRecP->cl)
			DLM_Dispose(&bicRecP->cl, nil, 0);	
		if (bicRecP->opcodesBufferID)
			BufferFree(bicRecP->opcodesBufferID);
		bicRecP->disposed == true;
	}
	
return err;
}

//===========================================================================================
XErr	BIC_Init(long api_data)
{	
BICRecord	*bicRecP = &((BifernoRecP)api_data)->bicRecord;
XErr		err = noErr;
//char		*strP;
//XFileInfo	fInfo;

	ClearBlock(bicRecP, sizeof(BICRecord));
	
	if (bicRecP->gl.block = NewBlock(sizeof(VL_Slot), &err, nil))		// global
		bicRecP->vl.block = NewBlock(sizeof(VL_Slot), &err, nil);
	if not(err)
	{	
		bicRecP->gl.totSlots = 0;
		bicRecP->vl.totSlots = 0;
	
		if NOT(err = DLM_Create(&bicRecP->cl, ID_LIST, false))
		{					
			bicRecP->opcodesBufferID = BufferCreateClear(1024, &err);
			if NOT(err)
			{	
				bicRecP->labelsBlock = NewBlock(1 * sizeof(LabelRec), &err, nil);
				bicRecP->totLabels = 0;
				bicRecP->sl.blockSize = 0;
				if (bicRecP->sl.block = NewBlock(sizeof(SL_Slot), &err, nil))
				{	
					bicRecP->sl.totSlots = 0;
					if (bicRecP->sl.offsets = NewBlock(sizeof(long), &err, nil))
						bicRecP->opcodesStack = BufferCreateClear(32 * sizeof(OpStackInfo), &err);
				}
			}
			
			/*CEquStr(bicRecP->basmFilePath, ((BifernoRecP)api_data)->curFile.filePath);
			strP = strrchr(bicRecP->basmFilePath, '.');
			*strP = 0;
			CAddStr(bicRecP->basmFilePath, ".basm");
			if NOT(err = OpenXFile(bicRecP->basmFilePath, CREATE_FILE_ALWAYS, READ_WRITE_PERM, true, &bicRecP->basmRefNum))
			{	
			#if __MAC_XLIB__
				if NOT(err = GetXFileInfo(bicRecP->basmFilePath, &fInfo))
				{	fInfo.macosCreator = 'CWIE';
					err = SetXFileInfo(bicRecP->basmFilePath, &fInfo);
				}
			#endif
			}*/
		}
	
	}
	if (err)
		BIC_End(api_data);
	
return err;
}

//===========================================================================================
XErr	BIC_PostProcess(long api_data)
{
XErr			err = noErr;
BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
OpStackInfoP	opStackP;
OpStackInfo		opStackInfo;

	// add a last opstackInfo with the last offset = totSize to go faster in loops
	ClearBlock(&opStackInfo, sizeof(OpStackInfo));
	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &opStackInfo.opOffset, nil); 
	if (err = BufferAddBuffer(bicRecP->opcodesStack, (Ptr)&opStackInfo, sizeof(OpStackInfo)))
		return err;
		
	// Adjust gotos/label (mandatory)
	if (err = _AdjustGotos(api_data, bicRecP))
		goto out;

	// Optimization 1: remove some br and adjust countstack (optional, but stack remains dirty)
	err = _Optim1(bicRecP);
	if (err)
		goto out;

	// Optimization 2: remove nops (optional)
	err = _Optim2(bicRecP);
	if (err)
		goto out;
		
	BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
	bicRecP->stack = _CalcMaxStack(opStackP, bicRecP->totOpcodes);

out:
return err;
}

//===========================================================================================
XErr	BIC_Output(long api_data, BlockRef *resultTextP, long *resultSizeP)
{	
	BICRecord		*bicRecP = &((BifernoRecP)api_data)->bicRecord;
	//long			tot, preLen, postLen, eof;
	//BlockRef		block = nil;
	XErr			err = noErr;//, err2 = noErr;
	//Ptr				p;
	long			totalSize, slSize, vlSize, llSize, outputID = 0;
	CStr255			aCStr;
	CStr63			tStr2;
	CStr63			versionStr, versionBAPIStr, xlibVersStr;
	BlockRef	codeBlock;
	
	
	_CompactCompilation(bicRecP, &totalSize, &codeBlock);
	DisposeBlock(&codeBlock);
	
	if (outputID = BufferCreate(256, &err))
	{	
		//BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, nil);
		if (err = BufferAddCString(outputID, kPreStr, NO_ENC, 0))
			goto out;
		
		if (err = BAPI_GetVersions(api_data, versionStr, versionBAPIStr, xlibVersStr))
			goto out;
		sprintf(aCStr, "<p><b>Biferno %s, BAPI %s, XLIB %s</b></p>", versionStr, versionBAPIStr, xlibVersStr);	
		if (err = BufferAddCString(outputID, aCStr, NO_ENC, 0))
			goto out;
		
		CEquStr(aCStr, "Max Stack: ");
		CNumToString(bicRecP->stack /** sizeof(ObjRef)*/, tStr2);
		CAddStr(aCStr, tStr2);
		if (bicRecP->actStack)
		{	CAddStr(aCStr, "<br><font color=\"red\"><b>Residual Stack: ");
			CNumToString(bicRecP->actStack /** sizeof(ObjRef)*/, tStr2);
			CAddStr(aCStr, tStr2);
			CAddStr(aCStr, "</b></font>");
		}
		CAddStr(aCStr, "<p>");
		if (err = BufferAddCString(outputID, aCStr, NO_ENC, 0))
			goto out;
		
		if (err = _VLDumpList(api_data, outputID, &bicRecP->vl, &vlSize))
			goto out;
		if (err = BufferAddCString(outputID, "<p>", NO_ENC, 0))
			goto out;
		
		if (err = _SLDumpList(api_data, outputID, &bicRecP->sl, &slSize))
			goto out;
		if (err = BufferAddCString(outputID, "<p>", NO_ENC, 0))
			goto out;
		
		if (err = _CLDumpList(api_data, outputID, bicRecP->cl, &llSize))
			goto out;
		if (err = BufferAddCString(outputID, "<p>", NO_ENC, 0))
			goto out;
		
		if (err = BufferAddCString(outputID, "<table border=0 cellpadding=0 cellspacing=0>\r\n", NO_ENC, 0))
			goto out;
		if (err = DumpAssembler(bicRecP, outputID))
			goto out;
		if (err = BufferAddCString(outputID, "\r\n</table>", NO_ENC, 0))
			goto out;
		
		CEquStr(aCStr, "<p><b>Tot Size: ");
		CNumToString(totalSize, tStr2);
		//CNumToString(totSize + vlSize + slSize + llSize, tStr2);
		CAddStr(aCStr, tStr2);
		CAddStr(aCStr, " (+ cl list) </b><p>");
		if (err = BufferAddCString(outputID, aCStr, NO_ENC, 0))
			goto out;
		
		if (err = _DumpClasses(api_data, outputID))
			goto out;
		
		if (err = BufferAddCString(outputID, kPostStr, NO_ENC, 0))
			goto out;
		*resultTextP = BufferGetBlockRefExtSize(outputID, resultSizeP, nil);
		BufferClose(outputID);
	}
out:
	if (err && outputID)
		BufferFree(outputID);
	BIC_End(api_data);
	
	/*preLen = CLen(kPreStr);
	 postLen = CLen(kPostStr);
	 if NOT(err = OpenXFile(bicRecP->basmFilePath, OPEN_FILE_EXISTING, READ_PERM, false, &bicRecP->basmRefNum))
	 {	if NOT(err = GetXEOF(bicRecP->basmRefNum, &eof))
	 {	tot = preLen + eof + postLen;
	 if (tot)
	 {	if (block = NewBlock(tot, &err, &p))
	 {	CopyBlock(p, kPreStr, preLen);
	 if NOT(err = ReadXFile(bicRecP->basmRefNum, p + preLen, &eof))
	 CopyBlock(p + preLen + eof, kPostStr, postLen);
	 }
	 }
	 else
	 block = NewBlock(1, &err, nil);
	 }
	 err2 = CloseXFile(&bicRecP->basmRefNum);
	 if (err2 && NOT(err))
	 err = err2;
	 }
	 
	 if NOT(err)
	 {	*resultTextP = block;
	 *resultSizeP = tot;
	 }
	 else
	 {	*resultTextP = nil;
	 *resultSizeP = 0;
	 if (block)
	 DisposeBlock(&block);
	 }*/
	return err;
}
