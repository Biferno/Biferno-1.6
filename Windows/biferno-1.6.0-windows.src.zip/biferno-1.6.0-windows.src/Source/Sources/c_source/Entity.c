/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Entity.c,v 1.8 2006-03-03 12:06:42 valfer Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "BifernoErrors.h"
#include "Entity.h"
#include "BfrParser.h"

extern 	DispatcherData	gsDispatcherData;


//===========================================================================================
static Boolean	_IsAcceptableCharacter(register int ch, short char2Short)
{
	switch(ch)
	{	case '[':
		case ' ':
		case '\t':
		case '\r':
		case '\n':
		case '=':
		case '.':
		case '(':
		case ')':
		case '{':
		case '}':
		case '?':
		case ';':
		case ',':
		case '<':
		case '>':
		case '$':
		case ':':
			return false;
	}

	switch(char2Short)
	{
		case '++':
		case '--':
		case PLUS_EQUAL:
		case LESS_EQUAL:
		case MULT_EQUAL:
		case DIV_EQUAL:
			return false;
	}

return true;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
Boolean	IsEntityCharValid(int ch, Boolean isFirstChar, Boolean *getReferenceP)
{
Boolean		res;

	if (ch == '&')
	{	if (getReferenceP)
			res = *getReferenceP = true;
		else
			res = false;
	}
	else
	{	if (getReferenceP)
			*getReferenceP = false;
		res = ((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z')) || ((ch >= '0') && (ch <= '9') && NOT(isFirstChar)) || (ch == '_');
	}

return res;
}

//===========================================================================================
XErr	IsEntityNameValid(char *varName)
{
int		len, ch;
char	*strP;
XErr	err = noErr;

	strP = varName;
	len = CLen(strP);
	if NOT(len)
	{	err = XError(kBAPI_Error, Err_EmptyName);
		goto out;
	}
	else if (len > MAX_CLASS_ELEM_LENGTH)
	{	err = XError(kBAPI_Error, Err_TooLongName);
		goto out;
	}
	
	ch = *strP++;
	len--;
	if NOT(IsEntityCharValid(ch, true, nil))
	{	err = XError(kBAPI_Error, Err_InvalidCharacter);
		goto out;
	}
	
	if (len)
	{	do	{	ch = *strP++;
				if NOT(IsEntityCharValid(ch, false, nil))
				{	if ((ch == '\"') || (ch == '\''))
						err = XError(kBAPI_Error, Err_QuotesExpected);
					else
						err = XError(kBAPI_Error, Err_InvalidCharacter);
					goto out;
				}
			} while(--len > 0);
	}

out:
return err;
}

//===========================================================================================
XErr	GetEntityName(long api_data, Ptr *oldFilePPtr, long *lenP, char *varName, Boolean noCheck)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
Ptr		tempP;
long	the_operator, len;
int		lastChar, i, ch;
XErr	err = noErr;
short	aShort;
CStr63	tempName;

	tempP = *oldFilePPtr;
	len = *lenP;
	if (len)
	{	ch = *tempP;
		if (len > 1)
			aShort = *(short*)tempP;
		else
			aShort = 0;
		i = 0;
		lastChar = 0;
		while (len && (i < MAX_VARIABLE_NAME_LENGTH) && _IsAcceptableCharacter(ch, aShort))
		{	tempName[i++] = ch;
			if (--len)
			{	ch = *(++tempP);
				if (len > 1)
					aShort = *(short*)tempP;
				else
					aShort = 0;
			}
			else
				tempP++;
			if ((the_operator = IsEvalOperator(&tempP, &len, false, -1, nil)) && (NOT(len) || (*tempP != ':'))/*ex: (the_operator != EVAL_TERNARY_SEMICOLON)*/)
			{	if ((the_operator == _NOT) && (IsNot(tempP, len)))	// ex(len > 2) && (*(short*)tempP == NOT_STR1) && (*(tempP + 2) == 'T'))
				{	if (lastChar == _IsAcceptableCharacter(ch, 0))
						break;
				}
				else
					break;
			}
			lastChar = ch;
		}
		tempName[i] = 0;
	}
	else
		*tempName = 0;
	
	if NOT(noCheck)
	{	if NOT(i)
			return XError(kBAPI_Error, Err_EmptyName);
		else if (i == MAX_VARIABLE_NAME_LENGTH)
			return XError(kBAPI_Error, Err_TooLongName);
		else if ((*tempName >= '0') && (*tempName <= '9'))
			return XError(kBAPI_Error, Err_InvalidCharacter);
			
		if NOT(err)
			err = IsEntityNameValid(tempName);
	}
	
	CEquStr(varName, tempName);
	//if (err && api_data && *tempName)
	//	NewMsgRecord(api_data, kDOING, tempName, 0, 0);
	
	*oldFilePPtr = tempP;
	*lenP = len;

return err;
}


