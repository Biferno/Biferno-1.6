/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Variable.c,v 1.67 2008-12-02 11:04:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "BifernoErrors.h"
#include "Dispatcher.h"
#include "Flower.h"
#include "Eval.h"
#include "Entity.h"
#include "Load.h"
#include "Param.h"
#include "Classes.h"
#include "BfrParser.h"
#include "Compiler.h"

#include "Reference.h"

#include	"HTTPMgr.h"

#include	<string.h>

extern 	DispatcherData				gsDispatcherData;
extern	PluginRecord				*gClassRecordBlockP;
extern	CStr63						gBifernoErrorsStr[];
extern	CStr255						gsUpSinceStr;
extern	Ref_GetTargetCallBack		ref_GetTarget;
extern	Ref_GetTargetClassCallBack	ref_GetTargetClass;

#define	kConstCStr	"const"
#define	kVarCStr	"var"

#define	kDummyString	"----"

//XErr	ProcessObject(long api_data, Ptr *oldFilePtrP, long *oldFileLenP, ProcessObjectCallRecord *processObjectP, long typeCastType, Boolean entityWasFound, Boolean gettingReference);

//===========================================================================================
XErr	StringToConstObj(long api_data, Ptr dataP, long dataLen, ObjRefP objRefP)
{
	return CL_StringToObj(api_data, dataP, dataLen, CONSTANT, OBJRECORD_P(objRefP));
}

//===========================================================================================
static XErr	_AddToPropertyList(BlockRef *propListBlockP)
{
XErr				err = noErr;
long				newSize, oldSize;		
BlockRef			propBlock;
PropertyListRec		*propList;
long 				totItems;

	propBlock = *propListBlockP;
	if (propBlock)		// Already allocated?
	{	propList = (PropertyListRec*)GetPtr(propBlock);
		totItems = propList->totItems + 1;
		newSize = sizeof(PropertyListRec) + ((totItems - 1) * sizeof(PropertyItem));
		oldSize = GetBlockSize(propBlock, &err);
		if (NOT(err) && (oldSize < newSize))
		{	if NOT(err = SetBlockSize(propBlock, newSize))
			{	propList = (PropertyListRec*)GetPtr(propBlock);
				propList->totItems = totItems;
			}
		}
		else
			propList->totItems = totItems;
	}
	else
	{	totItems = 1;
		newSize = sizeof(PropertyListRec);
		if (propBlock = NewBlockLocked(newSize, &err, (Ptr*)&propList))
		{	//LockBlock(propBlock);
			//propList = (PropertyListRec*)GetPtr(propBlock);
			propList->totItems = totItems;
			*propListBlockP = propBlock;
		}
	}
	
return err;
}

//===========================================================================================
static void	_ClearArrayIndexRec(ArrayIndexRec *arrIndP, long tot)
{
int		i;

	for (i = 0; i < tot; i++, arrIndP++)
	{	arrIndP->ind = 0;
		*arrIndP->ind_name = 0;
	}
}

//===========================================================================================
/*static Boolean	_HasDynamicProperty(BifernoRecP	bRunP, long classID)
{
PluginRecord*	plugRecP;
Boolean			res = false;
long			extID;
long			tLen;
XErr			err = noErr;

	extID = classID;
	while (extID)
	{	plugRecP = GetPluginRecFromClassID(nil, extID);
		if (plugRecP)
		{	if (plugRecP->dynamic)
			{	res = true;
				break;
			}
			else
				extID = plugRecP->extendedPluginID;
		}
		else
		{	tLen = sizeof(long);	
			if (err = DLM_GetObj(bRunP->application.classesList, -extID, (Ptr)&extID, &tLen, offsetof(BifernoClass, extendedClassID)+1, nil))
			{	res = true;
				break;
			}
		}
	};

return res;
}*/

//===========================================================================================
static Boolean	_TryMemberOfCurrent(BifernoRecP	bRunP, ObjRecord *resultVarP, Ptr *lineTextP, long *lineLenP, BlockRef *propListBlockP, long *incrTypeP, long *assignmentTypeP, SuperIsChangedNotify **notifyP, Boolean *isThisP, long classInExecution, long flags, XErr *theErrorP)
{
Boolean					staticProperty, appearsOneMethod;
XErr					err = noErr;
ObjRecord				saveObjRef;
Ptr						tempP;
long					tempLen;
Boolean					successfull;
long					totLoops;
uint32_t				slot;
MemberLoopCallRecord	*membLoopP;

	saveObjRef = *resultVarP;
	appearsOneMethod = false;
	if (classInExecution < 0)			// Biferno class
	{	if (bRunP->thisObjRef.id)
		{	*resultVarP = bRunP->thisObjRef;
			staticProperty = false;
		}
		else
		{	resultVarP->id = 0;
			staticProperty = true;
		}
	}
	else
		staticProperty = true;
	tempP = *lineTextP;
	tempLen = *lineLenP;
	resultVarP->classID = classInExecution;
	if NOT(err = PoolNewPtr(gsDispatcherData.memberLoopPool, (Ptr*)&membLoopP, &slot))
	{	membLoopP->varRecP = resultVarP; 
		membLoopP->incrTypeP = incrTypeP; 
		membLoopP->assignmentTypeP = assignmentTypeP; 
		membLoopP->appearsOneMethodP = &appearsOneMethod; 
		membLoopP->propListBlockP = propListBlockP; 
		membLoopP->isFunction = false;  
		membLoopP->dontCheckPeriod = true; 
		membLoopP->notifyP = notifyP;
		membLoopP->flags = flags;
		totLoops = 0;
		err = MemberLoop((long)bRunP, &tempP, &tempLen, membLoopP, true, &totLoops, false);
		PoolDisposePtr(gsDispatcherData.memberLoopPool, slot);
	}

	if (err)
	{	*resultVarP = saveObjRef;
		successfull = false;
		if (NOT(totLoops) && ((err == XError(kBAPI_Error, Err_NoSuchMember)) || (err == XError(kBAPI_Error, Err_MemberIsNotStatic)) || (err == XError(kBAPI_Error, Err_CantAccessThisMember))))
		{	BAPI_ResetError((long)bRunP);
			err = noErr;
		}
	}
	else
	{	*lineTextP = tempP;
		*lineLenP = tempLen;
		successfull = true;
		if (classInExecution < 0)
			*isThisP = true;
	}
	if (theErrorP)
		*theErrorP = err;		// ex noErr;
	
	//if (successfull)
	//	ResetMsgRecord((long)bRunP);
		
return successfull;
}
	
//===========================================================================================
static XErr	_GetAssignmentType(BifernoRecP bRunP, Ptr *oldFilePPtr, long *lenP, long *incrTypeP, long *assignmentP, Boolean isFunction, long totProperties, Boolean appearsOneMethod, Boolean varExists)
{
Ptr		saveP, tempP;
long	saveLen, len, incrType, assignment;
XErr	err = noErr;

	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTab(&tempP, &len);
	incrType = *incrTypeP;
	assignment = *assignmentP;
	// c'� il ++ o -- dopo?
	if ((len > 1) && (*(short*)tempP == '--'))
	{	if (incrType)				// non pu� esserci pre e post incremento insieme
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	incrType = kPostDecrem;
			tempP += 2;
			len -= 2;
		}
	}
	else if ((len > 1) && (*(short*)tempP == '++'))
	{	if (incrType)
			err = XError(kBAPI_Error, Err_BadSyntax);	// non pu� esserci pre e post incremento insieme
		else
		{	incrType = kPostIncrem;
			tempP += 2;
			len -= 2;
		}
	}
	
	if NOT(err)
	{	saveP = tempP;
		saveLen = len;
		
		SkipSpaceAndTab(&tempP, &len);
		if ((len && (*tempP == '=')) && ((len < 2) || (*(short*)tempP != '==')))
		{	assignment = ASSIGN;
			tempP++;
			len--;
		}
		else if ((len > 1) && (*(short*)tempP == PLUS_EQUAL))
		{	assignment = ADDASSIGN;
			tempP += 2;
			len -= 2;
		}
		else if ((len > 1) && (*(short*)tempP == LESS_EQUAL))
		{	assignment = SUBASSIGN;
			tempP += 2;
			len -= 2;
		}
		else if ((len > 1) && (*(short*)tempP == MULT_EQUAL))
		{	assignment = MULTASSIGN;
			tempP += 2;
			len -= 2;
		}
		else if ((len > 1) && (*(short*)tempP == DIV_EQUAL))
		{	assignment = DIVASSIGN;
			tempP += 2;
			len -= 2;
		}
		else
			assignment = 0;
			
		if NOT(assignment)
		{	tempP = saveP;
			len = saveLen;
		}
	
		// Controls
		if (assignment && incrType)		// robe tipo ++a = 12
			err = XError(kBAPI_Error, Err_IllegalOperation);
		else if (incrType && assignment)
			err = XError(kBAPI_Error, Err_IllegalOperation);													// no a++ = ...
		else if ((assignment || incrType) && isFunction)						// no a++; se a undef
			err = XError(kBAPI_Error, Err_IllegalOperation);
		else if (incrType && NOT(varExists))										// no a++; se a undef
			err = XError(kBAPI_Error, Err_UndefinedIdentifier);
		else if (assignment && (assignment != ASSIGN) && NOT(varExists))	// no a += b; se a undef
			err = XError(kBAPI_Error, Err_UndefinedIdentifier);
		else if (appearsOneMethod)
		{	if (assignment || (incrType == kPostIncrem) || (incrType == kPostIncrem))
				err = XError(kBAPI_Error, Err_IllegalOperationOnMethod);
		}
		else if (assignment && NOT(varExists) && (totProperties || appearsOneMethod))	// no a.prop = b; se a undef (ma myClass.prop si!)
			err = XError(kBAPI_Error, Err_UndefinedIdentifier);
		
		if NOT(err)
		{	*assignmentP = assignment;	
			if (assignment)
				bRunP->assignment = true;
			*oldFilePPtr = tempP;
			*lenP = len;
			*incrTypeP = incrType;
		}
	}

return err;
}

//===========================================================================================
// 	Copies an obj from volatile list to definitive list. Note, no constructor here, because it 
//	was called at volatile store time
static XErr	_CopyTheObject(long api_data, ObjRecordP sourceObjVar, char *varName, long scope, long type, ObjRecordP destObjVar, Boolean exists, BlockRef mCoordBlock, long mCoordDim, Boolean isImmediate, long typeCastType, Boolean ignoreIfConstant, BAPI_ModifyHook modCB)
{
	XErr			err = noErr, errForced = noErr;
	BifernoRecP		bRecP = (BifernoRecP)api_data;
	//long			a = sizeof(BifernoRec);
	long			sList = sourceObjVar->list, sID = sourceObjVar->id;
	Boolean			expanded;
	
	if NOT(isImmediate)
	{	if (sList != bRecP->volatileList)
		CDebugStr("Non doveva succedere mai!");
		sourceObjVar->type = type;
	}
	if (exists)
	{	err = BAPI_ReplaceObj(api_data, OBJREF_P(destObjVar), OBJREF_P(sourceObjVar), false);
		if ((err == XError(kBAPI_Error, Err_IllegalOperationOnConstant)) && ignoreIfConstant)
		{	
			if NOT(err = DLM_TurnOffFlag(destObjVar->list, destObjVar->id, kCostant, kDLMWhole))
			{	err = BAPI_ReplaceObj(api_data, OBJREF_P(destObjVar), OBJREF_P(sourceObjVar), false);
				DLM_TurnOnFlag(destObjVar->list, destObjVar->id, kCostant, kDLMWhole);
			}
		}
		if NOT(bRecP->fromUpdateObject)
		{	
			if ((destObjVar->list == bRecP->globalList) && (destObjVar->id == bRecP->globErrObjRef.id))
			{	long		errNum;
				if NOT(err = BAPI_ObjToInt(api_data, OBJREF_P(destObjVar), &errNum, kExplicitTypeCast))
				{	if (errNum)
					errForced = BAPI_Exception(api_data, kBAPI_Error, errNum, nil, false);
				else
					bRecP->moreErrors = false;
				}
			}
		}
		/* Note:
		 If is array, dest and source point to same elements. DLM_ObjTurnOnFlag later
		 will set NoDestructor on all elements, but this is not right for the dest, so:
		 */
		if (NOT(err) && NOT(isImmediate) && DLM_IsArray(sList, sID))
			DLM_TurnOffFlag(sList, sID, kIsArray, kDLMMain);
	}
	else
	{	
		if (NOT(isImmediate) && ContainsReference(sourceObjVar))
		{	
			if (destObjVar->scope == PERSISTENT)
				return XError(kBAPI_Error, Err_ObjectCantBePersistent);
			else if (bRecP->objRefInDestruction.id)
				return XError(kBAPI_Error, Err_NotAllowedInDestructor);
		}		
		
		if (mCoordBlock && mCoordDim)	// array is to expand?
		{	
			LockBlock(mCoordBlock);
			err = ResolveArrayElement(api_data, OBJREF_P(destObjVar), (ArrayIndexRec*)GetPtr(mCoordBlock), (short)mCoordDim, nil, &expanded, OBJREF_P(sourceObjVar), OBJREF_P(destObjVar), nil);
			UnlockBlock(mCoordBlock);
			if (not(err) && not(expanded))
			{
				/*
				For: "a[1] = a[2] = 'pippo'". When processes a[1] it does not expands the array because already expanded by "a[2] = 'pippo'".
				 So the object is not copied in the first index and an additional modify is needed
				 (ResolveArrayElement simply return the element if not expanded)
				 */
				err = ModifyVariable(api_data, destObjVar, sourceObjVar, typeCastType, ignoreIfConstant, modCB);
			}
		}
		else
		{	
			if (DLM_GetObjID(gsDispatcherData.reservedKeyword, varName, nil, nil) || DLM_GetObjID(gsDispatcherData.flowControls, varName, nil, nil))
			{	
				err = XError(kBAPI_Error, Err_ReservedKeyword);
				NewMsgRecord(api_data, kDOING, varName, 0, 0);
			}
			else
				err = CopyObjectExt(api_data, OBJREF_P(sourceObjVar), varName, scope, type, OBJREF_P(destObjVar));
		}
	}
	
	if NOT(err)
	{	
		if NOT(isImmediate)
			err = DLM_TurnOnFlag(sList, sID, kNoDestructor, kDLMElements);
		if (errForced)
			err = errForced;
	}
	
	return err;
}

//===========================================================================================
static XErr	_ReplaceObjectWithTypeCast(long api_data, ObjRecordP dest, ObjRecordP source)
{
	ObjRecord		sourceAfterTypeCast;
	XErr			err = noErr;

	if (dest->classID && dest->classID != source->classID)
	{	INVAL(sourceAfterTypeCast);
		err = CL_TypeCast(api_data, source, dest->classID, (ObjRecordP)&sourceAfterTypeCast, kExplicitTypeCast);
	}
	else
		sourceAfterTypeCast = *source;
	if not(err)
	{	
		if (dest->classID && dest->classID != sourceAfterTypeCast.classID)	// sometime polimorphism causes no typecast
			err = XError(kBAPI_Error, Err_IllegalDestructor);
		else
			err = BAPI_ReplaceObj(api_data, (ObjRefP)dest, (ObjRefP)&sourceAfterTypeCast, false);
	}
	return err;
}

//===========================================================================================
/*static XErr	_CopyElementsOfObject(long api_data, ObjRecordP destObjP, ObjRecordP valueObjP)
{
	long			j, tLen, totElements, totElementsValue, saveVisibilityClass;
	BifernoClass	bifernoClass;
	BAPI_Doc		doc;
	XErr			err = noErr;
	BifernoRecP		bRecP = (BifernoRecP)api_data;
	CStr63			propName;
	ObjRecord		destCurrentObj, valueCurrentObj;
	ObjRecord		destSuperObj, valueSuperObj;
	long			superClassId, resClassId, destClassId = destObjP->classID;
	
	if (destClassId < 0)
	{		
		if not(err = GetBifernoClassRec(bRecP, -destClassId, &bifernoClass))
			err = DLM_GetTotObjs(bifernoClass.properties, &totElements, false);
		if not(err)
		{
			// copy super obj (if any)
			if (bifernoClass.extendedClassID)
			{
				// dest
				if not(err = BAPI_GetSuperObj(api_data, (ObjRefP)destObjP, (ObjRefP)&destSuperObj))
				{
					if not(err = BAPI_GetSuperObj(api_data, (ObjRefP)valueObjP, (ObjRefP)&valueSuperObj))
					{
						superClassId = ((ObjRecordP)&destSuperObj)->classID;
						if (superClassId > 0 && gClassRecordBlockP[superClassId-1].wantDestructor)
							err = XError(kBAPI_Error, Err_IllegalDestructor);
						else if (superClassId == gsDispatcherData.arrayConstructor || superClassId < 0)
						{
							err = _CopyElementsOfObject(api_data, (ObjRecordP)&destSuperObj, (ObjRecordP)&valueSuperObj);
						}
						else
						{
							err = _ReplaceObjectWithTypeCast(api_data, &destSuperObj, &valueSuperObj);
						}
					}
				}
			}
		}
	}
	else
	{	
		if not(err = BAPI_GetArrayInfo(api_data, (ObjRefP)destObjP, &totElements, nil, nil))
		{
			if not(err = BAPI_GetArrayInfo(api_data, (ObjRefP)valueObjP, &totElementsValue, nil, nil))
			{
				if (totElements != totElementsValue)
				{
					if not(err = BAPI_SetArrayDim(api_data, (ObjRefP)destObjP, totElementsValue))
						totElements = totElementsValue;
				}
			}
		}
	}
	if not(err)
	{
		for (j = 1; (j <= totElements) && NOT(err); j++)
		{	
			// get the current property in the dest obj
			if (destClassId < 0)
			{
				tLen = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
				if not(err = DLM_GetIndObj(bifernoClass.properties, j, (Ptr)&doc, &tLen, nil, nil, nil, propName, false, false))
				{	
					if (doc.info.property.isConst || doc.type == kError || doc.isStatic)
						continue;

					saveVisibilityClass = bRecP->visibilityClass;
					bRecP->visibilityClass = destObjP->classID;		// to avoid can't access error
					if not(err = BAPI_GetProperty(api_data, (ObjRefP)destObjP, propName, 0, nil, (ObjRefP)&destCurrentObj))
					{
						// get the current property in the value obj
						bRecP->visibilityClass = valueObjP->classID;
						if not(err = BAPI_GetProperty(api_data, (ObjRefP)valueObjP, propName, 0, nil, (ObjRefP)&valueCurrentObj))
							resClassId = doc.returnClassID;
					}
					bRecP->visibilityClass = saveVisibilityClass;
				}
			}
			else
			{	
				// get the current array elem in the dest obj
				if not(err = BAPI_ElementOfArray(api_data, (ObjRefP)destObjP, j, (ObjRefP)&destCurrentObj))
				{
					// get the current array elem in the value obj
					if not(err = BAPI_ElementOfArray(api_data, (ObjRefP)valueObjP, j, (ObjRefP)&valueCurrentObj))
						resClassId = ((ObjRecordP)&destCurrentObj)->classID;
				}
			}
			if not(err)
			{
				// check
				if (resClassId > 0 && gClassRecordBlockP[resClassId-1].wantDestructor)
					err = XError(kBAPI_Error, Err_IllegalDestructor);
				else if (resClassId == gsDispatcherData.arrayConstructor || resClassId < 0)
				{
					err = _CopyElementsOfObject(api_data, (ObjRecordP)&destCurrentObj, (ObjRecordP)&valueCurrentObj);
				}
				else
				{
					err = _ReplaceObjectWithTypeCast(api_data, &destCurrentObj, &valueCurrentObj);
				}
			}
		}
	}
	return err;
}

//===========================================================================================
// 	Copies an obj from volatile list to definitive list. Note, no constructor here, because it 
//	was called at volatile store time
static XErr	_CopyTheElements(long api_data, ObjRecordP sourceObjVar, ObjRecordP destObjVar, Boolean isImmediate, Boolean ignoreIfConstant)
{
	XErr			err = noErr;
	BifernoRecP		bRecP = (BifernoRecP)api_data;
	
	// check iniziali
	if ((destObjVar->scope != APPLICATION && destObjVar->scope != PERSISTENT && destObjVar->scope != SESSION) || bRecP->currentCtx.defaultScope != LOCAL)
		CDebugStr("Non doveva succedere mai!");
	if NOT(isImmediate)
	{	
		if (sourceObjVar->list != bRecP->volatileList)
			CDebugStr("Non doveva succedere mai!");
		sourceObjVar->type = destObjVar->type;
	}
	
	if (destObjVar->classID > 0 && gClassRecordBlockP[destObjVar->classID-1].wantDestructor)
		err = XError(kBAPI_Error, Err_IllegalDestructor);
	else
		err = _CopyElementsOfObject(api_data, destObjVar, sourceObjVar);
	return err;
}
*/
//===========================================================================================
static XErr	_ConstToVar(BifernoRec *bRecP, ObjRecord *objRefP)
{
XErr	err = noErr;

	if IS_IMMEDIATE_P(objRefP)
	{	if NOT(err = NewLiteralInList(nil, bRecP->volatileList, objRefP, 0, &objRefP->id, 0))	
		{	objRefP->list = bRecP->volatileList;
			objRefP->scope = TEMP;
			objRefP->type = VARIABLE;
		}
	}
	else if (objRefP->type == CONSTANT)
	{	if NOT(err = DLM_TurnOffFlag(objRefP->list, objRefP->id, kCostant, kDLMWhole))
			objRefP->type = VARIABLE;
	}

return err;
}

//===========================================================================================
//	Executes assignment of leftObjVarP with rightObjVarP, also handle properties
static XErr	_DoAssignment(long api_data, char *varName, long assignmentType, ObjRecordP rightObjVarP, BlockRef propListBlock, ObjRecordP leftObjVarP, BlockRef mCoordBlock, long mCoordDim, long typeCastType, Boolean ignoreIfConstant, BAPI_ModifyHook modCB)
{
XErr			err = noErr;
BifernoRecP 	bRunP = (BifernoRecP)api_data;
int				i;
ObjRecord		tObjRef;
long			totProperties;
Boolean			isImmediate = IS_IMMEDIATE_P(rightObjVarP);

	if (rightObjVarP->id && rightObjVarP->classID)
	{	
		if (((rightObjVarP->list != bRunP->volatileList) && NOT(isImmediate)) || SameObj(bRunP->thisObjRef.list, bRunP->thisObjRef.id, rightObjVarP->list, rightObjVarP->id))
		{	ParameterRec	param;
		
			*param.name = 0;
			//param.expP = nil;
			//param.expLen = 0;
			param.objRef = OBJREF(*rightObjVarP);
			INVAL(tObjRef);
			if NOT(err = CL_Clone(api_data, TEMP, rightObjVarP->type, nil, rightObjVarP->classID, &param, 1, 0, true, &tObjRef))
			{	*rightObjVarP = tObjRef;
				isImmediate = IS_IMMEDIATE_P(rightObjVarP);
			}
		}			
		if NOT(err)
		{	// single array elements can be not initialized
			if (leftObjVarP->id && NOT(leftObjVarP->classID))
				leftObjVarP->classID = rightObjVarP->classID;
			
			if ((NOT(propListBlock) && NOT(leftObjVarP->id)) || mCoordBlock)	// new object
				err = _CopyTheObject(api_data, rightObjVarP, varName, leftObjVarP->scope, leftObjVarP->type, leftObjVarP, false, mCoordBlock, mCoordDim, isImmediate, typeCastType, ignoreIfConstant, modCB);
			else
			{	if (assignmentType != ASSIGN)
				{	switch(assignmentType)
					{	case ADDASSIGN:
							err = CL_ExecuteOperation(api_data, leftObjVarP, rightObjVarP, EVAL_ADD, rightObjVarP);
							break;
						case SUBASSIGN:
							err = CL_ExecuteOperation(api_data, leftObjVarP, rightObjVarP, EVAL_MINUS, rightObjVarP);
							break;
						case MULTASSIGN:
							err = CL_ExecuteOperation(api_data, leftObjVarP, rightObjVarP, EVAL_MULT, rightObjVarP);
							break;
						case DIVASSIGN:
							err = CL_ExecuteOperation(api_data, leftObjVarP, rightObjVarP, EVAL_DIV, rightObjVarP);
							break;
					}
					/*
					levata 5/11/2002 per casi tipo a.secs += 123456789123456789 in cui a destra non puoi convertire in int
					if NOT(err)
					{	if (leftObjVarP->classID != rightObjVarP->classID)
							err = CoercionToRequestedType(api_data, rightObjVarP, nil, leftObjVarP->classID, rightObjVarP, kImplicitTypeCast);
					}
					*/
				}
				if NOT(err)
				{	PropertyListRec *propertyList;
				
					propertyList = (PropertyListRec*)GetPtr(propListBlock);
					if (propertyList && (totProperties = propertyList->totItems))
					{	PropertyItem	*propertyItemP;
						
						LockBlock(propListBlock);
						*leftObjVarP = *rightObjVarP;
						propertyItemP = &propertyList->item[totProperties-1];
						for (i = (totProperties-1); (i >= 0) && NOT(err); i--, propertyItemP--)		// right to left!
						{	if (err = CL_SetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyDim, propertyItemP->propertyIDXPtr, rightObjVarP))
								NewMsgRecord((long)bRunP, kSETPROPERTY, propertyItemP->membIdent.doc.name, 0, 0);
								//CAddStringToErrMessage(api_data, propertyItemP->membIdent.memberName);
							else
								*rightObjVarP = propertyItemP->membIdent.objRef;
						}
						UnlockBlock(propListBlock);
					}
					else
						err = ModifyVariable(api_data, leftObjVarP, rightObjVarP, typeCastType, ignoreIfConstant, modCB);
				}
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_IllegalAssignment);

return err;
}

//===========================================================================================
//	Executes increment on leftObjVarP, return result in resultVarP
static XErr	_DoIncrement(long api_data, long incrType, ObjRecordP leftObjVarP, BlockRef propListBlock, BlockRef mCoordBlock, long mCoordDim, ObjRecordP resultVarP)
{
XErr	err = noErr;
int		i;
long	totProperties;

	if COMPILING(api_data)
	{	LockBlock(mCoordBlock);
		err = BIC_DoIncrement(api_data, leftObjVarP, (ArrayIndexRec*)GetPtr(mCoordBlock), mCoordDim, propListBlock, incrType);
		UnlockBlock(mCoordBlock);
		if NOT(err)
			*resultVarP = *leftObjVarP;
	}
	else
	{	if (incrType == kPreIncrem)
		{	err = CL_Increment(api_data, leftObjVarP, false);
			*resultVarP = *leftObjVarP;
		}
		else if (incrType == kPreDecrem)
		{	err = CL_Increment(api_data, leftObjVarP, true);
			*resultVarP = *leftObjVarP;
		}
		else if (incrType == kPostIncrem)
		{	ParameterRec	param;
		
			BAPI_ClearParameterRec(api_data, &param);
			param.objRef = OBJREF(*leftObjVarP);
			if NOT(err = CL_Clone(api_data, TEMP, leftObjVarP->type, nil, leftObjVarP->classID, &param, 1, 0, true, resultVarP))
				err = CL_Increment(api_data, leftObjVarP, false);
		}
		else if (incrType == kPostDecrem)
		{	ParameterRec	param;
		
			BAPI_ClearParameterRec(api_data, &param);
			param.objRef = OBJREF(*leftObjVarP);
			if NOT(err = CL_Clone(api_data, TEMP, leftObjVarP->type, nil, leftObjVarP->classID, &param, 1, 0, true, resultVarP))	// ex CL_Constructor
				err = CL_Increment(api_data, leftObjVarP, true);
		}
		if NOT(err)
		{	PropertyListRec *propertyList;
		
			propertyList = (PropertyListRec*)GetPtr(propListBlock);
			if (propertyList && (totProperties = propertyList->totItems))
			{	
			PropertyItem		*propertyItemP;
			ObjRecord			tempResult;
				
				LockBlock(propListBlock);
				//*leftObjVarP = tempResult;
				tempResult = *leftObjVarP;
				propertyItemP = &propertyList->item[totProperties-1];
				for (i = (totProperties-1); (i >= 0) && NOT(err); i--, propertyItemP--)		// right to left!
				{	if (err = CL_SetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyDim, propertyItemP->propertyIDXPtr, &tempResult))
						NewMsgRecord(api_data, kSETPROPERTY, propertyItemP->membIdent.doc.name, 0, 0);
						//CStringToErrMessage(api_data, propertyItemP->membIdent.memberName);
					else
						tempResult = propertyItemP->membIdent.objRef;
				}
				UnlockBlock(propListBlock);
			}
			//else
			//	err = ModifyVariable(api_data, leftObjVarP, leftObjVarP);
		}
	}

return err;
}

//===========================================================================================
/*
NO
 Important Note:
 _IdentifyObject can enter in critical section. If *enteredInCriticalSectionP is true on exit
 caller is responsible to call LeaveCriticalSection
*/
static XErr	_IdentifyObject(long api_data, Ptr *lineTextP, long *lineLenP, BlockRef *propListBlockP, char *varName, long varList, Boolean *isMethodP, Boolean *toStopP, long *incrTypeP, long *assignmentTypeP, ObjRecord *leftObjVarP, Boolean *isThisP, SuperIsChangedNotify **notifyP, BlockRef *mCoordBlockP, long *mCoordDimP, Boolean *entityWasFoundP, long flags, long *arrayElemReqClassIDP/*, Boolean *enteredInCriticalSectionP*/)
{	
XErr		err = noErr;
Ptr			textP;
long		len;
//CacheResult	saveCacheRec;
Boolean		isRef, canTry, isFunc, toStop = false;

	textP = *lineTextP;
	len = *lineLenP;
	if (entityWasFoundP)
		*entityWasFoundP = false;
	if (len && (*textP == '('))
		isFunc = true;
	else
		isFunc = false;
	canTry = (varList == 0);
	// Does this object exist?
	leftObjVarP->id = LookForObj(api_data, varName, &varList, &leftObjVarP->type, &leftObjVarP->classID, &leftObjVarP->scope, &err);
	if NOT(err)
	{	if (canTry && NOT(leftObjVarP->id))
		{	BifernoRecP	bRecP = (BifernoRecP)api_data;
			Ptr			tempP;
			long		tempLen, methClass;
			Boolean		retried = false;
			
			// try first as 
			if (bRecP->methodInExecutionClass)
				methClass = bRecP->methodInExecutionClass;
			else if (bRecP->currentCtx.leftMemberClass)
				methClass = bRecP->currentCtx.leftMemberClass;
			else
				methClass = 0;
		retry:	
			if (methClass)
			{	long		varLen;

				varLen = CLen(varName);
				tempP = textP - varLen;
				tempLen = len + varLen;
				if (_TryMemberOfCurrent(bRecP, leftObjVarP, &tempP, &tempLen, propListBlockP, incrTypeP, assignmentTypeP, notifyP, isThisP, methClass, flags, &err))
				{	if (entityWasFoundP)
						*entityWasFoundP = true;
					textP = tempP;
					len = tempLen;
					if (isFunc)
					{	*isMethodP = true;
						toStop = true;
					}
				}
				//else if (flags & kInCase)	// only static const properties are accepted
				//	err = XError(kBAPI_Error, Err_IllegalConstantExpression);
				// try also with leftMemberClass
				if (NOT(err) && NOT(retried) && NOT(leftObjVarP->id) && (methClass == bRecP->methodInExecutionClass) && (methClass = bRecP->currentCtx.leftMemberClass) && (methClass != bRecP->methodInExecutionClass))
				{	 retried = true;
					 goto retry;
				}
			}
			if (NOT(err) && NOT(leftObjVarP->id))	// Defaults
			{	if NOT(leftObjVarP->type)
					leftObjVarP->type = VARIABLE;
				if NOT(leftObjVarP->scope)
					leftObjVarP->scope = ((BifernoRecP)api_data)->currentCtx.defaultScope;
			}
		}
		else if (flags & kInCase)	// only static const properties are accepted
			err = XError(kBAPI_Error, Err_IllegalConstantExpression);
		else
			leftObjVarP->list = varList;

		
		/*if (_NeedCS(leftObjVarP))
		{
			XThreadsEnterCriticalSection();
			*enteredInCriticalSectionP = true;
		}*/
		
		// Is an array item?
		isRef = false;
		if (NOT(err) && leftObjVarP->id && ((leftObjVarP->classID == gsDispatcherData.arrayConstructor) || (isRef = (leftObjVarP->classID == gsDispatcherData.refConstructor))))
		{	if (isRef)
			{	
			long	targetClassID;
			
				if NOT(err = ref_GetTargetClass(api_data, (ObjRefP)leftObjVarP, &targetClassID, true))
				{	if (targetClassID == gsDispatcherData.arrayConstructor)
						err = ResolveArryItem(api_data, &textP, &len, leftObjVarP, nil, mCoordDimP, false, mCoordBlockP, arrayElemReqClassIDP);
				}
			}
			else
				err = ResolveArryItem(api_data, &textP, &len, leftObjVarP, nil, mCoordDimP, false, mCoordBlockP, arrayElemReqClassIDP);
		}
	}
	
*lineTextP = textP;
*lineLenP = len;
*toStopP = toStop;
return err;
}

//===========================================================================================
static XErr	_CVarDestructor(DLMRef dlRef, long objID, long classID, long scope, long api_data)
{
ObjRecord			varRec;
XErr			err = noErr;
PluginRecord*	plugRecP;
//long			extID;

	plugRecP = &gClassRecordBlockP[classID-1];
	if (plugRecP->wantDestructor)
	{	varRec.id = objID;
		varRec.classID = classID;
		varRec.list = dlRef;
		varRec.scope = scope;
		err = CL_Destructor(api_data, &varRec);
	}
	/*
	No, sar� distrutto quando la DLM distrugge anche la super!
	else if (extID = plugRecP->extendedPluginID)
	{	plugRecP = &gClassRecordBlockP[extID-1];
		if (plugRecP->wantDestructor)
		{	if (objID = DLM_GetSuperObjID(dlRef, objID, &dlRef))
				err = _CVarDestructor(dlRef, objID, extID, api_data);
			else
				;// ok, is zero in length
		}
	}
	*/
	
return err;
}

//===========================================================================================
/*static	void	_ScopeType(long aLong, long *typeP, long *scopeP)
{	
	switch(aLong)
	{	case VARIABLE:
		case CONSTANT:
			*typeP = aLong;
			break;
		case TEMP:
		case LOCAL:
		case GLOBAL:
		case APPLICATION:
		case SESSION:
		case SERVER:
			*scopeP = aLong;
			break;
		default:
			break;
	}
}
*/
//===========================================================================================
static XErr	_GetArrayIndex(long api_data, Ptr *oldFilePPtr, long *lenP, ArrayIndexRec *arrayRecP, Boolean *toContinueP, Boolean fromInput)
{
XErr		err = noErr;
Ptr			saveP, tempP;
long		saveLen, len;
int			parNum, i;
ObjRecord	varRec;
Boolean		perc = false;
long		evaluateParNum;

	BAPI_InvalObjRef(api_data, OBJREF_P(&varRec));
	tempP = *oldFilePPtr;
	len = *lenP;
	if ((len && (*tempP == '[')) || (fromInput && (perc = Begins(tempP, len, "%5B", 3))))
	{	if NOT(perc)
		{	tempP++;
			len--;
		}
		else
		{	tempP += 3;
			len -= 3;
		}
		i = 1;
		saveP = tempP;
		saveLen = 0;
		parNum = 1;
		while(len && parNum)
		{	if ((*tempP == ']') || (fromInput && (perc = Begins(tempP, len, "%5D", 3))))
				parNum--;
			else if ((*tempP == '[') || (fromInput && (perc = Begins(tempP, len, "%5B", 3))))
				parNum++;
			if (parNum)
			{	tempP++;
				len--;
			}
		}
		if (parNum)
			err = XError(kBAPI_Error, Err_SquareBracketExpected);
		else
		{	saveLen = tempP - saveP;
			if NOT(perc)
			{	tempP++;
				len--;
			}
			else
			{	tempP += 3;
				len -= 3;
			}
			//ex if NOT(err = EvalWithResume(api_data, &saveP, &saveLen, kNoFlowControl, &varRec))
			evaluateParNum = 0;
			if NOT(err = Evaluate(api_data, 0, 0, &saveP, &saveLen, nil, &varRec, kNoFlowControl + kLoadParamOnStack, &evaluateParNum, true/*, nil*/))
			{	if (evaluateParNum)
					err = XError(kBAPI_Error, Err_RoundBracketExpected);
				else
				{	if COMPILING(api_data)
						*(ObjRecordP)arrayRecP = varRec;
					else
					{	if (varRec.classID == kIntClassID)
						{	if NOT(err = CL_GetInt(api_data, &varRec, &arrayRecP->ind, kImplicitTypeCast))
							{	arrayRecP->ind_name[0] = 0;
								if (arrayRecP->ind <= 0)
									err = XError(kBAPI_Error, Err_BadArrayIndex);
							}
						}
						else if (varRec.classID == kStringClassID)
						{	if NOT(err = CL_GetString(api_data, &varRec, arrayRecP->ind_name, nil, 63, kImplicitTypeCast, kNormal))
								arrayRecP->ind = 0;
						}
						else if NOT(err = CL_GetInt(api_data, &varRec, &arrayRecP->ind, kImplicitTypeCast))
							arrayRecP->ind_name[0] = 0;
					}
				}
			}
			if (toContinueP)
				*toContinueP = true;
		}
	}
	else
	{	if (toContinueP)
			*toContinueP = false;
		arrayRecP->ind = 0;
		arrayRecP->ind_name[0] = 0;
	}
	*oldFilePPtr = tempP;
	*lenP = len;

return err;
}

//===========================================================================================
static XErr	_GetPropertyIndex(long api_data, Ptr *oldFilePPtr, long *lenP, ArrayIndexRec *propertyIDX, long *propertiesDimP, long arrayLevel)
{
XErr		err = noErr;
long		len, k;
Boolean		toContinue;
Ptr			tempP;

	tempP = *oldFilePPtr;
	len = *lenP;

	// INDICE PROPRIETA'?
	*propertiesDimP = 0;
	if (len && (*tempP == '['))
	{	toContinue = true;
		k = 0;
		while(toContinue && NOT(err))
		{	if (k >= arrayLevel)
			{	if (len && (*tempP == '['))
					err = XError(kBAPI_Error, Err_ArrayRequired);
				else
				{	*propertiesDimP = k;
					break;
				}
			}
			else
			{	if NOT(err = _GetArrayIndex(api_data, &tempP, &len, &propertyIDX[k], &toContinue, false))
				{	if COMPILING(api_data)
					{	if (toContinue)
						{	if VALID_P(&propertyIDX[k])
								err = BIC_LoadParam(api_data, (ObjRecordP)&propertyIDX[k]);
							else
								err = XError(kBAPI_Error, Err_BadArrayIndex);
						}
					}
					k++;
					if NOT(toContinue)
						*propertiesDimP = k-1;
				}
			}
		}
	}
	else
	{	propertyIDX->ind = 0;
		*propertyIDX->ind_name = 0;
	}
	
*oldFilePPtr = tempP;
*lenP = len;
return err;
}

//===========================================================================================
static Boolean	_GetClassMember(long api_data, ObjRecord *objRefP, Ptr *oldFilePPtr, long *lenP, long classID, BlockRef *membIdentBlockP, MemberAction **membActionP, Boolean dontCheckPeriod, SuperIsChangedNotify **notifyP, Boolean fromTryCurrent, Boolean gettingReference, XErr *errP)
{
Ptr				tempP;
long			len;
int				followChar;
Boolean			result = false;
XErr			err = noErr;
BifernoRec		*bRecP;
CStr255			aCStr;

	*aCStr = 0;
	if (dontCheckPeriod || (*lenP && (**oldFilePPtr == '.')))
	{	bRecP = (BifernoRec*)api_data;
		if (bRecP->outOfBoundary)
			err = XError(kBAPI_Error, Err_OutOfBoundary);
		else
		{	tempP = *oldFilePPtr;
			len = *lenP;
			if NOT(dontCheckPeriod)
			{	tempP++;		// skip '.'
				len--;
			}
			if (NOT(classID) && NOT(COMPILING(api_data)))
				err = XError(kBAPI_Error, Err_MemberOnUndefinedIdentifier);
			else if NOT(err = GetEntityName(api_data, &tempP, &len, aCStr, false))
			{	*oldFilePPtr = tempP;
				*lenP = len;
				SkipSpaceAndTab(&tempP, &len);
				if (len)
					followChar = *tempP;
				else
					followChar = 0;
				if NOT(classID)		// only if compiling
					CDebugStr("COMPILING TEMPORARILY DISABLED");
				else
					err = GetMemberInfo(api_data, aCStr, classID, objRefP, membIdentBlockP, membActionP, followChar, &result, fromTryCurrent, notifyP, false, gettingReference);
			}
			if NOT(err)
			{	if NOT(result)
				{	NewMsgRecord(api_data, kMEMBER, aCStr, 0, 0);
					err = XError(kBAPI_Error, Err_NoSuchMember);
				}
			}
			else
			{	if (err == XError(kBAPI_Error, Err_EmptyName))
					err = XError(kBAPI_Error, Err_BadSyntax);
				if (*aCStr)
					NewMsgRecord(api_data, kMEMBER, aCStr, 0, 0);
			}
		}
	}

*errP = err;
return result;
}

//===========================================================================================
static XErr	_IsBuiltInMember(char *memberName, ObjRecord *objRefP, BlockRef *membIdentBlockP, MemberAction **membActionP, Boolean *isBuiltInP)
{
uint32_t		slot;
long			tLen, res;
XErr			err = noErr;
Boolean			allocated;
MemberAction 	*membIdentP;
BAPI_Doc		*docP;

	allocated = false;
	if NOT(CCompareStrings_cs(memberName, "type"))
		res = TYPE;
	else if NOT(CCompareStrings_cs(memberName, "scope"))
		res = SCOPE;
	else if NOT(CCompareStrings_cs(memberName, "class"))
		res = CLASS;
	else
		res = 0;
	if (res)
	{	if (membIdentBlockP)
		{	tLen = sizeof(MemberAction) - sizeof(BAPI_ParameterDoc);
			//if (*membIdentBlockP = NewBlockLocked(tLen, &err, (Ptr*)&membIdentP))
			if NOT(err = PoolNewPtr(gsDispatcherData.propertyActionPool, (Ptr*)&membIdentP, &slot))
			{	allocated = true;
				ClearBlock(membIdentP, tLen);
				membIdentP->slot = slot;
				membIdentP->objRef = *objRefP;
				docP = &membIdentP->doc;
				docP->len = tLen;
				docP->type = kConstant;
				CEquStr(docP->name, memberName);
				docP->returnClassID = kStringClassID;
				docP->isBuiltIn = true;
				docP->implem = kCImplementation;
				docP->ident.c.val = res;
				if (membIdentBlockP)
					*membIdentBlockP = 0;
				if (membActionP)
					*membActionP = membIdentP;
			}
		}
		*isBuiltInP = true;
	}
	else
		*isBuiltInP = false;
	if (err && allocated)
		PoolDisposePtr(gsDispatcherData.propertyActionPool, slot);
		//DisposeBlock(membIdentBlockP);
		
return err;
}

//===========================================================================================
XErr	FillNotifyItem(ObjRecord *objRefP, char *propName, SuperIsChangedNotify **notifyP, long visibility)
{	
SuperIsChangedNotify	*nP;
XErr					err = noErr;
//BlockRef				block;
uint32_t				slot;

	if (objRefP->id && (visibility != kPrivate))
	{	if (notifyP)
		{	if NOT(*notifyP)
			{	if NOT(err = PoolNewPtr(gsDispatcherData.notifySuperIsChangedPool, (Ptr*)notifyP, &slot))
				{	nP = *notifyP;
					nP->slot = slot;
					//nP->block = block;
					nP->toNotify = false;
					nP->tot = 0;
				}
			}
			else
				nP = *notifyP;
			CEquStr(nP->propertyName[nP->tot], propName);
			nP->objRef[nP->tot] = *objRefP;
			nP->tot++;
		}
	}

return err;
}

//===========================================================================================
XErr	CClassHasMember(long api_data, char *memberName, long classID, ObjRecord *objRefP, BlockRef *membIdentBlockP, MemberAction **membActionP, int followChar, Boolean *memberExistsP, Boolean fromTryCurrent, SuperIsChangedNotify **notifyP, Boolean getInfo, Boolean gettingReference)
{	
XErr					err = noErr;
long					pluginID, membID, docLength, extID, tLen;
//int					followChar;
PluginRecord			*plugRecP;
Boolean					result, allocated;
MemberAction 			*membIdentP;
uint32_t				slot = -1;

	result = false;
	allocated = false;
	plugRecP = &gClassRecordBlockP[classID-1];
	if (membIdentBlockP)
		*membIdentBlockP = 0;
	if (membActionP)
		*membActionP = 0;
	//if (fromTryCurrent && plugRecP->dynamic && membIdentP->memberObjRef.id)
	//	return noErr;//XError(kBAPI_Error, Err_NoSuchMember);
	
	/*
	if (membIdentP->doc.type == kMethod)
		followChar = '(';
	else
		followChar = 0;
	*/
	
	if (/*membIdentP->memberObjID*/membID = DLM_GetObjIDExt(plugRecP->membersList, memberName, nil, &pluginID/*memberPluginID*/, &docLength))
	{	
	//MemberHeader	memberHeader;
	
		if (membIdentBlockP)
		{	tLen = sizeof(MemberAction) - sizeof(BAPI_Doc) + docLength;
			// if pass nil as membActionP always a BlockRef is allocated
			if (membActionP && (tLen == POOL_PROPERTY_ACTION_SIZE))
			{	if NOT(err = PoolNewPtr(gsDispatcherData.propertyActionPool, (Ptr*)&membIdentP, &slot))
				{	ClearBlock(membIdentP, tLen);
					membIdentP->slot = slot;
					*membIdentBlockP = 0;
				}
			}
			else
			{	if (*membIdentBlockP = NewBlockLocked(tLen, &err, (Ptr*)&membIdentP))
					ClearBlock(membIdentP, tLen);
			}
			if NOT(err)
			{	allocated = true;
				if (membActionP)
					*membActionP = membIdentP;
				membIdentP->id = membID;
				membIdentP->doc.ident.c.pluginID = pluginID;
				//tLen = sizeof(MemberHeader);
				// if NOT(err = DLM_GetObj(plugRecP->membersList, membIdentP->memberObjID, (Ptr)&memberHeader, &tLen, offsetof(MemberRecord, memberHeader)+1, nil))
				if NOT(err = DLM_GetObj(plugRecP->membersList, membID, (Ptr)&membIdentP->doc, &docLength, 0, nil))
				{	if NOT(getInfo)
						membIdentP->objRef = *objRefP;
					//membIdentP->doc.ident.c.val = membIdentP->doc.value;
					/*membIdentP->memberValue = memberHeader.value;
					membIdentP->memberClassID = memberHeader.classID;
					membIdentP->memberType = memberHeader.type;
					membIdentP->memberArrayLevel = memberHeader.returnAeLevel;
					membIdentP->memberArrayElementClassID = memberHeader.returnAeClassID;
					membIdentP->memberIsStatic = memberHeader.isStatic;
					membIdentP->memberIsConstant = memberHeader.isConstant;
					membIdentP->memberIsError = memberHeader.isError;*/
					err = CheckIfStatic(membIdentP, objRefP, fromTryCurrent, getInfo, gettingReference);
					/*if NOT(getInfo)
					{	if (NOT(membIdentP->doc.isStatic) && NOT(objRefP->id))
							err = XError(kBAPI_Error, Err_MemberIsNotStatic);
						else if (membIdentP->doc.isStatic && objRefP->id)
							err = XError(kBAPI_Error, Err_MemberIsStatic);
					}*/
					if NOT(err)
					{	if (notifyP && *notifyP)
						{	char *propP = (*notifyP)->propertyName[(*notifyP)->tot-1];
							
							if NOT(*propP)
								CEquStr(propP, membIdentP->doc.name);
						}
					}
				}
			}
		}
		result = true;
	}
	else if NOT(getInfo)
	{	while (NOT(membID) && NOT(err))
		{	if (extID = plugRecP->extendedPluginID)
			{	if NOT(err = GetMemberInfo(api_data, memberName, extID, objRefP, membIdentBlockP, membActionP, followChar, &result, fromTryCurrent, notifyP, false, gettingReference))
				{	if (result)
					{	membIdentP = *membActionP;	//(MemberAction*)GetPtr(*membIdentBlockP);
						if NOT(err = CheckIfStatic(membIdentP, objRefP, fromTryCurrent, getInfo, gettingReference))
						{	if (objRefP->id)	// if it's not static
							{	if NOT(err = FillNotifyItem(objRefP, memberName, notifyP, kPublic))
								{	if NOT(err = BAPI_GetSuperObj(api_data, OBJREF_P(objRefP), OBJREF_P(&membIdentP->objRef)))
										*objRefP = membIdentP->objRef;
								}
							}
						}
						break;
					}
					else
					{	if (extID > 0)
							plugRecP = &gClassRecordBlockP[extID-1];	// try to see upper
						else
							CDebugStr("ABNORMAL: A C Class cant extend a BifernoClass!!");
							// ex: err = BifernoClassHasMember(api_data, extID, membIdentP, &result, fromTryCurrent, notifyP);
					}
				}
			}
			else
				break;
		}
	}
	if NOT(err)
	{	if (NOT(result) && plugRecP->dynamic && NOT(fromTryCurrent) && NOT(getInfo))
		{	/*
			if (followChar == '(')
				membIdentP->memberType = kMethod;
			else
				membIdentP->memberType = kProperty;
			if NOT(membIdentP->memberObjRef.id)
				membIdentP->memberIsStatic = true;
			membIdentP->memberArrayLevel = MAX_ARRAY_LEVEL;
			*/
			tLen = sizeof(MemberAction) - sizeof(BAPI_ParameterDoc);
			// if (*membIdentBlockP = NewBlockLocked(tLen, &err, (Ptr*)&membIdentP))
			if NOT(err = PoolNewPtr(gsDispatcherData.propertyActionPool, (Ptr*)&membIdentP, &slot))
			{	
			BAPI_Doc	*docP;
			
				if (membIdentBlockP)
					*membIdentBlockP = 0;
				allocated = true;
				ClearBlock(membIdentP, tLen);
				membIdentP->slot = slot;
				if NOT(getInfo)
					membIdentP->objRef = *objRefP;
				docP = &membIdentP->doc;
				docP->len = tLen;
				if (followChar == '(')
					docP->type = kMethod;
				else
					docP->type = kProperty;
				docP->implem = kCImplementation;
				docP->isDynamic = true;
				CEquStr(docP->name, memberName);
				if (NOT(objRefP) || NOT(objRefP->id))
					docP->isStatic = true;
				docP->returnAeLevel = MAX_ARRAY_LEVEL;
				docP->ident.c.pluginID = classID;
				docP->isBuiltIn = false;
				if (membActionP)
					*membActionP = membIdentP;
			}
			result = true;
		}
	}
	if (memberExistsP)
		*memberExistsP = result;
	if (err && allocated)
	{	if (*membIdentBlockP)
			DisposeBlock(membIdentBlockP);
		else
			PoolDisposePtr(gsDispatcherData.propertyActionPool, slot);
	}
return err;
}

//===========================================================================================
static XErr	_EmergencyErr(long api_data, long id, XErr err, BlockRef *errBlockP, long *sizeP)
{
long		size;
CStr255		descr, eNameStr;
CStr15		errStr;
BlockRef	block;

	BufferReset(id);
	BufferAddCString(id, "Error occurred while displaying error: ", NO_ENC, 0);
	CNumToString(err, errStr);
	BufferAddCString(id, errStr, NO_ENC, 0);
	BufferAddCString(id, " ", NO_ENC, 0);
	BAPI_GetErrDescription(api_data, err, eNameStr, nil, nil, descr, nil, 0, nil);
	BufferAddCString(id, eNameStr, NO_ENC, 0);
	if (*descr)
	{	BufferAddCString(id, " (", NO_ENC, 0);
		BufferAddCString(id, descr, NO_ENC, 0);
		BufferAddCString(id, ")", NO_ENC, 0);
	}
	block = BufferGetBlockRef(id, &size);
	if (errBlockP)
		*errBlockP = block;
	if (sizeP)
		*sizeP = size;
		
return noErr;
}

//===========================================================================================
void	DisposePropListRec(BlockRef *propBlockP)
{	
PropertyItem		*propertyItemP;
PropertyListRec 	*propertyList;
int					tot, i;

	if (*propBlockP)
	{	propertyList = (PropertyListRec*)GetPtr(*propBlockP);
		LockBlock(*propBlockP);
		propertyItemP = &propertyList->item[0];
		tot = propertyList->totItems;
		for (i = 0; i < tot; i++, propertyItemP++)		// right to left!
		{	if (propertyItemP->propertyIDXBlockRef)
				DisposeBlock(&propertyItemP->propertyIDXBlockRef);
		}
		DisposeBlock(propBlockP);
	}
}

#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
XErr	GetFinalObjFlag(long api_data, ObjRecordP objRef, Boolean wantConst, Boolean wantFixed, unsigned short *flagsP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
unsigned short	objFlags;
XErr			err = noErr;
long			id;

	if IS_IMMEDIATE_P(objRef)
		objFlags = 0;
	else if (id = OBJ_ID_P(objRef))
		err = DLM_GetInfo(OBJ_LIST_P(objRef), id, &objFlags, nil, nil);
	else
		objFlags = 0;
	if NOT(err)
	{	if (wantConst)
			objFlags |= kCostant;
		else
			objFlags &= (0xFFFF ^ kCostant);
		if (wantFixed)
			objFlags |= kFixedSize;
		else
			objFlags &= (0xFFFF ^ kFixedSize);
	}
	if NOT(err)
		*flagsP = objFlags;
	
return err;
}

//===========================================================================================
XErr	AddElementToArray(long api_data, char *name, ObjRefP objRefP, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err = noErr;
CStr63				aCStr;
char				*strP;
CloneArrayRecord	*csoRecP = (CloneArrayRecord*)param;
long 				destID;
//long				reqClass, reqAeClass;

	if (name)
		strP = name;
	else
	{	*aCStr = 0;
		strP = aCStr;
	}
	if VALID_P(objRefP)
	{	/*if (arrayDim)
		{	reqClass = gsDispatcherData.arrayConstructor;
			reqAeClass = csoRecP->requestedElementClassID;
		}
		else
		{	reqClass = csoRecP->requestedElementClassID;
			reqAeClass = 0;
		}*/
		err = CloneObject(api_data, OBJRECORD_P(objRefP), strP, csoRecP->arrayDLRef, csoRecP->arrObjRef.scope, csoRecP->reqElementClassID/*csoRecP->requestedElementClassID*/, csoRecP->reqElement_Ae_ClassID/*0*/, csoRecP->isArrayConstant, csoRecP->isArrayFixed, &destID, nil, true);
	}
	else
	{
	ObjRecord		emptyObj;
	unsigned short	finalFlags;
	
		finalFlags = 0;
		if (csoRecP->isArrayConstant)
			finalFlags |= kCostant;
		if (csoRecP->isArrayFixed)
			finalFlags |= kFixedSize;
		if NOT(csoRecP->reqElementClassID)
			csoRecP->reqElementClassID = kStringClassID;
		// non so se sia corretto passare 0, 0 nei parametri quinto e sesto
		err = CreateEmptyObject(api_data, strP, csoRecP->arrayDLRef, csoRecP->arrObjRef.scope, csoRecP->reqElementClassID, csoRecP->reqElement_Ae_Level, csoRecP->reqElement_Ae_ClassID, finalFlags, false, &emptyObj);
	}
	if NOT(err)
	{	(csoRecP->arrayDim)++;
		err = DLM_SetArrayDim(csoRecP->arrObjRef.list, csoRecP->arrObjRef.id, csoRecP->arrayDim, true, nil, 0);
	}
	
return err;
}

//===========================================================================================
XErr	GetArraySpecs(long api_data, ObjRecord *arrayObjP, ArraySpecs *specP)
{
ObjRecord	tObjRef;
XErr		err = noErr;
long		arrayElemAeLevel, arrayDim, arrayElemClassID;

	tObjRef = *arrayObjP;
	arrayElemAeLevel = 0;
	if NOT(err = DLM_GetArrayInfo(arrayObjP->list, arrayObjP->id, &specP->arrayFlags, &specP->arrayDLRef, &arrayDim, &arrayElemClassID))
	{	specP->arrayDim = arrayDim;
		if ((arrayElemClassID == gsDispatcherData.arrayConstructor) && arrayDim)
		{	arrayElemAeLevel++;
			if NOT(err = BAPI_ElementOfArray(api_data, OBJREF_P(&tObjRef), 1, OBJREF_P(&tObjRef)))
			{	do {
					if NOT(err = BAPI_GetArrayInfo(api_data, OBJREF_P(&tObjRef), &arrayDim, &arrayElemClassID, nil))
					{	if ((arrayElemClassID == gsDispatcherData.arrayConstructor) && arrayDim)
						{	arrayElemAeLevel++;
							err = BAPI_ElementOfArray(api_data, OBJREF_P(&tObjRef), 1, OBJREF_P(&tObjRef));
						}
						else
							break;
					}
				} while NOT(err);
			}
		}
	}
	if NOT(err)
	{	specP->arrayElemClassID = arrayElemClassID;
		specP->arrayElemAeLevel = arrayElemAeLevel;
	}
		
return err;
}

//===========================================================================================
XErr	CloneArray(long api_data, ObjRecord *source, DLMRef list, ObjRecord *dest, char *destName, long requestedElementClass, Boolean wantConst, Boolean wantFixed)
{
XErr					err = noErr;
CloneArrayRecord		cRec;
long 					reqAeClass /*arrayDim, arrayElemClassID*/;
ObjRecord				destObjRef;
ArraySpecs				arSpec;
unsigned short			arrFlags;

	//if NOT(err = BAPI_GetArrayInfo(api_data, OBJREF_P(source), &arrayDim, nil))
	//{	if NOT(err = TraceElemnts(api_data, source, &element_Ae_Level, &arrayElemClassID))
	//	{
	if NOT(err = GetArraySpecs(api_data, source, &arSpec))
	{	destObjRef.list = list;
		destObjRef.classID = gsDispatcherData.arrayConstructor;
		if (requestedElementClass)
			reqAeClass = requestedElementClass;
		else
			reqAeClass = arSpec.arrayElemClassID;
		cRec.reqElement_Ae_Level = arSpec.arrayElemAeLevel;
		if (arSpec.arrayElemAeLevel)	// multidimensional
		{	cRec.reqElementClassID = gsDispatcherData.arrayConstructor;
			cRec.reqElement_Ae_ClassID = reqAeClass;
		}
		else
		{	cRec.reqElementClassID = reqAeClass;
			cRec.reqElement_Ae_ClassID = 0;
		}
		if (wantConst)
		{
			destObjRef.type = CONSTANT;
			arrFlags = kCostant;
		}
		else
		{	
			destObjRef.type = VARIABLE;
			arrFlags = 0;
		}
		destObjRef.id = DLM_NewArray(list, destName, destObjRef.classID, arrFlags, /*arSpec.arrayDim, */cRec.reqElementClassID, &cRec.arrayDLRef, &err);
		if NOT(err)
		{	cRec.arrObjRef = destObjRef;
			//cRec.expand = false;
			cRec.isArrayConstant = wantConst;
			cRec.isArrayFixed = wantFixed;
			cRec.arrayDim = 0;
			if NOT(err = BAPI_ArrayLoop(api_data, OBJREF_P(source), AddElementToArray, (long)&cRec))
			{	if (dest)
					*dest = destObjRef;
			}
		}
	}
				
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	AvoidCriticalDestruct(long api_data, long theClassId, long theScope)
{
Boolean			res = false;
	XErr		err = noErr;
	
	if not(api_data)	// during session, application free
		res = false;
	else if ((theScope == APPLICATION || theScope == PERSISTENT /*|| theScope == SESSION*/) && ((BifernoRecP)api_data)->currentCtx.defaultScope == LOCAL)
	{
		if (theClassId == gsDispatcherData.arrayConstructor || theClassId < 0)
			res = true;
		else if (theClassId > 0)
			res = gClassRecordBlockP[theClassId-1].wantDestructor;
	}
	if (res)
		err = XError(kBAPI_Error, Err_IllegalDestructor);

return err;
}

//===========================================================================================
XErr	CoercionToRequestedType(long api_data, ObjRecordP elem, /*long *operationP, */long requestedType, ObjRecordP newElem, long typeCastType)
{
XErr		err = noErr;
ObjRecord	tObj;
ObjRecord	telem;

	if (BAPI_IsReference(api_data, (ObjRefP)elem) && (requestedType != OBJ_CLASSID_P(elem)))
		err = ref_GetTarget(api_data, (ObjRefP)elem, (ObjRefP)&telem, false);
	else
		telem = *elem;
	if NOT(err)
	{	if (requestedType == telem.classID)
			*newElem = telem;
		else
		{	// serve se fai per es. (unsigned)-6, allora devi prima invertire il numero e poi fare il type cast
			/*if (operationP && (*operationP == EVAL_MINUS))
			{	if NOT(err = _InvertObj(api_data, elem, &tObj))
					*operationP = EVAL_ADD;
			}
			else*/
			tObj = telem;
			if NOT(err)
			{	INVAL_P(newElem);
				err = CL_TypeCast(api_data, &tObj, requestedType, newElem, typeCastType);
			}
		}
	}
	
return err;
}

//===========================================================================================
XErr	UndefVariable(long api_data, ObjRef *varObjRefP, Boolean checkForVolatile)
{
XErr				err = noErr;
long				classID;
unsigned short		flags;
BifernoRec			*bRecP;
BfrDestructRec		destructRec;

	if (IS_IMMEDIATE_P(varObjRefP))
		return XError(kBAPI_Error, Err_IllegalUndef);

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
		
	if (checkForVolatile)
	{	if (OBJ_LIST_P(varObjRefP) == bRecP->volatileList)
			return XError(kBAPI_Error, Err_IllegalUndef);
	}
	
	if NOT(err = DLM_GetInfo(OBJ_LIST_P(varObjRefP), OBJ_ID_P(varObjRefP), &flags, &classID, nil))
	{	if (flags & kLocked)
			err = XError(kBAPI_Error, Err_ObjectIsLocked);
		else
		{	destructRec.api_data = (long)bRecP;
			destructRec.scope = OBJ_SCOPE_P(varObjRefP);
			if (classID < 0)
				err = BifernoDestructorCallBack_CheckFlags(OBJ_LIST_P(varObjRefP), OBJ_ID_P(varObjRefP), flags, classID, (long)&destructRec);
			if NOT(err)
			{	if NOT(flags & kNoDestructor)
					err = VariableDestructor(OBJ_LIST_P(varObjRefP), OBJ_ID_P(varObjRefP), flags, classID, (long)&destructRec);
				if NOT(err)
					err = DLM_ResetObj(OBJ_LIST_P(varObjRefP), OBJ_ID_P(varObjRefP), VariableDestructor, (long)&destructRec);
			}
		}
	}
	
return err;
}

//===========================================================================================
// Note: this depends on structs DLM_ArrayIndexRec == ArrayIndexRec
XErr	ResolveArrayElement(long api_data, ObjRefP objRef, ArrayIndexRec *mCoords, short dim, short *lastResolvedP, Boolean *expandedP, ObjRef *elemToAdd, ObjRefP resultObjRef, long *arrayElementClassIDP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
Boolean		toExpand;
DLMRef		elemToAddList;
long		elemToAddID;
DLMBuffer	dlmBuffer, *dlmBufferP;
ObjRef		theArrayObj;

	if (IS_IMMEDIATE_P(objRef))
		err = XError(kBAPI_Error, Err_ArrayRequired);
	else
	{	if NOT(DLM_IsArray(OBJ_LIST_P(objRef), OBJ_ID_P(objRef)))			// is not an array ...
		{	if (OBJ_CLASSID_P(objRef) == gsDispatcherData.refConstructor)	// ... is a ref?
			{	if NOT(err = ref_GetTarget(api_data, objRef, &theArrayObj, true))
					objRef = &theArrayObj;
			}
		}
		if NOT(err)
		{	if (expandedP)
				toExpand = true;
			else
				toExpand = false;
			OBJ_TYPE_P(resultObjRef) = OBJ_TYPE_P(objRef);
			OBJ_SCOPE_P(resultObjRef) = OBJ_SCOPE_P(objRef);
			if (elemToAdd)
			{	if (IS_IMMEDIATE_P(elemToAdd))
				{	LiteralToDLMBuffer(OBJRECORD_P(elemToAdd), &dlmBuffer);
					elemToAddList = 0;
					elemToAddID = 0;
					dlmBufferP = &dlmBuffer;
				}
				else
				{	elemToAddList = OBJ_LIST_P(elemToAdd);
					elemToAddID = OBJ_ID_P(elemToAdd);
					dlmBufferP = nil;
				}
			}
			else
			{	elemToAddList = 0;
				elemToAddID = 0;
			}
			if NOT(err)
			{	err = DLM_ResolveArrayElem(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), (DLM_ArrayIndexRec*)mCoords, dim, lastResolvedP, toExpand, expandedP, &OBJ_LIST_P(resultObjRef), &OBJ_ID_P(resultObjRef), &OBJ_CLASSID_P(resultObjRef), elemToAddList, elemToAddID, dlmBufferP, gsDispatcherData.arrayConstructor, arrayElementClassIDP);
				if (err == XError(kXHelperError, DLM_Err_ObjectNotFound))
				{	if (IsIntNumber(mCoords->ind_name, &mCoords->ind))
					{	XErr	tErr;
					
						*mCoords->ind_name = 0;
						tErr = DLM_ResolveArrayElem(OBJ_LIST_P(objRef), OBJ_ID_P(objRef), (DLM_ArrayIndexRec*)mCoords, dim, lastResolvedP, toExpand, expandedP, &OBJ_LIST_P(resultObjRef), &OBJ_ID_P(resultObjRef), &OBJ_CLASSID_P(resultObjRef), elemToAddList, elemToAddID, dlmBufferP, gsDispatcherData.arrayConstructor, arrayElementClassIDP);
						if NOT(tErr)
							err = noErr;
					}
				}
				
				if (err)
				{	// This error should never happen
					//if (err == XError(kXHelperError, DLM_Err_InvalidArrayIndex))
					//	err = XError(kBAPI_Error, Err_ObjectIsArray);
					//else 
					if (err == XError(kXHelperError, DLM_Err_ObjectNotFound))
						err = XError(kBAPI_Error, Err_ArrayElementNotFound);
					else if (err == XError(kXHelperError, DLM_Err_OutOfBoundary))
						err = XError(kBAPI_Error, Err_OutOfBoundary);
				}
			}
		}
	}
	
return err;													
}

//===========================================================================================
XErr	NotifySuperIsChanged(long api_data, SuperIsChangedNotify *notifyP)
{
XErr		err = noErr;
int			i, tot;
ObjRecord		*objRefP;

	if (notifyP->toNotify)
	{	tot = notifyP->tot;
		objRefP = notifyP->objRef;
		for (i = 0; (i < tot) && NOT(err); i++, objRefP++)
		{
			err = CL_SuperIsChanged(api_data, objRefP, notifyP->propertyName[i]);
		}
	}

return err;
}

//===========================================================================================
/*XErr	GetProtoBlock(long api_data, long classID, long funcObjID, Boolean isBiferno, BlockRef *blockRefP, ProtoParam **tProtoParamP, long *totParamsP, char *prototype, Boolean *dontCheckNumParamsP, Boolean *dontCheckNamesP, Boolean fromConstructor, long *returnClassIDP, Boolean *visibilityP, Boolean *isStaticP)
{
long			tLen, protoObjID;
BlockRef		bl = 0;
XErr			err = noErr;
BifernoRecP 	bRecP = (BifernoRecP)api_data;
MemberRecord	membRec, *membRecP;
BifernoFunc		bifernoFunc;
DLMRef			protolist;

	if (classID > 0)
	{	if (funcObjID)
		{	tLen = sizeof(MemberRecord);
			if NOT(err = DLM_GetObj(gClassRecordBlockP[classID-1].membersList, funcObjID, (Ptr)&membRec, &tLen, 0, nil))
			{	protoObjID = membRec.protoParamObjID;
				protolist = gsDispatcherData.prototypes;
				if (dontCheckNumParamsP)
					*dontCheckNumParamsP = membRec.memberHeader.dontCheckNumParams;
				if (dontCheckNamesP)
					*dontCheckNamesP = membRec.memberHeader.dontCheckNames;
				if (prototype)
					CEquStr(prototype, membRec.prototype);
				*totParamsP = membRec.totParams;
				if (returnClassIDP)
					*returnClassIDP = membRec.returnClassID;
				if (visibilityP)
					*visibilityP = kPublic;		// C member are always public
				if (isStaticP)
					*isStaticP = membRec.memberHeader.isStatic;
			}
		}
		else	// constructor
		{	membRecP = &gClassRecordBlockP[classID-1].constructor;
			protoObjID = membRecP->protoParamObjID;
			protolist = gsDispatcherData.prototypes;
			if (dontCheckNumParamsP)
				*dontCheckNumParamsP = membRecP->memberHeader.dontCheckNumParams;
			if (dontCheckNamesP)
				*dontCheckNamesP = membRecP->memberHeader.dontCheckNames;
			if (prototype)
				CEquStr(prototype, membRecP->prototype);
			*totParamsP = membRecP->totParams;
			if (isStaticP)
				*isStaticP = membRecP->memberHeader.isStatic;
			if (returnClassIDP)
				*returnClassIDP = classID;
		}
	}
	else if (classID < 0)
	{	BifernoClass	bifernoClass;
		
		tLen = sizeof(BifernoClass);
		//ex if NOT(err = DLM_GetObj(bRecP->application.classesList, -classID, (Ptr)&bifernoClass, &tLen, 0, nil))
		if NOT(err = GetUserClassRecord(bRecP, classID, (Ptr)&bifernoClass, &tLen, 0, nil))
		{	if (NOT(funcObjID) && fromConstructor)	// constructor
			{	if NOT(funcObjID = bifernoClass.constructorObjID)
				{	*blockRefP = 0L;
					*tProtoParamP = nil;
					if (prototype)
						*prototype = 0;
					return noErr;
				}
			}
			if NOT(err)
			{	tLen = sizeof(BifernoFunc);
				if NOT(err = DLM_GetObj(bifernoClass.methods, funcObjID, (Ptr)&bifernoFunc, &tLen, 0, nil))
				{	protoObjID = bifernoFunc.protoParamObjID;
					protolist = bifernoClass.prototypes;
					if (dontCheckNumParamsP)
						*dontCheckNumParamsP = bifernoFunc.dontCheckNumParams;
					if (dontCheckNamesP)
						*dontCheckNamesP = bifernoFunc.dontCheckNames;
					if (prototype)
						CEquStr(prototype, bifernoFunc.prototype);
					*totParamsP = bifernoFunc.totParams;
					if (returnClassIDP)
					{	if (fromConstructor)
							*returnClassIDP = classID;
						else
							*returnClassIDP = bifernoFunc.returnClassID;
					}
					if (visibilityP)
						*visibilityP = bifernoFunc.visibility;
					if (isStaticP)
						*isStaticP = bifernoFunc.isStatic;
				}
			}
		}
	}
	else	// function
	{	if (isBiferno)
		{	tLen = sizeof(BifernoFunc);
			//ex if NOT(err = DLM_GetObj(bRecP->application.functionList, funcObjID, (Ptr)&bifernoFunc, &tLen, 0, nil))
			if NOT(err = GetUserFunctionRecord(bRecP, -funcObjID, (Ptr)&bifernoFunc, &tLen, 0, nil))
			{	protoObjID = bifernoFunc.protoParamObjID;
				protolist = bifernoFunc.protoParamList;			// gsDispatcherData.prototypes;
				if (dontCheckNumParamsP)
					*dontCheckNumParamsP = bifernoFunc.dontCheckNumParams;
				if (dontCheckNamesP)
					*dontCheckNamesP = bifernoFunc.dontCheckNames;
				if (prototype)
					CEquStr(prototype, bifernoFunc.prototype);
				*totParamsP = bifernoFunc.totParams;
				if (returnClassIDP)
					*returnClassIDP = bifernoFunc.returnClassID;
			}
		}
		else
		{	tLen = sizeof(MemberRecord);
			if NOT(err = DLM_GetObj(gsDispatcherData.functionsList, funcObjID, (Ptr)&membRec, &tLen, 0, nil))
			{	protoObjID = membRec.protoParamObjID;
				protolist = gsDispatcherData.prototypes;
				if (dontCheckNumParamsP)
					*dontCheckNumParamsP = membRec.memberHeader.dontCheckNumParams;
				if (dontCheckNamesP)
					*dontCheckNamesP = membRec.memberHeader.dontCheckNames;
				if (prototype)
					CEquStr(prototype, membRec.prototype);
				*totParamsP = membRec.totParams;
				if (returnClassIDP)
					*returnClassIDP = membRec.returnClassID;
			}
		}
	}
	if NOT(err)
	{	if (protoObjID)
		{	if NOT(err = DLM_GetObj(protolist, protoObjID, nil, &tLen, 0, nil))
			{	if (bl = NewBlockLocked(tLen, &err, (Ptr*)tProtoParamP))
				{	//*tProtoParamP = (ProtoParam*)GetPtr(bl);
					//LockBlock(bl);
					err = DLM_GetObj(protolist, protoObjID, (Ptr)*tProtoParamP, &tLen, 0, nil);
				}
			}
		}
		else 	// is void
		{	*tProtoParamP = nil;
			bl = 0;
		}
	}
	if NOT(err)
		*blockRefP = bl;

return err;
}
*/
//===========================================================================================
XErr	IsToDestruct(ObjRecord *objRefP, Boolean *toDestructP)
{
XErr	err = noErr;
unsigned short	flags;

	if NOT(err = DLM_GetInfo(objRefP->list, objRefP->id, &flags, nil, nil))
		*toDestructP = NOT(flags & kNoDestructor);

return err;
}

//===========================================================================================
// Biferno class: dispose only the instance (don't call the destructor)
XErr	VariableDestructor(DLMRef dlRef, long objID, unsigned short flags, long classID, long userData)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
#endif
XErr			err = noErr;
BfrDestructRec	*destructRecP = (BfrDestructRec*)userData;

	if (err = AvoidCriticalDestruct(destructRecP->api_data, classID, destructRecP->scope))
		return err;

	if (classID > 0)
		err = _CVarDestructor(dlRef, objID, classID, destructRecP->scope, destructRecP->api_data);
	else if (classID < 0)
	{	
		err = BifernoDisposeInstanceList(destructRecP->api_data, dlRef, objID, destructRecP->scope);
	}
	
return err;
}

//===========================================================================================
// Biferno class: dispose the instance and calls the destructor (check if objRefInDestruction)
XErr	VariableDestructorExt(DLMRef dlRef, long objID, unsigned short flags, long classID, long userData)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(flags)
#endif
XErr			err = noErr;	//, errOnDestruct = noErr;
BfrDestructRec	*destructRecP = (BfrDestructRec*)userData;

	if (err = AvoidCriticalDestruct(destructRecP->api_data, classID, destructRecP->scope))
		return err;

	if (classID > 0)
		err = _CVarDestructor(dlRef, objID, classID, destructRecP->scope, destructRecP->api_data);
	else if (classID < 0)
	{	BifernoRecP	bRecP = (BifernoRecP)destructRecP->api_data;
		BifernoInstance	instance;
		long			tLen;
		DLMRef			saveLocalList;
		
		// Already destroying this?
		if (dlRef == bRecP->localList)
			saveLocalList = bRecP->localList;
		else
			saveLocalList = 0;
		if ((bRecP->objRefInDestruction.id != objID) && (bRecP->objRefInDestruction.list != dlRef))
			err = BifernoDestructorCallBack(dlRef, objID, 0, classID, destructRecP->scope, destructRecP->api_data);
		if NOT(err)
		{	// otherwise Destructor (on error) released the local list!
			if (NOT(saveLocalList) || (saveLocalList == bRecP->localList))
			{	tLen = sizeof(BifernoInstance);
				err = DLM_GetObj(dlRef, objID, (Ptr)&instance, &tLen, 0, nil);
				if (err == XError(kXHelperError, DLM_Err_NoMoreDataInObject))
					err = noErr;
				else if NOT(err)
					err = DLM_Dispose(&instance.list, VariableDestructorExt, userData);
			}
		}
	}
	
return err;
}

//===========================================================================================
Boolean SameObj(DLMRef list1, long id1, DLMRef list2, long id2)
{
Boolean		res;

	res = (list1 == list2) && (id1 == id2);

return res;
}

//===========================================================================================
XErr	GetMemberInfo(long api_data, char *memberName, long classID, ObjRecord *objRefP, BlockRef *membIdentBlockP, MemberAction **membActionP, int followChar, Boolean *memberExistsP, Boolean fromTryCurrent, SuperIsChangedNotify **notifyP, Boolean getInfo, Boolean gettingReference)
{
XErr			err = noErr;
Boolean			result, isBuiltIn;
BifernoRecP 	bRecP;

	result = false;
	bRecP = (BifernoRecP)api_data;
	if NOT(err = _IsBuiltInMember(memberName, objRefP, membIdentBlockP, membActionP, &isBuiltIn))
	{	if (isBuiltIn)
			result = true;
		else
		{	if NOT(classID)
				err = XError(kBAPI_Error, Err_NoSuchMember);
			else if (classID > 0)
				err = CClassHasMember(api_data, memberName, classID, objRefP, membIdentBlockP, membActionP, followChar, &result, fromTryCurrent, notifyP, getInfo, gettingReference);
			else
				err = BifernoClassHasMember(api_data, memberName, classID, objRefP, membIdentBlockP, membActionP, followChar, &result, fromTryCurrent, notifyP, getInfo, gettingReference);
		}
		if (memberExistsP)
			*memberExistsP = result;	
	}
	
return err;
}

//===========================================================================================
// Cambiare valore di un Obj nella lista statica
XErr	ModifyVariable(long api_data, ObjRecordP varToSet, ObjRecordP value, long typeCastType, Boolean ignoreIfConstant, BAPI_ModifyHook _modCB)
{
unsigned short			flags;
XErr					err = noErr;
BifernoRecP				bRecP = (BifernoRecP)api_data;
ObjRecord				dest, *destP;
Boolean					isImmediate = IS_IMMEDIATE_P(value);
		
	if (_modCB)
		err = _modCB(api_data, (ObjRefP)varToSet, (ObjRefP)value);
	else
	{	if (value->classID != varToSet->classID)
		{	INVAL(dest);
			if NOT(err = CL_TypeCast(api_data, value, varToSet->classID, &dest, typeCastType))
				destP = &dest;
		}
		else
			destP = value;
		if NOT(err)
		{	if NOT(isImmediate)
			{	if (value->list != bRecP->volatileList)
					CDebugStr("ModifyVariable: non doveva succedere mai");
				if NOT(err = DLM_GetInfo(varToSet->list, varToSet->id, &flags, nil, nil))
				{	if NOT(flags & kNoDestructor)
						err = DestructVariableWithAllSupers(api_data, varToSet);
				}
			}
			if NOT(err)
				err = _CopyTheObject(api_data, destP, nil, varToSet->scope, varToSet->type, varToSet, true, 0, 0, isImmediate, typeCastType, ignoreIfConstant, _modCB);
			/*else if (err == XError(kBAPI_Error, Err_IllegalDestructor))
			{
				// try copying elements (or properties) between two objects
				err = _CopyTheElements(api_data, destP, varToSet, isImmediate, ignoreIfConstant);
			}*/
		}
	}
return err;
}

//===========================================================================================
XErr	GetUserHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, long lastClassErrCalled, char *error_code, char *host, char *appName)
{
BifernoRec	*bRecP;
XErr		err = noErr;
long		id;
CStr255		codeString, subErrStr, eNameStr, lineStr;//	, aCStr;
CStr63		errNumStr, errType, errLineStr, webMastStr;
Boolean		saveSuspendResume;

	if (error_code && *error_code)
	{	if (host)
			CEquStr(codeString, host);
		else
			CEquStr(codeString, "?");
		CAddStr(codeString, "-");
		if (appName)
			CAddStr(codeString, appName);
		else
			CAddStr(codeString, "?");
		CAddStr(codeString, "-");
		if (error_code)
			CAddStr(codeString, error_code);	
		else
			CAddStr(codeString, "?");
	}
	else
		*codeString = 0;
	bRecP = (BifernoRecP)api_data;
	if (bRecP)
	{	CEquStr(webMastStr, bRecP->application.webMaster);
		saveSuspendResume = bRecP->_suspendResume;
		bRecP->_suspendResume = true;
	}
	else
		*webMastStr = 0;
	FillErrorStrings(api_data, lastClassErrCalled, theError, errNumStr, eNameStr, errType, subErrStr, errLineStr, nil, nil);
	CEquStr(lineStr, "?");
	id = BufferCreate(255, &err);
	if (id && NOT(err))
	{	if (err = BufferAddCString(id, "<html><body bgcolor=\"#ffffff\"><head><title>Script Error</title></head><font face=\"verdana\"><b>\r\n", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, "An error occurred while processing a script (", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, eNameStr, ISOLATIN_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, ")</font>", NO_ENC, 0))
			goto out;
		if (*codeString)
		{	if (*webMastStr)
			{	if (err = BufferAddCString(id, "<p><font face=\"Verdana\" size=\"1\">please, <A HREF=\"mailto:", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, webMastStr, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "?subject=", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, codeString, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "\">email</A> to web master the following error code: ", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, codeString, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "</font>", NO_ENC, 0))
					goto out;
			}
			else
			{	if (err = BufferAddCString(id, "<p><font face=\"Verdana\" size=\"1\">Code: ", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, codeString, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "</font>", NO_ENC, 0))
					goto out;
			}
		}
		else
		{	if (err = BufferAddCString(id, "<p><font face=\"Verdana\" size=\"1\">The webmaster has been notified</font>\r\n", NO_ENC, 0))
				goto out;
		}
		if (err = BufferAddCString(id, "</body></html>\r\n", NO_ENC, 0))
			goto out;
	}
	
out:
if NOT(err)
{	long		size;
	BlockRef	bl;

	bl = BufferGetBlockRef(id, &size);
	if (errBlockP)
		*errBlockP = bl;
	if (sizeP)
		*sizeP = size;
	BufferClose(id);
}
else
{	if (id)
	{	if NOT(err = _EmergencyErr(api_data, id, err, errBlockP, sizeP))
			BufferClose(id);
		else
			BufferFree(id);
	}
	else
	{	if (errBlockP)
			*errBlockP = 0;
	}
}
if (bRecP)
	bRecP->_suspendResume = saveSuspendResume;
return err;
}

//===========================================================================================
/*XErr	GetUserHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, long lastClassErrCalled, char *error_code)
{
BifernoRec	*bRecP;
XErr		err = noErr;
long		id;
CStr255		subErrStr, eNameStr, lineStr, aCStr;
CStr63		errNumStr, errType, errLineStr, webMastStr;

	bRecP = (BifernoRecP)api_data;
	if (bRecP)
	{	CEquStr(webMastStr, bRecP->application.webMaster);
		bRecP->_suspendResume = true;
	}
	else
		*webMastStr = 0;

	FillErrorStrings(api_data, lastClassErrCalled, theError, errNumStr, eNameStr, errType, subErrStr, errLineStr, nil, nil);
	CEquStr(lineStr, "?");
	id = BufferCreate(255, &err);
	if (id && NOT(err))
	{	
		if (err = BufferAddCString(id, "<html><body bgcolor=\"#ffffff\"><center><table border=\"3\" cellpadding=\"3\" cellspacing=\"3\"><tr><td align=\"center\"><font face=\"verdana\"><b>\r\n", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, errType, ISOLATIN_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, "<p><font color=\"red\">\r\n", NO_ENC, 0))
			goto out;			
		if (err = BufferAddCString(id, errNumStr, NO_ENC, 0))
			goto out;			
		if (err = BufferAddCString(id, "</font></font><p><b>\r\n", NO_ENC, 0))
			goto out;			
		if (*eNameStr)
		{	if (err = BufferAddCString(id, eNameStr, ISOLATIN_ENC, 0))
				goto out;
		}
		if (err = BufferAddCString(id, "</b><p>", NO_ENC, 0))
			goto out;
		if (error_code && *error_code)
		{	if (*webMastStr)
			{	if (err = BufferAddCString(id, "<p><font face=\"Verdana\" size=\"1\">please, <A HREF=\"mailto:", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, webMastStr, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "?subject=", NO_ENC, 0))
					goto out;
				if (err = HTTPControllerGetServerParam(bRecP->userData, kServerDomain, aCStr, nil))
					goto out;
				if (err = BufferAddCString(id, aCStr, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, ", Biferno Error: ", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, error_code, NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(id, "\">email</A> to web master the following error code <br>", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, error_code, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "</font>", NO_ENC, 0))
					goto out;
			}
			else
			{	if (err = BufferAddCString(id, "<p><font face=\"Verdana\" size=\"1\">", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, error_code, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "</font>", NO_ENC, 0))
					goto out;
			}
		}


		if (err = BufferAddCString(id, "<p></b></font></td></tr></table>", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, "</body></html>\r\n", NO_ENC, 0))
			goto out;
	}
	
out:
if NOT(err)
{	long		size;
	BlockRef	bl;

	bl = BufferGetBlockRef(id, &size);
	if (errBlockP)
		*errBlockP = bl;
	if (sizeP)
		*sizeP = size;
	BufferClose(id);
}
else
{	if (id)
	{	if NOT(err = _EmergencyErr(api_data, id, err, errBlockP, sizeP))
			BufferClose(id);
		else
			BufferFree(id);
	}
	else
	{	if (errBlockP)
			*errBlockP = 0;
	}
}
return err;
}
*/
//===========================================================================================
XErr	LoadVariablesErrorTable(long api_data, long encodeMode, BlockRef *resultBlockP, long *resultBlockLenP)
{
XErr		err = noErr;
int			s;
CStr255		lineStr, scopeName;
long		i, totList;
DLMRef		listID;
BufferID	id;
BifernoRec	*bRecP = (BifernoRec*)api_data;
BlockRef	resultBlock;
long		stackIndex, resultBlockLen;

	if (bRecP)
	{	if (id = BufferCreate(255, &err))
		{	if NOT(bRecP->criticalMem)
			{	GetDocUrl(api_data, lineStr);
				totList = GetTotScopes() - 1;
				for (i = 0; i < totList; i++)
				{	if NOT(i)
						stackIndex = bRecP->stackPointer;
					else
						stackIndex = 0;
					if (err = GetVariableList(api_data, s = GetScope(i), &listID, true, stackIndex))
					{	err = noErr;
						listID = 0;
					}
					if (listID)
					{	if NOT(err = BAPI_ScopeName(api_data, s, scopeName))
						{	if (err = FillVariableHTMLTable(api_data, listID, s, scopeName, id, encodeMode, lineStr))
								break;
						}
					}
				}
			}
			if NOT(err)
			{	if NOT(err = BufferAddChar(id, 0))
				{	resultBlock = BufferGetBlockRef(id, &resultBlockLen);
					resultBlockLen--;
					BufferClose(id);
				}
			}
			if (err)
				BufferFree(id);
			else
			{	*resultBlockP = resultBlock;
				*resultBlockLenP = resultBlockLen;
			}
		}
	}
	else
		err = XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

return err;
}

//===========================================================================================
XErr	GetHtmlError(long api_data, XErr theError, BlockRef *errBlockP, long *sizeP, char *filePath, long lastClassErrCalled, char *class_error_note, int encodeMode, char *ip, Boolean superuser)
{
BifernoRec	*bRecP;
XErr		err = noErr;
long		/*tList, listID, i, */id;
CStr255		subErrStr, /*scopeName, */eNameStr, lineStr, descr;
CStr63		errNumStr, errType, errLineStr;
Boolean		saveSuspendResume;
char		*class_error_notePtr;
Ptr			fileData;
long		eNum, eType;

	*subErrStr = 0;
	XErrorGetTypeValue(theError, &eNum, &eType);
	if (bRecP = (BifernoRecP)api_data)
	{	saveSuspendResume = bRecP->_suspendResume;
		bRecP->_suspendResume = true;
		//if (bRecP->errorLine)
		//	bRecP->currentCtx.currentLine = bRecP->errorLine;
		//else 
		//if (bRecP->exceptionLine)
		//	bRecP->currentCtx.currentLine = bRecP->exceptionLine;
	}
	FillErrorStrings(api_data, lastClassErrCalled, theError, errNumStr, eNameStr, errType, subErrStr, errLineStr, descr, nil);
	CEquStr(lineStr, "?");
	id = BufferCreate(255, &err);
	if (id && NOT(err))
	{	if (err = BufferAddCString(id, "<html><body bgcolor=\"#ffffff\"><head><title>Script Error</title></head><center>", NO_ENC, 0))
			goto out;
		if (superuser)
		{	if (err = BufferAddCString(id, "<h3>Administrator</h3>", NO_ENC, 0))
				goto out;
		}
		if (err = BufferAddCString(id, "<table border=\"3\" cellpadding=\"3\" cellspacing=\"3\">", NO_ENC, 0))
			goto out;
		if ((eType == kBAPI_ClassError) && *errType)
		{	if (err = BufferAddCString(id, "<tr><td align=\"center\"><font face=\"verdana\"><b>Error of class: ", NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(id, errType, encodeMode, 0))
				goto out;
		}
		else
		{	if (err = BufferAddCString(id, "<tr><td align=\"center\"><font face=\"verdana\"><b>Script Error", NO_ENC, 0))
				goto out;			
		}
		if (err = BufferAddCString(id, "</b><b> (", NO_ENC, 0))
			goto out;			
		if (err = BufferAddCString(id, errNumStr, NO_ENC, 0))
			goto out;			
		if (err = BufferAddCString(id, ")</b></font><p>", NO_ENC, 0))
			goto out;			
		if (*eNameStr)
		{	if (err = BufferAddCString(id, "<font face=\"monaco\" size=\"2\" color=\"red\"><b>", NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(id, eNameStr, encodeMode, 0))
				goto out;
			if (err = BufferAddCString(id, "</b>", NO_ENC, 0))
				goto out;			
			if (*descr)
			{	if (err = BufferAddCString(id, "<br>", NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(id, descr, encodeMode, 0))
					goto out;
				if (err = BufferAddCString(id, "<br>", NO_ENC, 0))
					goto out;			
			}
			if (err = BufferAddCString(id, "</font>", NO_ENC, 0))
				goto out;			
		}
		/*else if (bRecP && bRecP->class_error_note)
		{	if (err = BufferAddCString(id, bRecP->class_error_note, encodeMode, 0))
				goto out;
			classNoteDisplayed = true;
		}*/
		if (err = BufferAddCString(id, "</b><p>\r\n", NO_ENC, 0))
			goto out;
		if (*subErrStr)
		{	if (err = BufferAddCString(id, "<p><font face=\"monaco\" size=\"2\" color=\"red\"><b>Sub Error:</b><br>", NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(id, subErrStr, encodeMode, 0))
				goto out;
			if (err = BufferAddCString(id, "</font><br>\r\n", NO_ENC, 0))
				goto out;
		}
		if (bRecP)
			class_error_notePtr = bRecP->class_error_note;
		else
			class_error_notePtr = class_error_note;
		// Class error notes
		if (lastClassErrCalled && *class_error_notePtr)
		{	if (err = BufferAddCString(id, "\r\n<p><font face=\"monaco\" size=\"2\" color=\"red\"><b>class \"", NO_ENC, 0))
				goto out;			
			if NOT(BAPI_NameFromClassID(api_data, lastClassErrCalled, lineStr))
			{	if (err = BufferAddCString(id, lineStr, NO_ENC, 0))
					goto out;			
			}
			else
			{	if (err = BufferAddCString(id, "?", NO_ENC, 0))
					goto out;			
			}
			if (err = BufferAddCString(id, "\" error message:</b><br>", NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(id, 	class_error_notePtr, encodeMode, 0))
				goto out;
			if (err = BufferAddCString(id, "</font><br>\r\n", NO_ENC, 0))
				goto out;
		}			
		if (bRecP)
		{	// Line
			if (bRecP->currentCtx.currentLine)
			{	if (err = BufferAddCString(id, "<p><font face=\"monaco\" size=\"2\">\r\n<b>at line ", NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(id, errLineStr, encodeMode, 0))
					goto out;
				if (err = BufferAddCString(id, ":</b></font><br>\r\n", NO_ENC, 0))
					goto out;
			}
			if (*bRecP->curFile.filePath)
			{	if (err = BufferAddCString(id, "<font face=\"monaco\" size=\"2\">", NO_ENC, 0))
					goto out;			
				if (bRecP->currentCtx.methodInExecutionID && (bRecP->currentCtx.processing == kProcessingFunction) /*bRecP->errInFunction*/)
				{	//if (bRecP->application.functionList)
					if (bRecP->currentCtx.curMethodList)
					{	BlockRef	bisFunctionBl;
						Ptr			p;
						//long		totalLen;
						BAPI_Doc	*docP;
						
						bisFunctionBl = 0;
						if (bRecP->currentCtx.methodInExecutionID == kConstrID)
						{	if NOT(err = GetContructorDoc(api_data, bRecP->methodInExecutionClass, &docP))
								p = (Ptr)docP;
						}
						else
						{	if NOT(err = GetBifernoFunctionRec(bRecP->currentCtx.curMethodList, bRecP->currentCtx.methodInExecutionID, &p, &bisFunctionBl, nil))
								docP = (BAPI_Doc*)GetPtr(bisFunctionBl);
						}
						if NOT(err)
						{	err = AddXLineOfFile(p + docP->len, docP->ident.b.funcLength/*totalLen - docP->len*/, bRecP->currentCtx.currentLine, id, encodeMode, 0);
							if (bisFunctionBl)
								DisposeBlock(&bisFunctionBl);
							if (err)
								goto out;
						}
					}
				}
				else
				{	fileData = GetPtr(bRecP->curFile.fileData);
					if (fileData)
					{	if (err = AddXLineOfFile(fileData, bRecP->curFile.fileSize, bRecP->currentCtx.currentLine, id, encodeMode, 1))
							goto out;
					}
				}
				if (err = BufferAddCString(id, "</font>\r\n", NO_ENC, 0))
					goto out;
			}
			else if (filePath && *filePath)
			{	if (err = BufferAddCString(id, "<p><font face=\"monaco\" size=\"2\">file:<br>", NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(id, filePath, encodeMode, 0))
					goto out;
				if (err = BufferAddCString(id, "</font><br>\r\n", NO_ENC, 0))
					goto out;
			}
			if (*bRecP->curFile.filePath)
			{	if (bRecP->currentCtx.methodInExecutionID && bRecP->currentCtx.curMethodList)
				{	if (bRecP->currentCtx.methodInExecutionID == kConstrID)
						err = BAPI_NameFromClassID(api_data, bRecP->methodInExecutionClass, eNameStr);
					else
						err = DLM_GetInfo(bRecP->currentCtx.curMethodList, bRecP->currentCtx.methodInExecutionID, nil, nil, eNameStr);
					if NOT(err)
					{	if ((bRecP->currentCtx.curMethodList == bRecP->local.funcsList) || (bRecP->currentCtx.curMethodList == bRecP->application.funcsList))
							err = BufferAddCString(id, "<p><font face=\"monaco\" size=\"2\"><b>in function:</b><br>", NO_ENC, 0);
						else
							err = BufferAddCString(id, "<p><font face=\"monaco\" size=\"2\"><b>in method:</b><br>", NO_ENC, 0);
						if (err)
							goto out;			
						if (err = BufferAddCString(id, eNameStr, encodeMode, 0))
							goto out;
						if (err = BufferAddCString(id, "</font><br>\r\n", NO_ENC, 0))
							goto out;
					}
				}
				if (err = BufferAddCString(id, "<p><font face=\"monaco\" size=\"2\"><b>of file:</b><br>", NO_ENC, 0))
					goto out;			
				if (err = BufferAddCString(id, bRecP->curFile.filePath, encodeMode, 0))
					goto out;
				if (err = BufferAddCString(id, "</font><br>\r\n", NO_ENC, 0))
					goto out;
			}
		}
		else if (filePath && *filePath)
		{	if (err = BufferAddCString(id, "<p><font face=\"monaco\" size=\"2\"><b>file:</b><br>", NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(id, filePath, encodeMode, 0))
				goto out;
			if (err = BufferAddCString(id, "</font><br>\r\n", NO_ENC, 0))
				goto out;
		}
		/*if (*eMsg)
		{	if (err = BufferAddCString(id, "\r\n<p><b>notes: </b><br>", NO_ENC, 0))
				goto out;			
			if (err = BufferAddCString(id, eMsg, encodeMode, kTagsVisible+kAlsoCR))
				goto out;
			if (err = BufferAddCString(id, "\r\n", NO_ENC, 0))
				goto out;
		}*/
		if (err = PrintMsgRecords(api_data, id, encodeMode))
			goto out;
		if (bRecP && bRecP->onErrorResume)
		{	
		Boolean		exists;
		ObjRecord		errRef;
		long		actualValue;
		
			if (err = BAPI_IsVariableDefined(api_data, "err", GLOBAL, &exists, OBJREF_P(&errRef)))
				goto out;
			if (exists)
				err = BAPI_ObjToInt(api_data, OBJREF_P(&errRef), &actualValue, kExplicitTypeCast);
			else
				actualValue = 0;
			if (actualValue)
			{	if (err = BufferAddCString(id, "<p><font face=\"verdana\" color=\"red\"><b>OnErrorResume is on", NO_ENC, 0))
					goto out;
				if (bRecP->moreErrors)
				{	if (err = BufferAddCString(id, "<br>and there was a previous error (", NO_ENC, 0))
						goto out;
					CNumToString(actualValue, eNameStr);
					if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
						goto out;
					if (err = BufferAddCString(id, ")", NO_ENC, 0))
						goto out;
				}
			}
			else
			{	if (err = BufferAddCString(id, "<p><font face=\"verdana\"><b>OnErrorResume is on", NO_ENC, 0))
					goto out;
			}
			if (err = BufferAddCString(id, "</b></font>", NO_ENC, 0))
				goto out;
			
		}
		if (err = BufferAddCString(id, "<p></td></tr></table>\r\n", NO_ENC, 0))
			goto out;
		
		if (bRecP)
		{	
		BlockRef	tableBlock;
		long		tableBlockLen;
		
			if NOT(err = PrintStack(bRecP, id))
			{	if NOT(err = LoadVariablesErrorTable(api_data, encodeMode, &tableBlock, &tableBlockLen))
				{	LockBlock(tableBlock);
					err = BufferAddBuffer(id, GetPtr(tableBlock), tableBlockLen);
					DisposeBlock(&tableBlock);
					if (err)
						goto out;
				
				}
			}
		}		
		/*{	
		int	s;
		
			if NOT(bRecP->criticalMem)
			{	GetDocUrl(api_data, lineStr);
				tList = GetTotScopes() - 1;
				for (i = 0; i < tList; i++)
				{	if (err = GetVariableList(api_data, s = GetScope(i), &listID))
					{	err = noErr;
						listID = 0;
					}
					if (listID)
					{	if NOT(err = BAPI_ScopeName(api_data, s, scopeName))
						{	if (err = FillVariableHTMLTable(api_data, listID, s, scopeName, id, encodeMode, lineStr))
								goto out;
						}
					}
				}
			}
			if (err = PrintStack(bRecP, id))
				goto out;
		}*/
		if (err = BufferAddCString(id, "</center><font face=\"Verdana\" size=\"2\"><br>", NO_ENC, 0))
			goto out;

		XGetSysInfo(eNameStr);
		if (err = BufferAddCString(id, "System: ", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
			goto out;
		
		BAPI_GetVersions(0, eNameStr, nil, nil);
		if (err = BufferAddCString(id, "Biferno version: ", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
			goto out;

		XCurrentDateTimeToString(eNameStr, kComplete);
		if (err = BufferAddCString(id, "Date: ", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
			goto out;
		if (bRecP)
		{	/*if (err = HTTPControllerGetServerParam(bRecP->userData, kServerUpSinceDate, eNameStr, nil))
				err = noErr;
			else
			{*/
			if (err = BufferAddCString(id, "Up Since: ", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, gsUpSinceStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
				goto out;
			//}
			if (err = HTTPControllerGetServerName(bRecP->userData, eNameStr))
			{	err = noErr;
				CEquStr(eNameStr, "?");
			}
			if (*eNameStr)
			{	if (err = BufferAddCString(id, "Web Server: ", NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
					goto out;
				if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
					goto out;
			}
		}
		
		if (ip && *ip)
		{	if (err = BufferAddCString(id, "IP address: ", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, ip, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
				goto out;
		}
		if (bRecP && bRecP->startTicks)
		{	long	diff;
		
			if (err = BufferAddCString(id, "Start ticks: ", NO_ENC, 0))
				goto out;
			CNumToString(bRecP->startTicks, subErrStr);
			FormatNumber(subErrStr, eNameStr, ',', '.');
			if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
				goto out;

			if (err = BufferAddCString(id, "Last Block Process: ", NO_ENC, 0))
				goto out;
			CNumToString(bRecP->finalTicks, subErrStr);
			FormatNumber(subErrStr, eNameStr, ',', '.');
			if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, "\r\n<br>", NO_ENC, 0))
				goto out;

			if (err = BufferAddCString(id, "Duration: ", NO_ENC, 0))
				goto out;
			CNumToString(XGetTicks() - bRecP->startTicks, subErrStr);
			FormatNumber(subErrStr, eNameStr, ',', '.');
			if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, " ticks (timeout is: ", NO_ENC, 0))
				goto out;
			CNumToString(bRecP->timeOut, subErrStr);
			FormatNumber(subErrStr, eNameStr, ',', '.');
			if (err = BufferAddCString(id, eNameStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, ")\r\n", NO_ENC, 0))
				goto out;				
			diff = bRecP->finalTicks - bRecP->startTicks;
			CNumToString(diff, subErrStr);
			if (err = BufferAddCString(id, " - (", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, subErrStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, ")\r\n<br>", NO_ENC, 0))
				goto out;
		}
		if (bRecP)
		{
		BlockRef	aBlock;
		long		aLen;
		
			if (err = BufferAddCString(id, "Temp. Max Size: ", NO_ENC, 0))
				goto out;
			CNumToString(bRecP->volatileMaxSize / 1024, subErrStr);
			if (err = BufferAddCString(id, subErrStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, " K\r\n<br>", NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, "Temp. Resets: ", NO_ENC, 0))
				goto out;
			CNumToString(bRecP->volatileResets, subErrStr);
			if (err = BufferAddCString(id, subErrStr, NO_ENC, 0))
				goto out;
			if (err = BufferAddCString(id, " \r\n<br>", NO_ENC, 0))
				goto out;
			// Full request
			if (err = BufferAddCString(id, "Full Request: ", NO_ENC, 0))
				goto out;
			if NOT(err = HTTPControllerGetFullRequest(bRecP->userData, &aBlock, &aLen))
			{	LockBlock(aBlock);
				err = BufferAddBuffer(id, GetPtr(aBlock), aLen);
				DisposeBlock(&aBlock);
			}
			if (err)
			{	CNumToString(err, errNumStr);
				BufferAddCString(id, errNumStr, NO_ENC, 0);			
				err = noErr;
			}			
			if (err = BufferAddCString(id, " \r\n<br>", NO_ENC, 0))
				goto out;
			// Post
			/*
			if NOT(err = HTTPControllerGetMethod(bRecP->userData, eNameStr))
			{	if NOT(strcmp(eNameStr, "POST"))
				{	if (err = BufferAddCString(id, "Post Args: ", NO_ENC, 0))
						goto out;
					if NOT(err = HTTPControllerGetPostArgs(bRecP->userData, &aBlock, &aLen))
					{	LockBlock(aBlock);
						if (aLen > 512)
							aLen = 512;
						err = BufferAddBuffer(id, GetPtr(aBlock), aLen);
						DisposeBlock(&aBlock);
					}
				}	
			}
			if (err)
			{	CNumToString(err, errNumStr);
				BufferAddCString(id, errNumStr, NO_ENC, 0);			
				err = noErr;
			}			
			if (err = BufferAddCString(id, " \r\n<br>", NO_ENC, 0))
				goto out;
			*/
		}
		if (err = BufferAddCString(id, "</font></body></html>\r\n", NO_ENC, 0))
			goto out;
	}
	
out:
if NOT(err)
{	long	size;
	BlockRef	bl;

	bl = BufferGetBlockRef(id, &size);
	if (errBlockP)
		*errBlockP = bl;
	if (sizeP)
		*sizeP = size;
	BufferClose(id);
}
else
{	if (id)
	{	if NOT(err = _EmergencyErr(api_data, id, err, errBlockP, sizeP))
			BufferClose(id);
		else
			BufferFree(id);
	}
	else
	{	if (errBlockP)
			*errBlockP = 0;
	}
}
if (bRecP = (BifernoRecP)api_data)
	bRecP->_suspendResume = saveSuspendResume;
	
return err;
}

//===========================================================================================
void	GetDocUrl(long api_data, char *docUrl)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
//XErr			err = noErr;
//char			aCStr[512];
//BifernoRecP		bRecP = (BifernoRecP)api_data;

	CEquStr(docUrl, "<A HREF=\"");
	CAddStr(docUrl, BFDOC_PATH);
	/*
	*docUrl = 0;
	if (api_data)
	{	if NOT(err = HTTPControllerGetServerParam(bRecP->userData, kServerDomain, aCStr, nil))
		{	ObjRecord	urlObjRef, request;
			char	*strP;
			
			CEquStr(docUrl, "<A HREF=\"http://");
			CAddStr(docUrl, aCStr);
			request.id = 0;
			if (request.classID = BAPI_ClassIDFromName(api_data, "request", false))
			{	if NOT(err = BAPI_GetProperty(api_data, OBJREF_P(&request), "url", 0, nil, OBJREF_P(&urlObjRef)))
				{	if NOT(err = BAPI_ObjToString(api_data, OBJREF_P(&urlObjRef), aCStr, nil, 512, kExplicitTypeCast))
					{	if (strP = strrchr(aCStr, '/'))
							*(strP+1) = 0;
						if ((CLen(docUrl) + CLen(aCStr) + CLen(BFDOC_PATH)) < 255)
						{	CAddStr(docUrl, aCStr);			
							CAddStr(docUrl, BFDOC_PATH);
						}
						else
							*docUrl = 0;
					}
				}
			}
			if (err)
				CAddStr(docUrl, BFDOC_PATH);
		}
	}
	*/
}

//===========================================================================================
XErr	FillVariableHTMLTable(long api_data, long list, long scope, char *scopeName, long replyID, int encodeMode, char *docUrl)
{
int					k;
unsigned short		flags;
long				enc = encodeMode, stringLen, totObjs;
ObjRecord			tObj;
CStr255				theName, className;
XErr				err = noErr;
CStr255				tempStr, errStr, aCStr;
char				*stringP;
BlockRef			ref = 0;
BifernoRecP			bRecP;
Boolean				saveSuspendMsgs, isLocal, saveResumeAlwaysOldLocal;
//ErrorMsgRecord		*saveErrMessageRecP;
//BlockRef			saveErrMessageRecBlock = 0;
CStr255				saveNote;

	if NOT(list)
		return noErr;
	if NOT(bRecP = (BifernoRecP)api_data)
		return noErr;
	if (NOT(err = DLM_GetTotObjs(list, &totObjs, true)) && totObjs)
	{	BAPI_InvalObjRef(api_data, OBJREF_P(&tObj));
		if (err = BufferAddCString(replyID, "\r\n\r\n<p><a name=\"VariableTopTable\"><p></A><TABLE CELLPADDING=4 BORDER=2 WIDTH=\"100%\" BGCOLOR=\"#CCCCCC\"><tr><th colspan=4><font face=monaco color=red size=2>", NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(replyID, scopeName, NO_ENC, 0))
			goto out;
		if (err = BufferAddCString(replyID, "</font></th></tr>\r\n<tr><th width=15%><font face=monaco size=2>Name</font></th><th width=8%><font face=monaco size=2>Type</font></th><th width=15%><font face=monaco size=2>Class</font></th><th><font face=monaco size=2>Value</font></th></tr>\r\n", NO_ENC, 0))
			goto out;
		saveSuspendMsgs = bRecP->suspendMsgs;
		bRecP->suspendMsgs = true;
		for (k = 1; (k <= totObjs) && NOT(err); k++)
		{	ref = 0;
			if NOT(err = DLM_GetIndObj(list, k, nil, nil, 0, &tObj.classID, &tObj.id, theName, true, true))
			{	if (tObj.classID)
				{	tObj.list = list;
					tObj.scope = scope;
					tObj.type = VARIABLE;
					saveResumeAlwaysOldLocal = bRecP->resumeAlwaysCaller;
					bRecP->resumeAlwaysCaller = true;
					/*saveErrMessageRecP = nil;
					if (GetTotMsgRecords(api_data))
					{	if (saveErrMessageRecBlock = NewBlockLocked(sizeof(ErrorMsgRecord), nil, (Ptr*)&saveErrMessageRecP))
							GetMsgRecords(api_data, saveErrMessageRecP);
					}
					*/
					CEquStr(saveNote, bRecP->class_error_note);
					err = BAPI_GetStringBlockExt(api_data, OBJREF_P(&tObj), aCStr, &stringP, &stringLen, &ref, kExplicitTypeCast, kForDebug);
					CEquStr(bRecP->class_error_note, saveNote);
					bRecP->resumeAlwaysCaller = saveResumeAlwaysOldLocal;
					/*if (saveErrMessageRecP)
					{	SetMsgRecords(api_data, saveErrMessageRecP);
						DisposeBlock(&saveErrMessageRecBlock);
					}
					else
						ResetMsgRecords(api_data);*/
					if (err)
					{	CEquStr(aCStr, "<b><blink>");
						if (err == XError(kBAPI_Error, Err_BAPI_ObjNotPrintable))
						{	CEquStr(errStr, "<b><blink>object not printable (method ");
							CAddStr(errStr, kToStringMethodName);
							CAddStr(errStr, " not found)</blink></b>");
							CAddStr(aCStr, errStr);
							CAddStr(aCStr, "</blink></b>");
						}
						else
						{	BAPI_GetErrDescription(api_data, err, errStr, nil, nil, nil, nil, 0, nil);
							if NOT(*errStr)
								CAddStr(aCStr, "Error");
							else
								CAddStr(aCStr, errStr);
							CAddStr(aCStr, "</blink></b>");
						}
						stringP = aCStr;
						stringLen = CLen(aCStr);
						ref = 0;
						err = noErr;
						enc = NO_ENC;
					}
					if NOT(err)
					{	// name
						if (err = BufferAddCString(replyID, "<tr><td width=\"15%\" valign=\"top\"><font face=monaco size=2>", NO_ENC, 0))
							goto out;
						if (*theName)
						{	if (err = BufferAddCString(replyID, theName, NO_ENC, 0))
								goto out;
						}
						else
						{	if (err = BufferAddCString(replyID, "n.a.", NO_ENC, 0))
								goto out;
						}
						// type
						if (err = DLM_GetInfo(list, tObj.id, &flags, nil, nil))
							goto out;
						if (err = BufferAddCString(replyID, "</font></td><td width=\"8%\" valign=\"top\"><font face=monaco size=2>", NO_ENC, 0))
							goto out;
						if (flags & kCostant)
							err = BufferAddCString(replyID, kConstCStr, NO_ENC, 0);
						else
							err = BufferAddCString(replyID, kVarCStr, NO_ENC, 0);
						if (err)
							goto out;
						// class
						if (err = BufferAddCString(replyID, "</font></td><td width=\"15%\" valign=\"top\"><font face=monaco size=2>", NO_ENC, 0))
							goto out;
						if (err = BAPI_NameFromClassID(api_data, tObj.classID, className))
						{	CEquStr(className, "<blink><b>unknown</b><blink>");
							err = noErr;
							isLocal = true;
						}
						else // no doc url if it is local
							isLocal = IS_LOCAL(tObj.classID);
						if (*docUrl && NOT(isLocal))
						{	if (err = BufferAddCString(replyID, docUrl, NO_ENC, 0))
								goto out;
							if (err = BufferAddCString(replyID, className, URL_ENC, 0))
								goto out;
							if (err = BufferAddCString(replyID, "\" TARGET=\"_new\">", NO_ENC, 0))
								goto out;
						}
						if (tObj.classID < 0)
						{	CStr255	aCStr2;
						
							CEquStr(aCStr2, "<I>");
							CAddStr(aCStr2, className);
							CAddStr(aCStr2, "</I>");
							err = BufferAddCString(replyID, aCStr2, NO_ENC, 0);
						}
						else
							err = BufferAddCString(replyID, className, NO_ENC, 0);
						if (err)
							goto out;
						if (*docUrl && isLocal)
						{	if (err = BufferAddCString(replyID, "</A>", NO_ENC, 0))
								goto out;
						}
						if NOT(flags & kHidden)
						{	if (tObj.classID == gsDispatcherData.arrayConstructor)
							{	long	arrayDim, arrClassID;
							
								if NOT(err = BAPI_GetArrayInfo(api_data, OBJREF_P(&tObj), &arrayDim, &arrClassID, nil))
									err = BAPI_NameFromClassID(api_data, arrClassID, tempStr);
								if (err)
								{	BAPI_GetErrDescription(api_data, err, className, nil, nil, nil, nil, 0, nil);
									CEquStr(tempStr, "{error while getting array type: ");
									CAddStr(tempStr, className);
									CAddStr(tempStr, "}");
									err = noErr;
								}
								CEquStr(className, " ");
								CAddStr(className, tempStr);
								CNumToString(arrayDim, tempStr);
								CAddStr(className, "[");
								CAddStr(className, tempStr);
								CAddChar(className, ']');
								err = BufferAddCString(replyID, className, NO_ENC, 0);
							}
							else if (tObj.classID == kStringClassID)
							{	CEquStr(className, " (");
								CNumToString(stringLen, tempStr);
								CAddStr(className, tempStr);
								CAddStr(className, ")");
								err = BufferAddCString(replyID, className, NO_ENC, 0);
							}
						}
						// value
						if (err = BufferAddCString(replyID, "</font></td><td valign=\"top\"><font face=monaco size=2>", NO_ENC, 0))
							goto out;
						if (flags & kHidden)
						{	if (err = BufferAddCString(replyID, kDummyString, NO_ENC, 0))
								goto out;
						}
						else 
						{	if (stringLen)
							{	if (*stringP == ' ')
								{	if (err = BufferAddCString(replyID, "&nbsp;", NO_ENC, 0))
										goto out;
									stringP++;
									stringLen--;
								}
								if (err = BufferAddText(replyID, stringP, stringLen, enc, kTagsVisible+kAlsoCR))
									goto out;
								enc = encodeMode;
							}
							else
							{	if (err = BufferAddCString(replyID, "&nbsp;", NO_ENC, 0))
									goto out;
							}
						}
						if (err = BufferAddCString(replyID, "</font></td></tr>", NO_ENC, 0))
							goto out;
					}
					if (ref)
					{	BAPI_ReleaseBlock(&ref);
						ref = 0;
					}
				}
			}
		}
		bRecP->suspendMsgs = saveSuspendMsgs;
		if (err = BufferAddCString(replyID, "</table><p><p>", NO_ENC, 0))
			goto out;
	}
	
out:
if (err)
	err = _EmergencyErr(api_data, replyID, err, nil, nil);
	
if (ref)
{	BAPI_ReleaseBlock(&ref);
	ref = 0;
}
return err;
}

//===========================================================================================
XErr	AddLiteralToObj(ObjRecord *objRef, ObjRecord *literalObjRefP)
{
XErr	err = noErr;

	switch(OBJ_CLASSID_P(literalObjRefP))
	{
		case kBooleanClassID:
			err = DLM_AddToObj(objRef->list, objRef->id, IMM_P(literalObjRefP), sizeof(Boolean));
			break;
		case kStringClassID:
			err = DLM_AddToObj(objRef->list, objRef->id, IMM_P(literalObjRefP) + 1, IMMLEN_STRLEN_P(literalObjRefP));
			break;
		case kDoubleClassID:
			err = DLM_AddToObj(objRef->list, objRef->id, IMM_P(literalObjRefP), sizeof(double));
			break;
		case kLongClassID:
			err = DLM_AddToObj(objRef->list, objRef->id, IMM_P(literalObjRefP), sizeof(LONGLONG));
			break;
		case kUnsignedClassID:
			err = DLM_AddToObj(objRef->list, objRef->id, IMM_P(literalObjRefP), sizeof(unsigned long));
			break;
		case kIntClassID:
			err = DLM_AddToObj(objRef->list, objRef->id, IMM_P(literalObjRefP), sizeof(long));
			break;
		case kCharClassID:
			CDebugStr("impossible char literal");
			break;
	}

return err;
}

//===========================================================================================
XErr	NewLiteralInList(char *name, DLMRef list, ObjRecord *literalObjRefP, long finalFlags, long *destObjIDP, long atPos)
{
XErr	err = noErr;

	if (finalFlags < 0)
		finalFlags = 0;
	switch(OBJ_CLASSID_P(literalObjRefP))
	{
		case kBooleanClassID:
			*destObjIDP = DLM_NewObjAtPos(list, name, IMM_P(literalObjRefP), sizeof(Boolean), kBooleanClassID, (unsigned short)(finalFlags | kFixedSize), atPos, &err);
			break;
		case kStringClassID:
			*destObjIDP = DLM_NewObjAtPos(list, name, IMM_P(literalObjRefP) + 1, IMMLEN_STRLEN_P(literalObjRefP), kStringClassID, (unsigned short)finalFlags, atPos, &err);
			break;
		case kDoubleClassID:
			*destObjIDP = DLM_NewObjAtPos(list, name, IMM_P(literalObjRefP), sizeof(double), kDoubleClassID, (unsigned short)(finalFlags | kFixedSize), atPos, &err);
			break;
		case kLongClassID:
			*destObjIDP = DLM_NewObjAtPos(list, name, IMM_P(literalObjRefP), sizeof(LONGLONG), kLongClassID, (unsigned short)(finalFlags | kFixedSize), atPos, &err);
			break;
		case kUnsignedClassID:
			*destObjIDP = DLM_NewObjAtPos(list, name, IMM_P(literalObjRefP), sizeof(unsigned long), kUnsignedClassID, (unsigned short)(finalFlags | kFixedSize), atPos, &err);
			break;
		case kIntClassID:
			*destObjIDP = DLM_NewObjAtPos(list, name, IMM_P(literalObjRefP), sizeof(long), kIntClassID, (unsigned short)(finalFlags | kFixedSize), atPos, &err);
			break;
		case kCharClassID:
			CDebugStr("impossible char literal");
			break;
	}

return err;
}

//===========================================================================================
/*XErr	ModifyImmediate(long api_data, ObjRecord *literalObjRefP, ObjRecordP objRecP)
{
XErr	err = noErr;

	switch(OBJ_CLASSID_P(literalObjRefP))
	{
		case kBooleanClassID:
			err = BAPI_ObjToBoolean(api_data, OBJREF_P(objRecP), (Boolean*)IMM_P(literalObjRefP), kImplicitTypeCast);
			break;
		case kStringClassID:
			CDebugStr("ModifyImmediate: non doveva mai succedere");
			break;
		case kDoubleClassID:
			err = BAPI_ObjToDouble(api_data, OBJREF_P(objRecP), (double*)IMM_P(literalObjRefP), kImplicitTypeCast);
			break;
		case kLongClassID:
			err = BAPI_ObjToLong(api_data, OBJREF_P(objRecP), (long long*)IMM_P(literalObjRefP), kImplicitTypeCast);
			break;
		case kUnsignedClassID:
			err = BAPI_ObjToUnsigned(api_data, OBJREF_P(objRecP), (unsigned long*)IMM_P(literalObjRefP), kImplicitTypeCast);
			break;
		case kIntClassID:
			err = BAPI_ObjToInt(api_data, OBJREF_P(objRecP), (long*)IMM_P(literalObjRefP), kImplicitTypeCast);
			break;
		case kCharClassID:
			CDebugStr("impossible char literal");
			break;
	}

return err;
}*/

//===========================================================================================
void	LiteralToDLMBuffer(ObjRecord *literalObjRefP, DLMBuffer *dlmBufferP)
{
	switch(OBJ_CLASSID_P(literalObjRefP))
	{
		case kBooleanClassID:
			dlmBufferP->bufferP = IMM_P(literalObjRefP);
			dlmBufferP->bufferLen = sizeof(Boolean);
			dlmBufferP->userData = kBooleanClassID;
			dlmBufferP->flags = kFixedSize;
			break;
		case kStringClassID:
			dlmBufferP->bufferP = IMM_P(literalObjRefP) + 1;
			dlmBufferP->bufferLen = IMMLEN_STRLEN_P(literalObjRefP);
			dlmBufferP->userData = kStringClassID;
			dlmBufferP->flags = 0;
			break;
		case kDoubleClassID:
			dlmBufferP->bufferP = IMM_P(literalObjRefP);
			dlmBufferP->bufferLen = sizeof(double);
			dlmBufferP->userData = kDoubleClassID;
			dlmBufferP->flags = kFixedSize;
			break;
		case kLongClassID:
			dlmBufferP->bufferP = IMM_P(literalObjRefP);
			dlmBufferP->bufferLen = sizeof(LONGLONG);
			dlmBufferP->userData = kLongClassID;
			dlmBufferP->flags = kFixedSize;
			break;
		case kUnsignedClassID:
			dlmBufferP->bufferP = IMM_P(literalObjRefP);
			dlmBufferP->bufferLen = sizeof(unsigned long);
			dlmBufferP->userData = kUnsignedClassID;
			dlmBufferP->flags = kFixedSize;
			break;
		case kIntClassID:
			dlmBufferP->bufferP = IMM_P(literalObjRefP);
			dlmBufferP->bufferLen = sizeof(long);
			dlmBufferP->userData = kIntClassID;
			dlmBufferP->flags = kFixedSize;
			break;
		case kCharClassID:
			CDebugStr("impossible char literal");
			break;
	}
}

//===========================================================================================
XErr	CloneObject(long api_data, ObjRecord *sourceObjVarP, char *name, DLMRef list, long theScope, long requestedClassID, long arrayElemRequestedClassID, Boolean wantConst, Boolean wantFixed, long *destIDP, ArraySpecs *arSpecP, Boolean cloneTarget)
{
BifernoRecP		bRecP = (BifernoRecP)api_data;
long			/*arrayDim, */arrayElemClassID, destID;
unsigned short	flags;
ObjRecord		clonedObjRef;
XErr			err = noErr;
ParameterRec	param;
Boolean			isImmediate = IS_IMMEDIATE_P(sourceObjVarP);
unsigned short	newObjFlags;
//ObjRecord		tObjRef;
ArraySpecs		arSpec;

	INVAL(clonedObjRef);
	if (arSpecP)
		ClearBlock(arSpecP, sizeof(ArraySpecs));
	if NOT(err = GetFinalObjFlag(api_data, sourceObjVarP, wantConst, wantFixed, &newObjFlags))
	{	if (requestedClassID && (requestedClassID != sourceObjVarP->classID))
		{	if (sourceObjVarP->classID)
			{	if NOT(err = BAPI_TypeCast(api_data, OBJREF_P(sourceObjVarP), requestedClassID, OBJREF_P(&clonedObjRef), kImplicitTypeCast))
				{	if IS_IMMEDIATE(clonedObjRef)
						err = NewLiteralInList(name, list, &clonedObjRef, newObjFlags, &destID, 0);
					else
					{	if NOT(err = DLM_CopyObj(clonedObjRef.list, clonedObjRef.id, list, name, newObjFlags, &destID))
							err = DLM_TurnOnFlag(clonedObjRef.list, clonedObjRef.id, kNoDestructor, kDLMElements);
					}
				}
			}
			else
			{	if NOT(err = CreateEmptyObject(api_data, name, list, theScope, requestedClassID, 0, 0, newObjFlags, false, &clonedObjRef))
					destID = clonedObjRef.id;
			}
		}
		else
		{	if (isImmediate)
				err = NewLiteralInList(name, list, sourceObjVarP, newObjFlags, &destID, 0);
			else
			{	if (DLM_IsArray(sourceObjVarP->list, sourceObjVarP->id))
				{	// "while" aggiunto 12/9/2002 per clone di array multidim
					/*tObjRef = *sourceObjVarP;
					do {
						if NOT(err = BAPI_GetArrayInfo(api_data, OBJREF_P(&tObjRef), &arrayDim, &arrayElemClassID))
						{	if ((arrayElemClassID == gsDispatcherData.arrayConstructor) && arrayDim)
								err = BAPI_ElementOfArray(api_data, OBJREF_P(&tObjRef), 1, OBJREF_P(&tObjRef));
							else
								break;
						}
					} while NOT(err);
					if NOT(err)*/
					if NOT(err = GetArraySpecs(api_data, sourceObjVarP, &arSpec))
					{	if (arSpecP)
							*arSpecP = arSpec;
						arrayElemClassID = arSpec.arrayElemClassID;
						if (arrayElemClassID && arrayElemRequestedClassID && (arrayElemRequestedClassID != arrayElemClassID))
						{	BAPI_ClearParameterRec(api_data, &param);
							param.objRef = OBJREF(*sourceObjVarP);
							if NOT(err = CL_Clone(api_data, TEMP, VARIABLE, nil, sourceObjVarP->classID, &param, 1, arrayElemRequestedClassID, cloneTarget, &clonedObjRef))
							{	if NOT(err = DLM_CopyObj(clonedObjRef.list, clonedObjRef.id, list, name, newObjFlags, &destID))
									err = DLM_TurnOnFlag(clonedObjRef.list, clonedObjRef.id, kNoDestructor, kDLMElements);
							}
						}
						else
							goto normal;
					}
				}
				else
				{	
				normal:
					if (sourceObjVarP->list == bRecP->volatileList)
					{	if NOT(err = DLM_GetInfo(sourceObjVarP->list, sourceObjVarP->id, &flags, nil, nil))
						{	if (flags & kNoDestructor)
							{	// someone already made this (for example the folder.Walk calls NoDestr on the 4th param to cause it to be cloned here)
								BAPI_ClearParameterRec(api_data, &param);
								param.objRef = OBJREF(*sourceObjVarP);
								err = CL_Clone(api_data, TEMP, VARIABLE, nil, sourceObjVarP->classID, &param, 1, arrayElemRequestedClassID, cloneTarget, &clonedObjRef);
							}
							else
								clonedObjRef = *sourceObjVarP;
							if NOT(err)
							{	if NOT(err = DLM_CopyObj(clonedObjRef.list, clonedObjRef.id, list, name, newObjFlags, &destID))
									err = DLM_TurnOnFlag(clonedObjRef.list, clonedObjRef.id, kNoDestructor, kDLMElements);
							}
						}
					}
					else
					{	BAPI_ClearParameterRec(api_data, &param);
						param.objRef = OBJREF(*sourceObjVarP);
						if NOT(err = CL_Clone(api_data, TEMP, VARIABLE, nil, sourceObjVarP->classID, &param, 1, arrayElemRequestedClassID, cloneTarget, &clonedObjRef))
						{	if NOT(err = DLM_CopyObj(clonedObjRef.list, clonedObjRef.id, list, name, newObjFlags, &destID))
								err = DLM_TurnOnFlag(clonedObjRef.list, clonedObjRef.id, kNoDestructor, kDLMElements);
						}
					}
				}
			}
		}
	}
	if (NOT(err) && destIDP)
		*destIDP = destID;

return err;
}

//===========================================================================================
XErr	ResolveArryItem(long api_data, Ptr *textPPtr, long *lenP, ObjRecordP leftObjVarP, ArrayIndexRec *mCoordsP, long *dimP, Boolean fromInput, BlockRef *mCoordsBlockP, long *arrayElemReqClassIDP)
{
XErr		err = noErr;
Ptr			textP = *textPPtr;
long		arrayElementClass, len = *lenP, dim;
Boolean		toContinue;
int			k;
BifernoRecP	bRunP;

	if ((len && (*textP == '[')) || (fromInput && (Begins(textP, len, "%5B", 3))))
	{	BlockRef		mCoordsBlock;
		ArrayIndexRec	*mCoords;
		
		if NOT(bRunP = (BifernoRecP)api_data)
			return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
		toContinue = true;
		k = 0;
		if (mCoordsBlock = NewBlockLocked(sizeof(ArrayIndexRec) * MAX_ARRAYINDEX, &err, (Ptr*)&mCoords))
		{	//LockBlock(mCoordsBlock);
			//mCoords = (ArrayIndexRec*)GetPtr(mCoordsBlock);
			ClearBlock(mCoords, sizeof(short) * MAX_ARRAYINDEX);
			while(toContinue && NOT(err))
			{	if NOT(err = _GetArrayIndex(api_data, &textP, &len, &mCoords[k], &toContinue, fromInput))
				{	if COMPILING(api_data)
					{	if (toContinue)
							err = BIC_LoadParam(api_data, (ObjRecordP)&mCoords[k]);
					}
					if (k > MAX_ARRAYINDEX)
						err = XError(kBAPI_Error, Err_ArrayRequired);
					else if (toContinue)
						k++;
				}
			}
			dim = k;
			if COMPILING(api_data)
			{	//if NOT(err)
				//	err = BIC_Index(api_data, leftObjVarP, mCoords, dim, leftObjVarP);
				// DisposeBlock(&mCoordsBlock);
				if (mCoordsBlockP)
					*mCoordsBlockP = mCoordsBlock;
				if (dimP)
					*dimP = dim;
			}
			else
			{	if NOT(err)
				{	if (dim && leftObjVarP)
					{	
					ObjRef	tempObjRef;
					
						INVAL(tempObjRef);
						if NOT(err = ResolveArrayElement(api_data, OBJREF_P(leftObjVarP), mCoords, (short)dim, nil, nil, nil, &tempObjRef, &arrayElementClass))
							*leftObjVarP = *(ObjRecordP)&tempObjRef;
					}
					else
					{	if (mCoordsBlockP)
							*mCoordsBlockP = 0;
					}
				}
				if ((err == XError(kBAPI_Error, Err_OutOfBoundary)) && leftObjVarP)
				{	
				ObjRecord	theArrayObj, *objP;
				
					bRunP->outOfBoundary = true;
					if (mCoordsBlockP)
						*mCoordsBlockP = mCoordsBlock;
					if (dimP)
						*dimP = dim;
					if (mCoordsP)
						mCoordsP = nil;
					if (leftObjVarP->classID == gsDispatcherData.refConstructor)
					{	if NOT(err = ref_GetTarget(api_data, (ObjRefP)leftObjVarP, (ObjRefP)&theArrayObj, true))
							objP = &theArrayObj;
					}
					else
						objP = leftObjVarP;
					if NOT(err = DLM_GetArrayInfo(objP->list, objP->id, nil, nil, nil, &objP->classID))
					{	if ((objP->classID == gsDispatcherData.arrayConstructor) && (dim > 1))
						{	ObjRecord			tObRef;
		
							tObRef = *objP;
							if NOT(err = ResolveArrayElement(api_data, OBJREF_P(&tObRef), mCoords, (short)(dim-1), nil, nil, nil, OBJREF_P(&tObRef), nil))
							{	if NOT(err = DLM_GetArrayInfo(tObRef.list, tObRef.id, nil, nil, nil, &tObRef.classID))
								{	if (tObRef.classID != gsDispatcherData.arrayConstructor)
										objP->classID = tObRef.classID;
								}
							}
							if (err == XError(kBAPI_Error, Err_OutOfBoundary))
							{	objP->classID = 0;	// a new array
								err = noErr;
							}
						}
						if (NOT(err) && arrayElemReqClassIDP)
							*arrayElemReqClassIDP = objP->classID;
					}
				}
				else
				{	if (mCoordsP)
						CopyBlock(mCoordsP, mCoords, dim * sizeof(ArrayIndexRec));
					if (dimP)
						*dimP = dim;
					DisposeBlock(&mCoordsBlock);
					if (mCoordsBlockP)
						*mCoordsBlockP = nil;
					if NOT(err)
					{	if (leftObjVarP)
						{	if NOT(leftObjVarP->classID)	// element of array undefined
								leftObjVarP->classID = arrayElementClass;	// for requestedType of Evaluate
						}
					}
				}
			}
		}
	}
	else
	{	dim = 0;
		if (dimP)
			*dimP = 0;
	}


*textPPtr = textP;
*lenP = len;
return err;
}

//===========================================================================================
long		LookForObj(long api_data, char *varName, long *varListP, long *varTypeP, long *classIDP, long *scopeP, XErr *errP)
{
long			objID = 0, flags = 0;	
BifernoRecP 	bRunP = (BifernoRecP)api_data;
XErr			err = noErr;
long			classID, varType, scope;

	if (varTypeP)
		varType = *varTypeP;
	else
		varType = 0;
	if (scopeP)
		scope = *scopeP;
	else
		scope = 0;
	classID = 0;
	
	// In Functions and methods (and class properties) vars are local if not specified by user
	if (bRunP && (bRunP->loadingClass || bRunP->currentCtx.methodInExecutionID))
	{	if NOT(*varListP)
		{	*varListP = bRunP->localList;
			scope = LOCAL;
		}
	}
	
	if (*varListP)
		objID = DLM_GetObjID(*varListP, varName, &flags, &classID);
	else if (bRunP)
	{	if (objID = DLM_GetObjID(bRunP->localList, varName, &flags, &classID))
		{	*varListP = bRunP->localList;
			scope = LOCAL;
		}
		else if (objID = DLM_GetObjID(bRunP->globalList, varName, &flags, &classID))
		{	*varListP = bRunP->globalList;
			scope = GLOBAL;
		}
		else if (objID = DLM_GetObjID(bRunP->application.list, varName, &flags, &classID))
		{	*varListP = bRunP->application.list;
			scope = APPLICATION;
		}
		else if (bRunP->sessionList && (objID = DLM_GetObjID(bRunP->sessionList, varName, &flags, &classID)))
		{	*varListP = bRunP->sessionList;
			scope = SESSION;
		}
		else if (objID = DLM_GetObjID(bRunP->application.persistentList, varName, &flags, &classID))
		{	*varListP = bRunP->application.persistentList;
			scope = PERSISTENT;
		}
	}
	
	if (objID > 0)
	{	if (varType)
		{	if ((varType == VARIABLE) && (flags & kCostant))
			{	if (classID)
				{	err = XError(kBAPI_Error, Err_BadSyntax); //ex objID = 0;
					NewMsgRecord(api_data, kADVICE, "The referenced entity is not of type var", 0, 0);
				}
				else // was undef
					err = DLM_TurnOffFlag(*varListP, objID, kCostant, kDLMWhole);
			}
			if ((varType == CONSTANT) && !(flags & kCostant))
			{	if (classID)
				{	err = XError(kBAPI_Error, Err_BadSyntax); //ex objID = 0;
					NewMsgRecord(api_data, kADVICE, "The referenced entity is not of type const", 0, 0);
				}
				else // was undef
					err = DLM_TurnOnFlag(*varListP, objID, kCostant, kDLMWhole);
			}
		}
		else
		{	if (flags & kCostant)
				varType = CONSTANT;
			else
				varType = VARIABLE;
		}
	}
	if (err)
	{	if (errP)
			*errP = err;
		objID = 0;
	}
	else
	{	if (classIDP)
			*classIDP = classID;
		if (scopeP)
			*scopeP = scope;
		if (varTypeP)
			*varTypeP = varType;
	}
	
return objID;
}

//===========================================================================================
// session const a = "pippo"
XErr		GetScopeAndType(long api_data, Ptr *oldFilePPtr, long *lenP, DLMRef *varListP, long *typeP, long *scopeP, char *theName)
{
Ptr				tempP;
long			len;	
BifernoRec		*bRecP;
long			objID, type, scope, aLong;
XErr			err = noErr;
Boolean			doneType = false, doneScope = false;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	tempP = *oldFilePPtr;
	len = *lenP;

	// defaults
	type = scope = 0;
	*scopeP = 0;
	*typeP = 0;
	while ((len > 0) && NOT(err))
	{	SkipSpaceAndTab(&tempP, &len/*, &bRecP->currentCtx.currentLine*/);
		if NOT(err = GetEntityName(api_data, &tempP, &len, theName, false))
		{	objID = DLM_GetObjID(gsDispatcherData.reservedKeyword, theName, nil, &aLong);
			if (objID)
			{	switch(aLong)
				{	case VARIABLE:
					case CONSTANT:
						if (doneType)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	type = aLong;
							doneType = true;
						}
						break;
					case TEMP:
					case LOCAL:
					case GLOBAL:
						if (doneScope)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	scope = aLong;
							doneScope = true;
						}
						break;
					case APPLICATION:
					case SESSION:
					case PERSISTENT:
						if (doneScope)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	if (bRecP->objRefInDestruction.id)
								return XError(kBAPI_Error, Err_NotAllowedInDestructor);
							scope = aLong;
							doneScope = true;
						}
						break;
					default:
						goto endWhile;
				}
			}
			else
				break;
		}
	};
endWhile:
	if NOT(err)
	{	if (scope)
		{	*scopeP = scope;
			err = GetVariableList(api_data, scope, varListP, false, 0);
		}
		if (type)
			*typeP = type;
	}
	else if ((err == XError(kBAPI_Error, Err_EmptyName)) && (scope || type))
		err = XError(kBAPI_Error, Err_ReservedKeyword/*Err_BadSyntax*/);
	
*oldFilePPtr = tempP;
*lenP = len;
return err;
}

//===========================================================================================
/*static void	DumpObjRef(ObjRecord *objRefP, XErr (*logFunc)(long userData, char *string), long userData)
{
CStr255		aCSTR, tStr;

	CEquStr(aCSTR, "Buffer => ");
	
	CAddStr(aCSTR, " id: ");
	CNumToString(objRefP->id, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " list: ");
	CNumToString(objRefP->list, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " classID: ");
	CNumToString(objRefP->classID, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " scope: ");
	CNumToString(objRefP->scope, tStr);
	CAddStr(aCSTR, tStr);

	CAddStr(aCSTR, " type: ");
	CNumToString(objRefP->type, tStr);
	CAddStr(aCSTR, tStr);

	logFunc(userData, aCSTR);
}*/


//===========================================================================================
XErr	GetVariableList(long api_data, long scope, DLMRef *listIDP, Boolean noError, int stackIndex)
{
long			listID = 0;
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
	
	switch(scope)
	{	case TEMP:
			if (api_data)
				listID = bRecP->volatileList;
			break;
		case LOCAL:
			if (api_data)
			{	if (stackIndex)
				{	if (stackIndex < 0)
						err = XError(kBAPI_Error, Err_InvalidScope);
					else
						listID = BfrGetIndStackList((BifernoRecP)api_data, stackIndex);
				}
				else
					listID = bRecP->localList;
			}
			break;
		case GLOBAL:
			if (api_data)
				listID = bRecP->globalList;
			break;
		case APPLICATION:
			if (api_data)
				listID = bRecP->application.list;
			break;
		case SESSION:
			if (api_data && bRecP->sessionList)
				listID = bRecP->sessionList;
			else
			{	err = XError(kBAPI_Error, Err_SessionIsDisabled);
				if ((bRecP->currentCtx.defaultScope == APPLICATION) && NOT(noError))
					NewMsgRecord(api_data, kADVICE, "Session variables cannot be used in the Biferno config run", 0, 0);
			}
			break;
		case PERSISTENT:
			if (api_data && bRecP->application.persistentList)
				listID = bRecP->application.persistentList;
			break;
		default:
			break;
	}
	if not(listID)
		err = XError(kBAPI_Error, Err_InvalidScope);

*listIDP = listID;
return err;
}

//===========================================================================================
static long	_IfRefClass(long api_data, ObjRecordP objP)
{
long	res;

	if (objP->classID == gsDispatcherData.refConstructor)
		ref_GetTargetClass(api_data, (ObjRefP)objP, &res, true);
	else
		res = objP->classID;

return res;
}

//===========================================================================================
XErr	MemberLoop(long api_data, Ptr *oldFilePtrP, long *oldFileLenP, MemberLoopCallRecord *memberLoopP, Boolean fromTryCurrent, long *totLoopsP, Boolean gettingReference)
{
Ptr						tempP;
long					t, propListTotItems, totParams, len;
XErr					err = noErr;
ParameterRec			*paramVarsP;
Boolean					recursive, needGetProperty, needToRegister, compilerAnyway;
BifernoRec				*bRecP;
BlockRef	 			membIdentBlock;
PropertyItem			*propertyItemP;
PropertyListRec 		*propertyList;
MemberAction 			*membActionP;

	bRecP = (BifernoRec*)api_data;
	tempP = *oldFilePtrP;
	len = *oldFileLenP;
	membIdentBlock = 0;
	*memberLoopP->memberName = 0;
	if (_GetClassMember(api_data, memberLoopP->varRecP, &tempP, &len, memberLoopP->varRecP->classID, &membIdentBlock, &membActionP, memberLoopP->dontCheckPeriod, memberLoopP->notifyP, fromTryCurrent, gettingReference, &err))
	{	if NOT(err)
		{	if (totLoopsP)
				(*totLoopsP)++;
			if (memberLoopP->memberName)
				CEquStr(memberLoopP->memberName, membActionP->doc.name);
			if (NOT(gettingReference) && NOT(memberLoopP->varRecP->id) && NOT(membActionP->doc.isStatic))
			{	if (DLM_GetObjID(gsDispatcherData.reservedKeyword, membActionP->doc.name, nil, nil))
					err = XError(kBAPI_Error, Err_ReservedKeyword);
				else
					err = XError(kBAPI_Error, Err_UndefinedIdentifier);
			}
			else
			{	recursive = true;
				if (((t = membActionP->doc.type) == kProperty) || (t == kConstant) || (t == kError))
				{	BlockRef		propertyIDXBlockRef = 0;
					ArrayIndexRec	*propertyIDXP;
					Boolean			disposePropIndex = false;
					long			memArLevel, propertyDim = 0;
					
					if ((memberLoopP->flags & kInCase) && (NOT(membActionP->doc.isStatic) || NOT(membActionP->doc.info.property.isConst)))
						err = XError(kBAPI_Error, Err_IllegalConstantExpression);
					else
					{	if (memArLevel = membActionP->doc.returnAeLevel)
						{	if (propertyIDXBlockRef = NewPtrBlock(sizeof(ArrayIndexRec) * memArLevel, &err, (Ptr*)&propertyIDXP))
							{	disposePropIndex = true;
								_ClearArrayIndexRec(propertyIDXP, memArLevel);
								if NOT(err = _GetPropertyIndex(api_data, &tempP, &len, propertyIDXP, &propertyDim, memArLevel))
								{	if (propertyDim > memArLevel)
										err = XError(kBAPI_Error, Err_ArrayRequired);
								}
							}
						}
						else
						{	if (len && (*tempP == '['))
								err = XError(kBAPI_Error, Err_ArrayRequired);
							else
							{	propertyIDXP = nil;
								propertyIDXBlockRef = propertyDim = 0;
							}
						}
						if NOT(err)
						{	/* We have to register all the properties in a "PropertyListRec" for two reasons:
								1 To do later the SetProperties (in reverse order, see "_DoIncrement" and "_DoAssignment") or
								2 If later it will appear a method with side effect (see later in this func)
							*/
							/*	if we are at first property (NOT(propertyList)) we don't need to do GetProperty only if:	
									follow assignment	->	it is a simple SetProperty
							*/
							needGetProperty = true;
							needToRegister = true;
							propListTotItems = 0;
							compilerAnyway = false;
							if (memberLoopP->propListBlockP && *memberLoopP->propListBlockP)
								propertyList = (PropertyListRec*)GetPtr(*memberLoopP->propListBlockP);
							else
								propertyList = nil;
							if COMPILING(api_data)
							{	if (len && (*tempP == '.'))
									compilerAnyway = true;	// multiple -> need all
							}
							else
							{	if (len && (*tempP == '.'))
									compilerAnyway = true;	// multiple -> need all
								else	// single -> need to register if is SetProperty, needGetProperty if it is NOT a SetProperty (but need if +=, -= etc)
								{	recursive = false;
									if (*memberLoopP->assignmentTypeP == -1)
										err = _GetAssignmentType(bRecP, &tempP, &len, memberLoopP->incrTypeP, memberLoopP->assignmentTypeP, memberLoopP->isFunction, 1, *memberLoopP->appearsOneMethodP, (Boolean)((membActionP->objRef.id != 0) || membActionP->doc.isStatic));
									if NOT(err)
									{	if (*memberLoopP->assignmentTypeP == ASSIGN)			// SetProperty with '='
										{	// needToRegister remain to true;
											// Note:
											//  if property is of array type (memArLevel==AE_LEVEL_LIMIT) and propertyDim!=0 (myProp[XX])
											//  GetProperty is needed to know the requested type (needGetProperty remains true)
											if (NOT(propertyDim) || (memArLevel != AE_LEVEL_LIMIT))
												needGetProperty = false;
										}
										else if NOT(*memberLoopP->assignmentTypeP)			// is not a SetProperty
										{	// needGetProperty remain to true;
											if (NOT(*memberLoopP->incrTypeP) && NOT(gettingReference))
												needToRegister = false;
										}
									}
								}
							}
							if NOT(err)
							{	if (needToRegister && memberLoopP->propListBlockP)	// -> N.B. can't be a setProperty after a method
								{	if NOT(err = _AddToPropertyList(memberLoopP->propListBlockP))
									{	propertyList = (PropertyListRec*)GetPtr(*memberLoopP->propListBlockP);	// reload
										propertyItemP = &propertyList->item[propertyList->totItems-1];
										CopyBlock(&propertyItemP->membIdent, membActionP, sizeof(MemberAction) - sizeof(BAPI_Doc) + membActionP->doc.len);
										propListTotItems = propertyList->totItems;
										propertyItemP->propertyDim = propertyDim;
										if (propertyDim)
										{
											propertyItemP->propertyIDXPtr = propertyIDXP;
											propertyItemP->propertyIDXBlockRef = propertyIDXBlockRef;
											disposePropIndex = false;	// Dispose it later
										}
										else
										{
											propertyItemP->propertyIDXPtr = nil;
											propertyItemP->propertyIDXBlockRef = 0;
											if (propertyIDXBlockRef)
												disposePropIndex = true;	// Dispose it now
										}
									}
								}
								else
									propListTotItems = 0;
								if NOT(err)
								{	if (needGetProperty)
									{	if COMPILING(api_data)
											err = BIC_GetProperty(api_data, membActionP, propertyDim, propertyIDXP, *memberLoopP->assignmentTypeP, memberLoopP->varRecP, compilerAnyway);
										else
											err = CL_GetProperty(api_data, membActionP, propertyDim, propertyIDXP, memberLoopP->varRecP);
										if NOT(err)
										{	// there could be a multiple set property on result of GetProperty
											if (NOT(COMPILING(api_data)) && (propListTotItems > 1))
												err = _ConstToVar(bRecP, &propertyItemP->membIdent.objRef);
										}
									}
									else
									{	memberLoopP->varRecP->list = memberLoopP->varRecP->id = 0;
										if (memArLevel && (memArLevel == propertyDim))
											memberLoopP->varRecP->classID = membActionP->doc.returnAeClass;	//membIdent.memberArrayElementClassID;
										else
											memberLoopP->varRecP->classID = membActionP->doc.returnClassID; // membIdent.memberClassID;	// for requestedType later
									}
								}
							}
						}
					}
					if (disposePropIndex)
						DisposeBlock(&propertyIDXBlockRef);
				}
				else
				{	SkipSpaceAndTab(&tempP, &len);
					if (gettingReference)
						err = XError(kBAPI_Error, Err_BadSyntax);
					else if ((*memberLoopP->incrTypeP == kPreIncrem) || (*memberLoopP->incrTypeP == kPostIncrem))
					{	//NewMsgRecord(api_data, kMETHOD, membActionP->doc.name, 0, 0);
						err = XError(kBAPI_Error, Err_IllegalOperationOnMethod);			// I metodi non hanno pre incremento
					}
					else if (NOT(len) || (len && (*tempP != '(')))
					{	//NewMsgRecord(api_data, kMETHOD, membActionP->doc.name, 0, 0);
						err = XError(kBAPI_Error, Err_RoundBracketExpected);	// deve seguire '('
					}
					else
					{	ObjRecord	resultRec;
						long		totProperties;
						Boolean		sideEffect;
						long		paramVarsBuffID;
						
						if (gettingReference)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else if (memberLoopP->flags & kInCase)
							err = XError(kBAPI_Error, Err_IllegalConstantExpression);
						else
						{	paramVarsBuffID = 0;
							if NOT(err)
							{	if NOT(err = GetFunctionParametersSmart(bRecP, _IfRefClass(api_data, memberLoopP->varRecP), &tempP, &len, &paramVarsBuffID, &paramVarsP, &totParams, &membActionP->doc))
								{	err = CL_ExecuteMethod(api_data, membActionP, paramVarsP, totParams, &resultRec, &sideEffect);
									BufferFree(paramVarsBuffID);
								}
							}
							// side effect sulle (eventuali) precedenti propriet�
							if NOT(err)
							{	if (memberLoopP->propListBlockP && *memberLoopP->propListBlockP)
									propertyList = (PropertyListRec*)GetPtr(*memberLoopP->propListBlockP);
								else
									propertyList = nil;
								if (sideEffect && propertyList && (totProperties = propertyList->totItems))
								{	if (*memberLoopP->appearsOneMethodP)
										err = XError(kBAPI_Error, Err_IllegalOperationOnMethod);
									else
									{	
									long		i;
									ObjRecord	rightObjVar;
									Boolean		putResultOnStack;
										
										rightObjVar = *memberLoopP->varRecP;
										LockBlock(*memberLoopP->propListBlockP);
										propertyItemP = &propertyList->item[totProperties-1];
										for (i = (totProperties-1); (i >= 0) && NOT(err); i--, propertyItemP--)		// right to left!
										{	
											if (NOT(COMPILING(api_data)) && (rightObjVar.scope != TEMP))
											{	ParameterRec	param;
												ObjRecord		tObjRef;
												
												param.objRef = OBJREF(rightObjVar);
												INVAL(tObjRef);
												if NOT(err = CL_Clone(api_data, TEMP, rightObjVar.type, nil, rightObjVar.classID, &param, 1, 0, true, &tObjRef))
													rightObjVar = tObjRef;
											}			
											if NOT(err)
											{	if COMPILING(api_data)
												{	putResultOnStack = false;
													err = BIC_SetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyIDXPtr, propertyItemP->propertyDim, &rightObjVar, putResultOnStack);
												}
												else
													err = CL_SetProperty(api_data, &propertyItemP->membIdent, propertyItemP->propertyDim, propertyItemP->propertyIDXPtr, &rightObjVar);
												if (err)
													NewMsgRecord(api_data, kSETPROPERTY, propertyItemP->membIdent.doc.name, 0, 0);
												else
													rightObjVar = propertyItemP->membIdent.objRef;
											}
										}
										if (NOT(err) && memberLoopP->notifyP && *memberLoopP->notifyP)
											(*memberLoopP->notifyP)->toNotify = true;
										UnlockBlock(*memberLoopP->propListBlockP);
									}
								}
								*memberLoopP->varRecP = resultRec;
								*memberLoopP->appearsOneMethodP = true;
							}
						}
					}
				}
				if (NOT(err) && recursive)
				{	memberLoopP->dontCheckPeriod = false;
					err = MemberLoop(api_data, &tempP, &len, memberLoopP, false, totLoopsP, gettingReference);
				}
			}
			if (membIdentBlock)
				DisposeBlock(&membIdentBlock);
			else
				PoolDisposePtr(gsDispatcherData.propertyActionPool, membActionP->slot);
		}
	}
	
*oldFilePtrP = tempP;
*oldFileLenP = len;
return err;
}

//===========================================================================================
static XErr	_ProcessObject(long api_data, Ptr *oldFilePtrP, long *oldFileLenP, ProcessObjectCallRecord *processObjectP, long typeCastType, Boolean entityWasFound, Boolean gettingReference, long arrayElemReqClassID/*, Boolean *setErrMsgP*/)
{	
XErr					err = noErr;
Ptr						textP;
long					len;
Boolean					defined, found, appearsOneMethod, outOfBoundary;
ObjRecord				rightObjVar;
long					saveLeftMemberClass;
BifernoRecP				bRecP = (BifernoRecP)api_data;
PropertyListRec			*propertyList;
long					totProperties;
BlockRef				propListBlock;
uint32_t				slot;
MemberLoopCallRecord	*membLoopP;
BAPI_ModifyHook			modCB = (BAPI_ModifyHook)0L;
Boolean					getRef = false;
ObjRecord				*resP, tempObj;

	textP = *oldFilePtrP;
	len = *oldFileLenP;
	
	// Class elements (metodo o propriet�)
	if (processObjectP->appearsOneMethodP)
		appearsOneMethod = *processObjectP->appearsOneMethodP;
	else
		appearsOneMethod = false;
	SkipSpaceAndTab(&textP, &len);
	appearsOneMethod = outOfBoundary = false;
	found = (processObjectP->leftObjVarP->id != 0);
	defined = (processObjectP->leftObjVarP->classID != 0) || COMPILING(api_data);
	if (processObjectP->rightValue)
		*processObjectP->assignmentTypeP = ASSIGN;	// anyway

	if (gettingReference && VALID_P(processObjectP->leftObjVarP))
	{	getRef = true;
		*processObjectP->result = *processObjectP->leftObjVarP;
	}
	if (processObjectP->propListBlockP)
	{	if NOT(*processObjectP->propListBlockP)					// _TryMemberOfCurrent could have already allocated it
		{	if NOT(err = PoolNewPtr(gsDispatcherData.memberLoopPool, (Ptr*)&membLoopP, &slot))
			{	membLoopP->varRecP = processObjectP->leftObjVarP; 
				membLoopP->incrTypeP = processObjectP->incrTypeP; 
				membLoopP->assignmentTypeP = processObjectP->assignmentTypeP; 
				membLoopP->appearsOneMethodP = &appearsOneMethod; 
				membLoopP->propListBlockP = processObjectP->propListBlockP; 
				membLoopP->isFunction = processObjectP->isFunction;  
				membLoopP->dontCheckPeriod = false; 
				membLoopP->notifyP = processObjectP->notifyP; 
				membLoopP->flags = processObjectP->flags; 
				if (err = MemberLoop(api_data, &textP, &len, membLoopP, false, nil, gettingReference))
				{	//NewMsgRecord(api_data, kMEMBER, membLoopP->memberName, 0, kOnlyIfEmpty);
					//if NOT(*bRecP->errMessage)
					//	CStringToErrMessage(api_data, membLoopP->memberName);
				}
				PoolDisposePtr(gsDispatcherData.memberLoopPool, slot);
			}
		}
	}
	if NOT(err)
	{	// Operator or post increment (controlla anche errori tipo: a++ = ... o --a++)
		SkipSpaceAndTab(&textP, &len);
		/*if (gettingReference)
		{	if (len)
				err = XError(kBAPI_Error, Err_BadSyntax);
			goto out;
		}*/
		/*
		if (len && (processObjectP->flags && kStopOnSemicolon) && (*textP == ':'))
		{	*processObjectP->result = *processObjectP->leftObjVarP;
			goto out;
		}
		*/
		if NOT(processObjectP->rightValue)
		{	if (processObjectP->propListBlockP && *processObjectP->propListBlockP)
			{	propertyList = (PropertyListRec*)GetPtr(*processObjectP->propListBlockP);
				totProperties = propertyList->totItems;
			}
			else
				totProperties = 0;
			if (*processObjectP->assignmentTypeP == -1)		// Has not been called by MemberLoop
			{	
			Boolean		isStatic;
			
				if ((totProperties == 1) && propertyList)
					isStatic = propertyList->item[0].membIdent.doc.isStatic;
				else
					isStatic = false;
				err = _GetAssignmentType(bRecP, &textP, &len, processObjectP->incrTypeP, processObjectP->assignmentTypeP, processObjectP->isFunction, totProperties, appearsOneMethod, (Boolean)((processObjectP->leftObjVarP->id != 0) || isStatic));
			}
			if (bRecP->outOfBoundary && ((*processObjectP->assignmentTypeP != ASSIGN) || *processObjectP->incrTypeP))
				outOfBoundary = true;
			//if ((*processObjectP->assignmentTypeP || *processObjectP->incrTypeP) && gettingReference/*(processObjectP->flags & kAddressParameter)*/)
			//	err = XError(kBAPI_Error, Err_BadSyntax);
		}
		if NOT(err)
		{	if (processObjectP->propListBlockP && *processObjectP->propListBlockP)
			{	propListBlock = *processObjectP->propListBlockP;
				propertyList = (PropertyListRec*)GetPtr(propListBlock);
			}
			else
			{	propListBlock = 0;
				propertyList = nil;
			}
			SkipSpaceAndTab(&textP, &len);
			if (NOT(len) && *processObjectP->assignmentTypeP && NOT(processObjectP->rightValue))
				err = XError(kBAPI_Error, Err_BadSyntax);
			if NOT(err)
			{	// Expression
				if COMPILING(api_data)
				{	if (NOT(*processObjectP->assignmentTypeP) && processObjectP->mCoordBlock && processObjectP->mCoordDim)
					{	LockBlock(processObjectP->mCoordBlock);
						err = BIC_Index(api_data, processObjectP->leftObjVarP, (ArrayIndexRec*)GetPtr(processObjectP->mCoordBlock), processObjectP->mCoordDim, processObjectP->leftObjVarP);
						UnlockBlock(processObjectP->mCoordBlock);
						if (err)
							goto out;
					}
				}
				if (*processObjectP->assignmentTypeP && (len || processObjectP->rightValue) && NOT(appearsOneMethod))	// method => no assignment
				{	if (outOfBoundary)
						err = XError(kBAPI_Error, Err_OutOfBoundary);
					else
					{	modCB = GetModifyHook(processObjectP->leftObjVarP->classID);
						if (processObjectP->rightValue)
						{	
						long	reqID, rightID;
						
							reqID = processObjectP->leftObjVarP->classID;
							if (modCB)
								reqID = 0;
							rightID = processObjectP->rightValue->classID;
							if (reqID && (reqID != rightID))
							{	INVAL(rightObjVar);
								err = CoercionToRequestedType(api_data, processObjectP->rightValue, /*nil, */reqID, &rightObjVar, kExplicitTypeCast);
							}
							else
								rightObjVar = *processObjectP->rightValue;
						}
						else
						{	
						Boolean		saveOutOfBoundary;
						long		reqType;
							
							SkipSpaceAndTab(&textP, &len);
							BAPI_InvalObjRef(api_data, OBJREF_P(&rightObjVar));
							if (propertyList && totProperties)
							{	saveLeftMemberClass = bRecP->currentCtx.leftMemberClass;
								bRecP->currentCtx.leftMemberClass = _IfRefClass(api_data, &propertyList->item[0].membIdent.objRef);	// ex propertyList->item[0].membIdent.objRef.classID;
							}
							saveOutOfBoundary = bRecP->outOfBoundary;
							bRecP->outOfBoundary = false;
							if (*processObjectP->assignmentTypeP == ASSIGN)
							{	reqType = processObjectP->leftObjVarP->classID;
								if (modCB)
									reqType = arrayElemReqClassID;
							}
							else
								reqType = 0;		// per += etc... right member can be different (a.secs += 123456789123456789)
							err = Evaluate(api_data, reqType, typeCastType, &textP, &len, nil, &rightObjVar, processObjectP->flags | kNoFlowControl | kInAssignment, processObjectP->numParP, true/*, setErrMsgP*/);
							bRecP->outOfBoundary = saveOutOfBoundary;
							if (totProperties)
								bRecP->currentCtx.leftMemberClass = saveLeftMemberClass;
						}
						if (NOT(err) && NOT(bRecP->currentCtx._stop) && NOT(bRecP->_exit))	// Evaluate could arise stop flags
						{	//if NOT(directAssign)
							{	if COMPILING(api_data)
								{	if (VALID(rightObjVar))
									{	LockBlock(processObjectP->mCoordBlock);
										err = BIC_DoAssignment(api_data, processObjectP->leftObjVarP, processObjectP->varName, *processObjectP->assignmentTypeP, (ArrayIndexRec*)GetPtr(processObjectP->mCoordBlock), processObjectP->mCoordDim, propListBlock, &rightObjVar);
										UnlockBlock(processObjectP->mCoordBlock);
									}
									else
										err = XError(kBAPI_Error, Err_IllegalAssignment);
								}
								else
									err = _DoAssignment(api_data, processObjectP->varName, *processObjectP->assignmentTypeP, &rightObjVar, propListBlock, processObjectP->leftObjVarP, processObjectP->mCoordBlock, processObjectP->mCoordDim, typeCastType, (Boolean)(found && NOT(defined)), modCB);
							}
							if NOT(err)
							{	if NOT(getRef)
									*processObjectP->result = *processObjectP->leftObjVarP;
								if (processObjectP->notifyP && *processObjectP->notifyP)
									(*processObjectP->notifyP)->toNotify = true;
								if (processObjectP->sideEffectIfAssign)
									bRecP->sideEffect = true;
							}
							else
								NewMsgRecord(api_data, kDOING, *oldFilePtrP, *oldFileLenP, 0/*kOnlyIfEmpty*/);
						}
					}
				}
				else if (*processObjectP->incrTypeP)
				{	if (outOfBoundary)
						err = XError(kBAPI_Error, Err_OutOfBoundary);
					else
					{	if (getRef)
							resP = &tempObj;
						else
							resP = processObjectP->result;
						if NOT(err = _DoIncrement(api_data, *processObjectP->incrTypeP, processObjectP->leftObjVarP, propListBlock, processObjectP->mCoordBlock, processObjectP->mCoordDim, resP))
						{	if (processObjectP->notifyP && *processObjectP->notifyP)
								(*processObjectP->notifyP)->toNotify = true;
							if (processObjectP->sideEffectIfAssign)
								bRecP->sideEffect = true;
						}
					}
				}
				else if ((NOT(found) || NOT(defined)) && NOT(processObjectP->staticProperty))
				{	if NOT(entityWasFound)
					{	//ex if (DLM_GetObjID(bRecP->application.classesList, processObjectP->varName, nil, nil) || DLM_GetObjID(gsDispatcherData.classListRef, processObjectP->varName, nil, nil))
						if (GetUserClassID(bRecP, processObjectP->varName) || DLM_GetObjID(gsDispatcherData.classListRef, processObjectP->varName, nil, nil))
							err = XError(kBAPI_Error, Err_BadSyntax);
						else if (len && (*textP == '('))
							err = XError(kBAPI_Error, Err_NoSuchClassOrFunction);
						else
						{	if (processObjectP->isFunction)
								BAPI_InvalObjRef(api_data, OBJREF_P(processObjectP->leftObjVarP));
							else if (found && outOfBoundary)
								err = XError(kBAPI_Error, Err_OutOfBoundary);
							else
								err = XError(kBAPI_Error, Err_UndefinedIdentifier);
						}
					}
				}
				else if (outOfBoundary)
					err = XError(kBAPI_Error, Err_OutOfBoundary);
				else
				{	if NOT(getRef)
						*processObjectP->result = *processObjectP->leftObjVarP;
				}
			}
		}
	}
	/*else
	{	if NOT(*bRecP->errMessage)
			CStringToErrMessage(api_data, memberName);
	}*/
	
out:
*oldFilePtrP = textP;
*oldFileLenP = len;
return err;
}

//===========================================================================================
static void	_ScopeName(long scopeID, char *scopeName)
{
	switch (scopeID)
	{	case TEMP:
			CEquStr(scopeName, "temp");
			break;
		case LOCAL:
			CEquStr(scopeName, "local");
			break;
		case GLOBAL:
			CEquStr(scopeName, "global");
			break;
		case APPLICATION:
			CEquStr(scopeName, "application");
			break;
		case SESSION:
			CEquStr(scopeName, "session");
			break;
		case PERSISTENT:
			CEquStr(scopeName, "persistent");
			break;
		default:
			*scopeName = 0;
			break;
	}
}

//===========================================================================================
static void	_PerhapsToErr(long api_data, char *varName, long scopeID)
{
CStr255		aCStr;
CStr63		scopeName;
	
	//CEquStr(aCStr, "Maybe you intend \'");
	_ScopeName(scopeID, scopeName);
	CEquStr(aCStr, scopeName);
	CAddStr(aCStr, " ");
	CAddStr(aCStr, varName);
	NewMsgRecord(api_data, kHINT, aCStr, 0, 0);
	//CStringToErrMessage(api_data, aCStr);
}

//===========================================================================================
XErr 	DoConstructor(long api_data, long constructor, Ptr *oldFilePPtr, long *lenP, Boolean pre_incr, Boolean pre_decr, ObjRecordP result, long *numParP, Boolean isSuper, ObjRecordP rightValue, long flags, Boolean gettingReference, BlockRef *setPropBlockP)
{
long					totParams;
XErr					err = noErr;
Ptr						tempP;
long					paramVarsID = 0, len;
BifernoRecP				bRecP = (BifernoRecP)api_data;
ParameterRecP			paramVarsP;
//MemberIdentification	membIdent;
BAPI_Doc 				*docP;

	tempP = *oldFilePPtr;
	len = *lenP;

	SkipSpaceAndTab(&tempP, &len);
	if (len && (*tempP == '.'))
	{	
	long	incrType, assignmentType;
	
		if (pre_incr)
			incrType = kPreIncrem;
		else if (pre_decr)
			incrType = kPreDecrem;
		else
			incrType = kNullIncr;
		if (isSuper)
		{	*result = bRecP->superObjRef;
			if NOT(result->id)
				err = XError(kBAPI_Error, Err_SuperConstructorRequired);
		}
		else
		{	BlockRef				setPropBlock = 0;
			uint32_t				slot;
			ProcessObjectCallRecord	*processObjectP = nil;
		
			BAPI_InvalObjRef(api_data, OBJREF_P(result));
			result->classID = constructor;
			//incrType = 0;
			assignmentType = -1;
			if NOT(err = PoolNewPtr(gsDispatcherData.processObjectPool, (Ptr*)&processObjectP, &slot))
			{	processObjectP->propListBlockP = &setPropBlock;
				processObjectP->leftObjVarP = result;
				processObjectP->varName = nil;
				processObjectP->incrTypeP = &incrType;
				processObjectP->assignmentTypeP = &assignmentType;
				processObjectP->rightValue = rightValue;
				processObjectP->numParP = numParP;
				processObjectP->flags = flags;
				processObjectP->result = result;
				processObjectP->mCoordBlock = 0;
				processObjectP->isFunction = false;
				processObjectP->staticProperty = true;
				processObjectP->sideEffectIfAssign = false;
				processObjectP->mCoordDim = 0;
				processObjectP->appearsOneMethodP = nil;
				processObjectP->notifyP = nil;
				err = _ProcessObject(api_data, &tempP, &len, processObjectP, kImplicitTypeCast, false, gettingReference, 0/*, nil*/);
				PoolDisposePtr(gsDispatcherData.processObjectPool, slot);
			}
			if (setPropBlock)	// Someone allocated it
			{	if (gettingReference)
					*setPropBlockP = setPropBlock;
				else
					DisposePropListRec(&setPropBlock);
			}
		}
	}
	else if (gettingReference)
		err = XError(kBAPI_Error, Err_UndefinedIdentifier);
	else
	{	if (flags & kInCase)
			err = XError(kBAPI_Error, Err_IllegalConstantExpression);
		else if (gettingReference/*flags & kAddressParameter*/)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	SkipSpaceAndTab(&tempP, &len);
			if (len && (*tempP == '('))
			{	
			//long	loadOpcodeBuffer;
			
				/*if COMPILING(api_data)
					loadOpcodeBuffer = BufferCreate(64, &err);
				else
					loadOpcodeBuffer = 0;*/
				if NOT(err)
				{	if NOT(err = GetContructorDoc(api_data, constructor, &docP))
					{	if NOT(err = GetFunctionParametersSmart(bRecP, constructor, &tempP, &len, &paramVarsID, &paramVarsP, &totParams/*, &membIdent, true*/, docP))
						{	if (err = CL_Constructor(api_data, TEMP, VARIABLE, nil, constructor, paramVarsP, totParams, docP, result))
								;//NewMsgRecord(api_data, kCONSTRUCTOR, *oldFilePPtr, *lenP, kOnlyIfEmpty);
							else if (isSuper)
							{	
								BifernoSetSuper(api_data, &bRecP->thisObjRef, result, &bRecP->superObjRef);
								// set result to 0 (super must be void)
								result->list = 0;
								result->id = 0;
							}
							BufferFree(paramVarsID);
						}
					}
				}
			}
			else
			{	result->id = 0;
				err = XError(kBAPI_Error, Err_BadSyntax);
			}
		}
	}

if (err)
{	if NOT(bRecP->currentCtx.currentOffset)
		bRecP->currentCtx.currentOffset = BfrGetOffset(bRecP, *lenP);
}
else
{	*oldFilePPtr = tempP;
	*lenP = len;
}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
/*
Schema
preDecr{| type.scope.nomeVar | []...[] | .member | []...[] |}postDecr {[operatore]} {|espressione|}

preDecr		= pre de/in-cremento (opzionale); se esiste allora non deve esistere [operatore]
nomeVar	= nome della variabile risultato
[]			= indice dell'array (opzionale), DA RISOLVERE
.method		= metodo o propriet� della classe (opzionale)
[]			= indice della propriet� (opzionale), DA RISOLVERE
preDecr		= post de/in-cremento (opzionale); se esiste allora non deve esistere [operatore]
[operatore]	= pu� essere: =, -=, += (opzionale)
espressione	= una stringa di caratteri fino a CR o ';' da Risolvere
*/
XErr	EvalVariable(long api_data, Ptr *lineTextP, long *lineLenP, long typeCastType, ObjRecordP rightValue, Boolean pre_incr, Boolean pre_decr, long *numParP, ObjRecordP resultVarP, char *varName, Boolean *noPostIncrP, long flags, Boolean ternaryPending, BlockRef *propBlockP/*, Boolean *setErrMsgP*/)
{
Ptr 					textP;
long					assignmentType, len, incrType;
XErr					err = noErr;
ObjRecord					leftObjVar;
DLMRef					varList;
BifernoRecP 			bRunP;
Boolean					entityWasFound, saveOutOfBoundary, appearsOneMethod, isThis, isSuper;
BlockRef				propBlock;
SuperIsChangedNotify 	*notifyP;
ProcessObjectCallRecord	*processObjectP = nil;
long					mCoordDim = 0;
uint32_t				slot;
BlockRef				mCoordBlock = 0L;
long					arrayElemReqClassID, constructor;	
Boolean					isFunc;
Boolean 				gettingReference;
	
	if NOT(bRunP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if NOT(*lineLenP)
		return noErr;
	
	// Initialization
	//enteredInCriticalSection = false;
	BAPI_InvalObjRef(api_data, OBJREF_P(&leftObjVar));
	leftObjVar.classID = arrayElemReqClassID = 0;
	textP = *lineTextP;
	len = *lineLenP;
	*varName = 0;
	varList = 0;
	propBlock = 0;		// perhaps somone will allocate it
	appearsOneMethod = isThis = isSuper = entityWasFound = isFunc = false;
	notifyP = nil;
	saveOutOfBoundary = bRunP->outOfBoundary;
	gettingReference = (Boolean)(propBlockP != nil);
	SkipSpaceAndTab(&textP, &len);
	
	// Pre de/in-crement
	if (pre_incr)
		incrType = kPreIncrem;
	else if (pre_decr)
		incrType = kPreDecrem;
	else
		incrType = kNullIncr;
	assignmentType = -1;		// undefined  (_GetAssignmentType has to be called)
	
	// Scope & Type
	err = GetScopeAndType(api_data, &textP, &len, &varList, &leftObjVar.type, &leftObjVar.scope, varName);
	// because varName is returned
	*lineTextP = textP;
	*lineLenP = len;
	bRunP->lastScope = leftObjVar.scope;
	if (err)
		goto out;
	if (NOT(ternaryPending) && len && NOT(flags & kStopOnSemicolon) && (*textP == ':'))	// is a label
	{	textP++;
		len--;
		if COMPILING(api_data)
			err = BIC_AddLabel(api_data, varName);
		goto out;
	}
		
	// Var name
	if NOT(varName[0])
	{	SkipSpaceAndTab(&textP, &len);
		if (err = GetEntityName(api_data, &textP, &len, varName, false))
			goto out;
	}
		
	if NOT(CCompareStrings_cs("this", varName))
	{	
		if (flags & kInCase)
		{	err = XError(kBAPI_Error, Err_IllegalConstantExpression);
			goto out;
		}
		else if (bRunP->thisObjRef.id)
		{	
			if (gettingReference && bRunP->executingConstructor)
			{
				err = XError(kBAPI_Error, Err_IllegalOperation);
				goto out;
			}
			else
			{
				/*if (_NeedCS((ObjRecordP)&bRunP->thisObjRef))
				{
					XThreadsEnterCriticalSection();
					enteredInCriticalSection = true;
				}*/
				leftObjVar = bRunP->thisObjRef;
				isThis = true;
			}
		}
		else
		{	err = XError(kBAPI_Error, Err_ThisIsUndefined);
			goto out;
		}
	}
	else if NOT(CCompareStrings_cs("true", varName))
	{	
		if (gettingReference || incrType)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	if COMPILING(api_data)
				BIC_LiteralBoolToObjRef(api_data, true, resultVarP);
			else
			{	resultVarP->id = IMMEDIATE_ID;
				resultVarP->classID = kBooleanClassID;
				*(Boolean*)IMM_P(resultVarP) = true;
			}
		}
		if (noPostIncrP)
			*noPostIncrP = true;
		goto out;
	}
	else if NOT(CCompareStrings_cs("false", varName))
	{	
		if (gettingReference || incrType)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	if COMPILING(api_data)
				BIC_LiteralBoolToObjRef(api_data, false, resultVarP);
			else
			{	resultVarP->id = IMMEDIATE_ID;
				resultVarP->classID = kBooleanClassID;
				*(Boolean*)IMM_P(resultVarP) = false;
			}
		}
		if (noPostIncrP)
			*noPostIncrP = true;
		goto out;
	}
	else if NOT(CCompareStrings_cs("super", varName))
	{	
		if (flags & kInCase)
		{	err = XError(kBAPI_Error, Err_IllegalConstantExpression);
			goto out;
		}
		else if (bRunP->superObjRef.id)
		{	
			/*if (_NeedCS((ObjRecordP)&bRunP->superObjRef))
			{
				XThreadsEnterCriticalSection();
				enteredInCriticalSection = true;
			}*/
			leftObjVar = bRunP->superObjRef;
			isSuper = true;
			err = FillNotifyItem(&bRunP->thisObjRef, "", &notifyP, kPublic);
		}
		else if (bRunP->superObjRef.classID)
		{	constructor = bRunP->superObjRef.classID;
			isSuper = true;
			goto doConstructor;
		}
		else
		{	err = XError(kBAPI_Error, Err_SuperIsUndefined);
			NewMsgRecord(api_data, kDOING, varName, 0, 0);
			goto out;
		}
	}
	// Function or variable?
	if (isThis || isSuper)
	{	
		Ptr		saveTextP = textP;
		long	saveLen = len;
		if (err = ResolveArryItem(api_data, &textP, &len, &leftObjVar, nil, nil, false, nil, nil))
		{	if (isThis)
			{	leftObjVar = bRunP->superObjRef;
				textP = saveTextP;
				len = saveLen;
				err = ResolveArryItem(api_data, &textP, &len, &leftObjVar, nil, nil, false, nil, nil);
			}
		}
	}
	else
	{	Boolean	toStop;
	
		if COMPILING(api_data)
		{	
			if NOT(err = BIC_IdentifyObject(api_data, varName, textP, len, leftObjVar.scope, nil, &leftObjVar))
			{	
				SkipSpaceAndTab(&textP, &len);
				if (len)
				{	if (*textP == '[')
						err = ResolveArryItem(api_data, &textP, &len, &leftObjVar, nil, &mCoordDim, false, &mCoordBlock, nil);
					if (err)
						goto out;
				}
				entityWasFound = (leftObjVar.id != 0);
			}
			toStop = false;
		}					
		else
			err = _IdentifyObject(api_data, &textP, &len, &propBlock, varName, varList, &appearsOneMethod, &toStop, &incrType, &assignmentType, &leftObjVar, &isThis, &notifyP, &mCoordBlock, &mCoordDim, &entityWasFound, flags, &arrayElemReqClassID/*, &enteredInCriticalSection*/);							
		if NOT(err)
		{	
		BlockRef 		membIdentBlock;
		MemberAction 	*membIdentP;
		Boolean			gotoOut = false;
		
			if (NOT(leftObjVar.id) || NOT(leftObjVar.classID))	// unknown or undeffed
			{	
				if (IsConstructor(api_data, &textP, &len, varName, false, &constructor, false, &isSuper, &err))
				{	if NOT(err)
					{	
					doConstructor:
						err = DoConstructor(api_data, constructor, &textP, &len, pre_incr, pre_decr, resultVarP, numParP, isSuper, rightValue, flags, gettingReference, &propBlock);
					}
					goto out;
				}
				else if (NOT(gettingReference) && NOT(err = GetFunctionInfo(api_data, &textP, &len, varName, &membIdentBlock, &isFunc)) && isFunc)
				{	
					if (flags & kInCase)
						err = XError(kBAPI_Error, Err_IllegalConstantExpression);
					else
					{	
						if (membIdentBlock)
							membIdentP = (MemberAction*)GetPtr(membIdentBlock);
						else
							membIdentP = nil;
						if NOT(err = DoFunction(api_data, membIdentP, varName, &textP, &len, &leftObjVar))
						{
							if (bRunP->currentCtx._stop || bRunP->_exit)
								gotoOut = true;
						}
					}
					if (membIdentBlock)
						DisposeBlock(&membIdentBlock);
					if (gotoOut)
						goto out;
				}
			}
			else
			{	if (toStop)
				{	*resultVarP = leftObjVar;
					goto out;
				}
				if (incrType && NOT(leftObjVar.id))
				{	err = XError(kBAPI_Error, Err_UndefinedIdentifier);
					goto out;
				}
			}
		}
	}
	if NOT(err)
	{	if NOT(err = PoolNewPtr(gsDispatcherData.processObjectPool, (Ptr*)&processObjectP, &slot))
		{	processObjectP->propListBlockP = &propBlock;
			processObjectP->leftObjVarP = &leftObjVar;
			processObjectP->varName = varName;
			processObjectP->incrTypeP = &incrType;
			processObjectP->assignmentTypeP = &assignmentType;
			processObjectP->rightValue = rightValue;
			processObjectP->numParP = numParP;
			processObjectP->flags = flags;
			processObjectP->result = resultVarP;
			processObjectP->mCoordBlock = mCoordBlock;
			processObjectP->isFunction = isFunc;
			processObjectP->staticProperty = false;
			if (isThis || isSuper)
				processObjectP->sideEffectIfAssign = true;
			else
				processObjectP->sideEffectIfAssign = false;
			processObjectP->mCoordDim = (Byte)mCoordDim;
			processObjectP->appearsOneMethodP = &appearsOneMethod;
			processObjectP->notifyP = &notifyP;
			err = _ProcessObject(api_data, &textP, &len, processObjectP, typeCastType, entityWasFound, gettingReference, arrayElemReqClassID/*, setErrMsgP*/);
			PoolDisposePtr(gsDispatcherData.processObjectPool, slot);
		}
	}

out:	
	if (notifyP)
	{	if NOT(err)
			err = NotifySuperIsChanged(api_data, notifyP);
		PoolDisposePtr(gsDispatcherData.notifySuperIsChangedPool, notifyP->slot);
	}
	if (propBlock)	// Someone allocated it
	{	if (propBlockP && NOT(err))
			*propBlockP = propBlock;
		else
			DisposePropListRec(&propBlock);
	}
	else if (propBlockP)
		*propBlockP = nil;
		
	if (mCoordBlock)
		DisposeBlock(&mCoordBlock);
	if NOT(err)
	{	*lineTextP = textP;
		*lineLenP = len;
	}
	else
	{	if ((err == XError(kBAPI_Error, Err_UndefinedIdentifier)) && (bRunP->loadingClass || bRunP->currentCtx.methodInExecutionID))
		{
		long	tScope;
		
			mCoordDim = bRunP->loadingClass;
			slot = bRunP->currentCtx.methodInExecutionID;
			bRunP->loadingClass = (Boolean)(bRunP->currentCtx.methodInExecutionID = 0);
			incrType = LookForObj(api_data, varName, &varList, nil, nil, &tScope, nil);
			bRunP->loadingClass = (Boolean)mCoordDim;
			bRunP->currentCtx.methodInExecutionID = slot;
			if (incrType && (tScope != LOCAL))	// varList, funcID, funcObjID not used 
				_PerhapsToErr(api_data, varName, tScope);
			else if NOT(isFunc)
				NewMsgRecord(api_data, kDOING, varName, 0, 0);
		}
		else if NOT(isFunc)
			NewMsgRecord(api_data, kDOING, varName, 0, 0);
	}
	bRunP->outOfBoundary = saveOutOfBoundary;
	
	// leave critical section if any
	//if (enteredInCriticalSection)
	//	XThreadsLeaveCriticalSection();
	
return err;
}

