/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Opcodes.c,v 1.10 2008-12-02 11:04:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Load.h"
#include "Flower.h"
#include "Eval.h"
#include "BfrParser.h"
#include "Dispatcher.h"

#include "Compiler.h"
#include "Opcodes.h"

CStr63	gsOpcodeNames[] = 
	{	
		"nop",
		"store",
		"storeElem",
		"storeElemN",
		//"decrstack",
		//"copy",
		"load",
		"loadDefault",
		
		"mul",
		"div",
		"mod",
		"add",
		"sub",
		"shiftl",
		"shiftr",
		"great",
		"less",
		"greate",
		"lesse",
		"equa",
		"nequa",
		"aand",
		"aor",
		"and",
		"or",
		"invert",
		
		"exit",
		"stop",
		"debug",
		"lock",
		"unlock",
		"include",
		
		"print",
		
		"bra",
		"bet",
		"bef",
		"bnse",
		
		"incr",
		"incrIndex",
		"incrIndexN",
		"incrproperty",
		"decr",
		"decrIndex",
		"decrIndexN",
		"decrproperty",
		
		"typecast",
		
		//"disposelocal",
		"call",
		"callini",
		"callend",
		//"invoke",
		"get",
		"get_los",
		"set",
		"set_push",
		
		"tern",
		
		"index",
		"indexN",
		"index_los",
		"indexN_los"
	};

//===========================================================================================
static Boolean	_OpFlowControl(Byte opCode)
{
	switch(opCode)
	{
		case kExit_o:
		case kStop_o:
		case kDebug_o:
		case k_Lock_o:
		case k_Unlock_o:
		case k_Include_o:

		case kBra_o:
		case kBet_o:
		case kBef_o:
		case kBnse_o:
			return true;
			
		default:
			return false;
	}
}

//===========================================================================================
static XErr	_AddOpcode(BICRecordP bicRecP, B_OpcodeExt *bOpcodeExtP, Boolean isExt, int lessStack)
{
long			totSize;
XErr			err = noErr;
OpStackInfo		opStackInfo;
int				i;

	// C'era un post decr da mettere
	/*if (bicRecP->postIncrType && NOT(ignorePostIncr))
	{	err = Opcode_OneParam(bicRecP, &bicRecP->postIncrObjRef, bicRecP->postIncrType, true);
		bicRecP->postIncrType = 0;
	}*/
	
	if (isExt)
		totSize = sizeof(B_OpcodeExt);
	else
		totSize = sizeof(B_Opcode);
	
	ClearBlock(&opStackInfo, sizeof(OpStackInfo));
	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &opStackInfo.opOffset, nil);
	if NOT(err = BufferAddBuffer(bicRecP->opcodesBufferID, (Ptr)bOpcodeExtP, totSize))
	{	bicRecP->lastOpcodeSize = totSize;
		bicRecP->lastOpcode = bOpcodeExtP->head.opCode;
		bicRecP->lastOpVariant = *(Byte*)&bOpcodeExtP->head.opVariant;
		if NOT(err = BufferAddBuffer(bicRecP->opcodesStack, (Ptr)&opStackInfo, sizeof(OpStackInfo)))
		{	
			// Decrement or Increment stack
			for (i = 0; i < lessStack; i++)
				LessStack(bicRecP, bicRecP->totOpcodes, false);
			if (bOpcodeExtP->head.opCode == kLoad_o || bOpcodeExtP->head.opCode == kLoadDefault_o || bOpcodeExtP->head.opCode == kSetPutOnStack_o)
				MoreStack(bicRecP, bicRecP->totOpcodes);
			else if ((bOpcodeExtP->head.dest == SP) && (bOpcodeExtP->head.opCode != kSet_o))
			{	
				if NOT(_OpFlowControl(bOpcodeExtP->head.opCode))
					MoreStack(bicRecP, bicRecP->totOpcodes);
			}
			if (bOpcodeExtP->head.opCode == kTern_o)
				LessStack(bicRecP, bicRecP->totOpcodes, false);
			bicRecP->totOpcodes++;
		}
	}
return err;
}

//===========================================================================================
static Boolean	_FitInShort(long aLong)
{
	return ((aLong <= 32767) && (aLong >= -32768));
}

//===========================================================================================
static void	_FillParam(BICRecordP bicRecP, ObjRecordP objRecP, Byte *param, Boolean *isExt, int *lessStackP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(bicRecP)
#endif
long		aLong, tLen, paramSpec = BIC_OBJREF_SPEC(objRecP);

	if (lessStackP)
		*lessStackP = 0;
	switch(paramSpec)
	{
		case kCL_LIST:
			*(short*)param = (short)objRecP->id;
			if (isExt)
				*isExt = false;
			break;
		case kImmediateValue:
			switch(objRecP->classID)
			{	case kBooleanClassID:
					*(Boolean*)param = *(Boolean*)BIC_IMM_P(objRecP);
					if (isExt)
						*isExt = false;
					break;
				case kStringClassID:
					tLen = BIC_IMMLEN_STRLEN_P(objRecP);
					CopyBlock((Ptr)param + 1, BIC_IMM_P(objRecP) + 1, tLen);
					*(Byte*)param = (Byte)tLen;
					if (isExt)
						*isExt = true;
					break;
				case kDoubleClassID:
					*(double*)param = *(double*)BIC_IMM_P(objRecP);
					if (isExt)
						*isExt = true;
					break;
				case kLongClassID:
					*(LONGLONG*)param = *(LONGLONG*)BIC_IMM_P(objRecP);
					if (isExt)
						*isExt = true;
					break;
				case kUnsignedClassID:
					*(unsigned long*)param = *(unsigned long*)BIC_IMM_P(objRecP);
					if (isExt)
						*isExt = true;
					break;
				case kIntClassID:
					aLong = *(long*)BIC_IMM_P(objRecP);
					if (_FitInShort(aLong))
					{	*(short*)param = (short)aLong;
						if (isExt)
							*isExt = false;
					}
					else
					{	*(long*)param = aLong;
						if (isExt)
							*isExt = true;
					}
					break;
			}
			break;
			
		case kVL_LIST:
			*(short*)param = (short)objRecP->id;
			if ((objRecP->id == SP) && lessStackP)
				*lessStackP = 1;
			if (isExt)
				*isExt = false;
			break;
	}
}

//===========================================================================================
static void	_GetExtension(VariantRec opVariant, char *str)
{
	*str = 0;
	switch(opVariant.pos1)
	{
		case kVariantVL_LIST:
			if (opVariant.pos2 && (opVariant.pos2 < kVariantVL_LIST))
				CEquStr(str, "_x");
			break;
		case kVariantCL_LIST:
			CEquStr(str, "_C");
			break;
		case kBooleanClassID:
			CEquStr(str, "_b");
			break;
		case kStringClassID:
			CEquStr(str, "_s");
			break;
		case kDoubleClassID:
			CEquStr(str, "_d");
			break;
		case kLongClassID:
			CEquStr(str, "_l");
			break;
		case kUnsignedClassID:
			CEquStr(str, "_u");
			break;
		case kVariant2BytesInt:
		case kIntClassID:
			CEquStr(str, "_i");
			break;
		case kVariantNumber:
		case kVariantSL:
			break;
		default:
			if (opVariant.pos1 && opVariant.pos2)
				CEquStr(str, "_");
	}
	switch(opVariant.pos2)
	{	case kVariantCL_LIST:
			CAddStr(str, "C");
			break;
		case kVariantVL_LIST:
			if (opVariant.pos1 && (opVariant.pos1 < kVariantVL_LIST))
				CAddStr(str, "x");
			break;
		case kBooleanClassID:
			CAddStr(str, "b");
			break;
		case kStringClassID:
			CAddStr(str, "s");
			break;
		case kDoubleClassID:
			CAddStr(str, "d");
			break;
		case kLongClassID:
			CAddStr(str, "l");
			break;
		case kUnsignedClassID:
			CAddStr(str, "u");
			break;
		case kVariant2BytesInt:
		case kIntClassID:
			CAddStr(str, "i");
			break;
	}
}

//===========================================================================================
static void	_GetOpcodeName(Byte opCode, VariantRec opVariant, char *nameP)
{
CStr15	tStr;

	CEquStr(nameP, gsOpcodeNames[opCode]);
	_GetExtension(opVariant, tStr);
	CAddStr(nameP, tStr);
}

//===========================================================================================
static Byte	_VariantFromObjRef(ObjRecordP objRefP)
{
long	spec = BIC_OBJREF_SPEC(objRefP);
Byte	variant;

	if (spec == kCL_LIST)
		variant = kVariantCL_LIST;
	else if (spec == kVL_LIST)
		variant = kVariantVL_LIST;
	else
	{	if ((objRefP->classID == kIntClassID) && (_FitInShort(*(long*)BIC_IMM_P(objRefP))))
			variant = kVariant2BytesInt;
		else	
			variant = (Byte)objRefP->classID;
	}
	
return variant;
}

//===========================================================================================
Byte	ObjRefIsExt(ObjRecordP objRecP)
{
//int			spec = BIC_OBJREF_SPEC(objRecP);
Boolean		res = false;

	switch(_VariantFromObjRef(objRecP))
	{
		case kVariant2BytesInt:
		case kVariantCL_LIST:
		case kVariantVL_LIST:
		case kBooleanClassID:
			res = false;
			break;
		default:
			res = true;
			break;
	}

return res;
}

//===========================================================================================
long	GetOpcodeSize(B_Opcode *bOpcodeP)
{
OpcodeHead	*headP = &bOpcodeP->head;
long		opSize;
VariantRec	variant = headP->opVariant;

	if (*(Byte*)&variant)
	{	if (variant.pos1 && VARIANT_IS_EXT(variant.pos1))
			opSize = LARGE;
		else if (variant.pos2 && VARIANT_IS_EXT(variant.pos2))
			opSize = LARGE;
		else
			opSize = SMALL;
	}
	else
		opSize = SMALL;

return opSize;
}

//===========================================================================================
void	MoreStack(BICRecordP bicRecP, int opcodeIndex)
{
OpStackInfoP	opStackP;

	BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
	opStackP += opcodeIndex;
	opStackP->countStack++;
	opStackP->incr_stack++;

	bicRecP->actStack++;
	//if (bicRecP->actStack > bicRecP->maxStack)
	//	bicRecP->maxStack = bicRecP->actStack;
}

//===========================================================================================
void	LessStack(BICRecordP bicRecP, int opcodeIndex, Boolean decr_incr)
{
OpStackInfoP	opStackP;
int				i, totOpcodes = bicRecP->totOpcodes;

	BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
	opStackP += opcodeIndex;
	if (decr_incr)
		opStackP->incr_stack--;
	else
		opStackP->decr_stack++;
	for (i = 0; i <= totOpcodes; i++, opStackP--)
	{	if (opStackP->countStack)
		{	(opStackP->countStack)--;
			break;
		}
	}
	bicRecP->actStack--;
}


//===========================================================================================
// opcodeIndex 1-based
void	NopUnusedOpcode(BICRecordP bicRecP, Ptr opcodesPtr, long opcodeIndex)
{
OpStackInfoP	opStackP;
int				incr_stack, decr_stack, totOpcodes = bicRecP->totOpcodes, totLessStack = 0;
OpcodeHead		*headP;

	BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
	opStackP += --opcodeIndex;
	opStackP->countStack = opStackP->incr_stack = opStackP->decr_stack = 0;
	headP = &((B_Opcode*)(opcodesPtr + opStackP->opOffset))->head;
	if (headP->opCode == kIndexN_o)
		totLessStack = PARAM_2_SHORT(headP);	// *(short*)((B_Opcode*)headP)->params;
	else if (headP->opCode == kGet_o)
	{	
	long		slIndex;
	SL_SlotP	slSlotP;
	
		slIndex = PARAM_1_SHORT(headP);
		if (slIndex < 0)
			slIndex = -slIndex;
		slSlotP = (SL_SlotP)(GetPtr(bicRecP->sl.block) + ((long*)GetPtr(bicRecP->sl.offsets))[slIndex-1]);
		// totLessStack = slSlotP->head.dim;
	}
	else if (PARAM_2_SHORT(headP) == SP)
		totLessStack++;
	headP->opCode = kNop_o;
	bicRecP->totNops++;
	if (totOpcodes)
	{	if (PARAM_1_SHORT(headP) == SP)
			totLessStack++;
		if (totLessStack)
		{	do
			{	opStackP--;
				incr_stack = opStackP->incr_stack;
				decr_stack = opStackP->decr_stack;
				if (incr_stack)
				{	totLessStack -= incr_stack;
					opStackP->countStack = opStackP->incr_stack = opStackP->decr_stack = 0;
					headP = &((B_Opcode*)(opcodesPtr + opStackP->opOffset))->head;
					headP->opCode = kNop_o;
					bicRecP->totNops++;
				}
				if (decr_stack)
				{	if NOT(incr_stack)		// not nopped
					{	do
						{	
							opStackP--;
							decr_stack -= opStackP->incr_stack;
						} while(decr_stack > 0);
					}
					else
						totLessStack += decr_stack;
				}
			} while (totLessStack > 0);
			/*
			headP->opCode = kDecrStack_o;
			headP->dest = totLessStack;
			opStackP->decr_stack = totLessStack;
			*/
		}
	}
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
void DumpVL(char *opcodeStr, int id)
{
CStr31		tStr;

	if (id)
	{	if (id == SP)
			CEquStr(opcodeStr, "SP");
		else
		{	CNumToString(id, tStr);
			CEquStr(opcodeStr, "VL");
			CAddStr(opcodeStr, tStr);
		}
	}
}

//===========================================================================================
void DumpCL(char *opcodeStr, int id)
{
CStr31		tStr;

	if (id)
	{	CNumToString(id, tStr);
		CEquStr(opcodeStr, "CL");
		CAddStr(opcodeStr, tStr);
	}
}

//===========================================================================================
void DumpSL(char *opcodeStr, int id)
{
CStr31		tStr;

	if (id)
	{	if (id > 0)
		{	CEquStr(opcodeStr, "SL");
			CNumToString(id, tStr);
		}
		else
		{	CEquStr(opcodeStr, "DL");
			CNumToString(-id, tStr);
		}
		CAddStr(opcodeStr, tStr);
	}
}

//===========================================================================================
void DumpBool(char *opcodeStr, Boolean aBool)
{
	if (aBool)
		CEquStr(opcodeStr, "true");
	else
		CEquStr(opcodeStr, "false");
}

//===========================================================================================
XErr DumpStr(char *opcodeStr, Byte *str)
{
BlockRef	resBlock = 0, resBlock2 = 0;
long		resBlockLen, resBlockLen2;
XErr		err = noErr;

	CEquStr(opcodeStr, "\"");
	if NOT(err = SubstituteExt((Ptr)&str[1], str[0], &resBlock, &resBlockLen, "\"", 1, "\\\"", 2, true, false))
	{	LockBlock(resBlock);
		if NOT(err = SubstituteExt(GetPtr(resBlock), resBlockLen, &resBlock2, &resBlockLen2, "\r", 1, "\\r", 2, true, false))
		{	DisposeBlock(&resBlock);
			LockBlock(resBlock2);
			if NOT(err = SubstituteExt(GetPtr(resBlock2), resBlockLen2, &resBlock, &resBlockLen, "\n", 1, "\\n", 2, true, false))
				CAddStr(opcodeStr, GetPtr(resBlock));
		}
	}			
	CAddChar(opcodeStr, '\"');

if (resBlock)
	DisposeBlock(&resBlock);
if (resBlock2)
	DisposeBlock(&resBlock2);
return err;
}

//===========================================================================================
void DumpDouble(char *opcodeStr, double *r)
{
	CRealToStr(r, opcodeStr, 2);
}

//===========================================================================================
void DumpLong(char *opcodeStr, LONGLONG l)
{
	CLongNumToString(l, opcodeStr);
}

//===========================================================================================
void DumpInt(char *opcodeStr, long val)
{
	CNumToString(val, opcodeStr);
}

//===========================================================================================
void DumpUnsigned(char *opcodeStr, unsigned long val)
{
	CNumToString(val, opcodeStr);
}

//===========================================================================================
/*static void	_DumpOtherStuff(long opcodeOff, OpcodeHead *headP, Byte *param, char *opcodeStr)
{
CStr31		tStr;

	switch(headP->opCode)
	{
		case kDecrStack_o:
			CNumToString(headP->dest, tStr);
			CAddStr(opcodeStr, " ");
			CAddStr(opcodeStr, tStr);
			break;
		
		case kBra_o:
			CNumToString(opcodeOff + *(long*)&headP->dest, tStr);
			CAddStr(opcodeStr, tStr);
			break;
		case kBet_o:
		case kBef_o:		
			CNumToString(opcodeOff + *(long*)&headP->dest, tStr);
			CAddStr(opcodeStr, ", ");
			CAddStr(opcodeStr, tStr);
			break;
		
		case kInvert_o:
			_DumpVL(opcodeStr, headP->param1);
			break;
			
		case kCall_o:
		case kInvoke_o:
			_DumpSL(opcodeStr, headP->param1);
			break;
		case kGetStat_o:
			if (*(Byte*)&headP->opVariant || *(short*)param)
				CAddStr(opcodeStr, ", ");
			_DumpSL(opcodeStr, headP->param1);
			break;
			
		case kIndexN_o:
			CNumToString(*(short*)param, tStr);
			CAddStr(opcodeStr, ", ");
			CAddStr(opcodeStr, tStr);
			break;
	}
}
*/
//===========================================================================================
static void	_GetOpcodStr_param(Byte opcodeClass, Byte *paramP, char *paramStr, long *sizeofParamP)
{

	switch(opcodeClass)
	{
		case kVariant2BytesInt:
			DumpInt(paramStr, *(short*)paramP);
			if (sizeofParamP)
				*sizeofParamP = sizeof(short);
			break;
		case kVariantCL_LIST:
			DumpCL(paramStr, *(short*)paramP);
			if (sizeofParamP)
				*sizeofParamP = sizeof(short);
			break;
		case kVariantVL_LIST:
			/*if (headP->opCode == kIndexN_o)
				_DumpVL(paramStr, headP->param1);
			else*/
			DumpVL(paramStr, *(short*)paramP);
			if (sizeofParamP)
				*sizeofParamP = sizeof(short);
			break;
		case kVariantNumber:
			CNumToString(*(short*)paramP, paramStr);
			if (sizeofParamP)
				*sizeofParamP = sizeof(short);
			break;
		case kVariantSL:
			DumpSL(paramStr, *(short*)paramP);
			if (sizeofParamP)
				*sizeofParamP = sizeof(short);
			break;
		case kBooleanClassID:
			DumpBool(paramStr, *(Boolean*)paramP);
			if (sizeofParamP)
				*sizeofParamP = sizeof(short);
			break;
		case kStringClassID:
			DumpStr(paramStr, (Byte*)paramP);
			if (sizeofParamP)
				*sizeofParamP = MAX_PARAM2_SIZE;
			break;
		case kDoubleClassID:
			DumpDouble(paramStr, (double*)paramP);
			if (sizeofParamP)
				*sizeofParamP = MAX_PARAM2_SIZE;
			break;
		case kLongClassID:
			DumpLong(paramStr, *(LONGLONG*)paramP);
			if (sizeofParamP)
				*sizeofParamP = MAX_PARAM2_SIZE;
			break;
		case kUnsignedClassID:
			DumpUnsigned(paramStr, *(unsigned long*)paramP);
			if (sizeofParamP)
				*sizeofParamP = MAX_PARAM2_SIZE;
			break;
		case kIntClassID:
			DumpInt(paramStr, *(long*)paramP);
			if (sizeofParamP)
				*sizeofParamP = MAX_PARAM2_SIZE;
			break;
		default:
			if (sizeofParamP)
				*sizeofParamP = sizeof(short);
			break;
	}
}

//===========================================================================================
static long	_DumpOpcode(long outputID, long offset, B_Opcode *bOpcodeP, XErr *errP)
{
CStr255		paramStr, opcodeStr;
short		p;
CStr31		tStr;
long		sizeofParam1, opSize;
OpcodeHead	*headP = &bOpcodeP->head;
Boolean		hasDest = false;

	*paramStr = 0;
	if (headP->opCode == kNop_o)
	{	CEquStr(opcodeStr, gsOpcodeNames[kNop_o]);
		goto addBuffer;
	}
	/*else if (headP->opCode == kDecrStack_o)
	{	CEquStr(opcodeStr, gsOpcodeNames[kDecrStack_o]);
		CNumToString(headP->dest, tStr);
		CAddChar(opcodeStr, ' ');
		CAddStr(opcodeStr, tStr);
		goto addBuffer;
	}*/
	else
		_GetOpcodeName(headP->opCode, headP->opVariant, opcodeStr);
	CAddChar(opcodeStr, ' ');
	if (IS_BRANCH(headP))
	{	
		if ((headP->opCode != kBra_o) && (headP->opCode != kBnse_o))
		{	
			DumpVL(tStr, BRANCH_TESTVAR(headP));
			CAddStr(opcodeStr, tStr);
			CAddStr(opcodeStr, ", ");
		}
		CNumToString(offset + BRANCH_OFFSET(headP), tStr);
		CAddStr(opcodeStr, tStr);
		if (headP->opVariant.pos2)
			CAddStr(opcodeStr, ", ");
		sizeofParam1 = sizeof(short);
	}
	else
	{	//dest
		if (p = headP->dest)
		{	
			if ((headP->opCode == kSet_o) || (headP->opCode == kSetPutOnStack_o))
			{	
				DumpSL(paramStr, p);
				CAddStr(opcodeStr, paramStr);
				*paramStr = 0;
			}
			else
			{	
				if (p == SP)
					CAddStr(opcodeStr, "SP");
				else
				{	
					CNumToString(p, tStr);
					CAddStr(opcodeStr, "VL");
					CAddStr(opcodeStr, tStr);
				}
			}
			hasDest = true;
		}
		/*
		if (headP->opCode == kStoreElemN_o)
		{	CNumToString(PARAM_1_SHORT(headP), tStr);
			CAddStr(opcodeStr, tStr);
		}
		*/
		// param 1
		_GetOpcodStr_param(headP->opVariant.pos1, bOpcodeP->params, paramStr, &sizeofParam1);
		if (*paramStr)
		{	if (hasDest)	
				CAddStr(opcodeStr, ", ");
			CAddStr(opcodeStr, paramStr);
		}
	}
	
	// param 2
	*paramStr = 0;
	_GetOpcodStr_param(headP->opVariant.pos2, (Byte*)((Ptr)bOpcodeP->params + sizeofParam1), paramStr, nil);
	if (*paramStr)
	{	CAddStr(opcodeStr, ", ");
		CAddStr(opcodeStr, paramStr);
	}
	
addBuffer:
	opSize = GetOpcodeSize(bOpcodeP);
	*errP = BufferAddCString(outputID, opcodeStr, ISOLATIN_ENC, kTagsVisible);

return opSize;
}

//===========================================================================================
/*static long	_DumpOpcode(long outputID, long offset, Ptr bOpcodeP, XErr *errP)
{
CStr255		opcodeStr;
short		p;
CStr31		tStr;
long		opSize;
OpcodeHead	*headP = &((B_Opcode*)bOpcodeP)->head;

	switch(headP->opCode)
	{
		case kNop_o:
			CequStr
			break;
		case kStore_o:
		case kStoreElem1_o:
		case kStoreElem2_o:
		case kStoreElemN_o:
		case kDecrStack_o:
		case kLoad_o:
		
		case kMul_o:
		case kDiv_o:
		case kMod_o:
		case kAdd_o:
		case kSub_o:
		case kShiftL_o:
		case kShiftR_o:
		case kGreat_o:
		case kLess_o:
		case kGreatE_o:
		case kLessE_o:
		case kEqua_o:
		case kNotEqua_o:
		case kArAnd_o:
		case kArOr_o:
		case kLogicAnd_o:
		case kLogicOr_o:
		case kInvert_o:
		
		case kExit_o:
		case kStop_o:
		case kDebug_o:
		case k_Lock_o:
		case k_Unlock_o:
			
		case kPrint_o:
		
		case kBra_o:
		case kBet_o:
		case kBef_o:
		
		case kIncr_o:
		case kDecr_o:
		
		case kCall_o:
		case kInvoke_o:
		case kGetStat_o:
		
		case kTern_o:
		
		case kIndex_o:
		case kIndexN_o:
		default:
			*opcodeStr = 0;
	}
	*errP = BufferAddCString(outputID, opcodeStr, ISOLATIN_ENC, kTagsVisible);

return opSize;
}*/

//===========================================================================================
/*static	void	_GetOpcode(BICRecordP bicRecP, long opcodeIndex, OpcodeHead *headP)
{
Ptr				opcodesPtr;
OpStackInfoP	opStackP;

	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, nil, &opcodesPtr);
	BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
	*headP = *(OpcodeHead*)(opcodesPtr + opStackP[opcodeIndex-1].opOffset);
}*/

//===========================================================================================
/*static	void	_SetOpcode(BICRecordP bicRecP, OpcodeHead *headP, long opcodeIndex)
{
Ptr				opcodesPtr;
OpStackInfoP	opStackP;

	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, nil, &opcodesPtr);
	BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
	CopyBlock(opcodesPtr + opStackP[opcodeIndex-1].opOffset, headP, sizeof(OpcodeHead));
}*/


#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	Opcode_typeCast(BICRecordP bicRecP, ObjRecordP source, long requestedClassID, ObjRecordP resultP, long api_data)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
Boolean		isExt;
int			lessStack;
ObjRecord	tempObjRef, resultObjRef;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	bOpcode.head.opCode = kTypeCast_o;
	bOpcode.head.dest = SP;
	if (BIC_OBJREF_SPEC(source) <= kImmediateValue)
	{	INVAL(tempObjRef);
		BIC_GetRealObjRef(bicRecP, source, &tempObjRef);
		SET_COMPILING(api_data, false);
		//COMPILING(api_data) = false;
		INVAL(resultObjRef);
		err = CL_TypeCast(api_data, &tempObjRef, requestedClassID, &resultObjRef, kExplicitTypeCast);
		SET_COMPILING(api_data, true);
		//COMPILING(api_data) = true;
		if NOT(err)
			err = BIC_GetBicObjRef(api_data, &resultObjRef, resultP);
	}
	else
	{	PARAM_1_SHORT(&bOpcode) = (short)requestedClassID;
		bOpcode.head.opVariant.pos1 = kVariantNumber;
		_FillParam(bicRecP, source, PARAM_2_P(&bOpcode), &isExt, &lessStack);
		bOpcode.head.opVariant.pos2 = _VariantFromObjRef(source);
		if NOT(err = _AddOpcode(bicRecP, &bOpcode, isExt, lessStack))
		{	resultP->type = 0;
			BIC_OBJREF_SPEC(resultP) = kVL_LIST;
			resultP->classID = 0;
			resultP->id = SP;
			resultP->scope = 0;
			resultP->list = 0;
		}
	}
	
return err;
}

//===========================================================================================
XErr	Opcode_tern(BICRecordP bicRecP, ObjRecordP obj1, ObjRecordP obj2, ObjRecordP obj3, ObjRecordP resultP, long api_data)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
int			lessStack = 0;
Boolean		isExt, res;
ObjRecord	tempObjRef;

	INVAL_P(resultP);
	if (BIC_OBJREF_SPEC(obj1) <= kImmediateValue) // || (obj1->classID == kImmediateValue))
	{	INVAL(tempObjRef);
		BIC_GetRealObjRef(bicRecP, obj1, &tempObjRef);
		if NOT(err = BAPI_ObjToBoolean(api_data, OBJREF_P(&tempObjRef), &res, kExplicitTypeCast))
		{	if (res)
				*resultP = *obj2;
			else
				*resultP = *obj3;
		}
	}
	else
	{	/*
		obj1 is always VL (otherwhise do immediately), so load on stack obj3
		and put in opcode obj1 and obj2 (that certainly fit in it)
		*/
		ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
		bOpcode.head.dest = SP;
		bOpcode.head.opCode = kTern_o;
		if NOT(err = Opcode_load(bicRecP, obj3))
		{	*(short*)bOpcode.params = (short)obj1->id;
			bOpcode.head.opVariant.pos1 = _VariantFromObjRef(obj1);
			bOpcode.head.opVariant.pos2 = _VariantFromObjRef(obj2);
			_FillParam(bicRecP, obj2, (Byte*)bOpcode.params + 2, &isExt, &lessStack);
			err = _AddOpcode(bicRecP, &bOpcode, isExt, lessStack);
		}
	}
		
return err;
}

//===========================================================================================
XErr	Opcode_set(BICRecordP bicRecP, long sl_index, ArrayIndexRec *propertyIndex, int propertyDim, int totLessStack, ObjRecordP value, Boolean putResultOnStack)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
Boolean		noLessStack, isExt, isIndexExt, isValueExt;
ObjRecordP	indexObjP;
Byte		*p;
int			temp;

	if (totLessStack == -1)
		noLessStack = true;
	else
		noLessStack = false;
	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	if (propertyDim == 1)
	{	
		indexObjP = (ObjRecordP)propertyIndex;
		isIndexExt = ObjRefIsExt(indexObjP);
		isValueExt = ObjRefIsExt(value);
		if (isIndexExt && isValueExt)
			goto normalStatic;
		else if (isIndexExt)
		{	if ((BIC_OBJREF_SPEC(value) == kVL_LIST) && (value->id == SP))
				totLessStack++;
			bOpcode.head.dest = (short)sl_index;
			if (putResultOnStack)
				bOpcode.head.opCode = kSetPutOnStack_o;
			else
				bOpcode.head.opCode = kSet_o;
			bOpcode.head.opVariant.pos1 = _VariantFromObjRef(indexObjP);
			bOpcode.head.opVariant.pos2 = _VariantFromObjRef(value);
			_FillParam(bicRecP, indexObjP, PARAM_1_P(&bOpcode), &isExt, nil);
			if (isExt)
				p = bOpcode.params + MAX_PARAM2_SIZE;
			else
				p = bOpcode.params + sizeof(short);
			_FillParam(bicRecP, value, p, nil, nil);
		}
		else if (isValueExt)
		{	if ((BIC_OBJREF_SPEC(indexObjP) == kVL_LIST) && (indexObjP->id == SP))
				totLessStack++;
			bOpcode.head.dest = (short)sl_index;
			if (putResultOnStack)
				bOpcode.head.opCode = kSetPutOnStack_o;
			else
				bOpcode.head.opCode = kSet_o;
			bOpcode.head.opVariant.pos1 = _VariantFromObjRef(indexObjP);
			bOpcode.head.opVariant.pos2 = _VariantFromObjRef(value);
			_FillParam(bicRecP, indexObjP, PARAM_1_P(&bOpcode), &isExt, nil);
			if (isExt)
				p = bOpcode.params + MAX_PARAM2_SIZE;
			else
				p = bOpcode.params + sizeof(short);
			_FillParam(bicRecP, value, p, &isExt, nil);
			isExt = true;
		}
		else
		{	if ((BIC_OBJREF_SPEC(indexObjP) == kVL_LIST) && (indexObjP->id == SP))
				totLessStack++;
			if ((BIC_OBJREF_SPEC(value) == kVL_LIST) && (value->id == SP))
				totLessStack++;
			bOpcode.head.dest = (short)sl_index;
			if (putResultOnStack)
				bOpcode.head.opCode = kSetPutOnStack_o;
			else
				bOpcode.head.opCode = kSet_o;
			bOpcode.head.opVariant.pos1 = _VariantFromObjRef(indexObjP);
			bOpcode.head.opVariant.pos2 = _VariantFromObjRef(value);
			_FillParam(bicRecP, indexObjP, PARAM_1_P(&bOpcode), &isExt, nil);
			_FillParam(bicRecP, value, PARAM_2_P(&bOpcode), &isExt, nil);
		}
	}
	else
	{	
	normalStatic:
		bOpcode.head.dest = (short)sl_index;
		if (putResultOnStack)
			bOpcode.head.opCode = kSetPutOnStack_o;
		else
			bOpcode.head.opCode = kSet_o;
		bOpcode.head.opVariant.pos1 = 0;
		bOpcode.head.opVariant.pos2 = _VariantFromObjRef(value);
		_FillParam(bicRecP, value, PARAM_2_P(&bOpcode), &isExt, &temp);
		totLessStack += propertyDim + temp;
	}
	if (noLessStack)
		totLessStack = 0;
	err = _AddOpcode(bicRecP, &bOpcode, isExt, totLessStack);

return err;
}

//===========================================================================================
XErr	Opcode_get(BICRecordP bicRecP, long sl_index, int totLessStack, Byte *param2, Boolean isExt, Byte variant2, long opCode, long dest)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	bOpcode.head.dest = (short)dest;
	bOpcode.head.opCode = (Byte)opCode;
	bOpcode.head.opVariant.pos1 = kVariantSL;
	bOpcode.head.opVariant.pos2 = variant2;
	PARAM_1_SHORT(&bOpcode) = (short)sl_index;
	if (isExt)
		CopyBlock(PARAM_2_P(&bOpcode), param2, MAX_PARAM2_SIZE);
	else
		CopyBlock(PARAM_2_P(&bOpcode), param2, sizeof(short));
	err = _AddOpcode(bicRecP, &bOpcode, isExt, totLessStack);

return err;
}

//===========================================================================================
XErr	Opcode_invoke(BICRecordP bicRecP, long sl_index, Byte opCode, int totLessStack, long moreStacks, long returnClassID)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
int			i, idx;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	if (returnClassID)
		bOpcode.head.dest = SP;
	else
		bOpcode.head.dest = 0;
	bOpcode.head.opCode = opCode;
	PARAM_1_SHORT(&bOpcode) = (short)sl_index;
	bOpcode.head.opVariant.pos1 = kVariantSL;
	if NOT(err = _AddOpcode(bicRecP, &bOpcode, false, totLessStack))
	{	idx = bicRecP->totOpcodes - 1;
		for (i = 0; i < moreStacks; i++)
			MoreStack(bicRecP, idx);
	}
	
return err;
}

//===========================================================================================
XErr	Opcode_load(BICRecordP bicRecP, ObjRecordP objRefP)
{
XErr			err = noErr;
	
	if (objRefP)
	{
		if ((BIC_OBJREF_SPEC(objRefP) == kVL_LIST) && (objRefP->id == SP))	// load stack on stack make no sense
		{	
			return noErr;
		}
		err = Opcode_OneParam(bicRecP, objRefP, kLoad_o);
	}
	else
	{
		err = Opcode_NoParams(bicRecP, kLoadDefault_o);
	}
	
return err;
}

//===========================================================================================
XErr	Opcode_branch(BICRecordP bicRecP, ObjRecordP objRefP, long offset, long which, long api_data)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
Boolean		res;
ObjRecord	tempObjRef;
int			lessStack = 0;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	BRANCH_OFFSET(&bOpcode) = offset;	// lo riempir� dopo
	if ((which == kBra_o) || (which == kBnse_o))
		bOpcode.head.opCode = (Byte)which;
	else
	{	if (BIC_OBJREF_SPEC(objRefP) == kVL_LIST)
		{	if (objRefP->type == IMMEDIATE_ID)	// optimization
			{	res = (Boolean)objRefP->scope;
				goto doBra;
			}
			else
			{	bOpcode.head.opCode = (Byte)which;
				BRANCH_TESTVAR(&bOpcode) = (short)objRefP->id;
				if (objRefP->id == SP)
					lessStack++; 
				//PARAM_2_SHORT(&bOpcode) = objRefP->id;
			}
		}
		else	// posso saperlo ora (un bra assoluto)
		{	INVAL(tempObjRef);
			BIC_GetRealObjRef(bicRecP, objRefP, &tempObjRef);
			if NOT(err = BAPI_ObjToBoolean(api_data, OBJREF_P(&tempObjRef), &res, kExplicitTypeCast))
			{	
			doBra:
				if (res && (which == kBet_o))
					bOpcode.head.opCode = kBra_o;
				else if (NOT(res) && (which == kBef_o))
					bOpcode.head.opCode = kBra_o;
				else
					bOpcode.head.opCode = 0;	// do nothing
			}
		}
	}
	if (NOT(err) && bOpcode.head.opCode)
	{	if NOT(err = _AddOpcode(bicRecP, &bOpcode, false, lessStack))
			bicRecP->totBrs++;
	}
	
return err;
}

//===========================================================================================
/*XErr	Opcode_decrstack(BICRecordP bicRecP, long lessStack)
{
XErr		err = noErr;
B_OpcodeExt	bOpCode;

	ClearBlock(&bOpCode, sizeof(B_OpcodeExt));
	bOpCode.head.dest = 0;
	bOpCode.head.opCode = kDecrStack_o;
	bOpCode.head.opVariant.pos1 = kVariantNumber;
	*(short*)bOpCode.params = lessStack;
	err = _AddOpcode(bicRecP, &bOpCode, false, 1);

return err;
}

//===========================================================================================
XErr	Opcode_copy(BICRecordP bicRecP, long destID)
{
XErr		err = noErr;
B_OpcodeExt	bOpCode;

	ClearBlock(&bOpCode, sizeof(B_OpcodeExt));
	bOpCode.head.dest = destID;
	bOpCode.head.opCode = kCopy_o;
	bOpCode.head.opVariant.pos1 = kVariantVL_LIST;
	bOpCode.head.opVariant.pos2 = kVariantVL_LIST;
	*(short*)bOpCode.params = SP;
	err = _AddOpcode(bicRecP, &bOpCode, false, 1);

return err;
}*/

//===========================================================================================
XErr	Opcode_store(BICRecordP bicRecP, ObjRecordP objLeftP, ObjRecordP objRightP, ArrayIndexRec *mCoords, long mCoordDim)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
long		totSize;
Ptr			opcodesPtr;
Boolean		isExt, isIndexExt, isRightValueExt;
int			lessStack = 0;
ObjRecordP	indexObjP;
Byte		*p;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	if (NOT(SMART_STORE_DISABLED(bicRecP)) && NOT(BIC_IS_IMM(objRightP)) && (objRightP->id == SP) && bicRecP->totOpcodes && NOT(mCoordDim))
	{	
	OpcodeHead	*opHeadP;
		
		// last opcode dest -> this opcode dest
		// Get last opcode
		BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
		opHeadP = (OpcodeHead*)(opcodesPtr + totSize - bicRecP->lastOpcodeSize);
		// set dest of last opcode -> dest of this store
		if (opHeadP->dest == SP)
		{	opHeadP->dest = (short)objLeftP->id;
			LessStack(bicRecP, bicRecP->totOpcodes - 1, true);
		}
		else
			goto doStore;
	}
	else
	{	
	doStore:
		if ((BIC_OBJREF_SPEC(objLeftP) == kVL_LIST) && (objLeftP->id != SP))
			bOpcode.head.dest = (short)objLeftP->id;
		else
			CDebugStr("_Opcode_store: non doveva mai succedere");	
		if (mCoordDim)
		{	if ((BIC_OBJREF_SPEC(objRightP) == kVL_LIST) && (objRightP->id == SP))
				lessStack++;
			if (mCoordDim == 1)
			{	indexObjP = (ObjRecordP)mCoords;
				isIndexExt = ObjRefIsExt(indexObjP);
				isRightValueExt = ObjRefIsExt(objRightP);
				if (isIndexExt && isRightValueExt)
					goto elemN;
				else if (isIndexExt)
				{	bOpcode.head.opCode = kStoreElem_o;
					bOpcode.head.opVariant.pos1 = _VariantFromObjRef(indexObjP);
					bOpcode.head.opVariant.pos2 = _VariantFromObjRef(objRightP);
					_FillParam(bicRecP, indexObjP, PARAM_1_P(&bOpcode), &isExt, nil);
					if (isExt)
						p = bOpcode.params + MAX_PARAM2_SIZE;
					else
						p = bOpcode.params + sizeof(short);
					_FillParam(bicRecP, objRightP, p, nil, nil);
				}
				else if (isRightValueExt)
				{	if ((BIC_OBJREF_SPEC(indexObjP) == kVL_LIST) && (indexObjP->id == SP))
						lessStack++;
					bOpcode.head.opCode = kStoreElem_o;
					bOpcode.head.opVariant.pos1 = _VariantFromObjRef(indexObjP);
					bOpcode.head.opVariant.pos2 = _VariantFromObjRef(objRightP);
					_FillParam(bicRecP, indexObjP, PARAM_1_P(&bOpcode), &isExt, nil);
					if (isExt)
						p = bOpcode.params + MAX_PARAM2_SIZE;
					else
						p = bOpcode.params + sizeof(short);
					_FillParam(bicRecP, objRightP, p, &isExt, nil);
					isExt = true;
				}
				else
				{	if ((BIC_OBJREF_SPEC(indexObjP) == kVL_LIST) && (indexObjP->id == SP))
						lessStack++;
					bOpcode.head.opCode = kStoreElem_o;
					bOpcode.head.opVariant.pos1 = _VariantFromObjRef(indexObjP);
					bOpcode.head.opVariant.pos2 = _VariantFromObjRef(objRightP);
					_FillParam(bicRecP, indexObjP, PARAM_1_P(&bOpcode), &isExt, nil);
					_FillParam(bicRecP, objRightP, PARAM_2_P(&bOpcode), &isExt, nil);
				}
			}
			else
			{	
			elemN:
				bOpcode.head.opCode = kStoreElemN_o;
				PARAM_1_SHORT(&bOpcode) = (short)mCoordDim;
				bOpcode.head.opVariant.pos1 = kVariantNumber;
				bOpcode.head.opVariant.pos2 = _VariantFromObjRef(objRightP);
				_FillParam(bicRecP, objRightP, PARAM_2_P(&bOpcode), &isExt, nil);
			}
		}
		else
		{	bOpcode.head.opCode = kStore_o;
			// bOpcode.head.param1	= 0;	// param1 is unused
			bOpcode.head.opVariant.pos1 = _VariantFromObjRef(objRightP);
			bOpcode.head.opVariant.pos2 = 0;
			_FillParam(bicRecP, objRightP, PARAM_1_P(&bOpcode), &isExt, &lessStack);
		}
		if NOT(err)
		{	if (bOpcode.head.opCode == kStoreElemN_o)
				lessStack += mCoordDim;
			// next will put incr
			/*if (bicRecP->postIncrType && (BIC_OBJREF_SPEC(objRightP) == kVL_LIST) && (objRightP->id == bicRecP->postIncrObjRef.id))
				ignorePostIncr = true;
			else
				ignorePostIncr = false;*/
			if NOT(err = _AddOpcode(bicRecP, &bOpcode, isExt, lessStack))
			{	/* Ottimizzazione:
				se ci fosse un branch dopo (cos� lo fa immediato)
					if (r = '')
						...
					
				o per un load di array o altro sullo stack:
					print(a[1][80] = 90)
				
				cos� carica 90 (e non a che sarebbe sbagliato)
					
				*/
				if (BIC_OBJREF_SPEC(objRightP) != kVL_LIST)
				{
					*objLeftP = *objRightP;
				/*ObjRecord	tempObjRef;
				Boolean		res;
				
					INVAL(tempObjRef);
					BIC_GetRealObjRef(bicRecP, objRightP, &tempObjRef);
					if NOT(err = BAPI_ObjToBoolean(api_data, OBJREF_P(&tempObjRef), &res, kExplicitTypeCast))
					{	objLeftP->type = 0;
						BIC_OBJREF_SPEC(objLeftP) = kImmediateValue;
						objLeftP->classID = kBooleanClassID;
						*(Boolean*)BIC_IMM_P(objLeftP) = res;
					}*/
				}
				else
				{	objLeftP->type = 0;
					objLeftP->scope = 0;
				}
			}
		}
	}
			
return err;
}

//===========================================================================================
XErr	Opcode_opposite(BICRecordP bicRecP, ObjRecordP objP, ObjRecordP resultP)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
int			lessStack = 0;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	bOpcode.head.opCode = kInvert_o;
	bOpcode.head.dest = SP;
	PARAM_1_SHORT(&bOpcode) = (short)objP->id;
	bOpcode.head.opVariant.pos1 = kVariantVL_LIST;
	if (objP->id == SP)
		lessStack++;
	if NOT(err = _AddOpcode(bicRecP, &bOpcode, false, lessStack))
	{	resultP->type = 0;
		BIC_OBJREF_SPEC(resultP) = kVL_LIST;
		resultP->classID = 0;
		resultP->id = SP;
		resultP->scope = 0;
		resultP->list = 0;
	}
		
return err;
}

//===========================================================================================
XErr	Opcode_index(BICRecordP bicRecP, ObjRecordP arrayObjrecP, ArrayIndexRec *mCoords, long dim, long opcode, long dest)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
Boolean		isExt;
ObjRecordP	indexObjIdP;
int			lessStack;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	bOpcode.head.dest = (short)dest;
	PARAM_1_SHORT(&bOpcode) = (short)arrayObjrecP->id;
	bOpcode.head.opVariant.pos1 = kVariantVL_LIST;
	if (dim == 1)
	{	bOpcode.head.opCode = (Byte)opcode;
		indexObjIdP = (ObjRecordP)mCoords;
		bOpcode.head.opVariant.pos2 = _VariantFromObjRef(indexObjIdP);
		_FillParam(bicRecP, indexObjIdP, PARAM_2_P(&bOpcode), &isExt, &lessStack);
		if ((bOpcode.head.opCode == kIndexLeaveOnStack_o) && NOT(IS_SP(indexObjIdP)))
			bOpcode.head.opCode = kIndex_o;
		err = _AddOpcode(bicRecP, &bOpcode, isExt, lessStack);
	}
	else
	{	bOpcode.head.opCode = (Byte)opcode + 1;
		bOpcode.head.opVariant.pos1 = kVariantVL_LIST;
		bOpcode.head.opVariant.pos2 = kVariantNumber;
		PARAM_2_SHORT(&bOpcode) = (short)dim;
		indexObjIdP = (ObjRecordP)mCoords;
		if (opcode == kIndexLeaveOnStack_o)
			lessStack = 0;
		else
			lessStack = dim;
		err = _AddOpcode(bicRecP, &bOpcode, false, lessStack);
	}
	
return err;
}

//===========================================================================================
XErr	Opcode_operation(BICRecordP bicRecP, ObjRecordP obj1, ObjRecordP obj2, long opcode, long operation, ObjRecordP resultP, long api_data)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;
Boolean		isExt;
ObjRecord	tempObjRef1, tempObjRef2, resultVarRec;
int			lessStack = 0;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	bOpcode.head.opCode = (Byte)opcode;
	bOpcode.head.dest = SP;
	if ((BIC_OBJREF_SPEC(obj1) != kVL_LIST) && (BIC_OBJREF_SPEC(obj2) != kVL_LIST))	// lo posso risolvere subito?
	{	BIC_GetRealObjRef(bicRecP, obj1, &tempObjRef1);
		BIC_GetRealObjRef(bicRecP, obj2, &tempObjRef2);
		INVAL(resultVarRec);
		if NOT(err = BAPI_ExecuteOperation(api_data, OBJREF_P(&tempObjRef1), OBJREF_P(&tempObjRef2), operation, OBJREF_P(&resultVarRec)))
			err = BIC_GetBicObjRef(api_data, &resultVarRec, resultP);
	}
	else
	{	bOpcode.head.opVariant.pos1 = _VariantFromObjRef(obj1);
		bOpcode.head.opVariant.pos2 = _VariantFromObjRef(obj2);
		if BIC_IS_IMM(obj1)
		{	_FillParam(bicRecP, obj1, PARAM_1_P(&bOpcode), &isExt, &lessStack);
			if (isExt)
				PARAM_2_AFTER_LARGE(&bOpcode) = (short)obj2->id;
			else
				PARAM_2_SHORT(&bOpcode)	= (short)obj2->id;
			if (obj2->id == SP)
				lessStack++;
		}
		else if BIC_IS_IMM(obj2)
		{	PARAM_1_SHORT(&bOpcode)	= (short)obj1->id;
			_FillParam(bicRecP, obj2, PARAM_2_P(&bOpcode), &isExt, &lessStack);
			if (obj1->id == SP)
				lessStack++;
		}
		else	// Both VL or SP
		{	PARAM_1_SHORT(&bOpcode)	= (short)obj1->id;
			PARAM_2_SHORT(&bOpcode)	= (short)obj2->id;
			isExt = false;
			if (obj1->id == SP)
				lessStack++;
			if (obj2->id == SP)
				lessStack++;
		}
		if NOT(err = _AddOpcode(bicRecP, &bOpcode, isExt, lessStack))
		{	resultP->type = 0;
			BIC_OBJREF_SPEC(resultP) = kVL_LIST;
			resultP->classID = 0;
			resultP->id = SP;
			resultP->scope = 0;
			resultP->list = 0;
		}
	}

return err;
}

//===========================================================================================
XErr	Opcode_NoParams(BICRecordP bicRecP, long which)
{
XErr		err = noErr;
B_OpcodeExt	bOpcode;

	ClearBlock(&bOpcode, sizeof(B_OpcodeExt));
	bOpcode.head.opCode = (Byte)which;
	err = _AddOpcode(bicRecP, &bOpcode, false, 0);

return err;
}

//===========================================================================================
XErr	Opcode_OneParam(BICRecordP bicRecP, ObjRecordP objRefP, long which)
{
XErr		err = noErr;
B_OpcodeExt	bOpCode;
Boolean		isExt;
int			lessStack;

	ClearBlock(&bOpCode, sizeof(B_OpcodeExt));
	bOpCode.head.opCode = (Byte)which;
	bOpCode.head.opVariant.pos1 = _VariantFromObjRef(objRefP);
	_FillParam(bicRecP, objRefP, bOpCode.params, &isExt, &lessStack);
	err = _AddOpcode(bicRecP, &bOpCode, isExt, lessStack);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	DumpAssembler(BICRecordP bicRecP, long outputID)
{
XErr			err = noErr;
Ptr				saveOpcodesPtr, opcodesPtr;
BlockRef		opStackBlockRef, block;
long			a, offset, index, totOpcodes, totSize;
CStr255			tStr, tStr2, aCStr;
OpStackInfoP	opStackP;

	if (totOpcodes = bicRecP->totOpcodes)
	{	block = BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, &opcodesPtr);
		LockBlock(block);
		index = 1;
		offset = 0;
		opStackBlockRef = BufferGetBlockRefExt(bicRecP->opcodesStack, (Ptr*)&opStackP);
		LockBlock(opStackBlockRef);
		do {
			CNumToString(index++, tStr2);
			CEquStr(tStr, "<tr><td width=30><pre>");
			CAddStr(tStr, tStr2);
			
			CAddStr(tStr, "</pre></td><td width=30><pre>");
			CNumToString(offset, tStr2);
			CAddStr(tStr, tStr2);

			CAddStr(tStr, "</pre></td><td width=30><pre>");
			if (a = opStackP->countStack)
			{	CAddStr(tStr, "<font color=\"red\">");
				CNumToString(a, tStr2);
				CAddStr(tStr, tStr2);
				CAddStr(tStr, "</font>");
			}

			CAddStr(tStr, "</pre></td><td width=30><pre>");
			if (a = opStackP->incr_stack)
			{	CAddStr(tStr, "+");
				CNumToString(opStackP->incr_stack, tStr2);
				CAddStr(tStr, tStr2);
			}
			
			CAddStr(tStr, "</pre></td><td width=30><pre>");
			if (a = opStackP->decr_stack)
			{	CAddStr(tStr, "-");
				CNumToString(opStackP->decr_stack, tStr2);
				CAddStr(tStr, tStr2);
			}
			
			CAddStr(tStr, "</pre></td><td><pre>");
			if NOT(err = BufferAddCString(outputID, tStr, NO_ENC, 0))
			{	saveOpcodesPtr = opcodesPtr;
				opcodesPtr += _DumpOpcode(outputID, offset, (B_Opcode*)opcodesPtr, &err);
				offset += (opcodesPtr - saveOpcodesPtr);
			}
			CEquStr(tStr, "</pre></td></tr>\r\n");
			err = BufferAddCString(outputID, tStr, NO_ENC, 0);
			opStackP++;
		} while (NOT(err) && --totOpcodes);
		UnlockBlock(opStackBlockRef);
		UnlockBlock(block);
		if NOT(err)
		{	CEquStr(aCStr, "<tr><td align=\"left\"><pre><b>Total: ");
			CNumToString(totSize, tStr);
			CAddStr(aCStr, tStr);
			CAddStr(aCStr, "</pre></td></tr></b>\r\n");
			err = BufferAddCString(outputID, aCStr, NO_ENC, 0);
		}
	}

return err;
}

//===========================================================================================
/*XErr	RemoveOpcode(BICRecord *bicRecP, long opcodeOffset, long opcodeSize)
{
long		sizeToCopy, totSize;
OpcodeHead	*sourceP, *destP, *opcodesPtr;

	BufferGetBlockRefExtSize(bicRecP->opcodesBufferID, &totSize, (Ptr*)&opcodesPtr);
	destP = (OpcodeHead*)((Ptr)opcodesPtr + opcodeOffset);
	sourceP = (OpcodeHead*)((Ptr)opcodesPtr + opcodeOffset + opcodeSize);
	sizeToCopy = totSize - opcodeOffset - opcodeSize;
	CopyBlock(destP, sourceP, sizeToCopy);
	BufferSetLength(bicRecP->opcodesBufferID, totSize - opcodeSize);
	bicRecP->totOpcodes--;
	
return noErr;
}*/

//===========================================================================================
/*XErr	GenerateOpCode(long api_data, BICRecordP bicRecP, ObjRecordP objLeftP, ObjRecordP objRightP, BICOpcode opcodeType, long data)
{
XErr	err = noErr;

	switch(opcodeType)
	{
		case kStore_o:
			err = _Opcode_store(bicRecP, objLeftP, objRightP);
			break;
		case kMul_o:
		case kDiv_o:
		case kMod_o:
		case kAdd_o:
		case kSub_o:
		case kShiftL_o:
		case kShiftR_o:
		case kGreat_o:
		case kLess_o:
		case kGreatE_o:
		case kLessE_o:
		case kEqua_o:
		case kNotEqua_o:
		case kArAnd_o:
		case kArOr_o:
		case kLogicAnd_o:
		case kLogicOr_o:
			err = _Opcode_operation(api_data, bicRecP, opcodeType, objLeftP, objRightP, data);
			break;

		case kExit_o:
			err = _Opcode_NoParams(bicRecP, kExit_o);
			break;
		case kDebug_o:
			err = _Opcode_NoParams(bicRecP, kDebug_o);
			break;
			
		case kPrint_o:
			err = _Opcode_OneParam(bicRecP, objLeftP, kPrint_o);
			break;
			
		case kBef_o:
		case kBet_o:
			err = _Opcode_branch(api_data, bicRecP, objLeftP, opcodeType);
			break;
			
	}

return err;
}*/
