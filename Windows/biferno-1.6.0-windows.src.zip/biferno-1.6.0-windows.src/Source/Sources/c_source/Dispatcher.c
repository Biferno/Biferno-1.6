/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Dispatcher.c,v 1.70 2008-11-27 15:27:48 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"
#ifdef __MAC_XLIB__
	#include "XFilesMacPrivate.h"
#endif


#include "HTTPMgr.h"

#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "BfrVersion.h"
#include "Flower.h"
#include "Dispatcher.h"
#include "Variable.h"
#include "Eval.h"
#include "BifernoErrors.h"
#include "Load.h"
#include "Entity.h"
#include "BfrParser.h"
#include "Application.h"
#include "Param.h"
#include "Volatile.h"
#include "Run.h"

#include "StaticClasses.h"
#include "BifernoAPI_DLL.h"

//#include "BJNI.h"
#include "Classes.h"
#include "CDivert.h"

#include "Reference.h"
#include "Multipart.h"
#include "HttpPage.h"
#include "BfrError.h"

#include <string.h>

extern NameValueRec					gsKeyword[];
extern NameValueRec					gsFlowControls[];
extern BlockRef						gsCallBacksBlock;
extern PluginRecord					*gClassRecordBlockP;
extern BlockRef						gDefaultsBlock;
extern long							gTotDefaults;
extern Boolean						gsLocally;
extern NameValueRec					gsKeyword[], gsFlowControls[];	
extern BAPIErrorRecord				gBifernoErrorsRec[];
extern long							gsBifernoCurrentUsers;
extern DispatcherData				gsDispatcherData;
extern Biferno_Dispatch				gStaticClassEntryPoint[MAX_STATIC_CLASSES];
extern long							gTotStaticClasses;
extern long							gRunID;
extern Ref_GetTargetClassCallBack	ref_GetTargetClass;
extern Ref_GetTargetCallBack		ref_GetTarget;
extern Page_PrintCallBack			page_Print;
extern Page_GetOutputCallBack		page_GetOutput;
extern Ref_NewReferenceCallBack		ref_NewReference;
extern Multipart_NewObjectCallBack	multiPart_NewObject;
//extern Error_UpdateEMsgRecordCallBack	error_UpdateEMsgRecord; 
extern CStr255						gPersistentFolder;

//extern Ref_SetTargetCallBack		ref_SetTarget;

extern BAPI_ModifyHook 				gsRefModifyHook;

#define	START_BCONFIG_SCRIPT	"============= BEGIN BIFERNO.config SCRIPT OUTPUT ==="
#define	END_BCONFIG_SCRIPT		"============= END BIFERNO.config SCRIPT OUTPUT ====="

#define	UNKNOWN	"Unknown"

typedef struct {
				CStr63		pluginName;
				long		idInOriginalList;
				CStr63		priorityPluginName;
				} PluginRecordLight, *PluginRecordLightP;

#define	TOT_RESERVED_KEYWORDS	21
NameValueRec	gsKeyword[TOT_RESERVED_KEYWORDS] = 
					{	"local",		LOCAL,
						"global",		GLOBAL,
						"application",	APPLICATION,
						"session",		SESSION,
						"persistent",	PERSISTENT,

						"var",			VARIABLE,
						"const",		CONSTANT,

						"true",			true,
						"false",		false,
						
						"type",			1,
						"class",		1,
						"scope",		1,

						"this",			_kTHIS,
						"public",		_kPUBLIC,
						"private",		_kPRIVATE,
						"protected",	_kPROTECTED,
						"static",		_kSTATIC,
						"super",		_kSUPER,
						
						"obj",			_kOBJ,
						"nonames",		_kNoNames,
												
						"target",		0
					};

#define	TOT_FLOW_CONTROLS		21
NameValueRec	gsFlowControls[TOT_FLOW_CONTROLS] = 
					{	"exit",			k_Exit,
						"stop",			k_Stop,
						"for",			k_For,
						"do",			k_Do,
						"while",		k_While,
						"if",			k_If,
						"else",			k_Else,
						"break",		k_Break,
						"continue",		k_Continue,
						"switch",		k_Switch,
						"case",			k_Case,
						"default",		k_Default,
						"include",		k_Include,
						"lock",			k_Lock,
						"unlock",		k_Unlock,
						"debug",		k_Debug,
						"goto",			k_Goto,
						"function",		k_Function,
						"class",		k_Class,
						"return",		k_Return
					};

//===========================================================================================
/*void	VersionToString(long version, char *versionStr, Boolean alsoDev)
{
Byte	majorVers, middleVers, minorVers;
CStr15	tempStr;

#ifdef __LITTLE_ENDIAN__
	majorVers = *(Byte*)((Ptr)&version+2);
	middleVers = *(Byte*)((Ptr)&version+1);
	minorVers = *(Byte*)((Ptr)&version);
	CNumToString(majorVers, versionStr);
	CAddChar(versionStr, '.');
	CNumToString(middleVers, tempStr);
	CAddStr(versionStr, tempStr);
	if (minorVers)
	{	CAddChar(versionStr, '.');
		CNumToString(minorVers, tempStr);
		CAddStr(versionStr, tempStr);
	}
#else
	majorVers = *(Byte*)((Ptr)&version+1);
	middleVers = *(Byte*)((Ptr)&version+2);
	minorVers = *(Byte*)((Ptr)&version+3);
	CNumToString(majorVers, versionStr);
	CAddChar(versionStr, '.');
	CNumToString(middleVers, tempStr);
	CAddStr(versionStr, tempStr);
	if (minorVers)
	{	CAddChar(versionStr, '.');
		CNumToString(minorVers, tempStr);
		CAddStr(versionStr, tempStr);
	}
#endif
	if (alsoDev)
		CAddStr(versionStr, DEVELOPMENT_VERS_STR);
}
*/
//===========================================================================================
static void	_GetPriority(PluginRecord *plugRec1P, PluginRecord *plugRec2P, long operation, long *priority1P, long *priority2P)
{
	switch (operation)
	{
		case EVAL_MULT:
		case EVAL_DIV:
		case EVAL_MOD:
		case EVAL_ADD:
		case EVAL_MINUS:
		case EVAL_SHIFTR:
		case EVAL_SHIFTL:
		case EVAL_GTH:
		case EVAL_LTH:
		case EVAL_GEQ:
		case EVAL_LEQ:
			if (plugRec1P)
				*priority1P = plugRec1P->oper_priority;
			else
				*priority1P = 0;
			if (plugRec2P)
				*priority2P = plugRec2P->oper_priority;
			else
				*priority2P = 0;
			break;
		case EVAL_EQUA:
		case EVAL_NEQUA:
			if (plugRec1P)
				*priority1P = plugRec1P->compare_priority;
			else
				*priority1P = 0;
			if (plugRec2P)
				*priority2P = plugRec2P->compare_priority;
			else
				*priority2P = 0;
			break;
		case EVAL_ARAND:
		case EVAL_AROR:
			if (plugRec1P)
				*priority1P = plugRec1P->oper_priority;
			else
				*priority1P = 0;
			if (plugRec2P)
				*priority2P = plugRec2P->oper_priority;
			else
				*priority2P = 0;
			break;
	}
}

//===========================================================================================
/*static XErr	_HTUUEnc(char *stringP, long stringLen, BlockRef *passEnc, long *passEncLenP)
{	
long		rest, blockLen;
BlockRef	resultBlock;
XErr		err = noErr;
Ptr			resultP;

	rest = 3 - (stringLen % 3);
	if ((stringLen + rest) > 48)
		return -1;
	blockLen = 5 + (4*stringLen)/3;
	if (resultBlock = NewBlock(blockLen, &err))
	{	LockBlock(resultBlock);
		resultP = GetPtr(resultBlock);
		*passEncLenP = HTUU_encode((Byte*)stringP, stringLen, resultP);
		*passEnc = resultBlock;
	}
	
return err;
}

//===========================================================================================
static XErr	_HTUUDec(char *stringP, long stringLen, BlockRef *passEnc, long *passEncLenP)
{	
BlockRef	resultBlock;
XErr		err = noErr;
Ptr			resultP;

	if (resultBlock = NewBlockClear(stringLen + 2, &err))
	{	LockBlock(resultBlock);
		resultP = GetPtr(resultBlock);
		*passEncLenP = HTUU_decode(stringP, (Byte*)resultP, stringLen);
		*passEnc = resultBlock;
	}
	
return err;
}

//===========================================================================================
static XErr		_PasswordFile(void)
{
XFileRef	fileRef;
XErr		err = noErr, err2 = noErr;
long		eof;
Ptr			textP;
BlockRef	block;
Boolean		fileEncoded = true, toDecode = false;
BlockRef	textEnc;
long		textEncLen;
CStr255		aCStr;

	*gSuperUser = 0;
	*gSuperPass = 0;
	err = OpenXFile(SUPER_PASSWORD_FILE, OPEN_FILE_EXISTING, READ_WRITE_PERM, false, &fileRef);
	if (err && (err == XError(kXLibError, ErrXFiles_FileNotFound)))
	{	err = OpenXFile(SUPER_PASSWORD_FILE_ENC, OPEN_FILE_EXISTING, READ_WRITE_PERM, false, &fileRef);
		if (err && (err == XError(kXLibError, ErrXFiles_FileNotFound)))
		{	err = OpenXFile(SUPER_PASSWORD_FILE_ENC_TODEC, OPEN_FILE_EXISTING, READ_WRITE_PERM, false, &fileRef);
			if NOT(err)
				toDecode = true;
		}
	}
	else
		fileEncoded = false;
	if NOT(err)
	{	if NOT(err = GetXEOF(fileRef, &eof))
		{	if (eof)
			{	if (block = NewBlock(eof, &err))
				{	LockBlock(block);
					textP = GetPtr(block);
					if NOT(err = ReadXFile(fileRef, textP, &eof))
					{	if (fileEncoded)
						{	if NOT(err = _HTUUDec(textP, eof, &textEnc, &textEncLen))
							{	CopyBlock(textP, GetPtr(textEnc), textEncLen);
								eof = textEncLen;
								DisposeBlock(&textEnc);
							}
						}
						if NOT(err)
						{	if NOT(err = GetEntityName(0, &textP, &eof, gSuperUser, true))
							{	SkipSpaceAndTabCRLF(&textP, &eof, nil);
								if NOT(err = GetEntityName(0, &textP, &eof, gSuperPass, true))
								{	if NOT(fileEncoded)
									{	CEquStr(aCStr, gSuperUser);
										CAddChar(aCStr, '\t');
										CAddStr(aCStr, gSuperPass);
										if NOT(err = _HTUUEnc(aCStr, CLen(aCStr), &textEnc, &textEncLen))
										{	if NOT(err = SetXFPos(fileRef, FROM_START, 0))
											{	if NOT(err = WriteXFile(fileRef, GetPtr(textEnc), &textEncLen))
													err = SetXEOF(fileRef, textEncLen);
											}
											DisposeBlock(&textEnc);
										}
									}
									else if (toDecode)
									{	CEquStr(aCStr, gSuperUser);
										CAddChar(aCStr, '\t');
										CAddStr(aCStr, gSuperPass);
										if NOT(err = SetXFPos(fileRef, FROM_START, 0))
										{	textEncLen = CLen(aCStr);
											if NOT(err = WriteXFile(fileRef, aCStr, &textEncLen))
												err = SetXEOF(fileRef, textEncLen);
										}
									}
								}
							}
						}
					}
					DisposeBlock(&block);
				}
			}
		}
		err2 = CloseXFile(&fileRef);
		if (err2 && NOT(err))
			err = err2;
		if NOT(err)
		{	if NOT(fileEncoded)
				err = RenameXFile(SUPER_PASSWORD_FILE, SUPER_PASSWORD_FILE_ENC);
			else if (toDecode)
				err = RenameXFile(SUPER_PASSWORD_FILE_ENC_TODEC, SUPER_PASSWORD_FILE);
		}
	}

return err;
}
*/
//===========================================================================================
static XErr	_FillGlobalErrorList(void)
{
DLMRef	list = gsDispatcherData.errorList;
XErr	err = noErr;
int		i, tot;
long	startErr;

	startErr = BIFERNO_BASE_ERROR;
	tot = Err_LastErr;
	for (i = 0; (i < tot) && NOT(err); i++, startErr++)
		DLM_NewObj(list, gBifernoErrorsRec[i].name, (Ptr)&startErr, sizeof(long), 0, 0, &err);

return err;
}

//===========================================================================================
static PluginRecord* _GetPluginRec(Biferno_ParamBlock *pbPtr, ObjRecord *varRecP)
{
PluginRecord*		plugRecP = nil;

	if (varRecP->classID > 0)
	{	plugRecP = &gClassRecordBlockP[varRecP->classID-1];
		if (pbPtr)
			pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
	}
	else	// < 0 BifernoClass
	{	plugRecP = nil;
		if (pbPtr)
			pbPtr->plugin_global_dataP = (uint32_t*)-varRecP->classID;
	}
	
	// for debug
	/*if (plugRecP)
	{	int		boole, a, b;
	
		a = varRecP->classID;
		b = varRecP->id;
		boole = plugRecP->wantDestructor;
	}*/
	
return plugRecP;
}

//===========================================================================================
static PluginRecord* _GetPluginRecFromClassID(Biferno_ParamBlock *pbPtr, long classID)
{
PluginRecord*		plugRecP;

	if (classID > 0)
	{	plugRecP = &gClassRecordBlockP[classID-1];
		if (pbPtr)
			pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
	}
	else	// < 0 BifernoClass
	{	plugRecP = nil;
		if (pbPtr)
			pbPtr->plugin_global_dataP = (uint32_t*)-classID;
	}
	
return plugRecP;
}

//===========================================================================================
PluginRecord* GetPluginRecFromClassID(Biferno_ParamBlock *pbPtr, long classID)
{
	return _GetPluginRecFromClassID(pbPtr, classID);
}

//===========================================================================================
Boolean	ContainsReference(ObjRecord *objRefP)
{
Boolean		result;
long		elemClassID;
XErr		err = noErr;

	if (DLM_IsArray(objRefP->list, objRefP->id))
	{	if NOT(err = DLM_GetArrayInfo(objRefP->list, objRefP->id, nil, nil, nil, &elemClassID))
		{	if (NOT(elemClassID) || (elemClassID == objRefP->classID))	// elem undefined or array of array
				result = true;
			else
				result = WantDestructorFromClass(elemClassID);
		}
	}
	else
		result = WantDestructorFromObj(objRefP);

return result;
}

//===========================================================================================
Boolean	WantDestructorFromObj(ObjRecord *varRecP)
{
PluginRecord*	plugRecP;
Boolean			wantDestructor;

	plugRecP = _GetPluginRec(nil, varRecP);
	if (plugRecP)
	{	if NOT(wantDestructor = plugRecP->wantDestructor)
		{	while (plugRecP->extendedPluginID)
			{	if (plugRecP = _GetPluginRecFromClassID(nil, plugRecP->extendedPluginID))
				{	if (wantDestructor = plugRecP->wantDestructor)
						break;
				}
				else
				{	wantDestructor = true;
					break;
				}
			}
		}
	}
	else
		wantDestructor = true;

return wantDestructor;
}

//===========================================================================================
Boolean	WantDestructorFromClass(long classID)
{
PluginRecord*	plugRecP;
Boolean			wantDestructor;

	plugRecP = _GetPluginRecFromClassID(nil, classID);
	if (plugRecP)
	{	if NOT(wantDestructor = plugRecP->wantDestructor)
		{	while (plugRecP->extendedPluginID)
			{	if (plugRecP = _GetPluginRecFromClassID(nil, plugRecP->extendedPluginID))
				{	if (wantDestructor = plugRecP->wantDestructor)
						break;
				}
				else
				{	wantDestructor = true;
					break;
				}
			}
		}
	}
	else
		wantDestructor = true;

return wantDestructor;
}

//===========================================================================================
/*static long	_MemberIdFromName(long *classIDP, char *memberName)
{
long			result = 0;
XErr			err = noErr;
long			membType, memberValue, memberObjID;
Boolean			found;


	if (*classIDP)
	{	if NOT(err = GetMemberInfo(*classIDP, memberName, 0, &memberValue, classIDP, &memberObjID, &membType, &found))
		{	result = memberValue;

		}
	}

return result;
}
*/
//===========================================================================================
static XErr	_RegisterDLLClass(long dllRef, long *pluginBAPIVersionP, char *dllErrStr, Boolean macosxBundle)
{
XErr		err = noErr;
XErr		(*_registerFunc)(long callsBackPtr);
long		(*_bapiVersionFunc)(XErr *errP);

	CEquStr(dllErrStr, "BAPI_PluginBAPIVersion");
	if NOT(err = XGetDLLSymbol(dllRef, "BAPI_PluginBAPIVersion", (long*)&_bapiVersionFunc, macosxBundle))
	{	*pluginBAPIVersionP = _bapiVersionFunc(&err);
		if NOT(err)
		{	CEquStr(dllErrStr, "RegisterCallBacks");
			if NOT(err = XGetDLLSymbol(dllRef, "RegisterCallBacks", (long*)&_registerFunc, macosxBundle))
			{	*dllErrStr = 0;
				err = _registerFunc((long)GetPtr(gsCallBacksBlock));
			}
		}
	}

return err;
}

//===========================================================================================
static	XErr	_InitCallBacksAPI(void)
{
CallBacksRec	*pData;
XErr			err = noErr;

	if (gsCallBacksBlock = NewBlockLocked(sizeof(CallBacksRec), &err, (Ptr*)&pData))
	{	//LockBlock(gsCallBacksBlock);
		//pData = (CallBacksRec*)GetPtr(gsCallBacksBlock);
		ClearBlock(pData, sizeof(CallBacksRec));
		
		// Eval
		pData->BAPI_Eval = (long)BAPI_Eval;
		pData->BAPI_ResetError = (long)BAPI_ResetError;
		
		// ObjRecord
		pData->BAPI_IsObjRefToDestruct = (long)BAPI_IsObjRefToDestruct;
		pData->BAPI_InvalObjRef = (long)BAPI_InvalObjRef;
		pData->BAPI_GetObjInfo = (long)BAPI_GetObjInfo;
		pData->BAPI_LocateObj = (long)BAPI_LocateObj;
		
		pData->BAPI_IsObjRefValid = (long)BAPI_IsObjRefValid;
		//pData->BAPI_InvalObjRef = (long)BAPI_InvalObjRef;
		pData->BAPI_GetObjClassID = (long)BAPI_GetObjClassID;
		
		pData->BAPI_SetObjClassID = (long)BAPI_SetObjClassID;
		pData->BAPI_SetObjScope = (long)BAPI_SetObjScope;
		pData->BAPI_SetObjType = (long)BAPI_SetObjType;

		pData->BAPI_GetObjScope = (long)BAPI_GetObjScope;
		pData->BAPI_GetObjType = (long)BAPI_GetObjType;
		pData->BAPI_NeedSerialize = (long)BAPI_NeedSerialize;

		// New Members
		pData->BAPI_NewProperties = (long)BAPI_NewProperties;
		pData->BAPI_NewMethods = (long)BAPI_NewMethods;
		pData->BAPI_RegisterErrors = (long)BAPI_RegisterErrors;
		pData->BAPI_NewFunctions = (long)BAPI_NewFunctions;
		pData->BAPI_NewConstants = (long)BAPI_NewConstants;
		pData->BAPI_NewApplicationDefault = (long)BAPI_NewApplicationDefault;
		
		// New Obj
		pData->BAPI_BufferToObj = (long)BAPI_BufferToObj;
		pData->BAPI_ScopeID = (long)BAPI_ScopeID;
		pData->BAPI_ConstructorScope = (long)BAPI_ConstructorScope;
		
		// Super Obj
		pData->BAPI_BufferToObjWithSuper = (long)BAPI_BufferToObjWithSuper;
		pData->BAPI_SetSuperObj = (long)BAPI_SetSuperObj;
		pData->BAPI_GetSuperObj = (long)BAPI_GetSuperObj;

		// Temporaneous objects
		pData->BAPI_IntToObj = (long)BAPI_IntToObj;
		pData->BAPI_LongToObj = (long)BAPI_LongToObj;
		pData->BAPI_UnsignedToObj = (long)BAPI_UnsignedToObj;
		pData->BAPI_DoubleToObj = (long)BAPI_DoubleToObj;
		pData->BAPI_BooleanToObj = (long)BAPI_BooleanToObj;
		//pData->BAPI_StringToConstObj = (long)BAPI_StringToConstObj;
		pData->BAPI_StringToObj = (long)BAPI_StringToObj;
		pData->BAPI_CharToObj = (long)BAPI_CharToObj;
		pData->BAPI_ArrayToObj = (long)BAPI_ArrayToObj;

		/*pData->BAPI_ReturnInt = (long)BAPI_ReturnInt;
		pData->BAPI_ReturnLong = (long)BAPI_ReturnLong;
		pData->BAPI_ReturnUnsigned = (long)BAPI_ReturnUnsigned;
		pData->BAPI_ReturnDouble = (long)BAPI_ReturnDouble;
		pData->BAPI_ReturnBoolean = (long)BAPI_ReturnBoolean;
		pData->BAPI_ReturnString = (long)BAPI_ReturnString;
		pData->BAPI_ReturnChar = (long)BAPI_ReturnChar;
		pData->BAPI_ReturnArray = (long)BAPI_ReturnArray;
		pData->BAPI_ReturnObject = (long)BAPI_ReturnObject;*/

		// Modify Objs
		pData->BAPI_ModifyObj = (long)BAPI_ModifyObj;
		pData->BAPI_ReplaceObj = (long)BAPI_ReplaceObj;
		pData->BAPI_WriteObj = (long)BAPI_WriteObj;
		pData->BAPI_ModifyObjClassID = (long)BAPI_ModifyObjClassID;
		pData->BAPI_LockObj = (long)BAPI_LockObj;
		pData->BAPI_UnlockObj = (long)BAPI_UnlockObj;
		//pData->BAPI_FreeObj = (long)BAPI_FreeObj;
		
		// Convert Objs to C types
		pData->BAPI_ObjToInt = (long)BAPI_ObjToInt;
		pData->BAPI_ObjToLong = (long)BAPI_ObjToLong;
		pData->BAPI_ObjToUnsigned = (long)BAPI_ObjToUnsigned;
		pData->BAPI_ObjToBoolean = (long)BAPI_ObjToBoolean;
		pData->BAPI_ObjToDouble = (long)BAPI_ObjToDouble;
		pData->BAPI_ObjToString = (long)BAPI_ObjToString;
		pData->BAPI_ObjToChar = (long)BAPI_ObjToChar;
		pData->BAPI_ObjToConstrString = (long)BAPI_ObjToConstrString;
		pData->BAPI_ObjToDebugString = (long)BAPI_ObjToDebugString;
		pData->BAPI_ReadObj = (long)BAPI_ReadObj;
		pData->BAPI_GetObj = (long)BAPI_GetObj;
		pData->BAPI_GetStringBlock = (long)BAPI_GetStringBlock;
		pData->BAPI_GetStringBlockExt = (long)BAPI_GetStringBlockExt;
		pData->BAPI_GetObjBlock = (long)BAPI_GetObjBlock;
		pData->BAPI_ReleaseBlock = (long)BAPI_ReleaseBlock;

		// Operations on object
		pData->BAPI_ConcatObjs = (long)BAPI_ConcatObjs;
		pData->BAPI_CopyObj = (long)BAPI_CopyObj;
		//pData->BAPI_CloneObj = (long)BAPI_CloneObj;
		pData->BAPI_GetPublishedVar = (long)BAPI_GetPublishedVar;
		pData->BAPI_AvoidDestructor = (long)BAPI_AvoidDestructor;
		pData->BAPI_ForceDestructor = (long)BAPI_ForceDestructor;
		pData->BAPI_SetArrayElemName = (long)BAPI_SetArrayElemName;

		// Arrays
		//pData->BAPI_NewArray = (long)BAPI_NewArray;
		pData->BAPI_GetArrayInfo = (long)BAPI_GetArrayInfo;
		pData->BAPI_SetArrayElemClass = (long)BAPI_SetArrayElemClass;
		pData->BAPI_SetArrayDim = (long)BAPI_SetArrayDim;
		//pData->BAPI_ResolveArrayElem = (long)BAPI_ResolveArrayElem;
		pData->BAPI_ElementOfArray = (long)BAPI_ElementOfArray;
		pData->BAPI_ElementOfArrayExt = (long)BAPI_ElementOfArrayExt;
		pData->BAPI_ArrayLoop = (long)BAPI_ArrayLoop;
		pData->BAPI_ArrayAddElement = (long)BAPI_ArrayAddElement;
		pData->BAPI_ArrayDelete = (long)BAPI_ArrayDelete;
		pData->BAPI_ArraySwap = (long)BAPI_ArraySwap;
		pData->BAPI_ArrayReverse = (long)BAPI_ArrayReverse;
		pData->BAPI_ArraySort = (long)BAPI_ArraySort;
		pData->BAPI_ArrayInsert = (long)BAPI_ArrayInsert;
		pData->BAPI_ArrayReset = (long)BAPI_ArrayReset;
		pData->BAPI_ArrayConcat = (long)BAPI_ArrayConcat;

		// Access to other classes
		pData->BAPI_Accessor = (long)BAPI_Accessor;
		pData->BAPI_Constructor = (long)BAPI_Constructor;
		pData->BAPI_Clone = (long)BAPI_Clone;
		pData->BAPI_Destructor = (long)BAPI_Destructor;
		pData->BAPI_ExecuteOperation = (long)BAPI_ExecuteOperation;
		pData->BAPI_Increment = (long)BAPI_Increment;
		
		//pData->BAPI_Increment = (long)BAPI_Increment;
		pData->BAPI_ExecuteMethod = (long)BAPI_ExecuteMethod;
		pData->BAPI_GetProperty = (long)BAPI_GetProperty;
		pData->BAPI_SetProperty = (long)BAPI_SetProperty;
		pData->BAPI_TypeCast = (long)BAPI_TypeCast;
		pData->BAPI_ExecuteFunction = (long)BAPI_ExecuteFunction;
		pData->BAPI_GetErrMessage = (long)BAPI_GetErrMessage;
		//pData->BAPI_GetErrNumber = (long)BAPI_GetErrNumber;
		pData->BAPI_SuperIsChanged = (long)BAPI_SuperIsChanged;		

		// Encode/Decode Strings
		pData->BAPI_EncodeIsolatin = (long)BAPI_EncodeIsolatin;
		pData->BAPI_DecodeIsolatin = (long)BAPI_DecodeIsolatin;
		pData->BAPI_EncodeURL = (long)BAPI_EncodeURL;
		pData->BAPI_DecodeURL = (long)BAPI_DecodeURL;
		pData->BAPI_EncodeBase64 = (long)BAPI_EncodeBase64;
		pData->BAPI_DecodeBase64 = (long)BAPI_DecodeBase64;

		// User Variables
		pData->BAPI_GetTotVariables = (long)BAPI_GetTotVariables;
		pData->BAPI_GetListTotVariables = (long)BAPI_GetListTotVariables;
		pData->BAPI_GetListTotVariablesExt = (long)BAPI_GetListTotVariablesExt;
		
		pData->BAPI_GetIndVariable = (long)BAPI_GetIndVariable;
		pData->BAPI_GetListIndVariable = (long)BAPI_GetListIndVariable;
		pData->BAPI_Publish = (long)BAPI_Publish;
		pData->BAPI_Hide = (long)BAPI_Hide;
		pData->BAPI_Undef = (long)BAPI_Undef;
		//pData->BAPI_IsClassDef = (long)BAPI_IsClassDef;
		pData->BAPI_IsFuncDef = (long)BAPI_IsFuncDef;
		pData->BAPI_IsVariableDefined = (long)BAPI_IsVariableDefined;
		pData->BAPI_IsVariableInitialized = (long)BAPI_IsVariableInitialized;
		pData->BAPI_IsVariableHidden = (long)BAPI_IsVariableHidden;
		pData->BAPI_GetClassInfo = (long)BAPI_GetClassInfo;
		pData->BAPI_FixedSize = (long)BAPI_FixedSize;
		pData->BAPI_ClearParameterRec = (long)BAPI_ClearParameterRec;
		
		// Standard Output
		pData->BAPI_StandardOutput = (long)BAPI_StandardOutput;
		pData->BAPI_SetCustomOutput = (long)BAPI_SetCustomOutput;
		pData->BAPI_SetStandardOutput = (long)BAPI_SetStandardOutput;
		pData->BAPI_GetOutputFunction = (long)BAPI_GetOutputFunction;
		pData->BAPI_Log = (long)BAPI_Log;

		// Copy a class
		//pData->BAPI_Divert = (long)BAPI_Divert;
		//pData->BAPI_Super = (long)BAPI_Super;
		//pData->BAPI_DivertAll = (long)BAPI_DivertAll;

		// Error Handling
		pData->BAPI_Exception = (long)BAPI_Exception;
		//pData->BAPI_GetErrNum = (long)BAPI_GetErrNum;
		pData->BAPI_GetErrDescription = (long)BAPI_GetErrDescription;
		pData->BAPI_NewMsgRecord = (long)BAPI_NewMsgRecord;
		
		pData->BAPI_GetMessageRecords = (long)BAPI_GetMessageRecords;
		pData->BAPI_GetErrorMsgRecord = (long)BAPI_GetErrorMsgRecord;
		
		pData->BAPI_GetStack = (long)BAPI_GetStack;
		pData->BAPI_GetIncludeStack = (long)BAPI_GetIncludeStack;

		pData->BAPI_GetHtmlError = (long)BAPI_GetHtmlError;
		//pData->BAPI_SetError = (long)BAPI_SetError;
		pData->BAPI_GetStatus = (long)BAPI_GetStatus;
		pData->BAPI_ScopeName = (long)BAPI_ScopeName;
		pData->BAPI_GetErrorStrings = (long)BAPI_GetErrorStrings;

		// Infos on system and functions/class
		pData->BAPI_GetCache = (long)BAPI_GetCache;
		pData->BAPI_GetVersions = (long)BAPI_GetVersions;
		pData->BAPI_GetNumVersions = (long)BAPI_GetNumVersions;
		pData->BAPI_Platform = (long)BAPI_Platform;
		pData->BAPI_GetBifernoHome = (long)BAPI_GetBifernoHome;
		pData->BAPI_GetServerUpSince = (long)BAPI_GetServerUpSince;
		pData->BAPI_GetMaxUsers = (long)BAPI_GetMaxUsers;
		pData->BAPI_GetPoolFactor = (long)BAPI_GetPoolFactor;
		pData->BAPI_FlushAppFiles = (long)BAPI_FlushAppFiles;
		pData->BAPI_FlushFile = (long)BAPI_FlushFile;
		pData->BAPI_ReloadApp = (long)BAPI_ReloadApp;
		pData->BAPI_GetCurrentAppInfo = (long)BAPI_GetCurrentAppInfo;
		pData->BAPI_GetGenericAppInfo = (long)BAPI_GetGenericAppInfo;
		pData->BAPI_RegisterApplication = (long)BAPI_RegisterApplication;
		pData->BAPI_GetApplications = (long)BAPI_GetApplications;
		pData->BAPI_GetAppChildren = (long)BAPI_GetAppChildren;
		
		pData->BAPI_GetClasses = (long)BAPI_GetClasses;
		pData->BAPI_GetMembers = (long)BAPI_GetMembers;
		//pData->BAPI_GetApplicationFunctions = (long)BAPI_GetApplicationFunctions;
		//pData->BAPI_GetPrototype = (long)BAPI_GetPrototype;
		//pData->BAPI_GetInfo = (long)BAPI_GetInfo;
		//pData->BAPI_GetDocumentation = (long)BAPI_GetDocumentation;
		
		pData->BAPI_GetMemberDoc = (long)BAPI_GetMemberDoc;
		pData->BAPI_GetClassDoc = (long)BAPI_GetClassDoc;
		
		pData->BAPI_ReleaseMemberDoc = (long)BAPI_ReleaseMemberDoc;
		pData->BAPI_DuplicateMemberDoc = (long)BAPI_DuplicateMemberDoc;
		pData->BAPI_IsMemberDef = (long)BAPI_IsMemberDef;
		
		//pData->BAPI_ExtendedClass = (long)BAPI_ExtendedClass;
		pData->BAPI_NameFromClassID = (long)BAPI_NameFromClassID;
		pData->BAPI_ClassIDFromName = (long)BAPI_ClassIDFromName;
		pData->BAPI_ScopeAllowed = (long)BAPI_ScopeAllowed;

		// Infos on files
		pData->BAPI_GetFilePath = (long)BAPI_GetFilePath;
		pData->BAPI_GetCurrentFilePath = (long)BAPI_GetCurrentFilePath;
		pData->BAPI_GetCurrentFileOffset = (long)BAPI_GetCurrentFileOffset;
		pData->BAPI_IsCacheActive = (long)BAPI_IsCacheActive;
		pData->BAPI_GetCurrentBasePath = (long)BAPI_GetCurrentBasePath;
		pData->BAPI_GetCurrentScriptInfo = (long)BAPI_GetCurrentScriptInfo;
		pData->BAPI_SetFileCacheState = (long)BAPI_SetFileCacheState;
		pData->BAPI_RealPath = (long)BAPI_RealPath;
		pData->BAPI_NativePath = (long)BAPI_NativePath;
		pData->BAPI_BifernoPath = (long)BAPI_BifernoPath;

		// Infos on HTTP
		pData->BAPI_HTTPTaskID = (long)BAPI_HTTPTaskID;
		pData->BAPI_GetHTTPParam = (long)BAPI_GetHTTPParam;

		// Flowing settings
		pData->BAPI_OnError = (long)BAPI_OnError;
		pData->BAPI_Exit = (long)BAPI_Exit;
		
		// Java
		pData->BAPI_JavaGetCurrentJNIEnv = (long)BAPI_JavaGetCurrentJNIEnv;
		pData->BAPI_JavaLoadJVM = (long)BAPI_JavaLoadJVM;
	
		// Symbols
		pData->BAPI_RegisterSymbol = (long)BAPI_RegisterSymbol;
		pData->BAPI_GetSymbol = (long)BAPI_GetSymbol;
				
		pData->BAPI_GetPluginRunData = (long)BAPI_GetPluginRunData;
		pData->BAPI_SetPluginRunData = (long)BAPI_SetPluginRunData;
		
		pData->BAPI_GetConfig = (long)BAPI_GetConfig;
		pData->BAPI_GetBooleanConfig = (long)BAPI_GetBooleanConfig;
		pData->BAPI_GetIntConfig = (long)BAPI_GetIntConfig;
		pData->BAPI_GetUnsignedConfig = (long)BAPI_GetUnsignedConfig;
		
		pData->BAPI_GetSID = (long)BAPI_GetSID;
		pData->BAPI_SetSID = (long)BAPI_SetSID;
		pData->BAPI_SetSID = (long)BAPI_CheckSID;
		pData->BAPI_GetIndSID = (long)BAPI_GetIndSID;
		pData->BAPI_SessionVariableToString = (long)BAPI_SessionVariableToString;
		
		//pData->BAPI_GetTimeout = (long)BAPI_GetTimeout;
		pData->BAPI_GetCurrentScriptStatus = (long)BAPI_GetCurrentScriptStatus;
		pData->BAPI_SetTimeout = (long)BAPI_SetTimeout;
		pData->BAPI_Yield = (long)BAPI_Yield;
		
		/*pData->BAPI_NewList = (long)BAPI_NewList;
		pData->BAPI_NewSingleList = (long)BAPI_NewSingleList;
		pData->BAPI_NewObjInList = (long)BAPI_NewObjInList;
		pData->BAPI_GetObjFromList = (long)BAPI_GetObjFromList;
		pData->BAPI_CloneList = (long)BAPI_CloneList;*/

		pData->BAPI_SetNumberFormat = (long)BAPI_SetNumberFormat;
		pData->BAPI_GetNumberFormat = (long)BAPI_GetNumberFormat;
		pData->BAPI_GetDateFormat = (long)BAPI_GetDateFormat;

		pData->BAPI_Flush = (long)BAPI_Flush;
		//pData->BAPI_Reload = (long)BAPI_Reload;
		
		pData->BAPI_GetReference = (long)BAPI_GetReference;
		pData->BAPI_DisposePropertyList = (long)BAPI_DisposePropertyList;
		pData->BAPI_ClonePropertyList = (long)BAPI_ClonePropertyList;
		pData->BAPI_ApplyPropertyList = (long)BAPI_ApplyPropertyList;
		pData->BAPI_GetPropertyListNames = (long)BAPI_GetPropertyListNames;
		pData->BAPI_GetPropertyListClassID = (long)BAPI_GetPropertyListClassID;
		pData->BAPI_MakeRef = (long)BAPI_MakeRef;
		pData->BAPI_IsReference = (long)BAPI_IsReference;
		
		pData->BAPI_GetReferenceTarget = (long)BAPI_GetReferenceTarget;
	}

return err;
}

//===========================================================================================
XErr	_FillList(DLMRef list, NameValueRec *keywords, long tot)
{
int		i;
XErr	err = noErr;

	for (i = 0; (i < tot) && NOT(err); i++)
	{	if NOT(DLM_NewObj(list, keywords[i].name, 0, 0, keywords[i].value, kFixedSize, &err))
			return err;
	}

return err;
}


//===========================================================================================
static XErr	_CallEntryPoint(BifernoRecP bRecP, PluginRecord *plugRecP, Biferno_Message message, Biferno_ParamBlockPtr pbPtr)
{
XErr				err = noErr;
long				pluginID, code_type, oldVolatileLevel;
BRunThreadClassRec	*runRecP = nil;

	if (bRecP)
		oldVolatileLevel = SetVolatileLevel(bRecP);		
	DumpStack("BifernoCode_Call");
	if (plugRecP)
	{	pluginID = plugRecP->pluginID;
		if (bRecP && bRecP->class_thread_dataP)
		{	runRecP = &bRecP->class_thread_dataP[pluginID-1];
			pbPtr->plugin_run_dataP = &runRecP->plugin_run_data;
		}
		else
			pbPtr->plugin_run_dataP = 0L;
		code_type = kCImplementation;
	}
	else
		code_type = kBifernoImplementation;
	switch(code_type)
	{	
		case kCImplementation:
			if (plugRecP->the_entryPoint)
			{	if (runRecP)
				{	err = runRecP->plugin_error_on_run;
					if (err)
						CEquStr(pbPtr->error, "Class initialization failed for this run");
					//pbPtr->plugin_run_error = err;
				}
				//else
				//	pbPtr->plugin_run_error = noErr;
				if NOT(err)
				{	if (bRecP && bRecP->exitEventCompleted && (message != kDestructor) && (message != kPrimitive))
						err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					else
						err = ((ClassesEntryPoint)plugRecP->the_entryPoint)(message, pbPtr);
				}
			}
			else
			{	err = XError(kBAPI_Error, Err_NoSuchClassOrFunction);
				NewMsgRecord((long)bRecP, kCLASS, nil, pluginID, kInputIsClassName);
				// ClassNameToErrMessage(pbPtr->api_data, pluginID);
			}
			break;
		/*case kJavaClass:
			#ifdef JAVA_ENABLED
			if (bRecP->application.javaActive)
			{
				long	theJavaEnvP;
				if (bRecP)
					theJavaEnvP = bRecP->theEnvP;
				else
					theJavaEnvP = 0L;
				err = BJNI_Call(theJavaEnvP, plugRecP->java_className, plugRecP->pluginType, message, pbPtr);
			}
			else
				err = XError(kBAPI_Error, Err_JavaFrameworkNotAvailable);
			#else
			err = XError(kBAPI_Error, Err_JavaFrameworkNotAvailable);
			#endif
			break;*/
		
		case kBifernoImplementation:
			err = BifernoCode_Call(message, pbPtr);
			break;
			
		default:
			err = XError(kBAPI_Error, Err_BAPI_UnknowExtensionType);
			break;
		
	}
	if (bRecP)
	{	if (plugRecP)
		{	// Divert of C Class (Biferno do it on its own)
			if (err && (err == XError(kBAPI_Error, Err_BAPI_MessageNotHandled) && plugRecP->extendedPluginID))
			{	long saveLID = bRecP->lastClassIDErrorCalled;
				if (err = CDivertDispatcher(message, pbPtr, plugRecP))
					bRecP->lastClassIDErrorCalled = saveLID;
			}
			//if (bRecP->class_thread_dataP)
			//	runRecP->plugin_run_dataP = pbPtr->plugin_run_data;
			if (err && NOT(bRecP->lastClassIDErrorCalled) && (pluginID != gsDispatcherData.errConstructor))
			{	bRecP->lastClassIDErrorCalled = pluginID;
				CEquStr(bRecP->class_error_note, pbPtr->error);
			}
		}
		else if (err && NOT(bRecP->lastClassIDErrorCalled) && (message != kExecuteFunction))
		{	bRecP->lastClassIDErrorCalled = -(long)pbPtr->plugin_global_dataP;
			CEquStr(bRecP->class_error_note, pbPtr->error);
		}
	}
	/*if (err && bRecP && *pbPtr->error && NOT(*bRecP->class_error_note))
		CEquStr(bRecP->class_error_note, pbPtr->error);*/
	
	if (bRecP)
		ResumeVolatileLevel(bRecP, oldVolatileLevel);
		//bRecP->volatileLevel = oldVolatileLevel;

return err;
}

//===========================================================================================
static XErr _FillPlugRecord(long pluginRef, Biferno_Dispatch pluginEntryPoint, long pluginBAPIVersion, long xlibVersion, Boolean isPlugin, LogCallBack logCallBack, void *userData, char *pluginPath, short pluginFRsrcRefNum, Boolean macosxBundle, long *nextBAPI_DispatchP)
{
Biferno_ParamBlock 		pb;
XErr					err = noErr;
PluginRecord			*plugRecP;
long					classObjID, totClass = gsDispatcherData.totClass;
CStr255					plugErrName, descr, cLogStr, eNameStr;
CStr63					versionStr, xlibversionStr;
char					*versionStrPtr = nil;
Boolean					addInReserved = false;

	if (nextBAPI_DispatchP)
		*nextBAPI_DispatchP = nil;
	ClearBlock(&pb, sizeof(Biferno_ParamBlock));
	pb.param.registerRec.api_version = CUR_BIFERNO_API_VERSION;
	totClass++;
	*plugErrName = 0;
	if NOT(err = SetBlockSize(gsDispatcherData.classRecordBlock, sizeof(PluginRecord) * totClass))
	{	LockBlock(gsDispatcherData.classRecordBlock);
		gClassRecordBlockP = (PluginRecord*)GetPtr(gsDispatcherData.classRecordBlock);
		plugRecP = gClassRecordBlockP + gsDispatcherData.totClass;
		ClearBlock(plugRecP, sizeof(PluginRecord));
		plugRecP->pluginBAPIVersion = pluginBAPIVersion;
		plugRecP->pluginXLibVersion = xlibVersion;
		plugRecP->the_entryPoint = (ClassesEntryPoint)pluginEntryPoint;
		plugRecP->pluginMacOSResourceFork = pluginFRsrcRefNum;
		pb.param.registerRec.pluginID = totClass;
		pb.param.registerRec.bifernoInLocalMode = gsLocally;
		pb.param.registerRec.macOSResRefNum = pluginFRsrcRefNum;
		pb.param.registerRec.maxUsers = gsDispatcherData.maxUsers;
		pb.api_data = 0;
		if NOT(err = _CallEntryPoint(nil, plugRecP, kRegister, &pb))
		{	if (nextBAPI_DispatchP)
			{	if (*nextBAPI_DispatchP = pb.param.registerRec.nextBAPI_Dispatch)
					plugRecP->moreDispatcher = true;
			}
			classObjID = DLM_GetObjID(gsDispatcherData.reservedKeyword, pb.param.registerRec.pluginName, nil, nil);	
			CEquStr(plugRecP->pluginName, pb.param.registerRec.pluginName);
			if NOT(classObjID)
			{	CEquStr(descr, pb.param.registerRec.pluginDescr);
				plugRecP->pluginType = pb.param.registerRec.pluginType;
				plugRecP->pluginID = totClass;
				plugRecP->successfull = true;
				plugRecP->dllRef = pluginRef;
				plugRecP->macosxBundle = macosxBundle;
				// Hooks
				plugRecP->modifyHook = (BAPI_ModifyHook)pb.param.registerRec.modifyHook;
				plugRecP->scopeAllowedHook = (BAPI_ScopeAllowedHook)pb.param.registerRec.scopeAllowedHook;
				plugRecP->incrementHook = (BAPI_IncrementHook)pb.param.registerRec.incrementHook;
				plugRecP->wantDestructor = pb.param.registerRec.wantDestructor;
				plugRecP->fixedSize = pb.param.registerRec.fixedSize;
				plugRecP->dynamic = pb.param.registerRec.dynamic;
				CEquStr(plugRecP->extendedClass, pb.param.registerRec.extendedClass);
				CEquStr(plugRecP->constructorString, pb.param.registerRec.constructor);
				versionStrPtr = pb.param.registerRec.pluginVersionStr;
				if NOT(*plugRecP->pluginName)
					err = XError(kBAPI_Error, Err_BAPI_ExtensionNameRequired);
				else
				{	DLM_NewObj(gsDispatcherData.classListRef, plugRecP->pluginName, 0, 0, totClass, kFixedSize, &err);
					if (err == XError(kXHelperError, DLM_Err_DuplicatedObject))
						err = XError(kBAPI_Error, Err_ClassRedeclared);
				}
				if NOT(err)
				{	gsDispatcherData.totClass = totClass;
					switch(totClass)
					{
						case kBooleanClassID:
							plugRecP->oper_priority = 1;
							plugRecP->compare_priority = 7;
							addInReserved = true;
							break;
						case kStringClassID:
							plugRecP->oper_priority = 7;
							plugRecP->compare_priority = 6;
							addInReserved = true;
							break;
						case kDoubleClassID:
							plugRecP->oper_priority = 6;
							plugRecP->compare_priority = 5;
							addInReserved = true;
							break;
						case kLongClassID:
							plugRecP->oper_priority = 5;
							plugRecP->compare_priority = 4;
							addInReserved = true;
							break;
						case kUnsignedClassID:
							plugRecP->oper_priority = 4;
							plugRecP->compare_priority = 3;
							addInReserved = true;
							break;
						case kIntClassID:
							plugRecP->oper_priority = 3;
							plugRecP->compare_priority = 2;
							addInReserved = true;
							break;
						case kCharClassID:
							addInReserved = true;
							plugRecP->oper_priority = 2;
							plugRecP->compare_priority = 1;
							break;
						default:
							// non primitive class have priority 0
							if NOT(CCompareStrings_cs(plugRecP->pluginName, "array"))
							{	gsDispatcherData.arrayConstructor = totClass;	
								addInReserved = true;
							}
							else if NOT(CCompareStrings_cs(plugRecP->pluginName, "error"))
							{	gsDispatcherData.errConstructor = totClass;	
								addInReserved = true;
							}
							else if NOT(CCompareStrings_cs(plugRecP->pluginName, "multipart"))
							{	gsDispatcherData.multipartConstructor = totClass;	
								addInReserved = true;
							}
							else if NOT(CCompareStrings_cs(plugRecP->pluginName, "httpPage"))
							{	gsDispatcherData.httpPageConstructor = totClass;	
								addInReserved = true;
							}
							else if NOT(CCompareStrings_cs(plugRecP->pluginName, "ref"))
							{	gsRefModifyHook = plugRecP->modifyHook;
								gsDispatcherData.refConstructor = totClass;	
								addInReserved = true;
							}
							else if NOT(CCompareStrings_cs(plugRecP->pluginName, "cacheItem"))
							{	//gsDispatcherData.cacheItemConstructor = totClass;
								addInReserved = true;
								if (plugRecP->fixedSize)
									gsDispatcherData.cacheItemIsFixed = true;
							}
							else if NOT(CCompareStrings_cs(plugRecP->pluginName, "stackItem"))
							{	// gsDispatcherData.stackItemConstructor = totClass;
								addInReserved = true;
								if (plugRecP->fixedSize)
									gsDispatcherData.stackItemIsFixed = true;
							}
							else if NOT(CCompareStrings_cs(plugRecP->pluginName, "jclass"))
								gsDispatcherData.javaHelperRef = plugRecP->dllRef;
							break;
					}
					/*
					16/1/2003
					levato perch� altrimenti uno script in cui uso MyVar non funziona pi� se, casualmente, 
					carico una dll che dichiara una classe che si chiama MyVar
					(per le primitive e qualcun altra invece va bene il reserved, addInReserved a true)
					*/
					//if (plugRecP->pluginType == kNewClassPlugin)
					if (addInReserved)
						DLM_NewObj(gsDispatcherData.reservedKeyword, plugRecP->pluginName, 0, 0, 0, kFixedSize, &err);
				}
			}
			else
			{	if (BAPI_ClassIDFromName(0L, plugRecP->pluginName, false))
					err = XError(kBAPI_Error, Err_ClassRedeclared);
				else
					err = XError(kBAPI_Error, Err_ReservedKeyword);
			}
		}
		if (err)
		{	if (*plugRecP->pluginName)
				CEquStr(plugErrName, plugRecP->pluginName);	
			else if (pluginPath)
				CEquStr(plugErrName, pluginPath);	
			ClearBlock(plugRecP, sizeof(PluginRecord));
		}
		else if (logCallBack)
		{	CStr255		aCStr;
			
			CEquStr(cLogStr, "\t");
			CAddStr(cLogStr, plugRecP->pluginName);
			if (*descr)
			{	CAddStr(cLogStr, ": ");
				CAddStr(cLogStr, descr);
			}
			if (isPlugin)
			{	VersionToString(pluginBAPIVersion, versionStr, nil);
				VersionToString(xlibVersion, xlibversionStr, nil);
				sprintf(aCStr, " [BAPI %s - XLib %s]", versionStr, xlibversionStr);
				CAddStr(cLogStr, aCStr);
			}		
			err = logCallBack(userData, cLogStr);
			if (isPlugin)
			{	if (versionStrPtr && *versionStrPtr)
				{	CEquStr(cLogStr, "\tVersion: ");
					CAddStr(cLogStr, versionStrPtr);
					err = logCallBack(userData, cLogStr);
				}
				err = logCallBack(userData, "\t************");
				err = logCallBack(userData, "");
			}		

		}
		UnlockBlock(gsDispatcherData.classRecordBlock);
	}

	if (err)
	{	if (logCallBack)
		{	CEquStr(cLogStr, "\t *** ERROR ***: ");
			BAPI_GetErrDescription(0L, err, eNameStr, nil, nil, nil, nil, totClass, nil);
			CAddStr(cLogStr, eNameStr);
			CAddStr(cLogStr, ": ");
			CAddStr(cLogStr, pb.error);
			CAddStr(cLogStr, " (");
			if (*plugErrName)
				CAddStr(cLogStr, plugErrName);
			CAddStr(cLogStr, ")");
			err = logCallBack(userData, cLogStr);
		}
	}

return err;
}

//===========================================================================================
/*static void _GetNexts(Ptr *tempPP, long *lenP, char *aStr, long max, Boolean checkChars)
{
int		i;
Ptr		tempP;
long	len;
int		ch;

	tempP = *tempPP;
	len = *lenP;
	i = 0;
	ch = *tempP;
	if NOT(checkChars)
	{	if (len && (ch == '\"'))
		{	tempP++;
			len--;
			ch = *tempP;
		}
		else
			return;
	}
	while (len && (i < max))
	{	if (checkChars)
		{	if NOT(IsEntityCharValid(ch, (i==0)))
				break;
		}
		else if (len && (ch == '\"'))
		{	tempP++;
			len--;
			break;
		}
		aStr[i++] = ch;
		if (--len)
			ch = *(++tempP);
		else
			tempP++;
	}
	aStr[i] = 0;
	*tempPP = tempP;
	*lenP = len;
}*/

//===========================================================================================
static XErr _LoadStaticXClasses(LogCallBack logCallBack, void *userData)
{
XErr				err = noErr;	//, err2 = noErr;
//LogCallBack			logCallBack = gsDispatcherData.logCallBack;
long				tot;
Biferno_Dispatch	*tDispatchP;
int					i;

	StaticClasses();
	
	if (logCallBack)
	{	if (err = logCallBack(userData, "Registering..."))
			return err;
	}

	tot = gTotStaticClasses;
	tDispatchP = &gStaticClassEntryPoint[0];
	for (i = 0; i < tot; i++)
	{
		err = _FillPlugRecord(0, tDispatchP[i], CUR_BIFERNO_API_VERSION, CUR_XLIB_VERSION, false, logCallBack, userData, nil, -1, false, nil);
	}
			
//out:
return err;
}

//===========================================================================================
/*static XErr _LoadJavaClass(char *javaClassName)
{
XErr		err = noErr;

	err = _FillPlugRecord(nil, javaClassName, true);

return err;
}
*/
//===========================================================================================
/*static XErr _LoadJavaClasses(LogCallBack logCallBack, long userData)
{
#ifndef JAVA_ENABLED
	#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(logCallBack, userData)
#endif
//long		i, tot;
XErr		err = noErr;
//char		*p;

#ifdef JAVA_ENABLED
	if (gBifernoGlobalPrefs.javaActive)
		err = BJNI_Init((long)logCallBack, userData);
#endif

	
	for now disabled
	
	tot = gBifernoGlobalPrefs.totJavaExt;
	p = GetPtr(gBifernoGlobalPrefs.javaExtsBlockRef);
	for(i = 0; i < tot; i++, p += 256)
	{	
		err = _LoadJavaClass(p);
	}
	
	DisposeBlock(&gBifernoGlobalPrefs.javaExtsBlockRef);
	
	
return err;	
}
*/


//===========================================================================================
static XErr _ExtensionVersionIsOk(long pluginBAPIVersion, XErr *resultErr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(pluginBAPIVersion)
#endif
// Here you can check if the Extension's BAPI version is satisfying and return error if not
// Errors can be one of these: Err_BAPI_ExtensionTooOld, Err_BAPI_ExtensionTooNew
Boolean		res;

	if (pluginBAPIVersion < 0x00010005)
	{	*resultErr = XError(kBAPI_Error, Err_BAPI_ExtensionTooOld);
		res = false;
	}
	else
	{	*resultErr = noErr;
		res = true;
	}

return res;
}

#ifdef __LITTLE_ENDIAN__		// INTEL
	#define	_SO	'os'
#else
	#define	_SO	'so'
#endif

//===========================================================================================
/*
ex
static XErr _LoadDynamicClass(char *pluginPath, long variant, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(variant)
XErr				err = noErr;
LogRec				*logRecP = (LogRec*)param;
LogCallBack 		logCallBack = logRecP->logCallBack;
long 				userData = logRecP->userData;
long				pluginEntryPoint = 0L;
long				pluginRef;
XFileInfo			xFileInfo;
Boolean				toLoad = false;
long				xlibVersion, pluginBAPIVersion;
CStr255				dllErrStr;
short				fRsrcRefNum;
char				cLogStr[512];
CStr255				eNameStr;
long				nextBAPIDispatch;

	if (logRecP->macosxBundle)
		toLoad = true;
	else
	{	if (err = GetXFileInfo(pluginPath, &xFileInfo))
		{
		#ifdef __UNIX_XLIB__
			long		pluginPathLen;
			
			pluginPathLen = CLen(pluginPath);
			xFileInfo.isDLL = (pluginPath[pluginPathLen-3] == '.') && (*(short*)&pluginPath[pluginPathLen-2] == _SO);
			err = noErr;
		#else
			return err;
		#endif
		}
	
		#ifdef __MAC_XLIB__
			toLoad = xFileInfo.isDLL
			#ifdef __MACOSX__
				;
			#else
				&& (xFileInfo.macosCreator == 'bife');
			#endif
		#else
			toLoad = xFileInfo.isDLL;
		#endif
	}
	if (toLoad)
	{	if NOT(err = XLoadDLL(pluginPath, &pluginRef, dllErrStr, &xlibVersion, logRecP->macosxBundle))
		{	if NOT(err = XGetDLLSymbol(pluginRef, "BAPI_Dispatch", &pluginEntryPoint, logRecP->macosxBundle))
			{	if NOT(err = _RegisterDLLClass(pluginRef, &pluginBAPIVersion, dllErrStr, logRecP->macosxBundle))
				{	if (_ExtensionVersionIsOk(pluginBAPIVersion, &err))
					{	
					#if __MAC_XLIB__ && !__MACOSX__
						FSSpec	fileSpec;
						short	oldres;
						
						if NOT(err = _GetMacSpec(pluginPath, &fileSpec, false, true))
						{	oldres = CurResFile();
							if ((fRsrcRefNum = FSpOpenResFile(&fileSpec, fsRdPerm)) == -1)
								err = ResError();
							if (err)
							{	// ok to overwrite err (Just notify user)
								PascalToC(fileSpec.name, eNameStr);
								sprintf(cLogStr, "Can't open resource fork of %s (%d)%s", eNameStr, err, EOL_STRING);
								err = logCallBack(userData, cLogStr);
							}
							UseResFile(oldres);
						}
					#else
						fRsrcRefNum = 0;
					#endif
						do
						{	if (err = _FillPlugRecord(pluginRef, (Biferno_Dispatch)pluginEntryPoint, pluginBAPIVersion, xlibVersion, true, logCallBack, userData, pluginPath, fRsrcRefNum, logRecP->macosxBundle, &nextBAPIDispatch))
								break;
							else if (nextBAPIDispatch)
								pluginEntryPoint = nextBAPIDispatch;
							else
								break;
						} while(1);
					}
				}
			}
			else
				CEquStr(dllErrStr, "Can't find symbol BAPI_Dispatch");
		}
		if (err)
		{	*cLogStr = 0;
			BAPI_GetErrDescription(0L, err, eNameStr, nil, nil, nil, nil, 0);
			CAddStr(cLogStr, eNameStr);
			CAddStr(cLogStr, ": ");
			CAddStr(cLogStr, dllErrStr);
			CAddStr(cLogStr, ": ");
			CAddStr(cLogStr, pluginPath);
			CAddStr(cLogStr, EOL_STRING);
			err = logCallBack(userData, cLogStr);
		}
		
	}

return err;
}
*/
//===========================================================================================
static XErr _LoadDynamicClass(char *pluginPath, long variant, long param)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(variant)
#endif
XErr				err = noErr, err2 = noErr;
LogRec				*logRecP = (LogRec*)param;
LogCallBack 		logCallBack = logRecP->logCallBack;
void 				*userData = logRecP->userData;
long				pluginEntryPoint = 0L;
long				pluginRef;
XFileInfo			xFileInfo;
Boolean				toLoad = false;
long				xlibVersion, pluginBAPIVersion;
CStr255				dllErrStr;
short				fRsrcRefNum;
char				cLogStr[512];
CStr255				eNameStr;
long				nextBAPIDispatch;
char				*strP;

	*dllErrStr = 0;
	if (logRecP->macosxBundle)
		toLoad = true;
	else
	{	if (err = GetXFileInfo(pluginPath, &xFileInfo))
		{
		#ifdef __UNIX_XLIB__
			long		pluginPathLen;
			
			pluginPathLen = CLen(pluginPath);
			xFileInfo.isDLL = (pluginPath[pluginPathLen-3] == '.') && (*(short*)&pluginPath[pluginPathLen-2] == _SO);
			err = noErr;
		#else
			return err;
		#endif
		}
	
		#ifdef __MAC_XLIB__
			toLoad = xFileInfo.isDLL
			#ifdef __MACOSX__
				;
			#else
				&& (xFileInfo.macosCreator == 'bife');
			#endif
		#else
			toLoad = xFileInfo.isDLL;
		#endif
	}
	
	// last check (invisible file?)
	if ((strP = strrchr(pluginPath, '/')) && (CLen(strP) > 1) && (*(strP+1) == '.'))
		toLoad = false;
	
	if (toLoad)
	{	if NOT(err = XLoadDLL(pluginPath, &pluginRef, dllErrStr, &xlibVersion, logRecP->macosxBundle))
		{	if NOT(err = XGetDLLSymbol(pluginRef, "BAPI_Dispatch", &pluginEntryPoint, logRecP->macosxBundle))
			{	if NOT(err = _RegisterDLLClass(pluginRef, &pluginBAPIVersion, dllErrStr, logRecP->macosxBundle))
				{	if (_ExtensionVersionIsOk(pluginBAPIVersion, &err))
					{	
					#if __MAC_XLIB__ && !__MACOSX__
						FSSpec	fileSpec;
						short	oldres;
						
						if NOT(err = _GetMacSpec(pluginPath, &fileSpec, false, true))
						{	oldres = CurResFile();
							if ((fRsrcRefNum = FSpOpenResFile(&fileSpec, fsRdPerm)) == -1)
								err = ResError();
							if (err)
							{	// ok to overwrite err (Just notify user)
								PascalToC(fileSpec.name, eNameStr);
								sprintf(cLogStr, "Can't open resource fork of %s (%d)%s", eNameStr, err, EOL_STRING);
								err = logCallBack(userData, cLogStr);
							}
							UseResFile(oldres);
						}
					#else
						fRsrcRefNum = 0;
					#endif
						do
						{	if (err = _FillPlugRecord(pluginRef, (Biferno_Dispatch)pluginEntryPoint, pluginBAPIVersion, xlibVersion, true, logCallBack, userData, pluginPath, fRsrcRefNum, logRecP->macosxBundle, &nextBAPIDispatch))
								break;
							else if (nextBAPIDispatch)
								pluginEntryPoint = nextBAPIDispatch;
							else
								break;
						} while(1);
					}
				}
			}
			else
				CEquStr(dllErrStr, "Can't find symbol BAPI_Dispatch");
		}		
	}
	if (err)
	{
	long	eNum, eType;
	
		CEquStr(cLogStr, "Error while loading: ");
		CAddStr(cLogStr, pluginPath);
		CAddStr(cLogStr, EOL_STRING);
		err2 = logCallBack(userData, cLogStr);

		*cLogStr = 0;
		BAPI_GetErrDescription(0L, err, eNameStr, nil, nil, nil, nil, 0, nil);
		CAddStr(cLogStr, eNameStr);
		CAddStr(cLogStr, ": ");
		CAddStr(cLogStr, dllErrStr);
		CAddStr(cLogStr, ": ");
		CAddStr(cLogStr, pluginPath);
		CAddStr(cLogStr, EOL_STRING);
		err2 = logCallBack(userData, cLogStr);
		XErrorGetTypeValue(err, &eNum, &eType);
		if (eType == kOSError)
		{	ErrorGetDescr(err, eNameStr, nil);
			CEquStr(cLogStr, eNameStr);
			CAddStr(cLogStr, EOL_STRING);
			err = logCallBack(userData, cLogStr);
		}
		else
			err = noErr;
	
		err2 = logCallBack(userData, EOL_STRING);
	}

return err;
}
//===========================================================================================
/*static XErr	_DisposeMember(DLMRef dlRef, long objID, long flags, long classID, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(classID, flags)
BlockRef		protoParamBlock;
XErr			err = noErr;
long			tLen;

	tLen = sizeof(BlockRef);
	if NOT(err = DLM_GetObj(dlRef, objID, (Ptr)&protoParamBlock, &tLen, offsetof(MemberRecord, protoParamBlock)+1, nil))
	{	if (protoParamBlock)
			DisposeBlock(&protoParamBlock);
	}

return err;
}
*/
//===========================================================================================
static XErr	_InitAllClasses(LogCallBack logCallBack, void *userData/*, long maxUsers*/)
{	
Biferno_ParamBlock 		pb;
//NewClassRec				*newClassRecP;
long					classes, totClasses;
int						i;
PluginRecord			*plugRecP;
XErr					err = noErr;
CStr255					eNameStr;
char					cLogStr[512];
//MemberRecord			*membRecP;
	
	LockBlock(gsDispatcherData.classRecordBlock);
	gClassRecordBlockP = (PluginRecord*)GetPtr(gsDispatcherData.classRecordBlock);
	
	// Classes
	totClasses = gsDispatcherData.totClass;
	
	plugRecP = (PluginRecord*)GetPtr(gsDispatcherData.classRecordBlock);
	classes = 0;
	for (i = 0; i < totClasses; i++, plugRecP++)
	{	if (plugRecP->pluginType == kNewClassPlugin)
		{	
			classes++;
			plugRecP->membersList = -1;
			if NOT(err = DLM_Create(&plugRecP->membersList, NAMECS_LIST, GLOBAL_LIST))
			{	ClearBlock(&pb, sizeof(Biferno_ParamBlock));
				//newClassRecP = &pb.param.initRec.newClassRec;
				pb.api_data = 0L;
				//pb.param.initRec.maxUsers = maxUsers;
				//pb.param.initRec.reloading = reloading;
				*pb.error = 0;
				if NOT(err = _CallEntryPoint(0L, plugRecP, kInit, &pb))
				{	plugRecP->plugin_global_data = pb.api_data;
					//plugRecP->wantDestructor = newClassRecP->wantDestructor;
					//plugRecP->fixedSize = newClassRecP->fixedSize;
					//plugRecP->dynamic = newClassRecP->dynamic;
					if (*plugRecP->extendedClass)
					{	if NOT(plugRecP->extendedPluginID = BAPI_ClassIDFromName(0, plugRecP->extendedClass, false))
							err = XError(kBAPI_Error, Err_NoSuchClass);
					}
					if NOT(err)
					{	
					BAPI_Doc	*memberDocP;
					Ptr			tempP = plugRecP->constructorString;
					long		tempLen = CLen(tempP);
						
						if (tempLen)
						{	if (plugRecP->constructor = NewBlockLocked(sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc), &err, (Ptr*)&memberDocP))
							{	ClearBlock(memberDocP, sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc));
								//ClearBlock(membRecP, sizeof(MemberRecord));
								if NOT(err = PrototypeToBAPI_Doc(0, &tempP, &tempLen, plugRecP->constructor, nil, false, kMethod))
								{	memberDocP = (BAPI_Doc*)GetPtr(plugRecP->constructor);		// reload it
									memberDocP->info.method.classID = i + 1;
									memberDocP->implem = kCImplementation;
									memberDocP->type = kMethod;
									CEquStr(memberDocP->prototype, plugRecP->constructorString);
								}
								//ParamNamesFromPrototype(newClassRecP->constructor, membRecP);
								if (err)
									DisposeBlock(&plugRecP->constructor);
							}
						}
						else
							plugRecP->constructor = 0;
						if (logCallBack)
						{	CEquStr(cLogStr, "\tClass: \"");
							CAddStr(cLogStr, plugRecP->pluginName);
							CAddStr(cLogStr, "\"");
							/*if (*pb.param.initRec.description)
							{	CAddStr(cLogStr, " (");
								CAddStr(cLogStr, pb.param.initRec.description);
								CAddStr(cLogStr, ")");
							}*/
							if (err = logCallBack(userData, cLogStr))
								goto out;
						}
					}
				}
				if (err)
				{	if (plugRecP->membersList)
						DLM_DisposeGlobal(&plugRecP->membersList, nil, 0);
					// ABORTED CLASS	
					plugRecP->the_entryPoint = 0L;
					plugRecP->successfull = false;
					if (logCallBack)
					{	CEquStr(cLogStr, "\t*** ERROR ***: ");
						BAPI_GetErrDescription(0L, err, eNameStr, nil, nil, nil, nil, plugRecP->pluginID, nil);
						CAddStr(cLogStr, eNameStr);
						CAddStr(cLogStr, ": ");
						CAddStr(cLogStr, pb.error);
						err = logCallBack(userData, cLogStr);
						CEquStr(cLogStr, "\t*** ERROR ***: Class \"");
						CAddStr(cLogStr, plugRecP->pluginName);
						CAddStr(cLogStr, "\" ABORTED!!");
						err = logCallBack(userData, cLogStr);
						if (*pb.error)
							err = logCallBack(userData, pb.error);
					}
					err = noErr;
				}
			}
		}
	}
		
	if (logCallBack)
		err = logCallBack(userData, "");
	
	// Functions
	plugRecP = (PluginRecord*)GetPtr(gsDispatcherData.classRecordBlock);
	for (i = 0; i < totClasses; i++, plugRecP++)
	{	if (plugRecP->pluginType == kNewFunctionsPlugin)
		{	if (logCallBack)
			{	CEquStr(cLogStr, "\tFunctions: \"");
				CAddStr(cLogStr, plugRecP->pluginName);
				CAddStr(cLogStr, "\"");
				if (err = logCallBack(userData, cLogStr))
					goto out;
			}
			ClearBlock(&pb, sizeof(Biferno_ParamBlock));
			pb.api_data = 0L;
			//pb.param.initRec.maxUsers = maxUsers;
			//pb.param.initRec.reloading = reloading;
			*pb.error = 0;
			if NOT(err = _CallEntryPoint(0L, plugRecP, kInit, &pb))
			{	
				//plugRecP->plugin_global_data = pb.plugin_global_data;
			}
			if (err)
			{	if (logCallBack)
				{	// ABORTED CLASS	
					plugRecP->the_entryPoint = 0L;
					plugRecP->successfull = false;
					CEquStr(cLogStr, "\tError: ");
					BAPI_GetErrDescription(0L, err, eNameStr, nil, nil, nil, nil, plugRecP->pluginID, nil);
					CAddStr(cLogStr, eNameStr);
					err = logCallBack(userData, cLogStr);
					if (*pb.error)
						err = logCallBack(userData, pb.error);
				}
				err = noErr;
			}
		}
	}						


out:
UnlockBlock(gsDispatcherData.classRecordBlock);
return err;
}

//===========================================================================================
static XErr	_Plugin_op(PluginRecord* plugRecP, long theClassID, long api_data, ObjRecordP item1, ObjRecordP item2, long operation, ObjRecordP resultVarRecP)
{
XErr				err = noErr;
BifernoRec			*bRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;
//BlockRef			block;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		if (plugRecP)
			pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
		else
			pbPtr->plugin_global_dataP = (uint32_t*)-theClassID;

		pbPtr->api_data = api_data;
		if (plugRecP)
			pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
		else
			pbPtr->plugin_global_dataP = (uint32_t*)-theClassID;
		pbPtr->param.executeOperationRec.objRef1 = OBJREF(*item1);
		pbPtr->param.executeOperationRec.objRef2 = OBJREF(*item2);
		pbPtr->param.executeOperationRec.operation = operation;
		//pbPtr->param.executeOperationRec.increment = increment;
		if NOT(err = _CallEntryPoint(bRecP, plugRecP, kExecuteOperation, pbPtr))
			*resultVarRecP = OBJRECORD(pbPtr->param.executeOperationRec.resultObjRef);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
		
return err;
}

//===========================================================================================
XErr	CreateEmptyArray(char *nameP, DLMRef list, long arrayLevel, long arrayElementClassID, long finalFlags, long *destIDP)
{	
ObjRecord	tObjRef;
DLMRef 		arrayDLRef;
long		objID;
XErr		err = noErr;
	
	ClearBlock(&tObjRef, sizeof(ObjRecord));
	tObjRef.list = list;
	tObjRef.classID = gsDispatcherData.arrayConstructor;
	tObjRef.id = *destIDP = DLM_NewArray(list, nameP, gsDispatcherData.arrayConstructor, (unsigned short)finalFlags, /*0, */0, &arrayDLRef, &err);
	if (arrayElementClassID)
	{	if (NOT(err) && (--arrayLevel > 0))
		{	do {
				if NOT(err = DLM_GetArrayInfo(tObjRef.list, tObjRef.id, nil, &arrayDLRef, nil, nil))
				{	objID = DLM_NewArray(arrayDLRef, nil/*"1"*/, gsDispatcherData.arrayConstructor, 0, /*0, */0, nil/*&arrayDLRef*/, &err);
					if NOT(err)
					{	if NOT(err = DLM_SetArrayDim(tObjRef.list, tObjRef.id, 1, true, nil, 0))	// only to update arMaxDim
						{	tObjRef.list = arrayDLRef;
							tObjRef.id = objID;
						}
					}
				}
			} while (NOT(err) && (--arrayLevel > 0));
		}
		if NOT(err)
			err = DLM_SetArrayElemClass(tObjRef.list, tObjRef.id, arrayElementClassID);
	}

return err;
}

//===========================================================================================
XErr	CreateEmptyObject(long api_data, char *nameP, DLMRef list, long theScope, long classID, long arrayLevel, long arrayElementClassID, long finalFlags, Boolean canBeImmediate, ObjRecord *resultObjRefP)
{
XErr		err = noErr;
long		type, destID;
Boolean		fixedSize;

	if (finalFlags < 0)
		finalFlags = 0;
	if (classID == gsDispatcherData.arrayConstructor)
		err = CreateEmptyArray(nameP, list, arrayLevel, arrayElementClassID, finalFlags, &destID);
	/*{	ObjRecord		tObjRef;
		DLMRef 		arrayDLRef;
		long		objID;
		
		ClearBlock(&tObjRef, sizeof(ObjRecord));
		tObjRef.list = list;
		tObjRef.classID = classID;
		tObjRef.id = destID = DLM_NewArray(list, nameP, gsDispatcherData.arrayConstructor, (unsigned short)finalFlags, 0, &arrayDLRef, &err);
		if (arrayElementClassID)
		{	if (NOT(err) && (--arrayLevel > 0))
			{	do {
					if NOT(err = DLM_GetArrayInfo(tObjRef.list, tObjRef.id, nil, &arrayDLRef, nil, nil))
					{	objID = DLM_NewArray(arrayDLRef, nil, gsDispatcherData.arrayConstructor, 0, 0, nil, &err);
						if NOT(err)
						{	if NOT(err = DLM_SetArrayDim(tObjRef.list, tObjRef.id, 1, true, nil, 0))	// only to update arMaxDim
							{	tObjRef.list = arrayDLRef;
								tObjRef.id = objID;
							}
						}
					}
				} while (NOT(err) && (--arrayLevel > 0));
			}
			if NOT(err)
				err = DLM_SetArrayElemClass(tObjRef.list, tObjRef.id, arrayElementClassID);
		}
	}*/
	else
	{	if (canBeImmediate)
		{	INVAL_P(resultObjRefP);
			switch(classID)
			{
				case kBooleanClassID:
					err = CL_BooleanToObj(api_data, false, resultObjRefP);
					goto out;
				case kStringClassID:
					if (finalFlags & kCostant)
						type = CONSTANT;
					else
						type = VARIABLE;
					err = CL_StringToObj(api_data, "", 0, type, resultObjRefP);
					goto out;
				case kDoubleClassID:
					err = CL_DoubleToObj(api_data, 0, resultObjRefP);
					goto out;
				case kLongClassID:
					err = CL_LongToObj(api_data, 0, resultObjRefP);
					goto out;
				case kUnsignedClassID:
					err = CL_UnsignedToObj(api_data, 0, resultObjRefP);
					goto out;
				case kIntClassID:
					err = CL_IntToObj(api_data, 0, resultObjRefP);
					goto out;
				/*case kCharClassID:							// come string
					err = CL_StringToObj(api_data, "", 0, CONSTANT, resultObjRefP);
					goto out;*/
				default:
					goto defaultLabel;
			}
		}
		else
		{	switch(classID)
			{
				case kBooleanClassID:
					{	Boolean	boolVal = false;
						destID = DLM_NewObj(list, nameP, (Ptr)&boolVal, sizeof(Boolean), kBooleanClassID, (unsigned short)(finalFlags | kFixedSize), &err);
					}
					break;
				case kStringClassID:
					destID = DLM_NewObj(list, nameP, "", 0L, kStringClassID, (unsigned short)finalFlags, &err);
					break;
				case kDoubleClassID:
					{	double	doubleVal = 0;
						destID = DLM_NewObj(list, nameP, (Ptr)&doubleVal, sizeof(double), kDoubleClassID, (unsigned short)(finalFlags | kFixedSize), &err);
					}
					break;
				case kLongClassID:
					{	LONGLONG	ll = 0;
						destID = DLM_NewObj(list, nameP, (Ptr)&ll, sizeof(LONGLONG), kLongClassID, (unsigned short)(finalFlags | kFixedSize), &err);
					}
					break;
				case kUnsignedClassID:
					{	unsigned long	uLong = 0;
						destID = DLM_NewObj(list, nameP, (Ptr)&uLong, sizeof(unsigned long), kUnsignedClassID, (unsigned short)(finalFlags | kFixedSize), &err);
					}
					break;
				case kIntClassID:
					{	long	aLong = 0;
						destID = DLM_NewObj(list, nameP, (Ptr)&aLong, sizeof(long), kIntClassID, (unsigned short)(finalFlags | kFixedSize), &err);
					}
					break;
				case kCharClassID:							// come string
					{	classID = kStringClassID; 
						destID = DLM_NewObj(list, nameP, "", 0, kStringClassID, (unsigned short)finalFlags, &err);
					}
					break;
				default:
				defaultLabel:
					if (classID == CLASSID_UNSPECIFIED)		// come string
					{	classID = kStringClassID; 
						destID = DLM_NewObj(list, nameP, "", 0, kStringClassID, (unsigned short)finalFlags, &err);
					}
					else
					{	if NOT(err = BAPI_FixedSize(api_data, classID, &fixedSize))
						{	if (fixedSize)
								finalFlags |= kFixedSize;
							destID = DLM_NewObj(list, nameP, "", 0L, classID, (unsigned short)finalFlags, &err);
						}
					}
					break;
			}
		}
	}
	if NOT(err)
	{	if (resultObjRefP)
		{	resultObjRefP->list = list;
			resultObjRefP->id = destID;
			resultObjRefP->classID = classID;
			resultObjRefP->scope = theScope;	// ex resultObjRefP->scope = 0;
			if (finalFlags & kCostant)
				resultObjRefP->type = CONSTANT;
			else
				resultObjRefP->type = VARIABLE;
		}
	}
	
out:
return err;
}

//===========================================================================================
XErr	SetDefault(long api_data, ParameterRec *newParamP, char *paramDefaults, BAPI_ParameterDoc *protoParamP)
{
Boolean			canBeImmediate, isDefault;
XErr			err = noErr;
char			*tempP;
long			templen;
BifernoRecP		bRecP = (BifernoRecP)api_data;
long			classID = protoParamP->classID;

	tempP = paramDefaults;
	if (templen = CLen(paramDefaults))
		err = GetOneParameter(api_data, &tempP, &templen, nil, newParamP, &isDefault, false, true, kStopOnCR + kLoadParamOnStack, nil, 0);
	else
	{	if COMPILING(api_data)
			canBeImmediate = true;
		else
			canBeImmediate = (protoParamP->targetClassID == 0);
		err = CreateEmptyObject(api_data, nil, bRecP->volatileList, TEMP, classID, protoParamP->aeLevel, protoParamP->aeClassID, -1, canBeImmediate, (ObjRecord*)&newParamP->objRef);
		if COMPILING(api_data)
		{	
		ObjRecord	bicObjRef;
		
			if NOT(err)
			{	if NOT(err = BIC_GetBicObjRef(api_data, (ObjRecord*)&newParamP->objRef, &bicObjRef))
					err = BIC_LoadParam(api_data, &bicObjRef);
			}
		}
	}
return err;
}

//===========================================================================================
static Boolean _HasName(ParameterRec *paramVarsP, long totParams)
{
int		i;

	for (i = 0; (i < totParams); i++, paramVarsP++)
	{	if (*paramVarsP->name)
			return true;
	}

return false;
}

//===========================================================================================
//static XErr	_AnalyzePrototype(long api_data, Boolean isBiferno, long classID, ProtoParam *protoParamP, long totParamsInProto, char *prototype, Boolean dontCheckNumParams, Boolean dontCheckNames, ParameterRec *paramVarsP, long totParams, BlockRef *newParamBlockP, long *newTotParamsP)
static XErr	_AnalyzePrototype(long api_data, BAPI_Doc *docP, ParameterRec *paramVarsP, long totParams, BlockRef *newParamBlockP, long *newTotParamsP)
{
XErr				err = noErr;
Boolean				isNew;
ParameterRec 		*tParamVarsP;
int					paramsInProto, i;
BAPI_ParameterDoc	*tempProtoParamP;
BifernoRecP			bRecP = (BifernoRecP)api_data;
BlockRef			paramBL = 0;

Boolean				isBiferno, dontCheckNumParams, dontCheckNames;
long				classID, totParamsInProto;
BAPI_ParameterDoc	*protoParamP;
long				targetClassID;

	if NOT(docP->isDynamic)
	{	dontCheckNumParams = docP->info.method.varArgs;
		totParamsInProto = docP->totParams;
		dontCheckNames = docP->info.method.noNames;
		protoParamP = docP->params;
		classID = docP->info.method.classID;
		isBiferno = docP->implem == kBifernoImplementation;
		
		//if (*prototype)
		{	if (NOT(dontCheckNumParams) && (totParams > totParamsInProto))
			{	//CEquStr(bRecP->errMessage, prototype);
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
			}
			if (NOT(err) && totParamsInProto)
			{	ParameterRec	tempParam, *newParamP;
				int				j;
				
				paramsInProto = totParamsInProto;
				if ((totParamsInProto != totParams) || (_HasName(paramVarsP, totParams)))
				{	if (totParams > totParamsInProto)
						totParamsInProto = totParams;
					paramBL = NewBlockClear(sizeof(ParameterRec) * totParamsInProto, &err, (Ptr*)&newParamP);
					if NOT(err)
					{	LockBlock(paramBL);
						//newParamP = (ParameterRec*)GetPtr(paramBL);
						isNew = true;
					}
				}
				else
				{	newParamP = paramVarsP;
					isNew = false;
				}
				if NOT(err)
				{	if (totParamsInProto && protoParamP)
					{	tParamVarsP = paramVarsP;	
						// order parameters by names
						for (i = 0; (i < totParams) && NOT(err); i++, tParamVarsP++)
						{	if (*tParamVarsP->name)
							{	tempProtoParamP = protoParamP;
								for (j = 0; j < paramsInProto; j++, tempProtoParamP++)
								{	if NOT(CCompareStrings(tParamVarsP->name, tempProtoParamP->name))
										break;
								}
								if (j < paramsInProto)
								{	if (isNew)
									{	if (*newParamP[j].name)
											err = XError(kBAPI_Error, Err_DuplicatedParameter);
										else
										{	newParamP[j] = *tParamVarsP;
											CEquStr(newParamP[j].name, tParamVarsP->name);
										}
									}
									else if (j < totParams)
									{	if (*newParamP[j].name)
											err = XError(kBAPI_Error, Err_DuplicatedParameter);
										else
										{	tempParam = newParamP[j];
											newParamP[j] = *tParamVarsP;
											CEquStr(newParamP[j].name, tParamVarsP->name);
											*tParamVarsP = tempParam;
										}
									}
								}
								else
								{	if (dontCheckNames)
										newParamP[i] = *tParamVarsP;
									else
									{	err = XError(kBAPI_Error, Err_InvalidParameterName);
										NewMsgRecord(api_data, kPARAMETER, tParamVarsP->name, 0, 0);
										NewMsgRecord(api_data, kPROTOTYPE, docP->prototype, 0, 0);
										//*prototype = 0;
									}
								}
							}
							else
								newParamP[i] = *tParamVarsP;
						}
						
						// set defaults
						if NOT(err)
						{	
						long			requestedClassID, saveCurMethodClass;

							saveCurMethodClass = bRecP->methodInExecutionClass;
							bRecP->methodInExecutionClass = classID;
							tempProtoParamP = protoParamP;
							for (i = 0; i < paramsInProto; i++, newParamP++, tempProtoParamP++)
							{	if NOT(OBJ_ID(newParamP->objRef))
								{	//if (tempProtoParamP->byRef && NOT(newParamP->expLen))
									//	newParamP->expLen = FOR_ADDRESS_INVALID_LENGTH;
									/*if (tempProtoParamP->targetClassID)
										err = XError(kBAPI_Error, Err_InvalidParameter);
									else*/
									err = SetDefault(api_data, newParamP, tempProtoParamP->defaultStr, tempProtoParamP);
									if (NOT(err) && tempProtoParamP->targetClassID)		// skip checks
										continue;
								}
								
								/* if foraddress var is defined
								C func will write on it and non need to do _EvalForAddressParameters
								Biferno func will do Evaluate anyway (see Classes.c)
								*/
								/*else if (tempProtoParamP->byRef && NOT(isBiferno))
								{	if (newParamP->expLen)
									{	if (OBJ_SCOPE(newParamP->objRef) != TEMP)	// (if it is TEMP it needs for things like &a.length)
											newParamP->expLen = FOR_ADDRESS_INVALID_LENGTH;
									}
									else
										err = XError(kBAPI_Error, Err_PrototypeMismatch);
								}*/

								if NOT(err)
								{	if (tempProtoParamP->targetClassID)
									{	if (OBJ_CLASSID(newParamP->objRef) == gsDispatcherData.refConstructor)
										{	if (NOT(err = ref_GetTargetClass(api_data, &newParamP->objRef, &targetClassID, false)) && targetClassID)
											{	if (targetClassID == gsDispatcherData.refConstructor)
													err = XError(kBAPI_Error, Err_InvalidParameter);
												else if ((targetClassID != tempProtoParamP->targetClassID) && (tempProtoParamP->targetClassID != CLASSID_UNSPECIFIED)) 
												{	// err = XError(kBAPI_Error, Err_InvalidParameter);
													err = XError(kBAPI_Error, Err_IllegalTypeCast);
													NewMsgRecord(api_data, kTYPECAST, (char*)targetClassID, tempProtoParamP->targetClassID, kInputIsClassID);
												}
											}
										}
										else
											err = XError(kBAPI_Error, Err_RefParameterRequired);
									}
									else if (OBJ_CLASSID(newParamP->objRef) == gsDispatcherData.refConstructor)
									{	// modif. 25/9/2003
										if (OBJ_SCOPE(newParamP->objRef) == TEMP)	// user wrote explicitely: &var
											err = XError(kBAPI_Error, Err_InvalidRefParameter);
										else
										{	// instead of error, get the copy pointed by the ref automatically
											err = ref_GetTarget(api_data, &newParamP->objRef, &newParamP->objRef, true);
										}
										// ex: err = XError(kBAPI_Error, Err_InvalidRefParameter);
									}
									
									if NOT(err)
									{	// for byref parameter the class must be right, no implicit typecast
										requestedClassID = tempProtoParamP->classID;
										if (tempProtoParamP->targetClassID && (requestedClassID != CLASSID_UNSPECIFIED) && (requestedClassID != OBJ_CLASSID(newParamP->objRef)))
										{	/*if (OBJ_CLASSID(newParamP->objRef) == gsDispatcherData.refConstructor)
											{	if NOT(err = Ref_GetTargetClass(api_data, &newParamP->objRef, (ObjRefP)&target))
												{	if (target.classID != requestedClassID)
														err = XError(kBAPI_Error, Err_IllegalTypeCast);
												}
											}
											else*/
												err = XError(kBAPI_Error, Err_IllegalTypeCast);
										}
									}
								}
								if (err)
								{	NewMsgRecord(api_data, kPARAMETER, tempProtoParamP->name, 0, 0);
									break;
								}
							}
							bRecP->methodInExecutionClass = saveCurMethodClass;
						}
					}
				}
			}
		}
	}
	
	if (err)
	{	if (paramBL)
			DisposeBlock(&paramBL);
	}
	else
	{	*newParamBlockP = paramBL;
		*newTotParamsP = totParamsInProto;
	}

return err;
}

//===========================================================================================
static XErr	_TypeToObj(long api_data, ObjRecord *obj, ObjRecord *objVarP)
{
XErr	err = noErr;
CStr255	aCStr;

	if (IS_IMMEDIATE_P(obj))
		CEquStr(aCStr, "const");
	else
	{	switch(obj->type)
		{	case VARIABLE:
				CEquStr(aCStr, "var");
				break;
			case CONSTANT:
				CEquStr(aCStr, "const");
				break;
			default:
				err = XError(kBAPI_Error, Err_InvalidVariableType); 
				break;
		}
	}
	if NOT(err)
		err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), (ObjRef*)objVarP);

return err;
}

//===========================================================================================
static XErr	_ScopeToObj(long api_data, ObjRecord *obj, ObjRecord *objVarP)
{
XErr	err = noErr;
CStr255	aCStr;

	switch(obj->scope)
	{	case TEMP:
			CEquStr(aCStr, "temp");
			break;
		case LOCAL:
			CEquStr(aCStr, "local");
			break;
		case GLOBAL:
			CEquStr(aCStr, "global");
			break;
		case APPLICATION:
			CEquStr(aCStr, "application");
			break;
		case SESSION:
			CEquStr(aCStr, "session");
			break;
		case PERSISTENT:
			CEquStr(aCStr, "persistent");
			break;
		default:
			err = XError(kBAPI_Error, Err_InvalidScope);
			break;
	}
	if NOT(err)
		err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), (ObjRef*)objVarP);

return err;
}

//===========================================================================================
static XErr	_ClassToObj(long api_data, ObjRecord *obj, ObjRecord *objVarP)
{
XErr	err = noErr;
CStr255	aCStr;
CStr63	pluginName;

	if (obj->classID)
	{	if NOT(err = BAPI_NameFromClassID(api_data, obj->classID, pluginName))
		{	CEquStr(aCStr, pluginName);
			err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), (ObjRef*)objVarP);
		}
	}
	else
	{	CEquStr(aCStr, "[undefined]");
		err = BAPI_StringToObj(api_data, aCStr, CLen(aCStr), (ObjRef*)objVarP);
	}

return err;
}

//===========================================================================================
/*static XErr	_EvalForAddressParameters(long api_data, ExecuteMethodRec *execRecP, BAPI_Doc *docP)
{
XErr				err = noErr;
int					i;
long				totP, numPar = 0, totParamsInProto;
ParameterRec		*tParamVarsP;
ObjRecord			resultObjRef;
char				varName[MAX_VARIABLE_NAME_LENGTH];
Boolean				saveRIR;
BAPI_ParameterDoc 	*protoParamP;

	protoParamP = docP->params;
	totParamsInProto = docP->totParams;
	tParamVarsP = execRecP->paramVarsP;
	totP = execRecP->totParams;
	for (i = 0; (i < totP) && NOT(err); i++, tParamVarsP++)
	{	// for prototypes with ... no error if i > totParamsInProto
		if ((i >= totParamsInProto) || protoParamP[i].byRef)
		{	if (tParamVarsP->expLen > 0)
			{	saveRIR = RESULT_IS_RELEVANT(api_data);
				RESULT_IS_RELEVANT(api_data) = true;
				err = EvalVariable(api_data, &tParamVarsP->expP, &tParamVarsP->expLen, kExplicitTypeCast, (ObjRecordP)&tParamVarsP->objRef, false, false, &numPar, &resultObjRef, varName, nil, 0L, false, nil);
				RESULT_IS_RELEVANT(api_data) = saveRIR;
				if (err)
					NewMsgRecord(api_data, kPARAMETER, tParamVarsP->expP, tParamVarsP->expLen, 0);
			}
			else if ((i < totParamsInProto) && NOT(tParamVarsP->expLen) && (tParamVarsP->expLen != FOR_ADDRESS_INVALID_LENGTH))
				err = XError(kBAPI_Error, Err_PrototypeMismatch);
		}
		else if (tParamVarsP->expLen)
			err = XError(kBAPI_Error, Err_PrototypeMismatch);
	}

return err;
}
*/			
//===========================================================================================
/*XErr	GetErrorName(long api_data, long classID, char *errName)
{
PluginRecord*	plugRecP;
XErr			err = noErr;

	// Does the class have this error
	plugRecP = _GetPluginRecFromClassID(nil, classID);
	if (plugRecP)
	{	if (plugRecP->membersList)
			err = DLM_GetInfo(plugRecP->membersList, plugRecP->objBaseError+EVALUE(theError)-plugRecP->baseError+1, nil, nil, errName);
		else
			*errName = 0;
	}
	else
		err = BifernoGetErrorName(api_data, classID, EVALUE(theError), errName);
	if NOT(*errName)
		err = XError(kBAPI_Error, Err_NoSuchProperty);

return err;
}*/

#define	TOT_APPL_DEFAULTS		24
#define	TOT_APPL_DEFAULTS_PAD	28
//===========================================================================================
static XErr	_WriteDefaultConfig(XFileRef xrefNum)
{
XErr				err = noErr;
char				logStr[512];
long				cLen;
int					i;
CStr255				aCStr;
ApplVarDefaultRec	*applDefaultsP;
ApplVarDefaultRec	applDefaults[TOT_APPL_DEFAULTS] = 
{
	"APPLICATION_NAME",			"\"BifernoMain\"",			"Name of the application",
	"SESSION",					"false",					"Use session variables?",
	"SESSION_TIMEOUT",			"15",						"Timeouts for session users (minutes)",
	"MAX_ERRFILES",				"2048",						"Max error files in folder ERRORS_FOLDER",
	"DEVELOPER_IP",				"\"*,local\"",				"IPs of developers",
	"ERRORS_FOLDER",			"\"\"",						"Folder for error files",
	"ERROR_PAGE",				"\"\"",						"Page error for non-developer users",
	"ADMIN_PASSWORD",			"\"\"",						"Password for bifernoadmin",
	"ADMIN_IP",					"\"\"",						"IPs allowed to access bifernoadmin",
	"ADMIN_PROTOCOL",			"\"https\"",				"Protocols allowed by bifernoadmin",
	"FILE_NOT_FOUND_PAGE",		"\"\"",						"Page to serve if file not found",
	"CACHE",					"false",					"Cache files in memory?",
	"TIMEOUT",					"2",						"Scripts Timeout (minutes)",
	"HEADER",					"\"\"",						"Header file path",
	"FOOTER",					"\"\"",						"Footer file path",
	"ACCESS_CONTROL",			"\"\"",						"Security check file",
	"ACCESS_CONTROL_NOACCESS",	"\"\"",						"Security no access file",
	"ACCESS_CONTROL_REALM",		"\"\"",						"Security realm name",
	"DATE_FORMAT",				"\"d-m-y\"",				"Default format for dates",
	"WEBMASTER",				"\"webmaster@mysite.com\"",	"WebMaster",
	"MAIL_HOST",				"\"smtp.mysite.com\"",		"Smtp Mail Server Host",
	"NOTIFY_MAIL_ERR",			"false",					"Send mail to webmaster if error",
	"DECIMAL_SEP",				"\".\"",					"Decimal separator",
	"THOUSAND_SEP",				"\"\"",						"Thousand separator"
};
char		message[] = "/*%sThe following line determines the name of the application.%sThe struct of the line must be:%s\tAPPLICATION_NAME = \"myName\"%sMyName must be enclosed in \", (no \'), and MUST NOT contain the character \'\\\' or an escaped %scharacters (as \\\", \\r, \\n, \\v etc...)%sBesides, the name of the application has to be a literal string, that is:%s\tAPPLICATION_NAME = \"myName\";	// => is ok%s\t%s\ta = \"myName\"%s\tAPPLICATION_NAME		= a		// => is not allowed (return Err_BadSintaxInApplicationName)%sThese restrictions apply only to the APPLICATION_NAME line%s*/%s%s";
char		resultStr[1024];
Byte		theDecSep, theThousSep;
char		sepDate[2], sepTime[2];
int			dateOrder;

	dateOrder = GetSeparators(&theDecSep, &theThousSep, sepDate, sepTime);
	CEquStr(logStr, "<?biferno");
	CAddStr(logStr, EOL_STRING);
	cLen = CLen(logStr);
	if (err = WriteXFile(xrefNum, logStr, &cLen))
		goto out;
	
	sprintf(resultStr, message, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING, EOL_STRING);
	cLen = CLen(resultStr);
	if (err = WriteXFile(xrefNum, resultStr, &cLen))
		goto out;
	
	for (i = 0; i < TOT_APPL_DEFAULTS; i++)
	{	CEquStr(aCStr, applDefaults[i].name);
		PadString((Byte*)aCStr, (short)CLen(aCStr), TOT_APPL_DEFAULTS_PAD, ' ', false);
		CEquStr(logStr, aCStr);
		
		CAddStr(logStr, "\t=\t");
		
		if NOT(CCompareStrings_cs(applDefaults[i].name, "DATE_FORMAT"))
		{	CEquStr(aCStr, "\"");
			switch(dateOrder)
			{	default:
				case _MDY:
					CAddStr(aCStr, "m");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "d");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "y");
					break;
				case _DMY:
					CAddStr(aCStr, "d");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "m");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "y");
					break;
				case _YMD:
					CAddStr(aCStr, "y");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "m");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "d");
					break;
				case _MYD:
					CAddStr(aCStr, "m");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "y");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "d");
					break;
				case _DYM:
					CAddStr(aCStr, "d");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "y");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "m");
					break;
				case _YDM:
					CAddStr(aCStr, "y");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "d");
					CAddStr(aCStr, sepDate);
					CAddStr(aCStr, "m");
					break;		
			}
			CAddStr(aCStr, " h");
			CAddStr(aCStr, sepTime);
			CAddChar(aCStr, 'm');
			CAddStr(aCStr, sepTime);
			CAddChar(aCStr, 's');
			CAddChar(aCStr, '\"');
		}
		else if NOT(CCompareStrings_cs(applDefaults[i].name, "DECIMAL_SEP"))
		{	CEquStr(aCStr, "\"");
			CAddChar(aCStr, theDecSep);
			CAddChar(aCStr, '\"');
		}
		else if NOT(CCompareStrings_cs(applDefaults[i].name, "THOUSAND_SEP"))
		{	CEquStr(aCStr, "\"");
			CAddChar(aCStr, theThousSep);
			CAddChar(aCStr, '\"');
		}
		else
			CEquStr(aCStr, applDefaults[i].value);
		CAddStr(aCStr, ";");
		PadString((Byte*)aCStr, (short)CLen(aCStr), TOT_APPL_DEFAULTS_PAD, ' ', false);
		CAddStr(logStr, aCStr);

		CAddStr(logStr, "\t/* ");
		CAddStr(logStr, applDefaults[i].comment);
		CAddStr(logStr, " */");
		CAddStr(logStr, EOL_STRING);
		if NOT(i)
			CAddStr(logStr, EOL_STRING);
		cLen = CLen(logStr);
		if (err = WriteXFile(xrefNum, logStr, &cLen))
			goto out;
			
		if NOT(CCompareStrings_cs(applDefaults[i].name, "ADMIN_PASSWORD"))
		{	CEquStr(message, "object.Hide(ADMIN_PASSWORD);");
			CAddStr(message, EOL_STRING);
			cLen = CLen(message);
			if (err = WriteXFile(xrefNum, message, &cLen))
				goto out;
		}
	}
	
	if (gTotDefaults)
	{	CEquStr(logStr, EOL_STRING);
		cLen = CLen(logStr);
		if (err = WriteXFile(xrefNum, logStr, &cLen))
			goto out;
		LockBlock(gDefaultsBlock);
		applDefaultsP = (ApplVarDefaultRec*)GetPtr(gDefaultsBlock);
		for (i = 0; i < gTotDefaults; i++, applDefaultsP++)
		{	CEquStr(aCStr, applDefaultsP->name);
			PadString((Byte*)aCStr, (short)CLen(aCStr), TOT_APPL_DEFAULTS_PAD, ' ', false);
			CEquStr(logStr, aCStr);
			
			CAddStr(logStr, "\t=\t");
			
			CEquStr(aCStr, applDefaultsP->value);
			CAddStr(aCStr, ";");
			PadString((Byte*)aCStr, (short)CLen(aCStr), TOT_APPL_DEFAULTS_PAD, ' ', false);
			CAddStr(logStr, aCStr);

			CAddStr(logStr, "\t/* ");
			CAddStr(logStr, applDefaultsP->comment);
			CAddStr(logStr, " */");
			CAddStr(logStr, EOL_STRING);
			cLen = CLen(logStr);
			if (err = WriteXFile(xrefNum, logStr, &cLen))
				goto out;
		}
		UnlockBlock(gDefaultsBlock);
	}
	CEquStr(logStr, EOL_STRING);
	CAddStr(logStr, "if (file.Exists(biferno.home + \"Utils/Utils.bfr\"))");
	CAddStr(logStr, EOL_STRING);
	CAddStr(logStr, "\tinclude(biferno.home + \"Utils/Utils.bfr\")");
	CAddStr(logStr, EOL_STRING);
	cLen = CLen(logStr);
	if (err = WriteXFile(xrefNum, logStr, &cLen))
		goto out;

	// Debug page
	CEquStr(logStr, EOL_STRING);
	CAddStr(logStr, "if (file.Exists(biferno.home + \"bifernoadmin/DebugPage/debug.x.bfr\"))");
	CAddStr(logStr, EOL_STRING);
	CAddStr(logStr, "{");
	CAddStr(logStr, EOL_STRING);
	CAddStr(logStr, "\tDEBUG_PAGE = biferno.home + \"bifernoadmin/DebugPage/debug.x.bfr\";");
	CAddStr(logStr, EOL_STRING);
	CAddStr(logStr, "\tDEBUG_PAGE_LIMIT = 1024;");
	CAddStr(logStr, EOL_STRING);
	CAddStr(logStr, "}");
	CAddStr(logStr, EOL_STRING);
	cLen = CLen(logStr);
	if (err = WriteXFile(xrefNum, logStr, &cLen))
		goto out;
	
	CEquStr(logStr, "?>");
	CAddStr(logStr, EOL_STRING);
	cLen = CLen(logStr);
	if (err = WriteXFile(xrefNum, logStr, &cLen))
		goto out;
	
out:
return err;
}

//===========================================================================================
static XErr	_CheckGlobalErr(BifernoRecP bRecP, long destList, long destObjID, long destclassid)
{	
XErr			err = noErr;
ObjRecord		destObjVar;

	if ((destclassid == gsDispatcherData.errConstructor) && (destList == bRecP->globErrObjRef.list) && (destObjID == bRecP->globErrObjRef.id))
	{	
	long	errNum;
		
		destObjVar.list = destList;
		destObjVar.id = destObjID;
		destObjVar.classID = destclassid;
		if NOT(err = BAPI_ObjToInt((long)bRecP, OBJREF_P(&destObjVar), &errNum, kExplicitTypeCast))
		{	if (errNum)
				err = BAPI_Exception((long)bRecP, kBAPI_Error, errNum, nil, false);
		}
	}

return err;
}

//===========================================================================================
static XErr	_BeforeModify(DLMRef list, long id, unsigned short flags, long classid, long param)
{
//unsigned short	flags;
XErr			err = noErr;
//long			classid;
BfrDestructRec	*destructRecP = (BfrDestructRec*)param;
ObjRecord 		objRef;

	//if NOT(err = DLM_GetInfo(list, id, &flags, &classid, nil))
	{	if NOT(flags & kNoDestructor)
		{	objRef.list = list;
			objRef.id = id;
			objRef.classID = classid;
			if (flags & kCostant)
				objRef.type = CONSTANT;
			else
				objRef.type = VARIABLE;
			objRef.scope = destructRecP->scope;
			err = DestructVariableWithAllSupers(destructRecP->api_data, &objRef);
			// ex err = VariableDestructorExt(list, id, 0, classid, param);
		}
		/*	if NOT(err)
				err = DLM_TurnOnFlag(list, id, kNoDestructor, kDLMMain);	// don't destruct this again before reinitializing it
		}*/
	}

return err;
}

//===========================================================================================
static XErr	_AfterModify(long api_data, long list, long id)
{
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;

	if (list == bRecP->volatileList)
	{	if (DLM_IsArray(list, id))
			err = DLM_TurnOffFlag(list, id, kIsArray, kDLMMain);
		err = DLM_TurnOnFlag(list, id, kNoDestructor, kDLMElements);
	}
	else
		CDebugStr("_AfterModify: the value comes not from volatile");
	
return err;
}

//===========================================================================================
XErr	ModifyObjCheckDestructors(long api_data, DLMRef destList, long destObjID, long destclassid, long destScope, DLMRef valueList, long valueID, long valueClassID)
{	
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
BfrDestructRec	destructRec;

	if (destclassid != valueClassID)
	{	NewMsgRecord(api_data, kTYPECAST, (char*)valueClassID, destclassid, kInputIsClassID);
		return XError(kBAPI_Error, Err_IllegalTypeCast); 
	}
	//if NOT(err = _BeforeModify(api_data, destList, destObjID))
	{	
		destructRec.api_data = api_data;
		destructRec.scope = destScope;
		if NOT(err = DLM_ModifyObjExt(destList, destObjID, valueList, valueID, VariableDestructorExt, (long)&destructRec, _BeforeModify))
			_AfterModify(api_data, valueList, valueID);
	}
	if NOT(err)
		_CheckGlobalErr(bRecP, destList, destObjID, destclassid);

return err;
}

//===========================================================================================
XErr	ModifyObjBufferCheckDestructors(long api_data, DLMRef destList, long destObjID, long destclassid, long destScope, void* dataP, long dataLen, long classID)
{	
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
BfrDestructRec	destructRec;

	if (destclassid != classID)
	{	NewMsgRecord(api_data, kTYPECAST, (char*)classID, destclassid, kInputIsClassID);
		return XError(kBAPI_Error, Err_IllegalTypeCast); 
	}
	//if NOT(err = _BeforeModify(api_data, destList, destObjID))
	destructRec.api_data = api_data;
	destructRec.scope = destScope;
	err = DLM_ModifyObj(destList, destObjID, dataP, dataLen, classID, VariableDestructorExt, (long)&destructRec, _BeforeModify);
	if NOT(err)
		_CheckGlobalErr(bRecP, destList, destObjID, destclassid);

return err;
}

//===========================================================================================
XErr	BufferToObjExt(long api_data, void* dataP, long dataLen, long classID, Boolean fixedSize, char *resultObjName, long scope, long type, ObjRefP objRefP)
{	
XErr					err = noErr;
ConstructorAPIdataRec	constrData;

	constrData.scope = scope;
	constrData.type = type;
	CEquStr(constrData.resultObjName, resultObjName);
	err = BAPI_BufferToObj(api_data, dataP, dataLen, classID, fixedSize, (long)&constrData, (ObjRefP)objRefP);

return err;
}

//===========================================================================================
XErr	ArrayToObjExt(long api_data, Boolean fixedSize, char *resultObjName, long scope, long type, ParameterRec *varRecsP, long totVars, long *errElemIDXP, ObjRefP objRefP)
{
XErr					err = noErr;
ConstructorAPIdataRec	constrData;

	constrData.scope = scope;
	constrData.type = type;
	CEquStr(constrData.resultObjName, resultObjName);
	err = BAPI_ArrayToObj(api_data, fixedSize, varRecsP, totVars, errElemIDXP, (long)&constrData, objRefP);

return err;
}

//===========================================================================================
static XErr	_CheckClassScope(long classID, long scope)
{
XErr	err = noErr;

	if ((scope > GLOBAL) && (classID < 0) && IS_LOCAL(classID))
		err = XError(kBAPI_Error, Err_IllegalScopeForObject);

return err;
}

//===========================================================================================
static XErr	_GetArrayElemClassRecursive(long api_data, ObjRecordP arrayObjP, long *classIDP)
{
	long		arrayDim, finalClassId;
	ObjRecord	tObjRef;
	XErr		err = noErr;
	
	// get classid of elements
	tObjRef = *arrayObjP;
	do
	{
		if not(err = DLM_GetArrayInfo(tObjRef.list, tObjRef.id, nil, nil, &arrayDim, &finalClassId))
		{
			if (finalClassId == gsDispatcherData.arrayConstructor)
			{	
				if (arrayDim)
					err = BAPI_ElementOfArray(api_data, (ObjRefP)&tObjRef, 1, (ObjRefP)&tObjRef);
				else
				{
					finalClassId = 0;
					break;
				}
			}
			else
				break;
		}
	} while not(err);
	
	*classIDP = finalClassId;
	return err;
}

//===========================================================================================
XErr	CopyObjectExt(long api_data, ObjRefP sourceObj, char *resultObjName, long scope, long type, ObjRefP destObj)
{	
XErr					err = noErr;
ConstructorAPIdataRec	constrData;

	if (scope >= GLOBAL)
	{
	Boolean		allowed;
	long		finalClassId;
		
		if (OBJ_CLASSID_P(sourceObj) == gsDispatcherData.arrayConstructor)
			err = _GetArrayElemClassRecursive(api_data, (ObjRecordP)sourceObj, &finalClassId);
		else
			finalClassId = OBJ_CLASSID_P(sourceObj);
		if NOT(err)
		{
			if NOT(err = _CheckClassScope(finalClassId, scope))
			{	
				if NOT(err = BAPI_ScopeAllowed(api_data, sourceObj, scope, &allowed))
				{	
					if NOT(allowed)
						err = XError(kBAPI_Error, Err_IllegalScopeForObject);
				}
			}
		}
	}
	if NOT(err)
	{	constrData.scope = scope;
		constrData.type = type;
		if (resultObjName)
			CEquStr(constrData.resultObjName, resultObjName);
		else
			*constrData.resultObjName = 0;
		err = BAPI_CopyObj(api_data, sourceObj, (long)&constrData, (ObjRefP)destObj);
	}
	
return err;
}

//===========================================================================================
XErr	CheckSetProperty(MemberAction *membActionP)
{
ObjRecordP 		varToSet = &membActionP->objRef;
long			type = membActionP->doc.type;

	//if (membIdentP->memberIsError)
	if ((type == kError) || (type == kConstant))
		return XError(kBAPI_Error, Err_IllegalOperationOnConstant);

	//if (membIdentP->memberIsConstant)
	if ((type == kProperty) && membActionP->doc.info.property.isConst)
		return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
	
	//if (membActionP->memberPluginID == BUILTIN_PROPERTY_MAGIC_NUMBER)
	if (membActionP->doc.isBuiltIn)
		return XError(kBAPI_Error, Err_PropertyIsOnlyRead);

	if (NOT(membActionP->doc.isStatic) && (varToSet->type == CONSTANT))
		return XError(kBAPI_Error, Err_IllegalOperationOnConstant);

return noErr;
}

#if __MWERKS__
#pragma mark-
#endif
//===========================================================================================
BAPI_ModifyHook	GetModifyHook(long classID)
{
BAPI_ModifyHook		res;

	if (--classID >= 0)
		res = gClassRecordBlockP[classID].modifyHook;
	else
		res = nil;

return res;
}

//===========================================================================================
BAPI_IncrementHook		GetIncrementHook(long classID)
{
BAPI_IncrementHook		res;

	if (--classID >= 0)
		res = gClassRecordBlockP[classID].incrementHook;
	else
		res = nil;

return res;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static XErr	LoadGenericSymbols()
{
XErr		err = noErr;
long		httpPageClassID;
long		refClassID;

	if (httpPageClassID = BAPI_ClassIDFromName(0, "httpPage", false))
	{	if (err = BAPI_GetSymbol(0, httpPageClassID, "HttpPage_Print", (long*)&page_Print))
			goto out;
		if (err = BAPI_GetSymbol(0, httpPageClassID, "HttpPage_GetOutput", (long*)&page_GetOutput))
			goto out;
	}
	else
	{	page_Print = nil;
		page_GetOutput = nil;
	}
	if (refClassID = BAPI_ClassIDFromName(0, "ref", false))
	{	if (err = BAPI_GetSymbol(0, refClassID, "Ref_GetTarget", (long*)&ref_GetTarget))
			goto out;
		if (err = BAPI_GetSymbol(0, refClassID, "Ref_NewReference", (long*)&ref_NewReference))
			goto out;
		if (err = BAPI_GetSymbol(0, refClassID, "Ref_GetTargetClass", (long*)&ref_GetTargetClass))
			goto out;
		//if (err = BAPI_GetSymbol(0, refClassID, "Ref_SetTarget", (long*)&ref_SetTarget))
		//	goto out;
	}
	else
	{	ref_GetTarget = nil;
		ref_NewReference = nil;
		ref_GetTargetClass = nil;
		//ref_SetTarget = nil;
	}
	//if (err = BAPI_GetSymbol(0, httpPageClassID, "HttpPage_DisposeOutput", (long*)&page_DisposeOutput))
	//	goto out;
	if (err = BAPI_GetSymbol(0, BAPI_ClassIDFromName(0, "multipart", false), "multiPart_NewObject", (long*)&multiPart_NewObject))
		goto out;
	//if (err = BAPI_GetSymbol(0, BAPI_ClassIDFromName(0, "error", false), "error_UpdateEMsgRecord", (long*)&error_UpdateEMsgRecord))
	//	goto out;

out:
return err;
}

//===========================================================================================
XErr	CL_Init(LogCallBack	logCallBack, void *userData, long maxUsers)
{
XErr		err = noErr;
CStr255		aCStr, bifHomePath;
CStr63		printName;
long		cLen;
char		*strP;
CStr255		extensionsPath, logStr;
LogRec		logRec;
CStr255		bifernoHomeConfig;
BlockRef	resultText;
long		resultSize;

	gRunID = 1;
		
	logRec.logCallBack = logCallBack;
	logRec.userData = userData;
	
	gsCallBacksBlock = nil;
	gTotStaticClasses = gDefaultsBlock = 0;
	gsBifernoCurrentUsers = 0;
	if (err = _InitCallBacksAPI())
		return err;
	
//#ifndef JAVA_ENABLED
	//if (logCallBack)
	//	logCallBack(userData, "[THIS VERSION IS COMPILED WITH JAVA DISABLED]");
//#else
//	if (logCallBack)
//		logCallBack(userData, "[JAVA IS ENABLED]");
//#endif
/*#ifndef JAVAPLUGINS
	if (logCallBack)
		logCallBack(userData, "[THIS VERSION IS COMPILED WITH JAVA PLUGINS DISABLED]");
#endif*/
	
	if (logCallBack)
		logCallBack(userData, "Filling lists...");
	// lista delle reserved keywords
	if (err = DLM_Create(&gsDispatcherData.reservedKeyword, NAMECS_LIST, LOCAL_LIST))
	{	if (logCallBack)
			logCallBack(userData, " Error creating reserved keyword list");
		return err;
	}
	// lista dei flow controls
	if (err = DLM_Create(&gsDispatcherData.flowControls, NAMECS_LIST, LOCAL_LIST))
	{	if (logCallBack)
			logCallBack(userData, " Error creating flow controls list");
		return err;
	}
	// lista delle funzioni (non legate ad una specifica classe)
	if (err = DLM_Create(&gsDispatcherData.functionsList, NAMECS_LIST, GLOBAL_LIST))
	{	if (logCallBack)
			logCallBack(userData, " Error creating functions list");
		return err;
	}
	
	// lista delle application lists
	if (err = DLM_Create(&gsDispatcherData.globApplicationListArray, NAMECS_LIST, GLOBAL_LIST))
	{	if (logCallBack)
			logCallBack(userData, " Error creating list of application lists");
		return err;
	}

	/*if (err = DLM_Create(&gsDispatcherData.prototypes, ID_LIST, GLOBAL_LIST))
	{	if (logCallBack)
			logCallBack(userData, " Error creating list of prototypes");
		return err;
	}*/
		
	// lista degli errori
	if (err = DLM_Create(&gsDispatcherData.errorList, NAMECS_LIST, GLOBAL_LIST))
	{	if (logCallBack)
			logCallBack(userData, " Error creating list of errors");
		return err;
	}
	if (err = _FillGlobalErrorList())
	{	if (logCallBack)
			logCallBack(userData, " Error filling list of errors");
		return err;
	}
	
	// lista delle sessions lists
	/*if (err = DLM_Create(&gsDispatcherData.sessionListArray, NAMECS_LIST, GLOBAL_LIST))
	{	if (logCallBack)
			logCallBack(userData, " Error creating list of application lists");
		return err;
	}*/

	if (err = _FillList(gsDispatcherData.reservedKeyword, gsKeyword, TOT_RESERVED_KEYWORDS))
		return err;
	if (err = _FillList(gsDispatcherData.flowControls, gsFlowControls, TOT_FLOW_CONTROLS))
		return err;
	
	// lista delle variabili valide across boot
	if (logCallBack)
		logCallBack(userData, "Loading server variables...");
	
	/*gsDispatcherData.serverList = 0;
	if NOT(err = XGetApplicationFolderPath(biferno_ServerDLMFilePath))
	{	CAddStr(biferno_ServerDLMFilePath, "Biferno_Server.dlm");
		if (err = DLM_Load(biferno_ServerDLMFilePath, NAMECS_LIST, true, &gsDispatcherData.serverList))
		{	if (logCallBack)
				logCallBack(userData, " Error reading server list: no server variable available");
			return err;
		}
	}*/
	
	if NOT(err)
	{	if NOT(err = XGetApplicationFolderPath(bifHomePath))
		{	if (logCallBack)
			{	CEquStr(logStr, "Biferno home is: ");
				CAddStr(logStr, bifHomePath);
				logCallBack(userData, logStr);
			}
			
			CEquStr(extensionsPath, bifHomePath);
			CAddStr(extensionsPath, "Extensions");
			if (CheckPath(extensionsPath, true) != noErr)
				err = CreateXFolder(extensionsPath);

			CEquStr(gPersistentFolder, bifHomePath);
			CAddStr(gPersistentFolder, "Persistent");
			if (CheckPath(gPersistentFolder, true) != noErr)
				err = CreateXFolder(gPersistentFolder);
			CAddStr(gPersistentFolder, "/");
		}
	}
					
	if NOT(err)
	{	if (gDefaultsBlock = NewBlock(sizeof(ApplVarDefaultRec), &err, nil))
		{	gTotDefaults = 0;
			if (gsDispatcherData.classRecordBlock = NewBlock(1, &err, nil))
			{	if NOT(err = DLM_Create(&gsDispatcherData.classListRef, NAMECS_LIST, LOCAL_LIST))
				{	gsDispatcherData.totClass = 0;
					gsDispatcherData.maxUsers = maxUsers;
					if NOT(err = _LoadStaticXClasses(logCallBack, userData))
					{	if NOT(gsDispatcherData.totClass)
							return -1;		// ok, panico
						else
						{	if (logCallBack)
								logCallBack(userData, "");
							logRec.macosxBundle = false;
							err = WalkXFolder(extensionsPath, nil, true, _LoadDynamicClass, (long)&logRec);
							#if __MACOSX__ && __USE_CARBON_FRAMEWORK__
								if NOT(err)
								{	logRec.macosxBundle = true;
									err = LoadBundles(extensionsPath, _LoadDynamicClass, (long)&logRec);							
								}
							#endif
							if (err && logCallBack)
							{	sprintf(aCStr, "Error on path: %s", extensionsPath);
								logCallBack(userData, aCStr);
							}
						}
						if NOT(err)
						{	//if NOT(err = _LoadJavaClasses(logCallBack, userData))
							{	if (logCallBack)
								{	if (err = logCallBack(userData, ""))
										return err;
									if (err = logCallBack(userData, "Initializing..."))
										return err;
								}
								err = _InitAllClasses(logCallBack, userData);
							}
						}
					}
				}
			}
		}
	}

	if NOT(err)
	{	
	Boolean		exists;
	
		CEquStr(printName, "print");
		CEquStr(aCStr, "(");
		cLen = 1;
		strP = aCStr;
		err = GetFunctionInfo(0, &strP, &cLen, printName, &gsDispatcherData.printDocBlock/*&gsDispatcherData.printFuncID, &gsDispatcherData.printObjID*/, &exists);

		DLM_NewObj(gsDispatcherData.reservedKeyword, "print", 0, 0, 0, 0, &err);
		//	err = -2;
		
		if NOT(err)
		{	if (logCallBack)
			{	if (err = logCallBack(userData, ""))
					return err;
				if (err = logCallBack(userData, "========================="))
					return err;
				if (err = logCallBack(userData, ""))
					return err;
			}
		}
	}
	
	
	// Load utilis symbols
	if NOT(err)
		err = LoadGenericSymbols();

	if NOT(err)
	{	LockBlock(gsDispatcherData.classRecordBlock);
		gClassRecordBlockP = (PluginRecord*)GetPtr(gsDispatcherData.classRecordBlock);
		//_PasswordFile();
		if (logCallBack)
			logCallBack(userData, "Registering Biferno Main...");
		if NOT(err = XGetApplicationFolderPath(bifernoHomeConfig))
		{	CStr255	theAppName;
		
			CAddStr(bifernoHomeConfig, BIFERNO_CONFIG);
			CEquStr(theAppName, BIFERNO_MAIN_NAME);
			if (err = CheckPath(bifernoHomeConfig, true))
			{	XFileRef xrefNum;
			
				if NOT(err = OpenXFile(bifernoHomeConfig, CREATE_FILE_NEW, READ_WRITE_PERM, false, &xrefNum))
				{	err = _WriteDefaultConfig(xrefNum);
					CloseXFile(&xrefNum);
				}
			}
			if NOT(err = RegisterApplication(theAppName, bifernoHomeConfig, &resultText, &resultSize, true, userData))
			{	if (resultText)
				{	CEquStr(aCStr, EOL_STRING);
					CAddStr(aCStr, START_BCONFIG_SCRIPT);
					CAddStr(aCStr, EOL_STRING);
					HTTPControllerWindowOutput((void*)userData, aCStr, CLen(aCStr));
					if (err = HTML2Txt(&resultText, &resultSize, true))	// Skip the header (at init no web context)
						DisposeBlock(&resultText);
					else
						err = HTTPControllerWindowOutputExt((void*)userData, resultText, resultSize);
					CEquStr(aCStr, EOL_STRING);
					CAddStr(aCStr, END_BCONFIG_SCRIPT);
					CAddStr(aCStr, EOL_STRING);
					HTTPControllerWindowOutput((void*)userData, aCStr, CLen(aCStr));
					if (logCallBack)
						logCallBack(userData, "...registration failed");
				}
				else if (logCallBack)
					logCallBack(userData, "...registered successfully");
			}
		}
	}
	if (gDefaultsBlock)
		DisposeBlock(&gDefaultsBlock);
	
return err;
}

//===========================================================================================
XErr	CL_ShutDown(LogCallBack	logCallBack, void *userData)
{
XErr				err = noErr, err2 = noErr;
long				totClass, i;
PluginRecord		*plugRecP;
Biferno_ParamBlock 	pb;
//long				userData = gsDispatcherData.logUserData;
#if __MAC_XLIB__ && !__MACOSX__
	short				oldres;
#endif

	// DumpServersLists(logCallBack, userData);
	
	XLibReset_JVM_API();
	CloseAllApplications(logCallBack, userData);
	
	ClearBlock(&pb, sizeof(Biferno_ParamBlock));
	if (gsDispatcherData.classRecordBlock)
	{	plugRecP = (PluginRecord*)GetPtr(gsDispatcherData.classRecordBlock);
		LockBlock(gsDispatcherData.classRecordBlock);
		gClassRecordBlockP = (PluginRecord*)GetPtr(gsDispatcherData.classRecordBlock);
		totClass = gsDispatcherData.totClass;
		for (i = 0; i < totClass; i++, plugRecP++)
		{	pb.api_data = 0L;
			pb.plugin_global_dataP = &plugRecP->plugin_global_data;
			//pb.param.shutDownRec.reloading = reloading;
			if (plugRecP->successfull)
			{	if (err = _CallEntryPoint(0L, plugRecP, kShutDown, &pb))
				{	if (logCallBack)
						logCallBack(userData, "Error on shut down");
				}
				
				if NOT(plugRecP->moreDispatcher)
				{	if (plugRecP->dllRef)
						XFreeDLL(&plugRecP->dllRef, plugRecP->macosxBundle);
				#if __MAC_XLIB__ && !__MACOSX__
					if (plugRecP->pluginMacOSResourceFork)
					{	oldres = CurResFile();
						if (plugRecP->pluginMacOSResourceFork != -1)
							CloseResFile(plugRecP->pluginMacOSResourceFork);
						UseResFile(oldres);
					}
				#endif
				}
			
				if (plugRecP->membersList)
					DLM_DisposeGlobal(&plugRecP->membersList, nil, 0);
				if (plugRecP->symbolList)
					DLM_DisposeGlobal(&plugRecP->symbolList, nil, 0);
				if (plugRecP->constructor)
					DisposeBlock(&plugRecP->constructor);
			}
		}
	}
	DLM_DisposeGlobal(&gsDispatcherData.classListRef, nil, 0);
	DLM_DisposeGlobal(&gsDispatcherData.functionsList, nil, 0);
	
	DLM_DisposeGlobal(&gsDispatcherData.globApplicationListArray, nil, 0);
	DLM_DisposeGlobal(&gsDispatcherData.errorList, nil, 0);
	
	DLM_DisposeGlobal(&gsDispatcherData.reservedKeyword, nil, 0);
	DLM_DisposeGlobal(&gsDispatcherData.flowControls, nil, 0);
	DisposeBlock(&gsDispatcherData.classRecordBlock);

	if (gsCallBacksBlock)
		DisposeBlock(&gsCallBacksBlock);
	
	if (gsDispatcherData.printDocBlock)
		DisposeBlock(&gsDispatcherData.printDocBlock);
	
	err2 = CFFlush(true);
	if (err2 && NOT(err))
		err = err2;
	
return err;
}

//===========================================================================================
XErr	CL_Run(PluginRecord	*plugRecP, Biferno_ParamBlock *pbPtr)
{
XErr		err = noErr;
BifernoRec	*bRecP = (BifernoRecP)pbPtr->api_data;

	if (plugRecP->successfull)
	{	CEquStr(pbPtr->param.runRec.serverName, bRecP->serverName);
		err = _CallEntryPoint(bRecP, plugRecP, kRun, pbPtr);
	}

return err;
}

//===========================================================================================
XErr	CL_Exit(PluginRecord *plugRecP, Biferno_ParamBlock *pbPtr)
{
XErr		err = noErr;
BifernoRec	*bRecP = (BifernoRecP)pbPtr->api_data;

	if (plugRecP->successfull)
	{	
		if (err = _CallEntryPoint(bRecP, plugRecP, kExit, pbPtr))
			CEquStr(bRecP->class_error_note, pbPtr->error);
	}

return err;
}
#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
XErr	GetContructorDoc(long api_data, long classID, BAPI_Doc **docP)
{
BlockRef		constrDoc;
PluginRecord*	plugRecP;
long			tLen;
XErr			err = noErr;
BifernoRec		*bRecP = (BifernoRec*)api_data;

	*docP = nil;
	if (classID > 0)
	{	plugRecP = &gClassRecordBlockP[classID-1];
		if (plugRecP->constructor)
			*docP = (BAPI_Doc*)GetPtr(plugRecP->constructor);
	}
	else if (bRecP)
	{	tLen = sizeof(BlockRef);
		if IS_LOCAL(classID)
		{	classID += LOCAL_ID_OFFSET;
			err = DLM_GetObj(bRecP->local.classList, -classID, (Ptr)&constrDoc, &tLen, offsetof(BifernoClass,constructorDoc)+1, nil);
		}
		else
			err = DLM_GetObj(bRecP->application.classList, -classID, (Ptr)&constrDoc, &tLen, offsetof(BifernoClass,constructorDoc)+1, nil);
		if NOT(err)
		{	if (constrDoc)
				*docP = (BAPI_Doc*)GetPtr(constrDoc);
		}
	}
	
return err;
}

//===========================================================================================
static XErr 	_CloneObjWithSuper(long api_data, ObjRefP objToCloneP, ConstructorRec *constrRecP)
{
XErr		err = noErr;
long		tLen;
BlockRef	block;
Ptr			buffP;
ObjRef		superObjRef, newSuperObjRef;
long 		classID;
Boolean		fixedSize;

	if NOT(err = BAPI_ReadObj(api_data, objToCloneP, nil, &tLen, 0, nil))
	{	if (block = NewBlockLocked(tLen, &err, &buffP))
		{	if NOT(err = BAPI_ReadObj(api_data, objToCloneP, (Ptr)buffP, &tLen, 0, nil))
			{	if NOT(err = BAPI_GetSuperObj(api_data, objToCloneP, &superObjRef))
				{	INVAL(newSuperObjRef);
					if NOT(err = BAPI_Clone(api_data, &superObjRef, &newSuperObjRef, true))
					{	classID = OBJ_CLASSID_P(objToCloneP);
						if NOT(err = BAPI_FixedSize(api_data, classID, &fixedSize))
							err = BAPI_BufferToObjWithSuper(api_data, (Ptr)buffP, tLen, classID, fixedSize, &newSuperObjRef, constrRecP->privateData, &constrRecP->resultObjRef);
					}
				}
			}
			DisposeBlock(&block);
		}
	}

return err;
}
	
//===========================================================================================
Boolean WantCloneEvent(PluginRecord* plugRecP, Boolean *extendsP)
{
Boolean 	wantCloneEvent;
long		ext;

	if (plugRecP->wantDestructor)
		wantCloneEvent = true;
	else
	{	wantCloneEvent = false;
		if (extendsP)
		{	if (plugRecP->extendedPluginID)
				*extendsP = true;
			else
				*extendsP = false;
		}
		else
		{	while (ext = plugRecP->extendedPluginID)
			{	if (ext < 0)
				{	wantCloneEvent = true;
					break;
				}
				else
				{	plugRecP = &gClassRecordBlockP[ext-1];
					if (plugRecP->wantDestructor)
					{	wantCloneEvent = true;
						break;
					}
					else
						wantCloneEvent = false;
				}		
			}
		}
	}		

return wantCloneEvent;
}

//===========================================================================================
// Called for kConstructor, kTypeCast and kClone (check event param)
static XErr	_Constructor(long api_data, long scope, long type, char *resultObjName, long classID,
								ParameterRec *varRecsP, long totVars, long typeCastType, ObjRecord *resultObjRefP, long event, Boolean cloneTarget, BAPI_Doc *docP)
{
Biferno_ParamBlock 		*pbPtr;
XErr					err = noErr;
PluginRecord*			plugRecP;
BifernoRec				*bRecP;
ConstructorRec			*constrRecP;
BlockRef				/*protoParamBlock, */newParamBl = 0;
long					newTotParams;
//ProtoParam			*protoParamP;
//Boolean				dontCheckNames, dontCheckNumParams;
CStr255					prototype;
uint32_t				/*totParamsInProto, */slot;
ConstructorAPIdataRec	constrData;
//BlockRef				membIdentBlock;

	*prototype = 0;
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if ((event == kClone) && NOT(OBJ_ID(varRecsP->objRef)))
	{	*resultObjRefP = *(ObjRecord*)&varRecsP->objRef;
		return noErr;
	}
	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	//*prototype = 0;
		ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRecFromClassID(pbPtr, classID);	
		constrRecP = &pbPtr->param.constructorRec;
		constrRecP->resultObjRef = OBJREF(*resultObjRefP);
		if (resultObjName)
			CEquStr(constrData.resultObjName, resultObjName);
		else
			*constrData.resultObjName = 0;
		constrData.scope = scope;
		constrData.type = type;		
		if (event == kConstructor)
		{	
		//BAPI_Doc 	*docP;

			//if NOT(err = GetContructorDoc(api_data, classID, &docP))
			{	if (docP)
				{	if NOT(err = _AnalyzePrototype(api_data, docP, varRecsP, totVars, &newParamBl, &newTotParams))
						CEquStr(prototype, docP->prototype);
				}
			}
			if NOT(err)
			{	if (newParamBl)
				{	constrRecP->varRecsP = (ParameterRec*)GetPtr(newParamBl);
					constrRecP->totVars = newTotParams;
				}
				else
				{	constrRecP->varRecsP = varRecsP;
					constrRecP->totVars = totVars;
				}
			}
		}
		else
		{	constrRecP->varRecsP = varRecsP;
			constrRecP->totVars = totVars;
		}
		if NOT(err)
		{	pbPtr->api_data = api_data;
			constrRecP->typeCastType = (Byte)typeCastType;	
			constrRecP->privateData = (long)&constrData;			
			if (NOT(plugRecP) || plugRecP->successfull)
			{	if (event == kClone)
				{	
				ObjRecord	*objP = (ObjRecordP)&constrRecP->varRecsP->objRef;
				long		dataLen;
				Boolean		extends;
				
					constrRecP->cloneTarget = cloneTarget;
					if NOT(err = DLM_GetObj(objP->list, objP->id, nil, &dataLen, 0, nil))
					{	if (dataLen)
						{	if (plugRecP && NOT(WantCloneEvent(plugRecP, &extends)))
							{	if (extends)
									err = _CloneObjWithSuper(api_data, &varRecsP->objRef, constrRecP);
								else
									err = BAPI_CopyObj(api_data, &varRecsP->objRef, constrRecP->privateData, &constrRecP->resultObjRef);
							}
							else
								err = _CallEntryPoint(bRecP, plugRecP, kClone, pbPtr);
						}
						else
							err = BAPI_BufferToObj(api_data, "", 0, objP->classID, false, (long)&constrData, &constrRecP->resultObjRef);
					}
				}
				else
					err = _CallEntryPoint(bRecP, plugRecP, event, pbPtr);
				if NOT(err)
				{	if (resultObjRefP)
					{	ObjRecord *tObjP = (ObjRecordP)&constrRecP->resultObjRef;
						if (tObjP->id)
						{	*resultObjRefP = *tObjP;
							/*
							 modificato: 16/7/2003
							 in realt� d� problemi perch�, per esempio, il Clone di un ref
							 da come risultato quello che punta il ref (di classe p.e. int)
							 e non un ref (di classe classID), quindi si genererebbe un oggetto
							 con classID sbagliata (p.e. "int" con classID "ref")
							 credo che invece per Constructor e TypeCast sia ok
							*/
							if (event != kClone)
								resultObjRefP->classID = classID;
						}
						else
							err = XError(kBAPI_Error, Err_BAPI_MessageNotHandled);
					}
				}
			}
			else
			{	err = XError(kBAPI_Error, Err_NoSuchClass);
				NewMsgRecord(api_data, kCLASS_BAD, nil, classID, kInputIsClassName);
			}
		}
		if (newParamBl)
			DisposeBlock(&newParamBl);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
		/*if (err)
		{	int		protLen;
		
			if (protLen = CLen(prototype))
				NewMsgRecord(api_data, kCONSTRUCTOR, prototype, protLen, 0);
		}*/
	}

return err;
}

//===========================================================================================
XErr	CL_Constructor(long api_data, long scope, long type, char *resultObjName, long classID,
								ParameterRec *varRecsP, long totVars, BAPI_Doc *docP, ObjRecord *resultObjRefP)
{
XErr	err = noErr;

	if COMPILING(api_data)
	{
		MemberAction	membAction;
		
		membAction.objRef.id = 0;
		membAction.id = 0;
		membAction.slot = -1;
		membAction.doc = *docP;
		err = BIC_CallFunction(api_data, &membAction, nil, varRecsP, totVars, resultObjRefP, true);
	}
	else
		err = _Constructor(api_data, scope, type, resultObjName, classID, varRecsP, totVars, kNoTypeCast, resultObjRefP, kConstructor, false, docP);

return err;
}

//===========================================================================================
XErr	CL_Clone(long api_data, long scope, long type, char *resultObjName, long classID,
								ParameterRec *varRecsP, long totVars, long requestedElementClass, Boolean cloneTarget, ObjRecord *resultObjRefP)
{
XErr	err = noErr;
Boolean	isImmediate;

	if (classID != OBJ_CLASSID(varRecsP->objRef))
		err = XError(kBAPI_Error, Err_IllegalOperation);
	else
	{	if (isImmediate = IS_IMMEDIATE(varRecsP->objRef))
			err = CopyObjectExt(api_data, &varRecsP->objRef, resultObjName, scope, type, (ObjRefP)resultObjRefP);
		else
		{	if (DLM_IsArray(OBJ_LIST(varRecsP->objRef), OBJ_ID(varRecsP->objRef)))
			{	DLMRef	list;
				Boolean	fixedSize;
				
				if NOT(err = GetVariableList(api_data, scope, &list, false, 0))
				{	if (requestedElementClass)
						err = BAPI_FixedSize(api_data, requestedElementClass, &fixedSize);
					else
						fixedSize = false;
					if NOT(err)
					{
						if not(err = CloneArray(api_data, (ObjRecordP)&varRecsP->objRef, list, resultObjRefP, resultObjName, requestedElementClass, (Boolean)(type == CONSTANT), fixedSize))
							resultObjRefP->scope = scope;
					}
				}
			}
			else if (ContainsReference((ObjRecordP)&varRecsP->objRef))
				err = _Constructor(api_data, scope, type, resultObjName, classID, varRecsP, totVars, kNoTypeCast, resultObjRefP, kClone, cloneTarget, nil);
			else
				err = CopyObjectExt(api_data, &varRecsP->objRef, resultObjName, scope, type, (ObjRefP)resultObjRefP);
		}
	}
	
return err;
}

//===========================================================================================
XErr	CL_Destructor(long api_data, ObjRecord *varRecP)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;
Biferno_ParamBlock	*pbPtr;
long				objLen;
uint32_t			slot;
//BlockRef			block;

	if (err = AvoidCriticalDestruct(api_data, varRecP->classID, varRecP->scope))
		return err;

	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	
		bRecP = (BifernoRecP)api_data;
		ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRec(pbPtr, varRecP);
		if (NOT(plugRecP) || plugRecP->wantDestructor)
		{	if NOT(err = DLM_GetObj(varRecP->list, varRecP->id, nil, &objLen, 0, nil))
			{	if (objLen)
				{	pbPtr->api_data = api_data;
					pbPtr->param.destructorRec.objRef = OBJREF(*varRecP);
					err = _CallEntryPoint(bRecP, plugRecP, kDestructor, pbPtr);
				}
			}
		}
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
// request class "requestedClassID" to create a new obj from "source"
XErr	CL_TypeCast(long api_data, ObjRecordP source, long requestedClassID, ObjRecordP dest, long typeCastType)
{
XErr				err = noErr;
BifernoRec			*bRecP;

	if (requestedClassID == CLASSID_UNSPECIFIED)
		return BAPI_Clone(api_data, OBJREF_P(source), OBJREF_P(dest), true);
	
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
	if COMPILING(api_data)
		return BIC_TypeCast(api_data, source, requestedClassID, dest);
	
	if NOT(source->id)
	{	switch(requestedClassID)
		{
			case kBooleanClassID:
				return CL_BooleanToObj(api_data, false, dest);
			case kStringClassID:
				return CL_StringToObj(api_data, "", 0, CONSTANT, dest);
			case kDoubleClassID:
				return CL_DoubleToObj(api_data, 0, dest);
			case kLongClassID:
				return CL_LongToObj(api_data, 0, dest);
			case kUnsignedClassID:
				return CL_UnsignedToObj(api_data, 0, dest);
			case kIntClassID:
				return CL_IntToObj(api_data, 0, dest);
			case kCharClassID:
			default:
				return XError(kBAPI_Error, Err_IllegalTypeCast);
		}
	}
	if (source->classID)
	{
	//long	dataLen;

		//if NOT(err = DLM_GetObj(source->list, source->id, nil, &dataLen, 0, nil))
		{	ParameterRec	param;
				
			if (source->classID > 0)
			{	BAPI_ClearParameterRec(api_data, &param);
				param.objRef = OBJREF(*source);
				err = _Constructor(api_data, TEMP, source->type, nil, requestedClassID, &param, 1, typeCastType, dest, kTypeCast, false, nil);
				//if (err && (err != XError(kBAPI_Error, Err_ExplicitTypeCastRequired)))
				//	err = XError(kBAPI_Error, Err_IllegalTypeCast);
			}
			else
				err = BifernoTypeCastToObject(api_data, source, requestedClassID, typeCastType, dest);
		}
	}
	else
	{	err = XError(kBAPI_Error, Err_NoSuchClass);
		NewMsgRecord(api_data, kCLASS_BAD, nil, source->classID, kInputIsClassName);
	}

	if ((err == XError(kBAPI_Error, Err_IllegalTypeCast)) || (err == XError(kBAPI_Error, Err_IllegalOperation))/* || (err == XError(kBAPI_Error, Err_NullObject))*/)
		NewMsgRecord(api_data, kTYPECAST, (char*)source, requestedClassID, kInputIsObj/* + kOnlyIfEmpty*/);
	else if (err)
	{	if NOT(IS_IMMEDIATE_P(source))
		{	CStr63	name;
			if NOT(DLM_GetInfo(source->list, source->id, nil, nil, name))
			{	if (*name)
					NewMsgRecord(api_data, kVARIABLE, name, 0, 0);
			}
		}
	}
	
return err;
}

//===========================================================================================
XErr	CL_GetInt(long api_data, ObjRecordP varRecP, long *longP, long typeCastType)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;
//BlockRef			block;
//Boolean				isLiteral = (varRecP->scope == LITERAL_SPECIAL_SCOPE);

	/*if (isLiteral)
		*longP = *(long*)LIT_P(varRecP);
	else
	{*/
	if NOT(varRecP->id)
	{	*longP = 0L;
		return noErr;
	}
	else if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRec(pbPtr, varRecP);
		pbPtr->api_data = api_data;
		pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
		
		// What you give
		pbPtr->param.primitiveRec.typeCastType = typeCastType;
		pbPtr->param.primitiveRec.objRef = OBJREF(*varRecP);
		
		// What you want
		pbPtr->param.primitiveRec.resultWanted = kInt;
		
		if NOT(err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kPrimitive, pbPtr))
			*longP = pbPtr->param.primitiveRec.result.intValue;

		if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
			NewMsgRecord(api_data, kTYPECAST, (char*)varRecP, kIntClassID, kInputIsObj/* + kOnlyIfEmpty*/);
			//IllegalTypeCastToErrMessage(api_data, varRecP->classID, kIntClassID);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
	
return err;
}

//===========================================================================================
XErr	CL_GetLong(long api_data, ObjRecordP varRecP, LONGLONG *llongP, long typeCastType)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;
//BlockRef			block;
//Boolean				isLiteral = (varRecP->scope == LITERAL_SPECIAL_SCOPE);

	/*if (isLiteral)
		*llongP = *(long long*)LIT_P(varRecP);
	else
	{*/
	if NOT(varRecP->id)
	{	*llongP = 0L;
		return noErr;
	}
	else if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRec(pbPtr, varRecP);
		pbPtr->api_data = api_data;
		pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
		
		// What you give
		pbPtr->param.primitiveRec.typeCastType = typeCastType;
		pbPtr->param.primitiveRec.objRef = OBJREF(*varRecP);
		
		// What you want
		pbPtr->param.primitiveRec.resultWanted = kLong;
		
		if NOT(err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kPrimitive, pbPtr))
			*llongP = pbPtr->param.primitiveRec.result.longValue;

		if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
			NewMsgRecord(api_data, kTYPECAST, (char*)varRecP, kLongClassID, kInputIsObj/* + kOnlyIfEmpty*/);
			//IllegalTypeCastToErrMessage(api_data, varRecP->classID, kLongClassID);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
	//}

return err;
}

//===========================================================================================
XErr	CL_GetUnsigned(long api_data, ObjRecordP varRecP, unsigned long *ulongP, long typeCastType)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;
//BlockRef			block;

	if NOT(varRecP->id)
	{	*ulongP = 0L;
		return noErr;
	}
	else if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRec(pbPtr, varRecP);
		pbPtr->api_data = api_data;
		pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;

		// What you give
		pbPtr->param.primitiveRec.typeCastType = typeCastType;
		pbPtr->param.primitiveRec.objRef = OBJREF(*varRecP);
		
		// What you want
		pbPtr->param.primitiveRec.resultWanted = kUnsigned;
		
		if NOT(err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kPrimitive, pbPtr))
			*ulongP = pbPtr->param.primitiveRec.result.uIntValue;

		if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
			NewMsgRecord(api_data, kTYPECAST, (char*)varRecP, kUnsignedClassID, kInputIsObj/* + kOnlyIfEmpty*/);
			//IllegalTypeCastToErrMessage(api_data, varRecP->classID, kUnsignedClassID);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}

return err;
}

//===========================================================================================
XErr	CL_GetDouble(long api_data, ObjRecordP varRecP, double *doubleP, long typeCastType)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;
//BlockRef			block;
//Boolean				isLiteral = (varRecP->scope == LITERAL_SPECIAL_SCOPE);

	/*if (isLiteral)
		*doubleP = *(double*)LIT_P(varRecP);
	else
	{	*/
	if NOT(varRecP->id)
	{	*doubleP = 0L;
		return noErr;
	}
	else if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRec(pbPtr, varRecP);
		pbPtr->api_data = api_data;
		pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;

		// What you give
		pbPtr->param.primitiveRec.typeCastType = typeCastType;
		pbPtr->param.primitiveRec.objRef = OBJREF(*varRecP);
		
		// What you want
		pbPtr->param.primitiveRec.resultWanted = kDouble;

		if NOT(err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kPrimitive, pbPtr))
			*doubleP = pbPtr->param.primitiveRec.result.doubleValue;

		if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
			NewMsgRecord(api_data, kTYPECAST, (char*)varRecP, kDoubleClassID, kInputIsObj/* + kOnlyIfEmpty*/);
			//IllegalTypeCastToErrMessage(api_data, varRecP->classID, kDoubleClassID);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
	
return err;
}

//===========================================================================================
XErr	CL_GetBoolean(long api_data, ObjRecordP varRecP, Boolean *boolP, long typeCastType)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;
//BlockRef			block;
//Boolean				isLiteral = (varRecP->scope == LITERAL_SPECIAL_SCOPE);

	/*if (isLiteral)
		*boolP = *(Boolean*)LIT_P(varRecP);
	else
	{*/	
	if NOT(varRecP->id)
	{	*boolP = false;
		return noErr;
	}
	else if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRec(pbPtr, varRecP);
		pbPtr->api_data = api_data;
		pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;

		// What you give
		pbPtr->param.primitiveRec.typeCastType = typeCastType;
		pbPtr->param.primitiveRec.objRef = OBJREF(*varRecP);
		
		// What you want
		pbPtr->param.primitiveRec.resultWanted = kBool;

		if NOT(err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kPrimitive, pbPtr))
			*boolP = pbPtr->param.primitiveRec.result.boolValue;

		if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
			NewMsgRecord(api_data, kTYPECAST, (char*)varRecP, kBooleanClassID, kInputIsObj/* + kOnlyIfEmpty*/);
			//IllegalTypeCastToErrMessage(api_data, varRecP->classID, kBooleanClassID);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
	
return err;
}

//===========================================================================================
XErr	CL_GetString(long api_data, ObjRecordP varRecP, char *stringP, long *stringLenP, long maxStorage, long typeCastType, short variant)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Primitive_String	*tP;
//Boolean				isLiteral = (varRecP->scope == LITERAL_SPECIAL_SCOPE);

	/*if (isLiteral)
	{	Ptr			strP = LIT_P(varRecP) + 1;
		long		strLen = LIT_STRLEN_P(varRecP);
		BlockRef	ref;
		
		if (variant == kForConstructor)
			err = StringEscaped(&strP, &strLen, &ref);
		else
			ref = 0;
		if NOT(err)
		{	if (stringP)
			{	if (maxStorage >= (strLen + 1))	// 0 terminated
				{	CopyBlock(stringP, strP, strLen);
					stringP[strLen] = 0;
					if (stringLenP)
						*stringLenP = strLen;
				}
				else
				{	CopyBlock(stringP, strP, maxStorage);
					if (stringLenP)
						*stringLenP = maxStorage;
					err = XError(kBAPI_Error, Err_BAPI_BufferTooSmall);
				}
			}
			else if (stringLenP)
				*stringLenP = strLen + 1;
		}
		if (ref)
			DisposeBlock(&ref);
	}
	else
	{*/
	if NOT(varRecP->id)
	{	if (stringP)
			CEquStr(stringP, "");
		if (stringLenP)
			*stringLenP = 0;
		return noErr;
	}
	if (varRecP->classID)
	{	Biferno_ParamBlock	*pbPtr;
		uint32_t			slot;
		//BlockRef			block;
		
		if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
		{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
			plugRecP = _GetPluginRec(pbPtr, varRecP);
			pbPtr->api_data = api_data;

			// What you give
			pbPtr->param.primitiveRec.typeCastType = typeCastType;
			pbPtr->param.primitiveRec.objRef = OBJREF(*varRecP);
			
			// What you want
			pbPtr->param.primitiveRec.resultWanted = kCString;	
			
			// Info
			tP = &pbPtr->param.primitiveRec.result.text;
			tP->variant = variant;
			tP->stringP = stringP;
			tP->stringMaxStorage = maxStorage;
			
			err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kPrimitive, pbPtr);
			if (stringLenP)
				*stringLenP = pbPtr->param.primitiveRec.result.text.stringLen;
			PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
		}
	}
	else
		*stringLenP = 0;

	if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
		NewMsgRecord(api_data, kTYPECAST, (char*)varRecP, kStringClassID, kInputIsObj/* + kOnlyIfEmpty*/);
		//IllegalTypeCastToErrMessage(api_data, varRecP->classID, kStringClassID);
	//}
	
return err;
}

//===========================================================================================
XErr	CL_GetChar(long api_data, ObjRecordP varRecP, char *theChar, long typeCastType)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;

	bRecP = (BifernoRecP)api_data;
	if NOT(varRecP->id)
	{	if (theChar)
			*theChar = '\0';
		return noErr;
	}

	if (varRecP->classID)
	{	Biferno_ParamBlock	*pbPtr;
		uint32_t			slot;
		//BlockRef			block;
	
		if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
		{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
			plugRecP = _GetPluginRec(pbPtr, varRecP);
			pbPtr->api_data = api_data;

			// What you give
			pbPtr->param.primitiveRec.typeCastType = typeCastType;
			pbPtr->param.primitiveRec.objRef = OBJREF(*varRecP);
			
			// What you want
			pbPtr->param.primitiveRec.resultWanted = kChar;	
			
			err = _CallEntryPoint(bRecP, plugRecP, kPrimitive, pbPtr);
			if (theChar)
				*theChar = *pbPtr->param.primitiveRec.result.theChar;
			PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
		}
	}

	if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
		NewMsgRecord(api_data, kTYPECAST, (char*)varRecP, kCharClassID, kInputIsObj/* + kOnlyIfEmpty*/);
		//IllegalTypeCastToErrMessage(api_data, varRecP->classID, kCharClassID);

return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	CL_IntToObj(long api_data, long aLong, ObjRecordP varRecP/*, Boolean checkIfConst*/)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
ObjRecord	tObjRef;

	if VALID_P(varRecP)
	{	if (varRecP->classID == gsDispatcherData.refConstructor)
		{	INVAL(tObjRef);
			if NOT(err = CL_IntToObj(api_data, aLong, &tObjRef))
				err = gsRefModifyHook(api_data, (ObjRefP)varRecP, (ObjRefP)&tObjRef);
		}
		else 
		{	if (varRecP->classID != kIntClassID)
			{	INVAL(tObjRef);
				if NOT(err = CL_IntToObj(api_data, aLong, &tObjRef))
					err = CL_TypeCast(api_data, &tObjRef, varRecP->classID, varRecP, kImplicitTypeCast);
			}
			else
			{	if (IS_IMMEDIATE_P(varRecP))
					*(long*)IMM_P(varRecP) = aLong;
				else
					err = DLM_ModifyObj(varRecP->list, varRecP->id, (Ptr)&aLong, sizeof(long), DLM_USERDATA_DEFAULT, nil, 0, nil);
			}
		}
	}
	else
	{	if (((BifernoRecP)api_data)->noImmediate)
			err = BAPI_BufferToObj(api_data, &aLong, sizeof(long), kIntClassID, true, nil, OBJREF_P(varRecP));
		else
		{	varRecP->id = IMMEDIATE_ID;
			varRecP->classID = kIntClassID;
			*(long*)IMM_P(varRecP) = aLong;
		}
	}

return err;
}

//===========================================================================================
XErr	CL_LongToObj(long api_data, LONGLONG l, ObjRecordP varRecP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
ObjRecord	tObjRef;

	if VALID_P(varRecP)
	{	if (varRecP->classID == gsDispatcherData.refConstructor)
		{	INVAL(tObjRef);
			if NOT(err = CL_LongToObj(api_data, l, &tObjRef))
				err = gsRefModifyHook(api_data, (ObjRefP)varRecP, (ObjRefP)&tObjRef);
		}
		else
		{	if (varRecP->classID != kLongClassID)
			{	INVAL(tObjRef);
				if NOT(err = CL_LongToObj(api_data, l, &tObjRef))
					err = CL_TypeCast(api_data, &tObjRef, varRecP->classID, varRecP, kImplicitTypeCast);
			}
			else
			{	if (IS_IMMEDIATE_P(varRecP))
					*(LONGLONG*)IMM_P(varRecP) = l;
				else
					err = DLM_ModifyObj(varRecP->list, varRecP->id, (Ptr)&l, sizeof(LONGLONG), DLM_USERDATA_DEFAULT, nil, 0, nil);
			}
		}
	}
	else
	{	if (((BifernoRecP)api_data)->noImmediate)
			err = BAPI_BufferToObj(api_data, &l, sizeof(LONGLONG), kLongClassID, true, nil, OBJREF_P(varRecP));
		else
		{	varRecP->id = IMMEDIATE_ID;
			varRecP->classID = kLongClassID;
			*(LONGLONG*)IMM_P(varRecP) = l;
		}		
	}

return err;
}

//===========================================================================================
XErr	CL_UnsignedToObj(long api_data, unsigned long uLong, ObjRecordP varRecP)
{
XErr		err = noErr;
ObjRecord	tObjRef;

	if VALID_P(varRecP)
	{	if (varRecP->classID == gsDispatcherData.refConstructor)
		{	INVAL(tObjRef);
			if NOT(err = CL_UnsignedToObj(api_data, uLong, &tObjRef))
				err = gsRefModifyHook(api_data, (ObjRefP)varRecP, (ObjRefP)&tObjRef);
		}
		else
		{	if (varRecP->classID != kUnsignedClassID)
			{	INVAL(tObjRef);
				if NOT(err = CL_UnsignedToObj(api_data, uLong, &tObjRef))
					err = CL_TypeCast(api_data, &tObjRef, varRecP->classID, varRecP, kImplicitTypeCast);
			}
			else
			{	if (IS_IMMEDIATE_P(varRecP))
					*(unsigned long*)IMM_P(varRecP) = uLong;
				else
					err = DLM_ModifyObj(varRecP->list, varRecP->id, (Ptr)&uLong, sizeof(unsigned long), DLM_USERDATA_DEFAULT, nil, 0, nil);
			}
		}
	}
	else
	{	if (((BifernoRecP)api_data)->noImmediate)
			err = BAPI_BufferToObj(api_data, &uLong, sizeof(unsigned long), kUnsignedClassID, true, nil, OBJREF_P(varRecP));
		else
		{	varRecP->id = IMMEDIATE_ID;
			varRecP->classID = kUnsignedClassID;
			*(unsigned long*)IMM_P(varRecP) = uLong;
		}
	}

return err;
}

//===========================================================================================
XErr	CL_DoubleToObj(long api_data, double r, ObjRecordP varRecP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
ObjRecord	tObjRef;

	if VALID_P(varRecP)
	{	if (varRecP->classID == gsDispatcherData.refConstructor)
		{	INVAL(tObjRef);
			if NOT(err = CL_DoubleToObj(api_data, r, &tObjRef))
				err = gsRefModifyHook(api_data, (ObjRefP)varRecP, (ObjRefP)&tObjRef);
		}
		else
		{	if (varRecP->classID != kDoubleClassID)
			{	INVAL(tObjRef);
				if NOT(err = CL_DoubleToObj(api_data, r, &tObjRef))
					err = CL_TypeCast(api_data, &tObjRef, varRecP->classID, varRecP, kImplicitTypeCast);
			}
			else
			{	if (IS_IMMEDIATE_P(varRecP))
					*(double*)IMM_P(varRecP) = r;
				else
					err = DLM_ModifyObj(varRecP->list, varRecP->id, (Ptr)&r, sizeof(double), DLM_USERDATA_DEFAULT, nil, 0, nil);
			}
		}
	}
	else
	{	if (((BifernoRecP)api_data)->noImmediate)
			err = BAPI_BufferToObj(api_data, &r, sizeof(double), kDoubleClassID, true, nil, OBJREF_P(varRecP));
		else
		{	varRecP->id = IMMEDIATE_ID;
			varRecP->classID = kDoubleClassID;
			*(double*)IMM_P(varRecP) = r;
		}
	}

return err;
}

//===========================================================================================
XErr	CL_BooleanToObj(long api_data, Boolean boolVal, ObjRecordP varRecP)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr		err = noErr;
ObjRecord	tObjRef;

	if VALID_P(varRecP)
	{	if (varRecP->classID == gsDispatcherData.refConstructor)
		{	INVAL(tObjRef);
			if NOT(err = CL_BooleanToObj(api_data, boolVal, &tObjRef))
				err = gsRefModifyHook(api_data, (ObjRefP)varRecP, (ObjRefP)&tObjRef);
		}
		else
		{	if (varRecP->classID != kBooleanClassID)
			{	INVAL(tObjRef);
				if NOT(err = CL_BooleanToObj(api_data, boolVal, &tObjRef))
					err = CL_TypeCast(api_data, &tObjRef, varRecP->classID, varRecP, kImplicitTypeCast);
			}
			else
			{	if (IS_IMMEDIATE_P(varRecP))
					*(Boolean*)IMM_P(varRecP) = boolVal;
				else
					err = DLM_ModifyObj(varRecP->list, varRecP->id, (Ptr)&boolVal, sizeof(Boolean), DLM_USERDATA_DEFAULT, nil, 0, nil);
			}
		}
	}
	else
	{	if (((BifernoRecP)api_data)->noImmediate)
			err = BAPI_BufferToObj(api_data, &boolVal, sizeof(Boolean), kBooleanClassID, true, nil, OBJREF_P(varRecP));
		else
		{	varRecP->id = IMMEDIATE_ID;
			varRecP->classID = kBooleanClassID;
			*(Boolean*)IMM_P(varRecP) = boolVal;
		}
	}

return err;
}

//===========================================================================================
// type is: CONSTANT/VARIABLE
XErr	CL_StringToObj(long api_data, char *stringP, long stringLen, long type, ObjRecordP varRecP)
{
XErr		err = noErr;
ObjRecord	tObjRef;

	if (VALID_P(varRecP))
	{	if (IS_IMMEDIATE_P(varRecP))
			return XError(kBAPI_Error, Err_IllegalOperationOnConstant); 
		if (varRecP->classID == gsDispatcherData.refConstructor)
		{	INVAL(tObjRef);
			if NOT(err = CL_StringToObj(api_data, stringP, stringLen, CONSTANT, &tObjRef))
				err = gsRefModifyHook(api_data, (ObjRefP)varRecP, (ObjRefP)&tObjRef);
		}
		else
		{	if (varRecP->classID != kStringClassID)
			{	INVAL(tObjRef);
				if NOT(err = CL_StringToObj(api_data, stringP, stringLen, CONSTANT, &tObjRef))
					err = CL_TypeCast(api_data, &tObjRef, varRecP->classID, varRecP, kImplicitTypeCast);
			}
			else
				err = DLM_ModifyObj(varRecP->list, varRecP->id, stringP, stringLen, DLM_USERDATA_DEFAULT, nil, 0, nil);
		}
	}
	else
	{	if ((type == CONSTANT) && (stringLen <= (MAX_SPACE_FOR_IMMEDIATE - 1)) && NOT(((BifernoRecP)api_data)->noImmediate)) // create a pascal literal string
		{
		Byte	*byteP;

			varRecP->id = IMMEDIATE_ID;
			varRecP->classID = kStringClassID;
			byteP = (Byte*)&varRecP->type;
			*byteP = (Byte)stringLen;
			CopyBlock(byteP + 1, stringP, stringLen);
		}
		else
		{
		ConstructorAPIdataRec	constrData;

			constrData.type = type;
			constrData.scope = TEMP;
			*constrData.resultObjName = 0;
			err = BAPI_BufferToObj(api_data, stringP, stringLen, kStringClassID, false, (long)&constrData, OBJREF_P(varRecP));
		}
	}
	
return err;
}

//===========================================================================================
XErr	CL_CharToObj(long api_data, char theChar, ObjRecordP varRecP)
{
XErr			err = noErr;
ParameterRec	param;
ObjRecord		tObjRef;

	if (VALID_P(varRecP))
	{	if (IS_IMMEDIATE_P(varRecP))
			CDebugStr("Non doveva mai succedere");
		if (varRecP->classID == gsDispatcherData.refConstructor)
		{	INVAL(tObjRef);
			if NOT(err = CL_CharToObj(api_data, theChar, &tObjRef))
				err = gsRefModifyHook(api_data, (ObjRefP)varRecP, (ObjRefP)&tObjRef);
		}
		else
		{	if (varRecP->classID != kCharClassID)
			{	
			ObjRecord	tObjRef;
			
				INVAL(tObjRef);
				if NOT(err = CL_CharToObj(api_data, theChar, &tObjRef))
					err = CL_TypeCast(api_data, &tObjRef, varRecP->classID, varRecP, kImplicitTypeCast);
			}
			else
			{	BAPI_ClearParameterRec(api_data, &param);
				if NOT(err = BAPI_StringToObj(api_data, &theChar, 1, &param.objRef))
					err = BAPI_Constructor(api_data, kCharClassID, &param, 1, OBJREF_P(&varRecP));
			}
		}
	}
	else
	{	BAPI_ClearParameterRec(api_data, &param);
		if NOT(err = BAPI_StringToObj(api_data, &theChar, 1, &param.objRef))
			err = BAPI_Constructor(api_data, kCharClassID, &param, 1, OBJREF_P(varRecP));
	}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
XErr	CL_ExecuteOperation(long api_data, ObjRecordP item1, ObjRecordP item2, long operation, ObjRecordP resultVarRecP)
{
XErr				err = noErr;
PluginRecord		*plugRec1P, *plugRec2P;
ObjRecord			realItem1, realItem2;
long				priority1, priority2;

	if (NOT(item1->classID) || NOT(item2->classID))
		return XError(kBAPI_Error, Err_VariableNotInitialized);

	plugRec1P = _GetPluginRec(nil, item1);
	plugRec2P = _GetPluginRec(nil, item2);
	INVAL(realItem1);
	INVAL(realItem2);
	switch(operation)
	{
		case EVAL_LOGIC_AND:
			{	Boolean	res1, res2;
			
				if NOT(err = BAPI_ObjToBoolean(api_data, OBJREF_P(item1), &res1, kExplicitTypeCast))
				{	if NOT(err = BAPI_ObjToBoolean(api_data, OBJREF_P(item2), &res2, kExplicitTypeCast))
						err = BAPI_BooleanToObj(api_data, (Boolean)(res1 && res2), OBJREF_P(resultVarRecP));
				}
			}
			break;
	
		case EVAL_LOGIC_OR:
			{	Boolean	res1, res2;
			
				if NOT(err = BAPI_ObjToBoolean(api_data, OBJREF_P(item1), &res1, kExplicitTypeCast))
				{	if NOT(err = BAPI_ObjToBoolean(api_data, OBJREF_P(item2), &res2, kExplicitTypeCast))
						err = BAPI_BooleanToObj(api_data, (Boolean)(res1 || res2), OBJREF_P(resultVarRecP));
				}
			}
			break;
	
		default:
			_GetPriority(plugRec1P, plugRec2P, operation, &priority1, &priority2);
			// between non primitive?
			if ((item1->classID != item2->classID) && NOT(priority1) && NOT(priority2))
				return XError(kBAPI_Error, Err_ExplicitTypeCastRequired);

			if (item1->classID != item2->classID)
			{	if (priority1 > priority2)
				{	// request class 1 to create a new obj from item2
					if NOT(err = CL_TypeCast(api_data, item2, item1->classID, &realItem2, kImplicitTypeCast))
						err = _Plugin_op(plugRec1P, item1->classID, api_data, item1, &realItem2, operation, resultVarRecP);
					/*
					abbolito: si cercava di fare l'inverso se falliva il typecast dato dalle priority
					
					else if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
					{	// request class 2 to create a new obj from item1
						if NOT(err = CL_TypeCast(api_data, item1, item2->classID, &realItem1, kImplicitTypeCast))
							err = _Plugin_op(plugRec2P, item2->classID, api_data, &realItem1, item2, operation, resultVarRecP);
					}
					*/
				}
				else
				{	// request class 2 to create a new obj from item1
					if NOT(err = CL_TypeCast(api_data, item1, item2->classID, &realItem1, kImplicitTypeCast))
						err = _Plugin_op(plugRec2P, item2->classID, api_data, &realItem1, item2, operation, resultVarRecP);
					/*
					abbolito: si cercava di fare l'inverso se falliva il typecast dato dalle priority
					
					else if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
					{	// request class 1 to create a new obj from item2
						if NOT(err = CL_TypeCast(api_data, item2, item1->classID, &realItem2, kImplicitTypeCast))
							err = _Plugin_op(plugRec1P, item1->classID, api_data, item1, &realItem2, operation, resultVarRecP);
					}
					*/
				}
			}
			else
				err = _Plugin_op(plugRec1P, item1->classID, api_data, item1, item2, operation, resultVarRecP);
			break;
	}
	if (err)
	{	if (err == XError(kBAPI_Error, Err_IllegalTypeCast))
			NewMsgRecord(api_data, kTYPECAST, (char*)item2, item1->classID, kInputIsObj/* + kOnlyIfEmpty*/);
		else
		{
		char	*strP;
		
			if (strP = _GetOperationStringP(operation))
				NewMsgRecord(api_data, kEXECUTING_OP, strP, CLen(strP), 0/*kOnlyIfEmpty*/);
			else
				NewMsgRecord(api_data, kEXECUTING_OP, UNKNOWN, CLen(UNKNOWN), 0/*kOnlyIfEmpty*/);
		
			
		}
	}	
	
return err;
}

//===========================================================================================
XErr	CL_Increment(long api_data, ObjRecord *objRefP, Boolean toDecr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(api_data)
#endif
XErr				err = noErr;
Boolean				isImmediate = IS_IMMEDIATE_P(objRefP);
BAPI_IncrementHook	incremHook;

	if (isImmediate)
	{	switch(objRefP->classID)
		{
			case kBooleanClassID:
				err = XError(kBAPI_Error, Err_IllegalOperation);
				break;
			case kStringClassID:
				err = XError(kBAPI_Error, Err_IllegalOperation);
				break;
			case kDoubleClassID:
				if (toDecr)
					--(*(double*)IMM_P(objRefP));
				else
					++(*(double*)IMM_P(objRefP));
				break;
			case kLongClassID:
				if (toDecr)
					--(*(LONGLONG*)IMM_P(objRefP));
				else
					++(*(LONGLONG*)IMM_P(objRefP));
				break;
			case kUnsignedClassID:
				if (toDecr)
					--(*(unsigned long*)IMM_P(objRefP));
				else
					++(*(unsigned long*)IMM_P(objRefP));
				break;
			case kIntClassID:
				if (toDecr)
					--(*(long*)IMM_P(objRefP));
				else
					++(*(long*)IMM_P(objRefP));
				break;
			case kCharClassID:
				CDebugStr("impossible char immediate");
				break;
			default:
				err = XError(kBAPI_Error, Err_IllegalOperation);
				break;
		}
	}
	else
	{	if (objRefP->type == CONSTANT)
			return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
		switch(objRefP->classID)
		{
			case kBooleanClassID:
				err = XError(kBAPI_Error, Err_IllegalOperation);
				break;
			case kStringClassID:
				err = XError(kBAPI_Error, Err_IllegalOperation);
				break;
			case kDoubleClassID:
				err = DLM_IncrementDouble(objRefP->list, objRefP->id, toDecr);
				break;
			case kLongClassID:
				err = DLM_IncrementLongLong(objRefP->list, objRefP->id, toDecr);
				break;
			case kUnsignedClassID:
				err = DLM_IncrementUnsigned(objRefP->list, objRefP->id, toDecr);
				break;
			case kIntClassID:
				err = DLM_IncrementLong(objRefP->list, objRefP->id, toDecr);
				break;
			case kCharClassID:
				err = XError(kBAPI_Error, Err_IllegalOperation);
				break;
			default:
				if (incremHook = GetIncrementHook(objRefP->classID))
					err = incremHook(api_data, (ObjRefP)objRefP, toDecr);
				else
					err = XError(kBAPI_Error, Err_IllegalOperation);
				break;
		}
	}
	
return err;
}

//===========================================================================================
/*XErr	CL_Increment(long api_data, ObjRecord *objRefP, Boolean toDecr)
{
XErr				err;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;
Biferno_ParamBlock	*pbPtr;
long				slot;
IncrementRec		*incrP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRecFromClassID(pbPtr, objRefP->classID);
		pbPtr->api_data = api_data;
		incrP = &pbPtr->param.incrementRec;
		// In expressions like: "myString.length--" result of GetProperty is immediate and then decrement
		// so:
		if IS_IMMEDIATE_P(objRefP)
		{	if NOT(err = NewLiteralInList(nil, bRecP->volatileList, objRefP, 0L, &objRefP->id))
			{	objRefP->list = bRecP->volatileList;
				objRefP->scope = TEMP;
				objRefP->type = VARIABLE;
			}
		}
		if NOT(err)
		{	incrP->objRef = OBJREF(*objRefP);
			incrP->decrement = toDecr;
			if (err = _CallEntryPoint(bRecP, plugRecP, kIncrement, pbPtr))
			{	if (err == XError(kBAPI_Error, Err_BAPI_MessageNotHandled))
					err = XError(kBAPI_Error, Err_IllegalOperation);
			}
		}
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
	
return err;
}*/

//===========================================================================================
XErr	CL_Opposite(long api_data, ObjRecord *objRefP, ObjRecord *resultP)
{
XErr				err;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;
OppositeRec			*oppRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRecFromClassID(pbPtr, objRefP->classID);
		pbPtr->api_data = api_data;
		oppRecP = &pbPtr->param.oppositeRec;
		oppRecP->objRef = OBJREF(*objRefP);
		if (err = _CallEntryPoint(bRecP, plugRecP, kOpposite, pbPtr))
		{	if (err == XError(kBAPI_Error, Err_BAPI_MessageNotHandled))
				err = XError(kBAPI_Error, Err_IllegalOperation);
		}
		else if (resultP)
			*resultP = OBJRECORD(oppRecP->resultObjRef);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
	
return err;
}

//===========================================================================================
/*static void	_ExecMethodFailed(long api_data, char *prototype, long memberPluginID)
{	
CStr63	className;
CStr255	aCStr;
	
	// Class name
	CEquStr(aCStr, prototype);
	CAddStr(aCStr, " of class ");
	BAPI_NameFromClassID(api_data, memberPluginID, className);
	CAddStr(aCStr, className);
	NewMsgRecord(api_data, kMETHOD, aCStr, 0, kOnlyIfEmpty);
}*/

//===========================================================================================
XErr	CL_ExecuteMethod(long api_data, MemberAction *membActionP, ParameterRec *paramVarsP, 
														long totParams, ObjRecordP resultVarRecP, Boolean *sideEffectP)
{
XErr				err;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;
//long				numPar = 0;
BlockRef			newParamBl = 0;
long				newTotParams;
ExecuteMethodRec	*execRecP;
ObjRecordP 			varRecP = &membActionP->objRef;
Biferno_ParamBlock	*pbPtr;
long				classID;
uint32_t			slot;

	classID = 0;
	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	if COMPILING(api_data)
	{	
	//Boolean		notResolved = false;	// ... da vedere
	/*long	bicPluginID;
	
		if (membIdentP->notResolved)
			bicPluginID = 0;
		else
			bicPluginID = membIdentP->memberClassID;*/
		if (sideEffectP)
			*sideEffectP = true;
		
		return BIC_CallFunction(api_data, membActionP, nil, paramVarsP, totParams, resultVarRecP, false);
	}
	
	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		if (membActionP->doc.implem == kCImplementation)
			classID = membActionP->doc.ident.c.pluginID;						// the plugin that declared the property
		else
			classID = membActionP->doc.info.property.classID;				// the class id owning the property
		plugRecP = _GetPluginRecFromClassID(pbPtr, classID);
		pbPtr->api_data = api_data;
		execRecP = &pbPtr->param.executeMethodRec;
		if (membActionP->doc.implem == kCImplementation)
			execRecP->methodID = membActionP->doc.ident.c.val;			// the value of the property
		else
			execRecP->methodID = membActionP->id;		// the objID in instance list
		//execRecP->methodID = membIdentP->memberValue;
		execRecP->bapiDocP = &membActionP->doc;
		//execRecP->bapiDocLen = membActionP->doc.len;
		CEquStr(execRecP->methodName, membActionP->doc.name);
		//if (membIdentP->memberObjID)
		//	err = GetProtoBlock(api_data, membIdentP->memberClassID, membIdentP->memberObjID, (plugRecP == nil), &protoParamBlock, &protoParamP, &totParamsInProto, prototype, &dontCheckNumParams, &dontCheckNames, false, nil, nil, nil);
		//if NOT(err)
		{	//if (membIdentP->memberObjID)
			{	// err = _AnalyzePrototype(api_data, (plugRecP == nil), membIdentP->memberClassID, protoParamP, totParamsInProto, prototype, dontCheckNumParams, dontCheckNames, paramVarsP, totParams, &newParamBl, &newTotParams);
				err = _AnalyzePrototype(api_data, &membActionP->doc, paramVarsP, totParams, &newParamBl, &newTotParams);
			}
			if NOT(err)
			{	execRecP->objRef = OBJREF(*varRecP);
				if (newParamBl)
				{	execRecP->paramVarsP = (ParameterRec*)GetPtr(newParamBl);
					execRecP->totParams = newTotParams;
				}
				else
				{	execRecP->paramVarsP = paramVarsP;
					execRecP->totParams = totParams;
				}
				BAPI_InvalObjRef(api_data, &execRecP->resultObjRef);
				if (sideEffectP)
					*sideEffectP = false;
				if (NOT(plugRecP) || plugRecP->successfull)
				{	if NOT(err = _CallEntryPoint(bRecP, plugRecP, kExecuteMethod, pbPtr))
					{	//ObjRecord		resultObjRef;
						
						if (sideEffectP)
							*sideEffectP = execRecP->sideEffect;
						if (resultVarRecP)
							*resultVarRecP = OBJRECORD(execRecP->resultObjRef);
						//if (plugRecP)	// Only C Function
						//	err = _EvalForAddressParameters(api_data, execRecP, &membActionP->doc);
						/*
						tParamVarsP = paramVarsP;	
						for (i = 0; (i < totParams) && NOT(err); i++, tParamVarsP++)
						{	if (protoParamP[i].forAddress)
							{	
								err = EvalVariable(api_data, &tParamVarsP->expP, &tParamVarsP->expLen, &tParamVarsP->objRef, false, false, &numPar, &resultObjRef);
								if (err)
									TextToErrMessage(api_data, tParamVarsP->expP, tParamVarsP->expLen, true);
								else if (tParamVarsP->expLen)
								{	TextToErrMessage(api_data, tParamVarsP->expP, tParamVarsP->expLen, true);
									err = XError(kBAPI_Error, Err_BadSyntax);
								}
							}
							else if (tParamVarsP->expLen)
								err = XError(kBAPI_Error, Err_PrototypeMismatch);
						}
						*/
					}
				}
				else
				{	err = XError(kBAPI_Error, Err_NoSuchClass);
					NewMsgRecord(api_data, kCLASS_BAD, nil, classID, kInputIsClassName);
					//ClassNameToErrMessage(api_data, membIdentP->memberPluginID);
				}
				if (newParamBl)
					DisposeBlock(&newParamBl);
			}
			//if (protoParamBlock)
			//	DisposeBlock(&protoParamBlock);
		}
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
		// DisposeBlock(&pbPtrBlock);
		if (err)	// && *prototype)
		{	//if NOT(err = BAPI_NameFromClassID(api_data, membIdentP->memberPluginID, bRecP->errMsg))
			//NewMsgRecord(api_data, kCLASS, nil, membIdentP->memberPluginID, kUseClassName);
			//NewMsgRecord(api_data, kPROTOTYPE, prototype, 0, 0);
			
			//_ExecMethodFailed(api_data, membActionP->doc.prototype/*prototype*/, classID);
		}
		/*{	
		CStr63	className;
		CStr255	aCStr;
			
			// Class name
			CEquStr(aCStr, "Class: ");
			BAPI_NameFromClassID(api_data, membIdentP->memberPluginID, className);
			CAddStr(aCStr, className);
			CAddStringToErrMessage(api_data, aCStr);

			// Method prototype
			CAddStringToErrMessage(api_data, prototype);
		}*/
	}
	
return err;
}

//===========================================================================================
XErr	CL_ExecuteFunction(long api_data, MemberAction *membActionP, char *funcName, ParameterRec *paramVarsP, long totParams, ObjRecordP resultVarRecP)
{
XErr				err;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;
//long				numPar = 0;
BlockRef			newParamBl = 0;
long				newTotParams;
ExecuteMethodRec	*execRecP;
Biferno_ParamBlock	*pbPtr;
uint32_t			slot;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	if COMPILING(api_data)
	{	
		if (membActionP && membActionP->doc.implem == kCImplementation && membActionP->doc.ident.c.pluginID == 24 && membActionP->doc.ident.c.val == 1)
			err = BIC_Print(api_data, (ObjRecordP)&paramVarsP->objRef);
		else
			err = BIC_CallFunction(api_data, membActionP, funcName, paramVarsP, totParams, resultVarRecP, false);
		
		return err;
	}
	
	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	
		ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		if (membActionP->doc.implem == kBifernoImplementation)
		{	plugRecP = nil;
			pbPtr->plugin_global_dataP = (uint32_t*)membActionP->id;		//ex funcObjID;
		}
		else
		{	plugRecP = GET_PLUGINREC(membActionP->doc.ident.c.pluginID/*pluginID*/);
			pbPtr->plugin_global_dataP = &plugRecP->plugin_global_data;
		}
		pbPtr->api_data = api_data;
		execRecP = &pbPtr->param.executeMethodRec;
		execRecP->bapiDocP = &membActionP->doc;
		if (membActionP->doc.implem == kCImplementation)
			execRecP->methodID = membActionP->doc.ident.c.val;			// the value of the property
		else
			execRecP->methodID = membActionP->id;		// the objID in functions list
		CEquStr(execRecP->methodName, membActionP->doc.name/*functionName*/);
		if NOT(err = _AnalyzePrototype(api_data, &membActionP->doc, paramVarsP, totParams, &newParamBl, &newTotParams))
		{	if (newParamBl)
			{	execRecP->paramVarsP = (ParameterRec*)GetPtr(newParamBl);
				execRecP->totParams = newTotParams;
			}
			else
			{	execRecP->paramVarsP = paramVarsP;
				execRecP->totParams = totParams;
			}
			BAPI_InvalObjRef(api_data, &execRecP->resultObjRef);
			if NOT(err = _CallEntryPoint(bRecP, plugRecP, kExecuteFunction, pbPtr))
			{	if (resultVarRecP)
					*resultVarRecP = OBJRECORD(execRecP->resultObjRef);
				//if (plugRecP)	// Only C Function
				//	err = _EvalForAddressParameters(api_data, execRecP, &membActionP->doc/*protoParamP, totParamsInProto*/);
			}
			if (newParamBl)
				DisposeBlock(&newParamBl);
		}
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
		//if (err)
		//	NewMsgRecord(api_data, kFUNCTION, membActionP->doc.prototype/*prototype*/, 0, 0);
	}
	
return err;
}

//===========================================================================================
XErr	CL_GetProperty(long api_data, MemberAction *membActionP, long propertyDim, ArrayIndexRec *propertyIndex, ObjRecordP resultVarRecP)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;
ObjRecordP 			varRecP = &membActionP->objRef;
GetPropertyRec		*getPropertyRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);

	INVAL_P(resultVarRecP);
	if (membActionP->doc.isBuiltIn)
	{	if (propertyIndex && propertyIndex[0].ind)
			return XError(kXHelperError, DLM_Err_ObjectIsNotArray);
		//switch(membIdentP->memberValue)
		switch(membActionP->doc.ident.c.val)
		{	case TYPE:
				err = _TypeToObj(api_data, varRecP, resultVarRecP);
				break;
			case SCOPE:
				err = _ScopeToObj(api_data, varRecP, resultVarRecP);
				break;
			case CLASS:
				err = _ClassToObj(api_data, varRecP, resultVarRecP);
				break;
			default:
				err = XError(kBAPI_Error, Err_NoSuchProperty);
				break;
		}
	}
	else
	{	
	Biferno_ParamBlock	*pbPtr;
	uint32_t			slot;
	long				classID;
	//BlockRef			block;

		// if (membIdentP->memberIsError && (membIdentP->memberPluginID > 0))
		if ((membActionP->doc.type == kError) && (membActionP->doc.implem == kCImplementation))
			err = BAPI_IntToObj(api_data, membActionP->doc.ident.c.val, OBJREF_P(resultVarRecP));
		else
		{	/*if (bRecP->inCase && (NOT(membIdentP->memberIsStatic) || NOT(membIdentP->memberIsConstant)))
				err = XError(kBAPI_Error, Err_IllegalConstantExpression);
			else */
			if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
			{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
				if (membActionP->doc.implem == kCImplementation)
					classID = membActionP->doc.ident.c.pluginID;						// the plugin that declared the property
				else
					classID = membActionP->doc.info.property.classID;				// the class id owning the property
				plugRecP = _GetPluginRecFromClassID(pbPtr, classID);
				pbPtr->api_data = api_data;
				getPropertyRecP = &pbPtr->param.getPropertyRec;
				getPropertyRecP->objRef = OBJREF(*varRecP);
				if (membActionP->doc.implem == kCImplementation)
					getPropertyRecP->propertyID = membActionP->doc.ident.c.val;			// the value of the property
				else
					getPropertyRecP->propertyID = membActionP->id;	// the objID in instance list
				getPropertyRecP->bapiDocP = &membActionP->doc;
				//getPropertyRecP->bapiDocLen = membActionP->doc.len;
				CEquStr(getPropertyRecP->propertyName, membActionP->doc.name);
				getPropertyRecP->propertyIndex = propertyIndex;
				getPropertyRecP->propertyDim = propertyDim;
				//BAPI_InvalObjRef(api_data, &getPropertyRecP->resultObjRef);
				getPropertyRecP->resultObjRef = OBJREF(*resultVarRecP);
				//if (membIdentP->memberIsConstant)
				if (membActionP->doc.info.property.isConst)
					getPropertyRecP->isConstant = true;
				if NOT(err = _CallEntryPoint(bRecP, plugRecP, kGetProperty, pbPtr))
				{	*resultVarRecP = OBJRECORD(getPropertyRecP->resultObjRef);
					//if (membIdentP->memberIsConstant)
					if (membActionP->doc.info.property.isConst)
					{	if NOT(IS_IMMEDIATE_P(resultVarRecP))
							resultVarRecP->type = CONSTANT;
					}
				}
				PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
			}
		}
	}
	
return err;
}

//===========================================================================================
// Cambiare valore di un Obj nella lista statica
XErr	CL_SetProperty(long api_data, MemberAction *membActionP, long propertyDim, ArrayIndexRec *propertyIDX, ObjRecordP value)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
BifernoRec			*bRecP;
ObjRecordP 			varToSet = &membActionP->objRef;
Biferno_ParamBlock	*pbPtr;
long				classID;
uint32_t			slot;
//BlockRef			block;
SetPropertyRec		*setPropertyRecP;

	if NOT(bRecP = (BifernoRecP)api_data)
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
	if (err = CheckSetProperty(membActionP))
		return err;
	
	// Check if it is a constant property
	/*if (membIdentP->memberIsConstant)
		return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
	
	if (membIdentP->memberPluginID == BUILTIN_PROPERTY_MAGIC_NUMBER)
		return XError(kBAPI_Error, Err_PropertyIsOnlyRead);

	if (varToSet->type == CONSTANT)
		return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
		
	if (membIdentP->memberIsError)
		return XError(kBAPI_Error, Err_IllegalOperationOnConstant);
	*/
	
	//if COMPILING(api_data)
	//	return BIC_SetProperty(api_data, membIdentP, propertyIDX, propertyDim, value);

	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		if (membActionP->doc.implem == kCImplementation)
			classID = membActionP->doc.ident.c.pluginID;						// the plugin that declared the property
		else
			classID = membActionP->doc.info.property.classID;				// the class id owning the property
		plugRecP = _GetPluginRecFromClassID(pbPtr, classID);
		pbPtr->api_data = api_data;
		setPropertyRecP = &pbPtr->param.setPropertyRec;
		setPropertyRecP->objRef = OBJREF(*varToSet);
		if (membActionP->doc.implem == kCImplementation)
			setPropertyRecP->propertyID = membActionP->doc.ident.c.val;			// the value of the property
		else
			setPropertyRecP->propertyID = membActionP->id;	// the id in instance list
		//ex setPropertyRecP->propertyID = membIdentP->memberValue;
		CEquStr(setPropertyRecP->propertyName, membActionP->doc.name);
		setPropertyRecP->propertyIndex = propertyIDX;
		setPropertyRecP->propertyDim = propertyDim;
		setPropertyRecP->value = OBJREF(*value);
		setPropertyRecP->bapiDocP = &membActionP->doc;
		//setPropertyRecP->bapiDocLen = membActionP->doc.len;
		err = _CallEntryPoint(bRecP, plugRecP, kSetProperty, pbPtr);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);	
	}

return err;
}

//===========================================================================================
XErr	CL_Accessor(long api_data, long classID, long message, Biferno_ParamBlockPtr paramBlockPtr)
{
PluginRecord*	plugRecP;
XErr			err = noErr;
Boolean			executed = false;

	if (classID)
	{	
		switch(message)
		{
			case kRegister:
				break;
			case kInit:
				break;
			case kShutDown:
				break;
			case kRun:
				break;
			case kExit:
				break;
			case kConstructor:
			case kTypeCast:
				break;
			case kClone:
				break;
			case kDestructor:
				break;
			case kExecuteOperation:
				break;
			case kExecuteMethod:
				{
				ExecuteMethodRec	*execP = &paramBlockPtr->param.executeMethodRec;
	
					err = BAPI_ExecuteMethod(api_data, &execP->objRef, execP->paramVarsP, execP->totParams, execP->methodName, &execP->resultObjRef, nil);
					executed = true;
				}
				break;
			case kExecuteFunction:
				{
				ExecuteMethodRec	*execP = &paramBlockPtr->param.executeMethodRec;
	
					err = BAPI_ExecuteFunction(api_data, execP->paramVarsP, execP->totParams, execP->methodName, &execP->resultObjRef);
					executed = true;
				}
				break;
			case kGetProperty:
				{
				GetPropertyRec		*getPropP = &paramBlockPtr->param.getPropertyRec;

					err = BAPI_GetProperty(api_data, &getPropP->objRef, getPropP->propertyName, getPropP->propertyID, getPropP->propertyIndex, &getPropP->resultObjRef);
					executed = true;
				}
				break;
			case kSetProperty:
				{
				SetPropertyRec		*setPropP = &paramBlockPtr->param.setPropertyRec;

					err = BAPI_SetProperty(api_data, &setPropP->objRef, setPropP->propertyName, setPropP->propertyID, setPropP->propertyIndex, &setPropP->value);
					executed = true;
				}
				break;
			case kPrimitive:
				break;
			case kGetErrMessage:
				break;
			default:
				break;		
		}
		if NOT(executed)
		{	paramBlockPtr->api_data = api_data;
			plugRecP = _GetPluginRecFromClassID(paramBlockPtr, classID);
			err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, message, paramBlockPtr);
		}
	}
	else
		err = XError(kBAPI_Error, Err_NoSuchClass);
	
return err;
}

//===========================================================================================
XErr	CL_GetErrMessage(long api_data, long classID, long theError, char *errName, char *errMessage, char *errType)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Biferno_ParamBlock	*pbPtr;
long				errValue;
uint32_t			slot;
//BlockRef			block;
//CStr63				tempStr;
int					lastErr, firstErr;

	if (classID)
	{	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
		{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
			plugRecP = _GetPluginRecFromClassID(pbPtr, classID);
			pbPtr->api_data = api_data;
			XErrorGetTypeValue(theError, &errValue, nil);
			pbPtr->param.getErrMessageRec.err = errValue;
			err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kGetErrMessage, pbPtr);
			if (err)	// == XError(kBAPI_Error, Err_BAPI_MessageNotHandled))
			{	if (errMessage)
					CEquStr(errMessage, "");
				err = noErr;
			}
			else// if NOT(err)
			{	if (errMessage)
					CEquStr(errMessage, pbPtr->param.getErrMessageRec.errMessage);
			}
			if NOT(err)
			{	if (errName)
				{	if (plugRecP)
					{	firstErr = plugRecP->baseError;
						lastErr = plugRecP->baseError + plugRecP->totErrors;
						if (plugRecP->membersList && (errValue >= firstErr) && (errValue <= lastErr))
							err = DLM_GetInfo(plugRecP->membersList, plugRecP->objBaseError+errValue-plugRecP->baseError+1, nil, nil, errName);
						else
							*errName = 0;
					}
					else
						err = BifernoGetErrorName(api_data, classID, errValue, errName);
				}
				if (errType)
				{	if NOT(classID)
						classID = gsDispatcherData.errConstructor;
					//CEquStr(errType, "ERROR OF CLASS \"");
					if NOT(err = BAPI_NameFromClassID(api_data, classID, errType))
					{	//CAddStr(errType, tempStr);
						//CAddStr(errType, "\"");
					}
				}
			}
			PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
		}
		if (err)
		{	if (errName)
				*errName = 0;
			if (errMessage)
				*errMessage = 0;
			if (errType)
				*errType = 0;		
		}
	}
	else
	{	if (errName)
			CEquStr(errName, "Unknown Error");
		if (errMessage)
			*errMessage = 0;
		if (errType)
			CEquStr(errType, "Unknown");
	}
	
return err;
}

//===========================================================================================
/*XErr	CL_GetErrNumber(long api_data, long classID, char *errName, long *theErrorP)
{
XErr				err = noErr;
PluginRecord*		plugRecP;
Biferno_ParamBlock	*pbPtr;
long				slot;
BlockRef			block;

	if (classID)
	{	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot, &block))
		{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
			plugRecP = _GetPluginRecFromClassID(pbPtr, classID);
			pbPtr->api_data = api_data;
			CEquStr(pbPtr->param.getErrNumber.errName, errName);
			err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kGetErrNumber, pbPtr);
			if (err == XError(kBAPI_Error, Err_BAPI_MessageNotHandled))
				*theErrorP = 0;
			else if NOT(err)
				*theErrorP = pbPtr->param.getErrNumber.errNumber;
			PoolDisposePtr(gsDispatcherData.paramBlockPool, slot, block);
		}
	}
	
return err;
}*/

//===========================================================================================
/*
XErr	CL_GetSuperObj(long api_data, ObjRecord *objRef, ObjRecord *superObjRef)
{
Biferno_ParamBlock	*pbPtr;
XErr				err = noErr;
PluginRecord*		plugRecP;
long				slot;
BlockRef			block;

	if (objRef->id)
	{	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot, &block))
		{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
			plugRecP = _GetPluginRec(pbPtr, objRef);
			pbPtr->api_data = api_data;
			pbPtr->param.getSuperObjRec.objRef = *objRef;
			superObjRef->id = 0;
			if (NOT(plugRecP) || plugRecP->extendedPluginID)
			{	if NOT(err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kGetSuperObj, pbPtr))
					*superObjRef = pbPtr->param.getSuperObjRec.superObjRef;
			}
			if (err == XError(kBAPI_Error, Err_BAPI_MessageNotHandled) || NOT(superObjRef->id))
				err = XError(kBAPI_Error, Err_UnknownSuperObj);
			PoolDisposePtr(gsDispatcherData.paramBlockPool, slot, block);
		}
	}
	else
		BAPI_InvalObjRef(api_data, superObjRef);
	
return err;
}
*/

//===========================================================================================
XErr	CL_SuperIsChanged(long api_data, ObjRecord *objRef, char *propertyName)
{
Biferno_ParamBlock	*pbPtr;
XErr				err = noErr;
PluginRecord*		plugRecP;
uint32_t			slot;
//BlockRef			block;

	if NOT(err = PoolNewPtr(gsDispatcherData.paramBlockPool, (Ptr*)&pbPtr, &slot))
	{	ClearBlock(pbPtr, sizeof(Biferno_ParamBlock));
		plugRecP = _GetPluginRec(pbPtr, objRef);
		pbPtr->api_data = api_data;
		pbPtr->param.superIsChangedRec.objRef = OBJREF(*objRef);
		if (propertyName)
			CEquStr(pbPtr->param.superIsChangedRec.propertyName, propertyName);
		if (NOT(plugRecP) || plugRecP->extendedPluginID)
			err = _CallEntryPoint((BifernoRecP)api_data, plugRecP, kSuperIsChanged, pbPtr);
		PoolDisposePtr(gsDispatcherData.paramBlockPool, slot);
	}
	
return err;
}

