/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Load.c,v 1.30 2008-12-02 11:04:47 tabasoft Exp $
	|______________________________________________________________________________
*/
#include 	"XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Load.h"
#include "Param.h"
#include "BifernoErrors.h"
#include "Entity.h"
#include "BfrParser.h"

#include "Classes.h"

extern 	DispatcherData	gsDispatcherData;
extern	PluginRecord	*gClassRecordBlockP;



#ifdef __LITTLE_ENDIAN__
	#define	TO_PRESTRING		'ot'
	//#define	STAT_KEY			'tats'
	//#define	STAT_KEY2			'ci'
#else
	#define	TO_PRESTRING		'to'
	//#define	STAT_KEY			'stat'
	//#define	STAT_KEY2			'ic'
#endif

//===========================================================================================
// Note: totParams incremented before calling this: (CheckProtoInfoBlock(... ++totParams))
static XErr	_CheckProtoInfoBlock(BlockRef memberDocBlock, BAPI_Doc **docP, long totParams)
{
XErr		err = noErr;
long		newSize;

	newSize = sizeof(BAPI_Doc) + (sizeof(BAPI_ParameterDoc) * (totParams - 1));
	if NOT(err = SetBlockSize(memberDocBlock, newSize))
	{	*docP = (BAPI_Doc*)GetPtr(memberDocBlock);
		ClearBlock((Ptr)(*docP) + newSize - sizeof(BAPI_ParameterDoc), sizeof(BAPI_ParameterDoc));
	}

return err;
}

//===========================================================================================
static XErr	_CheckIfDuplicatedParamName(BAPI_ParameterDoc *firstProtoParamP, long totParams, char *newParamName)
{
int		i;
XErr	err = noErr;
	
	--totParams;	// not last
	for (i = 0; i < totParams; i++, firstProtoParamP++)
	{	if NOT(CCompareStrings_cs(firstProtoParamP->name, newParamName))
		{	err = XError(kBAPI_Error, Err_DuplicatedParameter);
			break;
		}
	}

return err;
}

//===========================================================================================
static XErr	_ArrayLevel(Ptr *oldFilePPtr, long *lenP, long *arraylevelP)
{
Ptr		tempP;
long	len, arraylevel;
XErr	err = noErr;

	// arrayLevel
	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTab(&tempP, &len);
	arraylevel = 0;
	while (len >= 2)
	{	if (*(short*)tempP == ONE_ARRY_LEVEL)
		{	len -= 2;
			tempP += 2;
			arraylevel++;
			if (arraylevel > MAX_PROTO_ARRAY_LEVEL)
			{	err = XError(kBAPI_Error, Err_BadPrototype);
				break;
			}
		}
		else
			break;
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
	*arraylevelP = arraylevel;
}
return err;
}

//===========================================================================================
static XErr	_TokenizePrototype(long api_data, Ptr *tempPPtr, long *lenP, BlockRef memberDocBlock, char *curLoadingClassName, Boolean noLocal)
{
XErr				err = noErr;
//ProtoParam	*firstProtoParamP = nil;
long				len, tLen, totParams = 0;
//ProtoParam	*protoParamP;
Ptr					saveP, tempP;
int					i;
long				arrayElementClassID, arraylevel, paramClassID, *lineP;
CStr255				aCStr;
BifernoRecP			bRecP = (BifernoRecP)api_data;
BAPI_Doc 			*memberDocP;
BAPI_ParameterDoc	*actParamP;

	tempP = *tempPPtr;
	len = *lenP;
	
	memberDocP = (BAPI_Doc*)GetPtr(memberDocBlock);
	//*protoParamBlockP = 0L;
	memberDocP->info.method.varArgs = false;
	if (api_data)
		lineP = &bRecP->currentCtx.currentLine;
	else
		lineP = nil;
	for (i = 0; len && NOT(err); i++)
	{	SkipSpaceAndTabCRLF(&tempP, &len, lineP);
		if (len && (*tempP == ')'))
		{	tempP++;
			len--;
			break;
		}
		else if ((len > 2) && (*tempP == '.') && (*(short*)(tempP+1) == '..'))
		{	memberDocP->info.method.varArgs = true;
			tempP += 3;
			len -= 3;
			SkipSpaceAndTabCRLF(&tempP, &len, lineP);
			if (len && (*tempP == ')'))
			{	tempP++;
				len--;
			}
			else
				err = XError(kBAPI_Error, Err_BadPrototype);
			break;
		}
		else if NOT(err = GetEntityName(api_data, &tempP, &len, aCStr, false))
		{	if NOT(CCompareStrings_cs(aCStr, "void"))
			{	SkipSpaceAndTabCRLF(&tempP, &len, lineP);
				if (len && (*tempP == ')'))
				{	tempP++;
					len--;
					break;
				}
				else
					err = XError(kBAPI_Error, Err_BadSyntax);
			}
			else
			{	if NOT(CCompareStrings_cs(aCStr, "obj"))
					paramClassID = CLASSID_UNSPECIFIED;
				else if (bRecP && curLoadingClassName && *curLoadingClassName && NOT(CCompareStrings_cs(aCStr, curLoadingClassName)))
					paramClassID = CUR_LOADING_CLASS_MAGIC_NUMBER;
				else if NOT(paramClassID = BAPI_ClassIDFromName(api_data, aCStr, false))
				{	err = XError(kBAPI_Error, Err_NoSuchClass);
					if (bRecP)
						NewMsgRecord(api_data, kCLASS_BAD, aCStr, 0, 0);
				}
				if NOT(err)
				{	if (noLocal && IS_LOCAL(paramClassID))
						err = XError(kBAPI_Error, Err_ScopeConflict);
				}
			}
			if NOT(err)
			{	//ex if NOT(err = CheckProtoInfoBlock(protoParamBlockP, &protoParamP, &firstProtoParamP, ++totParams))
				if NOT(err = _CheckProtoInfoBlock(memberDocBlock, &memberDocP, ++totParams))
				{	actParamP = &memberDocP->params[totParams-1];
					SkipSpaceAndTab(&tempP, &len);
					if NOT(err = _ArrayLevel(&tempP, &len, &arraylevel))
					{	SkipSpaceAndTabCRLF(&tempP, &len, lineP);
						if (len && (*tempP == '*'))
						{	actParamP->targetClassID = paramClassID;
							paramClassID = gsDispatcherData.refConstructor;
							tempP++;
							len--;
							SkipSpaceAndTabCRLF(&tempP, &len, lineP);
						}
						else
							actParamP->targetClassID = 0;
					}
					if NOT(err)
					{	if (paramClassID)
						{	IsCommentExt(bRecP, &tempP, &len, nil, nil, true);
							if NOT(err = GetEntityName((long)bRecP, &tempP, &len, actParamP->name, false))
							{	if NOT(err = _CheckIfDuplicatedParamName(&memberDocP->params[0], totParams, actParamP->name))
								{	if NOT(arraylevel)
										err = _ArrayLevel(&tempP, &len, &arraylevel);
									if NOT(err)
									{	if (arraylevel)
										{	if (actParamP->targetClassID)
											{	arrayElementClassID = actParamP->targetClassID;
												actParamP->targetClassID = gsDispatcherData.arrayConstructor;
												paramClassID = gsDispatcherData.refConstructor;
											}
											else
											{	arrayElementClassID = paramClassID;
												paramClassID = gsDispatcherData.arrayConstructor;
											}
										}
										else
											arrayElementClassID = 0;
										SkipSpaceAndTab(&tempP, &len);
										if ((paramClassID == gsDispatcherData.arrayConstructor) && NOT(arrayElementClassID) && (NOT(len) || (*tempP != '(')))
											arraylevel = MAX_ARRAY_LEVEL;
										actParamP->classID = paramClassID;
										actParamP->aeLevel = (short)arraylevel;
										actParamP->aeClassID = arrayElementClassID;
										SkipSpaceAndTabCRLF(&tempP, &len, lineP);
										IsCommentExt(bRecP, &tempP, &len, nil, nil, true);
										if (len && (*tempP == '='))
										{	Byte	lastChar;
										
											tempP++;
											len--;
											SkipSpaceAndTabCRLF(&tempP, &len, lineP);
											saveP = tempP;
											// if remove "kStopOnPeriod" also search.or can be accepted
											// (but SkipOneParameter must stop on "...")
											SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, kStopOnComma/* + kStopOnPeriod*/, false, false);
											if ((tLen = tempP - saveP - 1) < 63)
											{	CopyBlock(actParamP->defaultStr, saveP, tLen);
												actParamP->defaultStr[tLen] = 0;
												if (lastChar == ')')
													break;
												else if (lastChar == '.')
												{	tempP--;
													len++;
												}
											}
											else
												err = XError(kBAPI_Error, Err_TooLongDefault);
										}
										else if ((len > 2) && (*tempP == '.') && (*(short*)tempP == '..'))
										{	memberDocP->info.method.varArgs = true;
											tempP += 3;
											len -= 3;
											SkipSpaceAndTabCRLF(&tempP, &len, lineP);
											if (len && (*tempP == ')'))
											{	tempP++;
												len--;
											}
											else
												err = XError(kBAPI_Error, Err_BadPrototype);
											break;
										}
										else if (len && (*tempP == ')'))
										{	tempP++;
											len--;
											break;
										}
										else
										{	SkipUntilChar(&tempP, &len, ',', nil);
											if (len)
											{	tempP++;
												len--;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	if (err)
	{	//if (*protoParamBlockP)
		//	DisposeBlock(protoParamBlockP);
	}
	else
	{	//*totParamsP = totParams;
		*tempPPtr = tempP;
		*lenP = len;
		memberDocP->totParams = totParams;
	}
	
return err;
}

//===========================================================================================
static XErr	_TokParams(long api_data, Ptr *prototypeP, long *lenP, BlockRef memberDocBlock, BAPI_Doc *membRecP, long *lineP, LoadClassRecord *loadClassRecordP, Boolean isLocal)
{
Ptr				tempP;
long			len;
XErr			err = noErr;
char			*strP;

	len = *lenP;
	tempP = *prototypeP;

	if (len && (*tempP == '('))
	{	tempP++;
		len--;
		SkipSpaceAndTabCRLF(&tempP, &len, lineP);
		if ((len > 6) && NOT(CompareBlock(tempP, "nonames", 7)))
		{	membRecP->info.method.noNames = true;
			tempP += 7;
			len -= 7;
		}
		else
			membRecP->info.method.noNames = false;
		if (loadClassRecordP)
			strP = loadClassRecordP->curLoadingClassName;
		else
			strP = nil;
		if NOT(err = _TokenizePrototype(api_data, &tempP, &len, memberDocBlock, strP, isLocal))
		{	membRecP = (BAPI_Doc*)GetPtr(memberDocBlock);	// reload it
			if ((membRecP->returnClassID == gsDispatcherData.arrayConstructor) && NOT(membRecP->returnAeClass))
				membRecP->returnAeLevel = MAX_ARRAY_LEVEL;
		}
	}
	else
		err = XError(kBAPI_Error, Err_BadPrototype);

if NOT(err)
{	*lenP = len;
	*prototypeP = tempP;
}
return err;
}

//===========================================================================================
XErr	PrototypeToBAPI_Doc(long api_data, Ptr *prototypeP, long *lenP, BlockRef memberDocBlock, LoadClassRecord *loadClassRecordP, Boolean isLocal, long type)
{
Ptr				tempP;
long			len;
XErr			err = noErr;
CStr255			returnClass;
BAPI_Doc 		*membRecP;
long			*lineP;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			checkReturnAeLevel;

	len = *lenP;
	tempP = *prototypeP;
	
	membRecP = (BAPI_Doc*)GetPtr(memberDocBlock);
	checkReturnAeLevel = true;
	
	if (api_data)
		lineP = &bRecP->currentCtx.currentLine;
	else
		lineP = nil;

	if (type != kFunction)
	{	SkipSpaceAndTabCRLF(&tempP, &len, lineP);
		if ((len > 5) && NOT(CompareBlock(tempP, "static", 6)))
		{	tempP += 6;
			len -= 6;
			membRecP->isStatic = true;
		}
		else
		{	if ((type == kConstant) || (type == kError))
			{	membRecP->info.property.isConst = true;
				membRecP->isStatic = true;
			}
			else
				membRecP->isStatic = false;
		}
	}
	
	SkipSpaceAndTabCRLF(&tempP, &len, lineP);
	if NOT(err = GetEntityName(0L, &tempP, &len, returnClass, false))
	{	if NOT(CCompareStrings_cs(returnClass, "void"))
			membRecP->returnClassID = 0;
		else if NOT(CCompareStrings_cs(returnClass, "obj"))
			membRecP->returnClassID = CLASSID_UNSPECIFIED;
		else if NOT(membRecP->returnClassID = BAPI_ClassIDFromName(0L, returnClass, false))
		{	membRecP->returnClassID = 0;	// void
			CEquStr(membRecP->name, returnClass);
			checkReturnAeLevel = false;
		}
		if (membRecP->returnClassID == gsDispatcherData.refConstructor)
			err = XError(kBAPI_Error, Err_IllegalRef);
	}
	if NOT(err)	
	{	SkipSpaceAndTab(&tempP, &len);
		if (membRecP->returnAeLevel)	// already set from caller
		{	membRecP->returnAeClass = membRecP->returnClassID;
			membRecP->returnClassID = gsDispatcherData.arrayConstructor;
		}
		else
		{	if (checkReturnAeLevel)
			{	if NOT(err = _ArrayLevel(&tempP, &len, &membRecP->returnAeLevel))
				{	if (membRecP->returnAeLevel)
					{	membRecP->returnAeClass = membRecP->returnClassID;
						membRecP->returnClassID = gsDispatcherData.arrayConstructor;
					}
					else
						membRecP->returnAeClass = 0;
				}
			}
			else
				membRecP->returnAeClass = membRecP->returnAeLevel = 0;
		}
		SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
		if NOT(err)
		{	if ((type == kMethod) || (type == kFunction))
			{	if (len)
				{	if NOT(err = GetEntityName(api_data, &tempP, &len, membRecP->name, false))
						SkipSpaceAndTabCRLF(&tempP, &len, lineP);
				}
				if NOT(err = _TokParams(api_data, &tempP, &len, memberDocBlock, membRecP, lineP, loadClassRecordP, isLocal))
				{	membRecP = (BAPI_Doc*)GetPtr(memberDocBlock);		// reload it
					membRecP->len = sizeof(BAPI_Doc) + (sizeof(BAPI_ParameterDoc) * (membRecP->totParams - 1));
				}
				/*
				// SkipUntilChar(&tempP, &len, '(', nil);
				if (len && (*tempP == '('))
				{	tempP++;
					len--;
					SkipSpaceAndTabCRLF(&tempP, &len, lineP);
					if ((len > 6) && NOT(CompareBlock(tempP, "nonames", 7)))
					{	membRecP->info.method.noNames = true;
						tempP += 7;
						len -= 7;
					}
					else
						membRecP->info.method.noNames = false;
					if (loadClassRecordP)
						strP = loadClassRecordP->curLoadingClassName;
					else
						strP = nil;
					if NOT(err = _TokenizePrototype(api_data, &tempP, &len, memberDocBlock, strP, isLocal))
					{	if ((membRecP->returnClassID == gsDispatcherData.arrayConstructor) && NOT(membRecP->returnAeClass))
							membRecP->returnAeLevel = MAX_ARRAY_LEVEL;
					}
				}
				else
					err = XError(kBAPI_Error, Err_BadPrototype);
				*/
			}
		}
	}

if NOT(err)
{	*lenP = len;
	*prototypeP = tempP;
}
	
return err;
}

#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
/*
static XErr	_FillProtoParams(BifernoRecP bRecP, Ptr *oldFilePPtr, long *lenP, Ptr startP, char *prototype, BlockRef *protoParamBlockP, long *totParamsP, Boolean *dontCheckNamesP, Boolean *dontCheckNumParamsP, LoadClassRecord *loadClassRecordP, Boolean isLocal)
{
XErr		err = noErr;
long		totParams, len;
int			tLen;
Ptr			strP, tempP;
BlockRef	protoParamBlock;

	tempP = *oldFilePPtr;
	len = *lenP;
	totParams = 0;
	protoParamBlock = 0;
	SkipUntilChar(&tempP, &len, '(', nil);
	if (len && (*tempP == '('))
	{	tempP++;
		len--;
		SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
		if ((len > 6) && NOT(CompareBlock(tempP, "nonames", 7)))
		{	*dontCheckNamesP = true;
			tempP += 7;
			len -= 7;
		}
		else
			*dontCheckNamesP = false;
		SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
		if (loadClassRecordP)
			strP = loadClassRecordP->curLoadingClassName;
		else
			strP = nil;
		if NOT(err = TokenizePrototype((long)bRecP, &tempP, &len, dontCheckNumParamsP, &protoParamBlock, &totParams, strP, isLocal))
		{	if ((tLen = (tempP - startP)) > 255)
				tLen = 255;
			CopyBlock(prototype, startP, tLen);
			prototype[tLen] = 0;
			*protoParamBlockP = protoParamBlock;
			*totParamsP = totParams;
		
			*oldFilePPtr = tempP;
			*lenP = len;
		}
	}
	else
		err = XError(kBAPI_Error, Err_ParenthesisExpected);

return err;
}
*/
//===========================================================================================
static void	_GetVisibName(BAPI_Doc *memberDocP, char *visibName, Boolean *isConstP)
{
long	visibility;

	switch(memberDocP->type)
	{	
		case kMethod:
		case kFunction:
			visibility = memberDocP->info.method.visibility;
			*isConstP = false;
			break;
		case kProperty:
		case kError:
		case kConstant:
			visibility = memberDocP->info.property.visibility;
			*isConstP = memberDocP->info.property.isConst;
			break;
	
	}
	switch(visibility)
	{
		case kPublic:
			CEquStr(visibName, "");
			break;
		case kPrivate:
			CEquStr(visibName, "private");
			break;
		case kProtected:
			CEquStr(visibName, "protected");
			break;
	}
}

//===========================================================================================
static void	_NameFromClass(long api_data, long classID, char *name, char *curLoadClass)
{
	if ((classID == CUR_LOADING_CLASS_MAGIC_NUMBER) && curLoadClass)
		CEquStr(name, curLoadClass);
	else
		BAPI_NameFromClassID(api_data, classID, name);
}

//===========================================================================================
void	FillMemberPrototype(long api_data, BAPI_Doc *memberDocP, char *curLoadClass)
{
char	*protP = memberDocP->prototype;
CStr63	className, visibName;
Boolean	isConst;
int		i, aeLevel;

	*protP = 0;
	if (memberDocP->type != kFunction)
	{	if (memberDocP->isStatic)
			CAddStr(protP, "static ");
		_GetVisibName(memberDocP, visibName, &isConst);
		if (*visibName)
		{	CAddStr(protP, visibName);
			CAddChar(protP, ' ');
		}
		if (isConst)
			CAddStr(protP, "const ");
	}
	if (memberDocP->returnClassID)
	{	if (memberDocP->returnAeClass && (aeLevel = memberDocP->returnAeLevel))
		{	_NameFromClass(api_data, memberDocP->returnAeClass, className, curLoadClass);
			for (i = 0; i < aeLevel; i++)
				CAddStr(className, "[]");
		}
		else
			_NameFromClass(api_data, memberDocP->returnClassID, className, curLoadClass);
		CAddStr(protP, className);
		CAddChar(protP, ' ');
	}
	else if (memberDocP->type == kMethod)
		CAddStr(protP, "void ");
	CAddStr(protP, memberDocP->name);
}
//===========================================================================================
static XErr	_IsBuiltIn(char *functionName)
{
XErr	err = noErr;
	
	//if (DLM_GetObjID(gsDispatcherData.functionsList, functionName, nil, nil))
	if (DLM_GetObjID(gsDispatcherData.reservedKeyword, functionName, nil, nil))
		err = XError(kBAPI_Error, Err_ReservedKeyword/*Err_FunctionRedeclared*/);

return err;
}


//===========================================================================================
static XErr	_GetMemberProto(long api_data, Ptr *oldFilePPtr, long *lenP, Ptr *startPPtr, Boolean *isStaticP, Byte *visibilityP, Boolean *isConstantP, long *classIDP, char *memberName, Byte *arraylevelP, long *arrayElementClassID, /*char *memberPrototype, Boolean *loadingStaticP, */LoadClassRecord *loadClassRecordP, Boolean *expectMethodP)
{
Ptr				tempP;
long			objID, aLong, len;
BifernoRecP		bRecP = (BifernoRecP)api_data;
Boolean			doneSTATIC = false, asLastOne = false, doneConst = false, donePrivate = false, doneObjReturned = false, objReturned = false;
XErr			err = noErr;
CStr63			varName;

	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
	*startPPtr = tempP;
	*isStaticP = false;	//*loadingStaticP;
	*visibilityP = kPublic;
	*isConstantP = false;
	*memberName = 0;
	//getNext = (*varName == 0);
	*expectMethodP = false;
	while ((len > 0) && NOT(err))
	{	//if (getNext)
		{	SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
			err = GetEntityName(api_data, &tempP, &len, varName, false);
			if (err && (err == XError(kBAPI_Error, Err_EmptyName)))
				err = XError(kBAPI_Error, Err_BadSyntax);
		}
		if NOT(err)
		{	objID = DLM_GetObjID(gsDispatcherData.reservedKeyword, varName, nil, &aLong);
			if (objID)
			{	switch(aLong)
				{	case _kPUBLIC:
						if (donePrivate)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	*visibilityP = kPublic;
							loadClassRecordP->lastClassID = 0;
							donePrivate = true;
						}
						break;
					case _kPRIVATE:
						if (donePrivate)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	*visibilityP = kPrivate;
							loadClassRecordP->lastClassID = 0;
							donePrivate = true;
						}
						break;
					case _kPROTECTED:
						if (donePrivate)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	*visibilityP = kProtected;
							loadClassRecordP->lastClassID = 0;
							donePrivate = true;
						}
						break;
					case VARIABLE:
						if (doneConst)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	*isConstantP = false;
							loadClassRecordP->lastClassID = 0;
							doneConst = true;
						}
						break;
					case CONSTANT:
						if (doneConst)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	*isConstantP = true;
							loadClassRecordP->lastClassID = 0;
							doneConst = true;
						}
						break;
					case _kOBJ:
						if (doneObjReturned)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	objReturned = true;
							loadClassRecordP->lastClassID = 0;
							doneObjReturned = true;
						}
						break;
					case _kSTATIC:
						if (doneSTATIC)
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	*isStaticP = true;
							loadClassRecordP->lastClassID = 0;
							doneSTATIC = true;
						}
						break;
					default:
						loadClassRecordP->lastClassID = 0;
						goto endWhile;
				}
			}
			else
				break;
			//getNext = true;
		}
	};
endWhile:
	if NOT(err)
	{	if (objReturned)
		{	CEquStr(memberName, varName);
			if NOT(err = _ArrayLevel(&tempP, &len, &aLong))
			{	*arraylevelP = (Byte)aLong;
				if (*arraylevelP)
				{	*classIDP = gsDispatcherData.arrayConstructor;
					*arrayElementClassID = CLASSID_UNSPECIFIED;
				}
				else
				{	*classIDP = CLASSID_UNSPECIFIED;
					*arrayElementClassID = 0;
				}
			}
		}
		else
		{	//CEquStr(memberPrototype, varName);
			if NOT(CCompareStrings_cs(varName, "void"))
				*classIDP = 0;
			else
			{	if NOT(*classIDP = BAPI_ClassIDFromName(api_data, varName, false))
				{	if (*loadClassRecordP->curLoadingClassName && NOT(CCompareStrings_cs(varName, loadClassRecordP->curLoadingClassName)))
						*classIDP = CUR_LOADING_CLASS_MAGIC_NUMBER;
					else
					{	if (loadClassRecordP->lastClassID)		// more on one line
						{	*classIDP = loadClassRecordP->lastClassID;
							CEquStr(memberName, varName);
							//*memberPrototype = 0;
							*isStaticP = (Byte)loadClassRecordP->lastClassID;
							*visibilityP = loadClassRecordP->lastVisibility;
							*isConstantP = loadClassRecordP->lastIsConstant;
							*isStaticP = loadClassRecordP->lastIsStatic;
							asLastOne = true;
						}
						else
						{	CEquStr(memberName, varName);
							//*memberPrototype = 0;
							*classIDP = 0;	// void
							*expectMethodP = true;
							//return XError(kBAPI_Error, Err_BadSyntax);	// if you write a = 10; loading a class return err XError(kBAPI_Error, Err_BadSyntax) (no XError(kBAPI_Error, Err_NoSuchClass)!)
						}
					}
				}
			}
			//SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
			SkipSpaceAndTab(&tempP, &len);
			*arraylevelP = 0;
			if NOT(asLastOne)
			{	if NOT(err = _ArrayLevel(&tempP, &len, &aLong))
				{	*arraylevelP = (Byte)aLong;
					SkipSpaceAndTab(&tempP, &len);
					if NOT(*memberName)
					{	if (err = GetEntityName(api_data, &tempP, &len, memberName, false))
							err = XError(kBAPI_Error, Err_BadSyntax);
					}
					//*loadingStaticP = 0;
					loadClassRecordP->lastClassID = 0;
					loadClassRecordP->lastVisibility = 0;
					loadClassRecordP->lastIsConstant = 0;
					loadClassRecordP->lastIsStatic = 0;
				}
			}
			if NOT(err)
			{	if NOT(*arraylevelP)
				{	err = _ArrayLevel(&tempP, &len, &aLong);
					*arraylevelP = (Byte)aLong;
				}
				if NOT(err)
				{	if (*arraylevelP)
					{	*arrayElementClassID = *classIDP;
						*classIDP = gsDispatcherData.arrayConstructor;
					}
					else
						*arrayElementClassID = 0;
					SkipSpaceAndTab(&tempP, &len);
					if ((*classIDP == gsDispatcherData.arrayConstructor) && NOT(*arrayElementClassID) /*&& (NOT(len) || (*tempP != '('))*/)
						*arraylevelP = MAX_ARRAY_LEVEL;
				}
			}
		}
	}

*oldFilePPtr = tempP;
*lenP = len;
return err;
}

//===========================================================================================
static void	_AdjustMethodsPropertyClass(BifernoClass *bifernoClassP, long classObjID)
{
DLMRef				list;
long				totalLen, totParams, totObjs;	//, objID;
BAPI_Doc			*bifernoFuncP;
XErr				err = noErr;
int					j, i;
BlockRef 			blockRef;
//CStr63				methodName;
BAPI_ParameterDoc	*tProtoParamP;

	// Adjust "info.method.classID" in constructor
	if (bifernoClassP->constructorDoc)
	{	bifernoFuncP = (BAPI_Doc*)GetPtr(bifernoClassP->constructorDoc);
		bifernoFuncP->info.method.classID = classObjID;
	}
	list = bifernoClassP->properties;
	if NOT(err = DLM_GetTotObjs(list, &totObjs, false))
	{	for (i = 1; (i <= totObjs) && NOT(err); i++)
		{	//tLen = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
			//if NOT(err = DLM_GetIndObj(list, i, (Ptr)&bProperty, &tLen, 0, nil, &objID, nil, false, false))
			if NOT(err = GetBifernoFunctionRec(list, i, (Ptr*)&bifernoFuncP, &blockRef, &totalLen))
			{	bifernoFuncP->info.property.classID = classObjID;
				if (bifernoFuncP->returnClassID == CUR_LOADING_CLASS_MAGIC_NUMBER)
					bifernoFuncP->returnClassID = classObjID;
				err = DLM_ModifyObj(list, i, (Ptr)bifernoFuncP, totalLen, 0, nil, 0, nil);
				DisposeBlock(&blockRef);
			}
		}
	}
	list = bifernoClassP->methods;
	if NOT(err = DLM_GetTotObjs(list, &totObjs, false))
	{	for (i = 1; (i <= totObjs) && NOT(err); i++)
		{	//if NOT(err = DLM_GetIndObj(list, i, nil, nil, 0, nil, &objID, methodName, false, false))
			{	if NOT(err = GetBifernoFunctionRec(list, i, (Ptr*)&bifernoFuncP, &blockRef, &totalLen))
				{	bifernoFuncP->info.method.classID = classObjID;
					if (bifernoFuncP->returnClassID == CUR_LOADING_CLASS_MAGIC_NUMBER)
						bifernoFuncP->returnClassID = classObjID;
					if (NOT(err) && (totParams = bifernoFuncP->totParams))
					{	tProtoParamP = bifernoFuncP->params;
						for (j = 0; j < totParams; j++, tProtoParamP++)
						{	if (tProtoParamP->classID == CUR_LOADING_CLASS_MAGIC_NUMBER)
								tProtoParamP->classID = classObjID;
						}
						//err = DLM_ModifyObj(list, objID, (Ptr)bifernoFuncP, tLen, 0, nil, 0, nil);
					}
					if NOT(err)
						err = DLM_ModifyObj(list, i, (Ptr)bifernoFuncP, totalLen, 0, nil, 0, nil);
					DisposeBlock(&blockRef);
				}
			}
		}
	}
}

//===========================================================================================
// file tofile(void)
static XErr	_CheckAllTypeCastMethod(BifernoRecP bRecP, DLMRef list)
{	
XErr		err = noErr;
//long		tLen, requestedClassID, totObjs, funcFileLine, totParamsInProto, returnClassID;
long		totObjs, tLen, requestedClassID;
//Boolean		isStatic;
CStr63		methodName, className;
CStr255		aCStr;
int			i;
Ptr			tPtr;
BAPI_Doc	*bifernoFuncP;
BlockRef	blockRef;

	if NOT(err = DLM_GetTotObjs(list, &totObjs, false))
	{	for (i = 1; (i <= totObjs) && NOT(err); i++)
		{	if NOT(err = DLM_GetInfo(list, i, nil, nil, methodName))
			{	if (*(short*)methodName == TO_PRESTRING)
				{	tPtr = methodName+2;
					tLen = CLen(methodName) - 2;
					if NOT(err = GetEntityName((long)bRecP, &tPtr, &tLen, className, true))
					{	if NOT(CCompareStrings_cs(methodName, kToConstrStringMethodName))
							requestedClassID = kStringClassID;
						else if NOT(CCompareStrings_cs(methodName, kToDebugStringMethodName))
							requestedClassID = kStringClassID;
						else
							requestedClassID = BAPI_ClassIDFromName((long)bRecP, className, false);
						if (requestedClassID)
						{	if NOT(err = GetBifernoFunctionRec(list, i, (Ptr*)&bifernoFuncP, &blockRef, nil))
							{	if (bifernoFuncP->isStatic)
									err = XError(kBAPI_Error, Err_BadPrototype);
								else if (bifernoFuncP->returnClassID != requestedClassID)
									err = XError(kBAPI_Error, Err_BadPrototype);
								else if (bifernoFuncP->totParams)
									err = XError(kBAPI_Error, Err_BadPrototype);
								if (err)
								{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
									CEquStr(aCStr, methodName);
									CAddStr(aCStr, " => ");
									BAPI_NameFromClassID((long)bRecP, requestedClassID, className);
									CAddStr(aCStr, className);
									CAddStr(aCStr, "\t");
									CAddStr(aCStr, methodName);
									CAddStr(aCStr, "(void)");
									NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
								}
								DisposeBlock(&blockRef);
							}
						}
					}
				}
			}
		}
	}

return err;
}

//===========================================================================================
static XErr	_SetClassMethodsObjID(BifernoRecP bRecP, BifernoClass *bifernoClassP)
{
XErr			err = noErr;
DLMRef			list = bifernoClassP->methods;
//ProtoParam		*protoParamP;
//long			funcFileLine, returnClassID, totParamsInProto;
BlockRef		blockRef;
//Boolean			isStatic;
CStr255			aCStr;
BAPI_Doc		*bifernoFuncP;

	// void class_name(parameters)
	/*if (bifernoClassP->constructorObjID = DLM_GetObjID(list, bifernoClassP->className, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->constructorObjID, nil, nil, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->constructorObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{*/	
		if (bifernoClassP->constructorDoc)
		{	bifernoFuncP = (BAPI_Doc*)GetPtr(bifernoClassP->constructorDoc);
			if (bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				CEquStr(aCStr, "void ");
				CAddStr(aCStr, bifernoClassP->className);
				CAddStr(aCStr, "([parameters...])");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
		}
		// put constructor doc in bifernoClassP rec
		//bifernoClassP->constructorDoc = blockRef;
		//DisposeBlock(&blockRef);
	/*	}
		if (err)
			return err;
	}*/
	// void	Clone(void)
	if (bifernoClassP->cloneObjID = DLM_GetObjID(list, kCloneMethodName, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->cloneObjID, nil, nil, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->cloneObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{	if (bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->totParams)
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				//CEquStr(bRecP->errMessage, "Clone correct prototype is: ");
				CEquStr(aCStr, "void Clone(void)");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
			DisposeBlock(&blockRef);
		}
		if (err)
			return err;
	}
	// void	Destructor(void)
	if (bifernoClassP->destructorObjID = DLM_GetObjID(list, kDestructorMethodName, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->destructorObjID, nil, nil, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->destructorObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{	if (bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->totParams)
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				//CEquStr(aCStr, "Destructor correct prototype is: ");
				CEquStr(aCStr, "void Destructor(void)");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
			DisposeBlock(&blockRef);
		}
		if (err)
			return err;
	}
	// void SetProperty(string propertyName)
	if (bifernoClassP->setPropertyObjID = DLM_GetObjID(list, kSetPropertyMethodName, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->setPropertyObjID, &protoParamBlock, &protoParamP, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->setPropertyObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{	if (bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if ((bifernoFuncP->totParams != 1) || (bifernoFuncP->params[0].classID != kStringClassID))
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				//CEquStr(bRecP->errMessage, "SetProperty correct prototype is: ");
				CEquStr(aCStr, "void SetProperty(string propertyName)");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
			//if (protoParamBlock)
			//	DisposeBlock(&protoParamBlock);
			DisposeBlock(&blockRef);
		}
		if (err)
			return err;
	}
	// void Operation(obj theObj, string operation)
	if (bifernoClassP->operationObjID = DLM_GetObjID(list, kOperationMethodName, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->operationObjID, &protoParamBlock, &protoParamP, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->operationObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{	if (bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if ((bifernoFuncP->totParams != 2) || (bifernoFuncP->params[0].classID != CUR_LOADING_CLASS_MAGIC_NUMBER) || (bifernoFuncP->params[1].classID != kStringClassID))
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				CEquStr(aCStr, "void Operation(");
				CAddStr(aCStr, bifernoClassP->className);
				CAddStr(aCStr, " theObj, string operation)");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
			//if (protoParamBlock)
			//	DisposeBlock(&protoParamBlock);
			DisposeBlock(&blockRef);
		}
		if (err)
			return err;
	}

	// boolean Compare(obj theObj, string operation)
	if (bifernoClassP->compareObjID = DLM_GetObjID(list, kCompareMethodName, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->operationObjID, &protoParamBlock, &protoParamP, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->compareObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{	if (bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID != kBooleanClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if ((bifernoFuncP->totParams != 2) || (bifernoFuncP->params[0].classID != CUR_LOADING_CLASS_MAGIC_NUMBER) || (bifernoFuncP->params[1].classID != kStringClassID))
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				CEquStr(aCStr, "boolean Compare(");
				CAddStr(aCStr, bifernoClassP->className);
				CAddStr(aCStr, " theObj, string operation)");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
			//if (protoParamBlock)
			//	DisposeBlock(&protoParamBlock);
			DisposeBlock(&blockRef);
		}
		if (err)
			return err;
	}

	// static string GetErrMessage(int err)
	if (bifernoClassP->getErrMessageObjID = DLM_GetObjID(list, kGetErrMessageMethodName, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->getErrMessageObjID, &protoParamBlock, &protoParamP, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->getErrMessageObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{	if NOT(bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID != kStringClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if ((bifernoFuncP->totParams != 1) || (bifernoFuncP->params[0].classID != kIntClassID))
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				//CEquStr(bRecP->errMessage, "GetErrDescr correct prototype is: ");
				CEquStr(aCStr, "static string GetErrMessage(int errCode");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
			//if (protoParamBlock)
			//	DisposeBlock(&protoParamBlock);
			DisposeBlock(&blockRef);
		}
		if (err)
			return err;
	}

	// void	SuperIsChanged(string propertyName)
	if (bifernoClassP->superIsChangedObjID = DLM_GetObjID(list, kSuperIsChangedMethodName, nil, nil))
	{	//if NOT(err = _GetBifernoProtoBlock(list, bifernoClassP->superIsChangedObjID, &protoParamBlock, &protoParamP, &totParamsInProto, &isStatic, &returnClassID, &funcFileLine))
		if NOT(err = GetBifernoFunctionRec(list, bifernoClassP->superIsChangedObjID, (Ptr*)&bifernoFuncP, &blockRef, nil))
		{	if (bifernoFuncP->isStatic)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if (bifernoFuncP->returnClassID)
				err = XError(kBAPI_Error, Err_BadPrototype);
			else if ((bifernoFuncP->totParams != 1) || (bifernoFuncP->params[0].classID != kStringClassID))
				err = XError(kBAPI_Error, Err_BadPrototype);
			if (err)
			{	bRecP->currentCtx.currentLine = bifernoFuncP->ident.b.fileLine;
				//CEquStr(bRecP->errMessage, "SuperIsChanged correct prototype is: ");
				CEquStr(aCStr, "void SuperIsChanged(string propertyName)");
				NewMsgRecord((long)bRecP, kPROTOTYPE, aCStr, 0, 0);
			}
			//if (protoParamBlock)
			//	DisposeBlock(&protoParamBlock);
			DisposeBlock(&blockRef);
		}
		if (err)
			return err;
	}
	
	bifernoClassP->tostringObjID = DLM_GetObjID(list, kToStringMethodName, nil, nil);

	bifernoClassP->to_construct_stringObjID = DLM_GetObjID(list, kToConstrStringMethodName, nil, nil);
	bifernoClassP->to_debug_stringObjID = DLM_GetObjID(list, kToDebugStringMethodName, nil, nil);

	bifernoClassP->tocharObjID = DLM_GetObjID(list, kToCharMethodName, nil, nil);
	bifernoClassP->tointObjID = DLM_GetObjID(list, kToIntMethodName, nil, nil);
	bifernoClassP->tolongObjID = DLM_GetObjID(list, kToLongMethodName, nil, nil);
	bifernoClassP->tounsignedObjID = DLM_GetObjID(list, kToUnsignedMethodName, nil, nil);
	bifernoClassP->todoubleObjID = DLM_GetObjID(list, kToDoubleMethodName, nil, nil);
	bifernoClassP->tobooleanObjID = DLM_GetObjID(list, kToBooleanMethodName, nil, nil);
	
	err = _CheckAllTypeCastMethod(bRecP, list);
	
return err;
}

//===========================================================================================
/*static Boolean	_SameFunction(BifernoFunc *func1, long len1, BifernoFunc *func2, long len2)
{
	//if	((len1 == len2) && 
	//	NOT(CompareBlock((Ptr)func1 + sizeof(BifernoFunc), (Ptr)func2 + sizeof(BifernoFunc), len1 - sizeof(BifernoFunc))))	// are the same
	return true;

return false;
}*/

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
static void	_FuncErrMsg(long api_data, char *funcName)
{
CStr255		msg;

	CEquStr(msg, "\"");
	CAddStr(msg, funcName);
	CAddStr(msg, "\" is a function or a method (use parenthesis to call it)");
	//CStringToErrMessage(api_data, msg);
	NewMsgRecord(api_data, kADVICE, msg, 0, 0);
}

//===========================================================================================
XErr	DoFunction(long api_data, MemberAction *membIdentP, char *funcName, Ptr *oldFilePPtr, long *lenP, /*char *funcName, long funcPlugID, long funcID, */ObjRecordP result/*, long funcObjID*/)
{
ParameterRec			*paramVarsP;
long					paramVarsBuffID = 0, len, totParams;
XErr					err = noErr;	//, err2 = noErr;
Ptr						tempP;
//long					loadOpcodeBuffer;
	
	tempP = *oldFilePPtr;
	len = *lenP;

	SkipSpaceAndTab(&tempP, &len);
	//membIdent.memberClassID = 0;
	//membIdent.memberObjID = funcObjID;
	//membIdent.memberPluginID = funcPlugID;
	/*if COMPILING(api_data)
		loadOpcodeBuffer = BufferCreate(64, &err);
	else
		loadOpcodeBuffer = 0;*/
	if NOT(err)
	{	
		if NOT(err = GetFunctionParameters(api_data, &tempP, &len, &paramVarsBuffID, &paramVarsP, &totParams, &membIdentP->doc/*, &membIdent, false*/))
		{	
			err = CL_ExecuteFunction(api_data, membIdentP, funcName, paramVarsP, totParams, result);
			BufferFree(paramVarsBuffID);
		}
		else if (err == XError(kBAPI_Error, Err_RoundBracketExpected))
			_FuncErrMsg(api_data, membIdentP->doc.name);
		//if (loadOpcodeBuffer)
		//	BufferFree(loadOpcodeBuffer);
	}
	
if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}

return err;
}

//===========================================================================================
// Attenzione, deve funzionare anche con oldFilePPtr a nil
XErr	GetFunctionInfo(long api_data, Ptr *oldFilePPtr, long *lenP, char *funcName, BlockRef *membIdentBlockP, Boolean *existP)
{
Ptr				tempP;
long			docLength, res, funcPlugID, objID, len;
XErr			err = noErr;
PluginRecordP	plugRecP;
Boolean			allocated;
MemberAction 	*membIdentP;
long			tLen;

	if (membIdentBlockP)
		*membIdentBlockP = nil;
	
	*existP = false;
	if (oldFilePPtr)
	{	
		tempP = *oldFilePPtr;
		len = *lenP;
	}
	else
	{	
		tempP = 0;	// if you forget above note => crash immediately!
		len = 0;
	}
	allocated = false;
	objID = 0;
	res = funcPlugID = 0;
	if (api_data)
	{	
	BifernoRecP		bRecP = (BifernoRecP)api_data;
	Boolean			exists, isApplication;
	
		if NOT(err = GetUserFunctionInfo(bRecP, funcName, membIdentBlockP, &exists, &isApplication))
		{	
			if (exists)
			{
				res = -1;	// it means that is Biferno Function
				/*if COMPILING(api_data)
				{
					// only local funcs are involved in compilation
					if (isApplication)
					{
						DisposeBlock(membIdentBlockP);
						res = 0;
					}
				}*/
			}
		}
	}
	if NOT(res)
	{	
		objID = DLM_GetObjIDExt(gsDispatcherData.functionsList, funcName, nil, &funcPlugID, &docLength);
		if (objID)
		{	res = funcPlugID;
			plugRecP = GetPluginRecFromClassID(nil, funcPlugID);
			if (oldFilePPtr)
			{	SkipSpaceAndTab(&tempP, &len);
				if (NOT(len) || (*tempP != '('))
					res = 0;
			}
			if (res)
			{	
				if (membIdentBlockP)
				{	
					tLen = sizeof(MemberAction) - sizeof(BAPI_Doc) + docLength;
					if (*membIdentBlockP = NewBlockLocked(tLen, &err, (Ptr*)&membIdentP))
					{	allocated = true;
						INVAL(membIdentP->objRef);
						err = DLM_GetObj(gsDispatcherData.functionsList, objID, (Ptr)&membIdentP->doc, &docLength, 0, nil);		
						if (err == XError(kXHelperError, DLM_Err_BufferToSmall))
							err = noErr;
					}
				}
			}
		}
	}
	
//out:
if (res)
{	if (oldFilePPtr)
	{	*oldFilePPtr = tempP;
		*lenP = len;
	}
	*existP = true;
}
if (err && allocated && *membIdentBlockP)
	DisposeBlock(membIdentBlockP);

return err;
}

/*
ex:
modificata a guardare prima nella lista user (poi C)
XErr	GetFunctionInfo(long api_data, Ptr *oldFilePPtr, long *lenP, char *funcName, BlockRef *membIdentBlockP, Boolean *existP)
{
Ptr				tempP;
long			docLength, res, funcPlugID, objID, len;
XErr			err = noErr;
PluginRecordP	plugRecP;
Boolean			allocated;
MemberAction 	*membIdentP;
long			tLen;

	*existP = false;
	if (oldFilePPtr)
	{	tempP = *oldFilePPtr;
		len = *lenP;
	}
	else
	{	tempP = 0;	// if you forget above note => crash immediately!
		len = 0;
	}
	allocated = false;
	objID = 0;
	res = 0;
	objID = DLM_GetObjIDExt(gsDispatcherData.functionsList, funcName, nil, &funcPlugID, &docLength);
	if (objID)
	{	res = funcPlugID;
		plugRecP = GetPluginRecFromClassID(nil, funcPlugID);
		//perch�? ex if (plugRecP->pluginType != kNewFunctionsPlugin)
		//	res = 0;
		//else
		{	if (oldFilePPtr)
			{	SkipSpaceAndTab(&tempP, &len);
				if (NOT(len) || (*tempP != '('))
					res = 0;
			}
		}
		if (res)
		{	if (membIdentBlockP)
			{	tLen = sizeof(MemberAction) - sizeof(BAPI_Doc) + docLength;
				if (*membIdentBlockP = NewBlockLocked(tLen, &err, (Ptr*)&membIdentP))
				{	allocated = true;
					INVAL(membIdentP->objRef);
					err = DLM_GetObj(gsDispatcherData.functionsList, objID, (Ptr)&membIdentP->doc, &docLength, 0, nil);		
					if (err == XError(kXHelperError, DLM_Err_BufferToSmall))
						err = noErr;
				}
			}
		}
	}
	else if (api_data)
	{	
	BifernoRecP		bRecP = (BifernoRecP)api_data;
	Boolean			exists;
	
		if NOT(err = GetUserFunctionInfo(bRecP, funcName, membIdentBlockP, &exists))
		{	if (exists)
				res = -1;	// it means that is Biferno Function
		}
	}
	
out:
if (res)
{	if (oldFilePPtr)
	{	*oldFilePPtr = tempP;
		*lenP = len;
	}
	*existP = true;
}
if (err && allocated && *membIdentBlockP)
	DisposeBlock(membIdentBlockP);

return err;
}

*/
//===========================================================================================
static XErr	_IsInOtherScope(char *name, long classScope, DLMRef checkForDuplicateList, Boolean isClass)
{
XErr	err = noErr;
	
	// Se dichiaro classe application ed esiste local error! -> l�inverso invece ok
	if (classScope == APPLICATION)
	{	if (DLM_GetObjID(checkForDuplicateList, name, nil, nil))
		{	if (isClass)
				err = XError(kBAPI_Error, Err_ClassRedeclared);
			else
				err = XError(kBAPI_Error, Err_FunctionRedeclared);
		}
	}
	
return err;
}

//===========================================================================================
static Boolean	_SameFile(char *path1, long line1, char *path2, long line2)
{
	return (NOT(ComparePaths(path1, path2)) && (line1 != line2));
}

//===========================================================================================
XErr	LoadBifernoFunction(long api_data, Ptr *oldFilePPtr, long *lenP, Ptr loadClassDataP)
{
Ptr					saveP, startP, tempP;
long				tScope, funcObjID, len;
XErr				err = noErr;
BifernoRecP			bRecP = (BifernoRecP)api_data;
LoadClassRecord		*loadClassRecordP = (LoadClassRecord*)loadClassDataP;
DLMRef				loadList;
BlockRef			memberDocBlock;
BAPI_Doc			*memberDocP;

	if NOT(bRecP->lastScope)
		bRecP->lastScope = bRecP->currentCtx.defaultScope;
	if (bRecP->lastScope == LOCAL)
	{	loadList = bRecP->local.funcsList;
		tScope = LOCAL;
	}
	else if (bRecP->lastScope == APPLICATION)
	{	if (bRecP->currentCtx.defaultScope != APPLICATION)
			return XError(kBAPI_Error, Err_InvalidScope);
		else
		{	loadList = bRecP->application.funcsList;
			tScope = APPLICATION;
		}
	}
	else
		return XError(kBAPI_Error, Err_InvalidScope);
	
	if (memberDocBlock = NewBlockLocked(sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc), &err, (Ptr*)&memberDocP))
	{	
	Boolean		addPeriods;
	long		protLen, saveLen;
	
		ClearBlock(memberDocP, sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc));
		tempP = *oldFilePPtr;
		len = *lenP;
		SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
		startP = tempP;
		if (bRecP->currentCtx.currentLine == bRecP->currentCtx.lastLoadLine)
			err = XError(kBAPI_Error, Err_BadSyntax);
		else
		{	// memberDocP->ident.b.fileLine = bRecP->lastLoadLine = bRecP->currentCtx.currentLine;
			SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
			memberDocP->type = kFunction;
			saveP = tempP;
			saveLen = len;
			if NOT(err = PrototypeToBAPI_Doc(api_data, &tempP, &len, memberDocBlock, loadClassRecordP, (Boolean)(bRecP->lastScope == APPLICATION), kFunction))
			{	
				if (NOT(err = _IsBuiltIn(memberDocP->name)) && NOT(err = _IsInOtherScope(memberDocP->name, tScope, bRecP->local.funcsList, false)))
				{
					memberDocP = (BAPI_Doc*)GetPtr(memberDocBlock);		// reload it
					//_FillMemberPrototype(api_data, memberDocP, "");
					protLen = saveLen - len;
					if (protLen > 255)
					{	protLen = 252;
						addPeriods = true;
					}
					else
						addPeriods = false;
					CopyBlock(memberDocP->prototype, saveP, protLen);
					memberDocP->prototype[protLen] = 0;
					if (addPeriods)
						CAddStr(memberDocP->prototype, "...");
					memberDocP->implem = kBifernoImplementation;
					memberDocP->len = sizeof(BAPI_Doc) + (sizeof(BAPI_ParameterDoc) * (memberDocP->totParams - 1));
					memberDocP->ident.b.list = loadList;
					SkipSmart(bRecP, &tempP, &len);
					//SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
					memberDocP->ident.b.sourceFile = bRecP->curFile;
					saveP = tempP;
					memberDocP->ident.b.fileLine = bRecP->currentCtx.lastLoadLine = bRecP->currentCtx.currentLine;
					memberDocP->ident.b.fileOffset = bRecP->curFile.fileSize - len;
					if (COMPILING(api_data))
					{
						// create VL of function
						
						// prendi dallo stack i parametri
						/*
						 int			totParams = memberDocP->totParams, i;
						ObjRecord	source, dest;
						
						BIC_OBJREF_SPEC(&source) = kVL_LIST;
						BIC_OBJREF_SPEC(&dest) = kVL_LIST;
						source.id = SP;
						for (i = 0; i < totParams; i++)
						{
							dest.id = i + 1;
							dest.classID = memberDocP->params[i].classID;							
							if (Opcode_store(&bRecP->bicRecord, &dest, &source, nil, 0))
								break;
						}
						if not(err)
							err = ProcessBlock(api_data, &tempP, &len, 0);
						 */
					}
					else
						err = SkipEntireBlock(api_data, &tempP, &len, 0, bRecP->currentCtx.tot_graf_pars, true);
					if NOT(err)
					{	
					long		funcLen, totLen;
					BlockRef	bl;
					Ptr			p;
					
						/*if (memberDocP->ident.b.fileLine == bRecP->currentCtx.currentLine)	// on 1 line
							err = XError(kBAPI_Error, Err_BadSyntax);
						else
						{	*/
						funcLen = tempP - saveP;
						totLen = memberDocP->len + funcLen;
						memberDocP->ident.b.funcLength = funcLen;
						if (bl = NewBlockLocked(totLen, &err, &p))
						{	CopyBlock(p, memberDocP, memberDocP->len);
							CopyBlock(p + memberDocP->len, saveP, funcLen);
							if NOT(funcObjID = DLM_GetObjID(loadList, memberDocP->name, nil, nil))
								funcObjID = DLM_NewObj(loadList, memberDocP->name, p, totLen, 0, 0L, &err);
							else
							{	
							BAPI_Doc		*bFuncRecP;
							BlockRef 		ref;
							long			totalLen;
							//Boolean			isSame = false;
								
								if NOT(err = GetBifernoFunctionRec(loadList, funcObjID, (Ptr*)&bFuncRecP, &ref, &totalLen))
								{	if (_SameFile(bRecP->curFile.filePath, memberDocP->ident.b.fileLine, bFuncRecP->ident.b.sourceFile.filePath, bFuncRecP->ident.b.fileLine))
									{	bRecP->currentCtx.currentLine = memberDocP->ident.b.fileLine;
										err = XError(kBAPI_Error, Err_FunctionRedeclared);
									}
									else
										err = DLM_ModifyObj(loadList, funcObjID, p, totLen, 0, nil, 0, nil);
									DisposeBlock(&ref);
								}
							}
							DisposeBlock(&bl);
						}
					}
				}
			}
		}
		DisposeBlock(&memberDocBlock);
	}
		
//out:
*oldFilePPtr = tempP;
*lenP = len;
return err;
}

//===========================================================================================
XErr	DoFunctionReturn(long api_data, Ptr *oldFilePPtr, long *lenP)
{
XErr			err = noErr;
Ptr				tempP;
long			saveLine, lCID, len;
BifernoRecP		bRecP;
ObjRecord		returnObj;

	if (api_data)
		bRecP = (BifernoRecP)api_data;
	else
		return XError(kBAPI_Error, Err_BAPI_InvalidAPIData);
	
	if NOT(bRecP->currentCtx.methodInExecutionID)
		return XError(kBAPI_Error, Err_IllegalFlowControl);
		
	tempP = *oldFilePPtr;
	len = *lenP;
	SkipSpaceAndTab(&tempP, &len);
	if (bRecP->currentCtx.returnClassID == CLASSID_UNSPECIFIED)
		lCID = 0;
	else
		lCID = bRecP->currentCtx.returnClassID;
	//tempObj = bRecP->lastFuncResultObj;
	INVAL(returnObj);
	saveLine = bRecP->currentCtx.currentLine;
	if NOT(err = Eval(api_data, lCID, kExplicitTypeCast, &tempP, &len, kNoFlowControl + kStopOnCR, &returnObj))
	{	if (returnObj.id && NOT(bRecP->currentCtx.returnClassID))
			err = XError(kBAPI_Error, Err_FunctionIsVoid);
		else if (NOT(returnObj.id) && bRecP->currentCtx.returnClassID)
			err = XError(kBAPI_Error, Err_ReturnValueRequired);
		else if (returnObj.id && NOT(IS_IMMEDIATE(returnObj)) && (returnObj.list && (returnObj.list != bRecP->volatileList)))
		{	ObjRecord	tObjRef;
			
			// Move to volatile list
			//if NOT(err = BAPI_CopyObj(api_data, OBJREF_P(&returnObj), nil, OBJREF_P(&tObjRef)))
			INVAL(tObjRef);
			if NOT(err = BAPI_Clone(api_data, OBJREF_P(&returnObj), OBJREF_P(&tObjRef), false))
			{	//if NOT(err = DLM_TurnOnFlag(returnObj.list, returnObj.id, kNoDestructor, kDLMElements))
					returnObj = tObjRef;
			}
		}
		if NOT(err)
		{	
		long			ael, aeClassID;
		Boolean			fixedSize;
		ArraySpecs		arSpec;
		
			if (returnObj.id && (aeClassID = bRecP->currentCtx.returnAeClass) && (lCID == gsDispatcherData.arrayConstructor))
			{	// if NOT(err = BAPI_GetArrayInfo(api_data, OBJREF_P(objP), nil, &arrayElemClassID))
				if NOT(err = GetArraySpecs(api_data, &returnObj, &arSpec))
				{	if (bRecP->currentCtx.returnAeLevel != MAX_ARRAY_LEVEL)
					{	ael = bRecP->currentCtx.returnAeLevel - 1;
						if (arSpec.arrayElemAeLevel != ael)
							err = XError(kBAPI_Error, Err_ArrayMismatch);
						else if (aeClassID != arSpec.arrayElemClassID)
						{	BAPI_FixedSize(api_data, aeClassID, &fixedSize);
							err = CloneObject(api_data, &returnObj, nil, bRecP->volatileList, TEMP, lCID, aeClassID, false, fixedSize, &returnObj.id, nil, true);
						}
					}
				}
			}
			if NOT(err)
				bRecP->lastFuncResultObj = returnObj;
		}
	}

if (err)
	bRecP->currentCtx.currentLine = saveLine;
else
{	*oldFilePPtr = tempP;
	*lenP = len;
}
return err;
}

//===========================================================================================
/*XErr	BisFunctionsDestructor(DLMRef dlRef, long objID, long varType, long api_data)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(varType, api_data)
XErr			err = noErr;
BisFunction		bisFunction;

	if NOT(err = DLM_GetObj(dlRef, objID, (Ptr)&bisFunction, nil, nil, 0, 0, sizeof(BisFunction)))
		DisposeBlock(&bisFunction.functionBlockRef);

return err;
}*/

#if __MWERKS__
#pragma mark-
#endif


//===========================================================================================
static XErr	_LoadBifernoProperty(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean isStatic, Byte visibility, Boolean isConstant, long classID, char *propertyName, Byte arrayLevel, long arrayElementClassID, /*char *propertyPrototype, */Boolean *endWithCommaP, LoadClassRecord *loadClassRecordP)
{
Ptr					saveP, tempP;
long				saveCurLine, docLen, ifErrorValue, objID, len, tLen;
XErr				err = noErr;
BifernoRecP			bRecP = (BifernoRecP)api_data;
CStr15				tStr;
Byte				lastChar;
BlockRef			memberDocBlock;
BAPI_Doc			*memberDocP;
	
	if (classID == gsDispatcherData.refConstructor)
		return XError(kBAPI_Error, Err_IllegalRef);
	if (DLM_GetObjID(gsDispatcherData.reservedKeyword, propertyName, nil, nil))
		return XError(kBAPI_Error, Err_ReservedKeyword);
	if (classID == CLASSID_UNSPECIFIED)
		return XError(kBAPI_Error, Err_BadSyntax);
	if (IS_LOCAL(classID) && (loadClassRecordP->curLoadClassScope == APPLICATION))
		return XError(kBAPI_Error, Err_ScopeConflict);
		
	tempP = *oldFilePPtr;
	len = *lenP;
	saveCurLine = bRecP->currentCtx.currentLine;
	ifErrorValue = 0;
	SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
	docLen = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
	if (memberDocBlock = NewBlockLocked(docLen, &err, (Ptr*)&memberDocP))
	{	ClearBlock(memberDocP, docLen);
		memberDocP->isStatic = isStatic;
		memberDocP->info.property.visibility = visibility;
		memberDocP->info.property.isConst = isConstant;
		memberDocP->returnAeLevel = arrayLevel;
		memberDocP->returnAeClass = arrayElementClassID;
		memberDocP->returnClassID = classID;
		memberDocP->len = sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc);
		memberDocP->implem = kBifernoImplementation;
		memberDocP->ident.b.sourceFile = bRecP->curFile;
		if (isStatic && isConstant && (classID == gsDispatcherData.errConstructor))
			memberDocP->type = kError;
		else if (isConstant)
			memberDocP->type = kConstant;
		else
			memberDocP->type = kProperty;
		CEquStr(memberDocP->name, propertyName);
		FillMemberPrototype(api_data, memberDocP, loadClassRecordP->curLoadingClassName);
		if (len && (*tempP == '='))
		{	tempP++;
			len--;
			SkipSpaceAndTab(&tempP, &len);
			saveP = tempP;
			
			SkipOneParameter((BifernoRecP)api_data, &tempP, &len, &lastChar, kStopOnCR | kStopOnComma, false, false);
			if ((tLen = tempP - saveP) < 255)
			{	CopyBlock(memberDocP->info.property.defaultStr, saveP, tLen);
				if ((lastChar == ',') && (tLen > 0))
					tLen--;
				memberDocP->info.property.defaultStr[tLen] = 0;
				*endWithCommaP = (lastChar == ',');
			}
			else
				err = XError(kBAPI_Error, Err_TooLongDefault);
			RemoveEndChar(&tempP, &len, kStopOnCR | kStopOnComma, &bRecP->currentCtx.currentLine, true);
		}
		else
		{	SkipSpaceAndTab(&tempP, &len);
			*endWithCommaP = len && (*tempP == ',');
			if (*endWithCommaP)
			{	tempP++;
				len--;
			}
			else if (len && (*tempP == ';'))
			{	tempP++;
				len--;
			}
		}
		if NOT(err)
		{	if (memberDocP->isStatic)
			{	
			ObjRecord	tObjref;
				
				err = DefaultProperty(bRecP, memberDocP, nil, loadClassRecordP->curLoadClassStaticList, APPLICATION, true, &tObjref);
				if (NOT(err) && (memberDocP->type == kError))
				{	if NOT(err = BAPI_ObjToInt(api_data, OBJREF_P(&tObjref), &ifErrorValue, kExplicitTypeCast))
					{	if NOT(ifErrorValue)
							err = XError(kBAPI_Error, Err_InvalidErrorValue);
					}
				}
			}
			if NOT(err)
			{	DLMRef	list;
			
				// Differentiate to order static after non static
				if (memberDocP->isStatic)
					list = loadClassRecordP->curLoadClassPropertyTemporaneousStaticList;
				else
					list = loadClassRecordP->curLoadClassPropertyList;
				memberDocP->ident.b.list = list;
				if NOT(objID = DLM_GetObjID(list, propertyName, nil, nil))
					objID = DLM_NewObj(list, propertyName, (Ptr)memberDocP, docLen, classID, 0L, &err);
				else
					err = XError(kBAPI_Error, Err_DuplicatedPropertyName);
				if NOT(err)
				{	if (ifErrorValue)
					{	CNumToString(ifErrorValue, tStr);
						DLM_NewObj(loadClassRecordP->curLoadClassErrorsList, tStr, propertyName, CLen(propertyName), 0, 0L, &err);
					}
				}
			}
		}
		DisposeBlock(&memberDocBlock);
	}

if NOT(err)
{	*oldFilePPtr = tempP;
	*lenP = len;
}
else
	bRecP->currentCtx.currentLine = saveCurLine;
		
return err;
}

//===========================================================================================
static XErr	_LoadBifernoMethod(long api_data, Ptr *oldFilePPtr, long *lenP, Boolean isStatic, Byte visibility, long classID, char *functionName, Byte arrayLevel, long arrayElementClassID, /*char *prototype, */LoadClassRecord *loadClassRecordP)
{
Ptr				saveP, tempP;
long			funcNameLine, funcObjID, len;
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
//Boolean			isNew = false;
//CStr255			aCStr;
BlockRef		memberDocBlock;
BAPI_Doc		*memberDocP;
long			preProtLen, protLen, saveLen;

	if (memberDocBlock = NewBlockLocked(sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc), &err, (Ptr*)&memberDocP))
	{	ClearBlock(memberDocP, sizeof(BAPI_Doc) - sizeof(BAPI_ParameterDoc));
		tempP = *oldFilePPtr;
		len = *lenP;
		memberDocP->isStatic = isStatic;
		memberDocP->info.method.visibility = visibility;
		memberDocP->returnClassID = classID;
		memberDocP->returnAeLevel = arrayLevel;
		memberDocP->returnAeClass = arrayElementClassID;
		memberDocP->implem = kBifernoImplementation;
		memberDocP->type = kMethod;
		funcNameLine = bRecP->currentCtx.currentLine;
		CEquStr(memberDocP->name, functionName);
		FillMemberPrototype(api_data, memberDocP, loadClassRecordP->curLoadingClassName);
		if (memberDocP->returnClassID == gsDispatcherData.refConstructor)
			err = XError(kBAPI_Error, Err_IllegalRef);
		else
		{	preProtLen = CLen(memberDocP->prototype);
			saveP = tempP;
			saveLen = len;
			SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
			// if NOT(err = PrototypeToBAPI_Doc(api_data, &tempP, &len, memberDocBlock, loadClassRecordP, loadClassRecordP->curLoadClassScope == APPLICATION, kMethod))
			if NOT(err = _TokParams(api_data, &tempP, &len, memberDocBlock, memberDocP, &bRecP->currentCtx.currentLine, loadClassRecordP, (Boolean)(loadClassRecordP->curLoadClassScope == APPLICATION)))
			{	memberDocP = (BAPI_Doc*)GetPtr(memberDocBlock);		// reload it
				memberDocP->len = sizeof(BAPI_Doc) + (sizeof(BAPI_ParameterDoc) * (memberDocP->totParams - 1));
				protLen = saveLen - len;
				if ((preProtLen + protLen) > 255)
					CAddStr(memberDocP->prototype, "...");
				else
				{	CopyBlock(memberDocP->prototype + preProtLen, saveP, protLen);
					memberDocP->prototype[preProtLen + protLen] = 0;
				}
				/*
				if (isStatic)
				{	CEquStr(memberDocP->prototype, "static ");
					CAddStr(memberDocP->prototype, aCStr);
				}
				else
					CEquStr(memberDocP->prototype, aCStr);
				*/
				//SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
				SkipSmart(bRecP, &tempP, &len);
				memberDocP->ident.b.sourceFile = bRecP->curFile;
				memberDocP->ident.b.fileLine = bRecP->currentCtx.currentLine;
				memberDocP->ident.b.fileOffset = bRecP->curFile.fileSize - len;
				saveP = tempP;
				if NOT(err = SkipEntireBlock(api_data, &tempP, &len, 0, bRecP->currentCtx.tot_graf_pars, true))
				{	long		funcLen, totLen;
					BlockRef	bl;
					Ptr			p;
					DLMRef		list;
				
					funcLen = tempP - saveP;
					totLen = memberDocP->len + funcLen;
					memberDocP->ident.b.funcLength = funcLen;
					list = loadClassRecordP->curLoadClassMethodList;
					memberDocP->ident.b.list = list;
					if (bl = NewBlockLocked(totLen, &err, &p))
					{	CopyBlock(p, memberDocP, memberDocP->len);
						CopyBlock(p + memberDocP->len, saveP, funcLen);
						// is the constructor?
						if NOT(CCompareStrings_cs(functionName, loadClassRecordP->curLoadingClassName))
						{	if (loadClassRecordP->constructorDoc)
								err = XError(kBAPI_Error, Err_DuplicatedConstructor);
							else
							{	loadClassRecordP->constructorDoc = bl;
								bl = 0;		// dont dispose it
							}
						}
						else
						{	// Put in list
							if NOT(funcObjID = DLM_GetObjID(list, functionName, nil, nil))
								funcObjID = DLM_NewObj(list, functionName, p, totLen, 0, 0L, &err);
							else
							{	bRecP->currentCtx.currentLine = funcNameLine;
								err = XError(kBAPI_Error, Err_MethodNameConflict);
							}
						}
						if (bl)
							DisposeBlock(&bl);
					}
				}	
			}
		}
		DisposeBlock(&memberDocBlock);
	}
	
//out:
*oldFilePPtr = tempP;
*lenP = len;
return err;
}

//===========================================================================================
static XErr	_LoadBifernoMember(long api_data, Ptr *oldFilePPtr, long *lenP, /*Boolean *loadingStaticP, */LoadClassRecord *loadClassRecordP)
{
XErr		err = noErr;
Ptr			saveP, startP;
Boolean 	isStatic, isConstant;
Byte		visibility;
long 		savelen, saveCurrentLine, arrayElementClassID, classID;
CStr63		memberName;
Byte		arrayLevel;
BifernoRecP	bRecP = (BifernoRecP)api_data;
Boolean		expectMethod, endWithComma;
/*int			varNameLen;

	if (*varName)
	{	varNameLen = CLen(varName);
		*oldFilePPtr -= varNameLen;
		*lenP += varNameLen;
	}*/
	saveCurrentLine = bRecP->currentCtx.currentLine;
	saveP = *oldFilePPtr;
	savelen = *lenP;
	/*if ((savelen > 5) && (*(long*)saveP == STAT_KEY) && (*(short*)(saveP + 4) == STAT_KEY2))
	{	*loadingStaticP = true;
		loadClassRecordP->lastClassID = 0;
		(*oldFilePPtr) += 6;
		(*lenP) -= 6;
		SkipSpaceAndTab(oldFilePPtr, lenP);
	}*/
	if NOT(err = _GetMemberProto(api_data, oldFilePPtr, lenP, &startP, &isStatic, &visibility, &isConstant, &classID, memberName, &arrayLevel, &arrayElementClassID, /*prototype, loadingStaticP, */loadClassRecordP, &expectMethod))
	{	if (*lenP && (**oldFilePPtr == '('))
		{	/*if (arrayLevel)
				err = XError(kBAPI_Error, Err_BadSyntax);
			else*/
				err = _LoadBifernoMethod(api_data, oldFilePPtr, lenP,/* startP,*/ isStatic, visibility, classID, memberName, arrayLevel, arrayElementClassID, /*prototype, */loadClassRecordP);
			//*loadingStaticP = 0;
			loadClassRecordP->lastClassID = 0;
			loadClassRecordP->lastVisibility = 0;
			loadClassRecordP->lastIsConstant = 0;
			loadClassRecordP->lastIsStatic = 0;
		}
		else
		{	if (expectMethod)
			{	err = XError(kBAPI_Error, Err_BadSyntax);
				NewMsgRecord(api_data, kDOING, memberName, 0, 0);
			}
			else if ((classID == CLASSID_UNSPECIFIED) || NOT(classID))
			{	err = XError(kBAPI_Error, Err_BadSyntax);
				NewMsgRecord(api_data, kDOING, memberName, 0, 0);
			}
			else
				err = _LoadBifernoProperty(api_data, oldFilePPtr, lenP, isStatic, visibility, isConstant, classID, memberName, arrayLevel, arrayElementClassID, /*prototype, */&endWithComma, loadClassRecordP);
			if NOT(err)
			{	if (endWithComma)
				{	//*loadingStaticP = false;
					loadClassRecordP->lastClassID = classID;
					loadClassRecordP->lastVisibility = visibility;
					loadClassRecordP->lastIsConstant = isConstant;
					loadClassRecordP->lastIsStatic = isStatic;
				}
				else
				{	//*loadingStaticP = false;
					loadClassRecordP->lastClassID = 0;
					loadClassRecordP->lastVisibility = 0;
					loadClassRecordP->lastIsConstant = 0;
					loadClassRecordP->lastIsStatic = 0;
				}
			}
		}
	}
	else
	{	*oldFilePPtr = saveP;
		*lenP = savelen;
		bRecP->currentCtx.currentLine = saveCurrentLine;
	}

return err;
}

//===========================================================================================
static XErr	_LoadClassBody(long api_data, Ptr *oldFilePPtr, long *lenP, LoadClassRecord *loadClassRecordP)
{
XErr			err = noErr;
BifernoRecP		bRecP = (BifernoRecP)api_data;
long			tot_graf_pars, *curLineP = &bRecP->currentCtx.currentLine;
//Boolean			loadingStatic = false;

	bRecP->loadingClass = true;
	while NOT(err)
	{	SkipSpaceAndTabCRLF(oldFilePPtr, lenP, curLineP);
		if (IsCommentExt(bRecP, oldFilePPtr, lenP, nil, nil, false))
			SkipSpaceAndTabCRLF(oldFilePPtr, lenP, curLineP);
		if (*lenP && **oldFilePPtr == '}')
		{	(*oldFilePPtr)++;
			(*lenP)--;
			tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
			if (tot_graf_pars < MAX_PARCHECKS)
				bRecP->currentCtx.toBalance[tot_graf_pars] = 0;
			if (--tot_graf_pars < 0)
				err = XError(kBAPI_Error, Err_CurlyBracketNotBalanced);
			else
				bRecP->currentCtx.tot_graf_pars = (short)tot_graf_pars;
			break;
		}
		err = _LoadBifernoMember(api_data, oldFilePPtr, lenP, /*&loadingStatic, */loadClassRecordP);
	}
	bRecP->loadingClass = false;

return err;
}

//===========================================================================================
XErr	LoadBifernoClass(long api_data, Ptr *oldFilePPtr, long *lenP)
{
Ptr					tempP;
long				clID, len;
XErr				err = noErr;
CStr63				nameErr, className;
BifernoRecP			bRecP = (BifernoRecP)api_data;
BifernoClass		bifernoClass;
long				tScope, tot_graf_pars, saveLine, dlmListScope;
LoadClassRecord		loadClassRecord;
DLMRef				loadList;
BfrDestructRec		destructRec;

	if (bRecP->loadingClass)
		return XError(kBAPI_Error, Err_BadSyntax);
		
	if NOT(bRecP->lastScope)
		bRecP->lastScope = bRecP->currentCtx.defaultScope;
	if (bRecP->lastScope == LOCAL)
	{	loadList = bRecP->local.classList;
		//checkForDuplicateList = bRecP->application.classList;
		tScope = GLOBAL;
		dlmListScope = LOCAL_LIST;
	}
	else if (bRecP->lastScope == APPLICATION)
	{	if (bRecP->currentCtx.defaultScope != APPLICATION)
			return XError(kBAPI_Error, Err_InvalidScope);
		else
		{	loadList = bRecP->application.classList;
			//checkForDuplicateList = bRecP->local.classList;
			tScope = APPLICATION;
			dlmListScope = GLOBAL_LIST;
		}
	}
	else
		return XError(kBAPI_Error, Err_InvalidScope);
	
	ClearBlock(&bifernoClass, sizeof(BifernoClass));
	ClearBlock(&loadClassRecord, sizeof(LoadClassRecord));

	tempP = *oldFilePPtr;
	len = *lenP;
	if (bRecP->currentCtx.currentLine == bRecP->currentCtx.lastLoadLine)
		err = XError(kBAPI_Error, Err_BadSyntax);
	else
	{	saveLine = bRecP->currentCtx.lastLoadLine = bRecP->currentCtx.currentLine;
		SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
		err = GetEntityName(api_data, &tempP, &len, className, false);
		if (err == XError(kBAPI_Error, Err_EmptyName))
		{	bRecP->currentCtx.currentLine = saveLine;
			err = XError(kBAPI_Error, Err_BadSyntax);
			NewMsgRecord(api_data, kDOING, "class", 0, 0);
			NewMsgRecord(api_data, kADVICE, "name of the class expected", 0, 0);
		}
		if NOT(err)
		{	// className must not be a name of en entity
		long	varList, varType, varScope, classID;
		
			varList = classID = varType = varScope = 0;
			if (LookForObj(api_data, className, &varList, &varType, &classID, &varScope, &err) && classID)
			{	bRecP->currentCtx.currentLine = saveLine;
				err = XError(kBAPI_Error, Err_InvalidName);
				NewMsgRecord(api_data, kDOING, className, 0, 0);
				NewMsgRecord(api_data, kADVICE, "this name is already a name of a variable", 0, 0);
			}
			else
				CEquStr(bifernoClass.className, className);
			bifernoClass.sourceLine = saveLine;
			if NOT(err)
			{	SkipSmart(bRecP, &tempP, &len);
				if ((len > 6) && NOT(CompareBlock(tempP, "extends", 7)))
				{
				CStr63	extClassName;
				
					tempP += 7;
					len -= 7;
					SkipSmart(bRecP, &tempP, &len);
					if NOT(err = GetEntityName(api_data, &tempP, &len, extClassName, false))
					{	if (bifernoClass.extendedClassID = BAPI_ClassIDFromName(api_data, extClassName, false))
						{	if ((bRecP->lastScope == APPLICATION) && IS_LOCAL(bifernoClass.extendedClassID))
								err = XError(kBAPI_Error, Err_ScopeConflict);
							else
								SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
						}
						else
							err = XError(kBAPI_Error, Err_NoSuchClass);
					}
				}
				if NOT(err)
				{	SkipSmart(bRecP, &tempP, &len);
					if (len && (*tempP == '{'))
					{	tempP++;
						len--;
						tot_graf_pars = bRecP->currentCtx.tot_graf_pars;
						if (tot_graf_pars < MAX_PARCHECKS)
							bRecP->currentCtx.toBalance[tot_graf_pars] = (short)bRecP->currentCtx.currentLine;
						bRecP->currentCtx.tot_graf_pars++;
						SkipSpaceAndTabCRLF(&tempP, &len, &bRecP->currentCtx.currentLine);
					}
					else
						err = XError(kBAPI_Error, Err_BadSyntax);
				}
				if NOT(err)
				{	SkipSmart(bRecP, &tempP, &len);
					if NOT(err = DLM_Create(&bifernoClass.properties, NAMECS_LIST, dlmListScope))
					{	if NOT(err = DLM_Create(&bifernoClass.methods, NAMECS_LIST, dlmListScope))
						{	if NOT(err = DLM_Create(&bifernoClass.staticProperties, ID_LIST, dlmListScope))
							{	//if NOT(err = DLM_Create(&bifernoClass.prototypes, ID_LIST, GLOBAL_LIST))
								{	if NOT(err = DLM_Create(&bifernoClass.errors, NAMECS_LIST, dlmListScope))
									{	long	classObjID;
								
										if NOT(err = DLM_Create(&loadClassRecord.curLoadClassPropertyTemporaneousStaticList, NAMECS_LIST, LOCAL_LIST))
										{	loadClassRecord.curLoadClassMethodList = bifernoClass.methods;
											loadClassRecord.curLoadClassPropertyList = bifernoClass.properties;
											loadClassRecord.curLoadClassStaticList = bifernoClass.staticProperties;
											loadClassRecord.curLoadClassErrorsList = bifernoClass.errors;
											CEquStr(loadClassRecord.curLoadingClassName, bifernoClass.className);
											loadClassRecord.curLoadClassScope = (Byte)tScope;
											err = _LoadClassBody(api_data, &tempP, &len, &loadClassRecord);
											bifernoClass.constructorDoc = loadClassRecord.constructorDoc;
											if NOT(err)
											{	bifernoClass.constructorDoc = loadClassRecord.constructorDoc;
												CEquStr(bifernoClass.sourceFilePath, bRecP->curFile.filePath);
												DLM_GetTotObjs(bifernoClass.properties, &bifernoClass.totNonStatic, false);
												if (err = DLM_ConcatLists(bifernoClass.properties, loadClassRecord.curLoadClassPropertyTemporaneousStaticList, nameErr))
												{	if (err == XError(kXHelperError, DLM_Err_DuplicatedObject))
													{	NewMsgRecord(api_data, kDOING, nameErr, 0, 0);
														err = XError(kBAPI_Error, Err_DuplicatedPropertyName);
													}
												}
											}
											DLM_Dispose(&loadClassRecord.curLoadClassPropertyTemporaneousStaticList, nil, 0);
										}
										if NOT(err)
										{	if NOT(err = _SetClassMethodsObjID(bRecP, &bifernoClass))
											{	if NOT(classObjID = DLM_GetObjID(loadList, bifernoClass.className, nil, nil))
												{	if NOT(err = _IsInOtherScope(className, tScope, bRecP->local.classList, true))
													{	if (NOT(DLM_GetObjID(gsDispatcherData.reservedKeyword, bifernoClass.className, nil, nil)))
														{	classObjID = DLM_NewObj(loadList, bifernoClass.className, (Ptr)&bifernoClass, sizeof(BifernoClass), 0, kFixedSize, &err);
															if (tScope == APPLICATION)
																clID = -classObjID;
															else
																clID = -classObjID - LOCAL_ID_OFFSET;
															_AdjustMethodsPropertyClass(&bifernoClass, clID);
														}
														else
														{	bRecP->currentCtx.currentLine = saveLine;
															err = XError(kBAPI_Error, Err_ReservedKeyword);
														}
													}
													else
														bRecP->currentCtx.currentLine = saveLine;
												}
												else
												{	
												BifernoClass	previousClass;
												long			tLen;
												
													tLen = sizeof(BifernoClass);
													if NOT(err = DLM_GetObj(loadList, classObjID, (Ptr)&previousClass, &tLen, 0, nil))
													{	if (_SameFile(bRecP->curFile.filePath, saveLine, previousClass.sourceFilePath, previousClass.sourceLine))
														{	bRecP->currentCtx.currentLine = saveLine;
															err = XError(kBAPI_Error, Err_ClassRedeclared);
														}
														else
														{	destructRec.api_data = api_data;
															destructRec.scope = tScope;
															if NOT(err = DisposeBifernoClass(loadList, classObjID, 0, 0, (long)&destructRec))
															{	if (tScope == APPLICATION)
																	clID = -classObjID;
																else
																	clID = -classObjID - LOCAL_ID_OFFSET;
																_AdjustMethodsPropertyClass(&bifernoClass, clID);
																err = DLM_ModifyObj(loadList, classObjID, (Ptr)&bifernoClass, sizeof(BifernoClass), 0, nil, 0L, nil);
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

if (err)
{	if (bifernoClass.properties)
		DLM_DisposeGlobal(&bifernoClass.properties, nil, 0L);
	if (bifernoClass.methods)
		DLM_DisposeGlobal(&bifernoClass.methods, nil, 0L);
	if (bifernoClass.errors)
		DLM_DisposeGlobal(&bifernoClass.errors, nil, 0L);
	if (bifernoClass.constructorDoc)
		DisposeBlock(&bifernoClass.constructorDoc);
	if (bifernoClass.staticProperties)
	{	destructRec.api_data = api_data;
		destructRec.scope = tScope;
		DLM_DisposeGlobal(&bifernoClass.staticProperties, VariableDestructorExt, (long)&destructRec);
	}
}

*oldFilePPtr = tempP;
*lenP = len;
return err;
}

