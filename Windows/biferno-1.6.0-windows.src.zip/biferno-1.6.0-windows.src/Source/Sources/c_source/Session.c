/*	
	|
	|	Biferno Web Script Language
	|
	|______________________________________________________________________________
	|	Biferno is a new generation, Cross Platform Web Scripting Language 
	|	that allows developers the rapid implementation of dynamic Web applications 
	|	and of Web sites that offer a high degree of user interactivity. 
	|	
	|	Copyright (C) 2002  Tabasoft Sas 
	|	
	|	This program is free software; you can redistribute it and/or modify 
	|	it under the terms of the GNU General Public License as published by 
	|	the Free Software Foundation; either version 2 of the License, or 
	|	(at your option) any later version. 
	|	
	|	This program is distributed in the hope that it will be useful, 
	|	but WITHOUT ANY WARRANTY; without even the implied warranty of 
	|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
	|	GNU General Public License for more details. 
	|	
	|	You should have received a copy of the GNU General Public License 
	|	along with this program; if not, write to the Free Software 
	|	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
	|______________________________________________________________________________
	|
	|	$Id: Session.c,v 1.18 2008-04-21 12:37:02 tabasoft Exp $
	|______________________________________________________________________________
*/
#include "XLib.h"


#include "BifernoAPI.h"
#include "BifernoEngineAPI.h"
#include "Variable.h"
#include "Dispatcher.h"
#include "Eval.h"
#include "Flower.h"
#include "Param.h"
#include "Entity.h"
#include "BfrParser.h"
#include "Load.h"
#include "BfrSession.h"

extern DispatcherData	gsDispatcherData;

#include <stdio.h>
#include <string.h>

//#include "XMemoryPrivate.h"

#define	MAGIC_NUMBER	30101968

// this must be LIST_USER_DATA_DIM in dim
typedef struct {
	unsigned long 	lastAccess;
	unsigned long	users;
	BlockRef		csBlockRef;		// session-based critical section
} SessionListRecord;

//===========================================================================================
static XErr	_Session_GetRecord(DLMRef sessionList, SessionListRecord *sessionListRecP)
{
	return DLM_ListInfo(sessionList, nil, (Byte*)sessionListRecP, nil, nil);
}

#if __MWERKS__
#pragma mark-
#endif

//===========================================================================================
LONGLONG	SIDCheckSum(char *sid)
{
char		*sidP = sid;
int			ch;
LONGLONG	ll;

	ll = 0;
	while(ch = *sidP++)
	{	
		ll += ((LONGLONG)ch * (LONGLONG)MAGIC_NUMBER);
	}
	
return ll;
}

//===========================================================================================
XErr	Session_FreeList(DLMRef *sessionListP, BlockRef csBlockRef, BlockRef *curSessionCSP)
{
DLMRef				sessionList = *sessionListP;
BfrDestructRec		destructRec;
SessionListRecord	sessionListRec;
XErr				err = noErr;

	if not(csBlockRef)
	{
		if NOT(err = _Session_GetRecord(*sessionListP, &sessionListRec))
			csBlockRef = sessionListRec.csBlockRef;
	}
	if not(err)
	{
		destructRec.api_data = 0;
		destructRec.scope = SESSION;
		DLM_Dispose(&sessionList, VariableDestructor, (long)&destructRec);
		if (curSessionCSP && csBlockRef == *curSessionCSP)
			*curSessionCSP = 0;
		XDeleteCS(&csBlockRef);
	}
	
return err;
}

//===========================================================================================
XErr	Session_GarbageCollection(void)
{
long				diff, totSessions, tLen, totAppls, objID;
XErr				err = noErr;
unsigned long		now;
DLMRef				sessionList, genApplList;
int					i, j;
CStr63				listName;
Application			appRec;
SessionListRecord	sessionListRec;

	XThreadsEnterCriticalSection();
	genApplList = gsDispatcherData.globApplicationListArray;
	if (NOT(err = DLM_GetTotObjs(genApplList, &totAppls, false)) && totAppls)
	{	XGetSeconds(&now);
		for (i = 1; (i <= totAppls) && NOT(err); i++)
		{	tLen = sizeof(Application);
			if (NOT(err = DLM_GetIndObj(genApplList, i, (Ptr)&appRec, &tLen, 0, nil, nil, listName, false, false)) && appRec.sessionOK)
			{	if (NOT(err = DLM_GetTotObjs(appRec.sessionsArrayList, &totSessions, false)) && totSessions)
				{	for (j = 1; (j <= totSessions) && NOT(err); j++)
					{	if (NOT(err = DLM_GetIndObj(appRec.sessionsArrayList, j, nil, nil, 0, &sessionList, &objID, listName, false, false)) && *listName && appRec.sessionOK)
						{	if NOT(err = _Session_GetRecord(sessionList, &sessionListRec))
							{	diff = now - sessionListRec.lastAccess;
								if ((((unsigned long)diff > appRec.session_timeout) && (diff > 0) && NOT(sessionListRec.users)))
								{	
									Session_FreeList(&sessionList, sessionListRec.csBlockRef, nil);

									// note that Can' delete dlm because can't modify list that other users are using
									err = DLM_SetName(appRec.sessionsArrayList, objID, "");
								}
							}
						}
					}
				}
			}
		}
	}
	XThreadsLeaveCriticalSection();

return err;
}

//===========================================================================================
XErr	Session_SetList(BifernoRec *bRecP, char *SIDStr, char *XIDStr)
{
#if __C_HAS_PRAGMA_UNUSED__
	#pragma unused(SIDStr)		// comment if unique IP (see note 1)
#endif
long				diff, objID;
XErr				err = noErr;
unsigned long		now;
Application			*applP = &bRecP->application;
CStr255				aCStr;
SessionListRecord	sessionListRec;
BfrDestructRec		destructRec;
DLMRef				sessArList;

	XThreadsEnterCriticalSection();
	sessArList = applP->sessionsArrayList;
	XGetSeconds(&now);
	objID = DLM_GetObjID(sessArList, bRecP->SID, nil, (long*)&bRecP->sessionList);
	if (objID)
	{	if NOT(err = _Session_GetRecord(bRecP->sessionList, &sessionListRec))
		{	
			diff = now - sessionListRec.lastAccess;
			// if (diff > 0) because the precision of clock can generate diff -1
			if (((unsigned long)diff > applP->session_timeout) && (diff > 0) && NOT(sessionListRec.users))
			{	
				destructRec.api_data = (long)bRecP;
				destructRec.scope = SESSION;
				DLM_ResetList(bRecP->sessionList, VariableDestructor, (long)&destructRec, 0, false);
				sessionListRec.users = 1;
			}
			else
				sessionListRec.users++;
		}
	}
	else
	{	
		sessionListRec.users = 1;
		// create critical section for this user
		if not(err = XNewCS(&sessionListRec.csBlockRef))
		{
			if NOT(err = DLM_Create(&bRecP->sessionList, NAMECS_LIST, LOCAL_LIST))
			{	
				// Try to get an available object with empty name (if exists is the first)
				err = DLM_GetIndObj(sessArList, 1, nil, nil, 0, nil, &objID, aCStr, true, false);
				if (NOT(err) && NOT(*aCStr))
				{	
					if NOT(err = DLM_SetName(sessArList, objID, bRecP->SID))
						err = DLM_ModifyObj(sessArList, objID, nil, 0, bRecP->sessionList,nil, 0, nil);
				}
				else
					DLM_NewObj(sessArList, bRecP->SID, nil, 0, bRecP->sessionList, 0, &err);
				if (err)
					DLM_Dispose(&bRecP->sessionList, nil, 0);
				else
					bRecP->sessionFirstTime = true;
			}
			if (err)
				XDeleteCS(&sessionListRec.csBlockRef);
		}
	}
	if NOT(err)
	{	sessionListRec.lastAccess = now;
		DLM_SetListUserData(bRecP->sessionList, (Byte*)&sessionListRec);
		if (*XIDStr)
			CStringToLongNum(XIDStr, CLen(XIDStr), &bRecP->XID);
		else
		{	bRecP->XID = SIDCheckSum(bRecP->SID);
			CLongNumToString(bRecP->XID, XIDStr);
		}
	}
	XThreadsLeaveCriticalSection();
	
	/*if (_Locking())
	{
		unsigned long threadID;
		
		XGetCurrentThread(&threadID);
		printf("thread %d entered (%s %d), acquired mutex %d\n", threadID, bRecP->SID, sessionListRec.users, sessionListRec.csBlockRef);
	}*/
	
	/*
	 NOTE: XEnterCS must be after XThreadsLeaveCriticalSection, otherwise -> dead lock
	 */
	XEnterCS(sessionListRec.csBlockRef);	
	bRecP->sessionCS = sessionListRec.csBlockRef;
	
	return err;
}

//===========================================================================================
XErr	Session_CloseList(BifernoRec *bRecP)
{
SessionListRecord	sessionListRec;
XErr				err = noErr;

	if (bRecP->sessionList)
	{	
		XThreadsEnterCriticalSection();
		if NOT(err = _Session_GetRecord(bRecP->sessionList, &sessionListRec))
		{	
			sessionListRec.users--;
			DLM_SetListUserData(bRecP->sessionList, (Byte*)&sessionListRec);
		}
		XThreadsLeaveCriticalSection();
	}
	
return err;
}

//===========================================================================================
XErr	GetIndSessionSID(BifernoRecP bRecP, long index, char *SIDStr)
{
long				diff, totObjs, objID;
XErr				err = noErr;
unsigned long		now;
DLMRef				dlmRef;
CStr63				listName;
Application			*applP = &bRecP->application;
SessionListRecord	sessionListRec;
BfrDestructRec		destructRec;

	*SIDStr = 0;
	if (applP->sessionOK)
	{	if NOT(index)
			CEquStr(SIDStr, bRecP->SID);
		else if (NOT(err = DLM_GetTotObjs(applP->sessionsArrayList, &totObjs, false)) && totObjs)
		{	if ((index > 0) && (index <= totObjs))
			{	XGetSeconds(&now);
				if NOT(err = DLM_GetIndObj(applP->sessionsArrayList, index, nil, nil, 0, &dlmRef, &objID, listName, false, false))
				{	if NOT(err = _Session_GetRecord(dlmRef, &sessionListRec))
					{	diff = now - sessionListRec.lastAccess;
						if (((unsigned long)diff > applP->session_timeout) && (diff > 0) && NOT(sessionListRec.users))
						{	
							destructRec.api_data = 0;
							destructRec.scope = SESSION;
							DLM_ResetList(dlmRef, VariableDestructor, (long)&destructRec, 0, false);
						}
						else
							CEquStr(SIDStr, listName);
					}
				}
			}
		}
	}

return err;
}

//===========================================================================================
XErr	ListFromSID(Application *applP, char *SIDStr, DLMRef *listP)
{
long				diff, objID;
XErr				err = noErr;
unsigned long		now;
DLMRef				sessionList;
SessionListRecord	sessionListRec;

	*listP = 0;
	if (applP->sessionOK)
	{	objID = DLM_GetObjID(applP->sessionsArrayList, SIDStr, nil, (long*)&sessionList);
		if (objID)
		{	XGetSeconds(&now);
			if NOT(err = _Session_GetRecord(sessionList, &sessionListRec))
			{	diff = now - sessionListRec.lastAccess;
				if ((unsigned long)diff < applP->session_timeout)
					*listP = sessionList;
				else
				{	

				}
			}
		}
	}

return err;
}

//===========================================================================================
XErr	Session_GetLastAccess(Application *applP, char *SIDStr, XDateTimeRec *lastAccessP)
{
XErr				err = noErr;
DLMRef				sessionList;
SessionListRecord	sessionListRec;

	if NOT(err = ListFromSID(applP, SIDStr, &sessionList))
	{	
		if NOT(err = DLM_ListInfo(sessionList, nil, (Byte*)&sessionListRec, nil, nil))
			SecondsToXDateTime(sessionListRec.lastAccess, lastAccessP);
	}

return err;
}


